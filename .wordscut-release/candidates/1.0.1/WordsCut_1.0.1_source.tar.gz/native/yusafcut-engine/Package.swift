// swift-tools-version:5.9
import PackageDescription

// YusafCut native media engine (first slice). Separate from the capture helper
// (`native/yusafcut-capture`). Contract: `docs/native-engine.md`.
let package = Package(
    name: "yusafcut-engine",
    platforms: [.macOS(.v13)],
    products: [
        .executable(name: "yusafcut-engine", targets: ["yusafcut-engine"]),
        .library(name: "EngineCore", targets: ["EngineCore"]),
        .library(name: "EngineMedia", targets: ["EngineMedia"]),
    ],
    targets: [
        // Pure logic: the render-plan model, validation, reason codes, timing.
        .target(name: "EngineCore"),
        // Apple frameworks: capabilities probe, AVFoundation composition builder.
        .target(name: "EngineMedia", dependencies: ["EngineCore"]),
        // JSON CLI: `capabilities`, `validate <plan>`, `probe-plan <plan>`.
        .executableTarget(name: "yusafcut-engine", dependencies: ["EngineCore", "EngineMedia"]),
        .testTarget(name: "EngineCoreTests", dependencies: ["EngineCore"]),
        .testTarget(name: "EngineMediaTests", dependencies: ["EngineMedia", "EngineCore"]),
    ]
)
