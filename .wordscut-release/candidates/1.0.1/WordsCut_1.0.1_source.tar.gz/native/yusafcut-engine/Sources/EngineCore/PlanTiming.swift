import Foundation

/// Where one clip lands, in integer ticks of `PlanTiming.timescale`.
public struct ClipTiming: Equatable, Sendable {
    /// Index into `plan.clips`.
    public var clipIndex: Int
    /// First source tick read.
    public var sourceStart: Int64
    /// Source ticks read (`play * speed`).
    public var consumed: Int64
    /// Output ticks of footage.
    public var play: Int64
    /// Output ticks of freeze after the footage.
    public var hold: Int64
    /// Output tick the clip starts at.
    public var outputStart: Int64
    public var outputEnd: Int64 { outputStart + play + hold }
}

/// Timing rules shared with `src/lib/nativeEngine.ts` (mirror every change there;
/// the parity fixture `tests/fixtures/native-engine-timing.json` pins both).
public enum PlanTiming {
    /// 90 kHz: every common frame rate (24, 25, 30, 48, 50, 60, 120 and the
    /// 1000/1001 NTSC rates) is a whole number of ticks per frame.
    public static let timescale: Int32 = 90_000

    public static func ticks(_ seconds: Double) -> Int64 {
        Int64((seconds * Double(timescale)).rounded())
    }

    /// Ticks per output frame, or nil when the rate is not a whole number of ticks.
    public static func frameTicks(_ fps: RationalFPS) -> Int64? {
        guard fps.num > 0, fps.den > 0 else { return nil }
        let n = Int64(timescale) * fps.den
        return n % fps.num == 0 ? n / fps.num : nil
    }

    /// Whole frames per length by error diffusion over the running total, the
    /// same rule as the export planner (`export_plan.rs::frame_counts`): the
    /// running output never drifts more than half a frame from the EDL.
    public static func frameCounts(_ lens: [Double], fps: Double) -> [Int64] {
        var out: [Int64] = []
        out.reserveCapacity(lens.count)
        var total = 0.0
        var emitted = 0.0
        for raw in lens {
            let d = raw.isFinite ? max(raw, 0) : 0
            total += d
            let n = max(((total - emitted) * fps + 1e-9).rounded(), 0)
            emitted += n / fps
            out.append(Int64(n))
        }
        if out.allSatisfy({ $0 == 0 }), let i = lens.firstIndex(where: { $0.isFinite && $0 > 0 }) {
            out[i] = 1
        }
        return out
    }

    /// Output seconds of footage for a clip (EDL `segmentPlayLength`).
    public static func playSeconds(_ c: PlanClip) -> Double {
        max(0, c.sourceOut - c.sourceIn) / c.effectiveSpeed
    }

    /// Lay out every clip. Assumes a plan that passed `PlanValidator`.
    /// Clips that end up with no output ticks are omitted.
    public static func layout(_ plan: RenderPlan) -> [ClipTiming] {
        var result: [ClipTiming] = []
        var cursor: Int64 = 0
        if plan.isQuantized, let ft = frameTicks(plan.fps) {
            var lens: [Double] = []
            for c in plan.clips {
                let play = playSeconds(c)
                lens.append(play)
                lens.append(play > 0 ? max(0, c.effectiveHold) : 0)
            }
            let n = frameCounts(lens, fps: plan.fps.seconds)
            for (i, c) in plan.clips.enumerated() {
                let play = n[2 * i] * ft
                let hold = n[2 * i + 1] * ft
                if play + hold == 0 { continue }
                let speed = c.effectiveSpeed
                let consumed = speed == 1 ? play : Int64((Double(play) * speed).rounded())
                result.append(ClipTiming(clipIndex: i, sourceStart: ticks(max(0, c.sourceIn)),
                                         consumed: consumed, play: play, hold: hold, outputStart: cursor))
                cursor += play + hold
            }
        } else {
            for (i, c) in plan.clips.enumerated() {
                let start = ticks(max(0, c.sourceIn))
                let consumed = max(0, ticks(c.sourceOut) - start)
                if consumed == 0 { continue }
                let speed = c.effectiveSpeed
                let play = speed == 1 ? consumed : Int64((Double(consumed) / speed).rounded())
                let hold = ticks(max(0, c.effectiveHold))
                result.append(ClipTiming(clipIndex: i, sourceStart: start, consumed: consumed,
                                         play: play, hold: hold, outputStart: cursor))
                cursor += play + hold
            }
        }
        return result
    }

    /// Total output ticks the plan describes.
    public static func durationTicks(_ plan: RenderPlan) -> Int64 {
        layout(plan).last?.outputEnd ?? 0
    }
}
