import Foundation

/// Render-plan schema version this engine understands. Bump on breaking changes;
/// the host sends `version` and an unknown version is refused (`plan-version-unsupported`).
public let renderPlanVersion = 1

/// Output frame rate as an exact rational (`30000/1001`, `30/1`).
public struct RationalFPS: Codable, Equatable, Sendable {
    public var num: Int64
    public var den: Int64
    public init(num: Int64, den: Int64) {
        self.num = num
        self.den = den
    }
    public var seconds: Double { Double(num) / Double(den) }
}

/// Normalised rectangle (0...1 of the canvas or the source picture).
public struct NormRect: Codable, Equatable, Sendable {
    public var x: Double
    public var y: Double
    public var width: Double
    public var height: Double
    public init(x: Double, y: Double, width: Double, height: Double) {
        self.x = x
        self.y = y
        self.width = width
        self.height = height
    }
}

/// One media file the plan reads. Repeated ranges of one file share one source.
public struct PlanSource: Codable, Equatable, Sendable {
    public var id: String
    public var path: String
    /// Seconds, as probed by the host (informational; the engine re-reads the file).
    public var duration: Double?
    /// Host hint; the engine trusts the file, not this flag.
    public var hasVideo: Bool?
    public var hasAudio: Bool?
    /// Source crop. Any crop routes to fallback (`crop`) in this slice.
    public var crop: NormRect?
    public init(id: String, path: String, duration: Double? = nil, hasVideo: Bool? = nil,
                hasAudio: Bool? = nil, crop: NormRect? = nil) {
        self.id = id
        self.path = path
        self.duration = duration
        self.hasVideo = hasVideo
        self.hasAudio = hasAudio
        self.crop = crop
    }
}

/// One clip of the main timeline, in output order. Mirrors an EDL `Segment`.
public struct PlanClip: Codable, Equatable, Sendable {
    public var sourceId: String
    /// Source seconds, `[sourceIn, sourceOut)`.
    public var sourceIn: Double
    public var sourceOut: Double
    /// Source seconds per output second. Absent = 1.
    public var speed: Double?
    /// Output seconds of freeze on the clip's last played frame. Absent = 0.
    public var holdSec: Double?
    /// Silence this clip's own audio (and its group audio). Absent = false.
    public var muted: Bool?
    public init(sourceId: String, sourceIn: Double, sourceOut: Double, speed: Double? = nil,
                holdSec: Double? = nil, muted: Bool? = nil) {
        self.sourceId = sourceId
        self.sourceIn = sourceIn
        self.sourceOut = sourceOut
        self.speed = speed
        self.holdSec = holdSec
        self.muted = muted
    }
    public var effectiveSpeed: Double { speed ?? 1 }
    public var effectiveHold: Double { holdSec ?? 0 }
}

public enum GroupTrackRole: String, Codable, Sendable {
    /// A second video track (the camera), composited later; timing only in this slice.
    case camera
    /// An extra audio track of the take (mic, system audio).
    case audio
}

/// A track recorded alongside a primary source on a shared clock.
public struct GroupTrack: Codable, Equatable, Sendable {
    public var sourceId: String
    public var role: GroupTrackRole
    /// Seconds this track started after the primary source (negative: before).
    /// Track time for primary source time `t` is `t - offsetSec`.
    public var offsetSec: Double
    public var gainDb: Double?
    /// Where the camera sits on the canvas. Not rendered yet (no compositor).
    public var placement: NormRect?
    public init(sourceId: String, role: GroupTrackRole, offsetSec: Double, gainDb: Double? = nil,
                placement: NormRect? = nil) {
        self.sourceId = sourceId
        self.role = role
        self.offsetSec = offsetSec
        self.gainDb = gainDb
        self.placement = placement
    }
}

/// Tracks that follow every clip cut from `primarySourceId`.
public struct RecordingGroup: Codable, Equatable, Sendable {
    public var primarySourceId: String
    public var tracks: [GroupTrack]
    public init(primarySourceId: String, tracks: [GroupTrack]) {
        self.primarySourceId = primarySourceId
        self.tracks = tracks
    }
}

/// A music / SFX bed on the output timeline (already resolved for mute / solo by the host).
public struct AudioBed: Codable, Equatable, Sendable {
    public var sourceId: String
    /// Output seconds; negative starts the bed's media at `-offsetSec`.
    public var offsetSec: Double
    public var gainDb: Double
    public init(sourceId: String, offsetSec: Double, gainDb: Double) {
        self.sourceId = sourceId
        self.offsetSec = offsetSec
        self.gainDb = gainDb
    }
}

/// The JSON render plan compiled by the host from the EDL (`src/lib/nativeEngine.ts`).
public struct RenderPlan: Codable, Equatable, Sendable {
    public var version: Int
    /// Monotonic request number; latest request wins (see docs/native-engine.md).
    public var generation: UInt64?
    public var fps: RationalFPS
    /// Snap every clip and hold to whole output frames (error diffusion). Absent = true.
    public var quantize: Bool?
    /// Fallback reason codes for project features present that this engine cannot do.
    public var requires: [String]?
    public var sources: [PlanSource]
    public var clips: [PlanClip]
    public var groups: [RecordingGroup]?
    public var audioBeds: [AudioBed]?
    public init(version: Int = renderPlanVersion, generation: UInt64? = nil, fps: RationalFPS,
                quantize: Bool? = nil, requires: [String]? = nil, sources: [PlanSource],
                clips: [PlanClip], groups: [RecordingGroup]? = nil, audioBeds: [AudioBed]? = nil) {
        self.version = version
        self.generation = generation
        self.fps = fps
        self.quantize = quantize
        self.requires = requires
        self.sources = sources
        self.clips = clips
        self.groups = groups
        self.audioBeds = audioBeds
    }
    public var isQuantized: Bool { quantize ?? true }

    public static func decode(_ data: Data) throws -> RenderPlan {
        try JSONDecoder().decode(RenderPlan.self, from: data)
    }
}
