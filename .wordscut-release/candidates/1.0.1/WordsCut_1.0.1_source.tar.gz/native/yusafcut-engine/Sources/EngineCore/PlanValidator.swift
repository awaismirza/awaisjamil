import Foundation

/// Structural and capability checks. Returns the FIRST failing reason, in a
/// fixed order (structure before features), so the host gets a stable code.
public enum PlanValidator {
    /// Bounded-memory limits (docs/native-engine.md → "Bounded memory").
    public static let maxSources = 64
    public static let maxClips = 10_000
    public static let maxGroupTracks = 8
    public static let maxAudioBeds = 16
    public static let minSpeed = 0.25
    public static let maxSpeed = 4.0
    public static let maxHoldSec = 3600.0
    public static let maxGainDb = 24.0
    /// Plans longer than this are refused (`plan-too-large`), in seconds.
    public static let maxOutputSec = 24.0 * 3600

    public static func validate(_ plan: RenderPlan) -> ValidationResult {
        if plan.version != renderPlanVersion {
            return .fail(Reason.versionUnsupported, .invalid, "version \(plan.version), engine speaks \(renderPlanVersion)")
        }
        if plan.clips.isEmpty { return .fail(Reason.empty, .invalid, "no clips") }
        let groupTracks = (plan.groups ?? []).reduce(0) { $0 + $1.tracks.count }
        if plan.sources.count > maxSources || plan.clips.count > maxClips
            || groupTracks > maxGroupTracks || (plan.audioBeds ?? []).count > maxAudioBeds {
            return .fail(Reason.tooLarge, .invalid,
                         "\(plan.sources.count) sources, \(plan.clips.count) clips, \(groupTracks) group tracks")
        }
        if plan.fps.num <= 0 || plan.fps.den <= 0 || plan.fps.seconds > 240 || plan.fps.seconds < 1 {
            return .fail(Reason.fpsInvalid, .invalid, "\(plan.fps.num)/\(plan.fps.den)")
        }
        if PlanTiming.frameTicks(plan.fps) == nil {
            return .fail(Reason.fpsNotRepresentable, .unsupported,
                         "\(plan.fps.num)/\(plan.fps.den) is not whole ticks at \(PlanTiming.timescale) Hz")
        }

        var ids = Set<String>()
        for s in plan.sources {
            if s.id.isEmpty || s.path.isEmpty || !ids.insert(s.id).inserted {
                return .fail(Reason.sourceDuplicate, .invalid, "source '\(s.id)' is empty or repeated")
            }
        }

        var total = 0.0
        for (i, c) in plan.clips.enumerated() {
            if !ids.contains(c.sourceId) {
                return .fail(Reason.sourceUnknown, .invalid, "clip \(i) names '\(c.sourceId)'")
            }
            if !c.sourceIn.isFinite || !c.sourceOut.isFinite || c.sourceIn < 0 || c.sourceOut < c.sourceIn {
                return .fail(Reason.clipRange, .invalid, "clip \(i): \(c.sourceIn)..\(c.sourceOut)")
            }
            if let s = c.speed, !(s.isFinite && s >= minSpeed && s <= maxSpeed) {
                return .fail(Reason.speedRange, .invalid, "clip \(i): speed \(s)")
            }
            if let h = c.holdSec, !(h.isFinite && h >= 0 && h <= maxHoldSec) {
                return .fail(Reason.holdRange, .invalid, "clip \(i): hold \(h)")
            }
            total += PlanTiming.playSeconds(c) + c.effectiveHold
        }
        if total > maxOutputSec { return .fail(Reason.tooLarge, .invalid, "\(total) s of output") }
        if total <= 0 { return .fail(Reason.empty, .invalid, "every clip is empty") }

        for g in plan.groups ?? [] {
            if !ids.contains(g.primarySourceId) {
                return .fail(Reason.sourceUnknown, .invalid, "group primary '\(g.primarySourceId)'")
            }
            for t in g.tracks {
                if !ids.contains(t.sourceId) {
                    return .fail(Reason.sourceUnknown, .invalid, "group track '\(t.sourceId)'")
                }
                if t.sourceId == g.primarySourceId || !t.offsetSec.isFinite {
                    return .fail(Reason.groupInvalid, .invalid, "group track '\(t.sourceId)'")
                }
                if let gain = t.gainDb, !validGain(gain) {
                    return .fail(Reason.gainInvalid, .invalid, "group track gain \(gain)")
                }
            }
        }
        for b in plan.audioBeds ?? [] {
            if !ids.contains(b.sourceId) {
                return .fail(Reason.sourceUnknown, .invalid, "audio bed '\(b.sourceId)'")
            }
            if !b.offsetSec.isFinite || !validGain(b.gainDb) {
                return .fail(Reason.gainInvalid, .invalid, "audio bed '\(b.sourceId)'")
            }
        }

        // Features: host-declared first (in the host's order), then what the plan shows.
        for code in plan.requires ?? [] {
            if Reason.unsupportedFeatures.contains(code) {
                return .fail(code, .unsupported, "project uses \(code)")
            }
            return .fail(Reason.unknownFeature, .unsupported, "unknown feature '\(code)'")
        }
        if plan.sources.contains(where: { $0.crop != nil }) {
            return .fail("crop", .unsupported, "source crop")
        }
        return .pass
    }

    static func validGain(_ db: Double) -> Bool { db.isFinite && db <= maxGainDb }
}
