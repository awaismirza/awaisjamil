/// Stable fallback / error reason codes. These strings are part of the contract
/// (docs/native-engine.md, src/lib/nativeEngine.ts): never rename one, only add.
public enum ReasonKind: String, Codable, Sendable {
    /// The plan is well-formed but asks for something this engine cannot do yet.
    case unsupported
    /// The plan is malformed; the host has a bug. Still routes to fallback.
    case invalid
}

public enum Reason {
    // Unsupported project features (host-declared in `requires`, or seen in the plan).
    public static let unsupportedFeatures: [String] = [
        "transition",
        "zoom",
        "cursor",
        "scene",
        "device-frame",
        "crop",
        "captions",
        "annotations",
        "keystrokes",
        "overlays",
        "privacy-mask",
        "voice-over",
        "music-ducking",
        "audio-fade",
    ]
    public static let unknownFeature = "unknown-feature"

    // Invalid plans.
    public static let versionUnsupported = "plan-version-unsupported"
    public static let empty = "plan-empty"
    public static let tooLarge = "plan-too-large"
    public static let fpsInvalid = "fps-invalid"
    public static let fpsNotRepresentable = "fps-not-representable"
    public static let sourceDuplicate = "source-duplicate-id"
    public static let sourceUnknown = "source-unknown"
    public static let clipRange = "clip-range-invalid"
    public static let speedRange = "clip-speed-out-of-range"
    public static let holdRange = "hold-out-of-range"
    public static let groupInvalid = "group-invalid"
    public static let gainInvalid = "gain-invalid"

    // Runtime errors from the composition builder.
    public static let sourceUnreadable = "source-unreadable"
    public static let insertFailed = "composition-insert-failed"
    /// The plan ends in a stretch with no picture and no sound (AVFoundation
    /// drops trailing empty edits, so the composition would come out short).
    public static let tailGap = "tail-gap-unsupported"
}

public struct ValidationResult: Codable, Equatable, Sendable {
    public var ok: Bool
    public var reason: String?
    public var kind: ReasonKind?
    public var detail: String?
    public static let pass = ValidationResult(ok: true, reason: nil, kind: nil, detail: nil)
    public static func fail(_ reason: String, _ kind: ReasonKind, _ detail: String) -> ValidationResult {
        ValidationResult(ok: false, reason: reason, kind: kind, detail: detail)
    }
}

/// An error with a stable code, raised while building a composition.
public struct EngineError: Error, CustomStringConvertible, Sendable {
    public var code: String
    public var message: String
    public init(_ code: String, _ message: String) {
        self.code = code
        self.message = message
    }
    public var description: String { "\(code): \(message)" }
}
