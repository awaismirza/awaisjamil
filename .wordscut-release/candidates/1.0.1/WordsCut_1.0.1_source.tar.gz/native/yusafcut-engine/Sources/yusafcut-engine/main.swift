import EngineCore
import EngineMedia
import Foundation

// yusafcut-engine: one JSON object per run on stdout.
//
//   yusafcut-engine capabilities
//   yusafcut-engine validate <plan.json | ->
//   yusafcut-engine probe-plan <plan.json | ->
//
// Exit codes: 0 ok, 1 the plan is unsupported / invalid / failed to build
// (JSON still printed, with a stable `reason`), 2 usage or unreadable input.

func emit<T: Encodable>(_ value: T) {
    let enc = JSONEncoder()
    enc.outputFormatting = [.sortedKeys]
    if let data = try? enc.encode(value), let s = String(data: data, encoding: .utf8) {
        print(s)
    }
}

struct Failure: Encodable {
    var ok = false
    var reason: String
    var kind: String
    var detail: String
    var generation: UInt64?
}

func readPlan(_ arg: String) -> RenderPlan? {
    let data: Data?
    if arg == "-" {
        data = FileHandle.standardInput.readDataToEndOfFile()
    } else {
        data = FileManager.default.contents(atPath: arg)
    }
    guard let data else {
        emit(Failure(reason: "plan-unreadable", kind: "invalid", detail: "cannot read \(arg)"))
        return nil
    }
    do {
        return try RenderPlan.decode(data)
    } catch {
        emit(Failure(reason: "plan-malformed", kind: "invalid", detail: "\(error)"))
        return nil
    }
}

let args = Array(CommandLine.arguments.dropFirst())
switch (args.first, args.count) {
case ("capabilities", 1):
    emit(EngineCapabilities.probe())
    exit(0)
case ("validate", 2):
    guard let plan = readPlan(args[1]) else { exit(2) }
    let r = PlanValidator.validate(plan)
    if r.ok {
        struct Ok: Encodable { var ok = true; var generation: UInt64?; var expectedDurationTicks: Int64; var timescale: Int32 }
        emit(Ok(generation: plan.generation, expectedDurationTicks: PlanTiming.durationTicks(plan),
                timescale: PlanTiming.timescale))
        exit(0)
    }
    emit(Failure(reason: r.reason ?? "", kind: r.kind?.rawValue ?? "invalid", detail: r.detail ?? "",
                 generation: plan.generation))
    exit(1)
case ("probe-plan", 2):
    guard let plan = readPlan(args[1]) else { exit(2) }
    let sema = DispatchSemaphore(value: 0)
    var code: Int32 = 0
    Task {
        do {
            let built = try await PlanComposition.build(plan)
            emit(built.report())
        } catch let e as EngineError {
            let r = PlanValidator.validate(plan)
            emit(Failure(reason: e.code, kind: r.ok ? "error" : (r.kind?.rawValue ?? "invalid"),
                         detail: e.message, generation: plan.generation))
            code = 1
        } catch {
            emit(Failure(reason: "internal", kind: "error", detail: "\(error)", generation: plan.generation))
            code = 1
        }
        sema.signal()
    }
    sema.wait()
    exit(code)
default:
    FileHandle.standardError.write(Data("usage: yusafcut-engine capabilities | validate <plan.json|-> | probe-plan <plan.json|->\n".utf8))
    exit(2)
}
