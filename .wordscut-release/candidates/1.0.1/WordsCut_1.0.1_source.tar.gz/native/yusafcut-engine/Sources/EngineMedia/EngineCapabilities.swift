import CoreMedia
import Foundation
import Metal
import VideoToolbox

/// What this Mac can do for the native engine. Printed by `yusafcut-engine capabilities`
/// and read by the app (`engine_bridge::native_engine_capabilities`).
public struct EngineCapabilities: Codable, Equatable, Sendable {
    public struct VideoToolboxInfo: Codable, Equatable, Sendable {
        public var h264Encode: Bool
        public var hevcEncode: Bool
        /// Hardware (not software) encoders, when the list says so.
        public var h264Hardware: Bool
        public var hevcHardware: Bool
    }
    public struct MetalInfo: Codable, Equatable, Sendable {
        public var available: Bool
        public var name: String?
    }

    /// Engine build version (not the app version).
    public var engineVersion: String
    /// Render-plan schema version understood.
    public var planVersion: Int
    public var available: Bool
    /// Stable code when `available` is false.
    public var reason: String?
    public var macosVersion: String
    public var appleSilicon: Bool
    public var videoToolbox: VideoToolboxInfo
    public var metal: MetalInfo
    /// What this build implements: `probe` (composition timing) only, for now.
    /// Later slices add `preview` and `export`.
    public var levels: [String]

    public static let engineVersionString = "0.1.0"
    public static let minimumMacOS = OperatingSystemVersion(majorVersion: 13, minorVersion: 0, patchVersion: 0)

    /// Probe the running machine. Cheap (no media is opened).
    public static func probe() -> EngineCapabilities {
        let os = ProcessInfo.processInfo.operatingSystemVersion
        let osString = "\(os.majorVersion).\(os.minorVersion).\(os.patchVersion)"
        let arm = isAppleSilicon()
        let vt = videoToolboxInfo()
        let device = MTLCreateSystemDefaultDevice()
        let metal = MetalInfo(available: device != nil, name: device?.name)
        let osOK = ProcessInfo.processInfo.isOperatingSystemAtLeast(minimumMacOS)
        let reason: String?
        if !osOK {
            reason = "macos-too-old"
        } else if !arm {
            reason = "not-apple-silicon"
        } else if !metal.available {
            reason = "no-metal-device"
        } else {
            reason = nil
        }
        return EngineCapabilities(
            engineVersion: engineVersionString, planVersion: 1, available: reason == nil,
            reason: reason, macosVersion: osString, appleSilicon: arm, videoToolbox: vt,
            metal: metal, levels: reason == nil ? ["probe"] : [])
    }

    /// True on an arm64 Mac, including when this process runs translated.
    static func isAppleSilicon() -> Bool {
        var value: Int32 = 0
        var size = MemoryLayout<Int32>.size
        if sysctlbyname("hw.optional.arm64", &value, &size, nil, 0) == 0 { return value == 1 }
        return false
    }

    static func videoToolboxInfo() -> VideoToolboxInfo {
        var listRef: CFArray?
        guard VTCopyVideoEncoderList(nil, &listRef) == noErr,
              let list = listRef as? [[String: Any]] else {
            return VideoToolboxInfo(h264Encode: false, hevcEncode: false, h264Hardware: false, hevcHardware: false)
        }
        return encoderSummary(list)
    }

    /// Pure summary of a `VTCopyVideoEncoderList` result (testable with fakes).
    static func encoderSummary(_ list: [[String: Any]]) -> VideoToolboxInfo {
        let codecKey = kVTVideoEncoderList_CodecType as String
        let hwKey = kVTVideoEncoderList_IsHardwareAccelerated as String
        var info = VideoToolboxInfo(h264Encode: false, hevcEncode: false, h264Hardware: false, hevcHardware: false)
        for entry in list {
            guard let codec = (entry[codecKey] as? NSNumber)?.uint32Value else { continue }
            let hw = (entry[hwKey] as? Bool) ?? false
            if codec == kCMVideoCodecType_H264 {
                info.h264Encode = true
                info.h264Hardware = info.h264Hardware || hw
            } else if codec == kCMVideoCodecType_HEVC {
                info.hevcEncode = true
                info.hevcHardware = info.hevcHardware || hw
            }
        }
        return info
    }
}
