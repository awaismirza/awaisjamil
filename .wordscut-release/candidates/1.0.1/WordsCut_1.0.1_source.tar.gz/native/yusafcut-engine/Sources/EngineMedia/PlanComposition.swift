import AVFoundation
import CoreMedia
import EngineCore
import Foundation

/// One track of a built composition, as reported by `probe-plan`.
public struct ProbedTrack: Codable, Equatable, Sendable {
    public var id: Int32
    public var mediaType: String
    /// `main`, `camera`, `group-audio` or `bed`.
    public var role: String
    public var sourceId: String?
    public var durationTicks: Int64
    public var segments: Int
    /// Segments that carry media (not empty edits).
    public var mediaSegments: Int
}

public struct ProbeReport: Codable, Equatable, Sendable {
    public var ok: Bool
    public var generation: UInt64?
    public var timescale: Int32
    public var durationTicks: Int64
    public var durationSeconds: Double
    /// What `PlanTiming` says the plan lasts; equals `durationTicks` for a correct build.
    public var expectedDurationTicks: Int64
    public var clips: Int
    public var tracks: [ProbedTrack]
    public var hasAudioMix: Bool
}

private func tk(_ t: Int64) -> CMTime { CMTime(value: t, timescale: PlanTiming.timescale) }

private func toTicks(_ t: CMTime) -> Int64 {
    guard t.isNumeric else { return 0 }
    return t.convertScale(PlanTiming.timescale, method: .roundHalfAwayFromZero).value
}

/// A source track with its usable range, in ticks.
struct LoadedTrack {
    let track: AVAssetTrack
    let start: Int64
    let end: Int64
    /// One source frame (video) in ticks, 0 when unknown.
    let frameTicks: Int64
}

struct LoadedSource {
    let asset: AVURLAsset
    let video: LoadedTrack?
    let audio: LoadedTrack?
}

/// Builds an `AVMutableComposition` (+ audio mix) from a validated render plan.
///
/// Timing only: no video composition, no compositor, no export. Every source is
/// opened once however many clips use it (repeated ranges reuse the asset);
/// nothing is decoded, so memory stays bounded by the number of sources.
public final class PlanComposition {
    public let plan: RenderPlan
    public let composition: AVMutableComposition
    public let audioMix: AVMutableAudioMix?
    public let timings: [ClipTiming]
    public let roles: [CMPersistentTrackID: (role: String, sourceId: String?)]

    init(plan: RenderPlan, composition: AVMutableComposition, audioMix: AVMutableAudioMix?,
         timings: [ClipTiming], roles: [CMPersistentTrackID: (role: String, sourceId: String?)]) {
        self.plan = plan
        self.composition = composition
        self.audioMix = audioMix
        self.timings = timings
        self.roles = roles
    }

    public var durationTicks: Int64 { toTicks(composition.duration) }

    /// Validate, open the sources and build. Throws `EngineError` with a stable code.
    public static func build(_ plan: RenderPlan) async throws -> PlanComposition {
        let check = PlanValidator.validate(plan)
        if !check.ok {
            throw EngineError(check.reason ?? Reason.unknownFeature, check.detail ?? "")
        }
        var sources: [String: LoadedSource] = [:]
        for s in plan.sources {
            sources[s.id] = try await load(s)
        }
        let timings = PlanTiming.layout(plan)
        let total = timings.last?.outputEnd ?? 0
        let comp = AVMutableComposition()
        var roles: [CMPersistentTrackID: (role: String, sourceId: String?)] = [:]
        var mixParams: [AVMutableAudioMixInputParameters] = []

        func newTrack(_ type: AVMediaType, _ role: String, _ sourceId: String?) throws -> AVMutableCompositionTrack {
            guard let t = comp.addMutableTrack(withMediaType: type, preferredTrackID: kCMPersistentTrackID_Invalid) else {
                throw EngineError(Reason.insertFailed, "could not add a \(type.rawValue) track")
            }
            roles[t.trackID] = (role, sourceId)
            return t
        }

        // Main picture and sound.
        let mainVideo = try newTrack(.video, "main", nil)
        let mainAudio = try newTrack(.audio, "main", nil)
        for t in timings {
            let clip = plan.clips[t.clipIndex]
            let src = sources[clip.sourceId]!
            try place(mainVideo, src.video, start: t.sourceStart, consumed: t.consumed, at: t.outputStart,
                      play: t.play, freezeTail: true)
            try freeze(mainVideo, src.video, sourceEnd: t.sourceStart + t.consumed, at: t.outputStart + t.play,
                       hold: t.hold, fallbackFrame: PlanTiming.frameTicks(plan.fps) ?? 3000)
            let audio = clip.muted == true ? nil : src.audio
            try place(mainAudio, audio, start: t.sourceStart, consumed: t.consumed, at: t.outputStart, play: t.play)
            try empty(mainAudio, at: t.outputStart + t.play, t.hold)
        }

        // Recording-group tracks follow every clip of their primary source.
        for g in plan.groups ?? [] {
            for gt in g.tracks {
                let src = sources[gt.sourceId]!
                let isCamera = gt.role == .camera
                let track = try newTrack(isCamera ? .video : .audio, isCamera ? "camera" : "group-audio", gt.sourceId)
                let off = PlanTiming.ticks(gt.offsetSec)
                for t in timings {
                    let clip = plan.clips[t.clipIndex]
                    let own = clip.sourceId == g.primarySourceId
                    let media = own ? (isCamera ? src.video : (clip.muted == true ? nil : src.audio)) : nil
                    let start = t.sourceStart - off
                    try place(track, media, start: start, consumed: t.consumed, at: t.outputStart, play: t.play,
                              freezeTail: isCamera)
                    if isCamera, own {
                        try freeze(track, media, sourceEnd: start + t.consumed, at: t.outputStart + t.play,
                                   hold: t.hold, fallbackFrame: PlanTiming.frameTicks(plan.fps) ?? 3000)
                    } else {
                        try empty(track, at: t.outputStart + t.play, t.hold)
                    }
                }
                if !isCamera, let gain = gt.gainDb, gain != 0 {
                    let p = AVMutableAudioMixInputParameters(track: track)
                    p.setVolume(linear(gain), at: .zero)
                    mixParams.append(p)
                }
            }
        }

        // Music / SFX beds: whole file from the offset, cut at the end of the edit.
        for b in plan.audioBeds ?? [] {
            guard let a = sources[b.sourceId]?.audio else { continue }
            let off = PlanTiming.ticks(b.offsetSec)
            let at = max(0, off)
            let mediaStart = a.start + max(0, -off)
            let len = min(a.end - mediaStart, total - at)
            if len <= 0 { continue }
            let track = try newTrack(.audio, "bed", b.sourceId)
            try empty(track, at: 0, at)
            try insert(track, a, from: mediaStart, length: len, at: at)
            try empty(track, at: at + len, total - at - len)
            if b.gainDb != 0 {
                let p = AVMutableAudioMixInputParameters(track: track)
                p.setVolume(linear(b.gainDb), at: .zero)
                mixParams.append(p)
            }
        }

        // A track that ended up all empty (e.g. no source has sound) is dropped.
        for track in comp.tracks where track.segments.allSatisfy({ $0.isEmpty }) {
            roles.removeValue(forKey: track.trackID)
            comp.removeTrack(track)
        }
        mixParams.removeAll { p in !comp.tracks.contains { $0.trackID == p.trackID } }
        // Trailing empty edits do not count towards a track's length, so a plan
        // whose last stretch has neither picture nor sound would come out short.
        let built = toTicks(comp.duration)
        if built != total {
            throw EngineError(Reason.tailGap, "composition lasts \(built) ticks, plan \(total)")
        }
        var mix: AVMutableAudioMix?
        if !mixParams.isEmpty {
            let m = AVMutableAudioMix()
            m.inputParameters = mixParams
            mix = m
        }
        return PlanComposition(plan: plan, composition: comp, audioMix: mix, timings: timings, roles: roles)
    }

    public func report() -> ProbeReport {
        let tracks = composition.tracks.map { t -> ProbedTrack in
            let r = roles[t.trackID]
            return ProbedTrack(
                id: t.trackID, mediaType: t.mediaType == .video ? "video" : "audio", role: r?.role ?? "unknown",
                sourceId: r?.sourceId, durationTicks: toTicks(t.timeRange.end),
                segments: t.segments.count, mediaSegments: t.segments.filter { !$0.isEmpty }.count)
        }
        let d = durationTicks
        return ProbeReport(
            ok: true, generation: plan.generation, timescale: PlanTiming.timescale, durationTicks: d,
            durationSeconds: Double(d) / Double(PlanTiming.timescale),
            expectedDurationTicks: timings.last?.outputEnd ?? 0, clips: timings.count, tracks: tracks,
            hasAudioMix: audioMix != nil)
    }

    // MARK: - Placement

    static func linear(_ db: Double) -> Float { Float(pow(10, db / 20)) }

    static func load(_ s: PlanSource) async throws -> LoadedSource {
        let url = URL(fileURLWithPath: s.path)
        guard FileManager.default.isReadableFile(atPath: url.path) else {
            throw EngineError(Reason.sourceUnreadable, "source '\(s.id)' is not a readable file")
        }
        let asset = AVURLAsset(url: url, options: [AVURLAssetPreferPreciseDurationAndTimingKey: true])
        do {
            let v = try await asset.loadTracks(withMediaType: .video).first
            let a = try await asset.loadTracks(withMediaType: .audio).first
            return LoadedSource(asset: asset, video: try await loaded(v), audio: try await loaded(a))
        } catch let e as EngineError {
            throw e
        } catch {
            throw EngineError(Reason.sourceUnreadable, "source '\(s.id)': \(error.localizedDescription)")
        }
    }

    static func loaded(_ track: AVAssetTrack?) async throws -> LoadedTrack? {
        guard let track else { return nil }
        let range = try await track.load(.timeRange)
        var frame: Int64 = 0
        if track.mediaType == .video {
            let mfd = try await track.load(.minFrameDuration)
            frame = toTicks(mfd)
            if frame <= 0 {
                let rate = try await track.load(.nominalFrameRate)
                if rate > 0 { frame = PlanTiming.ticks(1 / Double(rate)) }
            }
        }
        let start = toTicks(range.start)
        let end = start + toTicks(range.duration)
        if end <= start { return nil }
        return LoadedTrack(track: track, start: start, end: end, frameTicks: frame)
    }

    static func empty(_ dst: AVMutableCompositionTrack, at: Int64, _ length: Int64) throws {
        if length > 0 { dst.insertEmptyTimeRange(CMTimeRange(start: tk(at), duration: tk(length))) }
    }

    static func insert(_ dst: AVMutableCompositionTrack, _ src: LoadedTrack, from: Int64, length: Int64, at: Int64) throws {
        guard length > 0 else { return }
        do {
            try dst.insertTimeRange(CMTimeRange(start: tk(from), duration: tk(length)), of: src.track, at: tk(at))
        } catch {
            throw EngineError(Reason.insertFailed, error.localizedDescription)
        }
    }

    /// Place `[start, start + consumed)` of `src` at `at`, scaled to `play` output ticks.
    /// Parts before the source track starts become empty edits. Parts after it
    /// ends become an empty edit (sound) or a freeze of the file's last frame
    /// (picture, `freezeTail`): AVFoundation drops trailing empty edits, so a
    /// picture track that must reach the plan end may not end in an empty edit.
    static func place(_ dst: AVMutableCompositionTrack, _ src: LoadedTrack?, start: Int64, consumed: Int64,
                      at: Int64, play: Int64, freezeTail: Bool = false) throws {
        guard play > 0 else { return }
        guard let src, consumed > 0 else {
            try empty(dst, at: at, play)
            return
        }
        let end = start + consumed
        let lo = max(start, src.start)
        let hi = min(end, src.end)
        let lead = min(max(0, lo - start), consumed)
        let avail = max(0, hi - lo)
        let tail = consumed - lead - avail
        try empty(dst, at: at, lead)
        try insert(dst, src, from: lo, length: avail, at: at + lead)
        if tail > 0 && freezeTail && end > src.start {
            let frame = min(src.frameTicks > 0 ? src.frameTicks : 3000, src.end - src.start)
            try insert(dst, src, from: src.end - frame, length: frame, at: at + lead + avail)
            dst.scaleTimeRange(CMTimeRange(start: tk(at + lead + avail), duration: tk(frame)), toDuration: tk(tail))
        } else {
            try empty(dst, at: at + lead + avail, tail)
        }
        if play != consumed {
            dst.scaleTimeRange(CMTimeRange(start: tk(at), duration: tk(consumed)), toDuration: tk(play))
        }
    }

    /// Freeze the last frame read before `sourceEnd` for `hold` ticks.
    static func freeze(_ dst: AVMutableCompositionTrack, _ src: LoadedTrack?, sourceEnd: Int64, at: Int64,
                       hold: Int64, fallbackFrame: Int64) throws {
        guard hold > 0 else { return }
        guard let src else {
            try empty(dst, at: at, hold)
            return
        }
        let end = min(max(sourceEnd, src.start), src.end)
        let frame = src.frameTicks > 0 ? src.frameTicks : fallbackFrame
        var from = max(src.start, end - frame)
        var len = end - from
        if len <= 0 {
            // Nothing played (or the range ends before the file): hold the first frame.
            from = src.start
            len = min(frame, src.end - src.start)
        }
        try insert(dst, src, from: from, length: len, at: at)
        dst.scaleTimeRange(CMTimeRange(start: tk(at), duration: tk(len)), toDuration: tk(hold))
    }
}
