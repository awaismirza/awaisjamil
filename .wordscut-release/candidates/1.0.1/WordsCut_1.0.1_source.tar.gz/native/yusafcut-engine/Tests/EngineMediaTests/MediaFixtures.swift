import AVFoundation
import CoreMedia
import CoreVideo
import Foundation

/// Deterministic tiny media for tests: H.264 160x90 video at `fps` (each frame
/// a different shade) and, optionally, 48 kHz mono 16-bit PCM in a QuickTime
/// movie. PCM (not AAC) so the audio track has no encoder priming and its
/// duration is exact.
enum MediaFixtures {
    static func write(to url: URL, seconds: Double, fps: Int32 = 30, video: Bool = true,
                      audio: Bool = true) async throws {
        try? FileManager.default.removeItem(at: url)
        let writer = try AVAssetWriter(outputURL: url, fileType: .mov)
        let width = 160, height = 90
        var vIn: AVAssetWriterInput?
        var adaptor: AVAssetWriterInputPixelBufferAdaptor?
        if video {
            let input = AVAssetWriterInput(mediaType: .video, outputSettings: [
                AVVideoCodecKey: AVVideoCodecType.h264, AVVideoWidthKey: width, AVVideoHeightKey: height,
            ])
            input.expectsMediaDataInRealTime = false
            writer.add(input)
            adaptor = AVAssetWriterInputPixelBufferAdaptor(assetWriterInput: input, sourcePixelBufferAttributes: [
                kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
                kCVPixelBufferWidthKey as String: width, kCVPixelBufferHeightKey as String: height,
            ])
            vIn = input
        }
        var aIn: AVAssetWriterInput?
        if audio {
            let input = AVAssetWriterInput(mediaType: .audio, outputSettings: [
                AVFormatIDKey: kAudioFormatLinearPCM, AVSampleRateKey: 48_000, AVNumberOfChannelsKey: 1,
                AVLinearPCMBitDepthKey: 16, AVLinearPCMIsFloatKey: false, AVLinearPCMIsBigEndianKey: false,
                AVLinearPCMIsNonInterleaved: false,
            ])
            input.expectsMediaDataInRealTime = false
            writer.add(input)
            aIn = input
        }
        guard writer.startWriting() else { throw writer.error ?? CocoaError(.fileWriteUnknown) }
        writer.startSession(atSourceTime: .zero)

        // Offline writers control interleaving through each input's readiness.
        // Waiting on the earliest timestamp in one loop can starve the other
        // input: the writer may need that other track to advance first.
        // Feed independently and mark each track finished as soon as it ends.
        do {
            let videoInput = vIn, videoAdaptor = adaptor, audioInput = aIn
            async let picture: Void = writeVideo(videoInput, adaptor: videoAdaptor, writer: writer,
                                                seconds: seconds, fps: fps, width: width, height: height)
            async let sound: Void = writeAudio(audioInput, writer: writer, seconds: seconds)
            _ = try await (picture, sound)
        } catch {
            writer.cancelWriting()
            throw error
        }
        writer.endSession(atSourceTime: CMTime(value: CMTimeValue((seconds * 600).rounded()), timescale: 600))
        await writer.finishWriting()
        if writer.status != .completed { throw writer.error ?? CocoaError(.fileWriteUnknown) }
    }

    private static func writeVideo(_ input: AVAssetWriterInput?, adaptor: AVAssetWriterInputPixelBufferAdaptor?,
                                   writer: AVAssetWriter, seconds: Double, fps: Int32,
                                   width: Int, height: Int) async throws {
        guard let input, let adaptor else { return }
        let frames = Int((seconds * Double(fps)).rounded())
        for frame in 0..<frames {
            try await waitUntilReady(input, writer: writer)
            let pb = try pixelBuffer(adaptor: adaptor, width: width, height: height,
                                     shade: UInt8(truncatingIfNeeded: frame * 2))
            guard adaptor.append(pb, withPresentationTime: CMTime(value: CMTimeValue(frame), timescale: fps)) else {
                throw writer.error ?? CocoaError(.fileWriteUnknown)
            }
        }
        input.markAsFinished()
    }

    private static func writeAudio(_ input: AVAssetWriterInput?, writer: AVAssetWriter,
                                   seconds: Double) async throws {
        guard let input else { return }
        let rate = 48_000
        let totalSamples = Int((seconds * Double(rate)).rounded())
        var sample = 0
        while sample < totalSamples {
            try await waitUntilReady(input, writer: writer)
            let n = min(4_800, totalSamples - sample)
            guard input.append(try pcmSample(start: sample, count: n, rate: rate)) else {
                throw writer.error ?? CocoaError(.fileWriteUnknown)
            }
            sample += n
        }
        input.markAsFinished()
    }

    /// A failed encoder never becomes ready again. Surface its error instead of hanging CI.
    private static func waitUntilReady(_ input: AVAssetWriterInput, writer: AVAssetWriter) async throws {
        let deadline = Date().addingTimeInterval(15)
        while !input.isReadyForMoreMediaData {
            guard writer.status == .writing else {
                throw writer.error ?? CocoaError(.fileWriteUnknown)
            }
            guard Date() < deadline else {
                throw NSError(domain: "WordsCutTestFixtures", code: 1, userInfo: [
                    NSLocalizedDescriptionKey: "\(input.mediaType.rawValue) input did not become ready within 15 seconds (writer status \(writer.status.rawValue))",
                ])
            }
            try await Task.sleep(nanoseconds: 1_000_000)
        }
    }

    static func pixelBuffer(adaptor: AVAssetWriterInputPixelBufferAdaptor, width: Int, height: Int,
                            shade: UInt8) throws -> CVPixelBuffer {
        var pb: CVPixelBuffer?
        if let pool = adaptor.pixelBufferPool {
            CVPixelBufferPoolCreatePixelBuffer(nil, pool, &pb)
        }
        if pb == nil {
            CVPixelBufferCreate(kCFAllocatorDefault, width, height, kCVPixelFormatType_32BGRA, nil, &pb)
        }
        guard let buffer = pb else { throw CocoaError(.fileWriteUnknown) }
        CVPixelBufferLockBaseAddress(buffer, [])
        if let base = CVPixelBufferGetBaseAddress(buffer) {
            memset(base, Int32(shade), CVPixelBufferGetBytesPerRow(buffer) * height)
        }
        CVPixelBufferUnlockBaseAddress(buffer, [])
        return buffer
    }

    static func pcmSample(start: Int, count: Int, rate: Int) throws -> CMSampleBuffer {
        var asbd = AudioStreamBasicDescription(
            mSampleRate: Double(rate), mFormatID: kAudioFormatLinearPCM,
            mFormatFlags: kAudioFormatFlagIsSignedInteger | kAudioFormatFlagIsPacked,
            mBytesPerPacket: 2, mFramesPerPacket: 1, mBytesPerFrame: 2, mChannelsPerFrame: 1,
            mBitsPerChannel: 16, mReserved: 0)
        var fd: CMAudioFormatDescription?
        CMAudioFormatDescriptionCreate(allocator: nil, asbd: &asbd, layoutSize: 0, layout: nil,
                                       magicCookieSize: 0, magicCookie: nil, extensions: nil,
                                       formatDescriptionOut: &fd)
        var samples = [Int16](repeating: 0, count: count)
        for i in 0..<count {
            samples[i] = Int16(sin(Double(start + i) * 2 * .pi * 440 / Double(rate)) * 3000)
        }
        let bytes = count * 2
        var block: CMBlockBuffer?
        CMBlockBufferCreateWithMemoryBlock(allocator: nil, memoryBlock: nil, blockLength: bytes,
                                           blockAllocator: nil, customBlockSource: nil, offsetToData: 0,
                                           dataLength: bytes, flags: 0, blockBufferOut: &block)
        samples.withUnsafeBytes {
            _ = CMBlockBufferReplaceDataBytes(with: $0.baseAddress!, blockBuffer: block!,
                                              offsetIntoDestination: 0, dataLength: bytes)
        }
        var sb: CMSampleBuffer?
        CMAudioSampleBufferCreateReadyWithPacketDescriptions(
            allocator: nil, dataBuffer: block!, formatDescription: fd!, sampleCount: count,
            presentationTimeStamp: CMTime(value: CMTimeValue(start), timescale: CMTimeScale(rate)),
            packetDescriptions: nil, sampleBufferOut: &sb)
        guard let out = sb else { throw CocoaError(.fileWriteUnknown) }
        return out
    }
}
