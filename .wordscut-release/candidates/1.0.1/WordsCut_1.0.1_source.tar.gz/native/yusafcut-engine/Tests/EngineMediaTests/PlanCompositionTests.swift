import AVFoundation
import CoreMedia
import EngineCore
import Foundation
import VideoToolbox
import XCTest
@testable import EngineMedia

private struct ParityFixture: Decodable {
    struct Media: Decodable {
        var duration: Double
        var fps: Int32
        var hasAudio: Bool
    }
    struct Expected: Decodable {
        var quantizedTicks: Int64
        var unquantizedTicks: Int64
    }
    struct Case: Decodable {
        var name: String
        var plan: RenderPlan
        var expected: Expected
    }
    var media: [String: Media]
    var cases: [Case]

    static func load() throws -> ParityFixture {
        var url = URL(fileURLWithPath: #filePath)
        for _ in 0..<5 { url.deleteLastPathComponent() }
        url.appendPathComponent("tests/fixtures/native-engine-timing.json")
        return try JSONDecoder().decode(ParityFixture.self, from: Data(contentsOf: url))
    }
}

private func ticks(_ t: CMTime) -> Int64 {
    t.convertScale(PlanTiming.timescale, method: .roundHalfAwayFromZero).value
}

final class PlanCompositionTests: XCTestCase {
    /// Generated once per run: m1 4 s (video+audio), m2 3 s (video+audio),
    /// m3 2 s (video only), cam 5 s (video only), bed 10 s (audio only).
    static var dir: URL!
    static var paths: [String: String] = [:]

    override class func setUp() {
        super.setUp()
        dir = FileManager.default.temporaryDirectory.appendingPathComponent("yusafcut-engine-tests-\(UUID().uuidString)")
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let specs: [(String, Double, Bool, Bool)] = [
            ("m1", 4, true, true), ("m2", 3, true, true), ("m3", 2, true, false),
            ("cam", 5, true, false), ("bed", 10, false, true),
        ]
        let done = DispatchGroup()
        done.enter()
        // XCTest class setup blocks this thread; do not inherit its executor.
        // Keep AVFoundation writers serial: virtual macOS runners can fail
        // concurrent VideoToolbox / media-service sessions while writing to a
        // shared temporary directory, leaving unreadable fixture files.
        Task.detached {
            do {
                for (id, secs, v, a) in specs {
                    let url = dir.appendingPathComponent("\(id).mov")
                    try await MediaFixtures.write(to: url, seconds: secs, video: v, audio: a)
                    paths[id] = url.path
                }
            } catch {
                // XCTest may abort immediately below; stderr preserves the
                // actual writer error in hosted logs even when stdout buffers.
                let message = "native media fixture setup failed: \(error)\n"
                FileHandle.standardError.write(Data(message.utf8))
            }
            done.leave()
        }
        precondition(done.wait(timeout: .now() + 90) == .success,
                     "Native media fixtures did not finish within 90 seconds")
        precondition(paths.count == specs.count, "Native media fixtures could not be created")
    }

    override class func tearDown() {
        try? FileManager.default.removeItem(at: dir)
        super.tearDown()
    }

    private func source(_ id: String) -> PlanSource { PlanSource(id: id, path: Self.paths[id]!) }

    private func resolve(_ plan: RenderPlan) -> RenderPlan {
        var p = plan
        p.sources = p.sources.map { s in
            var s = s
            if s.path.hasPrefix("{{media:") { s.path = Self.paths[String(s.path.dropFirst(8).dropLast(2))]! }
            return s
        }
        return p
    }

    /// The main picture reaches the plan end exactly; every other track ends at
    /// or before it (AVFoundation drops trailing empty edits, so a sound track
    /// that ends in silence is shorter, which is fine).
    private func assertEveryTrack(_ built: PlanComposition, lasts total: Int64, _ msg: String = "",
                                  file: StaticString = #filePath, line: UInt = #line) {
        XCTAssertEqual(built.durationTicks, total, msg, file: file, line: line)
        for t in built.composition.tracks {
            let end = ticks(t.timeRange.end)
            if t.mediaType == .video, built.roles[t.trackID]?.role == "main" {
                XCTAssertEqual(end, total, "\(msg) main picture", file: file, line: line)
            } else {
                XCTAssertLessThanOrEqual(end, total, "\(msg) track \(t.trackID)", file: file, line: line)
            }
        }
    }

    // MARK: - Generated media sanity

    func testGeneratedMediaHasExactDurations() async throws {
        let m1 = AVURLAsset(url: URL(fileURLWithPath: Self.paths["m1"]!),
                            options: [AVURLAssetPreferPreciseDurationAndTimingKey: true])
        let v = try await m1.loadTracks(withMediaType: .video)
        let a = try await m1.loadTracks(withMediaType: .audio)
        XCTAssertEqual(v.count, 1)
        XCTAssertEqual(a.count, 1)
        let vr = try await v[0].load(.timeRange)
        let ar = try await a[0].load(.timeRange)
        XCTAssertEqual(ticks(vr.duration), 360_000)
        XCTAssertEqual(ticks(ar.duration), 360_000)
        let m3 = AVURLAsset(url: URL(fileURLWithPath: Self.paths["m3"]!))
        let m3Audio = try await m3.loadTracks(withMediaType: .audio)
        XCTAssertTrue(m3Audio.isEmpty)
    }

    // MARK: - Parity with the TS fixture

    func testFixtureCompositionsLastExactlyWhatTypeScriptExpects() async throws {
        let f = try ParityFixture.load()
        XCTAssertEqual(f.cases.count, 6)
        for c in f.cases {
            let plan = resolve(c.plan)
            let q = try await PlanComposition.build(plan)
            XCTAssertEqual(q.durationTicks, c.expected.quantizedTicks, "\(c.name) quantised")
            assertEveryTrack(q, lasts: c.expected.quantizedTicks, c.name)
            var unq = plan
            unq.quantize = false
            let u = try await PlanComposition.build(unq)
            XCTAssertEqual(u.durationTicks, c.expected.unquantizedTicks, "\(c.name) unquantised")
            assertEveryTrack(u, lasts: c.expected.unquantizedTicks, c.name)
            XCTAssertEqual(q.report().durationTicks, q.report().expectedDurationTicks, c.name)
        }
    }

    // MARK: - Repeated ranges

    func testRepeatedRangeReusesTheSameSourceRange() async throws {
        let plan = RenderPlan(
            fps: .init(num: 30, den: 1), sources: [source("m1")],
            clips: [
                PlanClip(sourceId: "m1", sourceIn: 2, sourceOut: 3),
                PlanClip(sourceId: "m1", sourceIn: 0, sourceOut: 1),
                PlanClip(sourceId: "m1", sourceIn: 2, sourceOut: 3),
            ])
        let built = try await PlanComposition.build(plan)
        XCTAssertEqual(built.durationTicks, 270_000)
        let video = built.composition.tracks(withMediaType: .video)[0]
        let media = video.segments.filter { !$0.isEmpty }
        XCTAssertEqual(media.count, 3)
        XCTAssertEqual(media[0].timeMapping.source, media[2].timeMapping.source)
        XCTAssertEqual(ticks(media[0].timeMapping.source.start), 180_000)
        XCTAssertEqual(ticks(media[1].timeMapping.source.start), 0)
        XCTAssertEqual(ticks(media[2].timeMapping.target.start), 180_000)
        let audio = built.composition.tracks(withMediaType: .audio)
        XCTAssertEqual(audio.count, 1)
        XCTAssertEqual(audio[0].segments.filter { !$0.isEmpty }.count, 3)
    }

    // MARK: - Missing audio stream

    func testSourceWithoutAudioLeavesASilentGapNotAShorterTrack() async throws {
        let plan = RenderPlan(
            fps: .init(num: 30, den: 1), sources: [source("m3"), source("m1")],
            clips: [
                PlanClip(sourceId: "m3", sourceIn: 0, sourceOut: 1),
                PlanClip(sourceId: "m1", sourceIn: 0, sourceOut: 1),
            ])
        let built = try await PlanComposition.build(plan)
        XCTAssertEqual(built.durationTicks, 180_000)
        assertEveryTrack(built, lasts: 180_000)
        let audio = built.composition.tracks(withMediaType: .audio)[0]
        XCTAssertTrue(audio.segments[0].isEmpty)
        XCTAssertEqual(ticks(audio.segments[0].timeMapping.target.duration), 90_000)
    }

    func testNoAudioAnywhereMeansNoAudioTrack() async throws {
        let plan = RenderPlan(fps: .init(num: 30, den: 1), sources: [source("m3")],
                              clips: [PlanClip(sourceId: "m3", sourceIn: 0.5, sourceOut: 2)])
        let built = try await PlanComposition.build(plan)
        XCTAssertTrue(built.composition.tracks(withMediaType: .audio).isEmpty)
        XCTAssertEqual(built.durationTicks, 135_000)
    }

    func testMutedClipIsSilentButKeepsItsLength() async throws {
        let plan = RenderPlan(fps: .init(num: 30, den: 1), sources: [source("m1")],
                              clips: [PlanClip(sourceId: "m1", sourceIn: 0, sourceOut: 1, muted: true),
                                      PlanClip(sourceId: "m1", sourceIn: 2, sourceOut: 3)])
        let built = try await PlanComposition.build(plan)
        let audio = built.composition.tracks(withMediaType: .audio)[0]
        XCTAssertTrue(audio.segments[0].isEmpty)
        XCTAssertEqual(built.durationTicks, 180_000)
    }

    // MARK: - Duration exactness

    func testRangePastTheEndOfTheFileIsPaddedNotShortened() async throws {
        // m2 is 3 s; ask for 2.5..3.5: the last half second is an empty edit.
        let plan = RenderPlan(fps: .init(num: 30, den: 1), quantize: false, sources: [source("m2")],
                              clips: [PlanClip(sourceId: "m2", sourceIn: 2.5, sourceOut: 3.5)])
        let built = try await PlanComposition.build(plan)
        XCTAssertEqual(built.durationTicks, 90_000)
        assertEveryTrack(built, lasts: 90_000)
    }

    func testNTSCRateQuantisesToWholeFrames() async throws {
        let plan = RenderPlan(fps: .init(num: 30000, den: 1001), sources: [source("m1")],
                              clips: [PlanClip(sourceId: "m1", sourceIn: 0, sourceOut: 1.001),
                                      PlanClip(sourceId: "m1", sourceIn: 2, sourceOut: 2.5, holdSec: 0.25)])
        let built = try await PlanComposition.build(plan)
        XCTAssertEqual(built.durationTicks % 3003, 0)
        XCTAssertEqual(built.durationTicks, PlanTiming.durationTicks(plan))
        assertEveryTrack(built, lasts: built.durationTicks)
    }

    func testHoldFreezesOneFrame() async throws {
        let plan = RenderPlan(fps: .init(num: 30, den: 1), sources: [source("m1")],
                              clips: [PlanClip(sourceId: "m1", sourceIn: 0, sourceOut: 1, holdSec: 2)])
        let built = try await PlanComposition.build(plan)
        XCTAssertEqual(built.durationTicks, 270_000)
        let video = built.composition.tracks(withMediaType: .video)[0]
        let freeze = video.segments.last!
        XCTAssertFalse(freeze.isEmpty)
        XCTAssertEqual(ticks(freeze.timeMapping.source.duration), 3000)
        XCTAssertEqual(ticks(freeze.timeMapping.target.duration), 180_000)
        // The hold is silent: sound stops where the footage stops.
        let audio = built.composition.tracks(withMediaType: .audio)[0]
        XCTAssertEqual(ticks(audio.timeRange.end), 90_000)
    }

    func testTailWithNoPictureAndNoSoundIsRefused() async {
        // Last clip: an audio-only file, muted. Nothing reaches the plan end.
        let plan = RenderPlan(fps: .init(num: 30, den: 1), sources: [source("m1"), source("bed")],
                              clips: [PlanClip(sourceId: "m1", sourceIn: 0, sourceOut: 1),
                                      PlanClip(sourceId: "bed", sourceIn: 0, sourceOut: 1, muted: true)])
        do {
            _ = try await PlanComposition.build(plan)
            XCTFail("expected a throw")
        } catch let e as EngineError {
            XCTAssertEqual(e.code, Reason.tailGap)
        } catch { XCTFail("\(error)") }
    }

    func testPictureRangePastTheFileEndFreezesTheLastFrame() async throws {
        let plan = RenderPlan(fps: .init(num: 30, den: 1), quantize: false, sources: [source("m2")],
                              clips: [PlanClip(sourceId: "m2", sourceIn: 2.5, sourceOut: 3.5)])
        let built = try await PlanComposition.build(plan)
        let video = built.composition.tracks(withMediaType: .video)[0]
        let last = video.segments.last!
        XCTAssertFalse(last.isEmpty)
        XCTAssertEqual(ticks(last.timeMapping.source.start), 270_000 - 3000)
        XCTAssertEqual(ticks(last.timeMapping.target.duration), 45_000)
    }

    // MARK: - Recording group (second video track with offset) and beds

    func testCameraTrackFollowsClipsWithItsOffset() async throws {
        // Camera started 0.5 s after the screen: screen t = camera t + 0.5.
        let plan = RenderPlan(
            fps: .init(num: 30, den: 1), sources: [source("m1"), source("m2"), source("cam")],
            clips: [
                PlanClip(sourceId: "m1", sourceIn: 0, sourceOut: 1),
                PlanClip(sourceId: "m2", sourceIn: 0, sourceOut: 1),
                PlanClip(sourceId: "m1", sourceIn: 2, sourceOut: 3, speed: 2),
            ],
            groups: [RecordingGroup(primarySourceId: "m1",
                                    tracks: [GroupTrack(sourceId: "cam", role: .camera, offsetSec: 0.5,
                                                        placement: NormRect(x: 0.7, y: 0.7, width: 0.25, height: 0.25))])])
        let built = try await PlanComposition.build(plan)
        XCTAssertEqual(built.durationTicks, 225_000)
        let videos = built.composition.tracks(withMediaType: .video)
        XCTAssertEqual(videos.count, 2)
        assertEveryTrack(built, lasts: 225_000)
        let cam = videos.first { built.roles[$0.trackID]?.role == "camera" }!
        let segs: [AVCompositionTrackSegment] = cam.segments
        // Clip 1: screen 0..1 -> camera -0.5..0.5: half a second empty, then camera 0..0.5.
        XCTAssertTrue(segs[0].isEmpty)
        XCTAssertEqual(ticks(segs[0].timeMapping.target.duration), 45_000)
        XCTAssertEqual(ticks(segs[1].timeMapping.source.start), 0)
        XCTAssertEqual(ticks(segs[1].timeMapping.source.duration), 45_000)
        // Clip 2 (other source): empty for its second.
        XCTAssertTrue(segs[2].isEmpty)
        // Clip 3: screen 2..3 at 2x -> camera 1.5..2.5 scaled to 0.5 s.
        XCTAssertEqual(ticks(segs[3].timeMapping.source.start), 135_000)
        XCTAssertEqual(ticks(segs[3].timeMapping.target.duration), 45_000)
        let report = built.report()
        XCTAssertEqual(report.tracks.filter { $0.role == "camera" }.count, 1)
    }

    func testBedIsCutToTheEditAndGainGoesToTheMix() async throws {
        let plan = RenderPlan(
            fps: .init(num: 30, den: 1), sources: [source("m1"), source("bed")],
            clips: [PlanClip(sourceId: "m1", sourceIn: 0, sourceOut: 3)],
            audioBeds: [AudioBed(sourceId: "bed", offsetSec: 1, gainDb: -12),
                        AudioBed(sourceId: "bed", offsetSec: -4, gainDb: 0)])
        let built = try await PlanComposition.build(plan)
        XCTAssertEqual(built.durationTicks, 270_000)
        assertEveryTrack(built, lasts: 270_000)
        XCTAssertEqual(built.composition.tracks(withMediaType: .audio).count, 3)
        XCTAssertEqual(built.audioMix?.inputParameters.count, 1)
        let beds = built.composition.tracks(withMediaType: .audio).filter { built.roles[$0.trackID]?.role == "bed" }
        // Second bed starts 4 s into its file at output 0.
        XCTAssertEqual(ticks(beds[1].segments[0].timeMapping.source.start), 360_000)
    }

    // MARK: - Errors

    func testUnsupportedPlanThrowsItsReason() async {
        var plan = RenderPlan(fps: .init(num: 30, den: 1), sources: [source("m1")],
                              clips: [PlanClip(sourceId: "m1", sourceIn: 0, sourceOut: 1)])
        plan.requires = ["privacy-mask"]
        do {
            _ = try await PlanComposition.build(plan)
            XCTFail("expected a throw")
        } catch let e as EngineError {
            XCTAssertEqual(e.code, "privacy-mask")
        } catch { XCTFail("\(error)") }
    }

    func testUnreadableSource() async {
        let plan = RenderPlan(fps: .init(num: 30, den: 1),
                              sources: [PlanSource(id: "x", path: "/nonexistent/x.mov")],
                              clips: [PlanClip(sourceId: "x", sourceIn: 0, sourceOut: 1)])
        do {
            _ = try await PlanComposition.build(plan)
            XCTFail("expected a throw")
        } catch let e as EngineError {
            XCTAssertEqual(e.code, Reason.sourceUnreadable)
        } catch { XCTFail("\(error)") }
    }
}

final class CapabilitiesTests: XCTestCase {
    func testProbeOnThisMac() {
        let c = EngineCapabilities.probe()
        XCTAssertEqual(c.planVersion, renderPlanVersion)
        XCTAssertFalse(c.macosVersion.isEmpty)
        if c.available {
            XCTAssertNil(c.reason)
            XCTAssertEqual(c.levels, ["probe"])
        } else {
            XCTAssertNotNil(c.reason)
            XCTAssertEqual(c.levels, [])
        }
        let json = try? JSONEncoder().encode(c)
        XCTAssertNotNil(json)
    }

    func testEncoderSummary() {
        let codec = kVTVideoEncoderList_CodecType as String
        let hw = kVTVideoEncoderList_IsHardwareAccelerated as String
        let info = EngineCapabilities.encoderSummary([
            [codec: NSNumber(value: kCMVideoCodecType_H264), hw: true],
            [codec: NSNumber(value: kCMVideoCodecType_HEVC)],
            [codec: NSNumber(value: kCMVideoCodecType_AppleProRes422)],
        ])
        XCTAssertTrue(info.h264Encode && info.h264Hardware)
        XCTAssertTrue(info.hevcEncode)
        XCTAssertFalse(info.hevcHardware)
        XCTAssertEqual(EngineCapabilities.encoderSummary([]).h264Encode, false)
    }
}
