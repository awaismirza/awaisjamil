import Foundation
import XCTest
@testable import EngineCore

/// The shared TS / Swift parity fixture (repo `tests/fixtures/native-engine-timing.json`).
struct ParityFixture: Decodable {
    struct Expected: Decodable {
        var edlDuration: Double
        var frames: [Int64]
        var quantizedTicks: Int64
        var unquantizedTicks: Int64
        var quantizedClipTicks: [[Int64]]
    }
    struct Case: Decodable {
        var name: String
        var plan: RenderPlan
        var expected: Expected
    }
    var timescale: Int32
    var cases: [Case]

    static func load() throws -> ParityFixture {
        var url = URL(fileURLWithPath: #filePath)
        for _ in 0..<5 { url.deleteLastPathComponent() }
        url.appendPathComponent("tests/fixtures/native-engine-timing.json")
        return try JSONDecoder().decode(ParityFixture.self, from: Data(contentsOf: url))
    }
}

func plan(_ clips: [PlanClip], fps: RationalFPS = .init(num: 30, den: 1)) -> RenderPlan {
    RenderPlan(fps: fps, sources: [PlanSource(id: "a", path: "/a.mov"), PlanSource(id: "b", path: "/b.mov")],
               clips: clips)
}

final class PlanTimingTests: XCTestCase {
    func testFixtureTicksMatchTypeScript() throws {
        let f = try ParityFixture.load()
        XCTAssertEqual(f.timescale, PlanTiming.timescale)
        XCTAssertFalse(f.cases.isEmpty)
        for c in f.cases {
            XCTAssertTrue(PlanValidator.validate(c.plan).ok, c.name)
            XCTAssertEqual(PlanTiming.durationTicks(c.plan), c.expected.quantizedTicks, c.name)
            var unq = c.plan
            unq.quantize = false
            XCTAssertEqual(PlanTiming.durationTicks(unq), c.expected.unquantizedTicks, c.name)
            let layout = PlanTiming.layout(c.plan)
            XCTAssertEqual(layout.map { [$0.play, $0.hold] }, c.expected.quantizedClipTicks, c.name)
            var lens: [Double] = []
            for cl in c.plan.clips {
                let p = PlanTiming.playSeconds(cl)
                lens.append(p)
                lens.append(p > 0 ? cl.effectiveHold : 0)
            }
            XCTAssertEqual(PlanTiming.frameCounts(lens, fps: c.plan.fps.seconds), c.expected.frames, c.name)
        }
    }

    func testFrameCountsMirrorExportPlanner() {
        XCTAssertEqual(PlanTiming.frameCounts([2.0 / 30, 0.066667, 10], fps: 30), [2, 2, 300])
        XCTAssertEqual(PlanTiming.frameCounts(Array(repeating: 0.04, count: 200), fps: 30).reduce(0, +), 240)
        XCTAssertEqual(PlanTiming.frameCounts([0.01], fps: 30), [1])
        XCTAssertEqual(PlanTiming.frameCounts([0], fps: 30), [0])
    }

    func testFrameTicks() {
        XCTAssertEqual(PlanTiming.frameTicks(.init(num: 30000, den: 1001)), 3003)
        XCTAssertEqual(PlanTiming.frameTicks(.init(num: 25, den: 1)), 3600)
        XCTAssertNil(PlanTiming.frameTicks(.init(num: 7, den: 1)))
    }

    func testSpeedConsumesSourceAndHoldsAreWholeFrames() {
        let p = plan([PlanClip(sourceId: "a", sourceIn: 0, sourceOut: 2, speed: 2, holdSec: 0.5)])
        let t = PlanTiming.layout(p)[0]
        XCTAssertEqual(t.play, 90_000)
        XCTAssertEqual(t.consumed, 180_000)
        XCTAssertEqual(t.hold, 45_000)
    }
}

final class PlanValidatorTests: XCTestCase {
    func testValidPlanPasses() {
        XCTAssertEqual(PlanValidator.validate(plan([PlanClip(sourceId: "a", sourceIn: 0, sourceOut: 1)])), .pass)
    }

    func testStructuralReasons() {
        let ok = PlanClip(sourceId: "a", sourceIn: 0, sourceOut: 1)
        var p = plan([ok])
        p.version = 2
        XCTAssertEqual(PlanValidator.validate(p).reason, Reason.versionUnsupported)
        XCTAssertEqual(PlanValidator.validate(plan([])).reason, Reason.empty)
        XCTAssertEqual(PlanValidator.validate(plan([ok], fps: .init(num: 0, den: 1))).reason, Reason.fpsInvalid)
        XCTAssertEqual(PlanValidator.validate(plan([ok], fps: .init(num: 7, den: 1))).reason,
                       Reason.fpsNotRepresentable)
        XCTAssertEqual(PlanValidator.validate(plan([PlanClip(sourceId: "zz", sourceIn: 0, sourceOut: 1)])).reason,
                       Reason.sourceUnknown)
        XCTAssertEqual(PlanValidator.validate(plan([PlanClip(sourceId: "a", sourceIn: 2, sourceOut: 1)])).reason,
                       Reason.clipRange)
        XCTAssertEqual(PlanValidator.validate(plan([PlanClip(sourceId: "a", sourceIn: 0, sourceOut: 1, speed: 8)])).reason,
                       Reason.speedRange)
        XCTAssertEqual(PlanValidator.validate(plan([PlanClip(sourceId: "a", sourceIn: 0, sourceOut: 1, holdSec: -1)])).reason,
                       Reason.holdRange)
        XCTAssertEqual(PlanValidator.validate(plan([PlanClip(sourceId: "a", sourceIn: 1, sourceOut: 1)])).reason,
                       Reason.empty)
        var dup = plan([ok])
        dup.sources.append(PlanSource(id: "a", path: "/c.mov"))
        XCTAssertEqual(PlanValidator.validate(dup).reason, Reason.sourceDuplicate)
        var big = plan(Array(repeating: ok, count: PlanValidator.maxClips + 1))
        XCTAssertEqual(PlanValidator.validate(big).reason, Reason.tooLarge)
        big.clips = [ok]
        big.groups = [RecordingGroup(primarySourceId: "a", tracks: [GroupTrack(sourceId: "a", role: .camera, offsetSec: 0)])]
        XCTAssertEqual(PlanValidator.validate(big).reason, Reason.groupInvalid)
        big.groups = nil
        big.audioBeds = [AudioBed(sourceId: "b", offsetSec: 0, gainDb: 99)]
        XCTAssertEqual(PlanValidator.validate(big).reason, Reason.gainInvalid)
    }

    func testFirstDeclaredFeatureWins() {
        var p = plan([PlanClip(sourceId: "a", sourceIn: 0, sourceOut: 1)])
        p.requires = ["zoom", "captions"]
        let r = PlanValidator.validate(p)
        XCTAssertEqual(r.reason, "zoom")
        XCTAssertEqual(r.kind, .unsupported)
        p.requires = ["hologram"]
        XCTAssertEqual(PlanValidator.validate(p).reason, Reason.unknownFeature)
        p.requires = nil
        p.sources[0].crop = NormRect(x: 0, y: 0, width: 0.5, height: 0.5)
        XCTAssertEqual(PlanValidator.validate(p).reason, "crop")
    }

    func testStructureIsCheckedBeforeFeatures() {
        var p = plan([PlanClip(sourceId: "nope", sourceIn: 0, sourceOut: 1)])
        p.requires = ["zoom"]
        XCTAssertEqual(PlanValidator.validate(p).reason, Reason.sourceUnknown)
    }

    func testDecodesHostJSON() throws {
        let json = """
        {"version":1,"generation":3,"fps":{"num":30000,"den":1001},"requires":["zoom"],
         "sources":[{"id":"m","path":"/x.mov","duration":4,"hasVideo":true,"hasAudio":false}],
         "clips":[{"sourceId":"m","sourceIn":0,"sourceOut":1,"speed":2,"muted":true}],
         "groups":[{"primarySourceId":"m","tracks":[]}],
         "audioBeds":[]}
        """
        let p = try RenderPlan.decode(Data(json.utf8))
        XCTAssertEqual(p.generation, 3)
        XCTAssertEqual(p.fps, RationalFPS(num: 30000, den: 1001))
        XCTAssertEqual(p.clips[0].effectiveSpeed, 2)
        XCTAssertTrue(p.isQuantized)
    }
}
