# yusafcut-capture

Native capture helper for YusafCut's recorder. Records with **ScreenCaptureKit**
(screen, window or area, plus system audio) and **AVFoundation** (camera,
microphone) into **separate, crash-safe files** on **one shared clock**, plus a
log of cursor, click and key-down times. Driven by the app over JSON lines.

```
swift build -c release            # or: npm run native:build (also installs the sidecar)
swift test                        # pure logic + synthetic-media writer tests
```

Requires macOS 13+, Apple Silicon. See `docs/native-capture.md` in the repo root
for the QA checklist and the design notes.

## Layout

| Target | What | Needs permissions to test? |
|---|---|---|
| `CaptureCore` | Protocol parsing, `events.jsonl` encoding, `SessionClock` / `ClockAligner`, geometry, manifest | no |
| `CaptureMedia` | `TrackWriter` (fragmented MP4 / M4A), sample re-timing | no (synthetic buffers) |
| `yusafcut-capture` | The CLI: devices, permissions, `SCStream`, `AVCaptureSession`, input monitor | yes |

## Protocol

One JSON object per line. stdin → requests, stdout → responses and events.
stderr is for humans.

Requests: `{"id": 1, "cmd": "<name>", ...params}`. `id` is echoed in the response.

| `cmd` | params | result |
|---|---|---|
| `list-devices` | – | `displays[]`, `windows[]`, `cameras[]`, `microphones[]`, `permissions` |
| `permissions` | – | `{screenRecording, camera, microphone, inputMonitoring}` each `granted` / `denied` / `notDetermined` / `restricted` |
| `request-permissions` | `kinds?: [...]` (default all) | new states; shows the system prompts |
| `start` | `display` \| `window` \| `area:{display,x,y,width,height}`, `camera?`, `microphone?`, `systemAudio?`, `fps?` (10–60, default 30), `outDir`, `showsCursor?` (default **false**) | `files`, `t0Host`, `startedAtUnix`, `pixelWidth`, `pixelHeight` |
| `pause` / `resume` | – | `elapsed` |
| `stop` | – | `durationSec`, `files` (only tracks that hold data) |
| `status` | – | `state` (`idle` / `recording` / `paused`), `elapsed` |
| `quit` | – | finalizes any take, exits |

Responses: `{"id":1,"ok":true,"result":{...}}` or
`{"id":1,"ok":false,"error":{"code":"permission-denied","message":"..."}}`.
Codes: `bad-request`, `permission-denied`, `not-found`, `invalid-state`, `capture-failed`.

Events (no `id`): `ready` (once, at launch), `state` (each second while a take
runs, and on every change), `error` (`message`; e.g. the screen stream died —
the take stays stoppable).

Closing stdin or sending SIGTERM/SIGINT finalizes the running take and exits.

## Output of a take (`outDir`)

| File | Content |
|---|---|
| `screen.mp4` | H.264, display/window/area at pixel size (≤ 3840 wide), no real cursor unless `showsCursor` |
| `system.m4a` | System audio (AAC) when `systemAudio` |
| `mic.m4a` | Microphone (AAC) |
| `camera.mp4` | Camera (H.264) |
| `events.jsonl` | One JSON object per line, `t` in media seconds |
| `manifest.json` | Clock anchors, capture geometry, which tracks exist. `finished:false` until `stop` |

All media files are **fragmented** MP4/M4A (a fragment every 2 s), so a killed
helper leaves files that still open, minus about the last two seconds.

### One clock

Everything is mapped to **media time**: seconds since `t0` (the host-clock instant
the take started), with paused stretches removed. Media time 0 is the same
instant in every file; a source that starts late (a camera that takes 300 ms to
warm up) simply starts later inside its file. `t0Host` (mach host seconds,
the clock `CMClockGetHostTimeClock` and `NSEvent.timestamp` share) and
`startedAtUnix` in `manifest.json` / the first `events.jsonl` line tie it to wall
time. Sources with their own clock (some USB / virtual cameras) are re-based on
their first buffer.

### `events.jsonl`

Exactly the format in `docs/cursor-events.md` (version 1; on
`feature/studio-recorder-zoom-backgrounds`): a `header` line (display and captured
rectangle in pixels, `target`), then `move`, `down`, `up`, `key` (modifiers only,
unless `recordKeyIdentity` is set on `start`: then optional `name` / `secure`, see `docs/cursor-events.md`), `scroll`. `x`,`y` are 0–1 across the captured rectangle, origin
top-left, clamped with `"outside":true`. `t` is media seconds on the same clock as
`screen.mp4`, pauses excluded. Extras that readers ignore: `pause`, `resume`,
`end`, `windowframe` (window capture), and `hostTime` in the header. Every line is
written straight to the file, so a killed helper leaves a usable log. Clicks and
scrolls need no permission; key events need **Input Monitoring**.
