import AVFoundation
import CoreMedia
import CoreVideo
import XCTest
@testable import CaptureMedia

private func makeVideoSample(width: Int, height: Int, pts: Double, shade: UInt8) -> CMSampleBuffer {
    var pb: CVPixelBuffer?
    CVPixelBufferCreate(kCFAllocatorDefault, width, height, kCVPixelFormatType_32BGRA, nil, &pb)
    let buffer = pb!
    CVPixelBufferLockBaseAddress(buffer, [])
    if let base = CVPixelBufferGetBaseAddress(buffer) {
        memset(base, Int32(shade), CVPixelBufferGetBytesPerRow(buffer) * height)
    }
    CVPixelBufferUnlockBaseAddress(buffer, [])
    var fd: CMVideoFormatDescription?
    CMVideoFormatDescriptionCreateForImageBuffer(allocator: nil, imageBuffer: buffer, formatDescriptionOut: &fd)
    var timing = CMSampleTimingInfo(
        duration: CMTime(value: 1, timescale: 30),
        presentationTimeStamp: CMTime(seconds: pts, preferredTimescale: 1_000_000),
        decodeTimeStamp: .invalid)
    var sb: CMSampleBuffer?
    CMSampleBufferCreateReadyWithImageBuffer(
        allocator: nil, imageBuffer: buffer, formatDescription: fd!, sampleTiming: &timing,
        sampleBufferOut: &sb)
    return sb!
}

private func makeAudioSample(pts: Double, frames: Int = 4800, rate: Double = 48_000) -> CMSampleBuffer {
    var asbd = AudioStreamBasicDescription(
        mSampleRate: rate, mFormatID: kAudioFormatLinearPCM,
        mFormatFlags: kAudioFormatFlagIsFloat | kAudioFormatFlagIsPacked,
        mBytesPerPacket: 4, mFramesPerPacket: 1, mBytesPerFrame: 4, mChannelsPerFrame: 1,
        mBitsPerChannel: 32, mReserved: 0)
    var fd: CMAudioFormatDescription?
    CMAudioFormatDescriptionCreate(
        allocator: nil, asbd: &asbd, layoutSize: 0, layout: nil, magicCookieSize: 0,
        magicCookie: nil, extensions: nil, formatDescriptionOut: &fd)
    var samples = [Float](repeating: 0, count: frames)
    for i in 0..<frames { samples[i] = sinf(Float(i) * 0.05) * 0.2 }
    let byteCount = frames * 4
    var block: CMBlockBuffer?
    CMBlockBufferCreateWithMemoryBlock(
        allocator: nil, memoryBlock: nil, blockLength: byteCount, blockAllocator: nil,
        customBlockSource: nil, offsetToData: 0, dataLength: byteCount, flags: 0, blockBufferOut: &block)
    samples.withUnsafeBytes {
        _ = CMBlockBufferReplaceDataBytes(
            with: $0.baseAddress!, blockBuffer: block!, offsetIntoDestination: 0, dataLength: byteCount)
    }
    var sb: CMSampleBuffer?
    CMAudioSampleBufferCreateReadyWithPacketDescriptions(
        allocator: nil, dataBuffer: block!, formatDescription: fd!, sampleCount: frames,
        presentationTimeStamp: CMTime(seconds: pts, preferredTimescale: 1_000_000),
        packetDescriptions: nil, sampleBufferOut: &sb)
    return sb!
}

final class TrackWriterTests: XCTestCase {
    var dir: URL!

    override func setUpWithError() throws {
        dir = FileManager.default.temporaryDirectory.appendingPathComponent("tw-\(UUID().uuidString)")
        try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
    }

    override func tearDown() { try? FileManager.default.removeItem(at: dir) }

    private func duration(_ url: URL) async throws -> Double {
        let asset = AVURLAsset(url: url)
        return CMTimeGetSeconds(try await asset.load(.duration))
    }

    func testRetimeShiftsPresentationTimestamp() throws {
        let src = makeVideoSample(width: 64, height: 48, pts: 5000.25, shade: 10)
        let out = try XCTUnwrap(retime(src, toMediaTime: 1.5))
        XCTAssertEqual(CMTimeGetSeconds(CMSampleBufferGetPresentationTimeStamp(out)), 1.5, accuracy: 1e-6)
        XCTAssertEqual(CMTimeGetSeconds(CMSampleBufferGetDuration(out)), 1.0 / 30, accuracy: 1e-6)

        let audio = makeAudioSample(pts: 7000)
        let a = try XCTUnwrap(retime(audio, toMediaTime: 0))
        XCTAssertEqual(CMTimeGetSeconds(CMSampleBufferGetPresentationTimeStamp(a)), 0, accuracy: 1e-6)
    }

    func testVideoWriterProducesReadableMP4() async throws {
        let url = dir.appendingPathComponent("screen.mp4")
        let w = TrackWriter(
            url: url, kind: .video,
            video: .init(width: 64, height: 48, fps: 30, bitrate: 500_000))
        for i in 0..<60 {
            w.append(makeVideoSample(width: 64, height: 48, pts: Double(i) / 30, shade: UInt8(i * 4)))
            while !(w.hasData) && i == 0 { usleep(1000) }
            usleep(2000)
        }
        let done = expectation(description: "finish")
        var ok = false
        w.finish(endTime: 2.0) { ok = $0; done.fulfill() }
        await fulfillment(of: [done], timeout: 15)
        XCTAssertTrue(ok, "\(String(describing: w.error))")
        let d = try await duration(url)
        XCTAssertEqual(d, 2.0, accuracy: 0.2)
    }

    func testAudioWriterProducesReadableM4A() async throws {
        let url = dir.appendingPathComponent("mic.m4a")
        let w = TrackWriter(url: url, kind: .audio)
        for i in 0..<20 {
            w.append(makeAudioSample(pts: Double(i) * 0.1))
            usleep(2000)
        }
        let done = expectation(description: "finish")
        var ok = false
        w.finish(endTime: 2.0) { ok = $0; done.fulfill() }
        await fulfillment(of: [done], timeout: 15)
        XCTAssertTrue(ok, "\(String(describing: w.error))")
        let d = try await duration(url)
        XCTAssertEqual(d, 2.0, accuracy: 0.2)
    }

    func testLateStartingTrackKeepsItsOffsetOnTheSharedTimeline() async throws {
        let url = dir.appendingPathComponent("camera.mp4")
        let w = TrackWriter(url: url, kind: .video, video: .init(width: 64, height: 48, fps: 30, bitrate: 500_000))
        // First frame arrives 1.0 s after t0.
        for i in 0..<30 {
            w.append(makeVideoSample(width: 64, height: 48, pts: 1.0 + Double(i) / 30, shade: 90))
            usleep(2000)
        }
        let done = expectation(description: "finish")
        w.finish(endTime: 2.0) { _ in done.fulfill() }
        await fulfillment(of: [done], timeout: 15)
        // The first frame must still present at ~1.0 s of movie time (not slid to 0).
        let asset = AVURLAsset(url: url)
        let tracks = try await asset.loadTracks(withMediaType: .video)
        let track = try XCTUnwrap(tracks.first)
        let reader = try AVAssetReader(asset: asset)
        let out = AVAssetReaderTrackOutput(track: track, outputSettings: nil)
        reader.add(out)
        XCTAssertTrue(reader.startReading())
        let first = try XCTUnwrap(out.copyNextSampleBuffer())
        let mediaPTS = CMTimeGetSeconds(CMSampleBufferGetPresentationTimeStamp(first))
        let range = try await track.load(.timeRange)
        let segments = try await track.load(.segments)
        let movieStart = CMTimeGetSeconds(segments.first.map { $0.timeMapping.target.start } ?? .zero)
        let emptyLead = segments.first.map { $0.isEmpty ? CMTimeGetSeconds($0.timeMapping.target.duration) : 0 } ?? 0
        XCTAssertEqual(mediaPTS + emptyLead + movieStart, 1.0, accuracy: 0.1,
                       "first frame presents at 1.0 s (media \(mediaPTS), lead \(emptyLead), range \(range))")
    }

    /// Crash safety: copy the file while the writer is still open (as if the
    /// process were killed right now) and make sure the copy decodes.
    func testFragmentedFileIsReadableWithoutFinishing() async throws {
        let url = dir.appendingPathComponent("crash.mp4")
        let w = TrackWriter(
            url: url, kind: .video,
            video: .init(width: 64, height: 48, fps: 30, bitrate: 500_000), fragmentSeconds: 1)
        for i in 0..<150 { // 5 s of media time
            w.append(makeVideoSample(width: 64, height: 48, pts: Double(i) / 30, shade: UInt8(i % 200)))
            usleep(4000)
        }
        let copy = dir.appendingPathComponent("crash-copy.mp4")
        try FileManager.default.copyItem(at: url, to: copy)
        let readable = try await AVURLAsset(url: copy).load(.isReadable)
        XCTAssertTrue(readable, "an unfinished fragmented MP4 must still be readable")
        let secs = try await duration(copy)
        XCTAssertGreaterThan(secs, 1.0, "at least the flushed fragments are recoverable")
        let done = expectation(description: "finish")
        w.finish(endTime: 5) { _ in done.fulfill() }
        await fulfillment(of: [done], timeout: 15)
    }

    func testAudioFragmentedFileIsReadableWithoutFinishing() async throws {
        let url = dir.appendingPathComponent("crash.m4a")
        let w = TrackWriter(url: url, kind: .audio, fragmentSeconds: 1)
        for i in 0..<60 {
            w.append(makeAudioSample(pts: Double(i) * 0.1))
            usleep(4000)
        }
        let copy = dir.appendingPathComponent("crash-copy.m4a")
        try FileManager.default.copyItem(at: url, to: copy)
        let secs = try await duration(copy)
        XCTAssertGreaterThan(secs, 0.5)
        let done = expectation(description: "finish")
        w.finish(endTime: 6) { _ in done.fulfill() }
        await fulfillment(of: [done], timeout: 15)
    }

    func testOutOfOrderSamplesAreDropped() {
        let url = dir.appendingPathComponent("ooo.mp4")
        let w = TrackWriter(url: url, kind: .video, video: .init(width: 64, height: 48, fps: 30, bitrate: 500_000))
        w.append(makeVideoSample(width: 64, height: 48, pts: 1.0, shade: 1))
        w.append(makeVideoSample(width: 64, height: 48, pts: 0.5, shade: 1))
        XCTAssertEqual(w.written, 1)
        XCTAssertEqual(w.dropped, 1)
    }
}
