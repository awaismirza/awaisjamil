import XCTest
@testable import CaptureCore

final class ProtocolTests: XCTestCase {
    func testSimpleCommands() throws {
        XCTAssertEqual(try parseRequest(#"{"id":7,"cmd":"list-devices"}"#),
                       Request(id: 7, command: .listDevices))
        XCTAssertEqual(try parseRequest(#"{"cmd":"pause"}"#), Request(id: nil, command: .pause))
        XCTAssertEqual(try parseRequest(#"{"id":1,"cmd":"resume"}"#).command, .resume)
        XCTAssertEqual(try parseRequest(#"{"id":1,"cmd":"stop"}"#).command, .stop)
        XCTAssertEqual(try parseRequest(#"{"id":1,"cmd":"status"}"#).command, .status)
        XCTAssertEqual(try parseRequest(#"{"id":1,"cmd":"permissions"}"#).command, .permissions)
    }

    func testRequestPermissionsDefaultsToAll() throws {
        XCTAssertEqual(try parseRequest(#"{"cmd":"request-permissions"}"#).command,
                       .requestPermissions(PermissionKind.allCases))
        XCTAssertEqual(
            try parseRequest(#"{"cmd":"request-permissions","kinds":["camera","microphone"]}"#).command,
            .requestPermissions([.camera, .microphone]))
        XCTAssertThrowsError(try parseRequest(#"{"cmd":"request-permissions","kinds":["bogus"]}"#))
    }

    func testThumbnailTargetsAndClampsWidth() throws {
        XCTAssertEqual(try parseRequest(#"{"cmd":"thumbnail","display":7}"#).command,
                       .thumbnail(target: .display(id: 7), maxWidth: defaultThumbnailWidth))
        XCTAssertEqual(try parseRequest(#"{"cmd":"thumbnail","window":9,"maxWidth":100000}"#).command,
                       .thumbnail(target: .window(id: 9), maxWidth: maxThumbnailWidth))
        XCTAssertEqual(try parseRequest(#"{"cmd":"thumbnail","display":7,"maxWidth":1}"#).command,
                       .thumbnail(target: .display(id: 7), maxWidth: minThumbnailWidth))
        XCTAssertThrowsError(try parseRequest(#"{"cmd":"thumbnail"}"#))
        XCTAssertThrowsError(try parseRequest(#"{"cmd":"thumbnail","display":"x"}"#))
    }

    func testStartDisplayWithEverything() throws {
        let r = try parseRequest("""
        {"id":2,"cmd":"start","display":69733824,"camera":"cam-1","microphone":"mic-1",
         "systemAudio":true,"fps":60,"outDir":"/tmp/take","showsCursor":true}
        """)
        guard case .start(let o) = r.command else { return XCTFail("not start") }
        XCTAssertEqual(o.target, .display(id: 69733824))
        XCTAssertEqual(o.camera, "cam-1")
        XCTAssertEqual(o.microphone, "mic-1")
        XCTAssertTrue(o.systemAudio)
        XCTAssertEqual(o.fps, 60)
        XCTAssertEqual(o.outDir, "/tmp/take")
        XCTAssertTrue(o.showsCursor)
    }

    func testStartDefaultsHideCursorAndThirtyFPS() throws {
        guard case .start(let o) = try parseRequest(#"{"cmd":"start","display":1,"outDir":"/x"}"#).command
        else { return XCTFail() }
        XCTAssertFalse(o.showsCursor)
        XCTAssertEqual(o.fps, 30)
        XCTAssertFalse(o.systemAudio)
        XCTAssertNil(o.camera)
    }

    func testFPSIsClamped() throws {
        guard case .start(let hi) = try parseRequest(#"{"cmd":"start","display":1,"outDir":"/x","fps":240}"#).command,
              case .start(let lo) = try parseRequest(#"{"cmd":"start","display":1,"outDir":"/x","fps":1}"#).command
        else { return XCTFail() }
        XCTAssertEqual(hi.fps, 60)
        XCTAssertEqual(lo.fps, 10)
    }

    func testWindowAndAreaTargets() throws {
        guard case .start(let w) = try parseRequest(#"{"cmd":"start","window":4242,"outDir":"/x"}"#).command,
              case .start(let a) = try parseRequest(
                #"{"cmd":"start","area":{"display":3,"x":10,"y":20,"width":640,"height":360},"outDir":"/x"}"#).command
        else { return XCTFail() }
        XCTAssertEqual(w.target, .window(id: 4242))
        XCTAssertEqual(a.target, .area(display: 3, rect: CaptureRect(x: 10, y: 20, width: 640, height: 360)))
    }

    func testAudioOnlyAndCameraOnlyAreValid() throws {
        XCTAssertNoThrow(try parseRequest(#"{"cmd":"start","microphone":"m","outDir":"/x"}"#))
        XCTAssertNoThrow(try parseRequest(#"{"cmd":"start","camera":"c","outDir":"/x"}"#))
    }

    func testStartRejectsBadInput() {
        func fails(_ s: String, _ field: String, line: UInt = #line) {
            XCTAssertThrowsError(try parseRequest(s), line: line) { err in
                guard case ProtocolError.invalidField(let f) = err else { return XCTFail("\(err)", line: line) }
                XCTAssertTrue(f.hasPrefix(field), "\(f)", line: line)
            }
        }
        fails(#"{"cmd":"start","outDir":"/x"}"#, "display/window/area/camera/microphone")
        fails(#"{"cmd":"start","display":1}"#, "outDir")
        fails(#"{"cmd":"start","display":1,"window":2,"outDir":"/x"}"#, "display/window/area (pick one)")
        fails(#"{"cmd":"start","display":-3,"outDir":"/x"}"#, "display")
        fails(#"{"cmd":"start","display":"abc","outDir":"/x"}"#, "display")
        fails(#"{"cmd":"start","area":{"display":1,"x":0,"y":0,"width":0,"height":5},"outDir":"/x"}"#, "area")
        fails(#"{"cmd":"start","camera":"c","systemAudio":true,"outDir":"/x"}"#, "systemAudio")
        fails(#"{"cmd":"start","display":1,"outDir":"/x","fps":"fast"}"#, "fps")
        fails(#"{"cmd":"start","display":1,"outDir":""}"#, "outDir")
    }

    func testMalformedLines() {
        XCTAssertThrowsError(try parseRequest("not json")) { XCTAssertEqual($0 as? ProtocolError, .invalidJSON) }
        XCTAssertThrowsError(try parseRequest("[1,2]")) { XCTAssertEqual($0 as? ProtocolError, .invalidJSON) }
        XCTAssertThrowsError(try parseRequest(#"{"id":1}"#)) { XCTAssertEqual($0 as? ProtocolError, .missingCommand) }
        XCTAssertThrowsError(try parseRequest(#"{"cmd":"explode"}"#)) {
            XCTAssertEqual($0 as? ProtocolError, .unknownCommand("explode"))
        }
    }

    func testBooleanIsNotAnInteger() {
        XCTAssertThrowsError(try parseRequest(#"{"cmd":"start","display":true,"outDir":"/x"}"#))
    }

    func testResponseEncoding() {
        XCTAssertEqual(okResponse(id: 3, result: ["a": .int(1)]).line(),
                       #"{"id":3,"ok":true,"result":{"a":1}}"#)
        XCTAssertEqual(okResponse(id: nil).line(), #"{"ok":true,"result":{}}"#)
        XCTAssertEqual(
            errorResponse(id: 4, code: ErrorCode.permissionDenied, message: "no").line(),
            #"{"error":{"code":"permission-denied","message":"no"},"id":4,"ok":false}"#)
        XCTAssertEqual(eventMessage("state", ["state": .string("paused")]).line(),
                       #"{"event":"state","state":"paused"}"#)
    }

    func testJSONValueRoundTrip() throws {
        let v: JSONValue = .object(["a": .array([.number(1.5), .null, .bool(true), .string("x/y")])])
        let data = try JSONEncoder().encode(v)
        XCTAssertEqual(try JSONDecoder().decode(JSONValue.self, from: data), v)
    }
}
