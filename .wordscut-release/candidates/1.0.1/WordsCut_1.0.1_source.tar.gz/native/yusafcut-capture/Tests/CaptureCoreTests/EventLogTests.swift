import XCTest
@testable import CaptureCore

final class EventLogTests: XCTestCase {
    func testEncodingMatchesTheCursorEventsContract() {
        XCTAssertEqual(EventLogFormat.encode(.move(t: 0.016, x: 0.412, y: 0.301, outside: false)),
                       #"{"type":"move","t":0.016,"x":0.412,"y":0.301}"#)
        XCTAssertEqual(EventLogFormat.encode(.move(t: 1.23456789, x: 1, y: 0.5, outside: true)),
                       #"{"type":"move","t":1.2346,"x":1,"y":0.5,"outside":true}"#)
        XCTAssertEqual(EventLogFormat.encode(.down(t: 0.9, x: 0.52, y: 0.33, outside: false, button: .left)),
                       #"{"type":"down","t":0.9,"x":0.52,"y":0.33,"button":"left"}"#)
        XCTAssertEqual(EventLogFormat.encode(.up(t: 0.98, x: 0.52, y: 0.33, outside: false, button: .other)),
                       #"{"type":"up","t":0.98,"x":0.52,"y":0.33,"button":"other"}"#)
        XCTAssertEqual(EventLogFormat.encode(.key(t: 2.4, mods: ["cmd", "shift"])),
                       #"{"type":"key","t":2.4,"mods":["cmd","shift"]}"#)
        XCTAssertEqual(EventLogFormat.encode(.key(t: 2.4, mods: [])), #"{"type":"key","t":2.4}"#)
        XCTAssertEqual(EventLogFormat.encode(.scroll(t: 1, dx: 0, dy: -3.5)),
                       #"{"type":"scroll","t":1,"dx":0,"dy":-3.5}"#)
        XCTAssertEqual(EventLogFormat.encode(.pause(t: 3)), #"{"type":"pause","t":3}"#)
        XCTAssertEqual(EventLogFormat.encode(.end(t: 9.99999)), #"{"type":"end","t":10}"#)
        XCTAssertEqual(
            EventLogFormat.encode(.windowFrame(t: 1, rect: CaptureRect(x: 1, y: 2, width: 3, height: 4))),
            #"{"type":"windowframe","t":1,"x":1,"y":2,"width":3,"height":4}"#)
    }

    func testHeaderLine() {
        let h = EventHeader(startedAtUnix: 1_760_000_000.123, hostTime: 12345.678901, displayWidth: 2560,
                            displayHeight: 1600, scale: 2,
                            captured: CaptureRect(x: 0, y: 0, width: 2560, height: 1600), target: "display")
        XCTAssertEqual(EventLogFormat.encode(.header(h)),
                       #"{"type":"header","version":1,"startedAtUnix":1760000000.123,"display":{"width":2560,"height":1600,"scale":2},"captured":{"x":0,"y":0,"width":2560,"height":1600},"target":"display","hostTime":12345.678901}"#)
    }

    func testClampUnit() {
        XCTAssertEqual(clampUnit(nx: 0.5, ny: 0.5).outside, false)
        let c = clampUnit(nx: -0.2, ny: 1.4)
        XCTAssertEqual(c.x, 0); XCTAssertEqual(c.y, 1); XCTAssertTrue(c.outside)
    }

    func testNegativeZeroAndNonFinite() {
        XCTAssertEqual(EventLogFormat.num(-0.00001, 2), "0")
        XCTAssertEqual(EventLogFormat.num(.nan, 2), "0")
        XCTAssertEqual(EventLogFormat.num(-1.5, 2), "-1.5")
    }

    func testEveryLineIsValidJSON() throws {
        let events: [InputEvent] = [
            .move(t: 0.5, x: 0.1, y: 0.2, outside: false),
            .down(t: 1, x: 1, y: 1, outside: true, button: .other), .key(t: 1, mods: ["alt"]), .end(t: 2),
        ]
        for e in events {
            let obj = try JSONSerialization.jsonObject(with: Data(EventLogFormat.encode(e).utf8))
            XCTAssertNotNil((obj as? [String: Any])?["type"])
        }
    }

    func testWriterAppendsLinesAndSurvivesWithoutClose() throws {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("events-\(UUID().uuidString).jsonl")
        defer { try? FileManager.default.removeItem(at: url) }
        let w = try EventLogWriter(url: url)
        w.append(.move(t: 0, x: 0.5, y: 0.5, outside: false))
        w.append(.key(t: 0.25, mods: []))
        // Not closed: simulates a killed helper. The lines must already be on disk.
        let text = try String(contentsOf: url, encoding: .utf8)
        let lines = text.split(separator: "\n")
        XCTAssertEqual(lines.count, 2)
        XCTAssertEqual(w.count, 2)
        w.close()
        w.append(.key(t: 1, mods: [])) // ignored after close
        XCTAssertEqual(try String(contentsOf: url, encoding: .utf8).split(separator: "\n").count, 2)
    }

    func testManifestRoundTrip() throws {
        var m = TakeManifest(
            t0Host: 100.5, startedAtUnix: 1_700_000_000,
            capture: .init(kind: "display", displayId: 1, windowId: nil,
                           rect: .init(CaptureRect(x: 0, y: 0, width: 1512, height: 982)),
                           pixelWidth: 3024, pixelHeight: 1964, scale: 2, fps: 30, showsCursor: false))
        m.tracks.screen = "screen.mp4"
        m.tracks.events = "events.jsonl"
        m.finished = true
        m.durationSec = 12.5
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("m-\(UUID().uuidString).json")
        defer { try? FileManager.default.removeItem(at: url) }
        try m.write(to: url)
        let back = try JSONDecoder().decode(TakeManifest.self, from: Data(contentsOf: url))
        XCTAssertEqual(back, m)
    }
}
