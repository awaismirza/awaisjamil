import XCTest
@testable import CaptureCore

final class GeometryTests: XCTestCase {
    func testEvenDimension() {
        XCTAssertEqual(evenDimension(1920), 1920)
        XCTAssertEqual(evenDimension(1081), 1080)
        XCTAssertEqual(evenDimension(1.2), 2)
        XCTAssertEqual(evenDimension(0), 2)
        XCTAssertEqual(evenDimension(3023.6), 3024)
    }

    func testNormalizeRelativeToCaptureRect() {
        let r = CaptureRect(x: 100, y: 50, width: 200, height: 100)
        let c = normalize(x: 200, y: 100, in: r)
        XCTAssertEqual(c.nx, 0.5, accuracy: 1e-9)
        XCTAssertEqual(c.ny, 0.5, accuracy: 1e-9)
        XCTAssertEqual(normalize(x: 0, y: 50, in: r).nx, -0.5, accuracy: 1e-9)
        XCTAssertEqual(normalize(x: 1, y: 1, in: CaptureRect(x: 0, y: 0, width: 0, height: 0)).nx, 0)
    }

    func testBitrateIsClamped() {
        XCTAssertEqual(videoBitrate(width: 320, height: 240, fps: 10), 4_000_000)
        XCTAssertEqual(videoBitrate(width: 7680, height: 4320, fps: 60), 40_000_000)
        let mid = videoBitrate(width: 1920, height: 1080, fps: 30)
        XCTAssertTrue(mid > 4_000_000 && mid < 40_000_000)
    }
}
