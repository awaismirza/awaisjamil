import XCTest
@testable import CaptureCore

final class DeviceLossTests: XCTestCase {
    func testEveryLossTellsTheUserTheTakeCanStillBeSaved() {
        let events: [DeviceLossEvent] = [
            .disconnected(device: "USB Microphone"),
            .interrupted(reason: "another app is using the camera"),
            .interrupted(reason: nil),
            .runtimeError(detail: "media services were reset"),
        ]
        for event in events {
            XCTAssertTrue(deviceLossMessage(event).hasSuffix("Stop to save what was recorded."))
        }
    }

    func testMessagesNameTheDeviceAndReason() {
        XCTAssertTrue(deviceLossMessage(.disconnected(device: "USB Microphone")).hasPrefix("USB Microphone was disconnected"))
        XCTAssertTrue(deviceLossMessage(.interrupted(reason: "another app is using the camera")).contains("(another app is using the camera)"))
        XCTAssertFalse(deviceLossMessage(.interrupted(reason: nil)).contains("()"))
    }
}
