import XCTest
@testable import CaptureCore

final class ExclusionTests: XCTestCase {
    let app: Int32 = 4242

    func testControllerOfTheLaunchingAppIsExcluded() {
        let windows = [
            WindowIdentity(id: 7, pid: app, title: controllerWindowTitle),
            WindowIdentity(id: 8, pid: app, title: "WordsCut"),          // the editor stays recordable
            WindowIdentity(id: 9, pid: 99, title: controllerWindowTitle), // another app's lookalike
            WindowIdentity(id: 3, pid: app, title: controllerWindowTitle + " (copy)"),
        ]
        XCTAssertEqual(controlWindowIDs(windows, appPid: app), [3, 7])
        XCTAssertTrue(isRecordingControl(windows[0], appPid: app))
        XCTAssertFalse(isRecordingControl(windows[1], appPid: app))
        XCTAssertFalse(isRecordingControl(windows[2], appPid: app))
    }

    func testNoControllerYieldsNoExclusions() {
        XCTAssertEqual(controlWindowIDs([], appPid: app), [])
    }

    func testTitleMatchesTheRustSide() throws {
        // Both sides must agree or the controller would appear in footage.
        XCTAssertEqual(controllerWindowTitle, "WordsCut Recording Controls")
    }
}
