import XCTest
@testable import CaptureCore

final class ClockTests: XCTestCase {
    func testCaptureOriginExcludesStartupAndEarlierSecondarySamples() {
        var origin = CaptureOrigin()
        XCTAssertNil(origin.observe(host: 100, primary: false))
        XCTAssertNil(origin.observe(host: .nan, primary: true))
        XCTAssertEqual(origin.observe(host: 107, primary: true), 107)
        XCTAssertEqual(origin.observe(host: 108, primary: true), 107)
        let clock = SessionClock(t0: origin.host!)
        XCTAssertEqual(clock.mediaTime(forHost: 107), 0)
        XCTAssertNil(clock.mediaTime(forHost: 106.5))
        XCTAssertEqual(clock.mediaTime(forHost: 109), 2)
    }

    func testMediaTimeIsRelativeToT0() {
        let c = SessionClock(t0: 1000)
        XCTAssertEqual(c.mediaTime(forHost: 1000), 0)
        XCTAssertEqual(c.mediaTime(forHost: 1002.5), 2.5)
        XCTAssertNil(c.mediaTime(forHost: 999.9), "samples from before the take are dropped")
    }

    func testPauseRemovesGapAndDropsSamplesInside() {
        var c = SessionClock(t0: 100)
        c.pause(atHost: 110)
        XCTAssertTrue(c.isPaused)
        XCTAssertNil(c.mediaTime(forHost: 112))
        XCTAssertEqual(c.mediaTime(forHost: 109.9)!, 9.9, accuracy: 1e-9)
        c.resume(atHost: 115)
        XCTAssertFalse(c.isPaused)
        XCTAssertNil(c.mediaTime(forHost: 112), "late-arriving sample from inside the pause stays dropped")
        XCTAssertEqual(c.mediaTime(forHost: 115)!, 10, accuracy: 1e-9)
        XCTAssertEqual(c.mediaTime(forHost: 118)!, 13, accuracy: 1e-9)
    }

    func testMultiplePauses() {
        var c = SessionClock(t0: 0)
        c.pause(atHost: 10); c.resume(atHost: 20)
        c.pause(atHost: 30); c.resume(atHost: 35)
        XCTAssertEqual(c.mediaTime(forHost: 40)!, 25, accuracy: 1e-9) // 40 - 10 - 5
        XCTAssertEqual(c.mediaTime(forHost: 25)!, 15, accuracy: 1e-9) // between pauses
        XCTAssertNil(c.mediaTime(forHost: 32))
    }

    func testElapsedFreezesWhilePaused() {
        var c = SessionClock(t0: 50)
        XCTAssertEqual(c.elapsed(atHost: 53), 3, accuracy: 1e-9)
        c.pause(atHost: 55)
        XCTAssertEqual(c.elapsed(atHost: 99), 5, accuracy: 1e-9)
        c.resume(atHost: 60)
        XCTAssertEqual(c.elapsed(atHost: 62), 7, accuracy: 1e-9)
    }

    func testDoublePauseAndResumeAreIdempotent() {
        var c = SessionClock(t0: 0)
        c.resume(atHost: 5) // not paused: ignored
        c.pause(atHost: 10); c.pause(atHost: 12)
        c.resume(atHost: 20)
        XCTAssertEqual(c.mediaTime(forHost: 21)!, 11, accuracy: 1e-9)
    }

    func testAlignerKeepsHostClockSources() {
        var a = ClockAligner()
        XCTAssertEqual(a.hostTime(forPTS: 5000.2, nowHost: 5000.35), 5000.2, accuracy: 1e-9)
        XCTAssertFalse(a.isForeignClock)
        XCTAssertEqual(a.hostTime(forPTS: 5001, nowHost: 5001.1), 5001, accuracy: 1e-9)
    }

    func testAlignerLatchesOffsetForForeignClock() {
        var a = ClockAligner()
        // Device clock started near zero while the host clock is at 8000 s.
        XCTAssertEqual(a.hostTime(forPTS: 12.0, nowHost: 8000.0), 8000.0, accuracy: 1e-9)
        XCTAssertTrue(a.isForeignClock)
        XCTAssertEqual(a.hostTime(forPTS: 13.0, nowHost: 8001.4), 8001.0, accuracy: 1e-9)
    }

    func testCursorEventAndFrameAgreeOnMediaTime() {
        // A click and the video frame showing it happen at the same host instant,
        // so they land on the same media time even across a pause.
        var c = SessionClock(t0: 200)
        c.pause(atHost: 205); c.resume(atHost: 210)
        let click = c.mediaTime(forHost: 212.25)!
        var a = ClockAligner()
        let frameHost = a.hostTime(forPTS: 212.25, nowHost: 212.3)
        XCTAssertEqual(c.mediaTime(forHost: frameHost)!, click, accuracy: 1e-9)
        XCTAssertEqual(click, 7.25, accuracy: 1e-9)
    }
}

final class SharedClockTests: XCTestCase {
    func testSharedClockMatchesValueClock() {
        let c = SharedClock(t0: 10)
        c.pause(atHost: 12)
        XCTAssertTrue(c.isPaused)
        XCTAssertNil(c.mediaTime(forHost: 13))
        c.resume(atHost: 14)
        XCTAssertEqual(c.mediaTime(forHost: 15)!, 3, accuracy: 1e-9)
        XCTAssertEqual(c.elapsed(atHost: 15), 3, accuracy: 1e-9)
        XCTAssertEqual(c.t0, 10)
    }

    func testConcurrentAccessDoesNotCrash() {
        let c = SharedClock(t0: 0)
        DispatchQueue.concurrentPerform(iterations: 200) { i in
            if i % 10 == 0 { c.pause(atHost: Double(i)); c.resume(atHost: Double(i) + 0.5) }
            _ = c.mediaTime(forHost: Double(i))
        }
    }
}
