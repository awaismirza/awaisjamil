import XCTest
@testable import CaptureCore

final class KeyIdentityTests: XCTestCase {
    private let off = KeyIdentityOptions()
    private let shortcuts = KeyIdentityOptions(recordKeyIdentity: true)
    private let all = KeyIdentityOptions(recordKeyIdentity: true, recordAllCharacters: true)

    private func d(_ code: UInt16, _ ch: String?, _ mods: [String] = [], secure: Bool = false,
                   _ o: KeyIdentityOptions) -> KeyDescriptor {
        keyDescriptor(keyCode: code, characters: ch, mods: mods, secureInput: secure, options: o)
    }

    func testOffRecordsNothingEvenWhenSecure() {
        XCTAssertEqual(d(40, "k", ["cmd"], off), KeyDescriptor())
        XCTAssertEqual(d(36, "\r", [], off), KeyDescriptor())
        XCTAssertEqual(d(40, "k", ["cmd"], secure: true, off), KeyDescriptor())
    }

    func testAllCharactersRequiresIdentity() {
        XCTAssertFalse(KeyIdentityOptions(recordKeyIdentity: false, recordAllCharacters: true).recordAllCharacters)
    }

    func testShortcutsAndSpecialKeysAreNamed() {
        XCTAssertEqual(d(40, "K", ["cmd", "shift"], shortcuts), KeyDescriptor(name: "k"))
        XCTAssertEqual(d(1, "s", ["ctrl"], shortcuts), KeyDescriptor(name: "s"))
        XCTAssertEqual(d(126, nil, [], shortcuts), KeyDescriptor(name: "up"))
        XCTAssertEqual(d(53, nil, [], shortcuts), KeyDescriptor(name: "esc"))
        XCTAssertEqual(d(115, nil, [], shortcuts), KeyDescriptor(name: "home"))
        XCTAssertEqual(d(36, "\r", ["cmd"], shortcuts), KeyDescriptor(name: "return"))
        XCTAssertEqual(d(96, nil, ["cmd"], shortcuts), KeyDescriptor(name: "f5"))
    }

    func testTypingFlowKeysNeedModifierOrSecondOptIn() {
        for code: UInt16 in [36, 76, 48, 49, 51, 117] {
            XCTAssertEqual(d(code, " ", [], shortcuts), KeyDescriptor(), "code \(code)")
            XCTAssertEqual(d(code, " ", ["shift"], shortcuts), KeyDescriptor(), "code \(code)")
            XCTAssertNotNil(d(code, " ", ["ctrl"], shortcuts).name)
            XCTAssertNotNil(d(code, " ", [], all).name)
        }
        XCTAssertEqual(d(49, " ", [], all), KeyDescriptor(name: "space"))
    }

    func testPlainCharactersAreNeverNamedByDefault() {
        XCTAssertEqual(d(40, "k", [], shortcuts), KeyDescriptor())
        XCTAssertEqual(d(40, "K", ["shift"], shortcuts), KeyDescriptor())
    }

    func testPlainCharactersOnlyWithSecondOptIn() {
        XCTAssertEqual(d(40, "K", ["shift"], all), KeyDescriptor(name: "k"))
        XCTAssertEqual(d(40, "kk", [], all), KeyDescriptor(), "multi-char input is dropped")
        XCTAssertEqual(d(40, "\u{7}", [], all), KeyDescriptor(), "control characters are dropped")
    }

    func testSecureInputNeverRecordsIdentityAndFlags() {
        for o in [shortcuts, all] {
            XCTAssertEqual(d(40, "k", ["cmd"], secure: true, o), KeyDescriptor(name: nil, secure: true))
            XCTAssertEqual(d(36, "\r", [], secure: true, o), KeyDescriptor(name: nil, secure: true))
        }
    }

    func testOptionAloneIsNotAShortcutForPrintableKeys() {
        // Option+L / Option+A type characters on DE, PL and FR layouts.
        XCTAssertEqual(d(37, "l", ["alt"], shortcuts), KeyDescriptor())
        XCTAssertEqual(d(0, "a", ["alt"], shortcuts), KeyDescriptor())
        XCTAssertEqual(d(0, "a", ["alt", "shift"], shortcuts), KeyDescriptor())
        XCTAssertEqual(d(37, "l", ["alt"], all), KeyDescriptor(name: "l"), "second opt-in")
        XCTAssertEqual(d(37, "l", ["alt", "cmd"], shortcuts), KeyDescriptor(name: "l"))
        // Option with non-printable keys is still fine.
        XCTAssertEqual(d(123, nil, ["alt"], shortcuts), KeyDescriptor(name: "left"))
        XCTAssertEqual(d(96, nil, ["alt"], shortcuts), KeyDescriptor(name: "f5"))
        XCTAssertEqual(d(51, nil, ["alt"], shortcuts), KeyDescriptor(name: "delete"), "Option+Delete")
    }

    func testShortcutLetterUsesTheAsciiLayoutCharacter() {
        let kd = { (layout: String?, ch: String?, mods: [String]) in
            keyDescriptor(keyCode: 8, characters: ch, layoutCharacter: layout, mods: mods,
                          secureInput: false, options: self.shortcuts)
        }
        XCTAssertEqual(kd("c", "с", ["cmd"]), KeyDescriptor(name: "c"), "Cyrillic layout, Latin shortcut")
        XCTAssertEqual(kd("3", "#", ["cmd", "shift"]), KeyDescriptor(name: "3"), "no Shift symbol drift")
        XCTAssertEqual(kd(nil, "c", ["ctrl"]), KeyDescriptor(name: "c"), "falls back to the event characters")
        XCTAssertEqual(kd("\r", "c", ["cmd"]), KeyDescriptor(name: "c"), "unusable layout char falls back")
    }

    func testPrivateUseAndSpecialKeysMapping() {
        XCTAssertEqual(d(126, "\u{F700}", ["cmd"], shortcuts), KeyDescriptor(name: "up"))
        XCTAssertEqual(d(114, "\u{F746}", [], shortcuts), KeyDescriptor(name: "insert"))
        XCTAssertEqual(d(71, nil, [], shortcuts), KeyDescriptor(name: "clear"))
        XCTAssertEqual(d(200, "\u{F728}", ["cmd"], shortcuts), KeyDescriptor(), "private-use names are dropped")
        XCTAssertEqual(d(200, "\u{F728}", [], all), KeyDescriptor())
    }

    func testWindowCaptureNamesOnlyInTheCapturedApp() {
        XCTAssertTrue(isInCapturedApp(windowMode: false, ownerPID: nil, frontmostPID: 5))
        XCTAssertTrue(isInCapturedApp(windowMode: true, ownerPID: 7, frontmostPID: 7))
        XCTAssertFalse(isInCapturedApp(windowMode: true, ownerPID: 7, frontmostPID: 8))
        XCTAssertFalse(isInCapturedApp(windowMode: true, ownerPID: nil, frontmostPID: 7), "fails closed")
        let elsewhere = keyDescriptor(keyCode: 40, characters: "k", mods: ["cmd"], secureInput: false,
                                      inCapturedApp: false, options: all)
        XCTAssertEqual(elsewhere, KeyDescriptor())
        let secureElsewhere = keyDescriptor(keyCode: 40, characters: "k", mods: [], secureInput: true,
                                            inCapturedApp: false, options: all)
        XCTAssertEqual(secureElsewhere, KeyDescriptor())
    }

    func testLayoutTranslationOnTheCurrentAsciiLayout() throws {
        // Environment dependent (the layout may be AZERTY etc.): check shape, not letter.
        guard let c = asciiLayoutCharacter(keyCode: 0) else { throw XCTSkip("no keyboard layout data") }
        XCTAssertEqual(c.count, 1)
        XCTAssertEqual(c, c.lowercased(), "unshifted")
        XCTAssertNil(translateKeyCode(0, layoutData: Data()), "empty layout data is rejected")
    }

    func testEventLogIsOwnerOnly() throws {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("yc-\(UUID().uuidString).jsonl")
        let w = try EventLogWriter(url: url)
        w.close()
        let perms = try FileManager.default.attributesOfItem(atPath: url.path)[.posixPermissions] as? Int
        XCTAssertEqual(perms, 0o600)
        try? FileManager.default.removeItem(at: url)
    }

    func testEncoding() {
        XCTAssertEqual(EventLogFormat.encode(.key(t: 1, mods: ["cmd"], name: "k")),
                       #"{"type":"key","t":1,"mods":["cmd"],"name":"k"}"#)
        XCTAssertEqual(EventLogFormat.encode(.key(t: 1, mods: [], name: nil, secure: true)),
                       #"{"type":"key","t":1,"secure":true}"#)
        XCTAssertEqual(EventLogFormat.encode(.key(t: 1, mods: [], name: "\"")),
                       #"{"type":"key","t":1,"name":"\""}"#)
        XCTAssertEqual(EventLogFormat.encode(.key(t: 1, mods: [], name: "\\")),
                       #"{"type":"key","t":1,"name":"\\"}"#)
    }

    func testStartParamsDefaultOffAndParse() throws {
        guard case .start(let a) = try parseRequest(#"{"cmd":"start","display":1,"outDir":"/x"}"#).command,
              case .start(let b) = try parseRequest(
                #"{"cmd":"start","display":1,"outDir":"/x","recordKeyIdentity":true,"recordAllCharacters":true}"#).command,
              case .start(let c) = try parseRequest(
                #"{"cmd":"start","display":1,"outDir":"/x","recordAllCharacters":true}"#).command
        else { return XCTFail("not start") }
        XCTAssertEqual(a.keyIdentity, KeyIdentityOptions())
        XCTAssertEqual(b.keyIdentity, KeyIdentityOptions(recordKeyIdentity: true, recordAllCharacters: true))
        XCTAssertFalse(c.keyIdentity.recordKeyIdentity || c.keyIdentity.recordAllCharacters)
    }
}
