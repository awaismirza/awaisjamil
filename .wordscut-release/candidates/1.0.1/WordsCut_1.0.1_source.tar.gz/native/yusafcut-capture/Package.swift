// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "yusafcut-capture",
    platforms: [.macOS(.v13)],
    products: [
        .executable(name: "yusafcut-capture", targets: ["yusafcut-capture"]),
    ],
    targets: [
        // Pure logic: protocol parsing, event-log encoding, clock alignment, geometry.
        .target(name: "CaptureCore"),
        // AVFoundation plumbing that can be exercised without capture permissions
        // (sample re-timing, crash-safe track writers).
        .target(name: "CaptureMedia", dependencies: ["CaptureCore"]),
        // The CLI. Embeds Resources/Info.plist so the helper carries its own
        // camera / microphone / screen-capture usage descriptions.
        .executableTarget(
            name: "yusafcut-capture",
            dependencies: ["CaptureCore", "CaptureMedia"],
            linkerSettings: [
                .unsafeFlags([
                    "-Xlinker", "-sectcreate",
                    "-Xlinker", "__TEXT",
                    "-Xlinker", "__info_plist",
                    "-Xlinker", "Resources/Info.plist",
                ]),
            ]
        ),
        .testTarget(name: "CaptureCoreTests", dependencies: ["CaptureCore"]),
        .testTarget(name: "CaptureMediaTests", dependencies: ["CaptureMedia", "CaptureCore"]),
    ]
)
