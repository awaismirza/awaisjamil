import CoreMedia
import Foundation

public func hostSecondsNow() -> Double {
    CMTimeGetSeconds(CMClockGetTime(CMClockGetHostTimeClock()))
}

/// Copy of `sample` whose presentation timestamp is `mediaTime` seconds (every
/// timing entry is shifted by the same delta, so multi-packet buffers keep their
/// internal spacing).
public func retime(_ sample: CMSampleBuffer, toMediaTime mediaTime: Double) -> CMSampleBuffer? {
    var needed = 0
    CMSampleBufferGetSampleTimingInfoArray(
        sample, entryCount: 0, arrayToFill: nil, entriesNeededOut: &needed)
    let oldPTS = CMSampleBufferGetPresentationTimeStamp(sample)
    let newPTS = CMTime(seconds: mediaTime, preferredTimescale: 1_000_000)

    var timings: [CMSampleTimingInfo]
    if needed == 0 {
        timings = [CMSampleTimingInfo(
            duration: CMSampleBufferGetDuration(sample), presentationTimeStamp: newPTS,
            decodeTimeStamp: .invalid)]
    } else {
        timings = Array(repeating: CMSampleTimingInfo(), count: needed)
        var got = 0
        CMSampleBufferGetSampleTimingInfoArray(
            sample, entryCount: needed, arrayToFill: &timings, entriesNeededOut: &got)
        let delta = CMTimeSubtract(newPTS, oldPTS)
        for i in timings.indices {
            timings[i].presentationTimeStamp = CMTimeAdd(timings[i].presentationTimeStamp, delta)
            if timings[i].decodeTimeStamp.isValid {
                timings[i].decodeTimeStamp = CMTimeAdd(timings[i].decodeTimeStamp, delta)
            }
        }
    }
    var out: CMSampleBuffer?
    let status = CMSampleBufferCreateCopyWithNewTiming(
        allocator: kCFAllocatorDefault, sampleBuffer: sample,
        sampleTimingEntryCount: timings.count, sampleTimingArray: &timings,
        sampleBufferOut: &out)
    return status == noErr ? out : nil
}
