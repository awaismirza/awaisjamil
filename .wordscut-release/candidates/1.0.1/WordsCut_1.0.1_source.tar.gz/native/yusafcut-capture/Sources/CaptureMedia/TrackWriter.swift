import AVFoundation
import CoreMedia
import Foundation

public enum TrackKind: String {
    case video, audio
}

/// One output file for one source. All calls must come from one serial queue.
///
/// The writer is created lazily from the first sample, so the audio format
/// (channels, rate) is known and a source that never delivers anything leaves no
/// empty file behind. Output is a *fragmented* MP4/M4A (`movieFragmentInterval`):
/// a movie fragment is flushed every couple of seconds, so if the process is
/// killed the file is still readable up to the last fragment.
public final class TrackWriter {
    public struct VideoSettings {
        public var width: Int
        public var height: Int
        public var fps: Int
        public var bitrate: Int
        public init(width: Int, height: Int, fps: Int, bitrate: Int) {
            self.width = width; self.height = height; self.fps = fps; self.bitrate = bitrate
        }
    }

    public let url: URL
    public let kind: TrackKind
    private let videoSettings: VideoSettings?
    private let fragmentSeconds: Double
    private var writer: AVAssetWriter?
    private var input: AVAssetWriterInput?
    private var failed = false
    public private(set) var written = 0
    public private(set) var dropped = 0
    private var lastPTS = CMTime.zero

    public init(url: URL, kind: TrackKind, video: VideoSettings? = nil, fragmentSeconds: Double = 2) {
        self.url = url
        self.kind = kind
        self.videoSettings = video
        self.fragmentSeconds = fragmentSeconds
    }

    public var hasData: Bool { written > 0 }
    public var error: Error? { writer?.error }

    public func append(_ sample: CMSampleBuffer) {
        guard !failed else { return }
        if writer == nil, !start(with: sample) { return }
        guard let writer, let input, writer.status == .writing else {
            if writer?.status == .failed { failed = true }
            return
        }
        let pts = CMSampleBufferGetPresentationTimeStamp(sample)
        // Writers require non-decreasing timestamps.
        if CMTimeCompare(pts, lastPTS) < 0 { dropped += 1; return }
        guard input.isReadyForMoreMediaData else { dropped += 1; return }
        if input.append(sample) {
            written += 1
            lastPTS = pts
        } else {
            failed = true
        }
    }

    private func start(with sample: CMSampleBuffer) -> Bool {
        do {
            let isVideo = kind == .video
            let w = try AVAssetWriter(url: url, fileType: isVideo ? .mp4 : .m4a)
            w.movieFragmentInterval = CMTime(seconds: fragmentSeconds, preferredTimescale: 600)
            w.shouldOptimizeForNetworkUse = false

            let settings: [String: Any]
            if isVideo, let v = videoSettings {
                settings = [
                    AVVideoCodecKey: AVVideoCodecType.h264,
                    AVVideoWidthKey: v.width,
                    AVVideoHeightKey: v.height,
                    AVVideoCompressionPropertiesKey: [
                        AVVideoAverageBitRateKey: v.bitrate,
                        AVVideoProfileLevelKey: AVVideoProfileLevelH264HighAutoLevel,
                        AVVideoMaxKeyFrameIntervalKey: max(1, v.fps * 2),
                        AVVideoAllowFrameReorderingKey: false,
                        AVVideoExpectedSourceFrameRateKey: v.fps,
                    ] as [String: Any],
                ]
            } else {
                let channels = Self.channelCount(of: sample)
                settings = [
                    AVFormatIDKey: kAudioFormatMPEG4AAC,
                    AVSampleRateKey: 48_000,
                    AVNumberOfChannelsKey: channels,
                    AVEncoderBitRateKey: 96_000 * channels,
                ]
            }
            let hint = CMSampleBufferGetFormatDescription(sample)
            let i = AVAssetWriterInput(
                mediaType: isVideo ? .video : .audio, outputSettings: settings, sourceFormatHint: hint)
            i.expectsMediaDataInRealTime = true
            guard w.canAdd(i) else { failed = true; return false }
            w.add(i)
            guard w.startWriting() else { failed = true; return false }
            // Media time 0 is the take's shared t0; samples arrive already retimed.
            w.startSession(atSourceTime: .zero)
            writer = w
            input = i
            return true
        } catch {
            failed = true
            return false
        }
    }

    static func channelCount(of sample: CMSampleBuffer) -> Int {
        guard let fd = CMSampleBufferGetFormatDescription(sample),
              let asbd = CMAudioFormatDescriptionGetStreamBasicDescription(fd)
        else { return 2 }
        return Int(min(max(asbd.pointee.mChannelsPerFrame, 1), 2))
    }

    /// Finish the file; `endTime` (media seconds) extends the movie to the
    /// moment the take stopped, even if the last frame was earlier (static screen).
    public func finish(endTime: Double, completion: @escaping (Bool) -> Void) {
        guard let writer, let input, writer.status == .writing else {
            completion(writer?.status == .completed)
            return
        }
        input.markAsFinished()
        let end = CMTime(seconds: max(endTime, CMTimeGetSeconds(lastPTS)), preferredTimescale: 1_000_000)
        writer.endSession(atSourceTime: end)
        writer.finishWriting { completion(writer.status == .completed) }
    }
}
