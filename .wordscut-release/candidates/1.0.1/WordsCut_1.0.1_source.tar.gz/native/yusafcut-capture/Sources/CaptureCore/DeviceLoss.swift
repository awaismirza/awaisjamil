import Foundation

/// How a camera / microphone capture session stopped delivering media.
public enum DeviceLossEvent: Equatable {
    case runtimeError(detail: String)
    case interrupted(reason: String?)
    case disconnected(device: String)
}

/// The sentence the app shows when a device is lost mid-take. The take is kept:
/// Stop still saves everything recorded before the loss.
public func deviceLossMessage(_ event: DeviceLossEvent) -> String {
    let tail = "Stop to save what was recorded."
    switch event {
    case .disconnected(let device):
        return "\(device) was disconnected. \(tail)"
    case .interrupted(let reason):
        let why = reason.map { " (\($0))" } ?? ""
        return "The camera or microphone was interrupted\(why). \(tail)"
    case .runtimeError(let detail):
        return "The camera or microphone failed: \(detail). \(tail)"
    }
}
