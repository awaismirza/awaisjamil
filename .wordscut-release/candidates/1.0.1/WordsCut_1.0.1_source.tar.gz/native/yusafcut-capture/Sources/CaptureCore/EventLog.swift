import Foundation

public enum MouseButton: String, Equatable {
    case left, right, other
}

/// Geometry of the captured region, in display pixels, for the header line.
public struct EventHeader: Equatable {
    public var startedAtUnix: Double
    public var hostTime: Double
    public var displayWidth: Double
    public var displayHeight: Double
    public var scale: Double
    public var captured: CaptureRect
    /// "display", "window" or "area"
    public var target: String
    public init(startedAtUnix: Double, hostTime: Double, displayWidth: Double, displayHeight: Double,
                scale: Double, captured: CaptureRect, target: String) {
        self.startedAtUnix = startedAtUnix; self.hostTime = hostTime
        self.displayWidth = displayWidth; self.displayHeight = displayHeight
        self.scale = scale; self.captured = captured; self.target = target
    }
}

/// One line of `events.jsonl`, as defined in `docs/cursor-events.md` (version 1).
/// `t` is media time in seconds (see `SessionClock`); `x`,`y` are 0…1 across the
/// captured rectangle, origin top-left, clamped (`outside` marks a clamp).
/// Key events carry timing and modifiers; `name`/`secure` only when the user opted in
/// to key identity (see `keyDescriptor`).
public enum InputEvent: Equatable {
    case header(EventHeader)
    case move(t: Double, x: Double, y: Double, outside: Bool)
    case down(t: Double, x: Double, y: Double, outside: Bool, button: MouseButton)
    case up(t: Double, x: Double, y: Double, outside: Bool, button: MouseButton)
    case key(t: Double, mods: [String], name: String? = nil, secure: Bool = false)
    case scroll(t: Double, dx: Double, dy: Double)
    // Extras readers may ignore:
    case pause(t: Double)
    case resume(t: Double)
    /// The captured window moved or resized (global points, origin top-left).
    case windowFrame(t: Double, rect: CaptureRect)
    case end(t: Double)
}

public enum EventLogFormat {
    public static let version = 1

    /// Fixed-precision number with trailing zeros removed ("1.5", "20", "0.0001").
    static func num(_ v: Double, _ decimals: Int) -> String {
        guard v.isFinite else { return "0" }
        var s = String(format: "%.\(decimals)f", v)
        if s.contains(".") {
            while s.hasSuffix("0") { s.removeLast() }
            if s.hasSuffix(".") { s.removeLast() }
        }
        return s == "-0" ? "0" : s
    }

    private static func t(_ v: Double) -> String { num(v, 4) }
    private static func n(_ v: Double) -> String { num(v, 5) }
    private static func p(_ v: Double) -> String { num(v, 2) }
    private static func o(_ outside: Bool) -> String { outside ? ",\"outside\":true" : "" }

    static func jsonEscape(_ s: String) -> String {
        var out = ""
        for u in s.unicodeScalars {
            switch u {
            case "\"": out += "\\\""
            case "\\": out += "\\\\"
            default:
                if u.value < 0x20 { out += String(format: "\\u%04x", u.value) } else { out.unicodeScalars.append(u) }
            }
        }
        return out
    }

    /// Deterministic one-line encoding (fixed key order, no trailing newline).
    public static func encode(_ e: InputEvent) -> String {
        switch e {
        case .header(let h):
            let c = h.captured
            return "{\"type\":\"header\",\"version\":\(version),\"startedAtUnix\":\(num(h.startedAtUnix, 3)),"
                + "\"display\":{\"width\":\(num(h.displayWidth, 0)),\"height\":\(num(h.displayHeight, 0)),\"scale\":\(num(h.scale, 2))},"
                + "\"captured\":{\"x\":\(num(c.x, 0)),\"y\":\(num(c.y, 0)),\"width\":\(num(c.width, 0)),\"height\":\(num(c.height, 0))},"
                + "\"target\":\"\(h.target)\",\"hostTime\":\(num(h.hostTime, 6))}"
        case .move(let tt, let x, let y, let out):
            return "{\"type\":\"move\",\"t\":\(t(tt)),\"x\":\(n(x)),\"y\":\(n(y))\(o(out))}"
        case .down(let tt, let x, let y, let out, let b):
            return "{\"type\":\"down\",\"t\":\(t(tt)),\"x\":\(n(x)),\"y\":\(n(y)),\"button\":\"\(b.rawValue)\"\(o(out))}"
        case .up(let tt, let x, let y, let out, let b):
            return "{\"type\":\"up\",\"t\":\(t(tt)),\"x\":\(n(x)),\"y\":\(n(y)),\"button\":\"\(b.rawValue)\"\(o(out))}"
        case .key(let tt, let mods, let name, let secure):
            let m = mods.isEmpty ? "" : ",\"mods\":[" + mods.map { "\"\($0)\"" }.joined(separator: ",") + "]"
            let nm = name.map { ",\"name\":\"\(jsonEscape($0))\"" } ?? ""
            return "{\"type\":\"key\",\"t\":\(t(tt))\(m)\(nm)\(secure ? ",\"secure\":true" : "")}"
        case .scroll(let tt, let dx, let dy):
            return "{\"type\":\"scroll\",\"t\":\(t(tt)),\"dx\":\(p(dx)),\"dy\":\(p(dy))}"
        case .pause(let tt):
            return "{\"type\":\"pause\",\"t\":\(t(tt))}"
        case .resume(let tt):
            return "{\"type\":\"resume\",\"t\":\(t(tt))}"
        case .windowFrame(let tt, let r):
            return "{\"type\":\"windowframe\",\"t\":\(t(tt)),\"x\":\(p(r.x)),\"y\":\(p(r.y)),\"width\":\(p(r.width)),\"height\":\(p(r.height))}"
        case .end(let tt):
            return "{\"type\":\"end\",\"t\":\(t(tt))}"
        }
    }
}

/// Appends events to `events.jsonl`. Each event is written straight to the file
/// (no user-space buffering), so a killed process loses at most the line in
/// flight — the OS already holds everything before it.
public final class EventLogWriter {
    private let handle: FileHandle
    private let lock = NSLock()
    private var closed = false
    public private(set) var count = 0

    public init(url: URL) throws {
        // Owner-only: the log can hold key names (and, with the second opt-in, typed text).
        FileManager.default.createFile(atPath: url.path, contents: nil, attributes: [.posixPermissions: 0o600])
        handle = try FileHandle(forWritingTo: url)
    }

    public func append(_ event: InputEvent) {
        let line = EventLogFormat.encode(event) + "\n"
        lock.lock(); defer { lock.unlock() }
        guard !closed, let data = line.data(using: .utf8) else { return }
        try? handle.write(contentsOf: data)
        count += 1
    }

    public func close() {
        lock.lock(); defer { lock.unlock() }
        guard !closed else { return }
        closed = true
        try? handle.synchronize()
        try? handle.close()
    }

    deinit { close() }
}
