import Carbon.HIToolbox
import Foundation

/// The character a key code produces with no modifiers on a given keyboard layout
/// (`UCKeyTranslate`, dead keys off). Pure given the layout data, so tests can inject it.
public func translateKeyCode(_ keyCode: UInt16, layoutData: Data) -> String? {
    layoutData.withUnsafeBytes { raw -> String? in
        guard let base = raw.baseAddress else { return nil }
        let layout = base.assumingMemoryBound(to: UCKeyboardLayout.self)
        var dead: UInt32 = 0
        var length = 0
        var chars = [UniChar](repeating: 0, count: 4)
        let status = UCKeyTranslate(
            layout, keyCode, UInt16(kUCKeyActionDown), 0, UInt32(LMGetKbdType()),
            OptionBits(kUCKeyTranslateNoDeadKeysBit), &dead, chars.count, &length, &chars)
        guard status == noErr, length > 0 else { return nil }
        return String(utf16CodeUnits: chars, count: length)
    }
}

/// `translateKeyCode` on the user's ASCII-capable layout (so Cyrillic, Greek, etc.
/// layouts still give the Latin shortcut letter). Call from the main thread: the
/// Text Input Source APIs are main-thread only. Nil when no layout data is available.
public func asciiLayoutCharacter(keyCode: UInt16) -> String? {
    guard let source = TISCopyCurrentASCIICapableKeyboardLayoutInputSource()?.takeRetainedValue(),
          let ptr = TISGetInputSourceProperty(source, kTISPropertyUnicodeKeyLayoutData)
    else { return nil }
    let data = Unmanaged<CFData>.fromOpaque(ptr).takeUnretainedValue() as Data
    return translateKeyCode(keyCode, layoutData: data)
}
