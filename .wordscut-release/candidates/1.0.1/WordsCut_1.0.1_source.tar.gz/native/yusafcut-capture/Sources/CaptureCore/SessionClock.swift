import Foundation

/// The shared timeline for one take.
///
/// Every source (screen, system audio, camera, microphone, cursor events) is
/// reduced to *host seconds* — the `mach_absolute_time` clock that
/// `CMClockGetHostTimeClock()` and `NSEvent.timestamp` use — and then mapped to
/// *media time*: seconds since `t0`, with paused stretches removed. Media time
/// 0 is the same instant in every output file.
public struct SessionClock {
    public let t0: Double
    private var finished: [(start: Double, end: Double)] = []
    private var pausedSince: Double?

    public init(t0: Double) { self.t0 = t0 }

    public var isPaused: Bool { pausedSince != nil }

    public mutating func pause(atHost host: Double) {
        guard pausedSince == nil else { return }
        pausedSince = max(host, t0)
    }

    public mutating func resume(atHost host: Double) {
        guard let start = pausedSince else { return }
        finished.append((start, max(host, start)))
        pausedSince = nil
    }

    /// Media time of a host time, or nil when the instant is before the take
    /// started or falls inside a pause (the sample must be dropped).
    public func mediaTime(forHost host: Double) -> Double? {
        if host < t0 { return nil }
        if let p = pausedSince, host >= p { return nil }
        var removed = 0.0
        for gap in finished {
            if host >= gap.start && host < gap.end { return nil }
            if host >= gap.end { removed += gap.end - gap.start }
        }
        return host - t0 - removed
    }

    /// Recorded seconds so far at `host` (frozen while paused).
    public func elapsed(atHost host: Double) -> Double {
        let upTo = pausedSince.map { min($0, host) } ?? host
        var removed = 0.0
        for gap in finished where gap.end <= upTo { removed += gap.end - gap.start }
        return max(0, upTo - t0 - removed)
    }
}

/// Maps a source's own presentation timestamps onto host seconds.
///
/// Built-in cameras, microphones and ScreenCaptureKit stamp buffers with the
/// host clock already. Some USB / virtual devices run their own clock; for those
/// the offset to the host clock is latched from the first buffer.
public struct ClockAligner {
    public let tolerance: Double
    private var offset: Double?

    public init(tolerance: Double = 2.0) { self.tolerance = tolerance }

    public var isForeignClock: Bool { (offset ?? 0) != 0 }

    public mutating func hostTime(forPTS pts: Double, nowHost: Double) -> Double {
        if offset == nil {
            offset = abs(pts - nowHost) <= tolerance ? 0 : nowHost - pts
        }
        return pts + (offset ?? 0)
    }
}

/// Thread-safe holder so the capture queue, the input monitor and the
/// controller all see the same pause state.
public final class SharedClock {
    private var clock: SessionClock
    private let lock = NSLock()

    public init(t0: Double) { clock = SessionClock(t0: t0) }

    public var t0: Double { lock.lock(); defer { lock.unlock() }; return clock.t0 }
    public var isPaused: Bool { lock.lock(); defer { lock.unlock() }; return clock.isPaused }

    public func mediaTime(forHost host: Double) -> Double? {
        lock.lock(); defer { lock.unlock() }
        return clock.mediaTime(forHost: host)
    }

    public func elapsed(atHost host: Double) -> Double {
        lock.lock(); defer { lock.unlock() }
        return clock.elapsed(atHost: host)
    }

    public func pause(atHost host: Double) { lock.lock(); clock.pause(atHost: host); lock.unlock() }
    public func resume(atHost host: Double) { lock.lock(); clock.resume(atHost: host); lock.unlock() }
}

/// Latches a take's origin from its first primary media sample, never a request
/// timestamp or an earlier secondary input. Owned by the serial capture queue.
public struct CaptureOrigin {
    public private(set) var host: Double?
    public init() {}
    public mutating func observe(host sample: Double, primary: Bool) -> Double? {
        guard sample.isFinite else { return host }
        if host == nil && primary { host = sample }
        return host
    }
}
