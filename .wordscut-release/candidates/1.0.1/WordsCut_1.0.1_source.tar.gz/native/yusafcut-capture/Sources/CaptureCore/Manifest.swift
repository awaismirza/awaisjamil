import Foundation

/// `manifest.json`, written when a take starts (with `finished: false`) and
/// rewritten when it stops. After a crash the first version is still there, and
/// the track files are fragmented so they stay readable.
public struct TakeManifest: Codable, Equatable {
    public struct Capture: Codable, Equatable {
        public var kind: String          // "display" | "window" | "area"
        public var displayId: UInt32?
        public var windowId: UInt32?
        /// Captured region in global points (origin top-left), at start.
        public var rect: Rect?
        public var pixelWidth: Int
        public var pixelHeight: Int
        public var scale: Double
        public var fps: Int
        public var showsCursor: Bool
        public init(kind: String, displayId: UInt32?, windowId: UInt32?, rect: Rect?,
                    pixelWidth: Int, pixelHeight: Int, scale: Double, fps: Int, showsCursor: Bool) {
            self.kind = kind; self.displayId = displayId; self.windowId = windowId
            self.rect = rect; self.pixelWidth = pixelWidth; self.pixelHeight = pixelHeight
            self.scale = scale; self.fps = fps; self.showsCursor = showsCursor
        }
    }
    public struct Rect: Codable, Equatable {
        public var x: Double, y: Double, width: Double, height: Double
        public init(_ r: CaptureRect) { x = r.x; y = r.y; width = r.width; height = r.height }
    }
    public struct Tracks: Codable, Equatable {
        public var screen: String?
        public var camera: String?
        public var microphone: String?
        public var systemAudio: String?
        public var events: String?
        public init() {}
    }

    public var version: Int = 1
    /// Host-clock seconds at media time 0.
    public var t0Host: Double
    public var startedAtUnix: Double
    public var finished: Bool = false
    public var durationSec: Double?
    public var capture: Capture?
    public var tracks: Tracks = Tracks()

    public init(t0Host: Double, startedAtUnix: Double, capture: Capture?) {
        self.t0Host = t0Host
        self.startedAtUnix = startedAtUnix
        self.capture = capture
    }

    public func write(to url: URL) throws {
        let enc = JSONEncoder()
        enc.outputFormatting = [.sortedKeys, .prettyPrinted, .withoutEscapingSlashes]
        try enc.encode(self).write(to: url, options: .atomic)
    }
}
