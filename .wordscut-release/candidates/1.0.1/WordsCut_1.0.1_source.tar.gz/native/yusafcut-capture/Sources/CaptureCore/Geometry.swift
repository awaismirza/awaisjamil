import Foundation

/// H.264 wants even dimensions.
public func evenDimension(_ value: Double) -> Int {
    let v = max(2, Int(value.rounded()))
    return v % 2 == 0 ? v : v - 1
}

/// Position of a global point inside a capture rectangle, 0…1 across the
/// rectangle (values outside 0…1 mean the cursor is outside the capture).
public func normalize(x: Double, y: Double, in rect: CaptureRect) -> (nx: Double, ny: Double) {
    guard rect.width > 0, rect.height > 0 else { return (0, 0) }
    return ((x - rect.x) / rect.width, (y - rect.y) / rect.height)
}

/// Average video bitrate for screen content: ~0.08 bits per pixel per frame,
/// kept within a sane range.
public func videoBitrate(width: Int, height: Int, fps: Int) -> Int {
    let raw = Double(width) * Double(height) * Double(fps) * 0.08
    return Int(min(max(raw, 4_000_000), 40_000_000))
}

/// Clamp a normalised position to 0…1; `outside` is true if it had to move.
public func clampUnit(nx: Double, ny: Double) -> (x: Double, y: Double, outside: Bool) {
    let x = min(max(nx, 0), 1), y = min(max(ny, 0), 1)
    return (x, y, x != nx || y != ny)
}
