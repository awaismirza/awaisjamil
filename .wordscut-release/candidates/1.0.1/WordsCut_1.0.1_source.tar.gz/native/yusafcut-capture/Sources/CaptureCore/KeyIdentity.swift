import Foundation

/// Privacy rules for key identity in `events.jsonl` (docs/cursor-events.md).
/// Pure: the monitor passes in what it observed, this decides what may be logged.
public struct KeyIdentityOptions: Equatable {
    /// Opt-in. Off: key events carry timing and modifiers only (version 1 behaviour).
    public var recordKeyIdentity: Bool
    /// Second opt-in, needs `recordKeyIdentity`: also log ordinary characters and
    /// typing-flow keys.
    public var recordAllCharacters: Bool
    public init(recordKeyIdentity: Bool = false, recordAllCharacters: Bool = false) {
        self.recordKeyIdentity = recordKeyIdentity
        self.recordAllCharacters = recordKeyIdentity && recordAllCharacters
    }
}

public struct KeyDescriptor: Equatable {
    public var name: String?
    public var secure: Bool
    public init(name: String? = nil, secure: Bool = false) { self.name = name; self.secure = secure }
}

/// Typing-flow keys: they reveal typing rhythm and edits, so they need a modifier
/// shortcut or the second opt-in (`recordAllCharacters`).
private let typingFlowKeys: [UInt16: String] = [
    36: "return", 76: "return", 48: "tab", 49: "space", 51: "delete", 117: "forwarddelete",
]

/// Virtual key codes (Carbon `kVK_*`) of navigation / function keys, named whenever
/// key identity is on.
private let specialKeys: [UInt16: String] = [
    53: "esc", 114: "insert", 71: "clear",
    115: "home", 119: "end", 116: "pageup", 121: "pagedown",
    123: "left", 124: "right", 125: "down", 126: "up",
    122: "f1", 120: "f2", 99: "f3", 118: "f4", 96: "f5", 97: "f6", 98: "f7", 100: "f8",
    101: "f9", 109: "f10", 103: "f11", 111: "f12", 105: "f13", 107: "f14", 113: "f15",
    106: "f16", 64: "f17", 79: "f18", 80: "f19", 90: "f20",
]

/// A single, printable, non-private-use character, lower-cased; nil otherwise.
/// (AppKit reports arrow / function keys as U+F700...U+F8FF.)
func cleanKeyCharacter(_ raw: String?) -> String? {
    guard let c = raw?.lowercased(), c.count == 1 else { return nil }
    for u in c.unicodeScalars {
        if CharacterSet.controlCharacters.contains(u) || (0xF700...0xF8FF).contains(u.value) { return nil }
    }
    return c
}

/// Window capture: key names are recorded only while the captured window's app is
/// in front (a press in another app is logged without a name). Screen and area
/// capture have no single owner, so they always return true.
public func isInCapturedApp(windowMode: Bool, ownerPID: Int32?, frontmostPID: Int32?) -> Bool {
    guard windowMode else { return true }
    guard let ownerPID, let frontmostPID else { return false }
    return ownerPID == frontmostPID
}

/// - Parameters:
///   - characters: `charactersIgnoringModifiers` of the event (what the layout types).
///   - layoutCharacter: the key's unshifted character on the ASCII-capable layout
///     (`asciiLayoutCharacter`); shown for Cmd/Ctrl shortcuts so a Cyrillic layout
///     still reads as the Latin shortcut letter and Shift never turns "3" into "#".
///   - mods: the held modifiers as logged ("cmd", "ctrl", "alt", "shift").
///   - secureInput: macOS secure event input is on (password fields).
///   - inCapturedApp: see `isInCapturedApp`.
public func keyDescriptor(keyCode: UInt16, characters: String?, layoutCharacter: String? = nil,
                          mods: [String], secureInput: Bool, inCapturedApp: Bool = true,
                          options: KeyIdentityOptions) -> KeyDescriptor {
    guard options.recordKeyIdentity, inCapturedApp else { return KeyDescriptor() }
    if secureInput { return KeyDescriptor(name: nil, secure: true) }
    if let special = specialKeys[keyCode] { return KeyDescriptor(name: special) }
    // Option alone types characters on many layouts (DE, PL, FR), so it is not a
    // "shortcut" for printable keys; Cmd or Ctrl is.
    let primary = mods.contains { $0 == "cmd" || $0 == "ctrl" }
    let anyModifier = primary || mods.contains("alt")
    if let flow = typingFlowKeys[keyCode] {
        return anyModifier || options.recordAllCharacters ? KeyDescriptor(name: flow) : KeyDescriptor()
    }
    guard primary || options.recordAllCharacters else { return KeyDescriptor() }
    let c = primary ? (cleanKeyCharacter(layoutCharacter) ?? cleanKeyCharacter(characters))
                    : cleanKeyCharacter(characters)
    return KeyDescriptor(name: c)
}
