import Foundation

// JSON-lines control protocol: one JSON object per line on stdin (requests) and
// stdout (responses + asynchronous events). Everything else the helper prints
// goes to stderr.
//
//   → {"id":1,"cmd":"list-devices"}
//   ← {"id":1,"ok":true,"result":{...}}
//   ← {"event":"state","state":"recording","elapsed":3.2}

public struct CaptureRect: Equatable {
    public var x: Double
    public var y: Double
    public var width: Double
    public var height: Double
    public init(x: Double, y: Double, width: Double, height: Double) {
        self.x = x; self.y = y; self.width = width; self.height = height
    }
}

public enum CaptureTarget: Equatable {
    case display(id: UInt32)
    case window(id: UInt32)
    /// A rectangle of one display, in that display's point coordinates
    /// (origin top-left).
    case area(display: UInt32, rect: CaptureRect)
}

public enum PermissionKind: String, CaseIterable {
    case screenRecording
    case camera
    case microphone
    /// Needed only for key-down timestamps; never blocks recording.
    case inputMonitoring
}

public struct StartOptions: Equatable {
    public var target: CaptureTarget?
    public var camera: String?
    public var microphone: String?
    public var systemAudio: Bool
    public var fps: Int
    public var outDir: String
    /// The real cursor is hidden by default: it is redrawn at render time from
    /// the cursor events.
    public var showsCursor: Bool
    /// Opt-in key identity (see `KeyIdentityOptions`); both default off.
    public var keyIdentity: KeyIdentityOptions = KeyIdentityOptions()
}

public enum Command: Equatable {
    case listDevices
    case permissions
    case requestPermissions([PermissionKind])
    /// A small JPEG of a display or window, for the recorder's source picker.
    case thumbnail(target: CaptureTarget, maxWidth: Int)
    case start(StartOptions)
    case pause
    case resume
    case stop
    case status
    case quit
}

public struct Request: Equatable {
    public var id: Int?
    public var command: Command
}

public enum ProtocolError: Error, Equatable {
    case invalidJSON
    case missingCommand
    case unknownCommand(String)
    case invalidField(String)

    public var message: String {
        switch self {
        case .invalidJSON: return "request is not a JSON object"
        case .missingCommand: return "request has no \"cmd\""
        case .unknownCommand(let c): return "unknown command \"\(c)\""
        case .invalidField(let f): return "invalid or missing field \"\(f)\""
        }
    }
}

public let minFPS = 10
public let maxFPS = 60
public let defaultFPS = 30
public let defaultThumbnailWidth = 480
public let minThumbnailWidth = 64
public let maxThumbnailWidth = 1280

private func intValue(_ any: Any?) -> Int? {
    if let n = any as? NSNumber, CFGetTypeID(n) != CFBooleanGetTypeID() { return n.intValue }
    return nil
}

private func doubleValue(_ any: Any?) -> Double? {
    if let n = any as? NSNumber, CFGetTypeID(n) != CFBooleanGetTypeID() { return n.doubleValue }
    return nil
}

private func idValue(_ any: Any?) -> UInt32? {
    guard let i = intValue(any), i >= 0, i <= Int(UInt32.max) else { return nil }
    return UInt32(i)
}

public func parseRequest(_ line: String) throws -> Request {
    guard let data = line.data(using: .utf8),
          let obj = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
    else { throw ProtocolError.invalidJSON }
    let id = intValue(obj["id"])
    guard let cmd = obj["cmd"] as? String else { throw ProtocolError.missingCommand }

    switch cmd {
    case "list-devices": return Request(id: id, command: .listDevices)
    case "permissions": return Request(id: id, command: .permissions)
    case "request-permissions":
        var kinds: [PermissionKind] = []
        if let raw = obj["kinds"] {
            guard let names = raw as? [String] else { throw ProtocolError.invalidField("kinds") }
            for n in names {
                guard let k = PermissionKind(rawValue: n) else { throw ProtocolError.invalidField("kinds") }
                kinds.append(k)
            }
        } else {
            kinds = PermissionKind.allCases
        }
        return Request(id: id, command: .requestPermissions(kinds))
    case "thumbnail":
        let target: CaptureTarget
        if obj["display"] != nil {
            guard let d = idValue(obj["display"]) else { throw ProtocolError.invalidField("display") }
            target = .display(id: d)
        } else if obj["window"] != nil {
            guard let w = idValue(obj["window"]) else { throw ProtocolError.invalidField("window") }
            target = .window(id: w)
        } else {
            throw ProtocolError.invalidField("display/window")
        }
        var maxWidth = defaultThumbnailWidth
        if let raw = obj["maxWidth"] {
            guard let m = intValue(raw) else { throw ProtocolError.invalidField("maxWidth") }
            maxWidth = min(max(m, minThumbnailWidth), maxThumbnailWidth)
        }
        return Request(id: id, command: .thumbnail(target: target, maxWidth: maxWidth))
    case "pause": return Request(id: id, command: .pause)
    case "resume": return Request(id: id, command: .resume)
    case "stop": return Request(id: id, command: .stop)
    case "status": return Request(id: id, command: .status)
    case "quit": return Request(id: id, command: .quit)
    case "start": return Request(id: id, command: .start(try parseStart(obj)))
    default: throw ProtocolError.unknownCommand(cmd)
    }
}

private func parseStart(_ obj: [String: Any]) throws -> StartOptions {
    var target: CaptureTarget?
    var chosen = 0
    if obj["display"] != nil {
        guard let d = idValue(obj["display"]) else { throw ProtocolError.invalidField("display") }
        target = .display(id: d)
        chosen += 1
    }
    if obj["window"] != nil {
        guard let w = idValue(obj["window"]) else { throw ProtocolError.invalidField("window") }
        target = .window(id: w)
        chosen += 1
    }
    if let area = obj["area"] {
        guard let a = area as? [String: Any],
              let d = idValue(a["display"]),
              let x = doubleValue(a["x"]), let y = doubleValue(a["y"]),
              let w = doubleValue(a["width"]), let h = doubleValue(a["height"]),
              w > 0, h > 0, x >= 0, y >= 0
        else { throw ProtocolError.invalidField("area") }
        target = .area(display: d, rect: CaptureRect(x: x, y: y, width: w, height: h))
        chosen += 1
    }
    if chosen > 1 { throw ProtocolError.invalidField("display/window/area (pick one)") }

    func optString(_ key: String) throws -> String? {
        guard let raw = obj[key] else { return nil }
        if raw is NSNull { return nil }
        guard let s = raw as? String, !s.isEmpty else { throw ProtocolError.invalidField(key) }
        return s
    }
    let camera = try optString("camera")
    let microphone = try optString("microphone")
    let systemAudio = (obj["systemAudio"] as? Bool) ?? false
    if target == nil && camera == nil && microphone == nil && !systemAudio {
        throw ProtocolError.invalidField("display/window/area/camera/microphone")
    }
    guard let outDir = obj["outDir"] as? String, !outDir.isEmpty else {
        throw ProtocolError.invalidField("outDir")
    }
    var fps = defaultFPS
    if let raw = obj["fps"] {
        guard let f = intValue(raw) else { throw ProtocolError.invalidField("fps") }
        fps = min(max(f, minFPS), maxFPS)
    }
    if systemAudio && target == nil {
        // System audio rides on the screen stream.
        throw ProtocolError.invalidField("systemAudio (needs a display, window or area)")
    }
    return StartOptions(
        target: target, camera: camera, microphone: microphone, systemAudio: systemAudio,
        fps: fps, outDir: outDir, showsCursor: (obj["showsCursor"] as? Bool) ?? false,
        keyIdentity: KeyIdentityOptions(
            recordKeyIdentity: (obj["recordKeyIdentity"] as? Bool) ?? false,
            recordAllCharacters: (obj["recordAllCharacters"] as? Bool) ?? false))
}

// MARK: - Output

public func okResponse(id: Int?, result: [String: JSONValue] = [:]) -> JSONValue {
    var o: [String: JSONValue] = ["ok": .bool(true), "result": .object(result)]
    if let id { o["id"] = .int(id) }
    return .object(o)
}

public func errorResponse(id: Int?, code: String, message: String) -> JSONValue {
    var o: [String: JSONValue] = [
        "ok": .bool(false),
        "error": .object(["code": .string(code), "message": .string(message)]),
    ]
    if let id { o["id"] = .int(id) }
    return .object(o)
}

public func eventMessage(_ name: String, _ fields: [String: JSONValue] = [:]) -> JSONValue {
    var o = fields
    o["event"] = .string(name)
    return .object(o)
}

/// Error codes the Rust side keys off.
public enum ErrorCode {
    public static let badRequest = "bad-request"
    public static let permissionDenied = "permission-denied"
    public static let notFound = "not-found"
    public static let invalidState = "invalid-state"
    public static let captureFailed = "capture-failed"
}
