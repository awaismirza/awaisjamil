import Foundation

/// Title of WordsCut's desktop recording controller. The app creates the window
/// with exactly this title (`src-tauri/src/controller.rs`).
public let controllerWindowTitle = "WordsCut Recording Controls"

/// What the helper needs to know about a window to decide whether it is part of
/// the app's own recording controls.
public struct WindowIdentity: Equatable {
    public var id: UInt32
    public var pid: Int32
    public var title: String
    public init(id: UInt32, pid: Int32, title: String) {
        self.id = id; self.pid = pid; self.title = title
    }
}

/// A recording control: owned by the app that launched this helper (`appPid`) and
/// carrying the controller title. Matching on both keeps another application's
/// similarly titled window recordable, and keeps the WordsCut editor recordable.
public func isRecordingControl(_ window: WindowIdentity, appPid: Int32) -> Bool {
    window.pid == appPid && window.title.hasPrefix(controllerWindowTitle)
}

/// Window IDs to exclude from display / area capture, sorted for stable comparison.
public func controlWindowIDs(_ windows: [WindowIdentity], appPid: Int32) -> [UInt32] {
    windows.filter { isRecordingControl($0, appPid: appPid) }.map(\.id).sorted()
}
