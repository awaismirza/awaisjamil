import AppKit
import Carbon.HIToolbox
import CaptureCore
import CaptureMedia
import Foundation

/// Cursor position (~60 Hz, on change), clicks, scrolls, key-down times and — for
/// window capture — window frame changes, all stamped on the take's media clock.
final class InputMonitor {
    private let clock: SharedClock
    private let log: EventLogWriter
    private let queue = DispatchQueue(label: "yusafcut.input", qos: .userInteractive)
    private var cursorTimer: DispatchSourceTimer?
    private var windowTimer: DispatchSourceTimer?
    private var monitor: Any?
    private let rectLock = NSLock()
    private var rect: CaptureRect
    private var lastCursor: CGPoint?
    private let windowID: UInt32?
    private let keyIdentity: KeyIdentityOptions

    init(clock: SharedClock, log: EventLogWriter, captureRect: CaptureRect, windowID: UInt32?,
         keyIdentity: KeyIdentityOptions = KeyIdentityOptions()) {
        self.keyIdentity = keyIdentity
        self.clock = clock
        self.log = log
        self.rect = captureRect
        self.windowID = windowID
    }

    private var currentRect: CaptureRect {
        rectLock.lock(); defer { rectLock.unlock() }
        return rect
    }

    /// Must be called on the main thread (NSEvent monitors).
    func start() {
        let mask: NSEvent.EventTypeMask = [
            .leftMouseDown, .leftMouseUp, .rightMouseDown, .rightMouseUp,
            .otherMouseDown, .otherMouseUp, .keyDown, .scrollWheel,
        ]
        monitor = NSEvent.addGlobalMonitorForEvents(matching: mask) { [weak self] e in self?.handle(e) }

        let t = DispatchSource.makeTimerSource(queue: queue)
        t.schedule(deadline: .now(), repeating: .milliseconds(16), leeway: .milliseconds(1))
        t.setEventHandler { [weak self] in self?.pollCursor() }
        t.resume()
        cursorTimer = t

        if let windowID {
            let w = DispatchSource.makeTimerSource(queue: queue)
            w.schedule(deadline: .now(), repeating: .milliseconds(100), leeway: .milliseconds(10))
            w.setEventHandler { [weak self] in self?.pollWindow(windowID) }
            w.resume()
            windowTimer = w
        }
    }

    func stop() {
        cursorTimer?.cancel(); cursorTimer = nil
        windowTimer?.cancel(); windowTimer = nil
        if let monitor { NSEvent.removeMonitor(monitor) }
        monitor = nil
    }

    private func unit(_ p: CGPoint) -> (x: Double, y: Double, outside: Bool) {
        let n = normalize(x: p.x, y: p.y, in: currentRect)
        return clampUnit(nx: n.nx, ny: n.ny)
    }

    private func quartzLocation() -> CGPoint? { CGEvent(source: nil)?.location }

    private func pollCursor() {
        guard let p = quartzLocation(), p != lastCursor,
              let t = clock.mediaTime(forHost: hostSecondsNow()) else { return }
        lastCursor = p
        let c = unit(p)
        log.append(.move(t: t, x: c.x, y: c.y, outside: c.outside))
    }

    private func pollWindow(_ id: UInt32) {
        guard let infos = CGWindowListCopyWindowInfo([.optionIncludingWindow], CGWindowID(id)) as? [[String: Any]],
              let bounds = infos.first?[kCGWindowBounds as String] as? NSDictionary,
              let r = CGRect(dictionaryRepresentation: bounds),
              let t = clock.mediaTime(forHost: hostSecondsNow()) else { return }
        let next = CaptureRect(x: r.origin.x, y: r.origin.y, width: r.width, height: r.height)
        rectLock.lock()
        let changed = next != rect
        if changed { rect = next }
        rectLock.unlock()
        if changed { log.append(.windowFrame(t: t, rect: next)) }
    }

    /// Window capture only: is the captured window's app in front? (Fails closed.)
    private func inCapturedApp() -> Bool {
        guard let windowID else { return true }
        let infos = CGWindowListCopyWindowInfo([.optionIncludingWindow], CGWindowID(windowID)) as? [[String: Any]]
        let owner = (infos?.first?[kCGWindowOwnerPID as String] as? NSNumber)?.int32Value
        return isInCapturedApp(windowMode: true, ownerPID: owner,
                               frontmostPID: NSWorkspace.shared.frontmostApplication?.processIdentifier)
    }

    private func handle(_ e: NSEvent) {
        // NSEvent.timestamp is seconds since boot on the same mach clock the
        // host-time clock uses.
        guard let t = clock.mediaTime(forHost: e.timestamp) else { return }
        let p = quartzLocation() ?? .zero
        let c = unit(p)
        switch e.type {
        case .leftMouseDown: log.append(.down(t: t, x: c.x, y: c.y, outside: c.outside, button: .left))
        case .leftMouseUp: log.append(.up(t: t, x: c.x, y: c.y, outside: c.outside, button: .left))
        case .rightMouseDown: log.append(.down(t: t, x: c.x, y: c.y, outside: c.outside, button: .right))
        case .rightMouseUp: log.append(.up(t: t, x: c.x, y: c.y, outside: c.outside, button: .right))
        case .otherMouseDown: log.append(.down(t: t, x: c.x, y: c.y, outside: c.outside, button: .other))
        case .otherMouseUp: log.append(.up(t: t, x: c.x, y: c.y, outside: c.outside, button: .other))
        case .keyDown:
            if !e.isARepeat {
                var mods: [String] = []
                let f = e.modifierFlags
                if f.contains(.command) { mods.append("cmd") }
                if f.contains(.control) { mods.append("ctrl") }
                if f.contains(.option) { mods.append("alt") }
                if f.contains(.shift) { mods.append("shift") }
                // Privacy: identity comes only from `keyDescriptor`; never print or log it elsewhere.
                let on = keyIdentity.recordKeyIdentity
                let d = on ? keyDescriptor(
                    keyCode: e.keyCode, characters: e.charactersIgnoringModifiers,
                    layoutCharacter: asciiLayoutCharacter(keyCode: e.keyCode),
                    mods: mods, secureInput: IsSecureEventInputEnabled(),
                    inCapturedApp: inCapturedApp(), options: keyIdentity) : KeyDescriptor()
                log.append(.key(t: t, mods: mods, name: d.name, secure: d.secure))
            }
        case .scrollWheel: log.append(.scroll(t: t, dx: e.scrollingDeltaX, dy: e.scrollingDeltaY))
        default: break
        }
    }
}
