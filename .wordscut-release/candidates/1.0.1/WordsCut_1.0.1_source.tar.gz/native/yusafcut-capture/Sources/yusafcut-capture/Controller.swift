import CaptureCore
import CaptureMedia
import Foundation

/// Executes protocol commands one at a time and owns the single active take.
actor Controller {
    private var session: RecordingSession?
    private var ticker: Task<Void, Never>?
    private var lastResult: JSONValue?

    func handle(_ line: String) async {
        let trimmed = line.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.isEmpty { return }
        let request: Request
        do {
            request = try parseRequest(trimmed)
        } catch let e as ProtocolError {
            Out.send(errorResponse(id: nil, code: ErrorCode.badRequest, message: e.message))
            return
        } catch {
            Out.send(errorResponse(id: nil, code: ErrorCode.badRequest, message: "\(error)"))
            return
        }
        let id = request.id
        do {
            let result = try await run(request.command)
            Out.send(okResponse(id: id, result: result))
        } catch let e as CaptureError {
            Out.send(errorResponse(id: id, code: e.code, message: e.message))
        } catch {
            Out.send(errorResponse(id: id, code: ErrorCode.captureFailed, message: error.localizedDescription))
        }
        if request.command == .quit { exit(0) }
    }

    private func run(_ command: Command) async throws -> [String: JSONValue] {
        switch command {
        case .listDevices:
            guard case .object(var o) = await Devices.list() else { return [:] }
            o["permissions"] = Permissions.all()
            return o
        case .permissions:
            guard case .object(let o) = Permissions.all() else { return [:] }
            return o
        case .requestPermissions(let kinds):
            var o: [String: JSONValue] = [:]
            for k in kinds { o[k.rawValue] = .string(await Permissions.request(k)) }
            return o
        case .thumbnail(let target, let maxWidth):
            return try await Thumbnails.capture(target: target, maxWidth: maxWidth)
        case .start(let opts):
            guard session == nil else { throw CaptureError(ErrorCode.invalidState, "a take is already running") }
            let s = RecordingSession(options: opts)
            s.onFailure = { [weak self] message in
                Out.log(message)
                Out.send(eventMessage("error", ["message": .string(message)]))
                Task { await self?.failActiveTake() }
            }
            guard case .object(let o) = try await s.start() else { return [:] }
            session = s
            startTicker()
            emitState()
            return o
        case .pause:
            let s = try active()
            guard s.state == "recording" else { throw CaptureError(ErrorCode.invalidState, "not recording") }
            s.pause(); emitState()
            return ["elapsed": .num(s.elapsed)]
        case .resume:
            let s = try active()
            guard s.state == "paused" else { throw CaptureError(ErrorCode.invalidState, "not paused") }
            s.resume(); emitState()
            return ["elapsed": .num(s.elapsed)]
        case .stop:
            let s = try active()
            ticker?.cancel()
            guard case .object(let o) = await s.stop() else { return [:] }
            session = nil
            Out.send(eventMessage("state", ["state": .string("idle"), "elapsed": .num(0)]))
            return o
        case .status:
            guard let s = session else { return ["state": .string("idle"), "elapsed": .num(0)] }
            return ["state": .string(s.state), "elapsed": .num(s.elapsed)]
        case .quit:
            if let s = session { _ = await s.stop(); session = nil }
            return [:]
        }
    }

    private func active() throws -> RecordingSession {
        guard let s = session else { throw CaptureError(ErrorCode.invalidState, "no take is running") }
        return s
    }

    /// The source died under us (e.g. screen capture stopped). Keep the session so
    /// `stop` can still finalize the files; just tell the app.
    private func failActiveTake() {
        Out.send(eventMessage("state", ["state": .string("failed")]))
    }

    private func emitState() {
        guard let s = session else { return }
        Out.send(eventMessage("state", ["state": .string(s.state), "elapsed": .num(s.elapsed)]))
    }

    private func startTicker() {
        ticker?.cancel()
        ticker = Task { [weak self] in
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: 1_000_000_000)
                await self?.emitState()
            }
        }
    }

    /// Stdin closed or SIGTERM: finalize the take so no footage is lost.
    func shutdown() async {
        ticker?.cancel()
        if let s = session { _ = await s.stop(); session = nil }
    }
}
