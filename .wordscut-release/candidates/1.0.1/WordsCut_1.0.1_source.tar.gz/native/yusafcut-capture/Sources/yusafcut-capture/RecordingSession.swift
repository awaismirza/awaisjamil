import AppKit
@preconcurrency import AVFoundation
import CaptureCore
import CaptureMedia
import CoreMedia
import Foundation
import ScreenCaptureKit

/// One take. Screen + system audio come from ScreenCaptureKit, camera and
/// microphone from AVCaptureSession; each source goes to its own fragmented file
/// and is re-timed onto the shared media clock before it is written.
final class RecordingSession: NSObject, SCStreamOutput, SCStreamDelegate,
    AVCaptureVideoDataOutputSampleBufferDelegate, AVCaptureAudioDataOutputSampleBufferDelegate
{
    private enum Source: Hashable { case screen, systemAudio, camera, microphone }

    let options: StartOptions
    private let outURL: URL
    private let queue = DispatchQueue(label: "yusafcut.samples", qos: .userInteractive)
    private(set) var clock: SharedClock!
    private var events: EventLogWriter!
    private var input: InputMonitor?
    private var manifest: TakeManifest!
    private var manifestURL: URL!

    private var stream: SCStream?
    private var avSession: AVCaptureSession?
    private var cameraOutput: AVCaptureVideoDataOutput?
    private var micOutput: AVCaptureAudioDataOutput?

    // Touched on `queue` only.
    private var writers: [Source: TrackWriter] = [:]
    private var aligners: [Source: ClockAligner] = [:]
    private var screenSettings: TrackWriter.VideoSettings?
    private var stopped = false
    private var exclusionTask: Task<Void, Never>?
    private var deviceObservers: [NSObjectProtocol] = []
    private var deviceLossReported = false
    private var origin = CaptureOrigin()
    private var primaryHasData = false
    private var startupError: Error?
    private var startupWaiter: CheckedContinuation<Void, Error>?
    private var primarySource: Source {
        options.target != nil ? .screen : (options.camera != nil ? .camera : .microphone)
    }

    private(set) var state = "idle"
    var onFailure: ((String) -> Void)?

    init(options: StartOptions) {
        self.options = options
        self.outURL = URL(fileURLWithPath: options.outDir, isDirectory: true)
    }

    // MARK: Start

    func start() async throws -> JSONValue {
        try FileManager.default.createDirectory(at: outURL, withIntermediateDirectories: true)

        if options.target != nil { try Permissions.requireScreen() }
        if options.camera != nil { try await Permissions.requireAV(.camera) }
        if options.microphone != nil { try await Permissions.requireAV(.microphone) }

        // Resolve capture geometry first so nothing is started on bad input.
        var plan: ScreenPlan?
        if let target = options.target { plan = try await resolve(target) }
        let cameraDevice = try options.camera.map { id -> AVCaptureDevice in
            guard let d = AVCaptureDevice(uniqueID: id) else {
                throw CaptureError(ErrorCode.notFound, "camera \(id) not found")
            }
            return d
        }
        let micDevice = try options.microphone.map { id -> AVCaptureDevice in
            guard let d = AVCaptureDevice(uniqueID: id) else {
                throw CaptureError(ErrorCode.notFound, "microphone \(id) not found")
            }
            return d
        }

        let eventsURL = outURL.appendingPathComponent("events.jsonl")
        events = try EventLogWriter(url: eventsURL)
        manifestURL = outURL.appendingPathComponent("manifest.json")

        // Writers for tracks whose format is known up front; camera and audio
        // writers are created from their first buffer.
        func url(_ name: String) -> URL { outURL.appendingPathComponent(name) }
        if let plan {
            screenSettings = .init(width: plan.pixelWidth, height: plan.pixelHeight, fps: options.fps,
                                   bitrate: videoBitrate(width: plan.pixelWidth, height: plan.pixelHeight, fps: options.fps))
            writers[.screen] = TrackWriter(url: url("screen.mp4"), kind: .video, video: screenSettings)
            if options.systemAudio { writers[.systemAudio] = TrackWriter(url: url("system.m4a"), kind: .audio) }
        }
        if options.microphone != nil { writers[.microphone] = TrackWriter(url: url("mic.m4a"), kind: .audio) }
        // Camera writer is created on its first frame (needs the real dimensions).

        // Build capture graph (not running yet).
        if cameraDevice != nil || micDevice != nil {
            let s = AVCaptureSession()
            s.beginConfiguration()
            if let d = cameraDevice {
                let inp = try AVCaptureDeviceInput(device: d)
                guard s.canAddInput(inp) else { throw CaptureError(ErrorCode.captureFailed, "cannot use camera \(d.localizedName)") }
                s.addInput(inp)
                let out = AVCaptureVideoDataOutput()
                out.alwaysDiscardsLateVideoFrames = true
                out.setSampleBufferDelegate(self, queue: queue)
                guard s.canAddOutput(out) else { throw CaptureError(ErrorCode.captureFailed, "cannot read camera frames") }
                s.addOutput(out)
                cameraOutput = out
                if s.canSetSessionPreset(.hd1280x720) { s.sessionPreset = .hd1280x720 }
            }
            if let d = micDevice {
                let inp = try AVCaptureDeviceInput(device: d)
                guard s.canAddInput(inp) else { throw CaptureError(ErrorCode.captureFailed, "cannot use microphone \(d.localizedName)") }
                s.addInput(inp)
                let out = AVCaptureAudioDataOutput()
                out.setSampleBufferDelegate(self, queue: queue)
                guard s.canAddOutput(out) else { throw CaptureError(ErrorCode.captureFailed, "cannot read microphone audio") }
                s.addOutput(out)
                micOutput = out
            }
            s.commitConfiguration()
            avSession = s
            observeDeviceLoss(session: s, devices: [cameraDevice, micDevice].compactMap { $0 })
        }

        if let plan {
            let st = SCStream(filter: plan.filter, configuration: plan.config, delegate: self)
            try st.addStreamOutput(self, type: .screen, sampleHandlerQueue: queue)
            if options.systemAudio { try st.addStreamOutput(self, type: .audio, sampleHandlerQueue: queue) }
            stream = st
        }

        // t0: the instant every track's time 0 refers to.
        let t0 = hostSecondsNow()
        clock = SharedClock(t0: t0)
        let unix = Date().timeIntervalSince1970

        // events.jsonl header (docs/cursor-events.md): pixels of the display and
        // of the captured rectangle.
        let sc = plan?.scale ?? 2
        let mainBounds = CGDisplayBounds(CGMainDisplayID())
        let disp = plan?.displayPoints ?? mainBounds.size
        let cap = plan?.globalRect ?? CaptureRect(x: 0, y: 0, width: mainBounds.width, height: mainBounds.height)
        var capPx = CaptureRect(x: 0, y: 0, width: cap.width * sc, height: cap.height * sc)
        if let plan, plan.kind != "display" {
            let origin = CGDisplayBounds(CGDirectDisplayID(plan.displayID ?? CGMainDisplayID())).origin
            capPx.x = (cap.x - origin.x) * sc
            capPx.y = (cap.y - origin.y) * sc
        }
        var eventHeader = EventHeader(
            startedAtUnix: unix, hostTime: t0, displayWidth: disp.width * sc, displayHeight: disp.height * sc,
            scale: sc, captured: capPx, target: plan?.kind ?? "display")

        var captureInfo: TakeManifest.Capture?
        if let plan {
            captureInfo = .init(
                kind: plan.kind, displayId: plan.displayID, windowId: plan.windowID,
                rect: .init(plan.globalRect), pixelWidth: plan.pixelWidth, pixelHeight: plan.pixelHeight,
                scale: plan.scale, fps: options.fps, showsCursor: options.showsCursor)
        }
        manifest = TakeManifest(t0Host: t0, startedAtUnix: unix, capture: captureInfo)
        manifest.tracks.events = "events.jsonl"
        if writers[.screen] != nil { manifest.tracks.screen = "screen.mp4" }
        if options.systemAudio { manifest.tracks.systemAudio = "system.m4a" }
        if options.microphone != nil { manifest.tracks.microphone = "mic.m4a" }
        if options.camera != nil { manifest.tracks.camera = "camera.mp4" }
        try? manifest.write(to: manifestURL)

        do {
            if let stream { try await stream.startCapture() }
            if let plan, plan.kind != "window", let id = plan.displayID { startExclusionWatcher(displayID: id) }
            if let avSession { await runSession(avSession) }
            try await waitForPrimaryMedia()
        } catch {
            await teardownAfterFailure()
            throw CaptureError(ErrorCode.captureFailed, "could not start capture: \(error.localizedDescription)")
        }

        // The capture queue has latched the first primary sample's host time.
        // Write the header before input monitoring can append any events.
        eventHeader.hostTime = clock.t0
        eventHeader.startedAtUnix = Date().timeIntervalSince1970 - clock.elapsed(atHost: hostSecondsNow())
        events.append(.header(eventHeader))
        manifest.t0Host = clock.t0
        manifest.startedAtUnix = eventHeader.startedAtUnix
        try? manifest.write(to: manifestURL)

        // Cursor/typing activity belongs to screen recordings, not voice-over
        // or webcam-only takes.
        if let plan {
            await MainActor.run {
                let monitor = InputMonitor(
                    clock: clock, log: events, captureRect: plan.globalRect, windowID: plan.windowID,
                    keyIdentity: options.keyIdentity)
                monitor.start()
                input = monitor
            }
        }
        state = "recording"

        var files: [String: JSONValue] = ["events": .string(eventsURL.path), "manifest": .string(manifestURL.path)]
        if writers[.screen] != nil { files["screen"] = .string(url("screen.mp4").path) }
        if options.systemAudio { files["systemAudio"] = .string(url("system.m4a").path) }
        if options.microphone != nil { files["microphone"] = .string(url("mic.m4a").path) }
        if options.camera != nil { files["camera"] = .string(url("camera.mp4").path) }
        return .obj([
            "files": .obj(files), "t0Host": .num(clock.t0), "startedAtUnix": .num(eventHeader.startedAtUnix),
            "pixelWidth": .num(plan?.pixelWidth ?? 0), "pixelHeight": .num(plan?.pixelHeight ?? 0),
            "inputMonitoring": .string(Permissions.state(.inputMonitoring)),
        ])
    }

    private func waitForPrimaryMedia() async throws {
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            queue.async { [self] in
                if self.primaryHasData { continuation.resume(); return }
                if let error = self.startupError { continuation.resume(throwing: error); return }
                self.startupWaiter = continuation
                self.queue.asyncAfter(deadline: .now() + 30) { [weak self] in
                    guard let self, let waiter = self.startupWaiter else { return }
                    self.startupWaiter = nil
                    waiter.resume(throwing: CaptureError(ErrorCode.captureFailed,
                        "The selected device produced no media within 30 seconds."))
                }
            }
        }
    }

    private func runSession(_ s: AVCaptureSession) async {
        await withCheckedContinuation { (c: CheckedContinuation<Void, Never>) in
            DispatchQueue.global().async { s.startRunning(); c.resume() }
        }
    }

    private func teardownAfterFailure() async {
        removeDeviceObservers()
        try? await stream?.stopCapture()
        avSession?.stopRunning()
        events?.close()
    }

    // MARK: Camera / microphone loss

    /// A pulled USB microphone, a camera taken by another app or a media-services
    /// reset stops AVCaptureSession output without any error to the writers. Report
    /// it once; the session stays alive so Stop can still finalize the tracks.
    private func observeDeviceLoss(session: AVCaptureSession, devices: [AVCaptureDevice]) {
        let center = NotificationCenter.default
        func watch(_ name: Notification.Name, object: AnyObject?, _ event: @escaping (Notification) -> DeviceLossEvent) {
            deviceObservers.append(center.addObserver(forName: name, object: object, queue: nil) { [weak self] note in
                self?.reportDeviceLoss(event(note))
            })
        }
        watch(.AVCaptureSessionRuntimeError, object: session) { note in
            let error = note.userInfo?[AVCaptureSessionErrorKey] as? NSError
            return .runtimeError(detail: error?.localizedDescription ?? "unknown error")
        }
        // macOS exposes no interruption-reason API (iOS only), so the reason is unknown.
        watch(.AVCaptureSessionWasInterrupted, object: session) { _ in .interrupted(reason: nil) }
        for device in devices {
            watch(AVCaptureDevice.wasDisconnectedNotification, object: device) { _ in
                .disconnected(device: device.localizedName)
            }
        }
    }

    private func reportDeviceLoss(_ event: DeviceLossEvent) {
        queue.async { [weak self] in
            guard let self, !self.stopped, !self.deviceLossReported else { return }
            self.deviceLossReported = true
            self.onFailure?(deviceLossMessage(event))
        }
    }

    private func removeDeviceObservers() {
        deviceObservers.forEach(NotificationCenter.default.removeObserver)
        deviceObservers.removeAll()
    }

    // MARK: Control-window exclusion

    nonisolated static func identity(of w: SCWindow) -> WindowIdentity {
        WindowIdentity(id: w.windowID, pid: w.owningApplication?.processID ?? -1, title: w.title ?? "")
    }

    /// The controller can be created, moved between Spaces or re-created after the
    /// stream started. Keep the filter's exclusion list in step with the windows.
    private func startExclusionWatcher(displayID: UInt32) {
        exclusionTask?.cancel()
        let appPid = getppid()
        exclusionTask = Task { [weak self] in
            var applied: [UInt32] = []
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: 750_000_000)
                guard let self, !self.stopped, let stream = self.stream else { return }
                guard let content = try? await SCShareableContent.excludingDesktopWindows(
                        false, onScreenWindowsOnly: true),
                      let display = content.displays.first(where: { $0.displayID == displayID })
                else { continue }
                let controls = content.windows.filter { isRecordingControl(Self.identity(of: $0), appPid: appPid) }
                let ids = controls.map { $0.windowID }.sorted()
                if ids == applied { continue }
                do {
                    try await stream.updateContentFilter(SCContentFilter(display: display, excludingWindows: controls))
                    applied = ids
                } catch {
                    Out.log("could not update the capture filter: \(error.localizedDescription)")
                }
            }
        }
    }

    // MARK: Screen geometry

    private struct ScreenPlan {
        var filter: SCContentFilter
        var config: SCStreamConfiguration
        var kind: String
        var displayID: UInt32?
        var windowID: UInt32?
        var globalRect: CaptureRect
        var displayPoints: CGSize
        var pixelWidth: Int
        var pixelHeight: Int
        var scale: Double
    }

    private func resolve(_ target: CaptureTarget) async throws -> ScreenPlan {
        let content: SCShareableContent
        do {
            content = try await SCShareableContent.excludingDesktopWindows(false, onScreenWindowsOnly: true)
        } catch {
            throw CaptureError(ErrorCode.permissionDenied,
                               "cannot read screen content (\(error.localizedDescription)). Check Screen Recording permission.")
        }
        let filter: SCContentFilter
        let appPid = getppid()
        let controls = content.windows.filter {
            isRecordingControl(Self.identity(of: $0), appPid: appPid)
        }
        var sourceRect: CGRect?
        let points: CGSize
        let global: CGRect
        let scale: Double
        var kind = "display"
        var displayPoints = CGSize.zero
        var displayID: UInt32?
        var windowID: UInt32?

        switch target {
        case .display(let id):
            guard let d = content.displays.first(where: { $0.displayID == id }) else {
                throw CaptureError(ErrorCode.notFound, "display \(id) not found")
            }
            filter = SCContentFilter(display: d, excludingWindows: controls)
            points = CGSize(width: d.width, height: d.height)
            global = d.frame
            scale = await MainActor.run { Devices.scale(forDisplay: id) }
            displayID = id
            displayPoints = CGSize(width: d.width, height: d.height)
        case .area(let id, let r):
            guard let d = content.displays.first(where: { $0.displayID == id }) else {
                throw CaptureError(ErrorCode.notFound, "display \(id) not found")
            }
            let bounds = CGRect(x: 0, y: 0, width: d.width, height: d.height)
            let rect = CGRect(x: r.x, y: r.y, width: r.width, height: r.height).intersection(bounds)
            guard rect.width >= 16, rect.height >= 16 else {
                throw CaptureError(ErrorCode.badRequest, "area is outside display \(id)")
            }
            filter = SCContentFilter(display: d, excludingWindows: controls)
            sourceRect = rect
            points = rect.size
            global = CGRect(x: d.frame.origin.x + rect.origin.x, y: d.frame.origin.y + rect.origin.y,
                            width: rect.width, height: rect.height)
            scale = await MainActor.run { Devices.scale(forDisplay: id) }
            kind = "area"
            displayID = id
            displayPoints = CGSize(width: d.width, height: d.height)
        case .window(let id):
            guard let w = content.windows.first(where: { $0.windowID == id }) else {
                throw CaptureError(ErrorCode.notFound, "window \(id) not found (is it on screen?)")
            }
            guard !isRecordingControl(Self.identity(of: w), appPid: appPid) else {
                throw CaptureError(ErrorCode.badRequest, "the recording controls cannot be recorded")
            }
            filter = SCContentFilter(desktopIndependentWindow: w)
            points = w.frame.size
            global = w.frame
            scale = await MainActor.run { Devices.scale(forRect: w.frame) }
            kind = "window"
            windowID = id
            displayPoints = CGDisplayBounds(CGMainDisplayID()).size
        }

        // Retina capture, capped so the encoder keeps up.
        var pw = points.width * scale, ph = points.height * scale
        let cap = 3840.0 / max(pw, 1)
        if cap < 1 { pw *= cap; ph *= cap }
        let width = evenDimension(pw), height = evenDimension(ph)

        let cfg = SCStreamConfiguration()
        cfg.width = width
        cfg.height = height
        if let sourceRect { cfg.sourceRect = sourceRect }
        cfg.minimumFrameInterval = CMTime(value: 1, timescale: CMTimeScale(options.fps))
        cfg.pixelFormat = kCVPixelFormatType_32BGRA
        cfg.showsCursor = options.showsCursor
        cfg.queueDepth = 6
        if options.systemAudio {
            cfg.capturesAudio = true
            cfg.sampleRate = 48_000
            cfg.channelCount = 2
            cfg.excludesCurrentProcessAudio = true
        }
        return ScreenPlan(
            filter: filter, config: cfg, kind: kind, displayID: displayID, windowID: windowID,
            globalRect: CaptureRect(x: global.origin.x, y: global.origin.y, width: global.width, height: global.height),
            displayPoints: displayPoints,
            pixelWidth: width, pixelHeight: height, scale: scale)
    }

    // MARK: Sample intake (all on `queue`)

    private func ingest(_ sample: CMSampleBuffer, from source: Source) {
        guard !stopped, clock != nil, CMSampleBufferIsValid(sample), CMSampleBufferDataIsReady(sample) else { return }
        let pts = CMTimeGetSeconds(CMSampleBufferGetPresentationTimeStamp(sample))
        guard pts.isFinite else { return }
        var aligner = aligners[source] ?? ClockAligner()
        let host = aligner.hostTime(forPTS: pts, nowHost: hostSecondsNow())
        aligners[source] = aligner
        let first = origin.host == nil
        guard let t0 = origin.observe(host: host, primary: source == primarySource) else { return }
        if first { clock = SharedClock(t0: t0) }
        guard let media = clock.mediaTime(forHost: host), let retimed = retime(sample, toMediaTime: media) else { return }

        if source == .camera, writers[.camera] == nil {
            guard let pb = CMSampleBufferGetImageBuffer(retimed) else { return }
            let w = evenDimension(Double(CVPixelBufferGetWidth(pb)))
            let h = evenDimension(Double(CVPixelBufferGetHeight(pb)))
            writers[.camera] = TrackWriter(
                url: outURL.appendingPathComponent("camera.mp4"), kind: .video,
                video: .init(width: w, height: h, fps: 30, bitrate: videoBitrate(width: w, height: h, fps: 30)))
        }
        guard let writer = writers[source] else { return }
        writer.append(retimed)
        if source == primarySource, !primaryHasData {
            if writer.hasData {
                primaryHasData = true
                startupWaiter?.resume()
                startupWaiter = nil
            } else if writer.error == nil {
                // A backpressured first frame must not establish time zero.
                origin = CaptureOrigin()
            }
        }
        if let err = writer.error, !stopped {
            startupError = err
            startupWaiter?.resume(throwing: err)
            startupWaiter = nil
            stopped = true
            onFailure?("writing \(writer.url.lastPathComponent) failed: \(err.localizedDescription)")
        }
    }

    // SCStreamOutput
    func stream(_ stream: SCStream, didOutputSampleBuffer sampleBuffer: CMSampleBuffer, of type: SCStreamOutputType) {
        switch type {
        case .screen:
            // Only complete frames carry pixels; idle/blank/suspended ones don't.
            guard let list = CMSampleBufferGetSampleAttachmentsArray(sampleBuffer, createIfNecessary: false) as? [[SCStreamFrameInfo: Any]],
                  let raw = list.first?[.status] as? Int, SCFrameStatus(rawValue: raw) == .complete
            else { return }
            ingest(sampleBuffer, from: .screen)
        case .audio:
            ingest(sampleBuffer, from: .systemAudio)
        default:
            break
        }
    }

    // SCStreamDelegate
    func stream(_ stream: SCStream, didStopWithError error: Error) {
        queue.async { [weak self] in
            guard let self, !self.stopped else { return }
            self.onFailure?("screen capture stopped: \(error.localizedDescription)")
        }
    }

    // AVCapture delegates
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        if output === cameraOutput {
            ingest(sampleBuffer, from: .camera)
        } else if output === micOutput {
            ingest(sampleBuffer, from: .microphone)
        }
    }

    // MARK: Pause / resume

    func pause() {
        guard state == "recording" else { return }
        let now = hostSecondsNow()
        if let t = clock.mediaTime(forHost: now) { events.append(.pause(t: t)) }
        clock.pause(atHost: now)
        state = "paused"
    }

    func resume() {
        guard state == "paused" else { return }
        let now = hostSecondsNow()
        clock.resume(atHost: now)
        if let t = clock.mediaTime(forHost: now) { events.append(.resume(t: t)) }
        state = "recording"
    }

    var elapsed: Double { clock == nil ? 0 : clock.elapsed(atHost: hostSecondsNow()) }

    // MARK: Stop

    /// Finalization runs once. A second caller (an app Stop racing SIGTERM / stdin
    /// close, or a retried Stop) awaits the same result instead of stopping the
    /// stream and finishing the writers a second time. Called only from the
    /// serial `Controller` actor, so the check-and-assign needs no lock.
    private var stopTask: Task<JSONValue, Never>?

    func stop() async -> JSONValue {
        if let running = stopTask { return await running.value }
        let task = Task { await self.performStop() }
        stopTask = task
        return await task.value
    }

    private func performStop() async -> JSONValue {
        exclusionTask?.cancel()
        removeDeviceObservers()
        let endHost = hostSecondsNow()
        let duration = clock.elapsed(atHost: endHost)
        state = "finalizing"
        await MainActor.run { input?.stop() }
        try? await stream?.stopCapture()
        avSession?.stopRunning()

        // Drain the sample queue, then finalize every writer.
        let finished: [String: Bool] = await withCheckedContinuation { cont in
            queue.async {
                self.stopped = true
                self.events.append(.end(t: duration))
                self.events.close()
                let group = DispatchGroup()
                var results: [String: Bool] = [:]
                let lock = NSLock()
                for (_, w) in self.writers {
                    group.enter()
                    w.finish(endTime: duration) { ok in
                        lock.lock(); results[w.url.lastPathComponent] = ok && w.hasData; lock.unlock()
                        group.leave()
                    }
                }
                group.notify(queue: self.queue) { cont.resume(returning: results) }
            }
        }

        // Keep only tracks that actually hold data.
        var files: [String: JSONValue] = ["events": .string(outURL.appendingPathComponent("events.jsonl").path),
                                          "manifest": .string(manifestURL.path)]
        func keep(_ source: Source, _ name: String, _ key: String, _ setter: (String?) -> Void) {
            if finished[name] == true { files[key] = .string(outURL.appendingPathComponent(name).path) }
            else { setter(nil); try? FileManager.default.removeItem(at: outURL.appendingPathComponent(name)) }
        }
        keep(.screen, "screen.mp4", "screen") { manifest.tracks.screen = $0 }
        keep(.camera, "camera.mp4", "camera") { manifest.tracks.camera = $0 }
        keep(.microphone, "mic.m4a", "microphone") { manifest.tracks.microphone = $0 }
        keep(.systemAudio, "system.m4a", "systemAudio") { manifest.tracks.systemAudio = $0 }
        manifest.finished = true
        manifest.durationSec = duration
        try? manifest.write(to: manifestURL)
        state = "idle"
        return .obj(["files": .obj(files), "durationSec": .num(duration)])
    }
}
