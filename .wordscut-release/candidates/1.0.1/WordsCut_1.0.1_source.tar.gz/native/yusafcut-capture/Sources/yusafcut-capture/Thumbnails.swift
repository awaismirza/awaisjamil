import AppKit
import CaptureCore
import Foundation
import ScreenCaptureKit

/// Single-frame previews for the recorder's source picker. Never prompts: if
/// Screen Recording is not granted the caller shows a placeholder instead.
enum Thumbnails {
    static func capture(target: CaptureTarget, maxWidth: Int) async throws -> [String: JSONValue] {
        guard CGPreflightScreenCaptureAccess() else {
            throw CaptureError(ErrorCode.permissionDenied, "Screen Recording access is not granted.")
        }
        guard #available(macOS 14.0, *) else {
            throw CaptureError(ErrorCode.captureFailed, "Source thumbnails need macOS 14 or newer.")
        }
        let content = try await SCShareableContent.excludingDesktopWindows(false, onScreenWindowsOnly: true)
        let filter: SCContentFilter
        let size: CGSize
        switch target {
        case .display(let id):
            guard let d = content.displays.first(where: { $0.displayID == id }) else {
                throw CaptureError(ErrorCode.notFound, "display \(id) is not available")
            }
            filter = SCContentFilter(display: d, excludingWindows: [])
            size = CGSize(width: d.width, height: d.height)
        case .window(let id):
            guard let w = content.windows.first(where: { $0.windowID == id }) else {
                throw CaptureError(ErrorCode.notFound, "window \(id) is not available")
            }
            filter = SCContentFilter(desktopIndependentWindow: w)
            size = w.frame.size
        case .area:
            throw CaptureError(ErrorCode.badRequest, "thumbnails are for displays and windows")
        }
        let scale = min(1.0, Double(maxWidth) / max(1, Double(size.width)))
        let cfg = SCStreamConfiguration()
        cfg.width = max(2, Int((Double(size.width) * scale).rounded()))
        cfg.height = max(2, Int((Double(size.height) * scale).rounded()))
        cfg.showsCursor = false
        let image = try await SCScreenshotManager.captureImage(contentFilter: filter, configuration: cfg)
        let rep = NSBitmapImageRep(cgImage: image)
        guard let jpeg = rep.representation(using: .jpeg, properties: [.compressionFactor: 0.7]) else {
            throw CaptureError(ErrorCode.captureFailed, "could not encode the thumbnail")
        }
        return [
            "mime": .string("image/jpeg"),
            "data": .string(jpeg.base64EncodedString()),
            "width": .int(image.width), "height": .int(image.height),
        ]
    }
}
