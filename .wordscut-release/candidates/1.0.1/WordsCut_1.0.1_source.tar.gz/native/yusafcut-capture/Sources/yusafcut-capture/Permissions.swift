import AVFoundation
import CaptureCore
import CoreGraphics
import Foundation

/// Permission state as reported to the app: "granted", "denied",
/// "notDetermined" or "restricted". Screen recording and input monitoring only
/// expose a yes/no preflight, so "denied" there means "asked in this process and
/// refused"; before that it reads "notDetermined".
enum Permissions {
    private static var screenAsked = false
    private static var inputAsked = false

    static func state(_ kind: PermissionKind) -> String {
        switch kind {
        case .screenRecording:
            return CGPreflightScreenCaptureAccess() ? "granted" : (screenAsked ? "denied" : "notDetermined")
        case .inputMonitoring:
            return CGPreflightListenEventAccess() ? "granted" : (inputAsked ? "denied" : "notDetermined")
        case .camera: return avState(.video)
        case .microphone: return avState(.audio)
        }
    }

    private static func avState(_ type: AVMediaType) -> String {
        switch AVCaptureDevice.authorizationStatus(for: type) {
        case .authorized: return "granted"
        case .denied: return "denied"
        case .restricted: return "restricted"
        case .notDetermined: return "notDetermined"
        @unknown default: return "notDetermined"
        }
    }

    static func all() -> JSONValue {
        var o: [String: JSONValue] = [:]
        for k in PermissionKind.allCases { o[k.rawValue] = .string(state(k)) }
        return .object(o)
    }

    /// Shows the system prompt where the OS allows one, and returns the new state.
    @discardableResult
    static func request(_ kind: PermissionKind) async -> String {
        switch kind {
        case .screenRecording:
            if !CGPreflightScreenCaptureAccess() {
                screenAsked = true
                _ = CGRequestScreenCaptureAccess()
            }
        case .inputMonitoring:
            if !CGPreflightListenEventAccess() {
                inputAsked = true
                _ = CGRequestListenEventAccess()
            }
        case .camera:
            if AVCaptureDevice.authorizationStatus(for: .video) == .notDetermined {
                _ = await AVCaptureDevice.requestAccess(for: .video)
            }
        case .microphone:
            if AVCaptureDevice.authorizationStatus(for: .audio) == .notDetermined {
                _ = await AVCaptureDevice.requestAccess(for: .audio)
            }
        }
        return state(kind)
    }

    /// Camera / microphone must be granted before a take can use them.
    static func requireAV(_ kind: PermissionKind) async throws {
        let s = await request(kind)
        guard s == "granted" else {
            let what = kind == .camera ? "Camera" : "Microphone"
            throw CaptureError(ErrorCode.permissionDenied,
                               "\(what) access is \(s). Allow it in System Settings → Privacy & Security → \(what).")
        }
    }

    static func requireScreen() throws {
        if !CGPreflightScreenCaptureAccess() {
            screenAsked = true
            _ = CGRequestScreenCaptureAccess()
        }
        guard CGPreflightScreenCaptureAccess() else {
            throw CaptureError(ErrorCode.permissionDenied,
                               "Screen Recording access is not granted. Allow it in System Settings → Privacy & Security → Screen & System Audio Recording, then relaunch WordsCut.")
        }
    }
}
