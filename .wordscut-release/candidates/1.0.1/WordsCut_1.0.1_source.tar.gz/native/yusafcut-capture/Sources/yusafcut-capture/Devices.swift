import AppKit
import AVFoundation
import CaptureCore
import Foundation
import ScreenCaptureKit

enum Devices {
    static func displayID(of screen: NSScreen) -> UInt32? {
        (screen.deviceDescription[NSDeviceDescriptionKey("NSScreenNumber")] as? NSNumber)?.uint32Value
    }

    @MainActor
    static func scale(forDisplay id: UInt32) -> Double {
        Double(NSScreen.screens.first { displayID(of: $0) == id }?.backingScaleFactor
            ?? NSScreen.main?.backingScaleFactor ?? 2)
    }

    @MainActor
    static func scale(forRect rect: CGRect) -> Double {
        // Quartz (top-left) → pick the screen whose frame contains the rect's centre.
        let primaryH = NSScreen.screens.first?.frame.height ?? 0
        let center = CGPoint(x: rect.midX, y: primaryH - rect.midY)
        return Double(NSScreen.screens.first { $0.frame.contains(center) }?.backingScaleFactor
            ?? NSScreen.main?.backingScaleFactor ?? 2)
    }

    private static func rectJSON(_ r: CGRect) -> JSONValue {
        .obj(["x": .num(r.origin.x), "y": .num(r.origin.y),
              "width": .num(r.size.width), "height": .num(r.size.height)])
    }

    static func cameras() -> [AVCaptureDevice] {
        var types: [AVCaptureDevice.DeviceType] = [.builtInWideAngleCamera]
        if #available(macOS 14.0, *) {
            types += [.external, .continuityCamera]
        } else {
            types += [.externalUnknown]
        }
        return AVCaptureDevice.DiscoverySession(deviceTypes: types, mediaType: .video, position: .unspecified).devices
    }

    static func microphones() -> [AVCaptureDevice] {
        var types: [AVCaptureDevice.DeviceType] = [.builtInMicrophone]
        if #available(macOS 14.0, *) {
            types += [.microphone, .external]
        } else {
            types += [.externalUnknown]
        }
        return AVCaptureDevice.DiscoverySession(deviceTypes: types, mediaType: .audio, position: .unspecified).devices
    }

    static func list() async -> JSONValue {
        let displays: [JSONValue] = await MainActor.run {
            var displays: [JSONValue] = []
            let mainID = CGMainDisplayID()
            for s in NSScreen.screens {
                guard let id = displayID(of: s) else { continue }
                let b = CGDisplayBounds(CGDirectDisplayID(id))
                displays.append(.obj([
                    "id": .num(id), "name": .string(s.localizedName),
                    "frame": rectJSON(b),
                    "width": .num(b.width), "height": .num(b.height),
                    "scale": .num(s.backingScaleFactor), "isMain": .bool(id == mainID),
                ]))
            }
            return displays
        }

        var windows: [JSONValue] = []
        var windowsError: JSONValue = .null
        do {
            let content = try await SCShareableContent.excludingDesktopWindows(false, onScreenWindowsOnly: true)
            for w in content.windows {
                guard w.windowLayer == 0, w.isOnScreen, let app = w.owningApplication,
                      w.frame.width >= 120, w.frame.height >= 80 else { continue }
                let title = w.title ?? ""
                // The recording controls are never a capture target.
                if isRecordingControl(RecordingSession.identity(of: w), appPid: getppid()) { continue }
                windows.append(.obj([
                    "id": .num(w.windowID), "title": .string(title),
                    "app": .string(app.applicationName), "bundleId": .string(app.bundleIdentifier),
                    "frame": rectJSON(w.frame),
                ]))
            }
        } catch {
            windowsError = .string("\(error.localizedDescription)")
        }

        let cams = cameras().map { d -> JSONValue in
            .obj(["id": .string(d.uniqueID), "name": .string(d.localizedName)])
        }
        let defaultMic = AVCaptureDevice.default(for: .audio)?.uniqueID
        let mics = microphones().map { d -> JSONValue in
            .obj(["id": .string(d.uniqueID), "name": .string(d.localizedName),
                  "isDefault": .bool(d.uniqueID == defaultMic)])
        }
        return .obj([
            "displays": .array(displays), "windows": .array(windows),
            "windowsError": windowsError,
            "cameras": .array(cams), "microphones": .array(mics),
        ])
    }
}
