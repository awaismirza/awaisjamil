import AppKit
import CaptureCore
import Foundation

// yusafcut-capture — native capture helper. JSON lines on stdin/stdout.
// See native/yusafcut-capture/README.md for the protocol.

setvbuf(stdout, nil, _IOLBF, 0)
let app = NSApplication.shared
app.setActivationPolicy(.prohibited)

let controller = Controller()
let helperVersion = "1.0.0"

func finishAndExit(_ code: Int32) {
    Task {
        await controller.shutdown()
        exit(code)
    }
}

var signalSources: [DispatchSourceSignal] = []
for sig in [SIGTERM, SIGINT, SIGHUP] {
    signal(sig, SIG_IGN)
    let src = DispatchSource.makeSignalSource(signal: sig, queue: .main)
    src.setEventHandler { finishAndExit(0) }
    src.resume()
    signalSources.append(src)
}

// Commands run strictly in order (pause → stop must not race).
let (lines, continuation) = AsyncStream<String>.makeStream()
Thread.detachNewThread {
    while let line = readLine() { continuation.yield(line) }
    continuation.finish()
}
Task {
    Out.send(eventMessage("ready", ["version": .string(helperVersion), "pid": .num(Int(getpid()))]))
    for await line in lines { await controller.handle(line) }
    // Parent closed our stdin: finalize the take and leave.
    await controller.shutdown()
    exit(0)
}

app.run()
