import CaptureCore
import Foundation

/// stdout carries protocol lines only; diagnostics go to stderr.
enum Out {
    private static let lock = NSLock()

    static func send(_ value: JSONValue) {
        lock.lock(); defer { lock.unlock() }
        FileHandle.standardOutput.write(Data((value.line() + "\n").utf8))
    }

    static func log(_ message: String) {
        FileHandle.standardError.write(Data(("[yusafcut-capture] " + message + "\n").utf8))
    }
}

struct CaptureError: Error {
    let code: String
    let message: String
    init(_ code: String, _ message: String) { self.code = code; self.message = message }
}

extension JSONValue {
    static func obj(_ d: [String: JSONValue]) -> JSONValue { .object(d) }
    static func num(_ v: Double) -> JSONValue { .number(v) }
    static func num(_ v: UInt32) -> JSONValue { .number(Double(v)) }
    static func num(_ v: Int) -> JSONValue { .number(Double(v)) }
}
