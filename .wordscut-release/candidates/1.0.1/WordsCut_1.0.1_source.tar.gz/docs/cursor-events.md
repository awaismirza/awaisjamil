# Cursor events contract (`events.jsonl`)

The shared format between **the native capture helper** (producer, see
`docs/HANDOFF.md` §4.1) and **auto zoom / cursor styling** (consumer, §4.5).
Both sides build against this file so they can be developed in parallel; the
consumer can use synthetic logs until the helper ships. Change it only by
editing this file and telling the other side.

Version 1. One UTF-8 JSON object per line, written next to the screen track of a
take (`<take>/events.jsonl`). Writers flush each line, so a crashed take still has
a usable log. Readers must be **tolerant**: skip blank or malformed lines, ignore
unknown `type`s and unknown fields, and sort by `t` before use.

## Header (first line)

```json
{"type":"header","version":1,"startedAtUnix":1760000000.123,
 "display":{"width":2560,"height":1600,"scale":2},
 "captured":{"x":0,"y":0,"width":2560,"height":1600},
 "target":"display"}
```

- `display`: the captured display in **pixels** (`scale` = backing scale factor).
- `captured`: the captured rectangle in the same pixels (equal to `display` for a
  full-screen capture; the window or area for window/area capture).
- `target`: `"display"`, `"window"` or `"area"`.

## Events

All coordinates are **normalised to the captured rectangle**: `x` and `y` in
0..1, origin **top-left**, y down. A cursor outside the rectangle is clamped and
marked `"outside":true`.

`t` is **seconds of recording time** on the same clock as the take's video track:
0 at the first video frame, and **pauses are excluded** (a paused interval
advances nothing), so `t` equals the source time of the media file the take
produces. `t` is non-decreasing.

| `type` | Fields | Notes |
|---|---|---|
| `move` | `t`, `x`, `y` | Only when the position changed. 30 to 60 per second is plenty; a producer may thin it. |
| `down` | `t`, `x`, `y`, `button` | `button` is `"left"`, `"right"` or `"other"`. |
| `up` | `t`, `x`, `y`, `button` | |
| `key` | `t`, optional `mods`, `name`, `secure` | A key-down. `mods` may list `"cmd"`, `"ctrl"`, `"alt"`, `"shift"`. `name` and `secure` exist only when the user opted in to key identity at record time (see below); otherwise a `key` carries timing and modifiers only. |
| `scroll` | `t`, `dx`, `dy` | Scroll deltas in points. |
| `cursorshape` | `t`, `shape` | Optional. `"arrow"`, `"ibeam"`, `"pointer"`, `"crosshair"`, `"resize"`, `"other"`. |

Example:

```
{"type":"header","version":1,"startedAtUnix":1760000000.1,"display":{"width":2560,"height":1600,"scale":2},"captured":{"x":0,"y":0,"width":2560,"height":1600},"target":"display"}
{"type":"move","t":0.016,"x":0.412,"y":0.301}
{"type":"move","t":0.033,"x":0.415,"y":0.304}
{"type":"down","t":0.9,"x":0.52,"y":0.33,"button":"left"}
{"type":"up","t":0.98,"x":0.52,"y":0.33,"button":"left"}
{"type":"key","t":2.4,"mods":["cmd"]}
{"type":"key","t":3.1,"mods":["cmd","shift"],"name":"z"}
{"type":"key","t":3.6,"name":"return"}
{"type":"key","t":4.0,"secure":true}
```

### Key identity (optional, opt-in, backward compatible)

Added without a version bump: readers already ignore unknown fields, and old logs
have neither field.

- `name` (string, 1 to 16 characters, no control characters): the key. Lower case
  for characters (`"k"`); otherwise one of `return`, `tab`, `space`, `delete`,
  `forwarddelete` (typing-flow keys), `esc`, `left`, `right`, `up`, `down`, `home`, `end`, `pageup`,
  `pagedown`, `f1` to `f20`. Readers show an unknown or invalid name as a generic
  "key".
- `secure` (`true` only): macOS secure event input was on (password fields). No
  `name` is recorded on such an event.

Privacy rules, enforced by the helper (`keyDescriptor`, unit tested):

1. Both are written only when the recorder option "Record key names"
   (`recordKeyIdentity`, default off) is on. Off: events are exactly as in older logs.
2. `name` is written for shortcuts (⌘ or ⌃ held: any key, shown as the unshifted key on
   the ASCII-capable layout via `UCKeyTranslate`, so a Cyrillic layout still gives the
   Latin shortcut letter and Shift never turns `3` into `#`) and for `esc`, `insert`,
   `clear`, arrows, `home`, `end`, `pageup`, `pagedown` and `f1` to `f20` (also with
   ⌥). **Option alone is not a shortcut for printable keys** (it types characters on
   DE, PL and FR layouts); Option+Return/Tab/Space/Delete is named.
3. Typing-flow keys (`return`, `tab`, `space`, `delete`, `forwarddelete`) without a
   modifier, and ordinary characters (including Option-only and Shift-only ones), have
   **no** `name` unless the second option "Also record all characters"
   (`recordAllCharacters`, default off, never persisted by the app, ignored without the
   first) is on. Private-use characters (U+F700 to U+F8FF, AppKit's arrow/function
   key characters) are never names.
4. With secure input active: no `name`, `secure:true`, regardless of options 2 and 3.
   macOS normally does not deliver key presses to monitors at all while secure input is
   on, so such presses are usually simply **absent**, not flagged.
5. Window capture: a name is recorded only while the captured window's owning app is
   frontmost (otherwise the press is logged without `name` or `secure`). Screen and area
   capture have no single owner: keys typed in **any app** are captured.
6. Key identities are never written to stdout, stderr, `os_log` or ffmpeg logs.
   `events.jsonl` is created with mode 0600.
7. Input Monitoring must be allowed; the recorder refuses to start with key names on
   while it is denied.

Not protected: macOS secure input is per focused field and many apps do not use it:
Terminal and iTerm `sudo` / `ssh` prompts (unless Secure Keyboard Entry is on) and many
Electron or web password fields. With "all characters" the log spells out what was
typed. "Strip key names" in the Overlays panel removes `name` / `secure` from the
project's tracks and snapshots; the take folder's raw `events.jsonl` is not changed.

## How the app is expected to use it

- A recording's result gains an `eventsPath` (set by the capture helper path);
  the project keeps a processed copy (or a path inside the `.scribe` bundle)
  keyed by media id, so editing and re-opening never need the raw file.
- Event time is the **source time of that media**, so mapping to the output
  timeline goes through the EDL like everything else (`sourceTimeToOutput`,
  `retimeZoomRegions`).
- Privacy: key identities only when opted in (see above), no window titles, nothing leaves the Mac.
- The keystroke overlay reads `key` events. Without `name` it shows the held
  modifiers ("⌘ key"); with it, real caps ("⌘ K", "↑"); `secure` events show
  "Typing (hidden)" in "All key presses" mode (not reliable: secure presses are
  usually absent). Logs from before 4.45.0 and logs recorded with key names off have
  no secure-input marker.

## Not in scope of version 1

Per-frame cursor image, multi-display layouts, hover state, drag paths beyond
`move`, and modifier-only presses. Add them with a version bump.
