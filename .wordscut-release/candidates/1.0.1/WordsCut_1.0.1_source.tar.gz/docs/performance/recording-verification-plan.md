# Recording verification plan (computer-use / manual)

Goal: prove the record -> stop -> edit -> export path on the real app with real capture, including
Stop-to-editor timing. The synthetic harness (`npm run bench:recording`) does not replace this.

## Preconditions and what is blocked by permissions

| Need | Who can do it | If missing |
|---|---|---|
| Real `yusafcut-capture` helper built (`npm run native:build`) | agent | Stub falls back to ffmpeg capture: a different path, do not report as native |
| Screen Recording permission for the app | **human only** (System Settings, then app restart) | Screen modes blocked |
| Camera permission | **human only** | Screen+camera blocked |
| Microphone permission | **human only** | Mic and screen+mic blocked |
| System audio (ScreenCaptureKit) | covered by Screen Recording | System audio track missing |
| Announced capture: the camera light and the screen are captured | human must be told and agree before each run | Do not record unannounced |
| Desktop control (computer-use) to click Record/Stop | granted per session | Fall back to the global shortcuts or a human driving |

An agent must not click through OS permission prompts for these. Anything blocked is reported as
"not verified", never as passed.

Set up a deterministic source so audio sync and mask coverage can be checked afterwards: play a
reference clip with a visible frame counter / timecode and a periodic beep or click track (for
example `ffmpeg -f lavfi -i "testsrc2=size=1280x720:rate=30,drawtext=text='%{pts\:hms}'"` with a 1 s
beep via `sine`), full-screen on the captured display. For mask coverage, add a privacy mask over a
known region and a distinctive pattern underneath.

## Matrix

Each row: record the stated length, Stop, then run the Common flow below. Run with
`YUSAFCUT_PERF_SPANS=1` and read spans per `scripts/bench/recording/read-spans.md`.

| ID | Mode | Tracks | Lengths |
|---|---|---|---|
| R1 | Screen only | screen (+ system audio if enabled) | 15 s, 60 s, 180 s |
| R2 | Screen + camera + mic + system audio | all four | 15 s, 60 s, 180 s |
| R3 | Mic only (voice-over) | mic | 15 s, 60 s |

3 takes per cell for timing medians (R2 at 180 s may be 1 take for functional checks, 3 for timing).

## Common flow

1. Record, Stop. Note wall-clock time of the Stop click.
2. Immediately press play as soon as the clip appears. Note time to first frame and whether audio is
   present at once.
3. Scrub: drag across the timeline end to end, then click mid-clip; confirm the frame follows and
   there are no stalls over 500 ms.
4. Cut: delete a word range in the middle (and one at the head), play across the join.
5. Export (default preset). Wait for completion.
6. Inspect the output (commands below).
7. Capture the span and timeline numbers.

## Inspection commands

```bash
OUT=/path/to/export.mp4
ffprobe -v error -show_entries format=duration:stream=index,codec_type,codec_name,width,height,r_frame_rate,start_time,duration -of json "$OUT"
# Frame at known times (counter overlay in the source gives ground truth)
ffmpeg -y -ss 5  -i "$OUT" -frames:v 1 /tmp/f5.png
ffmpeg -y -ss 30 -i "$OUT" -frames:v 1 /tmp/f30.png
# Audio sync: locate beeps and compare with the frame counter at the same instants
ffmpeg -i "$OUT" -af silencedetect=noise=-30dB:d=0.05 -f null - 2>&1 | grep silence_
# Per-stream duration difference
ffprobe -v error -select_streams v:0 -show_entries stream=duration -of csv=p=0 "$OUT"
ffprobe -v error -select_streams a:0 -show_entries stream=duration -of csv=p=0 "$OUT"
# Mask coverage: extract a frame inside the masked window and check the region is solid/blurred
ffmpeg -y -ss <t> -i "$OUT" -vf "crop=<w>:<h>:<x>:<y>" -frames:v 1 /tmp/mask.png
```

For beep vs frame-counter sync, read the counter value in the frame at each beep time from
`silencedetect`; the delta must be under the criterion below.

## Pass / fail criteria

| Check | Pass | Fail |
|---|---|---|
| Recording completes, editor shows clip | Always | Any error dialog, empty clip, or missing track |
| Stop-to-inserted (A), screen only (R1) | Report value; target under 2 s for any length (stream copy) | Grows with length beyond hash/probe cost |
| Stop-to-inserted (A), screen+camera (R2) | Report value; **target under 3 s regardless of length** once slice 1 lands. Before slice 1 the baseline is expected to scale ~0.26 s per recorded second | Under slice 1, scales with length |
| Time to first frame (B) | Under 1 s after inserted | Black frame or over 2 s |
| Immediate play | Plays with audio, no stall over 500 ms in the first 10 s | Silent, frozen, or A/V drift visible |
| Scrub | Frame updates within 250 ms of release; no black frames | Stuck frame or blank video |
| Cut | Join plays without a visible jump or audio pop; duration reduced by the cut amount within 1 frame | Wrong range removed, drift after the cut |
| Export | Succeeds; ffprobe duration within 1 frame (33 ms) of the expected EDL duration | Failure or mismatched duration |
| Audio sync | Beep-to-frame offset at start, middle and end each within 40 ms and not drifting by more than 40 ms from start to end | Offset over 80 ms or growing |
| Stream durations | Video and audio duration differ by under 50 ms | Larger gap |
| Mask coverage (when a mask is used) | Masked region fully covered in every frame of the masked window; none outside | Visible source pixels inside the region, or mask outside its window |
| Camera PiP (R2) | Bubble in the configured corner, margin about 28 px at the screen's width, not clipped | Missing, mirrored incorrectly, or half size |
| Mic-only (R3) | Audio-only media imports, plays, exports; levels not clipped | Silent or failed import |

## Report template

Per cell: build type, hardware, macOS, ffmpeg, take length, A, B, each span in ms, pass/fail per row
of the table, links to extracted frames, and every check that was blocked and why. Compare A and the
finalize span against `docs/benchmarks/recording-stop-*.json` for the same length.
