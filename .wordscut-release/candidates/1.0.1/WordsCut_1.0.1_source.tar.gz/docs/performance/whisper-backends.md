# Whisper backends: capability and accuracy evidence (WP-2B)

Scope: scripts and docs only. Measured on one M1 Pro (10 cores: 8 performance, 2 efficiency; 32 GB), macOS Darwin 27.0.0, bundled `src-tauri/binaries/whisper-cli-aarch64-apple-darwin`, model `ggml-large-v3-turbo.bin` (the only ggml model present locally; `tiny` was not on disk and nothing was downloaded). Raw data: [`../benchmarks/whisper-2026-10-20.json`](../benchmarks/whisper-2026-10-20.json) (40 s fixture, full matrix) and [`../benchmarks/whisper-2026-10-20-short12s.json`](../benchmarks/whisper-2026-10-20-short12s.json) (12 s fixture, production config only). Tools: `scripts/bench/whisper-matrix.mjs`, `scripts/bench/compare-words.mjs`.

## 1. Can this binary run without the Core ML encoder? No.

Test: symlink only `ggml-large-v3-turbo.bin` into an empty directory (no `ggml-large-v3-turbo-encoder.mlmodelc`), run the exact app flags (`-l en -sow -ml 0 -bo 5 -bs 5 -wt 0.01 --dtw large.v3.turbo`), with and without `-ng`.

Result: both runs exit **3** at context init, nothing transcribed. Stderr markers, in order:

```
whisper_init_with_params_no_state: use gpu    = 1        (0 with -ng)
whisper_backend_init_gpu: using Metal backend             (absent with -ng)
whisper_backend_init: using BLAS backend
whisper_init_state: loading Core ML model from '<dir>/ggml-large-v3-turbo-encoder.mlmodelc'
whisper_init_state: failed to load Core ML model from '<dir>/ggml-large-v3-turbo-encoder.mlmodelc'
error: failed to initialize whisper context
```

Consequences:
- The binary was built without `WHISPER_COREML_ALLOW_FALLBACK`. The roadmap finding A1 is confirmed: the app's "CPU fallback" when the encoder is missing cannot work with this binary; it fails rather than degrading.
- `-ng` does not mean CPU-only. With the encoder present, `-ng` still logs "Core ML model loaded" and only moves the decoder to CPU (section 2).
- A backend ladder Core ML+Metal -> Metal-only -> CPU is not possible with the shipped binary. Metal-only and CPU rows in the matrix are recorded as `blocked` with these markers (`probes` in the JSON).

### Pinned rebuild recipe (NOT executed)

`scripts/setup.sh` and `scripts/build-production.sh` build whisper.cpp `v1.7.5` with `-DWHISPER_METAL=ON -DWHISPER_COREML=ON`. The provenance of the committed binary is not proven (the version string is not embedded), so record the real commit when rebuilding. Recipe, to add to a pinned script like `build-arm64-media.sh` only after review:

```bash
set -euo pipefail
REF=v1.7.5                      # confirm this matches what produced the shipped binary
git clone --depth 1 --branch "$REF" https://github.com/ggerganov/whisper.cpp wc && cd wc
git rev-parse HEAD              # record the SHA in the build log / sidecar README
grep -rn "COREML_ALLOW_FALLBACK" CMakeLists.txt src/CMakeLists.txt   # verify the option exists at this ref
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DBUILD_SHARED_LIBS=OFF -DGGML_STATIC=ON \
  -DWHISPER_METAL=ON -DWHISPER_COREML=ON -DWHISPER_COREML_ALLOW_FALLBACK=ON -DWHISPER_BUILD_TESTS=OFF
cmake --build build --target whisper-cli -j"$(sysctl -n hw.logicalcpu)"
```

That the option name exists and makes a missing encoder non-fatal is from upstream's CMake as I know it; it is unverified here (no network use, no rebuild). Acceptance test after any rebuild: rerun `node scripts/bench/whisper-matrix.mjs --backends metal-only,cpu --fa off --threads 4`; `probes[*].status` must become `ok` (exit 0) with a "Metal backend" marker and no "Core ML model loaded" marker. Until then the app must treat a missing encoder as "prepare/download the encoder", not as a fallback.

## 2. Matrix results (large-v3-turbo, 40 s fixture, 3 reps)

Fixture: macOS `say` default voice, 8 sentences repeated, 16 kHz mono, 40.0 s. Warm = median of reps 2-3 (n=2); cold-approx = rep 1. Warm "total" is whisper's own `total time`. RSS = `/usr/bin/time -l` maximum resident set size.

| Backend | Threads | -fa | warm total (ms) | encode | decode work* | load | RTF (warm) | DTW active |
|---|---|---|---|---|---|---|---|---|
| Core ML + Metal | 4 | off | 7805 | 4562 | 1078 | 719 | 5.1x | yes |
| Core ML + Metal | 4 | on | 9262 | 5285 | 1021 | 1062 | 4.3x | no |
| Core ML + Metal | 8 | off | 8702 | 4693 | 1229 | 971 | 4.6x | yes |
| Core ML + Metal | 8 | on | 6119 | 3366 | 938 | 726 | 6.5x | no |
| Core ML + CPU decoder (`-ng`) | 4 | off | 11207 | 3561 | 5539 | 661 | 3.6x | yes |
| Core ML + CPU decoder | 4 | on | 10358 | 3539 | 5178 | 611 | 3.9x | no |
| Core ML + CPU decoder | 8 | off | 15627 | 3142 | 10994 | 530 | 2.6x | yes |
| Core ML + CPU decoder | 8 | on | 21718 | 3973 | 15913 | 712 | 1.8x | no |
| Metal-only, CPU | any | any | blocked: exit 3 at init (section 1) | | | | | |

*decode work = `decode + batchd + prompt` times (beam search reports decode time as 0).

Peak RSS is 4.27-4.30 GB for every runnable config; `peak memory footprint` 2.2-2.6 GB. 12 s fixture, production config: warm total 3371 ms (encode 1957, load 611, decode work 278), RSS 4.30 GB.

What is and is not supported by the data:
- **Variance is large.** Rep totals for one config span 5.5-10.1 s (4 threads, fa off) and 8.2-12.3 s (CPU decoder, 4 threads, fa off). With 2 warm reps per config, differences under roughly 30-40% are not distinguishable. No attempt was made to control thermals (`pmset` reported no throttle notes) or background load.
- **`-ng` is clearly worse** (decoder on CPU: 3-14x slower decode work) and does not remove Core ML. It is not a CPU fallback.
- **8 threads vs 4 did not help** on the Metal path in a way that exceeds the noise (7.8 s vs 8.7 s with fa off, 9.3 s vs 6.1 s with fa on, opposite directions). With a CPU decoder, 8 threads was slower. No evidence to change the default `-t 4` on this run.
- **`-fa` disables DTW.** stderr: `dtw_token_timestamps is not supported with flash_attn - disabling`; `dtw = 0`; every `t_dtw` is -1. The app relies on DTW word timings, so `-fa` is incompatible with the current accuracy path regardless of speed. Not a candidate.
- **Cold-approx** (rep 1) was not reliably slower than warm here: the OS file cache and Core ML compile cache were already warm from earlier runs. The ~10 s first-ever ANE compile (roadmap A3) is a system cache effect that this harness cannot reproduce without `sudo purge`/reboot or a never-used model; that needs [O].

## 3. Word-timing agreement across backends

`compare-words.mjs` rebuilds words from `-ojf` tokens, aligns them by LCS on normalised text, and compares DTW start (`t_dtw` x 10 ms) when both sides have it, token offsets otherwise (never mixed in one pair; `startBasis` in the JSON states which). Baseline = Core ML + Metal, 4 threads, fa off.

- All 7 other runnable configs produced the same 117 words with **start p50 = p95 = max = 0 ms** and end deltas 0 ms. Within the runnable set (encoder always Core ML) the output is deterministic for this fixture across threads, `-ng`, and `-fa` (the `-fa` rows compare offsets, not DTW, since DTW is off).
- The acceptance bar "p95 <= 20 ms across backends" is therefore **met trivially for the runnable set and untested for what matters**: the bar was meant to compare a non-Core-ML encoder (Metal-only/CPU), which this binary cannot run. It needs the rebuilt binary above, then rerun the matrix.
- In a single-token check, a DTW start (`t_dtw`) differs from the token offset start by hundreds of ms for some words, so DTW and non-DTW timings are different quantities. Do not diff across them, and any backend that disables DTW needs its own accuracy bar.
- Synthetic TTS has clean articulation and no overlap/noise, so agreement on real speech is expected to be worse. `tiny` was not run (model absent).

## 4. Verdict: persistent model reuse

Measured fixed per-job cost a resident model could remove: model load (warm) 611 ms on the 12 s clip (18% of 3.37 s total) and 719 ms on the 40 s clip (9% of 7.8 s). Core ML encoder load is inside that figure ("Core ML model loaded" is logged during init). Cost: RSS 4.30 GB (footprint 2.2 GB), held for the life of the app, on a 32 GB machine; the roadmap flags 8 GB machines as the problem case.

Decision: **do not implement persistent reuse by default.** The saving is ~0.6-1.0 s per job against 2.2-4.3 GB residency, and the dominant per-job costs (encode ~2 s per 30 s window, plus the one-off ANE compile) are not removed by residency. The compile is cached by the OS across process launches. Revisit only with an opt-in "keep model warm" for interactive short re-transcribes, and only after an [O] run shows many consecutive short jobs on a low-RAM machine. This matches the prompt's default (documented, not implemented).

## 5. Reproduce

Agent-run (no downloads; skips absent models; scratch dir is a temp dir unless `--scratch`):

```bash
node scripts/bench/whisper-matrix.mjs                        # full matrix, 40 s say fixture
node scripts/bench/whisper-matrix.mjs --fixture-seconds 12 --fa off --threads 4 --backends coreml-metal --out docs/benchmarks/whisper-<date>-short12s.json
node scripts/bench/whisper-matrix.mjs --dry-run              # show which models/configs would run
node scripts/bench/compare-words.mjs a.json b.json           # two whisper-cli -ojf outputs
```

Owner-run [O] (long clips, thermals, true cold, low-RAM, real speech). Convert the clip first: `src-tauri/binaries/ffmpeg-aarch64-apple-darwin -i clip.mov -ar 16000 -ac 1 -c:a pcm_s16le clip.wav`.

```bash
# [O] real speech, 10+ min, sustained thermal behaviour (10 reps; compare rep 1 vs rep 10)
node scripts/bench/whisper-matrix.mjs --fixture ~/clips/clip.wav --models large-v3-turbo --backends coreml-metal --fa off --threads 4 --reps 10 --out docs/benchmarks/whisper-long-<date>.json
# [O] true cold: after a reboot, or `sudo purge`, run once with --reps 1 and a model never used before
node scripts/bench/whisper-matrix.mjs --fixture ~/clips/clip.wav --models large-v3-turbo --backends coreml-metal --fa off --threads 4 --reps 1
# [O] tiny (download in the app first), then the same matrix
node scripts/bench/whisper-matrix.mjs --models tiny,large-v3-turbo
# [O] after a rebuild with ALLOW_FALLBACK (section 1): Metal-only/CPU probe + word-timing bar
node scripts/bench/whisper-matrix.mjs --backends coreml-metal,metal-only,cpu --fa off --threads 4,perf
```
