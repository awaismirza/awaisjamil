# Recording-to-editor path: measurement and native-engine ledger

Started 2026-10-21 on `main` v4.48.0 (`aade47c`). Branch `feature/recording-to-editor-timing` (v4.48.1).
Hardware for the numbers below: Apple M1 Pro, macOS 27.0.1, bundled ffmpeg 7.1.1, debug Rust build for
instrumentation, **synthetic** media (see caveats).

## Stage map (current code, verified by reading)

| # | Stage | Where | Blocks Stop-to-editor? |
|---|---|---|---|
| 1 | Stop requested | `recordingStore.stop` -> `stop_recording` | - |
| 2 | Helper stop / writers drained | `stop_native` (`record.stop_native.helper_stop`) | yes |
| 3 | **Finalize: audio mix + (camera composite)** | `native_capture::finalize_args`, one ffmpeg run | **yes** |
| 4 | Duration probe | `captured_duration` (`record.stop_native.probe`) | yes |
| 5 | `record:finished` -> import | `importFinishedRecording` | yes |
| 6 | ffprobe **and full-file SHA-256**, joined | `import_media` (`import.ffprobe`, `import.sha256`) | yes (waits for the slower) |
| 7 | Project insertion | `addMediaWithTranscript` | yes |
| 8 | First presented frame / playable | `<video>` rVFC (`firstFrame`) | - |
| 9 | Waveform, cursor log, transcription, proxy | background | no (already deferred) |

Key finding from the code: with **screen + camera**, stage 3 re-encodes the *entire take* with
`h264_videotoolbox` (picture-in-picture overlay). Screen-only stream-copies video and only re-encodes
the mixed audio.

## Synthetic stage costs (NOT production proof)

2560x1440@30 H.264 screen track, 1280x720 camera track, two AAC tracks, generated with `testsrc2`
(harder to scale than real screen content). Production argv shape from `finalize_args`. Single run each,
nothing else running.

| Take | SHA-256 of screen track | Copy video + mix audio | Camera composite (re-encode) |
|---|---|---|---|
| 30 s (44 MB) | 0.17 s | 0.89 s | 7.88 s |
| 120 s (177 MB) | 0.57 s | 3.45 s | 30.74 s |

Reading: the composite runs at roughly 0.26x realtime-length cost, i.e. **linear in take length**
(about 1 s of waiting per 4 s recorded). Hashing and copy+mix are small by comparison but also linear.
So for screen+camera takes the dominant Stop-to-editor cost is very likely the camera flattening, not
rendering, probing or hashing. This must be confirmed on real captured takes before the design is
committed to (next step below).

## Instrumentation added (v4.48.1)

- Rust spans (`YUSAFCUT_PERF_SPANS=1`): `record.stop.command`, `record.stop_native.total`,
  `.helper_stop`, `.finalize_composite` | `.finalize_copy_mix`, `.probe`, `import.total`, `import.ffprobe`,
  `import.sha256`. Read with the new `perf_spans_snapshot` command (`perfSpansSnapshot()` in `ipc.ts`).
- Frontend: `src/lib/recordingTimeline.ts` marks `stopRequested`, `finishedReceived`, `importStarted`,
  `importProbed`, `inserted`, `firstFrame` per session id (bounded to 16 sessions, no paths).
  A = `inserted`, B = `firstFrame`. C (playable with audio) and D (optional analysis) are not yet marked.

## Contracts decided for the next slices

1. **Slice 1 (removes the dominant cost):** for `screen-camera`, stop must not composite. Import the
   finalized screen track (+ audio mix or per-track audio) as the playable clip immediately; the camera
   stays a separate finalized track in a *recording group* (`tracks_dir`, shared origin, per-track
   offsets). Composition moves to preview/export. Existing flattened projects load unchanged.
2. **Slice 1b:** `import_media` returns probe metadata first; the SHA-256 is computed afterwards via the
   existing `hash_media` command and attached with a stale-project/identity guard. Until then the media
   has no checksum (never an invented one) and must not be treated as verified.
3. Project schema: additive optional `recordingGroup` on the media entry; defaults keep old projects
   byte-compatible. Native preview/export engine (Swift/AVFoundation) follows only after real
   measurements justify it; all unsupported configs route to the current preview/ffmpeg path.

## Slice 1 + 1b implemented (v4.49.0, `feature/recording-handoff-slice1`)

- Stage 3 for screen + camera is now a stream copy + audio mix; the composite became a background job
  (`composite_recording_camera`) whose result replaces the clip's file under guards (architecture.md,
  "Recording hand-off"). Span names: `record.stop_native.finalize_copy_mix` (always, at Stop) and
  `record.camera_composite` (background job). The `finalize_composite` span no longer exists.
- Stage 6 for recordings is `probe_media` (span `import.probe_only`); the SHA-256 runs after insertion
  (`hash_media`) and is attached with a stale guard. `import_media` (and its spans) is unchanged for
  other callers.
- New frontend marks: `playable` (C), `checksumAttached`, `cameraComposited`.

### Before / after, synthetic (same method and media as above, re-run 2026-10-21)

Same M1 Pro, bundled ffmpeg/ffprobe 7.1.1, `testsrc2` 2560x1440@30 screen, 1280x720 camera, two AAC
tracks, single run each, argv shapes as unit-tested in `native_capture.rs`. Script:
`stage_bench.sh` (kept out of the repo; it only runs the argv below with `time`).

| Take | Stop-blocking work before (composite + probe + max(ffprobe, SHA-256)) | Stop-blocking work after (copy+mix + probe + ffprobe) | Moved to background |
|---|---|---|---|
| 30 s (43 MB hand-off file) | 7.88 + 0.03 + 0.17 = **8.08 s** | 0.94 + 0.03 + 0.03 = **1.00 s** | composite 7.88 s, SHA-256 0.17 s |
| 120 s (174 MB) | 30.76 + 0.03 + 0.71 = **31.50 s** | 4.27 + 0.03 + 0.03 = **4.33 s** | composite 30.76 s, SHA-256 0.71 s |

The composite of these synthetic takes has the same container duration (30.016 s / 120.000 s) and
picture size (2560x1440) as the stream-copied hand-off file, so the swap guard (size equal, length
within 0.07 s) accepts it. Helper stop, IPC, React insertion and `<video>` load are not in these numbers
and were not measured (no real capture; the helper is a stub here). Stop-to-editor for screen-only
takes changes only by the removed SHA-256 wait (0.17 s / 0.71 s here).

### 4.49.1 review fixes

The background composite now uses `overlay … eof_action=pass` instead of `shortest=1`
(camera lost mid-take no longer shortens the picture) and Rust probes the hand-off file
and the composite once more (two ffprobe runs, about 0.03 s each here) to compare
video-stream length, size and sound before returning. Both are background work; the
Stop-blocking numbers above are unchanged. The composite timings above were measured
with the `shortest=1` argv; with equal-length tracks the filter graph does the same
work, so no re-run was made.

### Final argv note (4.50.1)

The shipped composite argv uses `overlay ... eof_action=pass`. The benchmark harness
(`npm run bench:recording`, `docs/benchmarks/recording-stop-2026-10-21.json`) and the
composite timings in this document come from the earlier `shortest=1` argv shape and
were **not re-run** on the final argv; they are synthetic, single-run, agent-measured and
not production-path proof. The 0.03 s ffprobe checks the background job now adds are
background work, not part of Stop-to-editor.

## Not done / not claimed

- No real recording was captured; the committed `yusafcut-capture` is a stub, so a production-path
  baseline (screen-only, screen+camera+mic+system, mic-only, short and long) still needs the real helper
  built and an announced short capture test.
- No native playback/export engine yet. The 4.50.0 engine package is a contract slice (capabilities, validator, composition builder) that nothing in the app calls; the composite is still FFmpeg, now in the background.
- `../yusaf-cut-perf` (branch `feature/apple-silicon-performance`, uncommitted `export_plan.rs` +
  export.rs changes, benchmark fixtures) was inspected read-only and left untouched. It is export-planning
  work (frame-count quantisation, per-range inputs); evaluate for the export milestone, do not merge blindly.
- Model routing: this turn ran on a single agent (Sonnet 5.5); no subagents or worktrees were spawned.

## Ledger

| Item | Value |
|---|---|
| Branch | `feature/recording-to-editor-timing` |
| Tests | vitest `tests/recordingTimeline.test.ts` (3), `tsc`, `cargo check` pass; full suites not yet rerun |
| Slice 1 branch | `feature/recording-handoff-slice1` v4.49.0: `npm run check`, 1289 Vitest, 445 lib + 17 cli Rust (1 ignored); v4.49.1 (shipped as 4.50.1): `npm run check`, 1295 Vitest, 449 lib + 17 cli Rust (1 ignored) |
