# Export baseline (WP-1A) - production argv, short fixtures

Measured 2026-10-20 on an Apple M1 Pro (8P+2E, 32 GB), macOS 27.0.1, branch `feature/apple-silicon-performance` at `3c4cdab` (working tree dirty), bundled ffmpeg 7.1.1 (arm64), 3 reps per scenario, quiet-ish machine (load ~8 at the end; see limits). Raw data: [`../benchmarks/export-baseline-2026-10-20.json`](../benchmarks/export-baseline-2026-10-20.json).

## How it works

- `src-tauri/examples/export_argv.rs` deserialises the same `ExportOpts` the UI sends and prints the argv from the **real** `build_reencode_argv` (via `reencode_argv_for_bench`), plus `smart_cut_eligible` and, for cursor scenarios, the activity `.ass` written by the real `cursor_export::write_ass` with the same size/fps rules as `prepare_cursor`.
- `scripts/bench/export-matrix.mjs` generates 10 s fixtures with the bundled ffmpeg (screen-like 1080p30 testsrc2, a VFR variant, a variant whose audio starts ~0.48 s late, a 720p25 camera clip), builds each scenario from `scripts/bench/fixtures/export/*.json`, runs the argv under `/usr/bin/time -l`, and validates the output with `ffprobe -count_frames` (duration, frame count, audio start offset vs video, A/V duration delta). Environment capture is in `scripts/bench/lib/env.mjs` (chip, RAM, `sw_vers`, build mode, git SHA, `pmset -g therm`).
- Run: `node scripts/bench/export-matrix.mjs [--reps 3] [--only 05,09] [--skip-build]` (builds the example unless `--skip-build`; honours `CARGO_TARGET_DIR`).
- Output settings are the UI defaults: `h264_videotoolbox`, 8000k video, 192k AAC, `-hwaccel videotoolbox` (no `-hwaccel_output_format`), no explicit width/height/fps except where noted.

## Results (10 s of 1080p30 unless noted; wall = median of 3)

| Scenario | Smart-cut eligible* | Wall s (min-max) | Peak RSS MB | x realtime | Valid |
|---|---|---|---|---|---|
| 01 no effects | yes | 1.88 (1.84-1.92) | 228 | 5.3 | yes |
| 02 no effects, VFR source | yes | 0.98 (0.98-1.02) | 231 | 10.2 | yes (stays VFR, 138 frames) |
| 03 no effects, audio starts 0.48 s late | yes | 1.83 (1.80-1.84) | 227 | 5.5 | **no: audio offset lost** |
| 04 no effects, 720p25 camera | yes | 0.94 (0.93-0.94) | 135 | 10.7 | yes |
| 05 zoom (2 regions) | no | 1.82 (1.82-1.83) | 368 | 5.5 | yes |
| 06 cursor ASS (105 KB) | no | 1.83 (1.81-1.86) | 248 | 5.5 | yes |
| 07 scene (gradient, square) | no | 1.88 (1.87-1.88) | 295 | 5.3 | yes |
| 08 scene, rounded + shadow | no | 3.79 (3.73-3.96) | 327 | 2.6 | yes |
| 09 zoom + cursor + rounded/shadow | no | 4.36 (4.32-4.46) | 408 | 2.3 | yes |
| 10 200 cuts (frame-aligned, 13.3 s out) | yes | 2.37 (2.36-2.38) | 235 | 5.6 | yes |
| 11 reordered/repeated ranges (5 ranges) | yes | 2.84 (2.82-2.85) | **756** | 3.5 | yes |
| 12 two sources (screen+camera, scaled 1920x1080@30, 11 s) | no | 2.01 (2.00-2.02) | 375 | 5.5 | yes |
| 13 200 x 40 ms cuts (sub-frame) | yes | 2.03 (1.94-2.06) | 234 | 3.9 | **no: 10.67 s out for an 8 s EDL** |

\*"Eligible" is what `run_export` computes for these options with `forceReencode=false`. For those rows production would try smart-cut first and these numbers are the full re-encode fallback (`forceReencode`/keyframe-poor sources), not the typical path. The smart-cut path is **not** measured here.

## What the numbers say (and do not)

- Effects cost is almost all in rounded corners + shadow: 07 (plain scene) is ~1.9 s but 08 is ~3.8 s (user CPU 21 s vs 5 s, i.e. the `geq`/alpha path saturates ~5 cores). Zoom and cursor were cheap on this 10 s clip (~1.8 s, same as no effects; zoom costs +140 MB RSS).
- The old "7.18 s for 5 s" number (`export_effects_ass`) is a synthetic graph and is now labelled so in `arm64-media-packaging.md`. It cannot be compared directly to 09 (4.4 s for 10 s): different graph, machine state and clip length.
- Reordered/repeated ranges triple peak RSS (756 vs 228 MB) because `concat` buffers frames; the growth with longer repeated spans is unmeasured here.
- Every argv uses `-hwaccel videotoolbox` without `-hwaccel_output_format`, so decoded frames come back to CPU (confirmed in the JSON as `argvHasHwaccelNoOutputFormat`). Bitrate is a fixed 8000k when the UI passes none.

## Defects found by validation (not fixed here)

1. **Delayed source audio loses its offset.** Scenario 03: source audio starts at 0.478 s, the export's starts at 0.000 s and is 0.44 s shorter than the video, so audio plays ~0.48 s early. Cause: `atrim` + `asetpts=PTS-STARTPTS` normalises each audio segment to start at 0. Needs a proper fix with a pad/`adelay` or input seeking in Phase 3a.
2. **Sub-frame segments inflate duration** (scenario 13): 200 ranges of 40 ms produce 300 frames / 10.67 s instead of 8 s. Real EDLs are padded so this is an edge case, but it confirms the exporter rounds each range up to whole frames.

## Limits

- 10 s synthetic clips; testsrc2/testsrc content (compresses well, no real screen text, no real camera). Wall times are for ffmpeg only: no job/IPC/progress overhead, no keyframe probe, no smart-cut, no chapter metadata, no music beds, no image backgrounds.
- The machine was shared with other agents. An earlier run at load ~35 gave 9-10 s for scenarios 08/09 (and a 6.9-13.3 s spread), so effects timings are very load-sensitive; the table above is the later run (load ~8). Treat differences below ~10% as noise; thermal state was "no warning" before/after but not controlled. Re-run on an idle machine for release claims.
- Argv generator is a debug cargo build, which does not affect the timed ffmpeg binary.
- Frame-count validation is relative to the output's own average frame rate (so VFR output is checked for duration, not frame equality) and is loose (+-2 frames, +-segments for many-cut cases).
- Peak RSS is ffmpeg's `maximum resident set size` (bytes) from `/usr/bin/time -l`, not including the app.
- No quality metric (SSIM/VMAF) yet; Phase 3a will need it for old-vs-new comparison.

## Long-duration release tests (documented, NOT run)

Owner-run on an idle, plugged-in M-series Mac. Use real recordings (30-60 min 4K screen, camera, two-source) and the same harness with a real project: export it from the app with diagnostics, or write an `ExportOpts` JSON and feed it to the example.

```bash
cd src-tauri && cargo build --release --example export_argv && cd ..
# opts.json = ExportOpts (same shape the UI sends to export_video; outputPath on a local SSD)
pmset -g therm
CARGO_TARGET_DIR=src-tauri/target node scripts/bench/export-matrix.mjs --skip-build --reps 3 --opts opts.json --out docs/benchmarks/export-baseline-long.json
```
(`--opts` runs one real export through the production argv, times it with `/usr/bin/time -l` and ffprobes the result into `export-real-*.json`; note the script looks for the example under `debug/`, so for a release-built generator copy it or build without `--release`.)


Record: wall time, peak RSS, thermal before/after, output duration/frames vs EDL, audio offset, and repeat 3 times with a cool-down. Scenarios: 30 min 4K no effects, 30 min 4K all effects, 60 min with 500+ cuts, reordered/repeated 10-minute ranges (RSS growth), two-source 4K+1080p.
