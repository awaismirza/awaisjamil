# Analysis, proxy, hash and Stop-to-edit baseline (WP-1B, Phase 1)

Raw data: [`../benchmarks/analysis-baseline-2026-10-20.json`](../benchmarks/analysis-baseline-2026-10-20.json). Reproduce: `node scripts/bench/analysis-matrix.mjs` (builds `src-tauri/examples/analysis_argv.rs`, generates fixtures in `$TMPDIR/yusafcut-bench-analysis`, ~4 min).

Environment: Apple M1 Pro, 32 GB, macOS 27.0.1, bundled `ffmpeg` sidecar (release binary), git `3c4cdab`, 3 reps per case, median shown. Every output was validated with ffprobe (duration, frame count, codec/size, audio, PCM byte length, digest vs `shasum`); all validations passed.

## What is measured

The ffmpeg argv is emitted by Rust, not re-typed in JS. Real builders: `preview_cache::proxy_args` (Balanced/Low), `waveform_args`, `native_capture::finalize_args`. Not callable today (built inline in the command handlers), so the example mirrors them literally and marks them `mirrored`: `detect_pauses` silencedetect and the 16 kHz WAV extraction in `transcribe.rs`. If those handlers change, the mirrors must change too (Phase 8 should extract builders). Hash uses `media::sha256_file` itself.

## Results

| Case | Input | Wall (median) | Peak RSS (ffmpeg) | Notes |
|---|---|---|---|---|
| Proxy Balanced | 1080p30, 60 s | 7.3 s (4.7-9.6) | 182 MB | 8x realtime; 1800 frames, h264 |
| Proxy Low | 1080p30, 60 s | 6.3 s (4.5-6.9) | 158 MB | |
| Proxy Balanced | 4K30, 20 s | 7.9 s (4.3-9.8) | 495 MB | 2.5x realtime |
| Proxy Low | 4K30, 20 s | 4.4 s (2.7-5.0) | 471 MB | |
| Waveform decode (8 kHz) | 60 s | 63 ms | 24 MB | 953x realtime |
| silencedetect | 60 s | 66 ms | 24 MB | 7 silence ranges found |
| 16 kHz WAV extraction | 60 s | 139 ms | 25 MB | |
| Stop-to-edit, screen+camera | 10 s 1080p | 2.1 s + 19 ms probe | 324 MB | re-encode `h264_videotoolbox` 8000k |
| Stop-to-edit, screen+camera | 60 s 1080p | 14.0 s + 15 ms probe | 329 MB | scales linearly with take length |
| Stop-to-edit, screen+camera | 20 s 4K | 11.1 s + 32 ms probe | 878 MB | 4K screen + 720p camera |
| Stop-to-edit, screen only | 10 / 60 s 1080p | 0.25 s / 1.25 s | 24-26 MB | video copy, audio AAC re-encode |
| Stop-to-edit, screen only | 20 s 4K | 0.45 s | 41 MB | |
| sha256 import hash | 500 MB | 1.8 s (289 MB/s) | 9 MB | `shasum -a 256` reference 1.6 s |

Takeaways: screen+camera finalize costs about 0.23 s of ffmpeg per second of 1080p take (roughly 4.3x realtime), so a 10-minute take is on the order of 2.3 minutes of Stop-to-edit (extrapolated, see limits); 4K is about 0.55 s/s. Screen-only is ~48x realtime (copy). Waveform, silence and 16 kHz decode are each about 60-140 ms per minute, so the three separate decodes are not the bottleneck on short audio; proxy encode and camera finalize are. Hashing costs 3.5 s per GB, streamed with constant memory, and is already concurrent with ffprobe in `import_media`.

## Native timing spans

`src-tauri/src/perf_spans.rs`: opt-in (`YUSAFCUT_PERF_SPANS=1` or `set_enabled`), ring buffer of at most 4096 records, each `{name, durationMs, startUnixMs, id?}` with no paths. `perf_spans::snapshot()` returns them; the orchestrator registers any command. Spans added: `record.stop_native.{total,helper_stop,finalize_ffmpeg,probe}`, `preview.waveform.decode`, `preview.proxy.{encode,validate_publish}` (job id attached), `pauses.detect`. Disabled cost is one relaxed atomic load.

## Honest limits

- Synthetic fixtures (`testsrc2` + `say` speech, libx264 veryfast sources). Real screen content (static, text) and real camera/screen capture files (fragmented MP4, VFR timestamps, HEVC/other settings) compress and decode differently. Track pairs are plain `+faststart` MP4, not helper output.
- Proxy numbers vary 2x between reps (e.g. 4.7-9.6 s). Other agents were running builds and benchmarks on the same machine, thermal state was not recorded by macOS (`pmset` reported no warning level). Treat proxy figures as a coarse range; finalize and decode figures were stable (spread under 5%).
- Peak RSS is the ffmpeg child only (`/usr/bin/time -l`), not the app, and not the helper.
- "Stop-to-edit" here is finalize + the `format=duration` probe; it excludes the Swift helper stop/finalize, `import_media` (ffprobe + hash), the UI, and any waveform/proxy that follows. Use the new spans for end-to-end values in a real session [O].
- Page cache was warm for the hash (the file had just been written/read); a cold external drive will be slower. The hash binary was built at opt-level 3, the argv generator in debug.
- Durations were not run beyond 60 s (1080p) / 20 s (4K); long-take figures are extrapolation. Memory for very long inputs is unmeasured.

## Long-duration commands (not run)

```bash
# 10-minute speech + 1080p track pair, 3 reps (about 45 min total; run on AC power, record pmset therm)
node scripts/bench/analysis-matrix.mjs --speech-sec 600 --reps 3 --out docs/benchmarks/analysis-baseline-600s.json
# 2 GB hash, cold-ish (purge needs sudo, so run it manually if wanted)
node scripts/bench/analysis-matrix.mjs --hash-mb 2048 --reps 3 --out docs/benchmarks/analysis-baseline-hash2g.json
# Real-session spans: launch the app with spans on, then read perf_spans::snapshot() via the registered command
YUSAFCUT_PERF_SPANS=1 npm run tauri:dev
```
