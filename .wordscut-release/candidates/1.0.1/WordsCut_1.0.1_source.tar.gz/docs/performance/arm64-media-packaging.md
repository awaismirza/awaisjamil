# Native Apple Silicon ARM64 Media Packaging & Performance Tooling (`v4.25.0`)

YusafCut targets Apple Silicon (`arm64` / `aarch64-apple-darwin`) exclusively.
This document specifies the required FFmpeg/FFprobe capability manifest, the
hermetic source-pinned ARM64 build pipeline (`scripts/build-arm64-media.sh`),
the automated compatibility verifier (`scripts/verify-media-binaries.sh`), the
reproducible media pipeline benchmark (`scripts/benchmark-media-pipeline.mjs`),
and the Phase 5 native Apple media framework follow-up plan.

---

## 0. Executive Visual Overview

```
╔══════════════════════════════════════════════════════════════════════════════╗
║              YusafCut v4.25.0 — Native Apple Silicon Media Stack             ║
╠══════════════════════════╦═══════════════════════════╦═══════════════════════╣
║   Target Architecture    ║   Bundled Binary Size     ║   Verification Suite  ║
║   arm64 (macOS 13.0+)    ║   25.1 MB + 25.0 MB       ║   101 / 101 Passed    ║
║   Zero x86_64 / Rosetta  ║   (-68% vs 79.5 MB each)  ║   6 Automated Stages  ║
╠══════════════════════════╩═══════════════════════════╩═══════════════════════╣
║   Dynamic Linkage: 20 Apple System Frameworks / /usr/lib  |  0 LC_RPATHs     ║
║   Static Stack:    FFmpeg 7.1.1 + libx264 + libass + harfbuzz + freetype     ║
╚══════════════════════════════════════════════════════════════════════════════╝
```

```mermaid
flowchart LR
    subgraph Upstream["1. Pinned Upstream Sources (SHA-256 Verified)"]
        S1["fribidi 1.0.16"]
        S2["freetype 2.13.3"]
        S3["harfbuzz 10.1.0\n(CoreText)"]
        S4["libass 0.17.3\n(CoreText)"]
        S5["x264 31e19f92"]
        S6["FFmpeg 7.1.1"]
        S1 & S2 --> S3 --> S4 --> S6
        S5 --> S6
    end

    subgraph Build["2. Hermetic ARM64 Build (scripts/build-arm64-media.sh)"]
        B1["PKG_CONFIG_LIBDIR Isolated\n(No /opt/homebrew leakage)"]
        B2["-arch arm64\n-mmacosx-version-min=13.0"]
        B3["Candidate Binaries\n(strip -x + ad-hoc codesign)"]
        S6 --> B1 --> B2 --> B3
    end

    subgraph Verify["3. Pre-Install Gate (scripts/verify-media-binaries.sh)"]
        V1["Stage 1-2: Mach-O arm64\n+ otool -L Portability"]
        V2["Stage 3-4: 60+ Codecs/Filters\n+ Synthetic ASS/Zoom/Scene"]
        V3["Stage 5-6: VideoToolbox HW\n+ Rust Integration Suite"]
        B3 --> V1 --> V2 --> V3
    end

    subgraph Install["4. Atomic Install & Benchmark"]
        I1["src-tauri/binaries/\nffmpeg & ffprobe"]
        I2["7-Stage Benchmark\n(scripts/benchmark-media-pipeline.mjs)"]
        V3 -->|"Pass (101/101)"| I1 --> I2
    end
```

---

## 1. YusafCut Media Capability Manifest

Every bundled `ffmpeg-aarch64-apple-darwin` and `ffprobe-aarch64-apple-darwin`
binary is verified against the exact codecs, filters, demuxers, muxers, and
hardware accelerators invoked by the Rust backend (`src-tauri/src/`).

### 1.1 Hardware Acceleration & Encoders
| Component | Type | Rust Consumer |
|---|---|---|
| `videotoolbox` | `hwaccel` | `commands/export.rs`, `smart_cut.rs` |
| `h264_videotoolbox` | Video encoder | `commands/export.rs`, `smart_cut.rs` |
| `hevc_videotoolbox` | Video encoder | `commands/export.rs` |
| `libx264` | Video encoder | `commands/export.rs`, `smart_cut.rs`, `preview_cache.rs`, `recorder.rs` |
| `aac` | Audio encoder | `commands/export.rs`, `smart_cut.rs`, `preview_cache.rs`, `recorder.rs` |
| `pcm_s16le` | Audio encoder | `commands/transcribe.rs`, `preview_cache.rs` |
| `png`, `rawvideo` | Image/frame encoders | `cursor_export.rs`, `zoom.rs`, `scene.rs` tests |

### 1.2 Decoders, Demuxers, Muxers & Input Devices
- **Video decoders:** `h264`, `hevc`, `vp8`, `vp9`, `prores`, `mpeg4`, `png`, `mjpeg`, `webp`
- **Audio decoders:** `aac`, `mp3`, `pcm_s16le`, `flac`, `vorbis`, `opus`
- **Demuxers:** `mov`, `matroska`, `wav`, `mp3`, `aac`, `flac`, `ogg`, `concat`, `image2`, `s16le`, `rawvideo`, `ffmetadata`
- **Muxers:** `mp4`, `ipod` (`.m4a`), `wav`, `s16le`, `rawvideo`, `null`, `image2`, `ffmetadata`
- **Input devices (`libavdevice`):** `avfoundation`, `lavfi`

### 1.3 Filter Graph Capabilities
- **Timeline / Smart-Cut / Composition (`commands/export.rs`, `recorder.rs`):** `trim`, `setpts`, `scale`, `pad`, `crop`, `fps`, `overlay`, `format`, `setsar`, `null`, `concat`, `select`, `drawbox`
- **Scene Framing & Rounded Masking (`scene.rs`):** `color`, `gradients`, `alphamerge`, `geq`, `gblur`, `lut`
- **Dynamic Zoom (`zoom.rs`):** `scale` (`eval=frame`), `crop` (per-frame expressions)
- **Styled Vector Cursor Rendering (`cursor_export.rs`):** `ass`, `subtitles` (via `libass` + `harfbuzz` + `freetype` + `fribidi` + macOS `CoreText`)
- **Audio Processing & Analysis (`commands/export.rs`, `commands/pauses.rs`, `preview_cache.rs`):** `atrim`, `asetpts`, `anull`, `asplit`, `volume`, `adelay`, `apad`, `sidechaincompress`, `amix`, `aresample`, `silencedetect`, `sine`

### 1.4 FFprobe Output Contracts
- `commands/media.rs`: `-v quiet -print_format json -show_format -show_streams` (`format.duration`, `streams[].codec_type`, `width`, `height`, `r_frame_rate`, `sample_rate`)
- `smart_cut.rs`: `-v error -skip_frame nokey -select_streams v:0 -show_entries frame=pkt_pts_time,pts_time -of csv=p=0`
- `commands/preview.rs`: `-v error -select_streams v:0 -show_entries stream=codec_name -of csv=p=0`

---

## 2. Reproducible Native ARM64 Build (`scripts/build-arm64-media.sh`)

### 2.1 Pinned Upstream Source Provenance & SHA-256 Checksums
`scripts/build-arm64-media.sh` downloads, caches, and verifies six upstream
source archives before building into an isolated temporary staging prefix:

| Component | Version | Upstream Source URL | SHA-256 Checksum | License |
|---|---|---|---|---|
| `fribidi` | `1.0.16` | `https://github.com/fribidi/fribidi/releases/download/v1.0.16/fribidi-1.0.16.tar.xz` | `1b1cde5b235d40479e91be2f0e88a309e3214c8ab470ec8a2744d82a5a9ea05c` | LGPL-2.1+ |
| `freetype` | `2.13.3` | `https://download.savannah.gnu.org/releases/freetype/freetype-2.13.3.tar.xz` | `0550350666d427c74daeb85d5ac7bb353acba5f76956395995311a9c6f063289` | FTL / GPL-2.0+ |
| `harfbuzz` | `10.1.0` | `https://github.com/harfbuzz/harfbuzz/releases/download/10.1.0/harfbuzz-10.1.0.tar.xz` | `6ce3520f2d089a33cef0fc48321334b8e0b72141f6a763719aaaecd2779ecb82` | MIT |
| `libass` | `0.17.3` | `https://github.com/libass/libass/releases/download/0.17.3/libass-0.17.3.tar.xz` | `eae425da50f0015c21f7b3a9c7262a910f0218af469e22e2931462fed3c50959` | ISC |
| `x264` | `31e19f92f00c7003fa115047ce50978bc98c3a0d` | `https://code.videolan.org/videolan/x264/-/archive/31e19f92f00c7003fa115047ce50978bc98c3a0d/x264-31e19f92f00c7003fa115047ce50978bc98c3a0d.tar.bz2` | `01a4acb74eea1118c3aa96c3e18ee3384bc1f2bc670f31fb0f63be853e4d9d08` | GPL-2.0+ |
| `ffmpeg` | `7.1.1` | `https://ffmpeg.org/releases/ffmpeg-7.1.1.tar.xz` | `733984395e0dbbe5c046abda2dc49a5544e7e0e1e2366bba849222ae9e3a03b1` | GPL-3.0+ (`--enable-gpl --enable-version3`) |

### 2.2 Hermetic Linkage & Deployment Target
- **Architecture:** `arm64` (`-arch arm64`, `Mach-O 64-bit executable arm64`)
- **Minimum macOS deployment target:** `13.0` (`-mmacosx-version-min=13.0`, matching `src-tauri/tauri.conf.json`)
- **Hermetic `pkg-config` isolation:** `PKG_CONFIG_PATH=""` and `PKG_CONFIG_LIBDIR="$STAGE_DIR/lib/pkgconfig"` prevent accidental discovery of developer Homebrew dylibs under `/opt/homebrew` or `/usr/local`.
- **Dynamic linkage (`otool -L`):** Both executables have zero `LC_RPATH` entries and link dynamically **only** to 20 standard macOS system libraries/frameworks:
  - `/System/Library/Frameworks/{Foundation,AudioToolbox,CoreAudio,AVFoundation,CoreVideo,CoreMedia,CoreGraphics,OpenGL,ApplicationServices,CoreFoundation,VideoToolbox,CoreImage,AppKit,CoreServices,CoreText}.framework`
  - `/usr/lib/{libSystem.B.dylib,libiconv.2.dylib,libz.1.dylib,libbz2.1.0.dylib,libobjc.A.dylib}`
- **Installed binary artifacts:**
  - `src-tauri/binaries/ffmpeg-aarch64-apple-darwin`: `25,079,808` bytes (`SHA-256: 7d11f254fbd8d9959f6193a2a1d9b73cd1b79aadaeb5df5c16f8e4f49dcc7a8e`)
  - `src-tauri/binaries/ffprobe-aarch64-apple-darwin`: `25,021,360` bytes (`SHA-256: 7d95782f5a909cbd62132b8aeb0836e677e144e3e85e0396f78fae352f3c5641`)

### 2.3 Licensing & Distribution Obligations
- FFmpeg `7.1.1` is configured with `--enable-gpl --enable-version3` and statically links `libx264` (GPLv2+), `fribidi` (LGPLv2.1+), `freetype` (FTL/GPLv2+), `harfbuzz` (MIT), and `libass` (ISC).
- The resulting binaries are governed by **GPL-3.0-or-later**, which is compatible with YusafCut's **AGPL-3.0-or-later** license (GPLv3 §13 permits conveying combined/linked works under AGPLv3).
- When distributing binary `.dmg` bundles, retain the repository's `LICENSE` (AGPL-3.0-or-later) and provide the pinned upstream source URLs and build script (`scripts/build-arm64-media.sh`) as the Complete Corresponding Source recipe.

---

## 3. Automated Compatibility Verification (`scripts/verify-media-binaries.sh`)

Run via:
```bash
npm run media:verify
# or with full Rust real-FFmpeg integration tests and JSON report:
bash scripts/verify-media-binaries.sh --run-rust-tests --json /tmp/verify-arm64.json
```

```
┌──────────────────────────────────────────────────────────────────────────────┐
│               6-Stage Verification Matrix (101 / 101 Passed)                 │
├──────────┬──────────────────────────────────────────────────────┬────────────┤
│ Stage 1  │ Existence, size, Mach-O arm64, arch -arm64, minos≤13 │  8 / 8  ✓  │
│ Stage 2  │ Dynamic linkage (otool -L system-only, 0 LC_RPATH)   │  4 / 4  ✓  │
│ Stage 3  │ Capability manifest (encoders/decoders/filters/devs) │ 78 / 78 ✓  │
│ Stage 4  │ Portable synthetic media smoke suite (8 pipelines)   │  8 / 8  ✓  │
│ Stage 5  │ VideoToolbox hardware encoding (H.264 & HEVC)        │  2 / 2  ✓  │
│ Stage 6  │ Rust real-FFmpeg integration tests (--run-rust-tests)│  1 / 1  ✓  │
└──────────┴──────────────────────────────────────────────────────┴────────────┘
```

---

## 4. Reproducible Native ARM64 Media Benchmark (`scripts/benchmark-media-pipeline.mjs`)

Run via:
```bash
npm run media:bench
# or with custom options:
node scripts/benchmark-media-pipeline.mjs --duration 5 --warmup 1 --runs 3 --json /tmp/bench-arm64.json
```

### 4.1 Measured Synthetic Pipeline Results (Apple M1 Pro, 10 cores, 32 GB RAM)
Fixture: deterministic 5.0 s `1920x1080@30fps` H.264 + 48 kHz AAC input (`1 warmup + 3 measured runs`, executed under `nice -n 10 /usr/bin/time -l arch -arm64`):

| Stage ID | Pipeline Operation | Median Wall Time (ms) | Spread (ms) | Effective Speed | Median Peak RSS (MB) |
|---|---|---:|---:|---:|---:|
| `ffprobe_metadata` | FFprobe JSON metadata + stream inspection | `19.41` | `±0.14` | Instant | `21.14` |
| `waveform_pcm_8k` | 8 kHz mono `s16le` PTS-aligned waveform decode | `23.73` | `±0.43` | `210.7×` realtime | `22.45` |
| `audio_extract_16k_wav` | 16 kHz mono PCM WAV extraction (Whisper input) | `23.86` | `±0.29` | `209.6×` realtime | `22.48` |
| `preview_proxy_720p` | 720p30 H.264 `libx264 ultrafast` + AAC proxy | `154.68` | `±13.25` | `32.3×` realtime | `224.73` |
| `export_libx264` | Direct 1080p30 software export (`libx264 veryfast`) | `434.37` | `±51.91` | `11.5×` realtime | `573.64` |
| `export_vt_h264` | Direct 1080p30 hardware export (`h264_videotoolbox`) | `990.50` | `±12.37` | `5.0×` realtime | `217.61` |
| `export_effects_ass` | **Synthetic graph, not the production exporter** (see [export-baseline.md](export-baseline.md)): full filtergraph (`gradients` + `scale`/`crop` zoom + `geq` rounded alpha mask + `libass` vector cursor + `h264_videotoolbox`) | `7180.42` | `±450.24` | `0.70×` realtime | `496.97` |

```
Wall Time by Stage (5.0s 1080p30 Synthetic Input — Lower is Faster)
────────────────────────────────────────────────────────────────────────────────
ffprobe_metadata       ▏ 19.4 ms   (21 MB RSS)
waveform_pcm_8k        ▏ 23.7 ms   (22 MB RSS)
audio_extract_16k_wav  ▏ 23.9 ms   (22 MB RSS)
preview_proxy_720p     █ 154.7 ms  (225 MB RSS)
export_libx264         ███ 434.4 ms (574 MB RSS)
export_vt_h264         ███████ 990.5 ms (218 MB RSS)
export_effects_ass     ████████████████████████████████████████████████ 7180.4 ms (497 MB RSS)
────────────────────────────────────────────────────────────────────────────────
                       ▲ Bottleneck: CPU filtergraph (geq mask + scale/crop + libass)
                         addressed in Phase 5 GPU Metal/CoreImage plan below
```

### 4.2 Scope & Pending Release-App Certification
- The table above certifies **CLI media pipeline throughput and memory footprint** on short deterministic 1080p30 synthetic media.
- Heavyweight long-duration soak tests (10-minute / 60-minute 1080p60 and 4K60 recordings, 30-minute editor playback/scrubbing p95 frame/seek certification in the packaged `.app` bundle) remain owner-scheduled release QA tasks so background agent runs never contend with interactive sessions.

---

## 5. Phase 5 — Native Apple Media Framework Follow-Up Plan

Even with native `arm64` compilation, the full-effects export stage (`export_effects_ass`, `7.18 s` for a 5 s 1080p30 clip; **synthetic graph, not the production exporter** - production-path numbers are in [export-baseline.md](export-baseline.md)) is dominated by **CPU filtergraph bottlenecks** inside FFmpeg (`geq` per-pixel rounded-corner alpha evaluation, CPU `scale=eval=frame` + `crop` zoom expressions, CPU `libass` rasterization, and `CVPixelBuffer` ↔ CPU `yuv420p`/`rgba` round-trips before `h264_videotoolbox`).

```mermaid
flowchart TD
    subgraph Current["Current Export Path (FFmpeg Filtergraph)"]
        C1["Source MP4 Decode"] --> C2["CPU libass Cursor Draw"]
        C2 --> C3["CPU scale=eval=frame + crop\n(Per-Frame Zoom)"]
        C3 --> C4["CPU geq + gblur + alphamerge\n(Rounded Corners & Shadow)"]
        C4 --> C5["CPU yuv420p Buffer Copy"]
        C5 --> C6["h264_videotoolbox Encode"]
    end

    subgraph Target["Target Phase 5 Path (Zero-Copy Apple Media + Metal)"]
        T1["AVAssetReader / VTDecompressionSession\n(IOSurface CVPixelBuffer)"] --> T2["Single Metal Compute/Render Pass\n(Zoom + SDF Rounded Mask + Shadow + Vector Cursor)"]
        T2 --> T3["AVAssetWriter / VTCompressionSession\n(Direct IOSurface H.264 / HEVC Encode)"]
    end
```

### 5.1 Decision Gate: HTML5 `<video>` / WebView vs Native `AVFoundation` Playback
- **Keep HTML5 `<video>` + `requestVideoFrameCallback` + preview proxies (`preview_cache.rs`)** as long as packaged-release diagnostics (`src/lib/playbackDiagnostics.ts`) meet the plan's interactive targets on 1080p60/4K sources:
  - Steady playback dropped frames `< 1%`
  - Coalesced scrub/seek p95 `< 80 ms` (proxy) / `< 140 ms` (original)
  - Cut-boundary transition jitter `< 1` frame (`16.7 ms`)
- **Trigger for Native `AVPlayer` / `AVSampleBufferDisplayLayer`:** If multi-segment cuts or 4K60 multi-track PIP playback exhibit WebKit media decoder stalls or >1 frame cut-boundary flashes that `useCoalescedSeek` + 720p proxies cannot mask, introduce an `AVComposition` / `AVPlayerItem` playback surface backed by `CAMetalLayer`.

### 5.2 GPU Composition via Metal / Core Image (Replacing CPU `geq`, `gblur`, `scale`, `overlay`)
- **Current bottleneck:** `scene.rs` uses FFmpeg's single-threaded pixel-expression filter `geq` to compute rounded-corner masks and `gblur` + `alphamerge` + `overlay` in CPU memory, while `zoom.rs` evaluates `scale=eval=frame` on the CPU for every frame.
- **Target architecture:**
  1. Decode source segments via `AVAssetReaderTrackOutput` (or `VTDecompressionSession`) directly into IOSurface-backed `CVPixelBuffer` (`kCVPixelFormatType_32BGRA` or `kCVPixelFormatType_420YpCbCr8BiPlanarVideoRange`).
  2. Perform zoom/crop transform, rounded-corner SDF mask, drop shadow, gradient/image background, and vector cursor overlay in a single **Metal compute/render pass** (or `CIFilter` chain rendered via a shared `CIContext(mtlDevice:)` into an output `CVPixelBufferPool`).
  3. Feed the composited `CVPixelBuffer` directly into `AVAssetWriterInputPixelBufferAdaptor` / `VTCompressionSession` (`h264`/`hevc`) with **zero CPU pixel readbacks**.

### 5.3 When to Prefer FFmpeg vs Native `AVAssetReader` / `AVAssetWriter` / `VideoToolbox`
- **Use Native Apple Media Pipeline (Swift helper or Rust Objective-C/CoreMedia bridge) when:**
  - Exporting H.264/HEVC MP4/MOV with scene framing, rounded corners, shadows, dynamic zoom, and cursor overlays (eliminates CPU `geq`/`scale`/`libass` bottleneck and keeps frames on GPU/Media Engine via `IOSurface`).
  - Performing fast keyframe-aligned passthrough / smart-cut stitching on native `MOV`/`MP4` containers via `AVMutableComposition` + `AVAssetExportSession`.
- **Retain Native ARM64 FFmpeg (`ffmpeg-aarch64-apple-darwin`) when:**
  - Probing arbitrary user-imported containers/codecs (`mkv`, `webm`, `vp9`, `opus`, `flac`, `ogg`).
  - Extracting 16 kHz mono PCM WAV (`pcm_s16le`) for `whisper-cli` / `whisperkit-cli` and running `silencedetect` (`commands/pauses.rs`).
  - Software-encoded archival exports (`libx264` CRF mode) or fallback when hardware VideoToolbox sessions are unavailable.

### 5.4 Bounded Concurrency & Cancellation Contract
- Any native Swift/Metal export helper must participate in `ExportState`'s existing job-ID + cancellation token lifecycle (`commands/export.rs`) and respect the bounded background analysis semaphore (`commands/preview.rs`) so background waveform/proxy/transcription work never starves active exports or UI responsiveness.
