# WordsCut Distribution, Code Signing & Notarization Guide

> Current distribution ownership (22 October 2026): `awaismirza/awaisjamil` owns the product site and draft-only release/signing/verification workflow. This app repository supplies private source and the build/signing helper scripts. See `docs/wordscut-distribution.md` in the awaisjamil repository. The older workflow paths and public-download assumptions below describe the previous setup. No application licence is changed by moving hosting.


> **Target Architecture:** Apple Silicon (`arm64` / `aarch64-apple-darwin` exclusively).  
> **Minimum macOS Version:** macOS 13.0+ (Ventura, Sonoma, Sequoia).  
> **Current Version:** `v4.25.0`

---

## 1. Overview & Dual Distribution Models

WordsCut supports two distribution workflows:

```mermaid
flowchart TD
    Build["Production Build\n(npm run build:production)"] --> Choice{"Distribution Channel"}
    
    Choice -->|"Direct Web Distribution"| Direct["Developer ID Application\n+ Apple Notarization"]
    Direct --> InsideOut["Inside-Out Signing\n(Sidecars -> Libs -> Main .app)"]
    InsideOut --> Notarize["xcrun notarytool submit\n(Apple Notary Service)"]
    Notarize --> Staple["xcrun stapler staple\n(Gatekeeper Validation)"]
    Staple --> OutDMG["📦 Notarized DMG\n(WordsCut_4.25.0_aarch64.dmg)"]
    
    Choice -->|"Mac App Store (MAS)"| MAS["Apple Distribution Certificate\n+ Sandboxed Profile"]
    MAS --> MASBuild["npm run build:mas\n(Sandboxed .app bundle)"]
    MASBuild --> Archive["npm run xcarchive\n(Creates WordsCut.xcarchive)"]
    Archive --> AppStore["App Store Connect\n(Xcode Organizer / altool)"]

    style Build fill:#2563eb,stroke:#1d4ed8,stroke-width:2px,color:#fff
    style OutDMG fill:#059669,stroke:#047857,stroke-width:2px,color:#fff
    style AppStore fill:#059669,stroke:#047857,stroke-width:2px,color:#fff
```

---

## 2. Code Signing Architecture & Nested Sidecars

WordsCut bundles several native Apple Silicon Mach-O executables inside `src-tauri/binaries/` which are copied into `WordsCut.app/Contents/MacOS/`:
1. `ffmpeg-aarch64-apple-darwin` (Hermetic static build, VideoToolbox HW acceleration)
2. `ffprobe-aarch64-apple-darwin` (Static media analysis)
3. `whisper-cli-aarch64-apple-darwin` (Static Metal/Core ML transcription engine)
4. `whisperkit-cli-aarch64-apple-darwin` (Swift Core ML whisper engine)
5. `yusafcut-capture-aarch64-apple-darwin` (Swift ScreenCaptureKit daemon)
6. `mlx-sidecar-aarch64-apple-darwin` (Self-contained PyInstaller MLX LLM binary)

### The "Inside-Out" Signing Requirement
Apple Gatekeeper enforces strict validation of nested binaries:
> **Crucial Rule:** Every nested binary and dynamic library must be signed with `--options runtime` and `--timestamp` **before** the parent `.app` bundle is signed. If the `.app` is signed first, signing nested binaries afterwards invalidates the top-level bundle seal.

---

## 3. Direct Distribution (DMG + Apple Notarization)

### Step 1: Export Developer ID Credentials
Ensure your Developer ID certificate is in your Keychain and credentials are configured:

```bash
# 1. Inspect installed certificates
security find-identity -v -p codesigning

# Expected output contains:
# "Developer ID Application: Your Name (TEAM_ID)"
```

Set up notarization credentials using `notarytool` (recommended approach, stores password securely in macOS Keychain):
```bash
xcrun notarytool store-credentials "AC_PASSWORD" \
  --apple-id "your-apple-id@example.com" \
  --team-id "YOUR_TEAM_ID" \
  --password "xxxx-xxxx-xxxx-xxxx"   # App-Specific Password from appleid.apple.com
```

### Step 2: Build and Sign Automatically
Run the dedicated signing script:
```bash
# Using stored keychain profile:
NOTARY_PROFILE="AC_PASSWORD" bash scripts/sign-and-notarize.sh

# OR using environment variables:
APPLE_SIGNING_IDENTITY="Developer ID Application: Your Name (TEAM_ID)" \
APPLE_ID="your-apple-id@example.com" \
APPLE_PASSWORD="xxxx-xxxx-xxxx-xxxx" \
APPLE_TEAM_ID="YOUR_TEAM_ID" \
bash scripts/sign-and-notarize.sh
```

### Step 3: Manual Step-by-Step Signing (Reference)
If executing manually without the script:

1. **Sign all nested sidecar binaries:**
   ```bash
   APP="src-tauri/target/release/bundle/macos/WordsCut.app"
   IDENTITY="Developer ID Application: Your Name (TEAM_ID)"

   find "$APP/Contents/MacOS" -type f -perm +111 | while read -r bin; do
     if [[ "$(basename "$bin")" != "WordsCut" ]]; then
       codesign --force --options runtime --timestamp --sign "$IDENTITY" "$bin"
     fi
   done
   ```

2. **Sign top-level App Bundle:**
   ```bash
   codesign --force --options runtime --timestamp \
     --entitlements src-tauri/Entitlements.plist \
     --sign "$IDENTITY" "$APP"
   ```

3. **Verify strict signature:**
   ```bash
   codesign --verify --deep --strict --verbose=2 "$APP"
   ```

4. **Sign the DMG installer:**
   ```bash
   DMG="src-tauri/target/release/bundle/dmg/WordsCut_4.25.0_aarch64.dmg"
   codesign --force --timestamp --sign "$IDENTITY" "$DMG"
   ```

5. **Submit to Apple Notarization:**
   ```bash
   xcrun notarytool submit "$DMG" --keychain-profile "AC_PASSWORD" --wait
   ```

6. **Staple the Notarization Ticket:**
   ```bash
   xcrun stapler staple "$DMG"
   ```

7. **Verify with Gatekeeper:**
   ```bash
   spctl --assess --type open --context context:primary-signature -v "$DMG"
   ```

---

## 4. Mac App Store (MAS) Distribution

For submission to App Store Connect:

1. **Prerequisites:**
   - Apple Distribution certificate installed in Keychain (`security find-identity -v -p codesigning`).
   - Provisioning profile downloaded from `developer.apple.com` and saved as:
     `src-tauri/WordsCut_MAS.provisionprofile`.
2. **Build Sandboxed App:**
   ```bash
   npm run build:mas
   ```
3. **Generate Xcode Archive:**
   ```bash
   npm run xcarchive
   ```
4. **Upload to App Store Connect:**
   Double-click `WordsCut.xcarchive` or open Xcode Organizer (`Xcode → Window → Organizer`) and click **Distribute App → App Store Connect → Upload**.

---

## 5. Verification Checklist

Before releasing any DMG build:

| Check | Command | Expected Result |
| :--- | :--- | :--- |
| **Architecture** | `lipo -archs src-tauri/target/release/bundle/macos/WordsCut.app/Contents/MacOS/WordsCut` | `arm64` |
| **Hardened Runtime** | `codesign -dvvv src-tauri/target/release/bundle/macos/WordsCut.app` | Contains `runtime` in flags |
| **Strict Signing** | `codesign --verify --deep --strict src-tauri/target/release/bundle/macos/WordsCut.app` | Clean exit (no errors) |
| **Notary Staple** | `xcrun stapler validate src-tauri/target/release/bundle/dmg/*.dmg` | `The validate action worked!` |
| **Gatekeeper** | `spctl -a -t open --context context:primary-signature -v src-tauri/target/release/bundle/dmg/*.dmg` | `accepted / source=Notarized Developer ID` |

---

## 6. Copy-Paste Prompt for Claude / Future Agents

When instructing an agent (Claude, Cursor, Codex) to build, sign, and notarize the product, copy and paste the following prompt:

````markdown
You are the release and signing agent for WordsCut on macOS Apple Silicon (arm64).
Please read `docs/distribution-and-signing.md` and sign the production release.

Task:
1. Verify prerequisites on the machine:
   - Ensure the architecture is arm64 (Apple Silicon).
   - Check available signing identities:
     security find-identity -v -p codesigning
   - Check notarytool keychain credentials or prompt for credentials if missing.

2. Verify or build the production release bundle:
   - If `src-tauri/target/release/bundle/macos/WordsCut.app` does not exist, run:
     npm run build:production

3. Sign the application bundle and DMG inside-out:
   - Run:
     NOTARY_PROFILE="AC_PASSWORD" bash scripts/sign-and-notarize.sh
   (Or supply APPLE_SIGNING_IDENTITY, APPLE_ID, APPLE_PASSWORD, APPLE_TEAM_ID).

4. Verify the build against Gatekeeper:
   - codesign --verify --deep --strict --verbose=2 src-tauri/target/release/bundle/macos/WordsCut.app
   - xcrun stapler validate src-tauri/target/release/bundle/dmg/*.dmg
   - spctl --assess --type open --context context:primary-signature -v src-tauri/target/release/bundle/dmg/*.dmg

5. Report the final status, file paths, checksums (shasum -a 256), and Gatekeeper assessment results.
````
