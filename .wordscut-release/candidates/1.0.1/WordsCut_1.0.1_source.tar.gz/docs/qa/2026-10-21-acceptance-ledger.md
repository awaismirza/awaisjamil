# QA acceptance ledger — baseline 476547c (v4.28.1)

Env: macOS 27.0.1, Apple M1 Pro, 32 GB. Worktree `yusaf-cut-qa` (detached → branch qa/acceptance-ledger).
Baseline gates (agent-run, unit/fixture level only): `npm run check` ok; Vitest 599; cargo 242 (+17 cli, 1 ignored); swift 37.
NOT exercised yet: native app UI, real capture, real exports. Browser-only Vite (port 1477) has no Tauri IPC.
Committed `yusafcut-capture` is a 326-byte stub (exit 78) => native-only paths fall back to ffmpeg unless `npm run native:build`.

## Environment blockers
- 3 live ffmpeg avfoundation recordings from /Applications/YusafCut.app (oldest ~1.9 days) — not ours, left running; recording hardware tests BLOCKED.
- Reference screenshots (ScreenKite / earlier timeline) were not attached; visual comparison BLOCKED.
- No desktop computer-use tool in this session (only in-app browser, iOS simulator). Native UI driving via cliclick/osascript needs Accessibility permission — unverified.
- Other agents' uncommitted worktrees: yusaf-cut-device-loss, yusaf-cut-perf (untouched).

## Matrix (current truth at `qa/integration-2` v4.41.0; Implemented = unit + real-ffmpeg tested, NOT live-verified in the app)
| Area | Implemented | Partial | Unimplemented |
|---|---|---|---|
| Timeline | playhead, zoom 1-32x, waveform lane, clip lane trim/split/roll/snap (speed-aware), zoom lane, chapters, cut map, lane visibility + Simple/Detailed presets, drag-move, duplicate, ripple delete | — | filmstrip, separate audio lane |
| Audio | music/SFX tracks (gain, offset, ducking), mute/solo, fades, loudnorm target + loudness report, preview mixing (`MusicPreview`), clip mute | ducking and >0 dB gain not in preview | voice-over track (override/insert/overlay), keep/discard/retake review, mixer UI |
| Keyboard | editor hotkeys in a registry, rebinding with conflict checks, modal/IME/repeat guards, layout-aware letters, tests; recorder shortcuts | — | — |
| Editor | delete words, find/replace, fillers, silence, split/trim/roll, duplicate/reorder, restoreWords (store), relink dialog, undo/redo, save/reopen, chapters | restore has no UI chip | — |
| Recording | ffmpeg screen/camera/mic/voiceover, pause/resume, native source, cursor log | window/area/system audio native-only | — |
| Visual | background, padding/corners/shadow, aspect, zoom/follow, cursor styles, crop, transparent bg, styled captions, annotations, keystroke overlay, speed, freeze holds, crossfade/dip | cursor motion blur, camera layout (record-time) | device frames, image/video overlays, privacy masks |
| Export | H.264, HEVC, MOV, ProRes 422/HQ, ProRes 4444 alpha, GIF, M4A, WAV, stems, range, SRT/VTT, chapters, burned-in captions, FCPXML 1.10 | FCPXML drops effects (listed as unsupported) | HEVC with alpha |
| Integrations | CLI, MCP | — | embedded agent, cloud/share, Screen Studio import, signed updates, asset library, AI-assisted editing (design only in `docs/ai/`) |

Owner live checks still required: see `docs/HANDOFF.md` §1 "OWNER LIVE CHECKS".

## Routing ledger
| Task | Agent | Model requested | Result |
|---|---|---|---|
| Inventory A–D (editor/audio/keys) | subagent | sonnet | done |
| Inventory recording/visual/export | subagent | sonnet | done |
| Timeline lane visibility | subagent worktree | sonnet | done (4.29.0, merged into `qa/integration`) |
| Hotkeys modal guard/rebinding | subagent worktree | sonnet | done (4.30.0, merged) |
| Export formats | subagent worktree | opus | done (4.31.0, merged) |
| FCPXML | subagent worktree | sonnet | done (4.32.0, merged; integration release 4.33.0) |
| Audio mixer | subagent worktree | — | done (4.34.0, merged) |
| Crop + transparent background | subagent worktree | — | done (4.35.0, merged into `qa/integration-2`) |
| Annotations + keystrokes | subagent worktree | — | done (4.36.0, merged in 4.40.0) |
| Styled captions | subagent worktree | — | done (4.37.0, merged) |
| Speed / freeze / transitions | subagent worktree | — | done (4.38.0, merged in 4.41.0) |
| Clip ops + relink | subagent worktree | — | done (4.39.0, merged) |
| AI foundation (design only) | subagent | — | done (`docs/ai/`, merged in 4.33.0) |
| Final independent review fixes | subagent | opus | done (4.41.0, no bump) |
Actual model IDs are not reported by the Agent tool; only the alias is known. "—" = not recorded.

## Fixtures
/private/tmp/yc-qa/fixtures: land_48k.mp4, port_44k_mono.mp4, audio_only.wav (16k), noaudio.mp4, delayed_audio.mp4, vfr.mp4 — synthetic lavfi, no private media.
