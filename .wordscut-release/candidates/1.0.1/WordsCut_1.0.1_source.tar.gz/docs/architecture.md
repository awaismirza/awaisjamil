# WordsCut Architecture

This document explains how the WordsCut code maps to the product spec. The GitHub source repository is `awaismirza/wordscut-app`; the product website and private release orchestration live in `awaismirza/awaisjamil`. Historical YusafCut names remain in compatibility-sensitive bundle IDs, storage keys, helper names, and project formats.

## Layered view

```
┌──────────────────────────────────────────────────────────────────┐
│ React + Tauri webview                                            │
│                                                                  │
│   ┌───────────────────────┐   ┌────────────────────────────────┐ │
│   │ TranscriptEditor      │   │ VideoPreview / Waveform        │ │
│   │ (TipTap + Word/Pause) │◀──┤ (HTML5 <video> + WaveSurfer)   │ │
│   └─────────┬─────────────┘   └────────────┬───────────────────┘ │
│             │                              │                     │
│             ▼                              ▼                     │
│   ┌──────────────────────────────────────────────────────────┐   │
│   │  Zustand stores                                          │   │
│   │    projectStore    — EDL + project metadata              │   │
│   │    playerStore    — playback position, markers, zoom     │   │
│   │    uiStore        — modal state, loaders, toasts         │   │
│   │    jobsStore      — background job mirror from Rust      │   │
│   │    editorUiStore  — active panel, drawer open,           │   │
│   │                     aspect ratio, zoom                   │   │
│   │    recordingStore — recorder session, devices, global    │   │
│   │                     shortcuts, auto-append pipeline      │   │
│   │  + zundo (50-step undo on projectStore)                  │   │
│   └────────────────┬─────────────────────────────────────────┘   │
└────────────────────┼─────────────────────────────────────────────┘
                     │ Tauri `invoke` / events
                     ▼
┌──────────────────────────────────────────────────────────────────┐
│ Rust backend (src-tauri/)                                        │
│                                                                  │
│   commands/{media,transcribe,project,export,snapshots,llm,       │
│             jobs,misc,pauses,record}                             │
│   ├── parse_ffprobe_json  (pure, tested)                         │
│   ├── parse_whisper_json  (pure, tested)                         │
│   ├── recorder arg/device parsers (pure, tested)                 │
│   └── filter graph builder (pure, tested)                        │
│                                                                  │
│   sidecar processes:                                             │
│     - ffprobe                                                    │
│     - ffmpeg (with VideoToolbox hw encode/decode)                │
│     - whisper-cli (Core ML + Metal, whisper.cpp)                 │
│     - mlx-sidecar (optional on-device LLM, `mlx-sidecar` feat)  │
└──────────────────────────────────────────────────────────────────┘
```

## The EDL contract

Everything important happens through `Project`:

```ts
type Project = {
  version: 1;
  id: string; name: string;
  createdAt: string; updatedAt: string;
  media: Record<MediaId, SourceMedia>;
  segments: Segment[];              // ORDER MATTERS — this IS the timeline
  settings: { exportPreset; paddingMs };
  chapters?: Chapter[];             // output-timeline chapter markers
  musicTracks?: MusicTrack[];       // audio bed tracks
}
```

**Invariants** (enforced by tests):

1. `Word.start` / `Word.end` are immutable source timecodes.
2. Source timecodes (`sourceIn`, `sourceOut`) refer to the original media file.
3. Deleting a word range splits the affected segment(s) and drops the middle.
4. `paddingMs` is applied at the *boundary* of cuts only — never to the start of
   the first surviving run or the end of the last surviving run. Padding next to
   a cut is capped at a quarter of the cut, so neighbouring kept segments never
   overlap in source time. Export cuts exactly `sourceIn`/`sourceOut` (it adds no
   padding of its own), so exported length always equals `totalDuration`.
5. Mark In / Mark Out (`playerStore`, output-timeline seconds) drive two range
   edits in `src/lib/rangeActions.ts`: `deleteOutputRange` (ripple delete) and
   `keepOutputRange` (extract — keep only the range). Both re-time chapters and
   audio-track offsets via `retimeAfterEdit`.
6. Shorten pauses cuts source-time ranges with `trimSourceRanges`: each range
   is reduced by every word span it touches, so it removes only audio between
   words, then splits the segment around what is left. Pauses are detected on
   the first media, so cuts apply to that media's segments only.
7. Pause removal, "Trim silences" (`cutSilences`) and Shorten pauses all share
   `trimSourceRanges`; silences always come from ffmpeg silencedetect, never
   from word gaps (DTW word spans absorb the silence before a word). A pause
   badge is removed only when its cut really removed time.
8. Fillers: `src/lib/fillers.ts` is the single list and matcher (multi-word
   aware, pure). `fillerStore` holds the selected phrases (safe hesitation
   sounds by default); the transcript highlight, waveform, status bar and
   `projectStore.deleteFillers` all use the same matches.

9. Speed, freeze frames and transitions (4.38.0) are optional per-segment fields
   (`speed`, `muted`, `holdSec`, `transitionIn`); absent means 1x / sound on / no
   hold / straight cut, so old projects load and save byte-identical. Rust reads
   them leniently (`SegmentTiming`'s own `Deserialize`): a malformed value falls
   back to its default instead of failing `load_project`, and unknown segment keys
   are kept in `SegmentTiming.extra` and written back (fixture
   `tests/fixtures/hostileTiming.json`, shared with `tests/timing.test.ts`). Other
   levels of the project still drop keys they do not know. See
   "Speed, freeze frames and transitions" below.

`tests/edl.test.ts` is the canonical reference. Read it before changing any
EDL operation.

## Speed, freeze frames and transitions (4.38.0)

**One time mapping.** A clip occupies `(sourceOut - sourceIn) / speed + holdSec`
output seconds (`segmentOutputLength`). `computeTimeline` and `getTimelineIndex`
add `speed` / `holdSec` to an entry only when they are not the default, and
every output↔source conversion goes through `src/lib/timeMap.ts`:
`entrySourceAt(entry, t)` (footage at speed, then the hold shows `sourceOut`)
and `entryOutputAt(entry, s)`. Rust mirrors the same rule in `edl.rs`
(`Segment::output_len`, `source_at`, `Project::output_duration`) and
`tests/fixtures/timingProject.json` is checked by both test suites. Speed is
clamped to 0.25–4, holds to 30 s, transitions to 0.1–2 s.

**Transitions are overlap-neutral.** `transitionIn` sits on the clip after a
cut (refused on the first clip) and never moves output time: each side gives
`h = min(duration/2, prevLen/2, thisLen/2)` (`transitionHalf`, mirrored in Rust).
Export pads each side of a crossfade with `h` of its frozen edge frame (and
silence), then `xfade`/`acrossfade` overlap the padded clips by `2h`, so the
joined length is exactly the timeline length and no removed source is
revealed. A dip fades the last `h` of one clip to black and the first `h` of
the next up, with matching audio fades.

**Edits carry timing.** Pieces cut from a clip (`deleteWords`, `splitClipAt`,
`trimSourceRanges`, `keepOutputRange`) keep its speed and mute; the transition
stays on the first piece and the hold on the last (`inheritTiming`). Each
piece is also tagged with the segment it came from, always as
`inheritLineage(inheritTiming(piece, seg), seg.id)`: `inheritTiming` returns a
new object and lineage lives in a WeakMap keyed by object identity, so tagging
first would be lost. Retiming matches by that lineage (owner), for footage and
for holds (`mapHold(e, newTl, t, same)`), so a duplicated clip's hold and
content stay on the copy. `restoreWords` only joins a restored piece with a
touching clip of the same speed and mute when no hold or transition would end
up in the middle. `setSegmentTiming` (store: `setSegmentTiming`, one undo step) re-times chapters,
zoom regions and music offsets through `retimeAfterEdit`, which follows content
through source time and holds through `mapHold` (same frame, same offset).

**Consumers of output time** all use the mapping: transcript click-to-seek and
paragraph times, playhead and `playbackPosition`, live captions and SRT/VTT
(`captions.ts`), auto chapters, zoom retime and auto zoom, cursor overlay
(preview and `cursor_export.rs`), waveform peaks (`waveformView.ts`: holds read
silent), agent plan diffs, chapters / music / range export (Rust uses
`output_duration`), annotations retime and keystroke captions (TS and
`annotations_export.rs`), and the clip lane's edge drag and playhead snap
(4.41.0). Known gap: FCPXML keeps every clip's output length on the spine but lists speed,
holds, mute and transitions in `unsupported`.

**Preview.** Still the single `<video>`: `playbackRate` = user rate × clip
speed (pitch preserved by WebKit), `muted` = user mute || clip mute, applied on
every clock tick and seek. A hold pauses the element on the frame just before
`sourceOut` and a rAF timer advances output time, then continues to the next
clip; `onPause` ignores the deliberate pause. A dip is drawn as a black overlay
with the export's ramp. A crossfade cannot be shown with one decoder, so the
preview shows a "Crossfade · rendered on export" badge over its window. The
scrubber marks speed (blue), holds (amber) and transitions (white tick).

**Export.** `src-tauri/src/retime.rs` builds the clip section of the graph only
when `Project::has_timing_effects()`; otherwise `build_reencode_argv` is byte
for byte unchanged. Clips with speed, a hold or crossfade padding (and every clip
once any crossfade exists, since `xfade` needs one rate and timebase) are
resampled to the export rate: the requested fps, else the first source's rate
as a rational (29.97 is `30000/1001`), capped at 60 (VFR screen recordings can
report a huge `r_frame_rate`; an explicit export fps is capped at 120). Mute- or
dip-only clips keep their source frames, so VFR footage stays VFR. A resampled
clip is `trim,setpts=(PTS-STARTPTS)/speed,fps=R:eof_action=pass,tpad(clone),
…,trim=end_frame=N`: `fps` must sit before `tpad` (ffmpeg 7.1's `tpad` pads
nothing straight after `trim,setpts`), `eof_action=pass` keeps a sub-frame clip
from rounding to no frame, and `N` comes from the rounded *timeline* boundaries
(`round(end·R) − round(start·R)` plus crossfade padding), so rounding never
accumulates. Audio is `atrim,atempo…(chained within 0.5–2),apad,atrim` to exactly
`N/R` seconds with `asetpts=N/SR/TB` (`atempo` fed digital silence otherwise
emits timestamps `concat` rejects). Runs between crossfades are `concat`ed and
joined with `xfade` at frame-exact offsets and a constant-power `acrossfade`
(`qsin`, at most −3 dB at the cut, since each side is padded with silence).
A resampled clip that rounds to zero frames is left out of the graph. Audio stems
use the same clips. Smart-cut stream copy is disabled for any project with a
timing effect (`smart_cut::is_eligible`). Real-ffmpeg tests: output length (video
frames and audio) against the mapping, beep timing, held frame, dip, 200 short
clips at odd speeds (picture frames = sound length = planned frames = mapping),
crossfade loudness and the VFR fixture.

## Recorder

The in-app recorder (v4.7.0) captures the screen, screen + camera
(picture-in-picture), camera, or a microphone-only voice-over.

**The 4.18.0 native branch, integrated in 4.21.0, prefers the native capture helper** (`yusafcut-capture`, Swift,
ScreenCaptureKit + AVFoundation; see `docs/native-capture.md`): separate aligned
tracks, cursor/click/key events, window capture, system audio, one set of files
per take (pause happens inside the helper). Device indices ≥ 1000 belong to the
helper's listing; `start_recording` routes on that. If the helper is missing or
fails to start, the take goes through the **ffmpeg avfoundation path described
below**, which is unchanged. `src-tauri/src/native_capture.rs` holds the protocol
client and mapping logic; `recording_state.rs` has `NativeSession` beside the
ffmpeg `ActiveSession`.

### Recording hand-off (4.49.0, review fixes shipped as 4.50.1): playable first, camera and checksum later

Measured cause (`docs/performance/recording-to-editor.md`): a native screen + camera
Stop re-encoded the whole take to burn in the camera (about 0.26 s per recorded
second), and the import read the whole file for its SHA-256 before the clip was
inserted. Both are now off the Stop-to-editor path.

```
stop_native ─ plan_stop_handoff(opts, tracks)              (native_capture.rs, pure)
   │  screen+camera with both tracks: playable = screen (video -c copy) + mic/system mix
   │                                  deferred_camera = tracks/camera.mp4 (left as is)
   │  every other mode / missing track: unchanged finalize_args
   ▼
RecordingResult { path, …, camera?: { path, offsetSec: 0, pipCorner, pipSize } }
   ▼
importFinishedRecording → appendRecordingToProject
   probe_media (ffprobe only, sha256 "") → entry.pendingCamera = { tracksDir, pip… }
   → addMediaWithTranscript → editable / playable
   ├─ hash_media ─▶ attachDeferredChecksum(projectId, mediaId, path, sha)
   ├─ cursor / transcript attach via resolveRecordingSource(projectId, media)
   └─ pendingCamera? ─▶ runCameraComposite (also resumePendingCameras on project open)
        composite_recording_camera({tracksDir, screenPath, pip…}) (job "composite",
          nice 10, cancellable, FIFO, argv = camera_composite_args)
          ─▶ Rust: composite_lines_up(video-stream length, size, sound) else refuse
        ─▶ probe ─▶ compositeMismatch? ─▶ wait for pause ─▶ sharesFile? ─▶ swapToComposite
        ─▶ hash_media on the composite ─▶ attachDeferredChecksum
```

**Design choice: deferred composite that swaps the clip's file, not a separate
camera layer.** Preview and export only know one file per media entry today, so a
separate camera layer would export without the camera (a regression). The background
job writes the file Stop used to write (`camera_composite_args` is `finalize_args`
for screen + camera) with one change since 4.49.1: the overlay uses
`eof_action=pass` instead of `shortest=1`. With `shortest=1` a camera lost mid-take
(1.5 s of a 4 s take) produced a 1.5 s picture inside a 4 s container (the container
length is the `duration=longest` audio mix); now the bubble just disappears and the
picture spans the screen track. The media entry is pointed at the composite only
when that cannot move an edit or change what is heard:

- same project (the job is cancelled on a project switch and its result dropped);
- the entry still points at the screen file it was inserted with (a relinked or
  replaced entry is never touched), and no OTHER entry in any undo / redo state uses
  that file or its checksum (`sharesFile`), so mask identity by path / checksum never
  splits between a swapped entry and its twin;
- in Rust, before the path is returned: the VIDEO streams are equally long (within
  0.07 s), same picture size, same audio presence and sample rate
  (`composite_lines_up`); in the editor again: size, audio presence, container length;
- playback is paused (the `<video>` source changes).

The swap is not an undo step: `src/lib/recordingHandoff.ts` rewrites the entry in
the present AND every undo / redo state, mapping one old object to ONE new object,
so the object-identity checks of `attachTranscript` / `attachCursorTrack` keep
working through undo, and Undo never brings back the camera-less file. It marks the
project unsaved (the saved file must reference the composite) and clears the
checksum, which is then computed for the composite; fps and sample rate come from
the composite. This was preferred over a `recordingGroup` schema change because it
needs no new preview/export path and every state it can produce is one the app
already handles (a single-file media entry).

**Pending marker (4.49.1).** Until the swap, the entry carries an optional
`pendingCamera: { tracksDir, pipCorner?, pipSize? }` (`edl.ts` / `edl.rs`
`PendingCamera`; serde default, a malformed value is dropped instead of failing the
load, older builds ignore and drop it). It is saved with the project, so a quit,
reload, project switch or save before the swap does not lose the camera:
`resumePendingCameras` runs at `initRecorder` and whenever the open project changes,
one composite per entry (`compositesInFlight`). Outcomes (4.50.2):

- swapped: marker removed by the swap. `swapToComposite` requires the PRESENT entry
  to match; if only undo / redo states hold it (insertion undone) nothing is swapped;
- definite refusal: marker cleared with `clearPendingCamera` (project marked unsaved,
  toast names `tracks/camera.mp4`). Definite means a Rust error prefixed
  `camera composite refused:` (`COMPOSITE_REFUSED`: tracks folder gone, no separate
  tracks, screen file outside the take, `composite_lines_up` mismatch), the editor's
  `compositeMismatch`, or `sharesFile`;
- transient (cancel from the Jobs list, ffmpeg killed, ffprobe / I/O failure, clip
  file missing, insertion undone): marker kept, "Camera not added yet", retried on
  the next open;
- interrupted by a project switch: job cancelled, marker kept; if the same project
  is open again when the run settles (A -> B -> A) it restarts immediately.

Composites are named `camera-composite-<uuid>.mp4`; one that is not swapped in is
deleted with `discard_recording_composite` (only that name pattern directly inside
a `rec-*` take folder; the hand-off file `screen-camera-*.mp4` can never match). The
job removes its `.partial` file on cancel / error and a composite that failed the
Rust check, and its output when it was cancelled while renaming. Rust keeps one
running composite job id per take folder: a new request for the same take (a
webview reload abandons the old caller) cancels the old job, then deletes the
take's `camera-composite-*.mp4` files that are not in the request's `keep` list
(every media and overlay path of the project, present and undo / redo, compared
canonically). `composite_lines_up` compares video-stream lengths; for a sparse /
VFR hand-off (video shorter than its container) it also accepts a composite video
that is not shorter and sits in an equally long container. The screen-only hand-off file is NOT deleted after a swap: saved project
files, snapshots or another window may still reference it (undo history in this
window is rewritten, but files on disk are not); it stays in the take folder.

**Deferred checksum.** `probe_media` returns the `SourceMedia` with `sha256: ""`
(the existing "no checksum recorded" value; nothing is invented). `hash_media`
runs afterwards and `attachDeferredChecksum` writes it only to the entry of the same
project and media id that still points at the hashed path and still has none;
no undo step, the project stays clean (persisted on the next real save, like
`backfillChecksums` on open, which also retries a failed hash). While absent:
mask identity (`sameFile` / `same_file`) matches by path only (a copy of the take
at another path is recognised once the checksum lands); relink falls back to its
structure check (`judge_relink`); the transcript cache is keyed by checksum and is
neither read nor written for media without one (`transcriptCache.ts`, previously
every unhashed file shared one key); the preview proxy fingerprint includes the
stored checksum, so a proxy requested before the hash lands is keyed differently
from one requested after. `import_media` (probe + hash joined) is unchanged for all
other callers (file picker, drag and drop, music, overlays, voice-over takes).
`edl.rs` now defaults a missing `sha256` to "".

**Not changed:** camera-only, screen-only and voice-over Stops; the FFmpeg
fallback recorder still composites per segment at Stop; session ids, duplicate
completion (`importedSessions`), device-loss warnings and partial-take recovery
(`NativeTracks::scan`) are as before; Stop warnings (e.g. the raw screen copy
when the audio mix failed) still reach `RecordingResult.warning`. Limitations: an
export started before the swap renders without the camera; a project closed without
saving after the take loses the take as a whole, as before. The preview proxy can be
built twice (before and after the checksum attach / swap). The composite is still
FFmpeg (background); no native preview or export exists, and the native engine
(`docs/native-engine.md`, `native/yusafcut-engine`) is a gated contract slice that
nothing calls. All of this is agent-verified by automated tests only; the app was not
run against a real capture.

Data flow:

```
RecorderDialog / ⌥⌘R ──▶ recordingStore.beginCountdown()
                              │ 3-2-1 · minimise window for screen modes
                              ▼
                    start_recording(opts)          (commands/record.rs)
                              │ spawns ffmpeg → recordings/rec-<id>/seg-000.mp4
      pause ⌥⌘P ──▶ pause_recording  — sends `q`, segment is finalised
      resume    ──▶ resume_recording — spawns seg-001, seg-002, …
      re-record ⌥⌘E ─▶ cancel_recording + start_recording (same opts)
      stop ⌥⌘R  ──▶ stop_recording   — concat demuxer joins segments (-c copy)
                              │ RecordingResult { path, durationSec, mode }
                              ▼
              importMedia → transcribe (best installed model)
              → snapWordsToSilences → addMediaWithTranscript
              → segment APPENDED at the end of the EDL
```

Key pieces:

- Recording safety (4.16.1): segments are fragmented MP4 (`frag_keyframe+empty_moov`,
  `-flush_packets 1`, a keyframe every second) so a crash loses about a second
  instead of the whole take. Screen + camera record to two files
  (`seg-000.mp4`, `seg-000.camera.mp4`) from one ffmpeg process with no filter
  graph; `stop_recording` composites each segment from the finished files
  (`composite_args`), then remuxes or joins to a normal faststart MP4. A failed
  camera or composite falls back to the screen alone. Real-ffmpeg tests cover the
  composite and a killed recording.
- `src-tauri/src/recorder.rs` — pure, unit-tested: avfoundation device-list
  parser, per-mode ffmpeg argument builder (including the `scale2ref` +
  `overlay` PiP filter), concat manifest builder.
- `src-tauri/src/recording_session.rs` — the authoritative session: pure state
  (id, phase, backend, mode, media-time elapsed, markers, error, monotonic
  `revision`), action authorization (`authorize` before and after the action
  lock), the per-session abort signal, and `or_cancelled`. Published as
  `record:snapshot`; fetched with `get_recording_snapshot`.
- `src-tauri/src/commands/record.rs` — owns the capture processes and reports every
  change to the authority; actions `start/pause/resume/stop/cancel/restart/mark`
  take a session id; `record:finished` + pending results for the importer.
- `src-tauri/src/controller.rs` + `controller.html` + `src/controller/` — the desktop
  recording controller window. `controller_view(snapshot)` (pure) decides
  closed/hidden/shown (never shown over FFmpeg screen capture); `sync` creates, shows,
  hides or destroys the window from the authority's sink; position is persisted and
  clamped with `clamp_to_monitors`. The webview mounts only `ControllerApp`, which
  mirrors snapshots (`startSnapshotMirror`) and sends session-id actions. Native
  exclusion: `CaptureCore/Exclusion.swift` + `RecordingSession.resolve/startExclusionWatcher`.
- `src/stores/recordingStore.ts` — mirror of the Rust session + action client (countdown/import are editor-local); session state machine
  (`idle → countdown → recording ⇄ paused → finalizing → processing`),
  device defaults, persisted options, global-shortcut registration
  (`tauri-plugin-global-shortcut`, reconciled by `syncShortcuts` whenever the
  settings or the session phase change), mark-a-moment markers, auto-append
  pipeline. `runRecorderAction` is the single entry point shared by shortcuts,
  the menu-bar item and the HUD.
- `src/lib/shortcuts.ts` — the shortcut registry: actions, defaults, canonical
  accelerators, validation (modifier required, reserved system combos),
  conflict detection and Mac-style labels. `src/lib/settings.ts` +
  `stores/settingsStore.ts` persist shortcuts and recording defaults and
  sanitise whatever is loaded, so a bad file can't leave the app without a
  working shortcut.
- `src/lib/editorShortcuts.ts` — the editor hotkey registry (Space, J/K/L, I/O,
  B, X, extract, delete, undo/redo, save, export): defaults identical to the old
  hard-coded keys, per-action text-field scope, auto-repeat and
  processing-lock flags, and `matchEditorShortcut`. It reuses the accelerator
  grammar and reserved list from `shortcuts.ts`; bindings persist in
  `settings.editorShortcuts` and are rebindable in Settings. Conflicts are
  checked across both the editor and the recorder (global) maps, so a key can
  never fire both. `hooks/useKeyboardShortcuts.ts` only matches an event and
  runs the action; it ignores IME composition, auto-repeat (except undo/redo),
  open modal dialogs / menus (`role=dialog|alertdialog|menu`, `aria-modal`;
  `aria-modal="false"` popovers don't block) and, per action, inputs and the
  transcript. UI hints read the live binding via `useEditorShortcutLabel`.
- Menu bar: `src-tauri/src/tray.rs` builds the tray item; `lib/trayModel.ts`
  decides its title (`● 01:23`), tooltip and which rows are enabled for each
  phase; `update_tray` applies it and row clicks return as `tray:action`.
  YusafCut minimises while the screen is captured, so the menu bar and the
  shortcuts are how a take is controlled.
- Settings tab (`panels/SettingsPanel.tsx`, pinned to the bottom of the rail):
  click a shortcut and press the new keys; one-press start, hide-window,
  auto-transcribe, markers-as-chapters and the countdown length.
- `src/components/Recorder/` — `RecorderDialog` (compact ≈460 px setup panel: Screen / Camera /
  Audio, Display / Window / Area, permission rows, camera + microphone previews, advanced
  section, Start with a visible disabled reason), with `SegmentedRadio` (keyboard radio
  group), `SourcePreview` (helper thumbnail + area drawing), `useMediaPreview`
  (webview `getUserMedia` camera preview / mic meter, best effort, released on close) and
  `RecordingHUD` (floating live pill). Pure logic — mode mapping, `startBlocker`,
  permission needs, area geometry, `toStartOptions`, `deviceChanges` — is in
  `src/lib/recorderSetup.ts` (`tests/recorderSetup.test.ts`). New IPC:
  `requestRecordingPermissions`, `openPrivacySettings`, `recordingThumbnail`;
  `RecordingDevices.displays` carries display point sizes for area selection.

Pause/resume never re-encodes: every segment uses identical encoder settings,
so the final join is a lossless stream copy.

## UI loading pattern

Every operation that blocks the UI **must** show a progress indicator. The
`uiStore` tracks five loader states:

| Field | Shown when |
|---|---|
| `mediaLoading` | ffprobe probe in progress (import or project open) |
| `transcribeProgress` | whisper-cli transcription running |
| `exportingProgress` | ffmpeg export in progress |
| `modelDownloadProgress` | model .bin/.zip download in progress |
| `editOperationLabel` | any heavy synchronous edit (Trim Silences, etc.) |

For synchronous heavy operations (anything that runs on the JS main thread and
blocks for > 100 ms), use the double-`requestAnimationFrame` deferred pattern
so React renders the dialog before the work starts:

```ts
setEditOperationLabel("Doing X…");
requestAnimationFrame(() => {
  requestAnimationFrame(() => {
    try {
      doHeavyWork();
    } finally {
      setEditOperationLabel(null);
    }
  });
});
```

## Transcription engine

YusafCut uses **whisper.cpp** exclusively via the `whisper-cli` sidecar with Core
ML + Metal acceleration. Key CLI flags for timestamp accuracy:

- `--split-on-word` — per-token word boundaries
- `--word-thold 0.01` — keep all tokens even with low probability
- `--max-len 0` — unbounded segment length; prevents timestamp compression drift
- `--best-of 5 --beam-size 5` — beam search for transcript quality
- `--dtw <preset>` — DTW cross-attention timestamp refinement, all models
  including `large.v3` / `large.v3.turbo` (dot-form preset names; the parser
  prefers the emitted `t_dtw` values and falls back to standard offsets)

If whisper-cli rejects the DTW preset (stale binary), the transcription is
retried once without `--dtw` rather than failing.

`parse_whisper_json` merges BPE tokens that have no leading space into the
previous word, so names and contractions stay whole. English/auto runs pass a
disfluent `--prompt` so hesitations are transcribed rather than dropped.

After transcription, word boundaries are snapped to ffmpeg-silencedetect
edges by `src/lib/timestampSnap.ts` (max 120 ms adjustment) so cuts always
land in silence, never mid-word.

WhisperKit (ANE) was removed in v3.2.0 because quantized models produced
inaccurate word timestamps causing video/text drift. To restore it, run:
`git show 4726d25:src-tauri/src/commands/transcribe.rs`

## Performance tooling (4.29.0)

- `scripts/bench/*.mjs` drive the production builders, not hand-written ffmpeg lines:
  `export-matrix.mjs`, `analysis-matrix.mjs`, `whisper-matrix.mjs`, plus `compare-words.mjs`
  (word-timing deltas). Fixtures live in `scripts/bench/fixtures/`, shared helpers in `scripts/bench/lib/`.
- `src-tauri/examples/export_argv.rs` and `analysis_argv.rs` print the argv that
  `commands/export.rs` and the proxy/waveform builders emit, so the harness benchmarks the real command lines.
- `src-tauri/src/perf_spans.rs`: opt-in timing spans (`YUSAFCUT_PERF_SPANS=1`), bounded ring of 4096, no paths.
- Transcription backend ladder (Core ML + Metal, then Metal-only, then CPU) lives in
  `src-tauri/src/commands/transcribe/backend.rs`; the backend used and per-stage timings are returned on each transcribe result.
- Results and methods: `docs/performance/*.md`, raw data in `docs/benchmarks/`.

## Native media engine, slice 1 (4.49.0)

Contract: `docs/native-engine.md`. Off by default; nothing in the app calls it yet.

```
Project (EDL) --compileRenderPlan (src/lib/nativeEngine.ts)--> RenderPlan JSON
   chooseEngine(plan, caps, {settings}) -> "fallback" (default) | "native"
   caps <- invoke("native_engine_capabilities") <- engine_bridge.rs
                                                    runs `yusafcut-engine capabilities`
native/yusafcut-engine: EngineCore (plan, validator, PlanTiming)
                        EngineMedia (EngineCapabilities, PlanComposition -> AVMutableComposition)
```

- `PlanTiming` (Swift) and `planLayout` (TS) are one rule set (90 kHz ticks,
  error-diffusion frame quantisation); `tests/fixtures/native-engine-timing.json`
  is asserted by Vitest against `edl.ts` and by Swift against real compositions.
- The helper is found like the capture helper (`YUSAFCUT_ENGINE_BIN`, debug
  copies, next to the executable) but is not bundled, so release builds report
  `helper-missing`.
- Only the `probe` level exists (composition timing). Preview, export and Metal
  compositing are future slices; every unsupported feature has a stable fallback code.

## Why a single `<video>` element

We chose one `<video>` element driving the source media, with the player
jumping over deleted ranges in `timeupdate`. Browsers seek MP4s in tens of
milliseconds, which satisfies the ~50 ms accuracy target in the spec.

Creating a second `<video>` node when the layout switches from the landing
screen to the editing view would unmount and remount the element, dropping
the loaded source and decoded buffers. The `EditorLayout` component always renders the
same wrapper around the single `VideoPreview` instance and only toggles
CSS classes to move it between the landing and editing layouts.

## UI layout

`EditorLayout` is the root shell component (v4.6.0). It renders:

- **StartScreen** — overlay shown while `project.media` is empty (drops are handled by `App.tsx`)
- **TopBar** (56 px) — Project menu (New/Open project, Open video, Add clip,
  Recent projects, Snapshots, Close), project name, dirty indicator,
  a centred live "time removed / % shorter" chip (original media duration
  minus `totalDuration`), Record, Undo, Redo, Save, and a primary Export
  button (dispatches `yusafcut:export`). There are no workspace modes.
- **EditorSidebar** (left, fixed) — 68 px `ToolRail` (icon + label per panel) + 352 px `InspectorPanel`
- **TranscriptEditor** (centre, resizable) — shown only when a transcript exists,
  always editable, with no toolbar of its own. Set in the system serif at 21 px;
  filler matches are highlighted from `fillerStore`
- **PreviewWorkspace** (right, flex-1) — wraps the single `<video>` instance; previous / next cut buttons (`lib/cuts.ts`) and live captions sit on the controls
- **BottomTimeline** — lane visibility is a persisted view preference (`lib/timelineView.ts` + `stores/timelineViewStore.ts`, View menu in `Waveform/TimelineViewMenu.tsx`), separate from the EDL and undo history; ruler, waveform, clip bar (`ClipLane`), cut map, chapters and zoom lane (`ZoomLane`; `Waveform/ExtraLanes.tsx` holds waveform + cut map) in a flow layout, shown only when media is loaded. The transcript is laid out by `lib/transcriptLayout.ts` in output order (never source order), and words inside zoom regions carry `data-zoom`
- **StatusBar** — project stats
- **Toolbar** — renders only its modal dialogs; no visible chrome

Panels are declared in `components/editor/sidebar/registry.tsx`, all always
available, in rail order: Media, Transcribe, Cleanup, Chapters, Zoom, Look, Find,
Tools, Music, Export, with Settings pinned to the bottom. `EditorSidebar` composes `ToolRail` (one icon per registered panel)
and `InspectorPanel` (renders the active panel component). Panel state lives
in `editorUiStore` (`setActivePanel` toggles the drawer, `openPanel` never
closes it). Importing media with no transcript opens Transcribe; when a
transcript first appears the Cleanup panel opens.

- **Cleanup** (`panels/CleanupPanel.tsx`) — filler chips with live counts, a
  review list of every match (click to hear it from one second before, Keep or
  Cut each, or cut all), a pause threshold slider with Remove / Shorten, and
  Quick trim. Operations come from `hooks/useCleanupActions.ts`.
- **Chapters** (`panels/ChaptersPanel.tsx`) — lists, renames, deletes and
  plays the project's chapters, and suggests new ones with `lib/autoChapters.ts`
  (see below). Suggestions are reviewed (checkbox and editable title each)
  before being added or replacing the existing set.
- **Find** (`panels/FindPanel.tsx`) — find, replace and delete matches; matches
  are highlighted in the transcript while it is open.

### Look (scene)

`Project.scene` (optional) frames the video: background (solid, gradient,
image), padding, rounded corners, shadow and output aspect. `lib/scene.ts` is
the single source of truth for geometry: `sceneLayout` places the video on the
canvas and `resolveSceneForExport` turns it into pixels.

- **Preview:** `lib/sceneCss.ts` turns the layout into CSS (`cqw` units, so it
  scales with the window). `VideoPreview` always renders the same wrapper
  elements and only changes their styles, so toggling the scene never remounts
  the `<video>`.
- **Export:** the frontend sends the resolved `SceneRender` in `ExportOpts`.
  `src-tauri/src/scene.rs` builds the ffmpeg graph (`color`/`gradients`
  background, an `alphamerge`d rounded mask made once at 1 fps, a blurred mask
  for the shadow, `overlay`). A scene forces the full re-encode path, because
  stream copy cannot draw it, and is ignored for audio-only exports.
- **Crop (4.35.0).** `SceneSettings.crop` (normalized, optional). `cropPixels`
  turns it into even source pixels; `sceneLayout` then lays out the *cropped*
  size, so aspect and letterboxing follow it. Preview: `sceneCss().crop` is a
  full-frame layer inside the clipped content box, offset and scaled so only the
  kept region shows (the zoom and cursor layer sits inside it, so both keep
  source coordinates). Export: `SceneRender.crop` becomes `crop=w:h:x:y` right
  before the scene scale, after zoom and cursor.
- **Device frames (4.44.0).** `SceneSettings.frame` (`{ kind: browser | laptop | phone | tablet, theme, color?, title? }`,
  absent = none). `lib/deviceFrame.ts` is pure and shared: `layoutFrame` fits the device into the padded area (screen aspect = the
  picture's for browser/laptop, fixed 9:19.5 / 4:3 for phone/tablet; the picture is contain-fitted inside the screen), and returns
  integer canvas-pixel shapes (`below` the picture, `above` it), the screen rectangle with per-corner radii, and centred text with an
  estimated-width cut (`fitText`, same string both sides). `sceneLayout` then sets `content` = the picture rect inside the screen,
  `radiusPx = 0` and adds `layout.frame`. Preview: `sceneCss().content` is the black, corner-clipped screen, `frame.inset` the picture
  box inside it (zoom/crop/cursor layers live in it, so their coordinate spaces are unchanged), `frame.belowGroup` / `above` are CSS
  boxes (`VideoPreview` renders them as siblings of `content`; the `<video>` never remounts) and the shadow is a `drop-shadow` filter on
  the outline group. Export: `SceneRender.frame` carries the same numbers; `build_scene_filter` draws background, shadow (union of the
  `silhouette` shapes), `below` shapes, the picture (`pad` to the screen, per-corner mask), then `above` shapes, each shape being a flat
  colour `alphamerge`d with a `geq` rounded mask. Browser text is an ASS file written by `prepare_frame_text` (private, removed on drop)
  and drawn by one `ass` stage right after the scene (`[outv]` -> `[scenetv]`, `alpha=1` for alpha formats), before the frame layer.
  Layer order is unchanged: per clip = privacy masks (source picture); picture layer = cursor, masks again, follow overlays and annotations, zoom, scene (picture + device), device text; frame layer = fixed overlays, fixed annotations,
  captions, key caps (full canvas). In the preview the mask, cursor, overlay and annotation layers sit inside the device's picture box; the notch / title bar draws over them. Fixture `tests/fixtures/deviceFrameRender.json` (TS-generated export payloads) is rendered by the
  Rust pixel tests, and a TS test pins it to the current geometry. All offsets and sizes are even (4:2:0), masks are rendered once (`d=1` + overlay repeat / `loop`), max 12 shapes; the plain-box path keeps its per-second `r=1` masks to keep the default argv byte-identical. Phone cutout is `dot` (default) / `notch` / `none`; traffic lights are neutral grey. Limits: no portrait tablet or landscape phone, text width is
  estimated (not measured) and Chromium and libass rasterise it slightly differently, `drop-shadow` blur is approximate.
- **Transparent background (4.35.0).** `{ kind: "transparent" }`; preview is a
  checkerboard. `build_scene_filter(.., keep_alpha)`: when the format
  `has_alpha()` (only `prores-4444`) the canvas is `color=black@0` in
  `yuva444p` and the output stays `yuva444p`; otherwise it is flattened to opaque
  black and `transparencyWarning` (exportOptions.ts) warns in the Export dialog.
  HEVC with alpha is not offered: bundled ffmpeg 7.1.1 `hevc_videotoolbox` writes
  no alpha layer. ffprobe reports ProRes 4444 as `yuva444p12le` (decoder
  native); the encoder is fed `yuva444p10le`.
- `build_reencode_argv` (export.rs) is the pure argument builder, so the real
  export is tested end to end with the bundled ffmpeg: duration, framed pixels,
  portrait canvas and image backgrounds. Those tests skip when the binary is
  missing.
- `Project.scene` is stored as raw JSON on the Rust side so saving and loading
  never drops it; the frontend validates it with `sanitizeScene`.

**Export formats (4.31.0).** `ExportOpts.format` (`ExportFormat` in export.rs,
`EXPORT_FORMATS` in `src/lib/exportOptions.ts`) picks the container and codec:
`mp4` (default, unchanged argv, golden-tested), `mov`, `prores-422`, `prores-422-hq`, `prores-4444` (alpha),
`gif`, `m4a`, `wav`. The podcast-audio preset with no explicit format means `m4a`
(`format_of` / `effectiveFormat`). `validate` rejects a path whose extension does
not match, stems on a video format, and bad ranges before ffmpeg starts.
- The graph builds only the streams that get written: audio formats concat with
  `v=0`, GIF with `a=0` (ffmpeg refuses unconnected outputs). GIF appends
  `fps` + `scale` + `palettegen=stats_mode=single` / `paletteuse=new=1` (a palette
  per frame). A whole-clip palette is only emitted at end of stream, so
  `paletteuse` would buffer every frame: measured 926 MB peak for a 60 s range
  versus a flat 88 MB per-frame. GIFs longer than 60 s (`GIF_MAX_SECONDS`) need a range.
- Smart-cut only runs for `mp4`/`mov` with no range and no stems; everything else
  takes the full re-encode path.
- `range` is cut inside the graph (`trim`/`atrim` + `setpts` on `[outv]`, `[outa]`
  and each stem), after music, zoom, cursor and scene are laid out on the whole
  timeline but before the GIF palette and the encoders, so nothing outside the
  range is buffered or encoded and progress counts only the range. Chapters are
  shifted by `chapters_in_range`.
- `stems` (audio formats) adds extra outputs to the same ffmpeg run: per source
  media a re-trimmed voice track with the other sources muted, and per music
  track an `asplit` tap after gain/offset and before ducking. Names come from
  `stem_paths`: `<name>-voice-N`, `<name>-music-N`. `preflight` refuses the export
  if a stem path exists or equals an input; on failure or cancel
  `remove_partial_outputs` deletes the main file and stems modified since start.
- `exportRequestProblem` (exportOptions.ts) mirrors the range / GIF-length checks,
  so the dialog disables Export and agents get `INVALID_INPUT` before a job starts.
  Under the podcast-audio preset the dialog switches to M4A on open and disables
  the video formats instead of remapping silently.
- Music beds split the voice once per ducking track (`vox_side`, `vox_side_1`, …),
  or not at all when nothing ducks.
- No alpha format: nothing upstream can produce transparency yet.

### Audio mixer (4.34.0)

- **Rules live twice, in step:** `Project::audible_tracks` / `resolve_fades` in `edl.rs` (export) and `audibleTracks` / `resolveFades` / `trackGainAt` / `previewVoices` in `src/lib/audioMix.ts` (preview). Solo wins over mute; with any solo only soloed tracks play. `AudioTrack.{muted,solo,fadeInSec,fadeOutSec}` are optional and omitted when off.
- **Export:** `append_music_bed_filters` iterates `audible_tracks()` only (so no input, ducking branch or stem for a silenced track; stem files are numbered over audible tracks). Per track: `atrim, volume, afade in, afade out, adelay, apad`; fades run on the track's own clock, the out-fade starts at `min(media, edit - offset) - fadeOut`. `ExportOpts.loudness_lufs` appends `loudnorm=I=T:TP=-1.5:LRA=11,aresample=48000` after the range cut and rules out smart-cut. `export_video` returns `ExportReport` (`measure_args` + `parse_audio_report`: `astats` peak and `ebur128` loudness over the written file, skipped for GIF).
- **Preview:** `components/VideoPreview/MusicPreview.tsx` (mounted in `PreviewWorkspace`) keeps one `HTMLAudioElement` per track and re-syncs on every player-store change (seek when drift exceeds 0.3 s; paused scrubs seek at 0.05 s). Not WebAudio: element volume is capped at 1.0, so gain above 0 dB is not reproduced in preview; no ducking in preview.

### Voice-over track (4.42.0)

- **Model:** a take is an `AudioTrack` with `kind: "voiceover"` plus optional `sourceIn` / `sourceOut` (trim in the take media), `mode` (`overlay` | `insert`), `overrideOriginal`, `insertSec` (hold this take owns) and `words` (its transcript, media time). `offsetSec` is the output anchor and is retimed by `retimeAfterEdit` with segment-id lineage like every track. Rust: `AudioTrack.voice: VoiceOverFields` (flattened, lenient like `SegmentTiming`, unknown keys such as `words` kept in `extra`). Fixture shared by both sides: `tests/fixtures/voiceoverProject.json`.
- **Pure ops:** `src/lib/voiceover.ts` (`captureAnchor` / `resolveAnchor`, `insertHoldAt`, `addVoiceOverTake`, `setVoiceOverMode`, `voiceOverOverflow`, `originalAudioGainAt`). Insert = split the clip at the anchor (`splitClipAt`) and add the take's length to the left piece's `holdSec`; near a cut the clip ending there is held; at the end the last clip. Everything downstream already goes through `computeTimeline` / `timeMap`, so nothing else special-cases inserts. `removeAudioTrack` gives the hold back (`adjustInsertHold`); `updateAudioTrack` resizes it on a trim and pins an insert take's offset. `MAX_HOLD_SEC` is 3600 in both languages; `HOLD_UI_MAX_SEC` (30) bounds the Timing slider.
- **Hold ownership:** an insert take owns `insertSec` of the hold that contains its `offsetSec` (`insertOwnedHold`). A new insert at a playhead inside a hold starts at that hold's END, so takes stack back to back. `adjustInsertHold(project, trackId, delta)` matches by take and shifts later takes in the same hold; `retimeAfterEdit` keeps an insert take on its hold (or a piece of the same clip with a big enough hold) and turns it into an overlay owning nothing when the held clip is gone. `setSegmentTiming` never goes below the owned part, the Timing panel edits only the rest, and `duplicateClip` copies only the user's freeze. Inserts are capped at `MAX_HOLD_SEC`.
- **Ducking:** when a bed ducks and takes are heard, the sidechain key is `[vox_key]` (voice) amixed with each take's `trk_key_i` branch, then split per ducking bed. Takes never duck themselves.
- **Recorder actions during a take:** `recordingStore.setVoiceOverActionGuard` (registered by `initVoiceOver`): the record shortcut / tray stops the take, Pause and Restart are refused with a toast. Stop uses Rust's live session id and retries once on a stale id.
- **Override and precedence:** `audioMix.replacementIntervals` (heard override takes, track order = age) and `envelopeGain` (0 inside each interval, linear 50 ms ramps outside). The clip audio is multiplied by the envelope of all intervals; a take by the envelope of NEWER takes only (`suppressorsOf`), so the newest wins and a take never mutes itself; music beds are never suppressed. Rust mirror: `Project::replacement_intervals`, `Project::suppressors_of`, `edl::envelope_expr` (ffmpeg `volume=...:eval=frame` after `asetnsamples=n=256`).
- **Export:** takes go through `append_music_bed_filters` (trim `atrim=start:end`, gain, fades, `adelay`, then the suppressor envelope). `[mainvox]` → `[mainvox_vo]` and each voice stem get the override envelope only when an override take is heard, so every other graph is byte-identical (`tests/fixtures/exportArgvGolden.json`). Stem names: `-voice-N`, `-music-N`, `-narration-N`.
- **Preview:** `MusicPreview` via `previewVoices` (trim + suppression); `VideoPreview` sets `<video>.volume` from `originalAudioGainAt` on every player tick (≈10 Hz steps on the ramps).
- **Captions:** `flattenWordsInOutputTime` drops clip words whose midpoint is inside a replacement interval and adds the words of heard takes (minus newer takes' intervals), sorted by time.
- **Workflow:** `src/stores/voiceOverStore.ts` (phases idle → countdown → starting → recording → stopping → review), UI in `src/components/Recorder/VoiceOver.tsx` (`VoiceOverBar`, `VoiceOverReviewDialog`), settings in the Music panel. Takes start with `purpose: "voiceover-take"`; Rust carries it to `RecordingResult`; `recordingStore.importFinishedRecording` hands such results to the voice-over handler (registered by `initVoiceOver`, before `initRecorder` replays pending results) and never appends them. The draft is written to localStorage (`yusafcut.voiceover.v1`) before the Rust result is acked. Races: a generation counter for countdown/start cancels, a stop during startup is deferred until the take is live, completion is deduped per session, a lost stop race waits for `record:finished`, and an idle snapshot with no result resets the workflow. `discard_recording_take` deletes only a `rec-*` folder directly inside `<app data>/recordings`, and the store calls it only when `isMediaPathReferenced` (project + undo/redo states) is false.
- **Shortcuts:** `EditorShortcutDef.scope` (`editor` | `review`). Review keys are matched only by the dialog (`matchReviewShortcut`) and conflict-checked within their scope, so they can reuse Space / O.

### Clip (timeline) editing

`lib/clipEdit.ts` edits clips, which are just source-time ranges of the EDL, so
the timeline can reach audio the transcript has no word for (a word Whisper
missed). `trimClipEdge` moves a clip's start or end within `edgeLimits` (inside
the media, at least one frame long, never into the neighbouring clip of the same
media), `splitClipAt`, `deleteClip` (ripple) and `rollEdit` (move a cut without
changing the length) round it out, and `snapTo` / `snapCandidates` give drag
snapping. A word belongs to the clip that holds its midpoint, so no word has two
owners. Extending a clip re-adds the words it now covers from `originalWords`.

Reorder, duplicate and ripple delete (`moveClip`, `duplicateClip`, `deleteClip`)
change only order or membership, never a clip's source range. Because two clips
may now play the same source range, `retimeAfterEdit` retimes chapters, zoom
regions and music starts by segment id first: edits that split or rebuild a
segment (`deleteWords`, `keepOutputRange`, `trimSourceRanges`, `splitClipAt`,
restore merges) record where the pieces came from (`inheritLineage`, a WeakMap,
never saved), and only a new segment with no recorded parent falls back to source
time, against old clips nothing else claimed. A duplicate gets fresh segment and
word ids (`<id>#<suffix>`); words pulled back by a trim or roll get a fresh suffix
whenever another clip holds the word or the clip is itself a copy, and
`baseWordId` keeps a clip from ever holding one word twice. A move keeps a chapter
at 0:00 and music that starts at or before the first cut where they are.
`dropIndexAt` picks the nearest cut to the dragged ghost's start (cuts computed
without the dragged clip, so a long clip can pass short ones); `ClipLane` drives
it with window-level pointer listeners and cancels on Esc, blur, pointer cancel
or the pointer leaving the window. Cursor tracks are source-time and need no
retiming. Each operation is one `projectStore` update, hence one undo step.

`restoreWords` in `lib/edl.ts` is the inverse of `deleteWords`: it rebuilds
words from `originalTranscripts` (runs of adjacent originals become a clip
placed after the clip before them in source time, merged when touching, padded
by `paddingMs` but never overlapping another clip). Projects without originals
return `RESTORE_LEGACY_MESSAGE` and change nothing. The transcript shows no
deleted-word chips, so there is no selection-menu entry yet; the store action
`restoreWords(ids)` and `deletedWords(project)` are ready for one.

### Relinking missing media

On `openProjectAtPath` the frontend asks Rust `find_missing_media` which source
paths are gone and `relinkStore` feeds `RelinkDialog` (mounted in
`EditorLayout`). "Locate…" calls `relink_media(path, expected)`, which probes the
file and hashes it. An identical SHA-256 is accepted whatever ffprobe reports
(`judge_relink`); only when it differs does the pure `verify_relink` (duration
within 0.1 s, fps within 0.01, equal picture size and audio sample rate) word the
refusal ("not the original file: ..." or "same length and format but different
content"). Hashes never appear in the message. Success only rewrites `media[id].path`
(`projectStore.relinkMediaPath`, also rewritten in the undo history, not an undo
step); the segments, ids and edits are untouched.

Earlier note: the project must keep the untouched transcript per media
(`Project.transcripts`), because today deleted words are dropped from both the
EDL and the localStorage transcript cache, so there is nothing to bring back.
The existing bottom timeline also draws word bars with pseudo-random heights;
the clip lane needs real waveform peaks.

### Zoom regions

`Project.zoomRegions` (optional) lists spans of the OUTPUT timeline where the
picture is magnified: `{id, start, end, scale 1.2–4, focusX/Y 0–1, easeMs}`.
`lib/zoom.ts` holds the rules and the motion:

- Regions never overlap and are at least 0.5 s. A new or moved region wins an
  overlap (neighbours are trimmed, or split around it); `normalizeRegions` and
  `sanitizeZoomRegions` repair anything loaded from a file.
- `sampleZoom(regions, t)` is the one definition of the motion: each region
  eases in and out with a smoothstep and the view centre drifts from the middle
  to its focus. `viewWindow` keeps the window inside the picture.
- Zoom follows edits: `retimeAfterEdit` (edl.ts) calls `retimeZoomRegions`, which
  maps each region through source time, so it closes up over cuts and drops
  when its content is gone, exactly like chapters.
- **Create/edit:** the selection flyout has a zoom level stepper plus Zoom in
  (a region over the selected words) and Zoom out (removes zoom there). The
  timeline's zoom lane (`Waveform/ZoomLane.tsx`) shows regions on the rail's own
  scale: drag to move, drag an edge to resize (applied once on release),
  double-click empty lane to add. The selected region's scale, focus (3×3 grid)
  and delete appear in the timeline header.
- **Preview:** `VideoPreview` applies `scale()/translate()` to the `<video>` from
  `sampleZoom(currentTime)`, clipped to the frame; no remount when toggled.
- **Export:** `src-tauri/src/zoom.rs` writes the same envelope as ffmpeg
  expressions of `t`, then `scale=eval=frame` and `crop`. The crop uses the
  scaled size computed from zoom(t), not `iw`/`ih` (crop keeps the first frame's
  size). The order is zoom, then scene, so the frame stays put while the picture
  moves inside it. Any region forces the full re-encode path and audio-only
  exports ignore it. Real-ffmpeg tests check pixels at the start, the ease
  midpoint (against the TypeScript curve), the plateau, corner focus and
  duration across cuts.

### Auto zoom and cursor tracks (4.18.0)

`Project.cursor` contains `{autoZoom, style, tracks}`. Tracks are keyed by media id
and keep source-time events and derived, sorted position samples; no raw path or
key identity is needed to reopen a project. Rust `edl.rs` preserves the optional
field as raw JSON. `sanitizeProjectCursor` validates preferences and rebuilds
position samples from events when projects are opened; store actions are immutable
and participate in normal undo history.

- `lib/cursor.ts` consumes the version-1 contract in `cursor-events.md`, ignoring
  malformed/unknown lines, sorting events and resolving duplicate position times.
  `cursorAt` interpolates positions with discrete outside/inside transitions.
  `smoothCursorTrack` uses a bounded symmetric moving time window, preserving
  endpoints and keeping outside excursions separate. Sampling is independent of
  playback history, so seeking is deterministic.
- `lib/autoZoom.ts` clips click/key triggers to each surviving EDL entry before
  clustering. It pads clusters by 0.4 s/1.2 s, uses sensitivity thresholds,
  skips high-travel paths, and feeds existing zoom normalization/add helpers.
  Proposals never overlap, cross into an unrelated shot, or use deleted triggers.
- `ZoomRegion.follow` and `focusKeys` hold absolute output times. `focusAt` samples
  them; the zoom envelope still eases focus from the picture centre. Trimming and
  moving keys preserves their relation to footage; edit retiming inserts boundary
  samples and a near-instant focus jump across a cut. Manual focus overrides stop
  following. Rust `zoom.rs` emits matching clamped linear ramps. A shared JSON
  fixture is sampled in TypeScript and checked against real exported frame pixels.
- `ZoomPanel` owns temporary proposals tied to the exact project snapshot. An edit
  invalidates a review. Generation/import paints the existing processing overlay
  before doing work; Add/Replace updates the project once. Cursor preferences
  apply to the next generation, and switching Auto zoom off does not delete
  existing reviewed timeline regions. The panel imports JSONL with a local file
  input and offers a dev-only fixture action from `tests/fixtures/cursorLogs.ts`.
- `lib/cursorStyle.ts` validates styling and samples click/idle/bounce effects in
  source time. `CursorOverlay` caches smoothing and draws local inline SVG glyphs
  plus optional blurred trails. SVG `preserveAspectRatio` matches the video's
  contain geometry, and both live inside a permanent zoom wrapper. Click effects
  from before the surviving clip's source start are omitted.

**Styled captions (4.37.0):** `captionStyle.ts` (style, safe font list, sanitize) and `captionLayout.ts` (pure
cue layout from `flattenWordsInOutputTime`, warnings, `cueAt`) feed both the preview (`CaptionOverlay.tsx`, sized
in `cqh` so it scales with the frame) and the export. With "Burn in captions" on, `buildExportOptions` sends
`ExportOpts.captions = {style, cues}` (cue and word times in output time). `captions_export.rs` sanitizes and
writes a private 0600 ASS (one event per cue, or per word when highlighting; BorderStyle 3 for the box) and
`build_reencode_argv_opts` adds its `ass=` stage on the finished frame, after zoom, cursor and scene and
between fixed annotations and key caps (see "Layer order policy" below), before the range trim and GIF palette. Frame size is the scene canvas (already the cropped canvas when a crop is set), else the export or source size; the preview caption frame uses the same `sceneLayout` canvas. When the scene keeps alpha (ProRes 4444), the `ass` stage runs with `alpha=1` so captions over transparent padding are drawn into the alpha plane. Captions force the
re-encode path; audio-only exports skip them. `Project.captions` is raw JSON in Rust. SRT/VTT still use `buildCues`.

**Cursor export (4.20.0):** Toolbar sends a typed drawCursor flag; settings/tracks
travel once in Project.cursor, avoiding duplicate activity-log serialization. `cursor_export.rs` ports the same
interpolation, smoothing, visibility, clip-start click gating and bounce model.
A blocking worker streams per-output-frame ASS vector drawings into a private
0600 temporary file, checking cancellation every frame. FFmpeg/libass draws the
six glyphs, rings and blurred trails on the concatenated picture, before zoom and
scene. Source geometry is fitted into the output picture consistently with
scale/pad. Active styling forces re-encode; audio-only exports ignore it. A Drop
guard removes activity files on completion, failure and cancellation. Glyphs use
vector paths; fonts/assets and full-resolution sprite frame buffers are not needed.

Shared JSON samples verify TS/Rust source-time parity; actual FFmpeg tests check
six glyph hotspots, click radii/hollow centers/bounce, repeated cuts and zoom/scene
composition. SVG and libass antialiasing can differ at edges. The saved synthetic
filter benchmark is explicitly not release certification. The copied FFmpeg is
x86_64 on an arm64 host; replace/validate sidecar architecture before an Apple
Silicon packaging claim. Automatic native recording-log attachment (step 7)
is implemented in 4.21.0; owner now performs all further manual app tests.

### Annotations and keystroke overlay (4.36.0)

- **Model.** `Project.annotations?: Annotation[]` (`src/lib/annotations.ts`) and
  `Project.keystrokes?: { enabled, mode }` (`src/lib/keystrokes.ts`); both absent
  on old projects. Rust keeps them as raw JSON (`edl.rs`) and re-validates with
  `annotations_export::sanitize` / `keystroke_captions`, the same rules as the
  TypeScript sanitizers (kinds `text` / `arrow` / `box`, min 0.25 s, positions
  0..1, `#rrggbb`, stroke 1–40 and font 8–200 px at 1080 lines, fades scaled to
  fit, text control characters stripped and capped at 500 code points).
- **Time.** Annotations live on the OUTPUT timeline and follow their clip like
  zoom regions: inside `retimeAfterEdit`, `retimeAnnotations` gets timelines whose
  "media" is the segment id (old) and the owning old segment (new, via
  `inheritLineage`), so an annotation on a duplicated clip stays on that copy and
  is never cloned onto the original. Source-time matching remains only for new
  segments no lineage claims. Spans close up over cuts and fully cut ones drop.
- **Space.** Normalised to the frame they are drawn in. Default: the finished
  frame (scene canvas, or the letterboxed picture without a scene), composited
  after zoom and scene so it stays put. `followZoom`: the picture, drawn with the
  cursor before zoom, so it magnifies with it.
- **Editing.** The "Overlays" tool tab (`OverlaysPanel.tsx`): add at the playhead,
  select from the list, edit numbers/text that commit on blur or Enter (one undo
  step each), colour swatches as a radio group, delete per row. Store actions
  `addAnnotation` / `updateAnnotation` / `removeAnnotation` / `setKeystrokes`
  are each one zundo step; an edit that would invalidate an annotation is refused.
- **Preview.** `AnnotationOverlay.tsx` (SVG, per-frame like the cursor layer):
  fixed layer as a sibling of the zoom wrapper (or on the scene stage), follow
  layer inside the zoom wrapper. The `<video>` never remounts.
- **Export.** `annotations_export.rs` writes one ASS script per layer (one
  Dialogue per item with `\fad`; boxes as filled or ring vector paths, arrows
  as a 7-point polygon shared with `arrowPolygon`, text in "Arial Unicode MS"
  via libass/CoreText with `{`, `}` escaped and a word joiner after every `\`).
  `export.rs` adds the follow script as its own `ass` stage after the cursor and
  the fixed one on the finished frame after the scene (`fps=…[framev]`, then one
  `ass` stage per script), before the range trim. Any of them, and captions,
  disable smart-cut; files are private and removed on drop. All ASS paths go
  through `captions_export::filter_stage` / `filter_file_arg` (two-level escaping).
- **Layer order policy** (all export stages and the preview follow it, so later
  features merge mechanically):
  - per clip: privacy masks on the source frames → trim / speed / freeze frame
    (incl. voice-over insert holds) / crossfade / dip;
  - picture layer: cursor → privacy masks again (hide the cursor) → follow-zoom media
    overlays → follow-zoom annotations → zoom → scene (incl. crop and the device
    frame shapes) → device frame text (`[scenetv]`);
  - frame layer: fixed media overlays → fixed annotations → captions → keystroke caps.
  then range trim, then the GIF palette. One argv builder, `build_reencode_argv_opts`,
  takes every prepared file in one `OverlayPaths` struct (`cursor`, `follow`,
  `fixed`, `captions`, `keys`); `build_reencode_argv` / `build_reencode_argv_with`
  are thin test wrappers, and with no overlays the argv is byte-identical to before
  (golden tests). Each frame-layer item is its own `ass` stage: `[framev]…[fixv]`,
  `[capv]`, `[keyv]`. Key caps sit at 0.94 h, or 0.80 h (`key_cap_y(true)`, preview
  `keyCapY` / `captionsAtBottom`) only when captions are burned in and positioned at
  the bottom. The preview reads the Export dialog's "Burn in captions" from
  `uiStore.burnCaptions`, so live captions alone never move the caps.
  Every frame-layer stage gets `:alpha=1` exactly when the scene keeps alpha
  (ProRes 4444 + transparent background), so overlays over transparent padding are
  drawn into the alpha plane.
- **Limits.** At most 500 annotations (both sanitizers; the panel says so and
  disables Add). Colour emoji (U+1F000–1FAFF, VS16, keycap, tags) are stripped
  from text in both sanitizers because libass cannot draw Apple Color Emoji; the
  panel shows a note. BMP symbols (⌘ ⇧ ✓ ©), CJK and Hangul render in Arial
  Unicode MS. Stored JSON is sanitised before retiming (zoom regions too), so
  hostile values cannot make an edit throw. A split annotation keeps its fade-in
  on the first piece and its fade-out on the last. Speed changes, if added, must
  update `retimeAnnotations` and `keystroke_captions`.
- **Keystrokes.** `key` events carry modifiers; `name` and `secure` only when the
  recorder option "Record key names" was on (`docs/cursor-events.md`, helper
  rules in `CaptureCore/KeyIdentity.swift`, passed as `recordKeyIdentity` /
  `recordAllCharacters` through `RecordOptions` -> `build_start_params`). Shortcut
  mode (default) shows presses holding ⌘/⌃/⌥ as e.g. "⇧ ⌘ Z" (or "⇧ ⌘ key" with
  no name); "All key presses" adds a "Typing" badge, named navigation keys
  ("↑"; Return/Tab/Space/Delete only with the second opt-in) and "Typing (hidden)" for `secure` presses, and shows a privacy note.
  Privacy rules (Option alone is no shortcut, ASCII-layout shortcut letters, window-capture frontmost check, secure input) live in the Swift `keyDescriptor` / `isInCapturedApp` / `asciiLayoutCharacter`; the take's `RecordingSnapshot.keyNames` drives the "Key names ON" indicator in the controller and tray; `recordAllCharacters` is never persisted (`recorderOpts.ts`); `stripKeyNames` (`keystrokes.ts`, `projectStore.stripKeyNames`) and `snapshots::strip_key_names_all` remove recorded names. `keyCaps` / `keyCapText` in `keystrokes.ts` and `key_caps` / `key_cap_text` in
  `annotations_export.rs` share `tests/fixtures/keystroke-identity.json`. Same combination within 1 s merges (×N), a
  caption holds 1 s, a new combination ends the previous one.

### Media overlays and privacy masks (4.43.0)

- **Model.** `Project.overlays?: MediaOverlay[]` (`src/lib/layers.ts`, output time) and
  `Project.masks?: PrivacyMask[]` (`src/lib/masks.ts`, SOURCE-ANCHORED:
  `{mediaId, srcStart, srcEnd, x, y, w, h, shape, effect, strength, color}`), absent
  on old projects, at most 200 each. Rust keeps both as raw JSON (`edl.rs`) and
  `layers_export.rs` re-validates with the same rules; `tests/fixtures/layersSanitize.json`
  is checked by both suites (hostile values, bad paths, unknown types, out-of-range
  numbers, and the legacy-mask conversion). Overlay kind comes from the file extension
  (png/jpg/jpeg/gif image, mp4/mov/m4v video); the path must be absolute with no control
  characters; images over 16384 px are refused.
- **Time.** Overlays: output timeline, like annotations (`retimeOverlays` on the shared
  `retimeSpans`; a video overlay split by an edit plays its file on in the later
  piece). Masks: never retimed. `maskOutputSpans(timeline, mask)` (TS) /
  `mask_output_spans` (Rust) derive where the masked source content is on screen —
  every clip of that source playing any of [srcStart, srcEnd] at its speed, plus a
  freeze frame of a masked last frame — each at least one frame long (extended, never
  dropped). Masks match by CONTENT (`contentKey` / `content_key`: SHA-256, else path),
  so a file imported twice under two media ids is masked in both: `sameFile` /
  `same_file`: both checksums known and equal, or equal paths (shared fixture
  `contentPairs`); checksums are backfilled on open. A permanent TS-vs-Rust parity
  test derives spans for 400 seeded random timelines (`maskSpansParity.gen.ts`). So duplicates,
  moves, restored words and speed changes are covered with no bookkeeping. Old output-time masks are converted on load (`migrateMasks` /
  `source_masks`, one source mask per clip touched; untouched ones are dropped with a
  red toast).
- **Space.** Overlays: normalised to the finished frame (canvas with a scene, else the
  letterboxed picture), or to the picture with `followZoom`. Masks: normalised to
  their own source's picture, so they follow zoom and crop, and a 4:3 source in a 16:9
  export is masked where it is pillarboxed. A mask is a static region: it does not
  track moving content (the panel says so and warns when a mask overlaps a `follow`
  zoom region).
- **Export** (`layers_export.rs`, wired in `build_reencode_argv_opts`). Masks run PER
  CLIP: `clip_mask_stage` reads `[k:v]`, trims to the clip's source range ± 1 s and
  applies `mask_chain` in SOURCE time with one source frame of padding, on the source's
  own frames with NO rate conversion first (a variable-rate frame is masked before any
  later `fps` duplicates it), then converts to the source's rate and masks AGAIN
  (`two_pass`: repeats of a pre-span frame that now sit inside the span are masked;
  dim-surround in pass 2 only, so each frame on screen in the span is dimmed once). The region comes from the decoded frame (`Geom::Frame`:
  `crop=w='…iw…'`, `overlay=x='…W…'`), never from stored sizes; strength scales with
  the source's short side (`mask_scale`, which refuses the export when the size is 0).
  A video overlay whose file is masked footage gets `overlay_mask_stage` on its own
  input, spans shifted by its `trimIn`;
  the clip's own chain (plain `trim`, or `retime::video_chain` via `append_clips`'
  `sources`) then reads that label, so speed, `tpad` freeze / crossfade padding,
  `xfade` and dip fades only ever see masked frames. `mask_chain`: `split` → `crop`
  the even-aligned region → `gblur` (sigma ≥ 6 px) / `pixelize` (block ≥ 8 px) /
  `drawbox` fill (+ `geq` ellipse alpha) → `overlay` back with `enable` over the
  spans; dim-surround darkens with `lutyuv` and puts the region back. Pixels outside
  the region are bit-identical (real-ffmpeg test). When the cursor is drawn, the masks
  (not dim) run again after it on the output picture, spans widened by the longest
  transition half (`Pic::CursorMasks`). Key caps: presses inside a mask's source span
  are dropped and captions are cut where a mask span starts (`keystroke_captions` /
  `keystrokeCaptions`). Overlays: one extra input each after the sources:
  `-protocol_whitelist file`, an explicit demuxer (`image2 -pattern_type none`, `gif`,
  `mov`), `-max_pixels`; stills are one frame repeated in the graph with
  `loop=-1:1,trim=duration`, GIF `-ignore_loop 0 -t`, video `-ss trimIn -t`; then
  `setpts` to the start, `scale`, `format=rgba`, optional `geq` corner radius, alpha
  `fade`s, `colorchannelmixer=aa` opacity, `rotate` (transparent corners), and
  `overlay=…:eof_action=pass:format=auto:enable=…` centred on the box. `format=auto`
  keeps the alpha plane of a transparent ProRes 4444 frame. "Include audio" adds
  `[k:a]` with gain, fades and `adelay`, mixed after the music (`amix … [outa_ov]`),
  before the range cut and loudnorm. Masks and overlays disable smart-cut; preflight
  refuses a missing overlay file.
- **No unmasked side outputs.** Everything after the per-clip mask stage (transitions,
  range trim, GIF palette, contact sheet, encoder) only sees masked frames; stems are
  audio-only; project snapshots hold JSON only. Not masked, by design: the source
  files, the preview proxy cache (`preview-v1`) and, when "Show masks in preview" is
  off, the preview itself. FCPXML points at the source media: the export asks first
  (`FcpxmlMaskDialog`, Cancel default) and lists masks as NOT APPLIED. Masks do not
  redact the transcript, captions, SRT / VTT, chapters or audio (the panel says so).
- **Check coverage.** `mask_coverage_sheet(opts, maskId)` runs as a cancellable job
  (`JobKind::Export`, `preview::run_ffmpeg`): `coverage_times` picks, for every place the
  mask is on screen (up to 6), the frame just before it (longest transition half + a
  frame), its first, middle and last frames and the frame just after; the export graph
  for that range (cursor included) ends in `select=…,scale=480:-2,tile=5xN`; the PNG is
  written to the temp folder, returned as bytes and deleted.
- **Preview** (`LayerOverlays.tsx`): `MaskLayer` inside the zoom wrapper right after
  the `<video>`, each mask in an aspect box of ITS source (CSS `backdrop-filter` blur, a
  canvas pixelate that starts as a solid fill, coloured / box-shadow boxes for solid and
  dim), shown when the playhead is in one of its derived spans; `MediaOverlayLayer`
  for follow overlays inside the wrapper and fixed ones beside the fixed annotations.
  Video overlays mount 1 s before their span, sync to the playhead like `MusicPreview`
  (seek when > 0.3 s off), are muted unless audio is included, and unmount after the
  span. A file that fails to load shows a striped placeholder.
- **Panel.** `OverlaysPanel.tsx` sections "Images and videos" (add via the file dialog
  + `import_media` for size / length / audio / streamed SHA-256, list with Missing
  badges from `find_missing_media`, Relink that refuses a checksum mismatch and
  rewrites undo history like `relinkMediaPath`) and "Privacy masks" (static-region and
  not-the-transcript note, source and first-on-screen times (edited in output time,
  mapped back to source), occurrence count, effect / shape selects, strength with the
  safe-for-text warning, swatches, follow-zoom warning, Check coverage, Show masks in
  preview). Number fields commit on blur / Enter: one undo step.

### Auto chapters

`lib/autoChapters.ts` suggests chapters from the transcript with no model:
words are grouped into sentences; every sentence boundary is scored by how
different the vocabulary is on each side (cosine distance, averaged over
window sizes of 2, 3 and 4 sentences), plus bonuses for a pause, a cue phrase
("next", "let's move on") and a speaker change. The best boundaries are kept at
least `minChapterSec` (10 s, YouTube's limit) apart, the first chapter is
always 0:00, and titles come from each chapter's opening sentence. The local
MLX sidecar's `summarise` command exists but is not wired to the app; it could
later rewrite these titles.

### Selection flyout

Selecting transcript text shows `TranscriptEditor/SelectionMenu.tsx`, a
portal-rendered toolbar over the selection: Play, Cut, Keep only, Mark, Start
chapter (an inline title field, prefilled from the selected words) and Copy.
It reads the selection from `playerStore.selectedWordIds` and the DOM range,
appears on mouse-up, and every edit goes through the normal undoable store
actions with an Undo toast.

The old two-row toolbar was removed in v4.4.0; the v4.4.0 right sidebar moved
to the left in v4.6.0. All actions are accessible through the sidebar panels,
the TopBar Project menu, or keyboard shortcuts.

## FCPXML export (4.32.0)

`src/lib/fcpxml.ts` (pure) turns a `Project` into FCPXML 1.10 and returns `{ xml, unsupported }`. `Toolbar.tsx` listens for `yusafcut:export-fcpxml` (fired by the Export tab), saves via the dialog and `writeTextFile`, and lists `unsupported` in the toast. The sequence frame rate is the first video source's; all times are whole frames as rationals (29.97 fps is `1001/30000s`), clips are contiguous in `computeTimeline` order.

| EDL feature | FCPXML |
|---|---|
| Segments (source in/out, repeats, several sources) | `asset-clip` in the spine, one `asset` per source file |
| Chapters | `chapter-marker` on the clip containing the time |
| Music tracks (offset, gain; muted/un-soloed tracks skipped) | `asset-clip lane="-1"` on the first clip, `adjust-volume` |
| Sources at another frame rate | conformed to the sequence rate, reported |
| Scene, zoom regions, cursor styling, ducking, music fades, captions, annotations, keystrokes | not exported, reported in `unsupported` |
| Speed, freeze frames, clip mute, transitions (4.38.0) | clip keeps its output length on the spine (chapters and music stay aligned) but plays at 1x with straight cuts; reported in `unsupported` |

Untested against Final Cut Pro or other importers; validated only as well-formed XML.

## Cross-platform code that isn't

The Tauri shell supports Linux and Windows, but YusafCut explicitly targets
Apple Silicon macOS. The architectural choice rests on whisper.cpp's Core ML +
Metal path and FFmpeg's VideoToolbox. We accept the lock-in for the
performance moat per spec section 1's non-goals.

## Playback, analysis and save flow (4.19.0)

`timelineIndex.ts` derives output ranges, direct segment/word references and word
occurrences once per immutable segment array. Seeks use binary search; sequential
playback advances an EDL entry so repeated source ranges remain distinct. The
single video element survives source/settings changes. `useCoalescedSeek` permits
one decoder seek plus a latest pending target, uses source/generation tokens,
forces exact drag release, and rejects stale frames. rVFC owns playing video;
audio uses RAF. Media events synchronize paused seeks and lifecycle only.

`playbackClock` is a precise imperative bus. Zoom and playhead styles paint without
large React updates; the cursor has its own tiny subscriber. Store time publishes
at roughly 10 Hz and at word/entry changes. Transcript highlighting caches DOM
word elements and touches only previous/next words, reading visibility on word
transitions. Manual wheel navigation temporarily suspends follow scrolling.

`commands/preview.rs` fingerprints source path/hash/size/mtime and format version,
then streams mono PCM into `waveform.rs` (100 peaks/second with maximum-reduced
levels). Audio PTS is padded to source origin; no PCM crosses IPC. The timeline no longer draws peaks (`AudioPeaks` was removed in 4.26.0). Proxy arguments
live in `preview_cache.rs`: bounded software H264/AAC, even dimensions, no upscale,
source timing retained, 1280/640 maximum dimension. Original media always stays in
Project and export. `usePreviewSource` caches ready paths per immutable media and
quality, ignores stale completions and falls back to original on decode failure.
Cache files are disposable, validated, uniquely staged then atomically published.
One shared semaphore bounds waveform/proxy/transcription analysis. Each worker
owns cancellation; `ExportState` checks job identity and cancellation across spawn.
Core ML model preparation retains its existing cancellation limitation.

Clip handles keep a local draft until pointer release; store trim/split/roll
operations create one revision. `Project.originalTranscripts` is optional and
mirrored by Rust. New recognition preserves the full source transcript. Legacy
edited words are not presented as complete originals, and cache v2 excludes the
old edited-EDL cache. Clip extension therefore cannot promise recovery for old
projects. Corrected surviving words take priority over original source words.

A stopped recording is imported and appended before model lookup/recognition.
Background progress is routed by media ID to a status-bar indicator, not the
blocking transcription dialog. Recognition attaches to surviving source ranges
and rebases same-document undo/redo snapshots without adding an undo-transcription
step. It cannot append to a different document or resurrect deleted clips.

All editor saves go through `SaveQueue`/`saveCoordinator`: one active and one latest
waiting immutable snapshot per normalized destination. Superseded saves report
that status explicitly; failures do not strand later saves. Completion clears
dirty only for the exact current snapshot. Rust adds a process-wide save gate
and UUID temporary paths, cleaned on failure. Undo history records only changed
project references, synchronously, so dirty/path writes create no fake undo steps.

Diagnostics are opt-in, bounded and local. Seeked-event timing and first accepted
playing-frame timing are distinct; paused presented-frame timing, JS heap, long
tasks and React Profiler callbacks can be unavailable. The Node benchmark is only
an index lookup comparison. No packaged-release p95 or memory-soak target is
claimed by these changes.

The in-editor recorder HUD is suppressed for screen modes, including pause and
finalization, because FFmpeg cannot exclude it. Camera/audio sessions honor a
persisted show/hide preference; the dedicated hide action never discards a take.
A grip stores normalized viewport coordinates on release, clamped on resize.
Countdown is painted away before capture starts. The existing menu-bar dispatcher
and shortcuts remain available independently of HUD visibility. This does not
implement the separately scoped native desktop controller or exclusion filter.

### Recording validation gap (4.19.1 audit)

The unchanged FFmpeg capture backend has an unresolved observed timer/media
discrepancy: a second audio take was paused at 12 seconds, but import and bundled
FFprobe both reported 0.501 seconds of M4A. A first uninterrupted take correctly
contained 16.640 seconds. The cause is not established. Repeat the paused-input
case while integrating the native helper and compare capture startup, first
sample timestamps, pause flushing and finalized duration. Do not infer success
from the UI wall-clock timer or from the background transcription pipeline.

### Capture timing and completion (continuation, verification in progress)

FFmpeg capture now publishes machine-readable `out_time_us` progress. Starting
waits for positive encoded media time; the live timer sums encoded time with
probed completed segment durations, excluding device startup. Pause and Stop wait
for the process terminal event before probing or moving files. A session action
gate spans finalization, and ticker IDs prevent an older take updating a newer
one. Stable file size is no longer treated as evidence that FFmpeg has exited.
The original 0.501-second take has not been reproduced; baseline UI testing did
confirm 14 seconds displayed versus 11.573 seconds saved. Final verification is
tracked in HANDOFF's live continuation log.

### Native capture integration and automatic cursor tracks (4.21.0)

Reuses source commits 76361be/09380dc, preserving the current FFmpeg media-progress
and completion code. A shared action mutex serializes both backends through stop
finalization. Native events bind to an internal session UUID; Pause/Resume command
acknowledgements own Rust phase, while helper snapshots supply elapsed media time.
A queued old helper tick cannot reverse a completed command. Public session-ID
snapshot/actions for a separate controller remain the next step.

Swift latches shared time zero at the first accepted primary sample, waits for
that sample before acknowledging Start, then writes matching manifest/header
origins and begins input monitoring. Audio/webcam-only takes do not monitor cursor
or typing activity. Stop results use probed finalized-media duration.

For native screen takes, eventsPath starts a separate metadata task after playable
media is appended. A Rust reader accepts only recording-owned events.jsonl files
under app data (128 MB limit); a bundled module worker parses the tolerant contract.
Switching documents aborts attachment. Source identity guards plus temporal-history
rebasing retain the processed track across edits/undo/redo without a metadata undo
step. Raw paths are not needed to reopen projects, and recognition proceeds in
parallel. Missing/bad logs leave the take playable with an explanatory toast.

Cursor/zoom export also supplies an animation frame cadence for sparse static-screen
input, preserving explicit export rates and higher source rates; otherwise it uses
at least 30 Hz so cursor motion is not frozen by a static source frame.

The real ARM64 Swift helper has been built. Permission/device/Spaces/control
exclusion and real cursor-log tests are owner-run; no capture success is claimed.
Native area UI/permission IPC, desktop controller, editable camera and release
performance certification remain pending. First-sample startup cancellation can
still wait for the bounded no-media deadline, to be fixed in session authority.

### Native ARM64 media packaging and verification (4.25.0)

YusafCut exclusively targets Apple Silicon (`arm64` / `aarch64-apple-darwin`).
`scripts/build-arm64-media.sh` (`npm run media:build`) builds `ffmpeg-aarch64-apple-darwin`
and `ffprobe-aarch64-apple-darwin` from SHA-256-pinned upstream source tarballs
(`FFmpeg 7.1.1`, `libass 0.17.3` with CoreText, `harfbuzz 10.1.0`, `freetype 2.13.3`,
`fribidi 1.0.16`, and `x264`) for `macOS 13.0+` with `PKG_CONFIG_LIBDIR` isolated
to the temporary static staging prefix. Both binaries have zero `LC_RPATH` entries
and link dynamically only to macOS system frameworks and `/usr/lib`.

`scripts/verify-media-binaries.sh` (`npm run media:verify`) validates `arm64`
Mach-O architecture, native execution, deployment target, dynamic linkage, all
required codecs/filters/devices, synthetic media smoke paths (including `libass`
vector cursor + zoom + scene composition), and VideoToolbox hardware encoding
before atomic installation and during `setup:all` / `build:production`.
`scripts/benchmark-media-pipeline.mjs` (`npm run media:bench`) measures median
wall time, spread, and peak RSS across the 7 core media stages. Full provenance,
checksums, benchmark measurements, and the Phase 5 native Apple media framework
follow-up plan are documented in `docs/performance/arm64-media-packaging.md`.


## Recorder bar (4.28.0)

Record opens a floating setup bar instead of the 460 px dialog. Design: `docs/recorder-bar-design.md`.

```
Editor (label "main")                         Bar (label "recorder-bar", recorder-bar.html)
recordingStore.openDialog()                   src/recorderBar/ (barStore, RecorderBarApp, Popovers)
  setupStyle "bar" + Tauri ──openRecorderBar──▶ src-tauri/src/recorder_bar.rs (create, position, hide main)
  error / "dialog" ─▶ openSetupDialog()        title "YusafCut Recording Controls — Setup" (excluded from capture)
listen recorder-bar:opts  ◀── emitTo("main") ── setOpts → persist (src/lib/recorderOpts.ts) + emit
listen recorder:open-dialog ◀─ "More options…"
onRecorderBarVisibility ─▶ barOpen; record shortcut → emitTo("recorder-bar","recorder-bar:record")
settingsStore ◀── window "storage" event ── bar writes countdown/transcribe to shared localStorage
```

The bar starts the take itself (countdown, hide bar, `startRecording`); Rust's session snapshots still drive the editor. The bar exists only while idle; Rust re-shows the main window on any non-idle to idle transition if it is hidden, and the editor restores it with `show()` + `setFocus()`.

## Agent CLI / MCP (4.27.0)

External AI tools drive the open project through the same app binary. Design, contracts and
the full tool catalog are in `docs/agent-cli-design.md`.

```
Claude Code / Codex / Gemini ──stdio JSON-RPC──▶ YusafCut mcp   (same binary, no GUI)
shell ─────────────────────────────────────────▶ YusafCut agent … (same binary, no GUI)
        reads <config>/dev.yusafcut.app/agent/connection.json
        HTTP 127.0.0.1:<random>, Authorization: Bearer <token>
                              │
Rust src-tauri/src/agent/     ▼
  server.rs (hyper)  POST /mcp, GET /v1/health, /v1/tools, POST /v1/tools/call
  mcp.rs (pure JSON-RPC) ─▶ relay.rs ── emit "agent:request" ──▶ webview
  settings.rs, security.rs (Host/Origin/token/path checks), commands.rs (Tauri commands)
                                                                  │
Webview  src/lib/agent/                                           ▼
  bridge.ts ─▶ registry.ts callTool(name, input, liveContext)
  tools/*.ts (pure) ─▶ lib/edl.ts, zoom.ts, fillers.ts, autoChapters.ts, captions.ts, projectOps.ts
  liveContext.ts ─▶ applyProject(next): one projectStore.setProject = one undo step
  plan.ts (diff for plans), schema.ts (JSON-schema subset), protocol.ts, toolTypes.ts
                                                                  │
Rust src-tauri/src/cli/       (same binary, dispatched from main.rs when argv[1] is agent or mcp)
  args.rs client.rs launch.rs stdio.rs output.rs inspect.rs mod.rs
  resources/agent/README.md, SKILL.md (embedded with include_str!)
```

- The EDL stays in the frontend. Rust relays calls and validates paths; it never edits a Project.
- Mutating tools plan by default (`confirm:false`) and apply with `confirm:true` plus a
  `baseRevision`, as one undo step. `history` undoes or redoes.
- Only one call runs at a time (relay mutex, 60 s deadline). Agent access is off by default,
  and `APP_SANDBOX_CONTAINER_ID` (Mac App Store) disables the server entirely.
- The "Project MCP Server" dialog (`src/components/Agent/AgentConnectDialog.tsx`, opened from the
  TopBar "Agent" button) toggles access and shows the CLI and MCP connection snippets.

## WordsCut brand and distribution (4.51.0)

The display name and packaged executable are `WordsCut`; `dev.yusafcut.app`, `.scribe`, `yusafcut.*` persistence/event names, Rust crate/library names and native helper paths remain compatibility anchors. Recording-controller titles change together in React, Rust and Swift so capture exclusion remains consistent. Legacy hardcoded app executable paths must be updated in external MCP clients.

The private source repository remains private. The product page and canonical release orchestration now live in `awaismirza/awaisjamil`; the earlier public distribution repository is retired. App source, installers, corresponding dependency sources and build logs are staged only in maintainer-only draft releases, never in public Git, Pages files or Actions artifacts. The manually dispatched release workflow validates credentials, unpacks a committed private snapshot, runs the source tests, builds real arm64 sidecars, signs nested Mach-O code, notarizes/staples the app and DMG, then separately downloads and verifies the exact staged candidate. It never publishes a free installer. The product page defaults to contact until an approved hosted checkout is configured. See `awaisjamil/docs/wordscut-distribution.md` for the shared local/CI commands and `docs/wordscut-release.md` for the migration ledger.

Mac App Store builds use a separate target directory and sandbox profile; persistent security-scoped file access and complete inherited-helper sandbox verification are still blockers. See `docs/wordscut-release.md`.
