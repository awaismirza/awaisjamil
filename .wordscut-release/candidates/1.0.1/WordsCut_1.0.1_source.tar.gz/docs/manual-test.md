# Manual test checklist (v1)

Until we set up an integration test rig, run through this before tagging a
release. The whole loop should take ~10 minutes on a 5-minute test clip.

## Setup

- [ ] `git clean -fdx && npm ci && cargo build --manifest-path src-tauri/Cargo.toml`
- [ ] `./src-tauri/binaries/fetch.sh` reports all three binaries present
- [ ] `npm run tauri:dev` launches with no console errors

## Import + transcribe

- [ ] Drag a `.mp4` onto the window → metadata appears in the sidebar
- [ ] Filename, resolution, duration are correct vs. `ffprobe` on the CLI
- [ ] Click **Transcribe**, pick `large-v3-turbo`, accept download prompt
- [ ] Progress bar advances; final transcript appears
- [ ] Click any word → video seeks to that timestamp
- [ ] Words highlight as the video plays

## Edit

- [ ] Select two adjacent words → press Delete → words show as struck-through
- [ ] Hit Play → audio skips the deleted range cleanly (no audible artefact)
- [ ] Cmd+Z restores the deletion
- [ ] Repeat with a longer range crossing a paragraph boundary
- [ ] Select a leading word → delete → segment trims from the start
- [ ] Select a trailing word → delete → segment trims from the end

## Save / load

- [ ] Cmd+S → choose location → `.scribe` bundle appears on disk
- [ ] Quit and relaunch
- [ ] Recent files menu shows the project; opening it restores all edits
- [ ] Move the source media file; relaunch → relink dialog appears; selecting
      the new path completes successfully

## Export

- [ ] Cmd+E → choose output → progress bar advances
- [ ] Output `.mp4` plays in QuickTime
- [ ] Output duration matches `totalDuration(project)` (within ±100ms)
- [ ] No audio glitches at cut boundaries
- [ ] Cancel works: hitting Cancel mid-export terminates ffmpeg promptly

## Performance smoke check (M2 Pro)

- [ ] 5-minute clip transcribes in < 60s with `large-v3-turbo`
- [ ] 5-minute edit exports (re-encode-all) in < 30s

## Word-sync accuracy (DTW pipeline, v4.5.0)

Transcribe a real clip ≥ 10 minutes using `large-v3-turbo`, then verify:

- [ ] Click a word near the START of the video → playback begins within
      ±50 ms of that word's onset
- [ ] Click words in the MIDDLE and at the very END → same accuracy;
      **no drift growth** toward the end
- [ ] During playback, the highlighted word matches what is being spoken
- [ ] Delete a sentence mid-video, export, and confirm the cut does not clip
      syllables
- [ ] DTW interpretation check: if every word highlight/seek consistently
      lands one word LATE, the `t_dtw` boundary interpretation in
      `parse_whisper_json` must be flipped (word start = own `t_dtw`,
      end = next token's) — fix and re-verify

## Studio features (4.13 to 4.17) — not yet verified in the running app

Do this with a real transcribed clip (build `whisper-cli` first: `npm run setup:all`).

### Sidebar and Cleanup
- [ ] The rail shows Media, Transcribe, Cleanup, Chapters, Look, Find, Tools, Music, Export and Settings (bottom); there is no Transcribe | Edit switch
- [ ] Cleanup: filler chips show counts; "Cut N fillers" removes exactly the highlighted ones; each row's Play / Keep / Cut works
- [ ] Cleanup: pause slider count changes with the threshold; Remove and Shorten cut the audio, and Undo restores the cut
- [ ] Find: matches highlight in the transcript; Replace all and Delete matches work

### Chapters and selection menu
- [ ] Chapters: Suggest produces titles you can edit; Add and Replace behave; 10 s minimum is respected
- [ ] Select words: the flyout appears on mouse-up; Play, Cut, Keep only, Mark, Start chapter, Copy and Zoom in/out all work and are undoable
- [ ] Toasts dismiss after 5 s; hovering one keeps it open

### Look and zoom
- [ ] Look: changing any control turns the frame on; preview and a real export match (background, padding, corners, shadow, aspect)
- [ ] 9:16 export letterboxes a landscape video and has the right size (ffprobe)
- [ ] Zoom regions: Zoom in over selected words animates in the preview; the lane block drags/resizes; export shows the same motion; zooms follow cuts

### Recorder, menu bar, settings
- [ ] Grant Screen Recording, Camera and Microphone permissions to the app (or the terminal in dev)
- [ ] Press the start shortcut (default ⌥⌘R): countdown, window hides, menu bar shows `● 00:01` and counts up
- [ ] Menu-bar menu: Pause/Resume, Mark a Moment, Restart Take, Stop and Add to Video, Discard all work
- [ ] Screen + camera: the finished clip has the camera bubble in the chosen corner at 18/25/33% of the screen width, and audio
- [ ] Kill the ffmpeg process mid-take (`pkill -9 ffmpeg`): the app stops the take and the footage up to about a second before the kill is still added
- [ ] Marked moments become "Moment n" chapters after stop
- [ ] Settings: rebind a shortcut (conflicts and reserved combos are refused); the new key works from another app; countdown and toggles persist after relaunch



## Auto zoom and cursor preview (4.18.0)

Verified in the running debug app with a synthetic 20-second video: open Zoom,
load the development demo, enable Follow cursor, generate/review/add four regions,
muted playback with the cursor overlay visible. Repeat on real native logs when
capture integration lands. Cursor styling export is not implemented.

- Load a JSONL file for each of two videos; save/reopen and verify tracks/settings.
- Remove or uncheck a suggestion, play another, Add; Undo removes the whole batch.
- Regenerate and Replace; changing settings or cutting footage invalidates reviews.
- Drag/resize a follow region; focus keys should move/trim with the content.
- Choose a timeline focus manually; that region stops following the cursor.
- Try all cursor shapes, colours, sizes, smoothing and click effects while playing;
  toggle idle hiding and blur, seek backwards, and verify deterministic effects.
- Add a Look frame and zoom; cursor remains inside the video frame and the video
  does not restart when styling changes. Hide the cursor and verify playback stays.
- Export a moving-focus zoom and inspect it; cursor styling remains preview only.
