# WordsCut — draft Mac App Store listing

Not submitted. Review sandbox/file-access, capture and AGPL/GPL store compatibility before upload.

Name: WordsCut
Subtitle: Edit video through words
Primary language: English (Australia)
Category: Video
SKU: wordscut-macos
Bundle ID: dev.yusafcut.app
Support URL: https://awaisjamil.com/products/wordscut/support
Privacy URL: https://awaisjamil.com/products/wordscut/privacy
Marketing URL: https://awaisjamil.com/products/wordscut
Keywords: transcript,video,editor,recording,captions,screen,voiceover

## Description

Edit words. Shape video.

WordsCut connects your transcript to your footage. Import a recording, transcribe it on your Mac, and remove words or sentences to cut the matching moments from your video.

Clean up fillers and pauses, add captions, refine the frame, and export your story. Processing happens locally on an Apple Silicon Mac. No account is required. Transcription models may download when selected.

Existing YusafCut .scribe projects remain compatible.

## Listing assets

App icon: src-tauri/icons/icon-1024.png. Website screenshots show the real app using synthetic media. Capture final store screenshots at Apple's currently accepted Mac dimensions after the sandboxed store candidate is validated; do not upload the direct-download screenshots as proof of store behavior.

## Submission gates

- Re-save/verify the canonical awaisjamil.com URLs above in the remote App Store Connect draft before any upload or submission; the earlier draft used the retired distribution site's URLs. This migration updates the local listing specification, not a store submission.

- Validate persistent security-scoped bookmarks and all reopened project media.
- Test inherited sandbox helper execution, model downloads and export.
- Validate capture and permission behavior in the signed store package.
- Resolve AGPL/GPL obligations versus store terms; retain all notices.
- Confirm final pricing, age rating, content rights and privacy questionnaire with owner.
- Obtain owner approval before accepting agreements or submitting for review.

## App Store Connect draft created — 22 October 2026

App ID 6825379087, bundle dev.yusafcut.app, SKU wordscut-macos, primary language English (Australia). Version 4.51.0 is Prepare for Submission, manual release selected, no sign-in required. Saved description, promotional text, keywords, Photo & Video category, subtitle, support/marketing and privacy URLs. No build uploaded or review submitted. Updated Paid Applications Schedule still requires owner review before submission.
