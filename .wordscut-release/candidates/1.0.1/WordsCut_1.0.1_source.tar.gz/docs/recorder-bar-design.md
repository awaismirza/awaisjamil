# Recorder bar — ScreenKite-style floating setup bar (design)

Target: v4.28.0. Replaces the 460 px `RecorderDialog` as the primary Record entry; the dialog stays as a fallback ("More options…").

## Look
One dark, opaque, rounded-looking horizontal bar floating top-centre (≈1180×76 px): close (×); mode buttons Display / Window / Area (Screenshot and Device/Sim omitted in v1); Camera chip; System-audio chip; Microphone chip (level bar); recordings-folder button; settings gear. The main window hides while the bar is up.

## Findings that shape the design
- `src-tauri/src/controller.rs` builds the controller window (`WebviewWindowBuilder`, `decorations(false)`, always-on-top, visible on all workspaces, skip taskbar, `focused(false)`, shadow). `default_position` (top centre, y+48) and `clamp_to_monitors` are `pub` and tested. `show_main_window` exists there.
- Swift `Exclusion.swift` excludes our-pid windows whose title has prefix `"YusafCut Recording Controls"`. Title the bar `"YusafCut Recording Controls — Setup"` → excluded from footage with no Swift change.
- The main window is **minimised** today by `recordingStore.ts` (`minimizeMainWindow`/`restoreMainWindow`). The countdown runs in the main store and is drawn by `RecordingHUD`; with the main window hidden the bar must own its countdown.
- `macOSPrivateApi` is false (MAS rule) → no transparent window / rounded corners in v1: opaque `#1C1C1E` bar, shadow on. A full-screen transparent Area overlay is not possible; Area is drawn on the thumbnail in a popover.
- Recordings folder: `app_data_dir/recordings/rec-<uuid>` (`commands/record.rs`).
- A borderless tao window can take key focus (Esc/Enter work).

## Decision: a new window, not the controller
Label `recorder-bar`, entry `recorder-bar.html`. The controller is idle-gated and never takes focus; the bar needs focus, device previews and permission prompts. The bar exists only while idle and is destroyed on close or when a take starts (this also releases the camera).

## WP1 — Rust + ipc contract
Files: `src-tauri/src/recorder_bar.rs` (new), `src-tauri/src/lib.rs`, `src-tauri/capabilities/recorder-bar.json`, `src/lib/ipc.ts` (only the new wrappers).
- Constants: `LABEL="recorder-bar"`, `TITLE="YusafCut Recording Controls — Setup"`, `BAR_W=1180.0` (clamped to monitor logical width − 48), `BAR_H=76.0`, `MAX_H=520.0`.
- `create()` like `controller::create` but `.focused(true)`, `.background_color(Color(28,28,30,255))`, `.visible(false)`, title `TITLE`; on `CloseRequested` → `prevent_close` + same path as `close_recorder_bar(true)`.
- `bar_frame(monitor:&Rect, scale:f64) -> (x,y,w,h)` pure + unit-tested: top centre via `controller::default_position`, then `clamp_to_monitors`. Monitor: the one containing the cursor, else the main window's, else first.
- Commands (register in `lib.rs`): `open_recorder_bar` (Err unless session phase is Idle; create/reuse, position, `show()`+`set_focus()`, THEN hide `main`; emit `recorder-bar:visibility {visible:true}`), `close_recorder_bar(restore_main: bool)` (destroy; if restore → `controller::show_main_window`; emit visibility), `hide_recorder_bar`, `set_recorder_bar_height(height)` (clamp, `set_size`, `clamp_in_place`), `open_recordings_folder` (`create_dir_all`, `open <dir>`).
- Sink safety net in `lib.rs`: snapshot phase `Recording` → destroy the bar if it exists; non-idle → `Idle` transition with `main` not visible → `show_main_window` (previous phase kept in a small `RecorderBarState`).
- Capability `recorder-bar.json`: windows `["recorder-bar"]`; `core:event:default`, `core:window:allow-start-dragging`.
- `ipc.ts` wrappers: `openRecorderBar`, `closeRecorderBar(restoreMain)`, `hideRecorderBar`, `setRecorderBarHeight(h)`, `openRecordingsFolder`, `onRecorderBarVisibility(cb)`.
- Acceptance: `cargo test` — `bar_frame` on 2880×1800@2 and on a 1280-wide monitor (width clamps; top centre at y+48·scale); idle-transition tracker unit test; `open_recorder_bar` errs when not Idle. `npm run check` passes.

## WP2 — Bar UI
Files: `recorder-bar.html`, `vite.config.ts` (third `rollupOptions.input` entry `bar`... emit `dist/recorder-bar.html`), `src/recorderBar/{main.tsx,RecorderBarApp.tsx,barStore.ts,...}`, `src/lib/recorderOpts.ts`, `tests/recorderBar*.test.ts(x)`.
- `barStore.ts` must NOT import `recordingStore`. `recorderOpts.ts` (pure): `OPTS_STORAGE_KEY = "yusafcut.recorderOptions"`, `loadStoredOpts`, `persistOpts`, `defaultDevicePatch(opts, devices)` (moved out of `refreshDevices`; WP3 later makes recordingStore import it — until then keep recordingStore untouched).
- Reuse: `recorderSetup.ts` (`toStartOptions`, `startBlocker`, `permissionIssues`, `requiredPermissions`, `modeFor`, `effectiveSource`), `useCameraPreview`/`useMicLevel`, `SourcePreview` (drag-to-draw via `onArea`), ipc wrappers.
- Tree: `RecorderBarApp` (Esc = close, Enter = start armed mode) → `BarShell` (`data-tauri-drag-region` on gaps only) → CloseButton, ModeGroup (Display | Window | Area; disabled + tooltip from `startBlocker`), PermissionChip ("Allow screen recording" / "Open Settings"), CameraChip (+popover: list, live preview, Off), SystemAudioChip (switch → `opts.systemAudio`; hidden on ffmpeg backend; no fake meter), MicChip (+level bar, popover list/"No microphone"), FolderButton, SettingsButton (popover: fps, countdown, transcribe, camera bubble corner/size, "More options…" which emits `recorder:open-dialog`, shortcuts help). Popover panels below the bar grow the window via `setRecorderBarHeight(76+panel)`: DisplayPicker (only if >1 screen), WindowPicker (hides windows titled `"YusafCut Recording Controls"…`, lazy thumbnails), AreaPicker (SourcePreview + "Record area"). `CountdownView` replaces bar content (big number, "Cancel (Esc)"). `InlineError`.
- Modes: Display with one screen → `sourceKind:"display"` + countdown; several → picker, start on pick. Window → picker, start on pick. Area → "Record area" enabled once `isValidArea`. Camera toggle sets `mode = modeFor("screen", on)`; camera-only/voice-over stay in "More options".
- Start sequence (`barStore.start`): `startBlocker` null → countdown from `useSettingsStore` `countdownSec` (read-only) → stop preview tracks → `hideRecorderBar()` → wait 2 rAF + 150 ms → `startRecording(toStartOptions(opts, devices))` → success: `closeRecorderBar(false)`; error: `openRecorderBar()` and show `InlineError`. Cancel during countdown is local (and `cancelRecording(id)` if a session id is known).
- Every `setOpts` → `persistOpts` + `emitTo("main","recorder-bar:opts",opts)`. On window `focus` → `refreshDevices`.
- Permissions: `notDetermined` → chip "Allow screen recording" → `request_recording_permissions(["screenRecording"])` then refresh; `denied` → "Open Settings" via `openPrivacySettings("screenRecording")`; still denied after grant → "Restart YusafCut to apply". Camera/mic chips ask on first enable; denied turns the chip red with Open Settings in its popover. Ignore permissions when `backend === "ffmpeg"` (Window/Area disabled there).
- Acceptance (Vitest, ipc mocked): Display one screen starts countdown, several opens picker; window picker hides own windows; Area Record disabled until `isValidArea`; start calls `hideRecorderBar` before `startRecording` and `closeRecorderBar(false)` after success, on failure re-opens + shows error; Esc during countdown cancels with no `startRecording`; `setOpts` persists under `OPTS_STORAGE_KEY` and emits `recorder-bar:opts`; permission chip states; import-guard test (bar does not import `recordingStore`); `npm run build` emits `dist/recorder-bar.html`.

## WP3 — Editor integration + docs (after WP1/WP2)
Files: `src/stores/recordingStore.ts`, `src/stores/settingsStore.ts` (add `recording.setupStyle: "bar"|"dialog"`, default `"bar"`, sanitize rule), Settings recording section, `TopBar.tsx`/`StartScreen.tsx` only if routing needs it, CHANGELOG, HANDOFF, architecture, README, version 4.28.0.
- `openDialog()`: if `setupStyle==="bar"` and in Tauri → `openRecorderBar()`; on error fall back to the dialog. Add `openSetupDialog()` for the old path; listen for `recorder:open-dialog`.
- Listen for `recorder-bar:opts` and apply via `set({opts})` without re-persisting. Add `barOpen` fed by `onRecorderBarVisibility`. `runRecorderAction("record")` when idle and `barOpen` → `emitTo("recorder-bar","recorder-bar:record")`. `restoreMainWindow()` also calls `win.show()`; `handleSnapshot` restores when main is not visible.
- Acceptance: store tests (routing bar/dialog/fallback, opts event applied, record shortcut forwarded while bar open, restore calls `show`); existing tests green; `npm run ci`.

## Risks
Opaque bar (no translucency/rounded corners without private API, MAS forbids); Area is on a thumbnail (macOS 14) not full screen; no system-audio meter (helper exposes none); hidden-window timers unverified (Rust idle→show net covers restore); `getUserMedia` in a second webview may re-prompt or mismatch by name; stop preview tracks before hiding; `data-tauri-drag-region` on gaps only; Spaces/fullscreen behaviour of the bar and exclusion/multi-display/TCC are owner-run checks (agents must not launch the UI).
