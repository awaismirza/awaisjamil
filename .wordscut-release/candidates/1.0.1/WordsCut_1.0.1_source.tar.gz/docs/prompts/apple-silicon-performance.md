# Apple Silicon performance modernization — paste-ready brief

Owner-supplied brief (2026-10-21). Any agent (Claude, Codex, other) can take this over: read `docs/HANDOFF.md` §"Apple Silicon performance" for the current phase status first, then continue from the first unfinished phase.

Worktree: `/Users/awaisjamil/code/projects/yusaf-cut-perf`, branch `feature/apple-silicon-performance` (cut from `main` at v4.28.0).

---

Implement the Apple Silicon performance modernization of YusafCut at:

/Users/awaisjamil/code/projects/yusaf-cut

This is an implementation request. Work through the phases below, preserving existing functionality and measuring improvements. Do not stop after producing another plan.

Read docs/HANDOFF.md first, then CLAUDE.md, docs/architecture.md, and applicable AGENTS.md instructions. Inspect the actual code before relying on documentation.

Repository rules:
- Preserve all existing uncommitted work. The current checkout may contain recorder-bar changes.
- Use a fresh feature branch and an isolated worktree for implementation.
- Follow versioning, documentation, explicit-path staging, and checkpoint requirements.
- Never open a PR or merge without my explicit instruction.
- Follow the existing restriction on agent-run UI/computer-use testing. Run authorized automated checks and clearly identify owner-run validation.
- Update HANDOFF Status / Next up after every completed milestone and before stopping.

Product constraints:
- Apple Silicon Macs only: M1 and later.
- All media processing and inference stay local.
- Preserve text-based editing, EDL semantics, undo/redo, existing projects, and original-media export quality.
- Current minimum macOS is 13. Keep that baseline unless I explicitly approve raising it. Gate newer APIs by availability.
- Prioritize measurable performance, responsiveness, memory use, energy efficiency, and correctness.
- Do not promise 100× overall speed. Report measured gains per operation.
- Preserve React and Rust where they work well. Use Swift, AVFoundation, Core Video, Metal, VideoToolbox, and Accelerate where they provide concrete benefits.
- Verify current Apple APIs against official documentation.

Start by writing a concise implementation roadmap with acceptance criteria, then execute it in independently verifiable phases.

## PHASE 1 — Establish trustworthy baselines and instrumentation

Inspect:
- scripts/benchmark-media-pipeline.mjs
- docs/performance/arm64-media-packaging.md
- docs/benchmarks/playback-debug-2026-10-19.json
- src/lib/playbackDiagnostics.ts
- src-tauri/src/commands/export.rs
- src-tauri/src/commands/record.rs
- src-tauri/src/commands/transcribe.rs

The saved 7.18-second effects benchmark uses a synthetic graph that differs from the production exporter. Do not present it as measured application export performance.

Create reproducible benchmarks that exercise the actual production paths:
- Export with no effects.
- Export with zoom, cursor, scene framing, rounded corners, and shadows, individually and together.
- Many cuts, repeated source ranges, and multiple sources.
- Screen-and-camera Stop-to-edit latency.
- Proxy generation.
- Audio extraction, waveform, silence detection, hashing, and transcription.
- Cold versus warm model startup.

Include short fixtures for iteration and documented long-duration release tests. Record hardware, macOS version, build mode, source properties, output settings, wall time, memory, and available energy/thermal observations.

Add useful native timing and backpressure diagnostics. Keep diagnostics local and bounded. Do not run disruptive long recording or soak tests without authorization.

## PHASE 2 — Correct transcription acceleration and startup behavior

Inspect src-tauri/src/commands/transcribe.rs, especially ensure_coreml_encoder and transcribe_whisper_cpp.

Currently, failure to prepare the Core ML encoder adds --no-gpu. Investigate whether the bundled whisper.cpp supports a working Metal-only fallback.

Implement capability-aware selection:
- Core ML plus Metal where supported and beneficial.
- Metal-only when Core ML is unavailable.
- CPU only when hardware acceleration is unavailable or fails.

Verify the actual bundled binary and runtime behavior; do not blindly remove flags.

Separate model download/preparation, model loading, audio extraction, and inference timings. Improve cancellation during preparation where practical.

Evaluate persistent model reuse for successive clips. Implement it only if measurements justify the lifecycle and memory cost; keep memory bounded and support cancellation and recovery.

Preserve DTW/timestamp behavior, filler retention, language options, translation, and existing recognition attachment/undo guarantees. Do not trade timing accuracy for throughput without an explicit selectable mode and validation.

## PHASE 3 — Build a reusable native media renderer

Inspect:
- src-tauri/src/commands/export.rs
- src-tauri/src/scene.rs
- src-tauri/src/zoom.rs
- src-tauri/src/cursor_export.rs
- native/yusafcut-capture/

Introduce a reusable Swift media module with clear interfaces. Choose process boundaries deliberately:
- Export can run in a native helper.
- Embedded native playback requires in-process AppKit/layer integration with Tauri.
- Never transfer raw video frames through JSON or JavaScript IPC.

Implement a native path using:
- AVFoundation asset reading/composition.
- Core Video pixel buffers and reusable buffer pools.
- CVMetalTextureCache and Metal rendering.
- AVAssetWriter or VideoToolbox-backed encoding.

Avoid CPU pixel readbacks where practical. Instrument conversions and copies rather than claiming an unverified "zero-copy" pipeline.

Render zoom by sampling the source rectangle directly into the final output dimensions. Avoid enlarging an entire frame only to crop it afterward.

Support the current feature set:
- EDL cuts and output order.
- Repeated source ranges and multiple sources.
- Source orientation, dimensions, and timing.
- Zoom easing and moving focus.
- Scene backgrounds, framing, rounded corners, and shadows.
- Cursor styles and click effects.
- Existing audio tracks, offsets, gain, mixing/ducking behavior.
- Export size, frame rate, codec, and bitrate settings.
- Chapters and other currently supported export metadata.
- Audio-only exports where applicable.

Cache static render resources. Use a shared rendering model suitable for both playback and export, including an AVVideoCompositing adapter where appropriate.

Preserve source/output time mappings using appropriate Core Media time representations. Handle variable frame rate, sparse screen frames, delayed audio starts, and final-frame duration correctly.

Integrate with existing job IDs, progress, cancellation, temporary-file cleanup, and failure recovery.

Keep FFmpeg as a working fallback for unsupported inputs/features until parity is proven. Route unsupported cases explicitly; never silently omit an effect.

Keep fast passthrough/smart-cut paths for eligible exports. AVFoundation passthrough does not automatically provide arbitrary frame-accurate smart rendering.

## PHASE 4 — Preserve separate recording tracks and remove mandatory flattening

Inspect:
- src-tauri/src/native_capture.rs, especially finalize_args
- src-tauri/src/commands/record.rs, especially stop_native
- native/yusafcut-capture/Sources/CaptureCore/Manifest.swift
- native/yusafcut-capture/Sources/CaptureMedia/TrackWriter.swift
- Project/SourceMedia types, serialization, import, relinking, and save/load

The native recorder already creates separate screen, camera, microphone, and system-audio tracks, but screen-and-camera completion composites and re-encodes before returning the recording.

Extend the project model compatibly to represent synchronized recording tracks:
- Import playable tracks promptly after writer finalization.
- Preserve camera as an editable layer.
- Preserve microphone/system-audio alignment and independent settings.
- Flatten during export.
- Support camera placement, size, crop, and visibility.
- Keep crash recovery and partial-take import.
- Preserve existing projects and provide explicit migration/default behavior.
- Ensure cuts, undo/redo, save/load, and relinking retain track relationships and timing.

Do not remove the existing finalization path before the replacement can play and export all relevant modes correctly.

## PHASE 5 — Improve native capture efficiency and reliability

Inspect RecordingSession.swift and TrackWriter.swift.

Measure and tune:
- Screen pixel formats, including encoding-friendly YCbCr where supported.
- Camera pixel formats.
- Queue depth and buffer pressure.
- Actual hardware encoder use.
- Per-track samples written/dropped and reasons.
- Startup, first accepted sample, pause/resume, finalization, and audio/video alignment.
- Static-screen behavior.
- Capture resolution, including the current 3840-pixel width cap.
- Color metadata and screen-text clarity.

Do not assume a pixel-format change is universally better. Compare image quality, bandwidth, memory, and energy.

Preserve shared-clock behavior, capture exclusions, permissions, fragmented-file recovery, and session authorization.

Investigate the unresolved duration/pause issue described in HANDOFF. Do not claim reliability from the UI timer alone; compare finalized sample timestamps, track durations, and probed media.

Address relevant AVCaptureSession runtime-error and device-disconnection handling with appropriate recovery/reporting.

## PHASE 6 — Native playback using the shared media engine

Keep the current transport API while introducing an alternative native playback implementation.

Compile EDL ranges into AVComposition/AVPlayerItem and integrate a native playback surface into the Tauri window. Reuse the renderer from Phase 3.

Requirements:
- Smooth same-source and cross-source cut transitions.
- Accurate seeking and latest-request-wins scrubbing.
- Stable preview during edits and project/source changes.
- Native audio/video synchronization.
- Consistent zoom, cursor, scene, and camera composition.
- Correct resizing, clipping, Retina scaling, focus, and layering.
- Coarse state updates across IPC; keep frame processing native.
- Preserve current playback as a fallback until validated.

Benchmark actual presented-frame latency. Do not confuse seek completion or JavaScript callback duration with display latency.

Use existing targets as a starting point:
- Ready-proxy seek-to-presented-frame p95 below 150 ms.
- Playback UI work p95 below 8 ms.
- Cut interruption p95 below 100 ms, with tighter goals where practical.

Document owner-run visual verification required before changing the default.

## PHASE 7 — Evaluate Apple-native speech recognition

On macOS 26+, implement an availability-gated experimental SpeechAnalyzer/SpeechTranscriber backend.

Check runtime device and locale support, model asset installation, permissions, and offline operation after asset preparation.

Compare against the existing Whisper engine using representative audio:
- Recognition accuracy.
- Word-boundary timing accuracy.
- Filler/disfluency retention.
- Accents, noise, and long recordings.
- Startup latency, throughput, memory, and energy.
- Cancellation and interrupted recognition.

Use finalized results for persistent editing data. Keep volatile streaming results separate. Preserve stable source timing and recognition attachment behavior.

Evaluate transcription during recording without compromising capture performance.

Keep Whisper available. Promote Apple speech only where measured quality and timing meet the editor's requirements.

## PHASE 8 — Consolidate analysis, proxies, and transcript updates

Inspect:
- src-tauri/src/preview_cache.rs
- src-tauri/src/commands/preview.rs
- src-tauri/src/commands/pauses.rs
- src-tauri/src/commands/media.rs
- src-tauri/src/waveform.rs
- src/components/TranscriptEditor/TranscriptEditor.tsx

Reduce repeated audio decoding by sharing a bounded PCM analysis pipeline where beneficial:
- Waveform peak generation.
- Silence detection.
- Recognition input preparation.
- Resampling through native APIs.
- Accelerate for bulk DSP where measurements justify it.

Preserve source-PTS alignment, silence semantics, fingerprinted caches, cancellation, and atomic publication.

Benchmark native proxy scaling/encoding against the existing libx264 path on realistic long inputs. Hardware encoding is not automatically faster for short clips.

Measure full-file hashing on the import critical path. Any deferral must preserve identity, integrity, cache invalidation, and relinking guarantees.

Improve transcript editing through incremental TipTap transactions and narrower invalidation instead of rebuilding the complete document on every relevant change. Preserve selection, word IDs, pause badges, highlighting, zoom annotations, and undo semantics. Treat virtualization as a separate decision requiring selection/accessibility proof.

Scheduling:
- Preserve bounded background work.
- Prioritize recording and interactive playback.
- Coordinate export, proxies, analysis, and inference to avoid resource contention.
- Do not increase concurrency indiscriminately.
- Account for low-memory base M1 machines and sustained thermal load.

## VERIFICATION AND DELIVERY

For each phase:
1. Define acceptance criteria before editing.
2. Implement the smallest complete vertical slice.
3. Run relevant TypeScript, Rust, Swift, and real-media integration checks.
4. Test output duration, frame boundaries, audio alignment, visual parity, cancellation, and cleanup.
5. Compare against the baseline using equivalent output quality/settings.
6. Update documentation, versions where required, and HANDOFF.
7. Commit completed checkpoints without opening a PR or merging.

Never treat stub binaries or skipped native tests as successful runtime verification. Clearly distinguish:
- Implemented.
- Automated verification passed.
- Benchmarked.
- Owner/UI verification pending.
- Deferred with evidence and rationale.

Do not invent hardware measurements. Supply reproducible commands for hardware unavailable locally.

At completion, report:
- What changed.
- Which paths now use native Apple APIs.
- Measured before/after results and their limits.
- Compatibility and project migration behavior.
- Remaining fallback paths.
- Exact owner-run validation steps.

Begin with repository inspection and the baseline phase, then continue through implementation. Ask only for decisions or permissions that genuinely block progress.
