# AI-assisted editing: capability inventory (milestone 1)

Status: design only, no feature code. Checked against `main` at v4.28.2 (`7f6bf9b`) on
2026-10-21. Line numbers are from that commit; re-check them before relying on them.

Companion docs: [`contracts.md`](contracts.md), [`eval-plan.md`](eval-plan.md),
[`milestones.md`](milestones.md).

## 0. Summary

Most of what the AI features need on the *editing* side already exists and is pure,
tested and reachable from the Agent CLI/MCP: stable word ids, an immutable EDL with
pure ops, a plan / confirm / apply flow with one undo step and a stale-revision guard.

What does **not** exist is the *model* side: the MLX sidecar is not wired into the app,
no LLM or embedding weights are on this Mac, there is no capability discovery, no
validation of model output against the project, and no AI job kind. The owner also
decided against using an LLM for chapters (HANDOFF §5.1, line 810), so every AI
feature must have a model-free baseline or a clear reason to need a model.

## 1. What is actually present on this Mac (checked 2026-10-21)

Machine: Apple M1 Pro, 32 GB unified memory.

| Item | Where | State |
|---|---|---|
| `whisper-cli` | main checkout `src-tauri/binaries/whisper-cli-aarch64-apple-darwin` (2.4 MB, arm64) | Real binary. Git-ignored, so **not** present in fresh worktrees. |
| Whisper weights | `~/Library/Application Support/dev.yusafcut.app/models/ggml-large-v3-turbo.bin` (1.6 GB) + `ggml-large-v3-turbo-encoder.mlmodelc` | Only large-v3-turbo is installed. |
| `ffmpeg` / `ffprobe` 7.1.1 | main checkout `src-tauri/binaries/` (25 MB each, arm64) | Real binaries, git-ignored. |
| `mlx-sidecar` PyInstaller bundle | main checkout `src-tauri/binaries/mlx-sidecar-aarch64-apple-darwin` (53 MB, arm64) | **Broken.** Started with a request on stdin it fails at once: `ImportError: attempted relative import with no known parent package` (`__main__.py` line 30 uses `from .server import serve`; PyInstaller runs it as a top-level script). |
| `mlx-sidecar` committed file | worktree / git `src-tauri/binaries/mlx-sidecar-aarch64-apple-darwin` (1 KB) | Dev shell launcher that runs `python -m mlx_llm` from `sidecars/mlx-llm/.venv`. |
| Python venv | `sidecars/mlx-llm/.venv -> ../../.venv` (main checkout only) | Works: `mlx_lm 0.29.1`, `mlx 0.29.3`, Metal available. `python -m mlx_llm` answers a JSON line (`{"ok":false,"error":"Unknown command: 'capabilities'"}`). |
| LLM weights | `~/.cache/huggingface/hub` | **None.** Only `aufklarer/Silero-VAD-v6.2.1-MLX` (1.2 MB, a VAD, unused by the app). The sidecar default `mlx-community/Llama-3.2-3B-Instruct-4bit` (~1.8 GB) is **not downloaded**; first use would trigger a Hugging Face download. |
| Embedding model | anywhere | **None.** |
| TTS / voice model | anywhere | **None.** |
| `whisperkit-cli` | main checkout, 6.7 MB arm64 | Not used (WhisperKit removed in v3.2.0). Worktree copy is a stub that exits 1. |
| Ollama / LM Studio | `~/.ollama`, `~/.lmstudio` | Not checked in depth; not part of the product (would break "100% local, bundled"). |

Consequence: every model-backed milestone must ship with a **mock adapter** for tests and
an explicit "model not installed" state. No real-model quality run is possible on this
machine until weights are downloaded by the owner.

## 2. Reusable capabilities (with file:line)

### 2.1 Data model and stable references

| Capability | Location | Notes for AI work |
|---|---|---|
| `Project`, `SourceMedia`, `Word`, `Segment` | `src/lib/edl.ts:21-110` | `Project.id` (uuid, `edl.ts:816`) and `SourceMedia.id` + `sha256` (`edl.ts:21-30`) are stable across saves. |
| Stable `Word.id` | assigned once in `src-tauri/src/transcribe.rs:114` (`Uuid::new_v4`) | Survives every edit (words are never mutated, `edl.ts:6-11`). **Re-transcribing a media creates new ids** (`Toolbar.tsx:100-121` `applyTranscriptToMedia`), so references from before a re-transcribe are dead. |
| `originalTranscripts[mediaId]` | `edl.ts:99`, written by `addMediaWithTranscript` (`edl.ts:684-705`), `sourceTranscript.ts:4`, `Toolbar.tsx:108` | Full pre-edit word list per media. This is the right corpus for indexing **source** content, including words already cut. |
| `Segment.id` | `edl.ts:41` | **Not stable**: every split / keep / trim makes new uuids (`edl.ts:296,466,656`). Never store it in a suggestion. |
| Output ↔ source time | `computeTimeline` `edl.ts:138`, `outputTimeToSource` `:157`, `sourceTimeToOutput` `:174`, `wordIdToOutputTime` `:191`, `getTimelineIndex` `timelineIndex.ts:27` | Output times shift after every cut; suggestions must store source refs and derive output ranges at display time. |
| Word lookup | `findWord` `edl.ts:258`, `wordIdsInOutputRange` `:213`, `wordIdsInSourceRange` `projectOps.ts:42` | Reference-existence checks build on these. |
| Session revision counter | `src/lib/agent/liveContext.ts:28-47` | +1 on every `project` reference change (incl. undo/redo/UI edits); **in memory only, resets on project open and app restart**. |

### 2.2 Deterministic edit operations (the only things a suggestion may apply)

| Op | Location | Agent tool |
|---|---|---|
| Delete words (with padding, segment split) | `deleteWords` `edl.ts:322` | `edit_cut_words` `agent/tools/edit.ts:37` |
| Delete / keep an output range | `wordIdsInOutputRange` + `deleteWords`; `keepOutputRange` `edl.ts:436` | `edit_cut_range` `edit.ts:91` |
| Delete by source range | `deleteBySourceRange` `projectOps.ts:53` | (no tool; used by store) |
| Fillers | `SAFE_FILLERS` / `OPT_IN_FILLERS` `fillers.ts:14,29`, `findFillersInSegments` `:122`, `fillerWordIds` `:131`, store `deleteFillers` `projectStore.ts:324` | `edit_cut_fillers` `edit.ts:135` |
| Silences / pauses | `cutSilences` `edl.ts:578`, `trimSourceRanges` `:602` (never clips a word), `detect_pauses` `src-tauri/src/commands/pauses.rs:69`, store `shortenPausesLongerThan` `projectStore.ts:568`, `useCleanupActions.ts:46,120` | `edit_trim_silences` `edit.ts:183` |
| Replace word text (timing untouched) | `replaceText` `projectOps.ts:88` | `edit_replace_text` `edit.ts:244` |
| Chapters | `addChapter`/`removeChapter`/`renameChapter` `edl.ts:719-746`, `setChapters` `projectOps.ts:26`, model-free `suggestChapters` `autoChapters.ts:199` | `chapters_suggest` / `chapters_edit` `agent/tools/chapters.ts:32,64` |
| Zoom regions | `zoom.ts`, `generateAutoZoom` `autoZoom.ts:52` | `zoom_edit` |
| Clip ops | `trimClipEdge`/`splitClipAt`/`deleteClip`/`rollEdit` `clipEdit.ts:104-245` | none |
| Keep chapters/zoom/music aligned after cuts | `retimeAfterEdit` `edl.ts:489` | implicit |
| Batch of edit steps as one apply | `editBatch` `edit.ts:305`, `BATCHABLE` `:280` | `edit_batch` |

### 2.3 Plan / confirm / apply with one undo step

| Piece | Location |
|---|---|
| Plan → apply flow, `STALE_REVISION` check before and after `prepare` | `runEdit` `src/lib/agent/registry.ts:130-172` |
| Pure diff for plan output (removed words, durations, chapter/zoom counts) | `diffProjects` `src/lib/agent/plan.ts:26`, `planOutput`/`appliedOutput` `:77,87` |
| Exactly one `setProject` per apply → one zundo entry | `applyProject` `liveContext.ts:83-98`; zundo `limit: 50`, reference equality `projectStore.ts:597-600` |
| Busy guard (export, recorder, transcribe, other edit) | `busyReason` `liveContext.ts:63` |
| Input validation (JSON-schema subset, pointer errors) | `validate` `src/lib/agent/schema.ts:124` |
| Error codes | `AgentErrorCode` `src/lib/agent/protocol.ts:40-54` |
| Undo toast | `pushUndoToast` in `applyProject` |

### 2.4 Transcript, search and captions

| Capability | Location |
|---|---|
| whisper.cpp with DTW timestamps, per-word confidence | `src-tauri/src/transcribe.rs`, `commands/transcribe.rs:61-90` (model names) |
| Word edges snapped to silence (≤120 ms) | `snapWordsToSilences` `src/lib/timestampSnap.ts:43` |
| Transcript cache per media | `transcriptCache.ts:9-39` |
| Lexical search (consecutive words, whole-word, case) | `findWords` `projectOps.ts:152`; tool `transcript_search` `agent/tools/transcript.ts:120` |
| Transcript paging (words / sentences / text) | `transcript_get` `transcript.ts:74` |
| Output-time words, cues, SRT, VTT | `flattenWordsInOutputTime` `captions.ts:45`, `buildCues` `:67`, `buildSrt` `:138`, `buildVtt` `:150`; tool `captions_export` `agent/tools/captions.ts:7` |
| `Word.speaker` field | `edl.ts:38`, always `None` from whisper (`transcribe.rs:119`): **no diarization** |

### 2.5 Jobs and sidecars

| Capability | Location | Gap |
|---|---|---|
| Background job queue: `Queued/Running/Completed/Failed/Cancelled`, cancel token, per-kind FIFO, last 20 persisted, running→cancelled on restart | `src-tauri/src/jobs.rs:42-75,343-350`; TS `JobKind` `src/lib/ipc.ts:450` | No `stale` status and no AI kinds (`Export, Transcribe, DownloadModel, Snapshot, Waveform, Proxy` only). |
| Model download job | `JobKind::DownloadModel` (whisper) | Whisper-only; could be reused for LLM/embedding weights. |
| MLX sidecar protocol (JSON line in, JSON line out, `{id, ok, result|error}`) | `sidecars/mlx-llm/mlx_llm/schemas.py:1-144`, `server.py:41-85` | Commands: `summarise` (chapters, `commands.py:148`), `broll` (`commands.py:272`). No `capabilities`, no `embed`, no cancel, no streaming, no token count, no memory reporting. Model cached in-process (`commands.py:36-51`). Parsing is lenient regex recovery (`commands.py:92-145`), not validation. |
| Sidecar tests | `sidecars/mlx-llm/tests/test_commands.py`, `test_server.py`; `npm run test:sidecar` | Mocked `generate`. |
| Sidecar wiring in the app | — | **None.** Removed in v3.4.0 (`src-tauri/src/lib.rs:6-8`, `src/lib/ipc.ts:446-448`); `mlx-sidecar` is not in `tauri.conf.json` `externalBin` (`:64-69`). Old wiring at commit `074d1d3`. |

### 2.6 Agent CLI / MCP

20 tools, loopback HTTP + stdio bridge, off by default, disabled in the MAS build
(`docs/agent-cli-design.md`, `src-tauri/src/agent/*`, `src/lib/agent/*`). An external
model (Claude Code, Codex) can already plan and apply edits through it. This is the
cheapest route to "AI-assisted editing" with **no local model**: the external agent is
the model, YusafCut is the deterministic executor.

## 3. Missing pieces

| # | Missing | Needed by | Model needed? |
|---|---|---|---|
| M1 | Durable project revision (survives restart / reopen) for jobs that outlive a session | all job-based features | no |
| M2 | `SourceRef` / `Suggestion` types, validator, hallucinated-reference rejection | all | no |
| M3 | AI job kinds + `stale` status in `jobs.rs` / `ipc.ts` | all model features | no |
| M4 | Transcript index (sentence/paragraph chunks keyed by word ids, over `originalTranscripts` and current EDL) | search, retakes, rough cut | no (lexical); yes for embeddings |
| M5 | Lexical ranking (BM25) | semantic search baseline | no |
| M6 | Embedding command in the sidecar + an installed embedding model | semantic search | **yes, none installed** |
| M7 | Sidecar `capabilities` command, memory/size limits, cancellation, working PyInstaller bundle | all model features | — |
| M8 | Per-word text correction op (set text of given word ids; today only find/replace over all words, `projectOps.ts:88`). `replaceText` also does not update `originalTranscripts`, so a `rollEdit` that restores words brings back the uncorrected text. | corrections | no |
| M9 | Retake / repeated-phrase detector | retakes | no for baseline (n-gram overlap), optional model to rank |
| M10 | Segment **reorder** op. There is none in `edl.ts`; rough cut today can only delete/keep, not move. | rough cut (if reorder is in scope) | no |
| M11 | TTS / narration generation and placing generated audio as an `AudioTrack` | narration | **yes, none installed** |
| M12 | Caption burn-in (export has no subtitle burn path; only SRT/VTT files) | captions | no |
| M13 | Sensitive-content detector (PII patterns) | sensitive | no for regex baseline |
| M14 | Speaker diarization (`Word.speaker` always empty) | rough cut by speaker, narration | yes |
| M15 | Unified assistant UI (suggestion list, review, accept/reject, evidence) | UI | no |
| M16 | Prompt construction that fences transcript as data | all model features | — |

## 4. Honest constraints

- **Owner preference:** chapters were deliberately made model-free because an LLM is "too
  much overhead" (HANDOFF §5.1). Each model-backed milestone needs explicit owner sign-off
  and a model-free fallback.
- **The bundled sidecar is broken and not shipped.** Re-enabling it is real work
  (import fix, `externalBin`, signing per `docs/distribution-and-signing.md`, MAS impact).
- **Weights are not bundled.** A 3B 4-bit model is ~1.8 GB plus ~2-3 GB of runtime memory;
  downloads must be an explicit user action through the job queue.
- **MAS build:** a PyInstaller Python sidecar and runtime model downloads need checking
  against App Store rules before any of this ships there.
