# AI-assisted editing: milestones, dependencies and file ownership

Status: design only. Milestone 1 is these four docs. The rest is a plan for parallel
agents; each milestone is one branch, one worktree, one version bump (CLAUDE.md rules).

## 1. Dependency graph

```
M1 docs (this)  ─▶  M2 shared foundation: contracts, validator, jobs, index, adapter, mock
                          │
        ┌─────────────────┼──────────────────┬──────────────────┬───────────────────┐
        ▼                 ▼                  ▼                  ▼                   ▼
   M3 semantic       M4 corrections     M6 narration       M7 sensitive        (M9 CLI/MCP can
      search           + retakes          + captions         + quality           start on M2
        │                 │                                                       read-only tools)
        └────────┬────────┘
                 ▼
            M5 rough cut  (needs search ranking + retake detector)
                 │
   M3 M4 M5 M6 M7 ──────────▶ M8 unified assistant UI
                                   │
                                   ▼
                              M9 CLI / MCP exposure (full)
```

Hard dependencies only: M3/M4/M6/M7 need M2 merged; M5 needs M3 and M4; M8 needs at
least two feature milestones merged; M9 can expose read-only tools after M2 and the
rest after the features. M3, M4, M6, M7 can run **in parallel**.

Before any model-backed milestone starts: owner sign-off that an LLM is acceptable for
that task (HANDOFF §5.1 records "no LLM" for chapters), and which model to download.

## 2. Milestones

Each lists: goal, model need, files **owned** (only this milestone edits them), files
**touched by contract** (append-only edits, coordinated), and done-when.

### M2 Shared foundation (jobs, index, retrieval core, adapter) — serial, first

- Model: none. Ships mock + null adapters; MLX adapter compiled but optional.
- Owns:
  - `src/lib/ai/contracts.ts` (types from contracts.md, frozen after merge; changes need a doc update)
  - `src/lib/ai/validate.ts` (model-output validator, contracts §3)
  - `src/lib/ai/revision.ts` (fingerprint, `isFresh`)
  - `src/lib/ai/sourceRef.ts` (resolve refs, output ranges)
  - `src/lib/ai/index.ts` (sentence/paragraph chunks over `originalTranscripts` + EDL, keyed by word ids)
  - `src/lib/ai/bm25.ts` (lexical ranking, baseline for search)
  - `src/lib/ai/prompt.ts` (data-block fencing, ordinal id table, contracts §7)
  - `src/lib/ai/adapter.ts`, `src/lib/ai/mockAdapter.ts`
  - `src/lib/ai/apply.ts` (accepted suggestions → one `edit_batch`, contracts §6)
  - `src/stores/aiStore.ts` (jobs + suggestions state)
  - `src-tauri/src/ai/` (new module: sidecar process manager, `ai_capabilities`, `ai_generate_json`, `ai_embed`, `ai_cancel`)
  - `sidecars/mlx-llm/mlx_llm/*` (add `capabilities`, `generate_json`, `embed`, `cancel`; fix `__main__` absolute import for PyInstaller)
  - `tests/ai/*`, `tests/fixtures/ai/*`, `sidecars/mlx-llm/tests/*`
- Touched by contract: `src-tauri/src/jobs.rs` (add AI `JobKind`s and `Stale`), `src/lib/ipc.ts` (AI invoke wrappers in one new section), `src-tauri/src/commands/mod.rs` + `lib.rs` (register commands), `src/lib/agent/protocol.ts` (add `MODEL_OUTPUT_INVALID` to `AgentErrorCode`), `tauri.conf.json` (`externalBin` for mlx-sidecar, only if the owner approves shipping it).
- Done when: Tier A tests 1-8 of eval-plan §3 pass; `npm run check`, Vitest, `cargo test`, `test:sidecar` green; nothing user-visible yet except a Settings line showing capability state.

### M3 Semantic search — parallel after M2

- Model: BM25 baseline none; embeddings **need an embedding model (none installed)**.
- Owns: `src/lib/ai/search.ts`, `src/components/Assistant/search/*` (temporary panel until M8), `tests/ai/search.test.ts`.
- Touched by contract: sidecar `embed` (implemented in M2), `src/lib/agent/tools/transcript.ts` (only if extending `transcript_search` with `mode:"semantic"`; otherwise M9).
- Done when: retrieval@5 measured for BM25 and embeddings on S1/S2; embeddings ship only if they beat BM25 by ≥ 0.1.

### M4 Corrections + retakes — parallel after M2

- Model: retake baseline (n-gram overlap) none; ranking and corrections optionally a chat model.
- Owns: `src/lib/ai/retakes.ts`, `src/lib/ai/corrections.ts`, new agent tool `edit_set_word_text` in `src/lib/agent/tools/correct.ts` (+ registration line in `registry.ts` and `BATCHABLE`), `src/lib/projectOps.ts` additions `setWordText` that also updates `originalTranscripts` (fixes capability-inventory M8), `tests/ai/retakes.test.ts`, `tests/ai/corrections.test.ts`.
- Touched by contract: `src/lib/agent/registry.ts` (one import + one array entry), `src/lib/agent/tools/edit.ts` (`BATCHABLE` entry).
- Done when: S6 retake FP ≤ 5%, S7 recall ≥ 0.7 for the baseline; meaning-changing-cut rate ≤ 1%; corrections never alter timing.

### M5 Rough cut — after M3 and M4

- Model: chat model to choose sections against a user brief; baseline = keep chapters/sections ranked by BM25 against the brief.
- Owns: `src/lib/ai/roughCut.ts`, `tests/ai/roughCut.test.ts`.
- Open decision: **reordering**. `edl.ts` has no reorder op (capability-inventory M10). v1 rough cut = keep/delete only, in source order. Reorder requires a new pure op `reorderSegments` in `edl.ts` — that is a core EDL change and needs the owner's approval and its own branch that owns `edl.ts` + `tests/edl.test.ts`.
- Done when: rough cut is one undoable `edit_batch`, keeps ≥ 10% duration, and the meaning-changing rate is reported.

### M6 Narration + captions — parallel after M2

- Model: captions none (text ops over `buildCues`); narration **needs a local TTS model (none installed)** and owner approval.
- Owns: `src/lib/ai/captionsAssist.ts` (cue text cleanup, line length), narration module `src/lib/ai/narration.ts` + `src-tauri/src/ai/tts.rs` if approved, `tests/ai/captions*.test.ts`.
- Touched by contract: `src/lib/captions.ts` (add options only, keep current outputs byte-identical — existing `tests/captions.test.ts` must pass unchanged), `AudioTrack` usage via existing `addAudioTrack` (`edl.ts:754`).
- Caption burn-in touches `src-tauri/src/commands/export.rs`: **out of scope** here; separate branch (HANDOFF §7 lists `export.rs` as a conflict hotspot).
- Done when: caption edits never change EDL; narration (if approved) lands as an `AudioTrack` in one undo step.

### M7 Sensitive content + quality checks — parallel after M2

- Model: regex/Luhn/keyword baseline none; optional chat model for context.
- Owns: `src/lib/ai/sensitive.ts`, `src/lib/ai/quality.ts` (low ASR confidence runs, long pauses, cut-mid-number warnings), `tests/ai/sensitive.test.ts`, `tests/ai/quality.test.ts`.
- Done when: S9 FN ≤ 2% with synthetic strings only; flags are read-only unless the user picks "cut".

### M8 Unified assistant UI — after ≥ 2 of M3-M7

- Model: none itself.
- Owns: `src/components/Assistant/*` (replaces temporary panels from M3-M7), a sidebar tab entry in `src/components/editor/sidebar/registry.tsx` (one line), `tests/Assistant*.test.tsx`.
- UI pattern: job list with states (contracts §4), suggestion list grouped by kind with quote + evidence + confidence, play-the-span, accept/reject per item, "Apply N" → one undo step, stale banner with "Re-run". Indeterminate loaders via `uiStore` per CLAUDE.md.
- Done when: owner runs it in `npm run tauri:dev` (agents must say they could not).

### M9 CLI / MCP exposure

- Model: none (external agents bring their own).
- Owns: `src/lib/agent/tools/ai.ts` (`ai_capabilities`, `ai_job_start`, `ai_job_status`, `ai_suggestions_get`, `ai_suggestions_apply` with `confirm` + `baseRevision`), `src-tauri/resources/agent/{README,SKILL}.md` updates, `tests/agent/ai.test.ts`.
- Touched by contract: `src/lib/agent/registry.ts` (imports + array entries), `docs/agent-cli-design.md` (catalog table).
- Done when: plan/apply semantics identical to existing tools; catalog snapshot updated.

## 3. Collision rules for parallel agents

- Shared files edited by several milestones are **append-only by contract**: add an
  enum member, an import or an array entry; never reorder or reformat. These are:
  `src/lib/agent/registry.ts`, `src/lib/agent/tools/edit.ts` (`BATCHABLE`),
  `src/lib/agent/protocol.ts`, `src-tauri/src/jobs.rs`, `src/lib/ipc.ts`,
  `src-tauri/src/commands/mod.rs`, `src-tauri/src/lib.rs`, `sidebar/registry.tsx`.
- Never touched by M3-M9 without the owner: `src/lib/edl.ts`, `src/stores/projectStore.ts`,
  `src-tauri/src/commands/export.rs`, `src-tauri/src/edl.rs` (HANDOFF §7 hotspots).
- `CHANGELOG.md`, version files, `README.md`, `docs/architecture.md`, `docs/HANDOFF.md`:
  each milestone adds its own lines; rebase on `origin/main` before pushing; expect
  trivial conflicts there and resolve by keeping both entries.
- `src/lib/ai/contracts.ts` is frozen after M2; a needed change goes into its own small
  branch with a `contracts.md` update, merged before dependants rebase.
- Fixtures: each milestone adds files under `tests/fixtures/ai/` with its own prefix;
  never edit another milestone's fixtures.
- Stage by explicit path, own worktree per agent (AGENTS.md).

## 4. Version plan (suggested)

M2 4.29.0 · M3/M4/M6/M7 one minor each in merge order · M5 minor · M8 minor · M9 minor.
Docs-only work (like M1) sits under `[Unreleased]` without a bump.
