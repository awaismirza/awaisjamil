# WordsCut release

> Current owner direction (22 October 2026): distribution is being consolidated into `awaismirza/awaisjamil` for a paid release. Original 1.0.0 assets and the complete old repository backup are retained in private draft releases there. The exact destination download passed both local verification and hosted credential/download verification in https://github.com/awaismirza/awaisjamil/actions/runs/39689869482. The old free release is now draft-only and its Pages URL redirects to the personal site; permanent deletion awaits the required owner confirmation. Fresh build 39691034070 passed all tests and compilation, signed the app and obtained Apple notarization Accepted, then failed on Apple CloudKit ticket delivery (error 68). The helper now retries Apple stapler/Gatekeeper gates at most three times; a fresh successful candidate is still required. Progress is tracked in the current HANDOFF section. The historical public URLs below are provenance, not maintained download links. Working source 1.0.1 is unreleased and retains its existing licence.


Version 1.0.0, 22 October 2026. The owner requested a numbering reset for the first public WordsCut release; the previous private Scribe v1.0.0 tag remains historical and unchanged. Release: https://github.com/awaismirza/wordscut/releases/tag/v1.0.0. Download page: https://awaismirza.github.io/wordscut/#download. Personal product page: https://awaisjamil.com/products/wordscut. The fresh local arm64 app and DMG were Developer ID signed, Apple notarized (`Accepted` for both), stapled and assessed by Gatekeeper. The exact public release then passed the verification-only Actions run https://github.com/awaismirza/wordscut/actions/runs/39624496604: checksums, source version, DMG/app signature, staple, Gatekeeper, team ID `APFM7SNP9X`, bundle ID `dev.yusafcut.app`, and app version `1.0.0`. Public installer SHA-256: `c91a6eab13e537deb64845f8eb4dd8b2b9662783278b64ac79c790e4bb17c171`.

The tag-triggered build workflow did not publish the release because hosted `npm run engine:test` failed while generating AVFoundation fixtures; its downloaded-build gate was skipped. The separately dispatched workflow job verified the actual published installer bytes. The workflow is configured to verify newly published releases automatically and can verify a historical release via `verify_published_tag`; the runbook is at https://github.com/awaismirza/wordscut/blob/main/docs/verify-published-release.md. Private PR #63 merged normally to main as `a143b0f`; its checks failed before running steps (run https://github.com/awaismirza/wordscut-app/actions/runs/39622489617), while local frontend, Rust, Swift helper/engine and native media verification passed.

## Compatibility

Keep bundle ID `dev.yusafcut.app`, `.scribe`, persisted localStorage keys and internal protocol names. The installed app/executable move to `WordsCut.app/Contents/MacOS/WordsCut`; external CLI/MCP configurations with a literal old path must be updated. The app retains recent projects and model/cache data. Controller titles are synchronized across frontend, Rust and Swift to preserve exclusion.

## Distribution

Private development repo: `awaismirza/yusaf-cut` (visibility unchanged). Public distribution: `awaismirza/wordscut` (owner explicitly approved public website/installers/corresponding source archives). A reviewed source archive is committed in the distribution repo and checksummed before extraction by release CI. No broad cross-repository access token is needed: the public workflow uses its own restricted GITHUB_TOKEN.

All seven secrets from `docs/plans/ci-cd-release.md` are configured in the distribution repository. The Developer ID certificate expires 2 February 2027; renew before then. The API key has Developer access across the Apple team; protect repository write access and rotate if compromised. Temporary credentials are never committed.

Manual dispatch builds/signs/notarizes and uploads artifacts, without publishing. Tags must match all versions and be reachable from main. Tags publish only from the public distribution repo. Signing fails if notarization credentials are missing. The signing step validates the app and DMG before upload. A separate macOS job then downloads the Actions artifact and repeats verification against those exact downloaded bytes: all SHA-256 entries, DMG code signature, stapled DMG ticket, Gatekeeper DMG assessment, mounted app code signature, stapled app ticket, Gatekeeper app assessment, Developer ID team `APFM7SNP9X`, and bundle ID `dev.yusafcut.app`. The release publish job depends on this artifact-verification job, so a tag cannot publish if any check fails. A manual dry run runs the same downloaded-artifact gate and never publishes. Stable download alias: `https://github.com/awaismirza/wordscut/releases/latest/download/WordsCut_latest_aarch64.dmg`.

The website is a download/documentation page with no checkout, payment processing or SaaS. GitHub Pages restrictions prohibit using it to run an online business/e-commerce site; use suitable commercial hosting before adding a paid storefront. Reference: https://docs.github.com/en/pages/getting-started-with-github-pages/github-pages-limits

## Licensing and Mac App Store

AGPL permits charging for copies, with corresponding source and licence obligations. Preserve notices and distribute matching application source and native dependency sources alongside installers; build scripts and lockfiles identify remaining dependency sources. Do not add a proprietary EULA or change licences. References: https://www.gnu.org/licenses/agpl-3.0.html and https://www.gnu.org/licenses/gpl-faq.html#DoesTheGPLAllowMoney

Store readiness is not established. Current blockers: persistent security-scoped bookmark access is declared but not implemented; sandbox inheritance for all helper executables needs signed testing; capture/Input Monitoring needs store feasibility verification; App Store distribution terms and AGPL/GPL dependencies need a resolved compatibility review. Agent server is already disabled under APP_SANDBOX_CONTAINER_ID; do not broaden entitlements simply to bypass this.

MAS prerequisites were corrected to the four configured production sidecars and output isolated at `src-tauri/target/mas`. A matching store provisioning profile was created; a separately signed candidate and WordsCut.xcarchive were prepared locally. The archive script refuses a direct-download build lacking an embedded provisioning profile. Do not submit to review until owner approval and blockers are resolved.

## Verification ledger

- Frontend: npm check; 1,350 tests pass.
- Rust: 458 library + 17 CLI tests pass, 1 library test ignored.
- Swift capture/engine: pass.
- Packaged app: launched; synthetic project reopened from Recent, media played from an ordinary visible HOME path; split/undo/save verified. Hidden directories do not match the current asset scope, and the unregistered .scribe folder picker requires follow-up. The latest local installed app was ad-hoc signed, so these additional UI checks are not evidence for a final CI-signed candidate. Earlier local Developer ID acceptance remains recorded; its build-output bundle was subsequently replaced.
- Earlier real packaged app: launched; synthetic narration video imported and transcribed locally; export completed and FFprobe verified 10.128980 seconds.
- Historical local notarization log: `/private/tmp/wordscut-notarization-latest.log` says Apple accepted a previous build. The current local `.app` and `.dmg` fail signature verification, so no local package is presently verified. Hosted dry run 39617578831 passed checksum/version gates, frontend check and tests, native tests, then failed the Swift engine suite because parallel AVFoundation fixture writers could not save temporary media. Fixture generation is now serialized and all 26 Swift engine tests pass locally. Private PR run 39619846623 did not start because GitHub Actions billing/spending is blocked. The workflow now includes downloaded-artifact verification as a required dependency of release publication. Restore billing, rerun checks and the manual dry run, then confirm the downloaded artifact gate passes before any release tag is pushed.
- Real camera/mic/screen capture: not yet tested in this rebrand; announce capture before starting.
- Website: GitHub Pages workflow succeeded; actual page loaded in Chrome. Interactive deletion verified (9 to 8 words); all five images loaded. Phone hero corrected to two lines; no horizontal overflow at 390px. Source lint: 0 failures, 0 warnings.

## Brand assets

Generated with built-in Imagegen. Master: `assets/brand/wordscut-icon-master.png`; Tauri icon set in `src-tauri/icons`. Prompt: emerald rounded-square Mac tile, warm-white three-line editorial mark with a central play/cut motif, alpha outside tile, no lettering/scissors/film reel. Wordmark is authored typography, not a raster embedded in an SVG. Website direction `sentence-as-layout`, seed 1705069566, emerald palette retained. Website imagery comes from the real app using synthetic media, not customer footage.

Apple Developer App ID `dev.yusafcut.app` registered as WordsCut, without optional capabilities. Notarization credentials also saved locally in the `WordsCut-notary` Keychain profile. No private key values are documented here.

## Website refresh

Owner requested purple styling on 22 October. Download site now uses plum/lavender with the existing sentence-as-layout composition, plus a full capabilities index. The awaisjamil.com product update is isolated at `/private/tmp/wordscut-personal-site`, PR #39: new `/products/wordscut` and legacy `/products/yusafcut` aliases including legal/support pages, current feature descriptions and real screenshots. Its original Services branch remains untouched.

App Store Connect draft created: app 6825379087, version 4.51.0 Prepare for Submission, manual release selected; listing text, category, support/marketing and privacy URLs prepared. No submission or legal agreement acceptance. CI native fixtures now use detached tasks and finite waits after hosted XCTest stalled; local engine tests pass (17 media + 9 core). New PR checks queued under the WordsCut namespace.

## Final owner handoff — 22 October 2026

Owner requested documentation/commit/normal merge so work can continue in Claude. Private PR #62 consolidates the older #61 implementation. Personal website PR #39 is merged and live; unrelated #25/#38 are excluded by explicit owner direction. Latest signed hosted dry run: 39617578831. No public installer release or release tag yet. Both local app and DMG were notarized, stapled and Gatekeeper accepted again using the secure Keychain profile; see `/private/tmp/wordscut-notarization-latest.log`. Main handoff and exact continuation steps are at the top of HANDOFF.md.

PR #62 merged normally to main as feaddb2; superseded PR #61 closed. The owner requested handoff to Claude before hosted release verification completed. No public release is claimed. The checkout is left on main with the final documentation checkpoint committed.
