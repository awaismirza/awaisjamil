# WordsCut — agent handoff

Updated 2026-10-22 for the WordsCut 1.0.0 release and source-repository rename. The older wave-2 / QA notes further down are historical. Read this file first, then `CLAUDE.md`
(workflow rules, mandatory) and `docs/architecture.md` (how the code fits).
Keep this file current: when you finish or start something, edit the
**Status** and **Next up** sections in the same commit.

## 1. Resume in five minutes

### Current distribution consolidation — 22 October 2026

**Status:** owner requested removal of public `awaismirza/wordscut` and consolidation of all product-site and release orchestration into `awaismirza/awaisjamil`, with a paid product planned. Website migration PR #40 and bounded Apple-service retry PR #41 are merged and live. Destination credential/download verification passed: https://github.com/awaismirza/awaisjamil/actions/runs/39689869482. Private app source stays in `wordscut-app`; working version is 1.0.1 (unreleased administrative change). The original 1.0.0 signed installer/source/dependency/provenance/checksum files are retained byte-for-byte in the awaisjamil **draft** release `wordscut-v1.0.0`, with a complete Git/history/website/metadata/verification backup. Local durable backup: `/Users/awaisjamil/code/projects/awaisjamil/.wordscut-private-backup/` (excluded from Git). Seven signing credentials were transferred with destination-key sealed-box encryption; no plaintext credential transfer or new keys were required. Downloading the destination assets and running the new macOS verifier passed all checks locally. Anonymous draft metadata and installer requests return 404.

**Merge status:** app PR #67 remains open. Automatic approval review rejected a merge because private CI cannot start under the billing block; explicit owner authorization to use passing local checks is pending. Do not bypass required protections.

**Current validation:** final local typecheck/lint, 1,350 frontend tests, 458 Rust library tests (one ignored), 17 CLI tests and 17 media + 9 core Swift engine tests passed. Rust needs normal Mac access for localhost test sockets and VideoToolbox; the restricted sandbox run failed those facilities, then the full normal-access run passed. Private app Actions checks did not start because of account billing/spending, not source failures. Website lint, nine tests, production build, live desktop/mobile pages and the old-site redirect passed; personal-site PRs #40–#43 are merged. The actual personal checkout is clean `main`; its unrelated `services-ai-first` branch remains intact.

**Release ownership:** `awaisjamil/.github/workflows/wordscut-release.yml` and `distribution/wordscut/{build,prepare-inputs,verify}.sh` are the canonical entry points. They stage private candidate releases and verify actual downloads automatically. This repository's duplicate release/Pages workflows are retired; development CI and source-specific helpers remain. Legacy `website/` files in app history are not a deployed product site.

**Paid-product state:** product page is https://awaisjamil.com/products/wordscut. Free GitHub download links are removed; the CTA defaults to contact while the paid release is prepared. No price, checkout, proprietary EULA or app licence enforcement is live. Existing AGPL-licensed recipients retain their rights; matching source/dependency files are available through support. A future closed-source release needs ownership and dependency-licence review. Authoritative purchase guidance/runbook: `awaisjamil/docs/wordscut-commerce.md` and `awaisjamil/docs/wordscut-distribution.md`.

**Next up:** full private candidate build https://github.com/awaismirza/awaisjamil/actions/runs/39690042800 reproduced the known Swift engine fixture failure before signing; diagnostics are in private draft `wordscut-build-log-39690042800`. Fixture audio/video feeding is now independent, with per-input completion and stderr errors; local engine suites pass. Private 1.0.1 input snapshot from commit `9a3eb28` is staged, and full hosted build https://github.com/awaismirza/awaisjamil/actions/runs/39691034070 passed frontend, capture, engine and Rust tests, built/signed the app, and received Apple notarization Accepted. Apple CloudKit then disconnected during app stapling (error 68). The signing helper now retries ticket/stapler/Gatekeeper gates up to three times, preserving mandatory success; prepare the updated private snapshot and rerun the build. Destination credential/download verification and live Pages checks passed; remove only public `awaismirza/wordscut` after the required deletion confirmation (question pending in this chat). The old free release is now a draft, and its Pages entry point redirects to the personal product page. Keep unrelated personal-site PRs #25/#38 excluded. Owner chooses price/payment provider and completes provider account activation before live sales. Do not bypass the real-media test gate or claim the new hosted build passed yet. No new App Store submission is authorized.

### Historical WordsCut handoff — 22 October 2026, v1.0.0 release published

**Repository branding:** the private source repository was renamed from `awaismirza/yusaf-cut` to `awaismirza/wordscut-app`; the public distribution repository remains `awaismirza/wordscut` so its GitHub Pages URL stays live. The local checkout path is still `yusaf-cut`; its `origin` now points to `wordscut-app`. GitHub redirects the former repository URL. Do not rename compatibility identifiers such as `dev.yusafcut.app`, `.scribe`, or the native helper/crate names.

**Status:** WordsCut 1.0.0 is published at https://github.com/awaismirza/wordscut/releases/tag/v1.0.0; the live download page is https://awaismirza.github.io/wordscut/#download and the personal product page is https://awaisjamil.com/products/wordscut. The historical private Scribe v1.0.0 tag remains untouched. Fresh local arm64 app and DMG are Developer ID signed/notarized. Automated verification of the exact public v1.0.0 assets passed in run https://github.com/awaismirza/wordscut/actions/runs/39624496604. Private PR #63 merged normally to main as `a143b0f`; its checks failed before any test step started, while local checks passed. No credentials are in git. Private repository visibility is unchanged.

**Published websites:** https://awaismirza.github.io/wordscut/ and https://awaisjamil.com/products/wordscut use the requested purple palette. Personal website PR #39 is merged/deployed, with current features, real synthetic-media screenshots, download-site links and `/products/yusafcut` aliases for overview/privacy/terms/support. Unrelated personal-site PRs #25/#38 must remain untouched. Its original checkout remains on `services-ai-first`; this task's isolated worktree is `/private/tmp/wordscut-personal-site`.

**Verification:** npm check + 1,350 frontend tests; Rust 458 library + 17 CLI tests (1 ignored); Swift capture suite and engine 17 media + 9 core tests pass locally. Real native media capability checks pass. Packaged synthetic import/transcription/export, playback from a visible HOME path, split/undo/save/recent-project reopen were exercised. Hidden media paths do not match the asset scope; manually choosing an unregistered .scribe directory in the file picker needs follow-up. Full camera/mic/screen capture and clean-Mac installation remain unverified. Do not claim those passed.

**Signing:** fresh v1.0.0 build at `src-tauri/target/release/bundle/macos/WordsCut.app` and `src-tauri/target/release/bundle/dmg/WordsCut_1.0.0_aarch64.dmg` passed codesign strict/deep, Apple notarization (`Accepted` for app and DMG), stapler validation, and Gatekeeper assessment. Automated run #39624496604 downloaded the published v1.0.0 assets, validated every checksum and source version, mounted the public DMG, and passed the app/DMG signature, staple, Gatekeeper, Team ID, bundle ID and embedded version checks. Public installer SHA-256: `c91a6eab13e537deb64845f8eb4dd8b2b9662783278b64ac79c790e4bb17c171`. No credential values are in git or release notes.

**Hosted CI:** public tag build run https://github.com/awaismirza/wordscut/actions/runs/39622776921 failed at `npm run engine:test`: hosted AVFoundation fixture setup failed, so its built-artifact gate was skipped. The separate verification-only job now passed against the exact published v1.0.0 bytes in run https://github.com/awaismirza/wordscut/actions/runs/39624496604. Future releases are checked before publish by the build→downloaded-artifact gate and again on the `release: published` event. Private PR #63 checks https://github.com/awaismirza/wordscut-app/actions/runs/39622489617 failed before any steps started; the local check/test suites passed. Do not describe that private run as a source failure or as green.

**Store:** Apple bundle ID registered, matching store profile created, separate Apple Distribution-signed candidate and `WordsCut.xcarchive` prepared. App Store Connect app **6825379087**, SKU `wordscut-macos`, version 4.51.0 is **Prepare for Submission**, manual release; listing text/category/subtitle/support/marketing/privacy links saved. No build uploaded, legal agreement accepted or review submitted by the agent. Persistent sandbox bookmarks, helper/capture permission testing and AGPL/GPL versus store terms remain gates. Owner must review the updated Paid Applications Schedule before any store submission.

**Next up:**
1. Private PR #63 and public distribution PRs #1–#3 are merged normally. The v1.0.0 release and its exact-asset automated verification are complete.
2. Investigate the hosted Swift AVFoundation fixture-creation failure before the next tag-triggered build. Start from a new branch and bump all version files for any code fix; do not change the already published v1.0.0 assets.
3. Store work stays separate; ask before submitting for App Review. Full ledger: `docs/wordscut-release.md`; detailed public verification runbook: https://github.com/awaismirza/wordscut/blob/main/docs/verify-published-release.md; listing notes: `docs/store/wordscut-listing.md`.

### Previous Status / Resume / Next up: `main` v4.50.4 (+ CI/release workflows on `chore/ci-release-workflows`, v4.50.5)

> **CI/CD (v4.50.5, branch `chore/ci-release-workflows`):** `ci.yml` and tag-only `release.yml` written, never run on GitHub. Owner steps before the first signed release: create the Developer ID Application certificate, an App Store Connect API key, and the 7 Actions secrets (names in `docs/plans/ci-cd-release.md`); run `release.yml` via `workflow_dispatch` (dry run); download the DMG artifact and test it on a Mac; then push a `vX.Y.Z` tag. Also in 4.50.4: `npm run app:install` (signs, installs, no duplicate apps); 4.50.3: recorder-bar start hang fixed (`nextPaint`) — **not yet verified in the running app**.


> **4.50.2 is on `main`** (merged with the hand-off review fixes): second review fixes for the recording hand-off: A -> B -> A project switch restarts the camera composite; only definite refusals (`camera composite refused:` from Rust, size / sound / length mismatch, shared screen file) clear `pendingCamera`, transient failures keep it; no swap when the insertion was undone; Rust cancels a stale composite job of the same take and sweeps unreferenced `camera-composite-*.mp4` (`keep` list); sparse / VFR hand-off accepted when the composite is not shorter. Details in CHANGELOG 4.50.2 and architecture "Recording hand-off". AGENT-VERIFIED only (npm run check, 1348 Vitest, 458 lib + 17 cli Rust, Swift engine tests); **never run in the real app; no required CI exists, so the merge was gated only by these local checks and two independent Opus reviews.**

**Branch / PR state.** `main` = v4.50.2 (squash of `integration/native-media-engine-1`, PR #57, tag `v4.50.2`). No branches in flight except the owner's live checks below. The older notes below (wave-2, QA pass, perf worktree `../yusaf-cut-perf`, uncommitted export-planning experiments) are historical and still accurate for their own branches.

**AGENT-VERIFIED ONLY.** Everything below was checked by automated tests (`npm run check`, Vitest, `cargo test` incl. real-ffmpeg tests, `swift test` for the engine package); counts are in CHANGELOG 4.49.0 / 4.50.1 and the ledger in `docs/performance/recording-to-editor.md`. **Nothing was run in the real app: no real capture, no packaged build, the capture helper in the repo is a stub.** The synthetic Stop timings (`npm run bench:recording`, `docs/benchmarks/recording-stop-2026-10-21.json`) are labelled synthetic and were measured with the pre-4.50.1 `shortest=1` argv; they were not re-run.

**What shipped**
- **Stop-to-editor timing:** perf spans for stop / finalize / probe / import (`YUSAFCUT_PERF_SPANS=1`, `perf_spans_snapshot`), frontend stage marks (`src/lib/recordingTimeline.ts`: `stopRequested` ... `firstFrame`, `playable`, `checksumAttached`, `cameraComposited`), plan and numbers in `docs/performance/recording-to-editor.md`, computer-use test plan in `docs/performance/recording-verification-plan.md`.
- **No Stop-time camera composite (native screen + camera):** Stop hands back the stream-copied screen + the microphone / system-audio mix; the camera stays `tracks/camera.mp4`. The composite runs afterwards as the background job `composite_recording_camera` ("Adding camera to recording", nice 10, cancellable, one at a time; overlay `eof_action=pass`) and swaps the clip's file under guards: same project, same screen file, no other entry (any undo / redo state) sharing that file or checksum, same picture size / sound / video-stream length (checked in Rust and again in the editor), playback paused. The swap is not an undo step (history is rewritten). A persisted optional `pendingCamera` marker on the media entry survives save / quit / project switch and resumes on open; it is cleared on swap or when the composite is given up (toast names `tracks/camera.mp4`). Unused `camera-composite-<uuid>.mp4` files are deleted (`discard_recording_composite`). Design: `docs/architecture.md` "Recording hand-off".
- **Deferred SHA-256:** recording import uses `probe_media` (ffprobe only, `sha256: ""`); `hash_media` runs after insertion and is attached with a project / media / path guard (no undo step, project stays clean). Transcript cache is neither read nor written for media without a checksum. `import_media` is unchanged for other callers.
- **Native engine contract slice (OFF, nothing uses it):** `docs/native-engine.md`, Swift package `native/yusafcut-engine` (capabilities, render-plan validator, AVFoundation composition builder, CLI `capabilities | validate | probe-plan`), Rust `native_engine_capabilities` (`helper-missing` when absent), `src/lib/nativeEngine.ts` (plan compiler, timing mirror, `chooseEngine` = fallback unless `enabled: true`, `GenerationGate`), TS / Swift timing parity fixture.
- **Bench harness:** `npm run bench:recording` (synthetic ffmpeg tracks through the `finalize_args` argv shape; not production-path proof), `scripts/bench/recording/read-spans.md`.

**Known limitations**
- An export started before the swap renders **without the camera** (no export guard for a pending composite yet).
- The **FFmpeg-fallback recorder still composites at Stop** (only the native helper path is deferred).
- The preview proxy (non-Original quality) can be **built twice** (before and after the checksum attach / camera swap).
- The screen-only hand-off file is **kept** in the take folder after a swap (saved projects, snapshots or other windows may reference it).
- **No native playback or export:** preview is still one HTML5 `<video>`, export is still FFmpeg; the camera is baked into a file by FFmpeg, now in the background, not composed natively. No `recordingGroup` schema.
- The **helper `yusafcut-capture` and `yusafcut-engine` are not bundled or signed**; the committed capture binary is a stub (ffmpeg fallback), the engine reports `helper-missing`.
- A project closed without saving after the take loses the take as a whole (as before).

**Next up**
1. Owner runs the OWNER LIVE CHECKS (recording hand-off) below, with the real helper built (`npm run native:build`) and announced captures.
2. Decide on an export guard (wait for / refuse a pending composite) and whether to delete the kept screen-only file.
3. Open the PR for the integration branch when the checks pass; bump the version per `CLAUDE.md`.
4. Then the native engine milestones in `docs/ROADMAP.md` ("Native Apple media engine"): recording group schema, Metal compositing preview, native export, scheduling / memory, helper bundling and signing, packaged-build verification. Measure on real takes before changing any default.

### OWNER LIVE CHECKS: recording hand-off and background composite (open; v4.50.1)

Run with the real helper, announced captures, `YUSAFCUT_PERF_SPANS=1` if you want timings (`docs/performance/recording-verification-plan.md`):

1. Record **screen + camera (+ mic)** for 30-60 s, press Stop: the clip appears quickly, with no long "finishing" wait; compare Stop-to-editor against the pre-4.49 build if you have one.
2. **Immediately play and edit** (delete words, split, undo) while the Jobs list shows "Adding camera to recording": audio / picture stay in step, no stutter at a swap.
3. **The camera appears** after the background composite finishes (once playback is paused); picture, sound and word timing unchanged; edits made meanwhile still line up.
4. **Quit during the composite**, reopen the project: the composite resumes and the camera appears; also try save before the swap, and a project switch mid-composite ("Camera not added yet", resumes when reopened).
5. **Unplug the camera mid-take**: the take is saved, the picture keeps its full length after the swap, the bubble just disappears when the camera ends.
6. **Project switch** during the composite: no camera lands in the other project; the job is cancelled / the marker is kept.
7. **Undo / redo across the swap**: Undo never brings back the camera-less file; edits made before and after the swap undo normally.
8. **Masks**: add a privacy mask on the take before the swap; it stays on the same footage after the swap and in export (check coverage).
9. **Export before and after the swap**: before, the export has no camera (known); after, it has the camera, same timing and audio.
10. **Regression:** a screen-only take and a mic-only (voice-over) take behave as before (Stop, import, transcription, edit, export); an FFmpeg-fallback recording (stub helper) still works, just with the composite at Stop.
11. The checksum lands after import without marking the project unsaved; reopening an unsaved-checksum project backfills it.


> **Branch state (2026-10-21, supersedes the "qa/wave2-final, no PR" lines below):** `main` is v4.47.0 and already contains `qa/wave2-final` (PR #53). Open PRs: #54 (`fix/recorder-device-loss-v4.47.1`, native camera/microphone loss, Swift tests only, no hardware unplug test) and the v4.48.0 performance integration (`feature/perf-integration`: production-path benchmark harness, opt-in perf spans, capability-aware whisper backend ladder; `npm run check`, 1269 Vitest and 438 Rust lib tests pass; benchmark numbers in `docs/benchmarks/` and `docs/performance/` were measured on the pre-4.47 tree). The bundled whisper-cli cannot initialise without the Core ML encoder (`BUNDLED_BINARY_SUPPORTS_FALLBACK = false`), so a missing encoder fails fast; Metal-only is not claimed. Uncommitted export-planning work (`export_plan.rs`, bench fixtures 14-17) still sits in the `yusaf-cut-perf` worktree on `feature/apple-silicon-performance`: not integrated, not reviewed.

> **Latest (2026-10-21): `main` is v4.41.0 (PR #52 merged the QA pass). `qa/wave2-final` is v4.47.0, pushed, no PR.** It is `qa/wave2` (v4.46.0: `feature/voiceover-track` v4.42.0, `feature/device-frames` v4.44.0, `feature/keystroke-identity` v4.45.0) plus `feature/overlays-masks` (v4.43.0); those branches need no further work on their own. Merge decisions are in CHANGELOG 4.47.0. **AGENT-VERIFIED (automated only):** `npm run check`; 1269 Vitest; 424 lib + 17 cli Rust tests (1 ignored); 52 Swift tests (media:verify last run before the 4.47.0 fixes: 122 passed / 1 skipped); incl. real-ffmpeg integration exports for masks with a browser device frame + zoom + crop, a voice-over insert hold, an override take, duplicated / moved clips, and the coverage sheet with a device frame. **Nothing was recorded, heard or clicked in the running app.** Next: the owner runs the OWNER LIVE CHECKS below, then decides on the PR from `qa/wave2-final` to `main`.
>
> **Voice-over track (v4.42.0):** record narration at the playhead, review, Overlay / Insert / Override, preview, export, stems, captions; design in `docs/architecture.md` → "Voice-over track", changes in CHANGELOG 4.42.0. Real-ffmpeg exports with synthetic tones for override / overlay / insert and the unchanged golden argv.
>
> **Device frames (`feature/device-frames`, v4.44.0, merged into `qa/wave2`):** Look tab Device frame section (None / Browser / Laptop / Phone / Tablet; colour, browser theme and address text). Geometry is one pure module, `src/lib/deviceFrame.ts`; preview = CSS boxes (`sceneCss`), export = ffmpeg masks in `scene.rs` plus a private ASS file for the browser text (`prepare_frame_text`). Agent-verified: `npm run check`, 1165 Vitest, 366 lib + 17 cli Rust tests incl. real-ffmpeg pixel tests (even offsets and no 1 px seam in 4:2:0, masks rendered once, bezel colours, picture content, rounded corners alpha 0, title text, shadow alpha, end-to-end export with temp-file cleanup, zoom). **Not looked at in the running app:** the CSS preview, `drop-shadow` strength vs the export shadow, text rendering (Chromium vs libass) and the Look panel layout. See the OWNER LIVE CHECKS item 10.
>
> **Keystroke identity (`feature/keystroke-identity`, v4.45.0, merged into `qa/wave2`):** opt-in `recordKeyIdentity` / `recordAllCharacters` recorder options, helper `keyDescriptor` privacy rules, `name` / `secure` on `key` events, real key caps and "Typing (hidden)" in the overlay (TS + Rust parity fixture). Agent-run: `npm run check`, Vitest, `cargo test`, `swift test`, `swift build`. **Never exercised with real key presses or Input Monitoring.** **Privacy review fixes (same branch):** Option alone is not a shortcut for printable keys; ASCII-layout shortcut letters; Return/Tab/Space/Delete only with a modifier or the second opt-in; "all characters" never persisted; "Key names ON" indicator in the controller and menu bar; window capture names only the frontmost captured app; 0600 events.jsonl; "Strip key names" (project + snapshots); Input Monitoring required and checked. The committed `yusafcut-capture` binary is still the stub; no binary was committed.
>
> **On `main` since v4.41.0 (via `qa/integration-2`, PR #52)** (CHANGELOG 4.29.0–4.41.0): timeline lane visibility (View menu, Simple/Detailed, waveform and cut-map lanes); rebindable, modal/IME-guarded, layout-aware editor hotkeys; export formats (MOV, ProRes 422/HQ, GIF, M4A, WAV, range export, audio stems); FCPXML 1.10 export; audio mixer (per-track mute/solo/fades, music preview playback via `MusicPreview`, loudnorm target + loudness report); source crop and transparent background (ProRes 4444 alpha); styled + burned-in captions; annotations and opt-in keystroke overlay; clip ops (drag reorder, duplicate, ripple delete, `restoreWords`, Relink dialog); per-clip speed, mute, freeze holds, crossfade / dip transitions; `docs/ai/` design (no feature code). Final review fixes (lenient segment timing load, ffmeta temp cleanup, one-undo sliders, key-cap rule, `media:verify` list) are in v4.41.0.
>
> **AGENT-VERIFIED (automated only):** `npm run check`; 829 Vitest; 348 lib + 17 cli Rust tests (1 ignored), including real-ffmpeg pixel/duration/audio tests for crop, alpha, captions, annotations, key caps, speed/hold/transitions, loudnorm, stems and one combined 2x + hold + crossfade + crop + caption + annotation + ducked-music export; `npm run media:verify` 115 passed / 1 skipped against the bundled ffmpeg 7.1.1; several independent Opus reviews whose findings were fixed. **None of this was driven in the running desktop app.**
>
> **Release note:** builds older than 4.29 drop the fields added since (clip timing, caption style, annotations, keystrokes, music mute/solo/fades, crop, transparent background) when they save. Do not save a project in an older build. From 4.41.0, unknown per-segment keys are kept on save; other unknown project keys are still dropped.
>
> **Overlays and privacy masks (`feature/overlays-masks`, v4.43.0, merged into `qa/wave2-final`):** image / video overlays and privacy masks (CHANGELOG 4.43.0, architecture "Media overlays and privacy masks"). Agent-verified only: `npm run check`, Vitest, `cargo test` (real-ffmpeg pixel tests: overlay range / position / opacity / PNG alpha, ProRes 4444 alpha over transparent padding, blur region vs bit-identical outside, masks under zoom + crop at four times, mask before an annotation, GIF and stems, video-overlay audio, coverage sheet), `npm run media:verify`. A follow-up commit (same version) answers an independent privacy review: masks are now SOURCE-ANCHORED (`src/lib/masks.ts`, spans derived from the timeline at every use), applied per clip before transitions / speed / holds, placed per source (mixed aspect), re-applied over the cursor, key caps suppressed, strength floors, FCPXML confirm, coverage sheet over every occurrence as a cancellable job, hardened overlay inputs; each review item has a regression test (real ffmpeg where pixels matter: crossfade and dip on both sides of a cut, duplicated clip, 0.11 s mask at 4x, 4:3 source, cursor). A third commit answers a second adversarial review (content-identity matching for a file imported twice, masks placed from the decoded frame size so stale rotated sizes cannot misplace them plus size re-probe on open / relink, masks applied to overlays of masked footage, VFR held frames, mask + speed + crossfade + export fps, size-0 refusal, coverage of every place up to 12 with a 0600 file in a 0700 folder, sub-1 % sizes refused), each with a real-ffmpeg "green box" regression test. A fourth commit answers a third review (two-pass masking around a constant-rate conversion for VFR frames held into a mask, checksum-or-path file identity plus checksum backfill on open, exact float parsing and a 400-timeline TS/Rust span parity test, the cursor pass placed from the decoded frame, coverage job always finished). A fifth commit closes the final-gate findings (equal paths are always the same file, even with different stored checksums; dim-surround in the second pass so held frames are dimmed once). Owner live checks: OWNER LIVE CHECKS below.
>
> **Remaining unimplemented:** FCPXML fidelity for effects (scene, zoom, cursor, captions, annotations, timing, overlays are listed as unsupported; masks as NOT APPLIED), embedded agent, cloud/share, Screen Studio import, signed updates, AI-assisted editing beyond the `docs/ai/` design, HEVC with alpha (bundled `hevc_videotoolbox` writes no alpha).
>
> **Blocked for agents:** recording tests (the installed `/Applications/YusafCut.app` held the capture hardware with live ffmpeg avfoundation processes); desktop UI driving (no safe computer-use; owner asked agents to stop app testing on 2026-10-20).
>
> **Next up:** the owner runs the OWNER LIVE CHECKS below, then decides on the PR from `qa/wave2-final` to `main`.

### OWNER LIVE CHECKS (open; agents cannot run these)

From the QA pass (v4.29.0–v4.41.0), in the running app:

1. **Speed / hold / dip playback in the preview:** play across a 2x and a 0.5x clip (word highlight in step, normal pitch); a hold freezes the picture while the playhead moves, including pause/resume and seek inside a hold; dip overlay at a cut, crossfade badge; undo/redo of each Timing control.
2. **MusicPreview is audible** via the `asset://` URL; mute, solo and fades are heard; sync after seek/pause/rate change; audio stops on project switch and after removing a track.
3. **Export with bottom captions + key caps + fixed annotation + a cropped scene**, viewed in QuickTime (placement, text size, key caps above burned-in captions); a **transparent ProRes 4444** export opened in an NLE (alpha present; MP4 with transparency shows the warning and exports on black).
4. **Combined export:** 2x + hold + crossfade + range + stems + loudness target, compared with the timeline (timing, stem names `-voice-N` / `-music-N`, measured loudness in the toast).
5. **Duplicate / drag-move / ripple-delete**, then save, reopen, undo, redo (drag ghost, drop line, Esc, leaving the window; Option+Left/Right on a focused clip name).
6. **Relink dialog** with moved media: lists it, refuses a wrong file with the reason, relinks the right one, and undo afterwards.
7. **FCPXML import into Final Cut Pro** (clips, chapter markers, music lane).
8. **Shortcuts:** rebind one in Settings, an AZERTY layout (Cmd+Z undo), Cmd+S / Cmd+E while a modal is open, IME composition does not fire hotkeys.
9. **Packaged `npm run tauri:build` DMG:** export with burned-in captions (libass + CoreText fonts inside the signed app; CJK, each font in the list).
10. **Device frames (v4.44.0):** Look tab, pick each device on a 16:9 clip and on a 9:16 canvas: preview vs an exported frame (outline, bezel, island / traffic lights, address text, shadow); zoom a region (the device stays still, the picture zooms inside the screen); an annotation and a cursor; transparent background + ProRes 4444 opened in an NLE (clean silhouette, no fringe); undo / redo of each control, slider drag = one step; old projects look unchanged.

**Voice-over track (v4.42.0):**

1. Cmd+Option+V with the playhead mid-clip: countdown, bar with timer and moving input meter, the video plays from the anchor; Stop with Cmd+Option+V. Then also stop from the tray, from Cmd+Option+R and twice quickly: one review, one take.
2. Alignment: narrate in time with a visible event (a clap on screen); keep as Overlay and check in preview and export how far the voice is from the picture. If it is consistently late or early, set "Latency trim" in the Music panel and re-check (the take's t = 0 is the first accepted mic sample; residual delay is IPC + `<video>.play()` start).
3. Review keys: Space plays the take, M, O, R (retake re-records at the same anchor), D, Return; Escape closes and the take is still offered (Music panel button, shortcut) — also after quitting and reopening the app.
4. Insert: picture holds the anchor frame while the narration plays, then resumes at the right frame; captions, chapters, zoom and annotations after it are still aligned; undo / redo of Keep; remove the take in the Music dialog and the hold is gone.
5. Override on a screen recording that has voice + system audio in one track: the whole clip audio is muted only while the take plays, with no click at the edges; a music bed keeps playing; mute the take in the Music dialog and the original returns (preview and export).
6. Two overlapping override takes: only the newer one is heard in the overlap.
7. Background transcription of a kept take: captions show the take's words, not the muted original's; switch project during transcription and nothing lands in the other project.
8. Unplug the microphone mid-take; switch project while recording and while reviewing; a 0.1 s take (press twice fast) is discarded with a message; Discard removes the `rec-*` folder from `~/Library/Application Support/<app>/recordings` and Keep never does.
9. Settings → Shortcuts: rebind the voice-over key and a review key; the review key may equal an editor key (e.g. X) without a warning.
10. During a take: global ⌥⌘P and the tray Pause / Restart show "off during a voice-over" and the take keeps recording in step with the video; ⌥⌘R stops it.
11. Two Insert takes at the same playhead play one after the other; the Timing panel on that clip shows only the user's freeze plus a note; Duplicate of the clip does not copy the narration hold.
12. A music bed with "Duck under voice" is audibly lower under an overlay take in the export (the measured test duck is about 3.7 dB with a −24 dB take; the existing compressor settings decide how much).
13. Review focus: on open, Return keeps; Tab to Discard then Return discards (after the confirm for takes of 2 s or more); Space on the Override checkbox ticks it.

**Keystroke identity (v4.45.0):**

1. Rebuild the helper (`npm run native:build`), turn on "Record key names", record, press Cmd+K / arrows / Esc / F5 and check `events.jsonl` (mode -rw-------) has `name` only for those (typed letters, Return, Tab, Space, Delete and Option+letter have none).
2. On a Russian or German layout, Cmd+C logs `c`, Cmd+Shift+3 logs `3`, Option+L logs nothing.
3. Turn on "Also record all characters", check letters and Return/Tab/Space/Delete appear, quit and relaunch: it is off again while "Record key names" is still on.
4. The controller and menu bar show "Key names ON" / "All characters ON" during the take.
5. Window capture: type in another app while recording a window and check those presses have no `name`.
6. With Input Monitoring denied, Start says key names cannot be recorded.
7. Focus a password field (Safari login, then `sudo` in Terminal with and without Secure Keyboard Entry) and check what the log holds.
8. Overlay caps in preview and export; "Strip key names…" removes them, one Cmd+Z brings them back, snapshots are cleaned.

**Overlays and privacy masks (v4.43.0):**

1. Overlays tab → "Add image or video…": a PNG with transparency, a JPEG, an animated GIF and an MP4 with sound. Placement, opacity, rotation, corner radius and fades in the preview match an MP4 export viewed in QuickTime; "Follow zoom" moves with a zoom; a fixed overlay sits under annotations / captions / key caps.
2. Video overlay sync while playing, pausing, seeking and at 2x; "Include its audio" audible in preview and export, gain heard, silent when off.
3. Move an overlay file away and reopen: "Missing" in the list, striped placeholder in the preview, export refuses with the file name; Relink refuses a different file and accepts the moved original; Undo afterwards keeps the new path.
4. Privacy masks: solid / pixelate / blur / dim, rectangle and ellipse, in the preview (backdrop-filter and the pixelate canvas in WKWebView, a 4:3 clip in a 16:9 project) and in an export with a zoom, a cropped scene, captions, a crossfade at the mask's edge, the cursor drawn and a range; "Check coverage" (Jobs list, cancellable) shows every place the mask is on screen, all covered; the static-region / not-the-transcript note, the safe-for-text warning and the follow-zoom warning read clearly; FCPXML export asks first with Cancel focused.
5. Cut, duplicate, move, restore words and speed-change a clip under a mask and an overlay: the mask covers every copy of its footage (list shows ×N), the overlay stays on its content; one Cmd+Z per field edit. Open a project saved with an output-time mask from the first 4.43.0 commit: the conversion toast appears.
6. Keyboard only: add, select, edit and delete overlays and masks; screen-reader names of the list buttons and selects.
7. Masks with the wave-2 features (v4.47.0): a mask on a clip inside a browser / phone device frame with a zoom and a crop: the mask stays on the same footage in the preview and in an MP4 export, and the device title / notch draws over it; a voice-over **Insert** take on a masked clip: the held frame is masked during the whole hold (preview and export); an **Override** take on a masked clip: the narration and the muted original sound exactly as without the mask; duplicate and move a masked clip after an Insert take: every copy is masked; "Check coverage" with a device frame on.
8. "Check coverage" on a raw clip with ONE mask only (no scene / look, zoom, crop, cursor, overlays, annotations, captions or keys): the sheet opens and every frame is covered (this graph failed before the 4.47.0 fix). Also: open an older project (no checksums, or a rotated phone clip): it opens clean (no unsaved marker) and Undo is empty; a pixelate mask stays pixelated while scrubbing and right after a seek while paused.

Also look at and use with the keyboard: the timeline lane View menu (look, popover placement, `<video>` not remounting), the Look crop panel (fields, presets, match with the export), the Captions panel, the Overlays panel (add/edit/delete, arrow keys on swatches, Cmd+Z per edit, "All key presses" privacy note), and the Timing panel. Earlier per-feature lists that still apply: keystroke caps from a real native recording with Input Monitoring on; export-format extensions play in QuickTime/Finder; smart-cut MOV of an untouched recording.

The checks for v4.26.0–v4.28.0 on `main` (recorder bar, Agent CLI/MCP, transcript order) are listed in the merged notes below and are also still open.

> **AI-assisted editing, milestone 1 (design only):** `docs/ai/` (merged into `qa/integration` in 4.33.0) holds the capability inventory, contracts, eval plan and milestone/file-ownership plan. No feature code. Findings: the MLX sidecar is not wired into the app (removed v3.4.0), the built PyInstaller `mlx-sidecar` crashes on start (relative import in `__main__.py`), and no LLM, embedding or TTS weights are installed on the dev Mac (only whisper large-v3-turbo). **Next:** owner decides whether LLM use is acceptable per task (HANDOFF §5.1 says no LLM for chapters) and which models to download; then M2 "shared foundation" per `docs/ai/milestones.md`.

> **Merged to `main` (v4.25.0):**
> - **Code signing, notarization & direct distribution (`docs/distribution-and-signing.md`, `scripts/sign-and-notarize.sh`, `npm run sign:dmg`):** Complete guide, inside-out signing automation for all 5 native `arm64` sidecars, Apple Notary Service submission, stapling, and ready-to-run prompt for Claude / future agents.
> - **Native Apple Silicon (`arm64`) media packaging & performance tooling (`feature/arm64-media-packaging`, v4.25.0):** Native `arm64` `ffmpeg` and `ffprobe` (`7.1.1`) built from SHA-256-pinned upstream sources (`scripts/build-arm64-media.sh`, `npm run media:build`), verified across 101 compatibility checks (`scripts/verify-media-binaries.sh`, `npm run media:verify`), and benchmarked across 7 pipeline stages (`scripts/benchmark-media-pipeline.mjs`, `npm run media:bench`). All `x86_64` / Intel fallback paths removed. Full details in [`docs/performance/arm64-media-handoff.md`](performance/arm64-media-handoff.md) and [`docs/performance/arm64-media-packaging.md`](performance/arm64-media-packaging.md).
> - **Recorder session authority, desktop controller & compact setup (`feature/recorder-session-controller`, v4.22.0–v4.24.0):** Merged in PR #46 (`15e1071`).

> **Merged in PR #48 (`feature/recorder-modern-agent-cli`, v4.28.0):** Floating recorder bar (`docs/recorder-bar-design.md`): Record opens a separate `recorder-bar` window (`recorder-bar.html`, `src/recorderBar/`, `src-tauri/src/recorder_bar.rs`); the main window hides while it is up. Editor side: `recordingStore.openDialog()` routes by Settings `recording.setupStyle` (`bar` default / `dialog`), falls back to the dialog on error, listens for `recorder-bar:opts`, `recorder:open-dialog` and bar visibility; settings written by the bar sync to the editor via the `storage` event. Agent-run checks: `npm run check`, Vitest, `cargo test`. **OWNER REQUIRED manual checks:** (1) bar position, key focus and multi-display placement; (2) bar is excluded from the footage; (3) main window hides when the bar opens and restores on close, after a take and after an error; (4) permission chips (Allow screen recording, Open Settings, restart note); (5) camera preview inside the bar and device switching; (6) countdown in the bar, Esc cancels; (7) "More options…" opens the dialog; Settings Recorder style = Dialog skips the bar; (8) Area drawing on the thumbnail; (9) record shortcut while the bar is open starts the armed mode.

> **Earlier in the same branch (v4.27.0):** Agent CLI / MCP (`docs/agent-cli-design.md`): loopback server inside the app, `YusafCut agent …` CLI, `YusafCut mcp` stdio bridge, 20 tools with plan / confirm / apply and single-undo, "Project MCP Server" dialog, off by default and disabled in the MAS build. Also: recorder camera preview no longer cropped or zoomed; recorder panel styling modernized; Toolbar open-project and export refactored onto shared helpers (`src/lib/projectActions.ts`, `src/lib/exportOptions.ts`). Agent-run checks passed: `npm run check`, 564 Vitest, 237 lib + 17 cli Rust tests. **OWNER REQUIRED manual checks:** (1) open the Record panel and view the camera preview uncropped; (2) Toolbar open-project and export still work (refactored to shared helpers); (3) enable Agent access in the new dialog, then `"<BIN>" agent tool list`, a plan then apply of `edit_trim_silences`, Undo in the UI, and `claude mcp add yusafcut -- "<BIN>" mcp`. B-roll is deferred to v2 (the EDL has no overlay track).

> **Merged in PR #47 (`feature/recording-append-timeline-native-load`, v4.26.0):** transcript now laid out in output order (fixes recorded/added clip words landing mid-transcript), simplified timeline (ruler + clip bar + zoom lane), no blocking "Loading media" dialog, zoom highlights in the transcript, Zoom panel hides cursor tools for clips without cursor data. Agent-run: `npm run check` + 497 Vitest pass. **Owner must verify in the running app:** add a clip, record a second, check transcript order and timestamps; select clips and watch the timeline for layout shift; zoom-region word highlight; Zoom panel on a non-recorded clip. No profiling was done, so no performance numbers are claimed.

### Recorder Session, Controller & Compact Setup (`feature/recorder-session-controller`, v4.22.0–v4.24.0)

Started 2026-10-20 from `origin/main` `344a50b`, in a separate worktree so the owner
can keep testing `main`. **Do not merge to main until the owner says so.** Resume with
`cd /Users/awaisjamil/code/projects/yusaf-cut-recorder-next` (sibling of the primary
checkout; `git worktree list` shows it). Binaries there are local copies: FFmpeg,
FFprobe, Whisper copied from the primary checkout, real arm64 helper built by `npm run native:build`.

**Plan / sequence:** A authoritative Rust session (DONE, below) → B separate movable
controller window + native capture exclusion + menu-bar controls → C compact recorder
setup (460 px, area/permission IPC; DONE, below) → roadmap (editable camera layer, ARM FFmpeg (DONE in v4.25.0),
perf matrix, backlog — unchanged from §4.5/4.6 and the live log).

**Milestone A — implemented (v4.22.0).**
- New `src-tauri/src/recording_session.rs` (pure, unit-tested): session id, phases,
  revision-numbered snapshots, `authorize` (id + phase), abort signal, monotonic
  elapsed, markers, `interrupt`. `record.rs` reports into it; sink emits `record:snapshot`.
- Commands: `get_recording_snapshot`, `start_recording` (claims slot before the action
  lock), `pause/resume/stop/cancel/restart_recording(sessionId)`, `mark_recording`,
  `pending_recording_results`, `ack_recording_result`; event `record:finished`.
  `record:state` / `record:error` are gone.
- Frontend: `recordingStore` mirrors snapshots (`applySnapshot`, highest revision wins;
  `initRecorder` subscribes before fetching), import runs only from `record:finished`
  / pending results via `importFinishedRecording` (deduped per session id).
- Races addressed: cancel during native start (abort signal, helper killed, no FFmpeg
  fallback after cancel; resume wait cancellable); stop vs helper failure (Finalizing
  gate: `interrupt` only valid in Recording/Paused); late helper ticks (monotonic
  elapsed, phase owned by acks); old-session events (ids); helper `failed` state →
  `interrupted` with recoverable media; Swift `RecordingSession.stop()` idempotent;
  `HelperClient::request` lost-wakeup on EOF.
- **Automated tests only** — 17 session-state tests, a fake-client cancel test, store
  mirror/cancel/import-dedupe tests. NOT owner/UI verified: real cancel during a slow
  first frame, simultaneous tray+shortcut actions, helper kill mid-take, FFmpeg fallback.
- **Known limits:** no AVCaptureSession runtime-error/disconnect observers in Swift
  (camera/mic unplug may not be detected until Stop); FFmpeg exits with code 0/255 are
  treated as clean even if a device vanished; `restart_recording` can lose the race to
  a start from another window (then returns "already running" after discarding);
  `list_recording_devices` still takes no action lock.
- **Milestone A validation (this worktree, agent-run):** baseline before changes — check ok,
  441 JS, 178 Rust (1 ignored), Swift ok. After: `npm run check` ok; **446 JS / 196 Rust**
  (1 ignored benchmark) / Swift 33 core tests; `native:build` and `npm run build` ok. No
  Tauri bundle build, no app launch, no UI/computer-use test.
- **Owner test steps for A:** start a screen take and press Cancel immediately (also while
  macOS shows a permission prompt/slow first frame) — should return to idle in about a
  second and never start FFmpeg; mash tray Stop + shortcut Stop together (one saved take,
  imported once); pause/resume/mark; kill `yusafcut-capture` mid-take (expect an error
  toast then a saved, importable partial take); restart from the tray.

**Milestone B — implemented (v4.23.0), automated checks only.**
- Controller window: `controller.html` (second Vite entry) → `src/controller/ControllerApp.tsx`;
  Rust `controller.rs` creates/shows/hides/destroys it from the authority sink, persists
  position (`recording-controller.json` in app config dir), clamps to connected monitors on
  every show, hides instead of closing. Capability `capabilities/controller.json` (events +
  start-dragging only; app commands are still callable by any window — Tauri app-manifest
  command scoping was NOT adopted because it would require listing every command in
  `default.json`).
- Exclusion: `native/.../CaptureCore/Exclusion.swift` + filter/watcher in `RecordingSession.swift`;
  FFmpeg fallback hides the controller (`controller_view`). Tray row "Hide/Show Recording
  Controls"; `show_main_window` explicitly targets `main`.
- **Validation:** `npm run check` ok; **458 JS / 204 Rust (1 ignored) / Swift 36 core + 7 media**;
  `native:build`, `npm run build` (emits `dist/controller.html` + `controller-*.js`) and
  `npx tauri build --debug --bundles app --no-sign` all succeeded. App NOT launched.
  Bundle: `src-tauri/target/debug/bundle/macos/YusafCut.app` in this worktree (quit other
  YusafCut instances before opening it; it shares app data with main).
- **OWNER REQUIRED (nothing below was run by an agent):** (1) start a native screen take —
  controller appears, is NOT in the recorded footage (check the first seconds and after
  dragging it / switching Spaces); (2) it does not steal typing focus from the app being
  recorded (`focused(false)` is requested but macOS may still activate on click); (3) drag,
  quit/relaunch, unplug the display it is on, expect it to reappear on a connected screen;
  (4) Stop/Pause/Mark/Restart/Discard from controller, tray and shortcuts; editor restores
  and imports exactly once; (5) force FFmpeg (`YUSAFCUT_FORCE_FFMPEG=1`): controller stays
  hidden, tray + shortcuts still stop; (6) fullscreen Spaces and multiple displays; (7) tray
  title/timer while editor and controller are hidden. Known: camera/voice-over takes still
  use the in-editor HUD (no controller); area/window picker excludes the controller only
  for display/area capture.

**Milestone C — implemented (v4.24.0), automated checks only.**
- `RecorderDialog` is now a ≈460 px panel: Screen / Camera / Audio, Display / Window / Area,
  thumbnail, permission rows, camera preview + mic meter (webview `getUserMedia`), System-audio
  switch, collapsible Advanced (fps, countdown, hide window, transcribe, camera bubble), one Start
  button with shortcut and a visible disabled reason, shortcuts behind a help button.
  Pure logic: `src/lib/recorderSetup.ts`; parts: `SegmentedRadio`, `SourcePreview`, `useMediaPreview`.
- New wiring: Swift `thumbnail` command (`Thumbnails.swift`, macOS 14+, no prompt); Rust commands
  `request_recording_permissions`, `open_privacy_settings`, `recording_thumbnail` (all refuse
  while a take runs; permission kinds whitelisted); `RecordOptions.area` + `RecordingDevices.displays`;
  `build_start_params` emits helper `area` after validation; ffmpeg fallback refuses area takes.
  `recordingStore`: `deviceNotices`, `requestPermissions`, and `toStartOptions` (only the chosen
  source goes to Rust; `sourceKind` is UI-only). opts persistence and index selection unchanged.
- **Validation (this worktree, agent-run):** `npm run check` ok; **492 JS** (50 files) / **210 Rust**
  (1 ignored) / Swift **37 core + 7 media**; `native:build` and `npm run build` ok. No Tauri
  bundle build this time, no app launch, no UI/computer-use test.
- **OWNER REQUIRED (nothing below was run by an agent):** (1) open Record → panel is ≈460 px, fits a
  small window, Esc/Tab/arrow keys work; (2) thumbnails for display and window (needs macOS 14+ and
  Screen Recording) and Refresh; (3) draw an Area by dragging and by typing; record → footage is
  exactly that rectangle (also on a second/Retina display); (4) permission rows: reset TCC
  (`tccutil reset ScreenCapture dev.yusafcut.app`, also Camera/Microphone) → Allow shows the system
  prompt, denied → Open Settings opens the right pane and Re-check/focus updates; (5) camera preview
  and mic meter show the *right* device and release (camera light off) when the panel closes — the
  webview may refuse `getUserMedia` or match by name wrongly; (6) unplug camera/mic/display with the
  panel open → notice, another device selected, Start reason correct; (7) `YUSAFCUT_FORCE_FFMPEG=1`:
  Window/Area disabled, display take works; (8) Start with controller window still excluded from
  footage (Milestone B items remain unverified).
- **Known limits:** Area is drawn on a thumbnail, not a full-screen overlay; thumbnails need macOS 14;
  camera preview/mic meter are not from the helper; camera/voice-over takes still use the in-editor
  HUD; Swift still lacks AVCaptureSession disconnect observers.

**Next (roadmap):** original 0.501 s duration defect still unresolved/unreproduced;
editable camera layer; native ARM FFmpeg packaging completed in v4.25.0 (`docs/performance/arm64-media-packaging.md`);
release performance matrix; older editor backlog (§4.5/4.6).

**Status: merged to main.** PR #42 merged as `6072a7398625c7c2dbd35d0ec370914c94b2a666`,
tagged and pushed as **v4.21.0** (`feature/recording-native-continuation`). The owner explicitly requested merging
completed work and removing all six secondary worktrees on 2026-10-20.
Use the primary checkout **`/Users/awaisjamil/code/projects/yusaf-cut`** on `main`
now; do not resume in the retired temporary worktree paths below.
The original continuation started from `207464c` (v4.19.1).

```bash
cd /Users/awaisjamil/code/projects/yusaf-cut
git status
npm run tauri:dev  # OWNER runs and manually tests; agents must not launch UI tests
```

**Cleanup/recovery:** before removing any worktrees, all branch history was saved
in a verified Git bundle, tracked changes in binary patches, untracked source in
tar archives, and actual runtime binaries in deduplicated copies under
`.git/worktree-cleanup-backups/2026-10-20-v4.21.0/` in the primary checkout.
`manifest.json` maps paths, commits and patch/archive names. Branch refs were kept
at worktree cleanup; see the subsequent branch cleanup below.
The save/seek groundwork worktrees had uncommitted candidate changes; these are
preserved for recovery, not blindly reapplied over newer integrated code. The
primary checkout's old generated `tsconfig.tsbuildinfo` change is also backed up.
**Cleanup completed:** all six secondary worktrees were removed; `git worktree list`
shows only the primary checkout. No worktree dev server/app process was running.
`npm install` completed in primary. FFmpeg, FFprobe and Whisper were preserved, and
the real ARM64 native helper is installed locally (the tracked fallback stub stays
unchanged via `skip-worktree`, as set by the native build script). Main was clean
at integration verification. The old generated build-file change is in the backup,
not reapplied over the new checkout. No manual app tests were run during cleanup.

**Next up:** owner runs `npm run tauri:dev` here and tests recording duration,
pause/resume, native log attachment and styled export. The exact old 0.501-second
failure is still unconfirmed. Agents continue with the compact recorder/controller,
Rust session authority and remaining roadmap below on a fresh branch; no computer-use
testing unless the owner changes that instruction. Previous `/private/tmp` app-build
paths below are historical and were deleted with the worktree; rebuild in primary
if a standalone app is needed. Recovery copies remain local under `.git` and are
not pushed. No local recordings were uploaded.

### Retired worktree code audit — 2026-10-20

Owner asked to merge any remaining relevant worktree code after cleanup. Compared
all saved uncommitted source patches/archives and the three substantive retired
branch tips with main at `041815a`. **No additional application code was missing.**
Do not merge the historical branches wholesale merely because squash merges make
their commit IDs appear unmerged.

- **Save/seek groundwork:** saveQueue, seekQueue, usePreviewSource, waveform and
  their saved tests are already identical to main. The saved transcription patch
  reconstructs to exactly main's transcribe.rs. Clip roll/snapping fixes and tests
  differ only in formatting. Main's preview_cache.rs includes the newer waveform
  alignment work absent from the older save candidate. Main's HUD and its tests
  additionally include cancellable startup handling.
- **Playback branch `9d2b2c9`:** all 84 changed paths exist in main; 63 match exactly.
  Remaining paths are release/docs metadata or files subsequently enhanced by
  v4.19.2–4.21.0. Save/seek coordinators, clip editing, caches and waveform code
  match exactly.
- **Native helper branch `09380dc`:** all 49 changed paths exist; 28 match exactly.
  Native source differs only in the first-primary-sample origin/startup changes
  and their regression test. Rust/IPC integration has the subsequent timing,
  background-log and session guards from v4.21.0. The real local helper executable
  intentionally differs from the committed fallback stub.
- **Older Claude branch `d36172a`:** all 30 changed paths exist; 9 match exactly,
  including filler logic/store, Whisper word parsing and filler/pause/range tests.
  Extract-range, retiming, filler deletion and actual pause cutting remain in the
  current EDL/store/actions; UI entry points have moved with later editor changes.
- **Verification:** 117 focused tests across 10 files passed in primary: save queue,
  save coordinator, seek queue, preview source, clip editing, HUD, fillers, pause
  removal, pause shortening and marked-range editing. No application code changed,
  so full build suites were not repeated. No app/computer-use tests were run.

**Next up remains unchanged:** owner manual tests and the unfinished roadmap above.
All source backups remain available; historical branch refs are now in the recovery
bundles described below. Only the primary worktree exists.

### Stale branch cleanup — 2026-10-20

Owner requested removing branches no longer required. Deleted **16 stale local
branches and 34 stale remote branches** after checking ancestry, merged PR heads,
prior code-integration audit and superseded release contents. Remote deletions
used exact expected commit leases to reject concurrent changes. Tags were retained.

A fresh verified recovery bundle and full ref/SHA/deletion inventory are local at
`.git/branch-cleanup-backups/2026-10-20/{all-branches.bundle,manifest.json,completed.json}`.
This includes all refs immediately before deletion; it is not uploaded. Earlier
worktree source patches and archives are still in the worktree cleanup backup.
Recover a retired branch by fetching its old `refs/heads/<name>` from the bundle
into a new local branch; use manifest.json for the exact ref and commit.

**Remaining:** local `main`; remote `main` and **`chore/release-3.7.3`**. The latter
has unique release-dmg.sh changes (repository-path handling and PR URL parsing)
which are absent from current main; kept for a deliberate future review rather
than discarded. Old version-only release branches and branches whose behavior
was superseded were removed. The temporary docs branch for this record is removed
after merging. No application code changed and no app tests were run. **Next up:**
owner manual tests and the unfinished roadmap remain unchanged.

### Live continuation log — update after each meaningful finding/change/check

**Current code:** v4.19.2 timing and v4.20.0 cursor-export checkpoints are pushed.
v4.21.0 native capture/log integration is implemented and verified by automated
checks; PR #42 brings these completed checkpoints to main as v4.21.0.
Owner has explicitly stopped all further agent computer-use testing;
continue implementation and automated checks only. Compact recorder/controller,
public Rust session authority, exclusions, camera layer and release metrics remain.


- **Initial baseline:** required docs read; fresh worktree created; npm install completed.
  Ignored real FFmpeg/FFprobe/Whisper sidecars copied from the existing autozoom
  worktree. Baseline check + 432 JS tests passed. Sandboxed Rust run failed 10 hardware-encoder tests with VideoToolbox -12908; the same unchanged suite outside sandbox passed all 139.
- **Original priority:** investigate the 12-second UI / 0.501-second finalized
  audio mismatch. Known timer/startup issues are corrected in v4.19.2/4.21.0; the
  exact original severe truncation remains unconfirmed, not claimed fixed.
- **Initial inspection (hypotheses, not diagnosis):** current timer begins at
  process spawn, not first captured sample. Pause/stop wait for file size to be
  unchanged for 120 ms rather than awaiting process termination. Both need
  falsification against real capture/process output. Backend result duration is
  wall time; import probes the actual file. Keep these two measurements distinct.
- **Evidence/logs:** `/private/tmp/yusafcut-continuation-{check,js,rust}.log`.
- **Capture experiment:** bundled FFprobe reconfirmed old failing file 0.501 s,
  mono AAC 48 kHz / 22 packets. A fresh 12-second subprocess take with built-in
  microphone index 1 finalized to 11.594 s / 211605 bytes. First progress at ~1 s;
  process exited 134 ms after q, before old flush check returned. This attempt did
  NOT reproduce the 0.501-second defect. Raw local timing log and audio remain in
  `/private/tmp/yusafcut-capture-investigation/` (never commit media).
- **Environment:** actual device enumeration has iPhone mic at index 0 and built-in
  mic at index 1; sandbox enumeration had no devices. Use unsandboxed capture/tests.
  Historical test used `npm run tauri:dev` on port 1430, app log
  `/private/tmp/yusafcut-continuation-app.log`.
- **Real baseline UI reproduction:** own app on localhost:1430, built-in mic,
  paused at displayed 00:14 then stopped. Output file
  `rec-9278bd9d-a583-40ab-807d-58a9ddce16c5/voiceover-41f56ce5-2c3f-4261-a434-b1466c5cd01a.m4a`
  under app-data recordings is 11.573 s / 207814 bytes; imported timeline agrees.
  This confirms timer/media mismatch from counting startup, but does NOT reproduce
  or establish the precise cause of the older 0.501-second output.
- **Timing fix (v4.19.2; partial UI verification below):** FFmpeg progress
  (`out_time_us`) drives timer; start waits for first encoded sample; pause/stop
  await actual Terminated event before probing/renaming; probed durations replace
  wall-time results. Shared action gate covers finalization, ticker IDs prevent
  old-session ticks. New pure watch/progress tests added. Rust check running.
- **UI verification before owner stopped computer testing:** updated own app
  captured a first segment, paused, and displayed **00:10 Paused**; bundled FFprobe
  measured **10.997 s / 211126 bytes**, so displayed whole seconds agree with
  actual media. Session directory `rec-3deb1ae2-3b68-426e-b83d-4309fc961277`.
  Resume was issued, but final concatenation was NOT UI-verified.
- **Owner steering (2026-10-20): STOP computer-use/manual app testing by agent.**
  Owner will test and report issues. Continue code and automated checks. Never
  claim the remaining manual scenarios passed. The resumed FFmpeg test process
  (PID 93177) had already exited before cleanup (SIGINT returned no such process);
  no unrelated app/process was stopped. Owner may have stopped it in the UI.
  This was historical test state; no worktree dev server remained at cleanup.
- **Automated result:** final check + **434 frontend / 142 Rust tests** passed;
  logs `/private/tmp/yusafcut-capture-final-{check,js,rust}.log`. Final changes add
  exit/error handling and startup-state tests. No further computer-use tests.
- **Checkpoint:** `5ecda68` (v4.19.2) committed and pushed to origin on
  `feature/recording-native-continuation`; no PR/merge.
- **Cursor export implementation (v4.20.0):** pure streaming
  `src-tauri/src/cursor_export.rs` draws ASS vectors with bundled libass before
  zoom/scene. Includes source-time interpolation/smoothing, visibility/idle,
  six shapes, ripple/ring/bounce and two blurred trails. Export opts/Toolbar carry a drawCursor flag;
  settings/tracks travel once in Project.cursor; native code generates private 0600 activity file
  in a blocking worker, checks cancellation per frame, and removes it on exit.
  Audio-only exports ignore cursor styling; cursor activity forces re-encode.
- **Cursor checks so far:** shared TS-generated JSON samples pass Rust sampling;
  six actual FFmpeg glyph pixel/hotspot tests pass; actual export graph proves
  cursor -> zoom -> scene and temporary cleanup. Final check + **435 frontend / 149 Rust tests** passed; one benchmark is
  ignored by the default suite and was explicitly run successfully. The shared
  fixture also covers unknown future events not advancing the idle clock.
  Final gate logs: `/private/tmp/yusafcut-cursor-final3-{check,js,rust}.log`.
- **Synthetic benchmark:** 30 s, 1080p/30, macOS arrow + smoothing + ripple + trails:
  900 visible frames, 863633-byte ASS, 89.8 ms debug generation. Filter-only render
  1134/1113 ms with cursor versus 140/59 ms without. This is not a release or UI
  benchmark; no long-media memory claim. Report currently at
  `docs/benchmarks/cursor-vector-2026-10-20.json`. Actual copied FFmpeg is
  x86_64, despite the aarch64 filename; host is arm64. Do not call this native
  ARM performance. Fix/validate packaging sidecar architecture during integration.
- **Cursor checkpoint:** `ae6780e` (v4.20.0) committed and pushed.
- **Native integration (v4.21.0 checkpoint):** a full branch merge was aborted
  because squash history conflicted across unrelated editor files. Applied exactly
  `git diff 76361be^ 09380dc` with `git apply --3way`; conflicts are now resolved.
  Patch: `/private/tmp/yusafcut-native-integration.patch`. Do not merge the entire
  native branch again. Current code preserves cursor export and FFmpeg fixes.
- **Native changes:** real helper built (arm64, ~600 KB; build-native script keeps
  tracked fallback stub skip-worktree). Swift startup waits for first accepted
  primary media sample; its timestamp is the shared zero for tracks/header/logs.
  Rust follows helper media-clock state, serializes actions through finalization,
  scopes events to a UUID and probes final duration. No new separate wall timer.
  Cursor/typing monitoring is limited to screen takes.
- **Automatic cursor logs:** stop passes eventsPath into immediate append, then
  a bounded app-owned reader and module worker parse the log without holding up
  playback/transcription. Project/source guards and cancellation prevent attaching
  to another document; current/undo/redo snapshots retain cursor metadata without
  an extra undo step. Voice/webcam-only results do not attach screen cursor data.
- **Final v4.21.0 checks:** check + **441 JS / 178 Rust tests** passed; one cursor
  benchmark is default-ignored (explicitly run for v4.20.0). The real-capture E2E
  scenario remains env-gated and was NOT run. Swift **33 core + 7 generated-media**
  tests passed; real arm64 helper rebuilt (~616 KB). Production Vite build emits
  `cursorLog.worker-*.js` (verified). Logs `/private/tmp/yusafcut-v421-*`; Rust final
  log `/private/tmp/yusafcut-v421-rust-final.log`.
  Swift still reports sendability warnings around NSObject/GCD ownership; do not
  claim strict Swift 6 concurrency certification. Actual capture/log/permissions
  remain owner-run, not agent-tested. A static/VFR-input cursor pixel regression
  passes; cursor/zoom export now supplies frames independently of sparse input.
- **Packaged app:** `npx tauri build --debug --bundles app --no-sign` succeeded.
  Standalone app for owner testing (NOT launched/tested by agent):
  `/private/tmp/yusaf-cut-recording-continuation/src-tauri/target/debug/bundle/macos/YusafCut.app`.
  Quit older instances before opening this rebuilt app. It embeds the web worker
  and actual ARM helper; copied FFmpeg remains Intel. No release certification.
- **Next action:** compact recorder/controller and public Rust session-ID snapshot /
  actions; safe capture exclusion, area/permission IPC, editable camera and release
  measurements. Audit helper error/Stop reentrancy and AV interruption/device-loss
  handling. Startup cancellation can wait for the no-media deadline plus fallback;
  fix it in session authority. Keep the historical 0.501-second cause unconfirmed.
- **Owner manual test:** record 10–15 s on built-in mic, Pause and compare frozen
  timer to saved media duration; Resume for another 5 s and Stop; check the joined
  clip excludes paused time and both segments are present. Repeat a quick Stop
  during startup. Report device, displayed time and actual saved duration.
- **Session cleanup:** the own resumed capture ended before attempted cleanup;
  no active capture was killed. Own dev server still uses port 1430. Bundled debug
  app may still have the pre-final-rebuild Rust binary: rebuild before owner tests.
  No claim is made about user-observed final concatenation.


## 2. Repository and branch state

| Thing | State |
|---|---|
| `main` | v4.28.2 (PR #50, tag `v4.28.2`, 2026-10-21). Includes everything through the floating recorder bar and Agent CLI/MCP. No open feature branches in flight. |
| `qa/integration-2` | v4.41.0, pushed, no PR. `main` v4.28.2 plus the whole QA pass (4.29.0–4.41.0): every `feature/*` branch from the pass and `docs/ai-foundation-contracts` are merged in. Worktree `../yusaf-cut-int2`. See §1 OWNER LIVE CHECKS. |
| `feature/studio-recorder-zoom-backgrounds` | v4.17.0 base, squash-merged into `main` by PR #40. Its file tree at `ad2129a` matches `main` at `1d9879d`. |
| Auto zoom branch | `feature/auto-zoom-cursor`, v4.18.0 (`937c5fe`), includes main through `1d9879d`; steps 1–5 done, cursor export / native log attachment pending (§4.5). |
| Previous implementation | `feature/playback-recorder-improvements`, `9d2b2c9`, merged through PR #41. Worktree `../yusaf-cut-autozoom` preserved. |
| Active continuation | `feature/recording-native-continuation`, `/private/tmp/yusaf-cut-recording-continuation`, based on `origin/main` at `207464c`. See live log above. |
| Native capture source | `76361be` / `09380dc` integrated as a focused source patch in v4.21.0 continuation. Real capture verification is owner-run. Do not merge the old branch history again. See §4.1. |
| Stale branches | `feature/shorten-pauses-trim`, `feature/editor-ui-redesign`, `feature/auto-chapters-selection-menu` are already inside `main` via #39. `claude/*` are throwaway session worktrees, and `origin/codex/video-editor-ux-playback-timeline` and `origin/feat/v2.1-pro-sync-and-timeline` are old v2-era branches. Ignore them all. |
| CI | There is no `.github/workflows` directory. Tagging triggers nothing. Tags are lightweight `vX.Y.Z`. |

The 5 implementation commits on the studio base branch (now squashed into main), oldest first:

1. `4.15.0` menu-bar item, Settings tab, custom shortcuts, mark a moment, one-press start.
2. `4.16.0` Look tab (background, padding, corners, shadow, aspect) in preview and export.
3. `4.16.1` recorder crash fix (see §5.3).
4. (no bump) clip edit operations module `src/lib/clipEdit.ts` (see §4.2).
5. `4.17.0` zoom regions: selection flyout, timeline lane, preview, export.

**Merging is the owner's decision.** `CLAUDE.md` says do not create the PR or
merge unless the owner explicitly asks. `main` has a "review required" rule, so a
normal merge is blocked for the PR author. For #39 the owner explicitly approved
`gh pr merge --admin --squash`; that approval was for that PR only. Ask before
bypassing it again. When asked to release: open the PR from the working branch to
`main`, squash-merge, then tag the squash commit `v4.17.0` (or the current
version) and push the tag. PR titles used so far: `Release X.Y.Z: <summary>`.

## 3. What the product does now (by area, with the files that matter)

Local-first, Apple-Silicon-only text-based video editor. Tauri 2 (React + Rust).
The **EDL** (`src/lib/edl.ts`) is the single source of truth: every edit is a pure
transformation of `Project`.

| Area | What exists | Key files |
|---|---|---|
| Transcription | whisper.cpp (Core ML + Metal) via sidecar `whisper-cli`, DTW timestamps; sub-word tokens merged into words; word edges snapped to silence | `src-tauri/src/transcribe.rs`, `commands/transcribe.rs`, `src/lib/timestampSnap.ts` |
| Word editing | click/select words, delete, undo (50 steps), find/replace | `src/components/TranscriptEditor/*`, `src/stores/projectStore.ts` |
| Cleanup | filler chips with counts, review list (play / keep / cut each), pause threshold slider (remove or shorten), quick trim of silences; every bulk cut toasts with Undo | `sidebar/panels/CleanupPanel.tsx`, `src/hooks/useCleanupActions.ts`, `src/lib/fillers.ts`, `fillerStore.ts` |
| Auto chapters | model-free topic segmentation, reviewed before adding; Chapters tab lists/renames/deletes | `src/lib/autoChapters.ts`, `panels/ChaptersPanel.tsx` |
| Selection flyout | quick actions over selected text: Play, Cut, Keep only, Mark, Start chapter, Copy, Zoom in/out | `TranscriptEditor/SelectionMenu.tsx` |
| Look (scene) | background (presets/solid/gradient/image), padding, rounded corners, shadow, aspect; same layout maths feeds preview (CSS `cqw`) and export (ffmpeg graph) | `src/lib/scene.ts`, `sceneCss.ts`, `panels/ScenePanel.tsx`, `src-tauri/src/scene.rs` |
| Zoom regions | regions on the output timeline, eased motion, lane on the timeline, preview + export | `src/lib/zoom.ts`, `src-tauri/src/zoom.rs`, `Waveform/ZoomLane.tsx` |
| Recorder | ffmpeg avfoundation recorder, pause/resume segments, screen+camera as two files composited at stop, crash-safe fragmented MP4, auto-append to the timeline | `src-tauri/src/recorder.rs`, `commands/record.rs`, `src/stores/recordingStore.ts` |
| Menu bar + shortcuts + settings | tray item with live timer and controls; configurable global shortcuts; Settings tab pinned to the rail bottom | `src-tauri/src/tray.rs`, `src/lib/trayModel.ts`, `src/lib/shortcuts.ts`, `settings.ts`, `settingsStore.ts`, `panels/SettingsPanel.tsx` |
| Preview | prev/next cut buttons, live captions, "Preview · edited cut" tag; the `<video>` is never remounted (scene/zoom change only wrapper styles) | `src/components/VideoPreview/VideoPreview.tsx`, `src/lib/cuts.ts` |
| Export | smart-cut stream-copy path; full re-encode path builds one ffmpeg graph (`build_reencode_argv`); scene or zoom forces full re-encode | `src-tauri/src/commands/export.rs`, `smart_cut.rs` |
| Layout | single left rail of tabs (no workspace modes): Media, Transcribe, Cleanup, Chapters, Look, Find, Tools, Music, Export, Settings (bottom). Start screen when no media. | `src/components/editor/*`, `sidebar/registry.tsx` |

Invariants worth remembering: words are never mutated; a word belongs to the
clip holding its midpoint; scene/zoom/chapters are stored on `Project` (Rust keeps
`scene` and `zoomRegions` as raw JSON so saving never drops them); preview and
export share one source of geometry/motion (`scene.ts`, `zoom.ts`).

## 4. Status of the in-flight and planned work

### 4.1 Native Apple capture helper — CODE INTEGRATED; OWNER QA PENDING

**Current (v4.21.0):** native helper source and fallback routing are integrated,
real ARM64 binary built, Swift generated-media/core and Rust fake-helper checks
run. Startup is latched to accepted primary media; adapter uses the helper clock.
Automatic screen log attachment is implemented. No real native capture,
permission, global-menu or exclusion success is claimed. Source/control UI,
controller, public session API, area/permission IPC and editable camera are next.
The following records the original separate-branch brief for context.

The owner asked to move to Apple's own APIs and chose the order **capture first,
then rendering**. A Claude session ("Native Mac capture helper (ScreenCaptureKit)")
started this on 2026-10-19 in its own worktree
`.claude/worktrees/intelligent-joliot-3ffd52`, branch `feature/native-capture-helper`
(cut from 4.17.0). **Check that branch (`git log feature/native-capture-helper`)
for its progress before touching anything in this area; do not duplicate it.** It
was told to write `events.jsonl` exactly as in `docs/cursor-events.md`. If you
are asked to continue it, the brief it was given is:

- New Swift package `native/yusafcut-capture` (swift-tools 5.9, macOS 13), built
  to a Tauri sidecar `yusafcut-capture-aarch64-apple-darwin`, controlled with JSON
  lines over stdin/stdout (same pattern as the MLX sidecar).
- Commands: `list-devices` (displays, windows, cameras, mics), `start`
  (display | window | area, camera, microphone, systemAudio, fps, outDir), `pause`,
  `resume`, `stop`, `status`.
- Record with ScreenCaptureKit (screen + system audio) and AVCaptureSession
  (camera + mic) into **separate crash-safe files** via AVAssetWriter, plus
  `events.jsonl` with cursor position (~60 Hz), clicks and key-down times on **one
  shared clock**. Option to hide the real cursor (it will be redrawn later).
- Rust side spawns the helper behind the existing commands (`start_recording`,
  pause/resume/stop/cancel, `list_recording_devices`, `record:state`,
  `record:error`) and **falls back to the ffmpeg recorder** if the helper is
  missing. Do not break the tray, shortcuts or settings.
- `native:build` npm script (swift build, copy to `src-tauri/binaries/`), wire into
  `tauri.conf.json` `externalBin` and `setup:all`; Info.plist usage strings and
  entitlements.
- Tests: `swift test` for pure parts; Rust protocol tests with a fake helper;
  manual QA checklist; be honest about what needs macOS permissions to verify.
- Run it in its **own git worktree** (see §7).

After capture: auto-zoom from the cursor/click log, cursor effects, an editable
webcam layer (bubble/rounded/rectangle shapes, size, drag placement, mirror,
hide while zoomed), then **native rendering** (Core Image on Metal through
AVAssetReader/Writer for scene + zoom + webcam, ffmpeg kept as fallback).
Open risks: needs Xcode at build time; the Mac App Store sandbox probably blocks
key capture; more binaries to sign.

### 4.2 Timeline editor UI — trim/split/roll interface IMPLEMENTED (4.19.0)

Owner request: keep it text-first, but add real timeline editing so if Whisper
misses a word they can trim the start or end of a clip, with a better timeline UI.

Done: `src/lib/clipEdit.ts` (+ `tests/clipEdit.test.ts`, 28 tests incl. a random
invariant test): `trimClipEdge`, `edgeLimits`, `splitClipAt`, `deleteClip` (ripple),
`rollEdit`, `snapTo`, `snapCandidates`, `listClips`. Extending a clip over audio
that has words brings them back from `originalWords`.

Implemented in §4.6: optional `Project.originalTranscripts` mirrored by Rust,
source-aligned real multiresolution audio peaks, and a separate clip lane with
trim handles, keyboard frame/second nudges, split-at-playhead and roll controls.
Drags commit once; undo/redo retains background recognition results. Legacy
projects open, with an explicit warning that extension cannot recover deleted
words without full originals. `rollEdit` now moves both edges atomically and
keeps words/snapping isolated by source media (35 pure clip tests).

Still not implemented from this older expanded UI wish list: S/Q/W shortcuts,
clip-delete interface, a draggable roll handle, and clip-selection-to-transcript
highlighting. The attached newer roadmap's core trim/split/roll interface is in
place; these additional controls must not be described as shipped.

### 4.3 Everything else from the plan

| Item | State |
|---|---|
| Auto zoom (follow cursor) and cursor styling | Steps 1–7 implemented through v4.21.0 continuation; real native-log verification owner-run, see §4.5 |
| Webcam as an editable layer | waits on 4.1 (needs a separate camera track) |
| Native rendering (Core Image / Metal) | after 4.1 |
| "Undo last 10 s" while recording | not built (needs segment trimming) |
| Keystroke overlay, speed regions, GIF export, webcam background blur | later |
| Apple on-device speech as an alternative transcriber | optional, later |

### 4.4 Known gaps and unverified things (be honest about these)

- **Not verified in the running app:** the menu-bar item, the Settings tab, the
  Look tab, the Cleanup/Chapters/Find panels and the selection flyout were checked
  by tests and (for CSS) a static page, **not** with a real transcript or camera.
  Run the manual checklist in `docs/manual-test.md` ("Studio features") first.
- **Sidecar state:** the current autozoom worktree has real ignored FFmpeg, FFprobe and whisper-cli binaries. A 16.64-second audio take was captured and transcribed by large-v3-turbo during §4.6 UI verification. Check actual sidecar files when changing checkouts; the earlier stub warning is historical.
- **Pause chips are not restored by Undo** (pause tokens live outside the undo
  history; `src/stores/projectStore.ts` `pauseTokens`).
- **Pause tokens are not saved** in the `.scribe` bundle.
- `docs/yusafcut-spec.md` is the original design spec and is partly out of date
  (it still describes an LLM chapter feature and older recorder behaviour).
- Capture error text for the old crash came from the owner's machine; the
  exact trigger of `best_input >= 0` was never reproduced with synthetic inputs.

### 4.5 Auto zoom, follow cursor and cursor styling — STEPS 1–7 IMPLEMENTED; REAL CAPTURE QA OWNER-RUN

**Latest status (2026-10-20, v4.20.0):** step 6 now implemented in the current
continuation worktree (§1): pure streaming ASS vectors through bundled FFmpeg,
private/cancellable activity-file lifecycle, typed IPC/Toolbar draw flag (tracks travel once in Project.cursor) and
cursor-before-zoom-before-scene composition. Shared TS/Rust samples and actual
FFmpeg glyph/effect/geometry tests pass; full final checks are being completed.
Manual app review is owner-run. Step 7 is implemented in v4.21.0 via native
eventsPath, guarded background parsing and metadata-history rebasing.
Latest gates: check, 435 frontend and 149 Rust tests passed; explicit synthetic
benchmark also passed. Final fixture/predicate rerun also passed; logs are in §1.

**Historical status (2026-10-19, v4.18.0):** implemented on
`feature/auto-zoom-cursor`, own worktree
`/Users/awaisjamil/code/projects/yusaf-cut-autozoom`, cut from
`origin/feature/studio-recorder-zoom-backgrounds` at `ad2129a` (v4.17.0).
This is a partial delivery; the full §4.5 definition of done is not met.

Merged `origin/main` (`1d9879d`, release 4.17.0) into this branch on
2026-10-19 at the owner’s request. Its tree exactly matched the original
`ad2129a` base, so squash-history conflicts were resolved by retaining the
4.18.0 auto-zoom implementation. No new behavior or version bump was needed.
Verification after the merge: check, 364 TypeScript tests and 121 Rust tests pass.

- **1 done:** tolerant `cursor.ts` parser/model, interpolation, deterministic
  smoothing with preserved endpoints and no outside-boundary smearing. Fixture
  generator in `tests/fixtures/cursorLogs.ts` covers clicks, typing, long idle,
  fast flicks, and cursor leaving the capture area.
- **2 done:** `autoZoom.ts` clusters surviving click/typing activity per EDL shot,
  lead/hold, sensitivity, scale, trigger toggles, travel rejection, deterministic
  ids, min-duration and non-overlap. Cuts remove triggers and shift suggestions;
  repeated media clips and unrelated media are tested.
- **3 done:** optional follow/focus keys, 0.25-second generation, interpolation in
  preview and ffmpeg, keys retained on drag/trim/split/save and retimed through
  cuts. A manual timeline focus choice stops following. Shared JSON fixture plus
  real-ffmpeg pixel checks prove moving-focus/ease parity.
- **4 done:** Zoom rail tab, persisted/sanitized project preferences and per-media
  source tracks (Rust raw JSON), review list with play/keep/remove and one-step
  undoable Add/Replace. Reviews are invalidated by project edits. Auto zoom off
  prevents generation; it does not erase existing regions.
- **5 done:** SVG cursor overlay sharing the permanent video zoom/scene wrapper;
  show/hide, six shapes, size, colour, smoothing, ripple/ring/bounce, idle hiding,
  optional blurred trails. DOM test proves the video node survives setting changes.
- **6 done in 4.20.0:** `cursor_export.rs`, ExportOpts/Toolbar cursor payload,
  private temporary ASS vectors rather than sprites, cancellation/cleanup,
  six glyphs/effects/trails/idle, cuts/repeats/source geometry and zoom/scene order.
  Real FFmpeg pixel tests plus shared TS sampling and a synthetic filter benchmark
  are included. Owner handles manual visual validation; no native renderer
  deferral or release-performance claim is made.
- **7 implemented in 4.21.0:** native screen results attach eventsPath after
  immediate playable append. Bounded app-owned reader, worker parsing, document /
  source guards, cancellation and undo/redo metadata rebasing are covered by tests.
  Missing logs preserve media. No real native cursor log was verified: owner now
  runs manual capture tests. Local JSONL import and labelled development demo remain.


**Verification:** baseline check + 328 TS + 118 Rust passed (copied ignored
sidecars from the original checkout into this worktree first). After steps 1–5:
check + 364 TS + 121 Rust passed, using the real bundled ffmpeg. Two existing
scene-gradient pixel tests failed intermittently on the first TypeScript-only
step-1 run; a complete retry and later step runs passed without changing scene
code. `npm run tauri:dev` ran on port 1421 because 1420 was occupied. Bundled the
debug binary with `npx tauri bundle --debug --bundles app --no-sign` so UI tools
could identify this checkout; a standalone Vite server on 1421 kept that debug
bundle live. In the running app, opened a disposable synthetic 20-second project,
loaded the demo (608 positions), enabled Follow cursor, generated/reviewed/added
four regions, and verified muted playback with the cursor visible. Native
capture permissions/real cursor logs and cursor styling export remain unverified.

**Current continuation:** the owner subsequently requested the saved playback/recorder
plan, post-recording responsiveness, movable/hidden controls, computer-use tests,
and a final commit/push/merge once **everything** is complete. Work continues on
`feature/playback-recorder-improvements` (§4.6). The new request authorizes normal
merge when finished; do not treat this as permission to bypass required review.
Steps 6–7 have since been implemented in the current continuation; real native
recording QA remains owner-run.

**Next up for §4.5:** owner-run native capture/log/preview/export validation.
Code integration is complete; compact source/controller UI, exclusion and public
session authority remain in §4.6. Source remains on the continuation branch;
main includes only the earlier checkpoint through PR #41.

Original implementation brief follows for the remaining work:

Owner request: an **Auto zoom** option (in the Settings or a Zoom page) that
generates zoom regions from cursor activity, with a **Follow cursor** switch, plus
**cursor styling**, like Screenkite and Recordly. Reference behaviour:

- *Screenkite:* auto zoom that follows the cursor and zooms on each click and
  keystroke as you record.
- *Recordly:* zoom regions suggested automatically from cursor activity, then
  editable by drag on the timeline; cursor overlay with size, smoothing, motion
  blur, click bounce, cursor sway, a loop mode, and macOS-style cursor assets.

**The data comes from the native capture helper (§4.1), which is being built in
another worktree. Do not wait for it:** the format is fixed in
[`docs/cursor-events.md`](cursor-events.md) (`events.jsonl`: header, `move`,
`down`/`up`, `key`, `scroll`, optional `cursorshape`, positions normalised to the
captured area, time = source time of the media). Build and test against
synthetic logs now; wiring to real recordings is the last step.

**Build order (each step shippable and tested):**

1. **Parse and model (pure, no UI).** `src/lib/cursor.ts`: tolerant `parseCursorLog`
   (skip bad lines, unknown types; sort by `t`), a processed `CursorTrack`
   (flat arrays are fine), `cursorAt(track, t)` with interpolation, and smoothing
   (e.g. one-euro filter or critically damped spring) with tests for: jitter is
   reduced, endpoints preserved, no overshoot past the data, deterministic.
   `tests/fixtures/` generator for synthetic logs (click clusters, typing bursts,
   long idle, fast flicks, cursor leaving the area).
2. **Auto zoom generator (pure).** `src/lib/autoZoom.ts`: turn a `CursorTrack` into
   `ZoomRegion[]` using existing helpers in `src/lib/zoom.ts` (`addZoomRegion`,
   `normalizeRegions`, `retimeZoomRegions`). Suggested rule: cluster clicks and
   typing bursts; region = first event minus a lead (about 0.4 s) to last event
   plus a hold (about 1.2 s); merge clusters closer than about 2 s; focus = mean
   cursor position of the cluster, clamped so the view stays inside the picture;
   skip clusters where the cursor travels far (zoom out instead); respect
   `MIN_REGION_SEC` and never overlap. Sensitivity low/medium/high changes the
   thresholds. Map source time to output time through the EDL so it works after
   cuts. Tests: non-overlap and validity for every fixture, stability (same input,
   same output), cuts remove or shift regions correctly.
3. **Follow cursor in the zoom motion.** Add `follow?: boolean` (and a sampled
   `focusKeys?: {t,x,y}[]`, about one key per 0.25 s, smoothed) to `ZoomRegion` in
   `src/lib/zoom.ts`; `sampleZoom` interpolates the focus along the keys.
   Mirror it in `src-tauri/src/zoom.rs` (the exporter builds the same motion as an
   ffmpeg expression of `t`; piecewise-linear focus is the simplest, or drive
   `crop` x/y with `sendcmd`). Keep the existing preview/export parity tests and
   add one for a moving focus. Rust keeps `zoomRegions` as raw JSON, so no struct
   change is needed unless you add a typed field.
4. **Zoom and Cursor panel (UI).** A new rail tab (suggested name **Zoom**, icon
   `ZoomIn`, registered in `src/components/editor/sidebar/registry.tsx`; update
   `tests/panelRegistry.test.ts`). Sections: *Auto zoom* (on/off, scale, sensitivity,
   clicks/typing toggles, **Follow cursor** switch, "Generate from cursor" that shows
   a review list like Cleanup before adding: per row play / keep / remove, then Add
   or Replace); *Cursor* styling (below). It must say clearly when a recording has
   no cursor log ("Recorded without cursor data. New recordings made with the
   native recorder include it."). Persist the settings in the project (a new
   optional `Project.cursor` field, raw JSON in Rust like `scene`, sanitised by a
   `sanitize*` function like `sanitizeScene`).
5. **Cursor styling (preview).** `CursorStyle`: show/hide, style (arrow, pointer,
   dot, ring, crosshair, macOS-style arrow), size, colour, smoothing, click effect
   (none, ripple, ring, bounce), hide when idle, optional motion blur. Render the
   cursor as an overlay inside the scene stage in `VideoPreview.tsx` so it scales
   and zooms with the picture (the wrapper elements already exist; do not remount
   the `<video>`). Use inline SVG or CSS shapes (no network, no new assets unless
   bundled).
6. **Cursor styling (export).** The recorded cursor should be hidden at capture
   (the helper has an option) and redrawn here. In ffmpeg, a moving sprite can be
   an `overlay` driven by `sendcmd` (x and y commands from a generated file, one
   per frame) and click effects as extra overlays gated with `enable=between(t,..)`;
   build it in a new pure module (like `scene.rs` / `zoom.rs`) and test it with
   the real bundled ffmpeg as those modules do. If this proves too heavy for
   ffmpeg, document it and leave export to the native renderer step (§4.3), but
   say so in `CHANGELOG.md`.
7. **Wire real data.** When the native helper lands, `recordingStore.ts` stores the
   `events.jsonl` path/track for the appended media and the panel works on real
   recordings. Until then, offer a clearly labelled dev action or a script to load
   a fixture log so the UI can be exercised.

**Files you will touch:** new `src/lib/cursor.ts`, `autoZoom.ts`, a cursor-style
module, `src/components/editor/sidebar/panels/ZoomPanel.tsx`, `src/lib/zoom.ts`,
`src-tauri/src/zoom.rs`, `VideoPreview.tsx` (overlay), `Toolbar.tsx` (export
payload), `ipc.ts`, `src/stores/projectStore.ts`, `edl.ts` (+ Rust `edl.rs` for the
raw field), `globals.css`, tests, docs.

**Do not touch (other agents own them):** `src-tauri/src/recorder.rs`,
`src-tauri/src/commands/record.rs`, the `native/` folder, `tauri.conf.json`
externalBin, and `Waveform.tsx` beyond what zoom needs (the timeline editor agent
will rework it; if you must change `ZoomLane`, keep it small).

**Definition of done:** `npm run check`, `npm test` and `cargo test` pass; pure
libs have tests; preview and export parity is tested; the panel works on fixtures;
docs, CHANGELOG and version bumped; HANDOFF §4.5 updated with what is done and what
is not. State plainly what you could not verify without a real cursor log.

### 4.6 Playback / accurate timeline / recorder improvement plan — IMPLEMENTATION IN PROGRESS

**Status (2026-10-19, v4.19.1 audit; implementation 4.19.0):** own branch
`feature/playback-recorder-improvements` in `../yusaf-cut-autozoom`, starting at
`937c5fe`. Exact supplied plan saved in
`docs/plans/playback-recorder-improvement-plan.md`. The full plan is NOT complete.
The owner subsequently explicitly requested the checkpoint admin merge: PR #41
merged at `207464c`, tagged v4.19.1. Remaining work continues on the branch listed
in §1; eventual merge is authorized when the requested work is complete.

**Done:**
- Cached `TimelineIndex`, binary seeks and entry-anchored sequential playback,
  including repeated source ranges. Stable video element; rVFC ownership while
  playing, audio RAF fallback, coalesced decoder seeks with exact drag release,
  media/edit generations and stale-frame protection. Pausing cancels a pending
  resume across metadata loads.
- Precise imperative frame bus for playhead/zoom and isolated cursor rendering;
  coarse store time at about 10 Hz plus word/entry changes. Cached transcript DOM
  mapping, only previous/next highlights, visibility reads on word transitions,
  follow scrolling suspended during manual navigation.
- Opt-in bounded local frame/seeked/presented-frame/cut/React/long-task/save/heap
  diagnostics, explicit unsupported measurements and periodic optional JS-heap
  sampling. No telemetry. Saved Node lookup and debug UI samples under benchmarks.
- Optional full `originalTranscripts` through TS/Rust serialization. Cache v2
  never promotes edited legacy words to full originals. Real source-PTS-aligned
  FFmpeg PCM peaks, maximum-reduced resolutions, fingerprinted disposable caches
  and a viewport-sized canvas. Clip trim/split/roll store actions, snap feedback,
  keyboard frame/second nudges, local drag drafts, one release commit, capture
  cleanup and undo regression coverage. Secondary zoom lane can be collapsed.
- Original/Balanced/Low preview with original-media fallback while proxies build,
  source/quality ready-path reuse, stale-result guards and decode fallback.
  Exports always keep originals. Cache workers validate, stage uniquely, publish
  atomically and can be cancelled in Jobs; one shared analysis slot also bounds
  transcription. FFprobe and streaming SHA run concurrently. Running extraction
  and Whisper children honor cancellation; Core ML preparation still only checks
  cancellation once preparation returns.
- Serialized coalescing save queue tied to immutable snapshots, explicit
  superseded outcomes and surfaced failures. Rust process-wide save gate + UUID
  temporary files with failure cleanup. Undo after save is dirty. Dirty/path
  updates create no history entry; background recognition rebases current and
  applicable past/future source ranges without becoming an undo-transcription.
- **Recording completion:** append playable media immediately after import;
  Whisper runs in background with status-bar progress. Editing during recognition
  survives completion; document switches cannot import/attach to another project.
  Retranscription controls are disabled for an already recognizing source.
- FFmpeg gradient seed/speed fixed for deterministic output and pixel tests.

**User's latest HUD request:** camera/audio controls are draggable,
with normalized/clamped remembered position, a dedicated Hide action and Settings
show/hide preference. Screen modes suppress the in-editor HUD throughout capture,
pause and finalization; the countdown is painted away before capture starts.
Menu-bar timer/actions and global shortcuts remain independent. This is the
fallback safety behavior, **not** the separate native desktop controller/filter.

**Verification:** final `npm run check`, **432 frontend tests (44 files)** and
**139 Rust tests** passed after the HUD addition. A self-contained debug app built successfully
with `npx tauri build --debug --bundles app --no-sign`; `npm run tauri:dev` also
ran on 1422 (1420 occupied). Used computer use against the own worktree app,
not `/Applications/YusafCut.app`: opened synthetic cursor project, muted playback,
real waveform, Original→Balanced generation and diagnostics; captured a real
16.64-second audio take with the built-in microphone. The take played while
Whisper was at **56%**, without a blocking transcription dialog. Recognition
completed; split at 11.54 s, roll +0.10 s to 11.64 s and one-step undo back to
11.54 s were verified in the UI. Clip keyboard behavior has regression tests;
a native AX click did not focus the trim button, so no UI keyboard claim is made.
Also computer-tested a second audio take: paused at 12 s, dragged the HUD away
from centre, hid it, restored it through Settings without discarding the paused
take, then stopped through the shared dispatcher. Screen-mode overlay suppression
is covered for recording/paused/finalizing/processing by tests; a new screen
capture/exclusion video was not verified. SystemUIServer/ControlCenter bindings
timed out and isolated app/desktop screenshots omit the system status menu, so
actual Mac menu-bar clicking remains unverified. Tool-injected global recording
keystrokes produced no state change; do not claim those were UI-verified either.
Existing tray/shortcut model/dispatch tests pass. The menu-bar implementation
was retained, not replaced by a verified native desktop controller.

Debug sample (not release certification): synchronous frame-work p95 **1 ms**,
1308 samples; presented-seek p95 **330 ms** from only three mixed source/proxy
seeks. **Do not claim the 150-ms target met.** JS heap, long tasks and React
Profiler were unavailable in that production-React debug bundle. No long-4K,
multiple-media, 30-minute memory soak or release performance matrix was run.
The native playback gate therefore has no pass/fail conclusion yet.

**New unresolved capture finding:** the second HUD test paused at UI **00:12**,
but its finalized M4A and imported EDL duration were **0.501 seconds** (bundled
FFprobe confirmed 11,604 bytes / 0.501 s). The first take correctly contained
**16.640 seconds** (309,273 bytes). No cause or fix is claimed. Preserve the
recording files locally; do not commit microphone media. Reproduce this pause /
startup / flush timing issue as a priority in native capture integration before
claiming reliable recording or merging. The recorder backend files were not
changed by this checkpoint. The test app is idle and its original Screen+Camera
mode was restored; existing unrelated `/Applications` capture processes were
not stopped. `6e922b3` is the pushed implementation checkpoint.

**Not done / next up:**
1. v4.19.0 checkpoint contains the completed hide/move fallback, responsive
   recording pipeline and playback/timeline work, with docs/version/tests. Verify
   real menu-bar clicks/global shortcuts and screen footage from the owner's
   desktop when accessible. No system-wide menu-bar UI success is claimed.
2. Native source and log attachment are integrated in v4.21.0; cursor export
   shipped on the branch in v4.20.0. Owner-run duration/native-log/permissions QA
   is still outstanding. No real native cursor log has been verified.
3. Phase 3: compact Display/Window/Area setup with permission/device/meter/preview
   states; Rust serialized session authority with snapshots/session IDs; separate
   narrow-capability desktop pill, capture exclusion or hidden fallback, remembered
   screen-clamped position; editable camera from separate tracks. Native area is
   helper-only, permission-request IPC and controller exclusion are not wired yet.
4. Run the packaged-release benchmark matrix and memory soak. Only if measured
   targets still miss after proxies, implement AVFoundation playback behind the
   existing transport; Metal/effect rendering is a separate measurement decision.
5. Reconcile latest main, final check/tests/Swift/UI verification, then normal
   owner-authorized merge. Main requires review; earlier admin-bypass permission
   applied only to #39. Do not bypass that rule without explicit approval.

Do not mistake the older in-app HUD for an excluded desktop controller. Existing
`/Applications` capture processes were observed during UI testing and left alone;
no unrelated recording was stopped. Local QA media/sidecars stay ignored and are
not committed. Restore generated `tsconfig.tsbuildinfo` after final checks.

## 5. Things learned the hard way

### 5.1 Owner preferences and decisions
- Wants a best-in-class, Descript/Screen-Studio-grade experience, text-first, 100%
  local. Discuss big architectural moves first (they asked "discuss with me" for
  chapters), then build.
- Chapters: **no LLM**. Decision: model-free segmentation (an LLM is "too much
  overhead"). The MLX sidecar's `summarise` exists but is not wired to the app.
- Notifications dismiss after 5 s (hover holds them open).
- Native direction: capture first, then rendering. Timeline: model first,
  interface after zoom landed (it has).
- One-press recording that auto-inserts into the timeline is a core UX goal.

### 5.2 Workflow rules (from `CLAUDE.md`, restated because they bite)
- Every feature/fix on a new branch; **bump the version on every meaningful
  commit** in `package.json`, `src-tauri/Cargo.toml`, `src-tauri/tauri.conf.json`
  (plus `src-tauri/Cargo.lock` for our crate and the README status line); update
  `CHANGELOG.md`, `docs/architecture.md`, `README.md` in the same commit.
  When bumping `Cargo.lock`, change only the `yusafcut` package's version line.
- Never create a PR or merge unless the owner explicitly says so.
- **Shared checkout hazard:** a session started with context "fork" shares the
  working folder. Stage files by explicit path (`git add path ...`), never
  `git add -A`, while another session may be editing; `tsconfig.tsbuildinfo` is a
  tracked build artifact that changes on every typecheck. For parallel work use a
  separate git worktree.
- Docs-only or groundwork commits (like `clipEdit.ts`) can sit under `[Unreleased]`
  in the changelog without a version bump.

### 5.3 ffmpeg 7.1 (the bundled build, evermeet 7.1) quirks
- Live multi-input filter graphs with two avfoundation sources can abort with
  `Assertion best_input >= 0` -> record to separate files, composite from files.
- `scale2ref` `main_w` is the *camera*, not the screen -> use `scale` with a
  reference input and `ref_w`.
- `alphamerge` needs `shortest=1` when its mask source is endless, or the export
  never ends.
- `crop` fixes its output width/height at configure time -> compute the scaled size
  explicitly when zooming.
- Output is buffered: without `-flush_packets 1` a killed process leaves a
  28-byte file. Recordings are fragmented MP4 (`frag_keyframe+empty_moov`) with a
  keyframe every second and are remuxed to a normal faststart MP4 on stop.
- Real-ffmpeg Rust tests run the bundled binary and skip when it is missing.
- `tpad` pads nothing directly after `trim,setpts` (it never sees the EOF it
  needs); put `fps=N` between them (`retime.rs`). `setpts` speed changes keep every
  frame, so a 4x clip carries 4x the frames until resampled with `fps`.
- `atempo` smears a tone's edges by tens of ms at 0.5x; measure audio sync on a
  beep's centre (silence end + next silence start), not its onset.
- `fps` rounds a clip shorter than a frame to no frame unless `eof_action=pass`;
  `atempo` fed digital silence emits timestamps that make `concat` fail with
  "Invalid data" unless the clip ends with `asetpts=N/SR/TB` (`retime.rs`).

### 5.4 Tooling
- zsh errors on unmatched globs; quote them (`'*.ts'`).
- Playwright cannot open `file:` URLs; serve a temp page through the Vite dev
  server (root-level html file) and delete it after. `.playwright-mcp/` is created
  in the repo root; delete it.
- A native macOS menu-bar item cannot be inspected from a script without
  accessibility permission; verify by eye.
- `npm run tauri:dev` hot-reloads the frontend and rebuilds Rust on change.

## 6. Verification checklist before you claim something is done

1. `npm run check` clean; `npm test`; `(cd src-tauri && cargo test)`.
2. For UI: run `npm run tauri:dev` with a real project and look at it. If you
   cannot, say so plainly; do not claim it works.
3. Update `CHANGELOG.md`, `docs/architecture.md`, `README.md`, and this file.
4. Commit with explicit paths, push the branch, do not open a PR.

## 7. Parallel work and handing off to another agent

- One agent per area; give each its own worktree:
  `git worktree add ../yusaf-cut-<name> -b feature/<name> feature/studio-recorder-zoom-backgrounds`.
- Areas that conflict if two agents touch them at once: `src/components/Waveform/Waveform.tsx`,
  `src/stores/projectStore.ts`, `src-tauri/src/commands/export.rs`, `src-tauri/src/edl.rs`,
  `src/styles/globals.css`, `CHANGELOG.md`.

Paste-ready prompt for an agent taking **auto zoom + cursor styling** (§4.5), for
example Codex, working in parallel with the native capture session:

```
You are working on YusafCut (Tauri 2 + React/Rust, Apple-Silicon text-based video editor)
at /Users/awaisjamil/code/projects/yusaf-cut. Read AGENTS.md, docs/HANDOFF.md (especially
§4.5), CLAUDE.md, docs/architecture.md and docs/cursor-events.md. Work in your OWN git
worktree on a new branch cut from feature/studio-recorder-zoom-backgrounds (v4.17.0):
  git worktree add ../yusaf-cut-autozoom -b feature/auto-zoom-cursor feature/studio-recorder-zoom-backgrounds
Implement Auto zoom (with a Follow cursor option) and cursor styling exactly as laid out
in HANDOFF §4.5, in the order given, against synthetic cursor logs that follow
docs/cursor-events.md. Another agent is building the native capture helper that will
produce real logs; do not touch recorder.rs, commands/record.rs, the native/ folder or
tauri.conf.json. Follow CLAUDE.md (bump versions in all places, update CHANGELOG,
architecture and README, stage files by explicit path, never open a PR or merge). Verify
with npm run check, npm test and cargo test. When you finish or run out of budget, update
HANDOFF.md §4.5 with what is done, what is not, and the next step.
```

Paste-ready prompt for the next agent:

```
Continue YusafCut. Read AGENTS.md, this HANDOFF (especially live log in §1),
CLAUDE.md, architecture, cursor-events and the saved playback/recorder plan.
Main integration is PR #42, v4.21.0 (previous main PR #41 was 207464c).
Use /Users/awaisjamil/code/projects/yusaf-cut on main; old worktrees are retired.
Read the cleanup/recovery note in §1. Inspect git status/log and preserve work.
For new implementation create a fresh feature branch/worktree from origin/main.
The v4.19.2 checkpoint corrects the media clock and awaits actual FFmpeg exit.
Native/log integration is v4.21.0; inspect §1 for exact current commit/status.
The original 0.501-second defect is not conclusively reproduced.
OWNER NOW REQUESTS NO COMPUTER-USE TESTING: implement and run automated checks;
owner handles manual app checks. Keep this handoff current after each milestone.
Steps 6–7 are implemented in v4.20.0/4.21.0. Next is controller/session authority and
remaining roadmap. The owner requested the v4.21.0 checkpoint merge and cleanup;
that does not mean the remaining roadmap or manual verification is complete.
Stage explicit paths, bump versions/docs, commit and push checkpoints.
```
