# Native Apple media engine: contract (slice 1)

Status (v4.50.1; slice shipped in 4.50.0): **contract + timing-only vertical slice. Nothing in the app uses it.**
FFmpeg (export) and the single HTML5 `<video>` (preview) stay the default
everywhere. The native engine is capability-gated and opt-in, and no setting or
UI turns it on yet.

| Piece | Where |
|---|---|
| Swift package (separate from the capture helper) | `native/yusafcut-engine` |
| Plan model, validator, reason codes, timing | `Sources/EngineCore` |
| Capabilities probe, AVFoundation composition builder | `Sources/EngineMedia` |
| JSON CLI `yusafcut-engine` | `Sources/yusafcut-engine/main.swift` |
| Rust bridge (`native_engine_capabilities`) | `src-tauri/src/engine_bridge.rs`, `src-tauri/src/commands/engine.rs` |
| Plan compiler, timing mirror, `chooseEngine`, `GenerationGate` | `src/lib/nativeEngine.ts` |
| TS / Swift timing parity fixture | `tests/fixtures/native-engine-timing.json` (generator `nativeEngineTiming.gen.ts`) |

Build and test the package: `npm run engine:build`, `npm run engine:test`
(`swift build` / `swift test` in `native/yusafcut-engine`).

Generated AVFoundation fixtures feed audio and video independently, respecting each input's readiness and marking each finished as soon as its samples end. A single timestamp-ordered loop could wait on an input while starving the other track the offline writer needed for interleaving. Setup retains bounded readiness/time limits and writes the underlying error to stderr before failing; the real-media timing/composition assertions remain required. The application engine itself is unchanged by this test-fixture scheduling correction.

## 1. Render plan (JSON, version 1)

The host compiles a plan from the project (`compileRenderPlan(project, opts)`);
the engine never reads a `.scribe` project. Times are **seconds as JSON numbers,
exactly as the EDL stores them**; the engine converts them to Core Media
rational time (section 2). Absent optional fields mean the default.

```jsonc
{
  "version": 1,                       // schema version; unknown -> plan-version-unsupported
  "generation": 17,                   // monotonic request number (section 6)
  "fps": { "num": 30000, "den": 1001 },  // output rate, exact rational
  "quantize": true,                   // snap clips and holds to whole frames (default true)
  "requires": ["zoom", "captions"],   // features present that need the fallback (section 4)
  "sources": [                        // one entry per file, however many clips use it
    { "id": "m1", "path": "/abs/screen.mov", "duration": 61.2,
      "hasVideo": true, "hasAudio": true,
      "crop": { "x": 0, "y": 0, "width": 1, "height": 1 } }   // any crop -> fallback "crop"
  ],
  "clips": [                          // main timeline, in output order (= EDL segments)
    { "sourceId": "m1", "sourceIn": 3.2, "sourceOut": 7.9,
      "speed": 2,                     // source s per output s, 0.25..4 (default 1)
      "holdSec": 1.5,                 // freeze the last played frame (default 0)
      "muted": true }                 // silence clip + group audio (default false)
  ],
  "groups": [                         // recording groups: tracks on the primary's clock
    { "primarySourceId": "m1",
      "tracks": [
        { "sourceId": "cam1", "role": "camera", "offsetSec": 0.12,
          "placement": { "x": 0.72, "y": 0.70, "width": 0.25, "height": 0.25 } },
        { "sourceId": "mic1", "role": "audio", "offsetSec": -0.03, "gainDb": -2 }
      ] }
  ],
  "audioBeds": [                      // music / SFX beds, already resolved for mute / solo
    { "sourceId": "music", "offsetSec": 4.0, "gainDb": -18 }
  ]
}
```

Mapping from the EDL (`src/lib/edl.ts`):

| EDL | Plan |
|---|---|
| `project.media[id]` used by a segment, bed or group track | `sources[]` (`hasVideo` = width and height > 0, `hasAudio` = sample rate > 0) |
| `segments[]` with `sourceOut > sourceIn` | `clips[]`, same order; `speed` / `holdSec` via `segmentSpeed` / `segmentHold`, omitted when default |
| Repeated or reordered ranges of one file | several clips naming one source; the engine opens the file once |
| `audioTracks` after `audibleTracks()` (solo wins over mute), not voice-over | `audioBeds[]` |
| First clip's `media.fps` | `fps` via `rationalFps` (29.97 -> 30000/1001, 23.976 -> 24000/1001, 59.94 -> 60000/1001) |
| Recording group (camera, extra audio) | `groups[]`. **The project has no such field yet**; the recording slice (`docs/performance/recording-to-editor.md`, slice 1) will add `recordingGroup`, then the compiler fills this from it. Today callers can pass `opts.groups`. |

Group tracks: for primary source time `t`, track time is `t - offsetSec`
(`offsetSec` = seconds the track started after the primary). Each group track
becomes one composition track that follows every clip cut from its primary
(same range, same speed, camera holds freeze, audio holds are silent) and is
empty during clips of other sources. Before the track starts or after it ends
the camera is empty (lead) or frozen on its last frame (tail).

## 2. Timing semantics

- **Rational time.** Every plan time becomes `CMTime(value: round(seconds * 90000), timescale: 90000)`.
  90 kHz makes every common rate a whole number of ticks per frame (24: 3750,
  25: 3600, 30: 3000, 30000/1001: 3003, 48, 50, 60, 120). A rate that is not
  (`frameTicks == null`) is refused with `fps-not-representable`.
- **Output-time mapping is the EDL's.** Clip `i` plays `(sourceOut - sourceIn) / speed`
  output seconds, then `holdSec` of freeze, and clips are concatenated in order:
  exactly `segmentOutputLength` / `computeTimeline` in `src/lib/edl.ts`.
- **Frame quantisation (`quantize`, default on)** is the export planner's rule
  (`export_plan.rs::frame_counts` in the `../yusaf-cut-perf` experiment, read
  only, not merged): the play part and the hold part of each clip, in order, are
  assigned whole frames by **error diffusion over the running EDL total**, so the
  running output is never more than half a frame from the EDL and 200 x 40 ms
  cuts make 8.000 s, not 10.67 s. A part may get zero frames; a clip whose parts
  both get zero is dropped; a non-empty plan never gets zero frames in total.
  For a quantised clip `play = frames * frameTicks` and the source read is
  `consumed = round(play * speed)` from `sourceIn` (so sound is cut to exactly
  the picture length, as in the export planner).
- **Unquantised** (`quantize: false`): `consumed = ticks(sourceOut) - ticks(sourceIn)`,
  `play = round(consumed / speed)`, `hold = ticks(holdSec)`.
- Implementations: `PlanTiming` (Swift) and `planLayout` / `planDurationTicks`
  (TS). Rounding is half away from zero on both sides. **Change both together**;
  `tests/nativeEngine.test.ts` and `EngineCoreTests` / `EngineMediaTests` fail on drift.
- **Composition rules** (`PlanComposition`):
  - every clip writes exactly `play + hold` ticks to every track (media, scaled
    with `scaleTimeRange` for speed, or empty edits), so tracks stay in step;
  - a range past the end of a file: picture freezes the file's last frame,
    sound is an empty edit; a range before a group track starts: empty edit;
  - a source without an audio stream, or a muted clip: empty edit on the sound
    tracks (never a shorter track);
  - hold: picture = the last played frame (one source frame) scaled to the hold;
    sound = empty edit;
  - beds play their whole file from `max(0, offsetSec)` (negative offset starts
    inside the file) and are cut at the end of the edit, like the export;
  - tracks that end up all empty are removed (no audio track for a silent plan).
  - **AVFoundation drops trailing empty edits.** The main picture track always
    reaches the plan end (tail freeze), so `composition.duration` equals the plan
    duration; a plan whose last stretch has neither picture nor sound (e.g. a
    muted audio-only last clip) is refused with `tail-gap-unsupported` rather
    than silently coming out short. Sound tracks may end early (silence).
  - Speed changes sound pitch in a bare composition. The preview / export levels
    must set `audioTimePitchAlgorithm` (`.spectral` or `.timeDomain`) like the
    current `<video>` `preservesPitch`.

## 3. Capability levels

`yusafcut-engine capabilities` prints:

```json
{"available":true,"reason":null,"engineVersion":"0.1.0","planVersion":1,
 "macosVersion":"27.0.1","appleSilicon":true,
 "videoToolbox":{"h264Encode":true,"h264Hardware":true,"hevcEncode":true,"hevcHardware":true},
 "metal":{"available":true,"name":"Apple M1 Pro"},"levels":["probe"]}
```

| Level | Meaning | Status |
|---|---|---|
| `probe` | build an AVMutableComposition + audio mix, report its tracks and duration | **implemented** |
| `preview` | AVPlayer playback of the plan in the editor | not implemented |
| `export` | AVAssetReader / VideoToolbox (or AVAssetExportSession) export of the plan | not implemented |

`available` requires macOS 13+, Apple Silicon and a Metal device (reasons
`macos-too-old`, `not-apple-silicon`, `no-metal-device`). VideoToolbox encoder
availability is reported for the export level to use; it does not gate `probe`.

The Rust command `native_engine_capabilities` (TS `nativeEngineCapabilities()`)
finds the helper like the capture helper does (`YUSAFCUT_ENGINE_BIN`, then in
debug builds `src-tauri/binaries/yusafcut-engine-aarch64-apple-darwin` or
`native/yusafcut-engine/.build/{release,debug}/yusafcut-engine`, then next to
the app executable), runs `capabilities` with a 5 s timeout and never fails:
problems become `{available:false, reason}`. **The helper is not bundled**
(not in `externalBin`), so a shipped build always reports `helper-missing`.
`YUSAFCUT_NATIVE_ENGINE=0` forces `disabled-by-env`.

## 4. Engine choice and fallback reasons

`chooseEngine(plan, caps, { settings, operation })` returns
`{engine: "native" | "fallback", reason}`. Checks, in order (first failure wins):

1. `settings.enabled` is false -> `disabled-by-setting` (**the default**:
   `DEFAULT_NATIVE_ENGINE_SETTINGS = { enabled: false }`, nothing sets it).
2. no caps / not available -> the helper's reason, else `helper-missing`.
3. `caps.planVersion != plan.version` -> `plan-version-unsupported`.
4. no clips -> `plan-empty`.
5. first entry of `plan.requires` (unknown codes -> `unknown-feature`); any source crop -> `crop`.
6. `caps.levels` lacks the operation (`preview` by default) -> `level-unavailable`.

Because the helper implements only `probe`, steps 1 and 6 both keep every real
preview / export on the fallback today.

Stable reason codes (never rename; add only). Mirrored in
`EngineCore/Reasons.swift`, `src/lib/nativeEngine.ts`, `engine_bridge.rs`.

| Group | Codes |
|---|---|
| Choice / availability | `disabled-by-setting`, `disabled-by-env`, `helper-missing`, `helper-failed`, `helper-timeout`, `helper-bad-output`, `macos-too-old`, `not-apple-silicon`, `no-metal-device`, `level-unavailable` |
| **Unsupported features (route to fallback)**, in `REQUIRE_ORDER` | `transition` (crossfade / dip), `zoom` (zoom regions, incl. auto zoom), `cursor` (drawn cursor for a used source), `scene` (active Look scene: background, padding, corners, shadow), `device-frame`, `crop`, `captions` (burned-in, an export option), `annotations`, `keystrokes` (key-cap overlay), `overlays` (image / video overlays), `privacy-mask`, `voice-over` (any voice-over take: overlay, insert or override), `music-ducking`, `audio-fade` (bed fades) |
| Unknown feature | `unknown-feature` |
| Invalid plan (host bug; still fallback) | `plan-version-unsupported`, `plan-empty`, `plan-too-large`, `fps-invalid`, `fps-not-representable`, `source-duplicate-id`, `source-unknown`, `clip-range-invalid`, `clip-speed-out-of-range`, `hold-out-of-range`, `group-invalid`, `gain-invalid`, `plan-unreadable`, `plan-malformed` |
| Build errors | `source-unreadable`, `composition-insert-failed`, `tail-gap-unsupported`, `internal` |

What IS supported at the `probe` level: multiple sources, cuts, reordered and
repeated ranges, speed 0.25..4, freeze holds, muted clips, sources without an
audio (or video) stream, recording groups (second video track and extra audio
tracks with per-track offsets and gains), music beds with offset and gain.
Camera `placement` is carried but not rendered (no compositor yet).

## 5. Progress, cancel and errors (CLI protocol)

- One JSON object per run on stdout; nothing else on stdout. Exit `0` ok,
  `1` plan refused or build failed (JSON still printed, with `reason` and
  `kind`: `unsupported` | `invalid` | `error`), `2` usage or unreadable input.
- `validate <plan.json | ->` prints `{ok:true, generation, expectedDurationTicks, timescale}`
  or `{ok:false, reason, kind, detail, generation}`.
- `probe-plan <plan.json | ->` prints `{ok, generation, timescale, durationTicks,
  durationSeconds, expectedDurationTicks, clips, tracks:[{id, mediaType, role,
  sourceId, durationTicks, segments, mediaSegments}], hasAudioMix}`.
- **For the long-running levels (preview / export, not built yet)** the helper
  will run as a long-lived process speaking newline-delimited JSON over stdio
  like the capture helper: requests `{id, cmd, generation, plan}`, events
  `{"event":"progress","generation":n,"fraction":0..1}` at most every 250 ms,
  terminal `{"event":"done"|"error","generation":n,"reason":...}`. Cancel =
  `{cmd:"cancel", generation}` or closing stdin; the helper stops within one
  frame of work, deletes partial output, and answers `error` with
  `reason: "cancelled"`. A helper that dies is reported by the bridge as
  `helper-failed` and the caller falls back for that request.
- Errors are never thrown across the bridge: the Rust side returns a value with
  a reason code; the TS side treats any non-native outcome as "use fallback".

## 6. Stale generations (latest request wins)

- Every request carries a `generation` from one `GenerationGate` per project
  (`next()`); a project switch calls `invalidate()`.
- The helper echoes `generation` on every response and event.
- The host applies a response only if `gate.isCurrent(generation)`; anything
  older is dropped, never merged. Starting a new request for the same purpose
  cancels the previous one (cancel message), but correctness never depends on
  the cancel arriving: the gate alone decides.
- The helper may coalesce: when a newer request arrives before an older one
  starts work, the older is answered `error` / `cancelled` without work.

## 7. Bounded memory

- One `AVURLAsset` per source id, however many clips reuse it; the composition
  references media, it never decodes in `probe`.
- Validator limits (`plan-too-large`): 64 sources, 10,000 clips, 8 group tracks,
  16 audio beds, 24 h of output. The Rust bridge parses at most 64 KiB of
  capabilities output.
- Future preview / export levels: decode through AVPlayer / AVAssetReader with
  bounded queues (at most a few frames in flight per track, `alwaysCopiesSampleData = false`),
  a Metal texture cache with a fixed pool, and no whole-file buffers.

## 8. What remains (not done in this slice)

- **Metal compositing** (camera picture-in-picture from `placement`, crop,
  scene, device frames, zoom, cursor, overlays, masks, captions, annotations,
  key caps) and an `AVVideoComposition` / custom compositor.
- **Preview level**: AVPlayer in the editor, sync with transcript / waveform,
  `audioTimePitchAlgorithm` for speed, seek behaviour, the long-lived helper
  protocol of section 5.
- **Export level**: VideoToolbox H.264 / HEVC encode, progress / cancel,
  comparison with the FFmpeg export (frames, durations, A/V sync).
- Transitions, voice-over (overlay / insert / override), music ducking and bed
  fades in the audio mix.
- `recordingGroup` in the project schema (slice 1 of the recording work) and
  compiling it into `groups`.
- A user-facing (or developer) setting that sets `enabled`, and bundling the
  helper (`externalBin`, signing in `scripts/sign-and-notarize.sh`).
- Real measurements on captured takes before any default changes.
