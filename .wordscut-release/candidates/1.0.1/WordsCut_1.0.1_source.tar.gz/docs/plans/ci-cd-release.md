# CI/CD plan: signed releases from GitHub Actions

Current status (2026-10-22, WordsCut 1.0.0): the owner requested a local signed first release. The v1.0.0 DMG is published, and automated workflow run [39624496604](https://github.com/awaismirza/wordscut/actions/runs/39624496604) verified the exact downloaded release assets, source version, signatures, notarization tickets, Gatekeeper results, team, bundle ID and app version. The tag-triggered build run failed earlier during hosted Swift AVFoundation fixture setup, so its artifact gate was skipped; the published-artifact verifier is now a separate job in the active public Release workflow and automatically runs on published releases. Existing releases can be verified with its `verify_published_tag` dispatch input. Private PR checks fail before runner steps start; local frontend, Rust, Swift and media checks pass. See `../wordscut-release.md` for the release ledger and the public `docs/verify-published-release.md` for the verification procedure. The v4.50.5 plan below is historical; its missing-certificate and sandbox issues have been resolved.

Historical status (2026-10-21, v4.50.5): workflows WRITTEN, NEVER RUN on GitHub: `.github/workflows/ci.yml`, `.github/workflows/release.yml`, `scripts/build-whisper.sh`, `src-tauri/Entitlements.direct.plist`, and the fixed `scripts/sign-and-notarize.sh` (signing path tested locally with an Apple Development identity; notarization, the Developer ID certificate and all secrets are untested/not created). Actions are pinned to major tags (`@v4`), not SHAs: pin by SHA after the first green run.
Owner decisions are marked **[owner]**; credentials are things only the owner can create.

## Goals

1. A signed, notarized `YusafCut_<version>_aarch64.dmg` built on GitHub Actions and downloadable from the repo's Releases page.
2. A release is created **only when the owner pushes a version tag** (`vX.Y.Z`). Pushes and merges to `main` never release.
3. Pull requests get fast checks (separate workflow, no secrets).

## Triggers (the "tag only" rule)

```yaml
# release.yml
on:
  push:
    tags: ['v[0-9]+.[0-9]+.[0-9]+']      # no branches key, so main pushes never match
  workflow_dispatch: {}                    # optional dry run: build + sign, no release (guarded by `if: github.ref_type == 'tag'` on the publish job)
```
- No `branches:` trigger and no `schedule:`. A merge to `main` cannot start this workflow.
- First job verifies the tag matches the code: tag `vX.Y.Z` must equal `package.json`, `src-tauri/Cargo.toml` and `src-tauri/tauri.conf.json` versions (CLAUDE.md already requires all three to match) and the tagged commit must be reachable from `origin/main` (`git merge-base --is-ancestor $GITHUB_SHA origin/main`), so a tag on an unreviewed branch fails fast. **[owner]** drop the ancestry rule if you want to release from branches.
- `concurrency: { group: release-${{ github.ref }}, cancel-in-progress: false }`.
- Optionally protect tags: repo Settings -> Rules -> Tag ruleset for `v*` so only the owner can create them.

## Runner and build steps (release job, `runs-on: macos-15` arm64)

1. `actions/checkout` (full history for the ancestry check), Node 22, Rust stable (`dtolnay/rust-toolchain`), Swift/Xcode from the runner image.
2. `npm ci`.
3. **Sidecars are gitignored, so CI must produce them:**
   - `ffmpeg` / `ffprobe`: `npm run media:build` (pinned, SHA-256-verified upstream sources; slow). Cache `src-tauri/binaries/ffmpeg-*` and `ffprobe-*` with `actions/cache` keyed on `hashFiles('scripts/build-arm64-media.sh')`.
   - `whisper-cli`: built from source per HOW_TO_RUN.md (script it as `scripts/ci/build-whisper.sh`; cache by pinned commit). Must be statically linked or its dylibs bundled.
   - `yusafcut-capture`: `npm run native:build` (must produce the real helper, not the stub; fail if the file is under 100 KB, as `scripts/build-app.sh` already does).
   - `mlx-sidecar` is not in `externalBin`; do not build it in CI.
4. `npx tauri build --bundles app,dmg` (config: `src-tauri/tauri.conf.json`).
5. Sign (below), notarize, staple, verify.
6. Publish job (needs: build, `permissions: contents: write`): create the GitHub Release for the tag and upload the DMG plus `SHA256SUMS.txt`. Use `gh release create "$GITHUB_REF_NAME" --generate-notes --verify-tag` (draft first if you want to review: **[owner]**).

## Signing and notarization

Prerequisite **[owner]**: a **Developer ID Application** certificate (needs the paid Apple Developer Program; Xcode -> Settings -> Accounts -> Manage Certificates -> +). The current keychain has only Apple Development and Apple Distribution certificates, which cannot be notarized for direct download.

Secrets (repo Settings -> Secrets and variables -> Actions, or an `release` Environment with required reviewer **[owner]**):

| Secret | Content |
|---|---|
| `MACOS_CERTIFICATE_P12` | base64 of the exported Developer ID Application `.p12` |
| `MACOS_CERTIFICATE_PASSWORD` | the `.p12` export password |
| `KEYCHAIN_PASSWORD` | any random string, for the temporary CI keychain |
| `APPLE_SIGNING_IDENTITY` | `Developer ID Application: Name (TEAMID)` |
| `APPLE_API_KEY_P8`, `APPLE_API_KEY_ID`, `APPLE_API_ISSUER` | App Store Connect API key for `notarytool` (preferred) or `APPLE_ID` + app-specific `APPLE_PASSWORD` + `APPLE_TEAM_ID` |

Steps: create a temporary keychain, import the `.p12`, `security set-key-partition-list`, sign inside-out (every nested binary in `Contents/MacOS`, then the app, then the DMG) with `--options runtime --timestamp`, `xcrun notarytool submit --wait`, `xcrun stapler staple`, then `spctl --assess` and `codesign --verify --deep --strict`. Delete the keychain in an `always()` step. Never echo secrets; no `set -x` around them.

**Blocking issue to fix first:** `scripts/sign-and-notarize.sh` signs with `src-tauri/Entitlements.plist`, which enables the **App Sandbox** (a Mac App Store profile) while the sidecars are signed without sandbox entitlements. A sandboxed app cannot freely spawn ffmpeg / whisper / the capture helper and read arbitrary project files. Before CI signing is trusted:
- create a separate non-sandbox `Entitlements.direct.plist` for Developer ID builds (hardened runtime: `device.camera`, `device.audio-input`, plus whatever the app needs, e.g. `cs.disable-library-validation` only if a sidecar needs it);
- keep `Entitlements.plist` for the MAS build only;
- test a signed+hardened build on a real Mac: launch, record screen+camera+mic, spawn ffmpeg, export. Screen Recording and Input Monitoring are TCC permissions, not entitlements.
Until that is verified on hardware, CI output must be treated as unverified.

## PR checks (separate `ci.yml`, no secrets)

`on: pull_request` and `push` to `main`: `npm ci`, `npm run check`, `npm test`, `npm run test:rust` (needs the ffmpeg sidecar: reuse the cache), optional `swift test` for `native/yusafcut-engine`. There is no CI today, so merges are currently gated only by local runs. **[owner]** make these required via a branch ruleset (the branch-protection API is unavailable on this plan, so use rulesets if available, or rely on the PR checks UI).

## Rollout order

1. **[owner]** Create the Developer ID certificate and the Actions secrets above.
2. Add `Entitlements.direct.plist`; verify a locally signed hardened build works (this is the real risk).
3. Add `ci.yml` (PR checks) and confirm green.
4. Add `release.yml` with `workflow_dispatch` dry run only (no publish) and confirm the signed DMG passes `spctl` and runs on a clean Mac.
5. Enable the tag trigger and publish; cut a matching version tag only after hosted dry-run verification and packaged QA pass. Download from Releases and test.

## Risks

- Cold builds of ffmpeg and whisper on a runner are slow (cache them; first run may take tens of minutes).
- The repo is **private**: the Releases page is visible only to collaborators; downloaders need repo access. Public downloads need a public repo or a separate distribution channel.
- Actions minutes for macOS runners are billed at a higher rate on private repos.
- Pin third-party actions by SHA; give each job least-privilege `permissions`; only the publish job gets `contents: write`.
- Notarization can reject unsigned nested binaries or missing hardened runtime; the sign step must cover every executable in the bundle.
