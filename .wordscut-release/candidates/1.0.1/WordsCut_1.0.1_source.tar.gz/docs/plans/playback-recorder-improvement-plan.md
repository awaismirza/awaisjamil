# YusafCut: feature-gap report and improvement plan

## 1. Summary and findings

**Recommendation: improve playback and editor responsiveness first, then deliver a compact recorder with a true desktop recording pill.** Integrate the native capture and cursor work already underway before adding more presentation features.

Research date: **19 October 2026**. Baseline inspected: `main`, **v4.17.0**, commit `1d9879d`.

The handoff is stale about release status: v4.17.0 is already merged into `main`. Native capture has committed implementation on its separate branch; auto-zoom and cursor features have active, uncommitted work in another worktree. Neither should be treated as released or independently verified.

This report uses the supplied recorder screenshot, local source inspection, official product documentation, and published product visuals. I did not run the Tauri app or benchmark playback, so performance findings below identify code costs and risks—not measured speedups.

## 2. Features we have, partially have, and miss

ScreenKite’s strongest relevant differences are activity-driven zoom, flexible camera placement, and a native rendering pipeline. Its speed claims are vendor benchmarks, not evidence that YusafCut would achieve the same results. [ScreenKite features](https://www.screenkite.com/#features)

Recordly documents a broader demo-editing toolkit, particularly cursor presentation, editable webcam overlays, speed regions, annotations, cropping, and GIF output. [Recordly feature list](https://github.com/webadderallorg/Recordly#all-features)

| Capability | Competitor reference | YusafCut status | Recommended priority |
|---|---|---|---|
| Transcript editing, silence cleanup, local transcription | ScreenKite | Already present; preserve as our core workflow | Maintain |
| Backgrounds, padding, corners, shadows, aspect ratios | Both | Already present in preview and export | Polish |
| Manual zoom regions | Both | Already present, including timeline handles and export | Maintain |
| Automatic zoom and cursor following | Both | Active work in separate worktree | Integrate existing work |
| Cursor smoothing, size and click effects | Recordly | Active implementation; main lacks these controls | Integrate existing work |
| Native screen capture | Both | Implemented on separate native-capture branch | Validate and integrate |
| Window/area capture and system audio | ScreenKite; Recordly documents window/system audio | Missing from main’s recorder flow; native branch provides foundations | High |
| Editable webcam layer | Both | Main composites camera into the finished recording; limited corner/size options | High |
| Direct clip trimming and splitting | Both | Pure editing model exists; timeline interface is unfinished | High |
| Real audio waveform | Timeline accuracy requirement | Current bars use hashes of word text, not audio amplitudes | High |
| Preview quality controls | ScreenKite | No preview proxy/quality workflow found | High, after profiling |
| Speed regions, annotations and cropping | Recordly | No equivalent complete editing workflow found | Later |
| GIF export | Recordly | Missing | Later |
| Background blur and device/browser frames | Recordly | Missing from current scene controls | Later |
| Keystroke overlays | ScreenKite | Capture-event contract exists; presentation remains unfinished | Later |
| Recover unfinished recordings | ScreenKite | Crash-resistant files exist; guided recovery is a separate gap | Medium |
| Teleprompter and time-lapse | ScreenKite | Missing | Low |
| Device recording, agent editing and professional interchange | ScreenKite | No complete equivalent workflow found | Defer |

Additional ScreenKite references: [recording controls and recovery](https://www.screenkite.com/en/guide/new-recording), [timeline tools](https://www.screenkite.com/en/guide/timeline-tracks), [preview quality](https://www.screenkite.com/en/guide/preview-quality).

**Avoid spending the next release on feature-count parity.** Better playback, reliable capture, a useful desktop controller, and accurate trimming will improve everyday use more than a marketplace or AI assistant.

## 3. Recorder and editor UI direction

The supplied recorder is understandable, but oversized for a frequent desktop action. Four large mode cards, lengthy introductory copy, device fields and a prominent shortcut strip compete for attention. The blank Display field and disabled Start button provide no visible explanation.

### Compact recorder setup

Replace the large modal with an approximately **460 px wide recorder panel**, accessible from Record and the existing menu-bar entry.

- Use compact segmented choices for **Screen / Camera / Audio**. For screen recording, expose **Display / Window / Area** as the source choice.
- Treat camera as an optional screen-recording input, preserving all four existing recording capabilities.
- Show the chosen source clearly, preferably with a thumbnail and display/window name.
- Put **Microphone**, **System audio**, and **Camera** in compact rows. Expand device selection when enabled.
- Provide a microphone level meter and optional camera preview before starting.
- Move countdown, quality and other infrequent settings into an expandable section.
- Show loading, permission denied, no devices, and disconnected-device states explicitly. Explain why recording cannot start.
- Use one prominent **Start recording** button. Reduce introductory copy to “Recorded locally · Added to this project.”
- Make that message reflect whether automatic transcription is actually enabled.
- Move the full shortcut reference behind a help control; retain the start shortcut beside the primary action.

ScreenKite documents a source-first recording hub. CleanShot’s customizable capture workflow is another useful interaction reference. [ScreenKite recording hub](https://www.screenkite.com/en/guide/new-recording), [CleanShot features](https://cleanshot.com/features)

### True desktop recording pill

The existing HUD is positioned inside the editor window. Minimizing the editor hides it. Build a **separate desktop controller**, initially around **320 × 52 px**:

`● 02:14   Pause   Mark   Stop   ⋯`

- Draggable, above ordinary app windows, shown without stealing keyboard focus.
- Remember its position and clamp it to available screens after monitor changes.
- Keep **Pause/Resume** and **Stop** visible. Put restart and discard in the overflow menu, with confirmation before losing a take.
- Show explicit countdown, recording, paused, finishing and failure states.
- Keep menu-bar controls and global shortcuts working when the pill is hidden.
- Restore the editor after stopping and show import/transcription progress there.
- Exclude recorder controls from captured footage through the native capture filter. With the FFmpeg fallback, hide the pill during screen capture if exclusion cannot be guaranteed.

Tauri exposes window controls suitable for a separate controller, but macOS workspace/fullscreen behavior needs real-app verification. Preserve the repository’s disabled-private-API constraint; use an opaque rounded window initially rather than introducing private APIs for transparency. [Tauri window API](https://docs.rs/tauri/latest/tauri/webview/struct.WebviewWindowBuilder.html)

### Editor polish

Preserve the text-first layout. Improve the timeline with real waveforms, clear clip boundaries, trim handles, snapping feedback, and consistent ruler/playhead alignment. Keep secondary lanes collapsible so camera, zoom and other effects do not crowd the transcript workflow.

## 4. Implementation roadmap, in order

### Phase 1 — Establish measurements and fix playback-path work

Confirmed source findings:

| Finding | Implication |
|---|---|
| Playback clock calls `computeTimeline`, followed by linear searches | Work grows with edit count on frame callbacks |
| Preview, timeline and transcript subscribe to changing playback time | Large components can rerender at playback frequency |
| Transcript highlighting scans segments/words, queries DOM and reads layout each tick | Repeated main-thread work even while the same word remains active |
| Timeline auto-follow repeatedly requests smooth scrolling | Competing scroll animations can contribute to uneven movement |
| Visible bars are already virtualized, but rebuilding them scans broader project data | Virtualization reduces DOM count without eliminating lookup costs |
| Cross-media playback changes the single video source | Decoder/source-switch latency remains possible after React optimization |

Relevant starting points: [playback clock](/Users/awaisjamil/code/projects/yusaf-cut/src/components/VideoPreview/VideoPreview.tsx:260), [transcript highlighting](/Users/awaisjamil/code/projects/yusaf-cut/src/components/TranscriptEditor/TranscriptEditor.tsx:345), [timeline rendering](/Users/awaisjamil/code/projects/yusaf-cut/src/components/Waveform/Waveform.tsx:187).

Implementation:

- Add local diagnostic measurements for frame timing, seek completion, cut transitions, long tasks, React commits, memory and save latency. No telemetry.
- Build one derived timeline index per segment revision: ordered output ranges, segment references, word ranges and word-ID lookup. Use binary search for seeks and an advancing index during sequential playback.
- Track playback by **EDL entry**, not merely source time, so repeated uses of the same media range resolve correctly.
- Keep the frame clock imperative for playhead movement and zoom/cursor transforms. Publish timecode updates at about 10 Hz; publish transcript/caption changes when the active word changes.
- Update only the previous and next highlighted word. Cache word elements and measure visibility on word transitions.
- Separate static timeline content from the moving playhead. Replace repeated smooth-scroll calls with one controlled follow mechanism that suspends during manual navigation.
- Give `requestVideoFrameCallback` ownership while playing; use media events for paused seeks and lifecycle synchronization.
- Preserve the stable video element and existing source/output-time edit semantics.

### Phase 2 — Playback continuity, accurate timeline and overall responsiveness

- Preserve original transcripts per media before enabling clip extension. Old projects lacking originals must remain usable without claiming deleted words can be recovered.
- Generate real waveform peaks once per source through Rust/FFmpeg; cache multiple resolutions. Draw waveform detail according to visible pixels, with accessible clip controls above it.
- Wire the existing trim/split/roll model into undoable store actions. Commit drags once on release.
- Coalesce scrub requests: keep the latest target, avoid unlimited outstanding seeks, and perform an exact seek when dragging ends.
- Add **Original / Balanced / Low** preview sources using time-aligned local proxies. Originals remain authoritative for export. Proxy generation must be cancellable and never block opening a project.
- Serialize autosaves per project. Associate each save with a revision; clear dirty state only when that revision is still current. Surface failures and prevent concurrent writes to the same temporary file.
- Run probing and hashing concurrently where safe; stream hashes as today. Bound background analysis/proxy jobs so they do not compete freely with playback.
- Move measured long-running analysis off the UI thread. A loading dialog alone does not remove a synchronous stall.

**Native gate:** after indexing, render isolation and proxies, use the benchmark suite below. If cut-heavy playback still misses the continuity target, implement an AVFoundation composition-based playback engine behind the same transport interface. Keep HTML playback as fallback.

Evaluate Metal/Core Image rendering separately for effect-heavy preview/export; hardware encoding alone does not eliminate CPU filter/compositing costs.

### Phase 3 — Recorder integration and desktop UI

- Validate and integrate the native-capture branch without duplicating its capture implementation.
- Implement the compact source picker, permission states and desktop pill.
- Route pill actions through the existing recorder action dispatcher.
- Make Rust the authority for session status and action serialization. A second WebView must receive a state snapshot plus events; it must not create an independent recorder store or processing pipeline.
- Include a session identifier in actions so stale controls cannot stop a later take.
- Scope controller permissions separately from editor file-access permissions.
- Integrate existing auto-zoom/cursor work after confirming preview/export parity.
- Follow with an editable camera layer backed by separate captured tracks.

### Interfaces and compatibility

Add a derived `TimelineIndex`, optional original-transcript storage, cached waveform/proxy commands, and a recorder-controller snapshot/action interface.

Keep indexes, peaks and proxies outside undo history. Cache files must be disposable and reconstructible. New project fields are optional and preserved by Rust serialization; existing `.scribe` projects continue to open.

## 5. Verification, defaults and deliverables

**Initial performance targets**, measured in a packaged release build on the owner’s Mac:

- Playback UI work: p95 below **8 ms per presented frame**.
- No recurring playback-induced main-thread tasks above **50 ms**.
- Seek-to-presented-frame: p95 below **150 ms** with a ready proxy.
- Cut-transition visual interruption: p95 below **100 ms**.
- A 30-minute repeated-playback/seek run shows no sustained memory growth.
- Where the existing baseline already meets a target, preserve it and reduce unnecessary work.

Benchmark short 1080p media, long 4K media, hundreds of cuts, repeated source ranges, multiple media files, audio-only projects, captions, zoom and scene effects. Separate cold loading, steady playback, same-source cuts and cross-media transitions.

Regression coverage must include boundary mapping, stale seek completion, undo after trimming, save completion during newer edits, failed saves, cache invalidation, and opening older projects.

Run `npm run check`, `npm test`, Rust tests, and Swift tests where native capture changes require them. Verify recorder UI through `npm run tauri:dev`, including minimized editor, multiple displays, fullscreen Spaces, permission denial, device removal, pause/resume and control exclusion from footage.

Defaults chosen:

- Playback first; recorder redesign follows.
- Draggable desktop pill plus existing menu-bar controls.
- Optimize the present architecture before native playback replacement.
- Retain Apple Silicon, local processing and text-first editing.
- Treat active capture/cursor work as integration dependencies.
- Deliver the saved research report, benchmark results and phased implementation notes with corresponding handoff updates when implementation begins.
- Follow branch/version/documentation rules for implementation; no PR or merge without an explicit request.

This planning pass changes no repository files.
