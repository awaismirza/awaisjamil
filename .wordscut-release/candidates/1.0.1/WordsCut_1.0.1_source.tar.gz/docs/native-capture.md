# Native capture helper

The native branch originated at 4.18.0 and was integrated in 4.21.0. The recorder prefers a Swift helper, `yusafcut-capture`
(`native/yusafcut-capture`), over ffmpeg's avfoundation input. ffmpeg stays as an
automatic fallback. The helper records the screen, window or area with
ScreenCaptureKit (plus system audio), and the camera and microphone with
AVFoundation, into **separate crash-safe files on one clock**, together with
timestamped cursor, click and key-down events. The real cursor is not captured;
the editor automatically attaches processed screen logs and can redraw it in preview/export.
Actual capture verification is owner-run at their request; no new computer-use capture test is claimed.

Protocol, file formats and clock model: `native/yusafcut-capture/README.md`.

## How the app uses it

```
request_recording_permissions ── short-lived helper, `request-permissions` (prompts where macOS allows)
open_privacy_settings ── `open x-apple.systempreferences:…Privacy_<pane>` (fixed whitelist)
recording_thumbnail ── short-lived helper, `thumbnail` (display/window JPEG as a data: URL, idle only)
list_recording_devices ── spawns helper, `list-devices`, quits it
   │  returns displays + cameras (video[]), microphones (audio[]), windows[], permissions
   │  device indices are 1000+ (NATIVE_INDEX_BASE); ffmpeg's are small numbers
   ▼
start_recording(opts) ── any index ≥ 1000 (or windowId) → native path
   │  spawn helper → `start` → tracks land in recordings/rec-<id>/tracks/
   │  helper missing / crashes before ready / answers capture-failed / times out
   │      → same take through ffmpeg (indices translated by name, no error shown)
   │  permission-denied / bad-request / not-found → surfaced to the user as the start error
pause / resume ── `pause` / `resume` (the helper drops samples and removes the gap;
   │              one set of files, no segments to join)
stop_recording ── `stop`, then ffmpeg folds tracks into ONE mp4 for the editor:
   │   screen (copied) or camera, + mic/system audio mixed to AAC,
   │   screen+camera composited with the existing PiP filter
   │   result.tracksDir keeps the raw tracks and result.eventsPath points at events.jsonl
cancel_recording ── kills the helper, deletes the take
```

* `src-tauri/src/native_capture.rs` — protocol client (`HelperClient`), device
  mapping, `start` parameters, ffmpeg finalize arguments. No Tauri dependency, so
  it is tested with a fake helper process and in-memory streams.
* `src-tauri/src/commands/record.rs` — process lifecycle. Session state is the
  authoritative `recording_session.rs` snapshot (`record:snapshot`), identical for
  both backends; actions carry the session id.
* Cancel during `start` aborts the pending helper request and kills the helper (it
  does not wait out the helper's own deadline) and never falls back to ffmpeg.
* If the helper dies mid-take (`exited` event) or reports state `failed`, the
  session becomes `interrupted` with the error; **Stop** then recovers the
  fragmented files from disk. Camera/microphone loss (`AVCaptureSessionRuntimeError`,
  `AVCaptureSessionWasInterrupted`, `AVCaptureDevice.wasDisconnectedNotification`) is
  reported once the same way (`CaptureCore/DeviceLoss.swift` messages). macOS gives no
  interruption reason. Real unplug behavior is OWNER REQUIRED.
* `YUSAFCUT_FORCE_FFMPEG=1` forces the ffmpeg recorder; `YUSAFCUT_CAPTURE_BIN=/path`
  points at another helper binary.

## Excluding YusafCut's recording controls

Display and area capture use `SCContentFilter(display:excludingWindows:)` with every
window owned by the launching app (`getppid()`) whose title starts with
`CaptureCore.controllerWindowTitle` ("YusafCut Recording Controls"; the Rust side
creates the window with the same title). The set is re-read every 750 ms while
recording and applied with `SCStream.updateContentFilter`, so a controller created
or re-created after start is still excluded. Window capture of the controller is
rejected and the controller is not listed. The YusafCut editor window remains
recordable. Automated: pure matching tests only. **Whether the controller really
is absent from footage (and how long after creation) is OWNER REQUIRED.**

## Build

```bash
npm run native:build      # swift build -c release + install as the Tauri sidecar
npm run native:test       # swift test
```

`src-tauri/binaries/yusafcut-capture-aarch64-apple-darwin` is committed as a stub
that exits immediately (so `tauri build` works without Swift and the app falls
back to ffmpeg). `native:build` replaces it locally and marks it `skip-worktree`.
`npm run setup:all` runs it when Swift is available.

Permissions: `src-tauri/Info.plist` carries `NSCameraUsageDescription`,
`NSMicrophoneUsageDescription` and `NSScreenCaptureUsageDescription`; the helper
embeds an equivalent plist in its binary. `Entitlements.plist` (MAS) gained
`com.apple.security.device.audio-input`. Screen Recording has no entitlement; the
user grants it in System Settings → Privacy & Security.

## Manual QA checklist

Automated tests cover the protocol, clock, event log, writers (with synthetic
media) and a fake-helper process. They **cannot** cover macOS permission prompts,
real camera/microphone/system-audio capture or the Tauri UI. Walk through this on
a Mac before releasing a change to the helper. Run `npm run native:build` first.

**Permissions**
- [ ] Fresh TCC state (`tccutil reset ScreenCapture dev.yusafcut.app`, same for `Camera`, `Microphone`): open the recorder dialog — devices list, no prompt yet.
- [ ] Start a screen take → system Screen Recording prompt; deny → the dialog shows the "Screen Recording access is not granted…" error and **no** ffmpeg fallback happens. Allow in System Settings, relaunch, record again → works.
- [ ] Screen + camera + mic: camera and microphone prompts appear; denying camera shows the camera error and nothing is recorded.
- [ ] Without Input Monitoring: take works, `events.jsonl` has `move`/`down` events but no `key`. Grant it → `key` lines appear.

**Compact setup panel (4.24.0)**
- [ ] Display / Window / Area each show a thumbnail (Screen Recording granted); Area: drag a rectangle, record → footage matches it; type a size → clamps inside the display.
- [ ] Deny Screen Recording → panel shows the permission row (Open Settings / Re-check) and Start stays disabled with the reason; a never-asked permission shows Allow and the system prompt appears.
- [ ] Unplug a camera/mic with the panel open, refocus the window → notice names it and another device is chosen.
- [ ] Camera preview and mic meter move with the right device; both release (camera light off) when the panel closes.
- [ ] Arrow keys move the segmented choices; Tab order reaches Start; the disabled reason is read by VoiceOver.

**Capture**
- [ ] Screen only: stop → file imports, plays, has no cursor drawn into it, audio follows the mic.
- [ ] Screen + camera: the final video has the camera bubble in the chosen corner; `tracks/` holds `screen.mp4` and `camera.mp4` separately and both are 1:1 in duration with the final.
- [ ] Camera only, Voice-over only: result plays; voice-over is an `.m4a`.
- [ ] System audio (`systemAudio: true`, e.g. via `RecordOptions` from the console): play a video during the take; its sound is in the final file mixed with the mic.
- [ ] Window capture (`windowId` from `list_recording_devices().windows`): only that window is in the video; move/resize it during the take → `windowFrame` events appear.
- [ ] Sync: clap or click while watching the cursor; in `events.jsonl` the `down` time matches the frame where the click shows (± 1 frame), and the clap matches in `mic.m4a`.

**Pause / resume**
- [ ] Pause for 10 s mid-take, resume: the final video has no 10 s gap, `events.jsonl` has `pause`/`resume` at the same `t`, no event is stamped inside the gap, audio and video stay in sync after the resume.
- [ ] Pause/resume via the shortcut and the menu-bar item works as before.

**Crash recovery**
- [ ] Start a take, then `pkill -9 yusafcut-capture` after ~10 s. Within a second the HUD shows paused and an error toast says the helper stopped; **Stop** produces a playable file of about the recorded length (minus ≤ 2 s), `tracks/manifest.json` says `finished:false`, and `events.jsonl` is intact up to the last line.
- [ ] Repeat with a camera + mic take: `ffprobe tracks/camera.mp4 tracks/mic.m4a` both read.
- [ ] Quit YusafCut mid-take: the helper sees stdin close, finalizes, and the files in `recordings/rec-*/tracks/` are complete (`finished:true`).

**Fallback**
- [ ] `YUSAFCUT_FORCE_FFMPEG=1 npm run tauri:dev`: the dialog lists ffmpeg devices (small indices), a take records via ffmpeg as before.
- [ ] Replace the helper with the stub (`git checkout -- src-tauri/binaries/yusafcut-capture-aarch64-apple-darwin` after `git update-index --no-skip-worktree`) and start a take with native indices selected: it falls back to ffmpeg without an error.
- [ ] Menu-bar item, global shortcuts and Settings tab behave exactly as with ffmpeg.

## Known gaps

* The compact setup panel (4.24.0) chooses display / window / area and system audio.
  Area is drawn on a thumbnail (or typed) in display points, not on the live screen, so
  there is no full-screen crosshair overlay yet. Thumbnails need macOS 14+ and Screen
  Recording; without them the panel shows a placeholder. Camera preview and the
  microphone meter use the webview's `getUserMedia` (matched to the helper's device by
  name; falls back to the system default) — not the helper — and are unverified in the
  real app. Window and area capture are unavailable on the FFmpeg fallback.
* The final file is still one mixed MP4 for the existing editor; the raw tracks
  and events are kept in `tracksDir` for the rendering step.
* Camera/microphone/system-audio capture and the permission prompts have only
  been exercised by hand on a developer Mac; see the checklist.

## Integration checkpoint (4.21.0)

Start now waits for the first accepted primary sample and uses its host timestamp
as the shared origin. Rust uses helper media-clock snapshots, not a second wall
clock; final durations are probed from output files. Background cursor parsing
uses a module worker and rebases current/undo/redo project metadata safely.

Source/device permission UI, public Rust controller snapshot/actions, area UI,
control exclusion and editable camera layers are still pending. No real capture
or system-menu verification was performed after the owner stopped computer-use
testing. Swift builds/tests pass in Swift 5.9 mode with existing NSObject/GCD
sendability warnings; strict Swift 6 concurrency is not certified. Copied FFmpeg
is x86_64 despite its aarch64 filename; native-ARM sidecar packaging needs repair.
