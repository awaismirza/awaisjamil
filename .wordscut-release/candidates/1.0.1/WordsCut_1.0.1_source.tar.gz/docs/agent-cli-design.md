# Agent CLI / MCP — design (v1)

Status: in implementation · Target: v4.27.0 (minor)

## 0. Goals and non-goals

**Goal.** External AI CLIs (Claude Code, Codex, Gemini CLI) can drive the running WordsCut editor: open a `.scribe` project, inspect transcript and EDL, edit it (cut words, ranges, fillers, silences; replace text; chapters; zoom regions), export video or captions, and save. Edits use the **same pure functions and the same Zustand store** as the UI, so they appear live and are undoable like a click.

**Non-goals for v1.** B-roll/overlays (the EDL has no overlay track; `suggest_broll` was removed in v3.4.0 — see §11), transcription, recording, scene/Look editing, music tracks, remote access, a built-in agent chat, and editing without the app.

The ScreenKite research notes are marketing-derived and partly unverified. We copy only the CLI verbs (`project open`, `tool list|describe|call`, `skills`, `export`), the `confirm:false` plan / `confirm:true` apply model and the "CLI / MCP" connection dialog.

## 1. Architecture

```
Claude Code / Codex / Gemini ──stdio JSON-RPC──▶ WordsCut mcp  (same binary, no GUI)
                    shell ──────────────────────▶ WordsCut agent …     (same binary, no GUI)
                                   │ reads <config>/dev.yusafcut.app/agent/connection.json
                                   ▼  HTTP/1.1 127.0.0.1:<random>, Authorization: Bearer <token>
┌──────────────── WordsCut.app (running) ───────────────────────────────────────┐
│ Rust src-tauri/src/agent/                                                      │
│   server.rs (hyper)  POST /mcp (MCP Streamable HTTP, JSON responses)           │
│                      GET /v1/health, GET /v1/tools, POST /v1/tools/call        │
│   mcp.rs (pure JSON-RPC) ─▶ relay.rs ── emit_to("main","agent:request") ─┐     │
│                              ▲ oneshot ◀── invoke agent_respond ◀────────┼─┐   │
│ Webview                                                                  ▼ │   │
│   src/lib/agent/bridge.ts ─▶ registry.callTool(name,input,liveContext) ────┘   │
│        tools/*.ts (pure) ─▶ lib/edl.ts, zoom.ts, fillers.ts, autoChapters.ts,  │
│                             captions.ts, projectOps.ts                         │
│        liveContext.applyProject(next) ─▶ projectStore.setProject (1 undo step) │
└────────────────────────────────────────────────────────────────────────────────┘
```

Key decisions:
- **The EDL stays in the frontend.** Rust never edits a Project; it relays calls and validates paths/files.
- **The catalog comes from the frontend.** On mount `bridge.ts` calls `agent_ready({catalog})`; Rust caches it. `tools/list` is answered from that cache, before it arrives the server returns `EDITOR_NOT_READY`.
- **One call at a time.** `relay.rs` holds a tokio mutex around each call; default deadline 60 s.
- **Stdio bridge is the main MCP entry.** Port and token change per launch, so client configs point at `WordsCut mcp`, which finds the server through the connection file. Plain HTTP config is offered as "Other".
- **HTTP server: hyper 1.x** (already in Cargo.lock via reqwest; enable `server`/`http1`). Fallback: `tiny_http` on a thread.

## 2. Shared contracts (WP0 — already committed in the tree; do not change signatures)

Files: `src/lib/agent/protocol.ts`, `src-tauri/src/agent/{mod.rs,protocol.rs,connection.rs}`. Read them for the exact types (`AgentContext`, `ToolCatalogEntry`, `ToolOutcome`, `RelayRequest/Response`, `PathInfo`, `ServerInfo`, `Health`, `ConnectionInfo`).

### 2.4 Tauri commands (implemented by WP-C, called by WP-B and WP-E)
| Command | Args | Returns |
|---|---|---|
| `agent_ready` | `{ catalog: ToolCatalogEntry[] }` | `()` |
| `agent_respond` | `{ response: RelayResponse }` | `()` (unknown id ignored) |
| `agent_path_info` | `{ path }` | `PathInfo` |
| `agent_write_text_file` | `{ path, contents, overwrite }` | `()` (validated, §6) |
| `agent_server_info` | – | `ServerInfo` |
| `agent_set_enabled` | `{ enabled }` | `ServerInfo` |
| `agent_regenerate_token` | – | `ServerInfo` |

### 2.5 HTTP surface (all endpoints require `Authorization: Bearer <token>`)
- `POST /mcp`: JSON-RPC 2.0, MCP Streamable HTTP, `application/json` responses (no SSE). Methods: `initialize` (negotiates `2025-06-18`, `2025-03-26` or `2024-11-05`; echo the client's version if supported else newest), `notifications/initialized` (202), `ping`, `tools/list`, `tools/call`. `GET /mcp` → 405.
  `tools/call` result: `{content:[{type:"text",text:<pretty JSON>}], structuredContent:<data>, isError:<!ok>}`.
- `GET /v1/health` → `Health`. `GET /v1/tools` → `ToolCatalogEntry[]`. `POST /v1/tools/call` with `{name,input}` → `ToolOutcome`.
- Status: 401 bad token, 403 bad Host or any Origin header, 404, 405, 413 body > 1 MiB, 503 `EDITOR_NOT_READY`.

## 3. Tool catalog (v1, 20 tools)

Mutating tools take: `confirm` (boolean, default false; false = plan, true = apply as ONE undo step) and `baseRevision` (integer; fail `STALE_REVISION` if the project changed since).

**Plan output** (`confirm:false`): `{applied:false, summary, revision, durationBefore, durationAfter, removedSec, removedWords:[{id,text,outputStart}] (max 200, plus removedWordCount), chapters:{before,after}, zoomRegions:{before,after}, details:{…}, next:"Call again with confirm:true (and baseRevision) to apply."}`
**Apply output**: same plus `applied:true`, new `revision`, `undo:"history {action:'undo'}"`. No-op → `applied:false, summary:"Nothing to do"`, no undo entry.
Times are **output-timeline seconds** unless named `source*`. `wordId` = stable `Word.id`.

| # | Tool | Mutates | Reuses |
|---|---|---|---|
| 1 | `project_info` | no | `totalDuration`, `project.media`, `computeTimeline` (edl.ts) |
| 2 | `transcript_get` | no | `flattenWordsInOutputTime` (captions.ts), `buildCues` |
| 3 | `transcript_search` | no | normalisation from `replaceText`/`deleteWordsByText` → `projectOps.findWords` |
| 4 | `edl_get` | no | `project.segments`, `computeTimeline`, `projectChapters`, `sanitizeZoomRegions` |
| 5 | `chapters_suggest` | no | `suggestChapters` (autoChapters.ts) |
| 6 | `edit_cut_words` | yes | `deleteWords` (edl.ts); ranges via `wordIdsInOutputRange` |
| 7 | `edit_cut_range` | yes | delete: `wordIdsInOutputRange`+`deleteWords`; keep: `keepOutputRange` |
| 8 | `edit_cut_fillers` | yes | `findFillersInSegments`+`deleteWords` (= `projectStore.deleteFillers`) |
| 9 | `edit_trim_silences` | yes | `ctx.detectPauses` + `cutSilences` (= `useCleanupActions.trimAudioSilences`) |
| 10 | `edit_replace_text` | yes | `projectOps.replaceText` (extracted from store) |
| 11 | `chapters_edit` | yes | `addChapter`/`removeChapter`/`renameChapter`, `projectOps.setChapters` |
| 12 | `zoom_edit` | yes | `addZoomRegion`/`removeZoomRegion`/`clearZoomRange`/`sanitizeZoomRegions` (zoom.ts), `generateAutoZoom` (autoZoom.ts) |
| 13 | `edit_batch` | yes | runs 6–12 `compute` in sequence, one apply |
| 14 | `history` | yes* | `useProjectStore.temporal.getState().undo/redo` (*no confirm) |
| 15 | `project_open` | session | `projectActions.openProjectAtPath` |
| 16 | `project_save` | session | `saveProjectRevision` (saveCoordinator.ts) + `addRecentProject` |
| 17 | `captions_export` | file | `buildSrt`/`buildVtt` + `agent_write_text_file` |
| 18 | `export_start` | file, confirm | `buildExportOptions` (new `src/lib/exportOptions.ts`, extracted from `Toolbar.runExport`) + `exportVideo` |
| 19 | `export_status` | no | `uiStore.exportingProgress` + last result kept by liveContext |
| 20 | `export_cancel` | session | `cancelExport` (ipc) |

### 3.1 Input schemas
Every schema is `{"type":"object","additionalProperties":false,…}`; `C` = confirm + baseRevision.

1. `project_info`: `{}` → `{name, filePath, dirty, revision, durationSec, originalDurationSec, media:[{id,path,durationSec,width,height,fps,hasTranscript}], wordCount, segmentCount, chapterCount, zoomRegionCount, busy}`
2. `transcript_get`: `format` enum words|sentences|text (default sentences); `offset` int ≥0 default 0; `limit` int 1–5000 default 1000; `range` {start,end} numbers ≥0. → words `[{id,text,start,end,confidence}]`; sentences `[{start,end,text,wordIds}]`; text = string with `[mm:ss]` markers per sentence. Always `{total, offset, nextOffset|null, revision}`.
3. `transcript_search`: required `query` (string 1–200); `wholeWord` default true; `caseSensitive` default false; `maxResults` 1–500 default 100. Multi-word queries match consecutive words. → `{matches:[{wordIds,text,start,end,context}], total}`
4. `edl_get`: `include` array (max 4) of timeline|segments|chapters|zoomRegions, default [timeline,chapters,zoomRegions]. `segments` omits word arrays (gives `wordCount`, `firstWordId`, `lastWordId`).
5. `chapters_suggest`: `count` int 1–50; `minChapterSec` 1–600 default 10 → `{suggestions:[{time,title}]}`
6. `edit_cut_words`: C + `wordIds` (array of strings ≤64 chars, 1–20000) | `ranges` (≤500 of {start,end}). Exactly one of wordIds/ranges (checked in code, else `INVALID_INPUT`). Unknown ids → `details.unknownIds`, ignored; all unknown → `NOT_FOUND`.
7. `edit_cut_range`: C + required `start`,`end` (end > start), `mode` delete|keep default delete.
8. `edit_cut_fillers`: C + `phrases` (≤100 strings 1–40 chars) → `details:{byPhrase:{um:12,…}}`. Default = `fillerStore.selected` (SAFE_FILLERS).
9. `edit_trim_silences`: C + `minDurationSec` 0.2–10 default 0.6; `keepSec` 0–2 (default 2 × paddingMs); `noiseThresholdDb` −80…−10 default −35. First media only (`details.mediaId`) → `details:{silencesFound, silencesCut, sourceRanges (max 200)}`. `prepare()` runs detection on every call incl. plans.
10. `edit_replace_text`: C + required `find` (1–200), `replace` (≤200), `caseSensitive` false, `wholeWord` true. Changes word text only, not timing.
11. `chapters_edit`: C + `set` (replace all), `add`, `removeIds`, `rename` [{id,title}], `fromSuggestions` {count}. Chapter input = `{time ≥0 (required), title ≤120}`; write inline (no `$ref` support). Order: set|fromSuggestions (mutually exclusive), removeIds, rename, add.
12. `zoom_edit`: C + `add` [{start,end,scale 1.2–4 default 1.6,focusX 0–1 default .5,focusY default .5,easeMs 0–2000 default 450}], `removeIds`, `clearRanges` [{start,end}], `auto` {sensitivity low|medium|high, replace default false}. Order: auto, clearRanges, removeIds, add. Regions < 0.5 s dropped → `details.rejected`. No cursor tracks → `details.autoSkipped:"no cursor data"`.
13. `edit_batch`: C + required `steps` (1–50 of {name enum of tools 6–12, input object}). Per-step confirm/baseRevision ignored; each step validated against its own schema; later steps see the timeline after earlier steps → `details.steps:[{name,summary,removedSec}]`.
14. `history`: required `action` undo|redo, `steps` 1–50 default 1 → `{done, revision, durationSec}`.
15. `project_open`: required `path` (1–4096), `discardUnsaved` default false. Dirty + not discard → `DIRTY_PROJECT` (hint: `project_save`). Returns project_info.
16. `project_save`: `path` optional; none → saves to `filePath`, else `INVALID_INPUT`. Must end `.scribe`.
17. `captions_export`: required `format` srt|vtt, `outputPath`, `overwrite` false. No path → `{content}` (truncate at 1 MiB, `truncated:true`); path → writes, returns `{outputPath, cueCount}`.
18. `export_start`: C + required `outputPath`, `resolution` original|720p|1080p|4k, `codec` auto|h264|hevc, `fps` enum 24,25,30,50,60, `overwrite`. Ignores baseRevision; plan shows resolved ExportOptions minus project. Apply starts and returns `{started:true, outputPath}`; poll `export_status`. Already running → `BUSY`.
19. `export_status`: `{}` → `{running, progress, lastResult}`
20. `export_cancel`: `{}` → `{cancelled}`

## 4. Plan/apply model and undo grouping

Registry flow for an `edit` tool:
1. Validate input with `schema.ts` (small JSON-schema subset, no new dependency). Fail `INVALID_INPUT` with JSON pointer.
2. `ctx.busyReason()` → `BUSY`. Missing media/transcript when needed → `NO_MEDIA`/`NO_TRANSCRIPT`.
3. `baseRevision` mismatch → `STALE_REVISION` (include current).
4. `prep = await tool.prepare?.(input, ctx)`.
5. `{next, summary, details} = tool.compute(project, input, prep)` (pure).
6. `diff = diffProjects(before, next)` (plan.ts, pure).
7. `confirm !== true` → return plan with `revision`.
8. `confirm === true` → recompute from the current project; `next === before` → `applied:false`; else `revision = await ctx.applyProject(next, summary)`.

`liveContext.applyProject` makes exactly one `setProject(next)` (zundo is reference-equality, so one set = one undo entry; `edit_batch` composes first). It wraps in `uiStore.withProcessingEdit("Agent: "+summary, …)` and calls `pushUndoToast("Agent: "+summary)`.

Trap: `withProcessingEdit` awaits `requestAnimationFrame`, which never fires while the window is hidden/minimised. liveContext races rAF against `setTimeout(50)` with a local helper; do not change `uiStore`.

`revision` counter lives in liveContext, bumped by `useProjectStore.subscribe` on every `project` reference change (undo/redo/UI edits too); resets on project open.

## 5. Frontend layout

```
src/lib/agent/
  protocol.ts        (WP0)
  schema.ts plan.ts registry.ts toolTypes.ts            (A)
  tools/project.ts transcript.ts edit.ts chapters.ts zoom.ts history.ts captions.ts export.ts (A)
  liveContext.ts bridgeIpc.ts bridge.ts                  (B)
  serverIpc.ts connectSnippets.ts                        (E)
src/lib/projectOps.ts      (A) pure: findWords, deleteBySourceRange, deleteWordsByText, replaceText, withZoom, setChapters
src/lib/exportOptions.ts   (A) pure: buildExportOptions(project, settings, outputPath)
src/lib/projectActions.ts  (B) openProjectAtPath(path), MEDIA_EXTENSIONS
src/components/Agent/AgentConnectDialog.tsx (E)
```

Tool definitions (`toolTypes.ts`):
```ts
interface ToolBase { name: string; title: string; description: string; inputSchema: JsonSchema }
export interface EditTool<I, P = void> extends ToolBase { kind: "edit";
  needs?: { media?: boolean; transcript?: boolean };
  prepare?(input: I, ctx: AgentContext): Promise<P>;
  compute(project: Project, input: I, prep: P): { next: Project; summary: string; details?: Record<string, unknown> } }
export interface ActionTool<I> extends ToolBase { kind: "query" | "action"; mutates: boolean;
  run(input: I, ctx: AgentContext): Promise<Record<string, unknown>> }
```

WP-A provides for WP-B:
```ts
export interface ExportUiSettings { resolution: "original"|"720p"|"1080p"|"4k"|"custom"; customWidth: number; customHeight: number;
  codec: "auto"|"h264"|"hevc"; fps?: string|number; videoBitrateKbps?: number; audioBitrateKbps?: number; forceReencode?: boolean }
export function buildExportOptions(project: Project, s: ExportUiSettings, outputPath: string): ExportOptions
```
(the body of `Toolbar.runExport` from `dims` through the `exportVideo` argument; scene via `resolveSceneForExport`, `sanitizeZoomRegions`, `drawCursor`.)

Bridge started in `App.tsx`: `useEffect(() => { const p = startAgentBridge(); return () => void p.then(u => u()); }, [])`; calls `agentReady(catalog())` after the listener attaches.

## 6. Security

- **Off by default.** `<agent_dir>/settings.json` `{"enabled": false}`; only the dialog toggle changes it. When enabled the server starts in `setup()` and returns `EDITOR_NOT_READY` until `agent_ready`.
- Bind `127.0.0.1:0` only. Port chosen per launch.
- Token: 256 bits from two `uuid::Uuid::new_v4()` hex values; new per start and on "Regenerate"; constant-time compare; required on every route.
- Connection file: dir 0700, `connection.json` 0600, atomic write; removed on `RunEvent::Exit` and on disable.
- Reject any request with an `Origin` header (403). `Host` must be `127.0.0.1:<port>` or `localhost:<port>`. No CORS headers.
- Limits: body 1 MiB (413); response data capped 4 MiB by the registry (`truncated:true`); schema caps; per-call deadline 60 s incl. queue time; pending map cleared on timeout.
- Paths (Rust `security.rs`, via `agent_path_info` and re-checked in `agent_write_text_file`): absolute, no NUL, canonicalised, parent must exist; refuse paths inside the running `.app` bundle or `agent_dir()`. Extension allowlists: open `.scribe` (dir with `project.json`) or `project.json`; save `.scribe`; export `.mp4`/`.mov` (`.m4a` for `podcast-audio`); captions `.srt`/`.vtt`. No overwrite unless `overwrite:true`. Text writes ≤ 10 MiB.
- No generic eval or shell. Logs: tool name, duration, outcome code only — never token, inputs or transcript.
- Threat model: other processes running as the same user can read the token and are trusted; the dialog says so.
- App Store build: if `APP_SANDBOX_CONTAINER_ID` is set → `available:false`, `unavailableReason:"Not available in the Mac App Store build"`, server never starts.

## 7. Rust layout

```
src-tauri/src/agent/
  mod.rs         (WP0 stub; C finishes) AgentState, init(app), shutdown()
  protocol.rs connection.rs                (WP0)
  settings.rs security.rs mcp.rs relay.rs server.rs commands.rs   (C)
src-tauri/src/cli/            (D; declared from main.rs with `mod cli;`)
  mod.rs args.rs client.rs launch.rs stdio.rs output.rs inspect.rs
src-tauri/resources/agent/README.md, SKILL.md   (D; include_str!)
```
- `security.rs` pure: `check_host`, `has_origin`, `token_eq`, `validate_path(kind, path)`, `MAX_BODY`.
- `mcp.rs` pure: `trait ToolBackend { ready; catalog; async call }`, `handle_jsonrpc(msg, backend) -> Option<Value>`.
- `relay.rs`: pending `HashMap<String, oneshot::Sender<Value>>`, catalog `RwLock`, exec `Mutex`, `emit_to("main", EVENT_REQUEST, …)`.
- `lib.rs` (C only): `.manage(AgentState)`, register the 7 commands, `agent::init` in `setup`, `.build(ctx)?.run(|h, e| if let RunEvent::Exit = e { agent::shutdown(h) })`.
- `Cargo.toml` (C only): `hyper = { version = "1", features = ["server","http1"] }`, `hyper-util = { version = "0.1", features = ["tokio"] }`, `http-body-util = "0.1"`.
- `main.rs` (D): if `args[1]` is `agent` or `mcp` → `std::process::exit(cli::run(&args[1..]))`, else `yusafcut_lib::run()` (check actual lib crate name).

## 8. CLI

```
WordsCut agent readme
WordsCut agent status [--json]
WordsCut agent project open --path <dir.scribe> [--discard-unsaved] [--json]
WordsCut agent project info [--json]
WordsCut agent project save [--path <p>] [--json]
WordsCut agent project inspect --path <p> [--json]      # headless, read-only
WordsCut agent tool list [--json]
WordsCut agent tool describe --name <tool> [--json]
WordsCut agent tool call --name <tool> (--input-json '<json>' | --input-file <file|->) [--json]
WordsCut agent skills [--print <name>] [--write <dir>]
WordsCut agent export --output <p> [--resolution 1080p] [--codec auto] [--confirm] [--json]
WordsCut mcp                                            # stdio MCP server
Global: --no-launch  --timeout <sec>  --json
```
- `project open|info|save` and `export` are shorthand for `tool call`. Exit codes: 0 ok, 2 usage, 3 app not running/unreachable, 4 unauthorized or access disabled, 5 tool error, 6 `STALE_REVISION`. `--json` prints exactly one line with the `ToolOutcome`.
- App not running: read `connection.json`, call `/v1/health`; on failure and no `--no-launch`, `open -a <bundle>` (bundle from `current_exe()/../../..`; in dev print "start `npm run tauri:dev`") and poll ≤ 30 s. Access disabled → exit 4 "Enable it in WordsCut → Agent (CLI/MCP)". `project inspect` uses the lib's project loader, read-only.
- `mcp` stdio bridge: newline-delimited JSON-RPC on stdin/stdout, logs only to stderr. `initialize`, `notifications/initialized`, `ping` answered locally; `tools/list` and `tools/call` forwarded to `POST /mcp` (re-read connection file each request; auto-launch on first need). App unreachable → JSON-RPC error `-32001`.
- README/SKILL: workflow loop (§4), time conventions, catalog summary, "plan first, apply with baseRevision", undo via `history`, example sessions.

## 9. UI: "Project MCP Server" dialog

Entry: TopBar button "Agent" (lucide `Bot`, beside Export) and a Project-menu item. Open state is local `useState` in `TopBar.tsx`. Built on `ui/dialog.tsx` with a two-button segmented tab control (CLI | MCP).

- **Header**: "Project MCP Server"; status pill (Running · 127.0.0.1:PORT / Off / Unavailable); "Allow agent access" switch → `agentSetEnabled`; one sentence: local only, any app running as you can connect while on.
- **CLI tab**: Binary path + Copy. "Start here": `"<BIN>" agent readme` + Copy. Examples: `project open --path "<filePath or ~/Movies/demo.scribe>" --json`, `tool list`, `tool call --name edit_trim_silences --input-json '{"confirm":false}' --json`. Optional PATH hint.
- **MCP tab**: client chooser Claude Code / Codex / Gemini CLI / Other (HTTP):
  - Claude Code: `claude mcp add yusafcut -- "<BIN>" mcp`, or `.mcp.json` `{"mcpServers":{"yusafcut":{"command":"<BIN>","args":["mcp"]}}}`
  - Codex (`~/.codex/config.toml`): `[mcp_servers.yusafcut]` / `command = "<BIN>"` / `args = ["mcp"]`
  - Gemini CLI (`~/.gemini/settings.json`): same JSON as Claude's `.mcp.json`
  - Other: URL `http://127.0.0.1:<port>/mcp`, header `Authorization: Bearer <token>`; token masked with Reveal/Copy/Regenerate and a warning that both change per launch.
- Copy uses `navigator.clipboard.writeText` + toast.

## 10. Work packages (disjoint file sets)

**WP0 (done)** contracts. **WP-Z** integration (version 4.27.0 in package.json/Cargo.toml/tauri.conf.json, CHANGELOG, architecture.md, README, HANDOFF) is done by the orchestrator last; packages must not touch those files.

### WP-A: tool registry (pure TS)
Files: `src/lib/agent/{schema,plan,registry,toolTypes}.ts`, `src/lib/agent/tools/*.ts`, `src/lib/projectOps.ts`, `src/lib/exportOptions.ts`, `src/stores/projectStore.ts` (behaviour-preserving refactor to `projectOps`), `tests/agent/*.test.ts`.
Acceptance: existing Vitest suites pass unchanged; `npm run check` clean; `catalog()` returns 20 entries (names `^[a-z][a-z0-9_]{1,63}$`, object schemas with `additionalProperties:false`, snapshot test); fake-context tests: `confirm:false` never calls `applyProject`, `confirm:true` exactly once, `edit_batch` of 3 steps once, no-op zero; `edit_cut_fillers` matches `projectStore.deleteFillers`; `edit_trim_silences` with injected silences matches `cutSilences`; `edit_cut_range` keep matches `keepOutputRange`; bad `baseRevision` → `STALE_REVISION`; bad input → `INVALID_INPUT` with pointer; `buildExportOptions` matches current Toolbar output for all resolutions.

### WP-B: live bridge and app-action extraction
Files: `src/lib/agent/{liveContext,bridgeIpc,bridge}.ts`, `src/lib/projectActions.ts`, `src/components/Toolbar/Toolbar.tsx` (use `openProjectAtPath`, `buildExportOptions`), `src/App.tsx`, `tests/agentBridge.test.ts`, `tests/liveContext.test.ts`.
Acceptance: with tauri api mocked, bridge calls `agent_ready` with catalog after `listen`; one `agent:request` → exactly one `agent_respond` with same id; throwing tool → `INTERNAL`; unlisten cleans up; `applyProject` adds exactly one zundo past state, bumps revision, resolves when rAF never fires, refuses `BUSY` while exporting or recorder not idle; Toolbar behaviour unchanged. Until WP-A lands B may use a local stub for `registry.ts` but must not commit it.

### WP-C: Rust server and relay
Files: `src-tauri/src/agent/{mod,settings,security,mcp,relay,server,commands}.rs`, `src-tauri/src/lib.rs`, `src-tauri/Cargo.toml`, `Cargo.lock`.
Acceptance (`cargo test`): security Host/Origin/token/path cases; mcp with fake backend (version negotiation, tools/list before ready errors, `isError` mapping, notification no response, `-32601`, `-32700`); integration on ephemeral port (401, 403, 413, round trip, serialised concurrent calls); relay timeout → `TIMEOUT` and pending cleared, unknown id ignored; connection file written/removed; disabled under `APP_SANDBOX_CONTAINER_ID`; `npm run test:rust` green.

### WP-D: CLI and stdio MCP bridge
Files: `src-tauri/src/main.rs`, `src-tauri/src/cli/*.rs`, `src-tauri/resources/agent/{README,SKILL}.md`.
Acceptance (`cargo test`): parser accepts all §8 forms, unknown flags exit 2, `--input-file -` reads stdin; human and `--json` output tests; missing connection + `--no-launch` → 3, 401 → 4, `STALE_REVISION` → 6; stdio bridge answers `initialize`/`ping` locally, forwards `tools/call`, emits exactly one JSON line per request; `agent readme` prints the embedded README; `project inspect` works on a temp `.scribe`; no Tauri runtime started for `agent`/`mcp`.

### WP-E: connection dialog
Files: `src/components/Agent/AgentConnectDialog.tsx`, `src/lib/agent/{connectSnippets,serverIpc}.ts`, `src/components/editor/TopBar.tsx` (verify real path of the top bar), `tests/connectSnippets.test.ts`, `tests/AgentConnectDialog.test.tsx`.
Acceptance: exact snippet strings for Claude Code, Codex, Gemini, HTTP with correct shell/TOML/JSON escaping (JSON parses); dialog renders Running/Off/Unavailable from mocked `agent_server_info`; toggle calls `agent_set_enabled`; copy buttons write correct text; token masked until Reveal; TopBar button opens the dialog; `npm run check` clean.

## 11. Deferred / v2
- **B-roll**: `Project.overlays`, preview layer, export overlay graph, `broll_propose`/`broll_accept` with the same plan/apply model.
- More tools: `media_import`, `media_add_clip`, `transcribe_start`, `scene_set`, `music_add`, `player_seek`.
- Protocol: SSE notifications, MCP `resources`, per-tool risk tiers / approval prompts.
