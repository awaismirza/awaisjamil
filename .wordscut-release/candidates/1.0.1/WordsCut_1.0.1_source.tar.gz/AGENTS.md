# AGENTS.md

Instructions for any coding agent working in this repository (Claude, Codex,
Cursor, others).

1. Read `docs/HANDOFF.md` first. It says what state the project is in, what is
   done, what is in flight, what to do next, and the traps that cost time before.
2. Then read `CLAUDE.md`. Its workflow rules are mandatory for every agent:
   new branch per change, bump the version in all three places, update the docs in
   the same commit, never open a PR or merge unless the owner explicitly asks.
3. Then `docs/architecture.md` for how the code fits together.

Rules that matter most:

- Stage files by explicit path (`git add <path>`), never `git add -A`, because
  another agent may be editing the same checkout. Use a git worktree for parallel
  work.
- Do not claim a UI change works unless you ran it (`npm run tauri:dev`) or say
  that you could not.
- Before you stop, update the **Status / Next up** sections of `docs/HANDOFF.md`
  so the next agent can continue from exactly where you left off.

Quick verification:

```bash
npm install && npm run check && npm test && (cd src-tauri && cargo test)
```
