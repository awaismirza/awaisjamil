import { act, cleanup, fireEvent, render, screen, within } from "@testing-library/react";
import { afterEach, beforeEach, expect, it, vi } from "vitest";
import { parseCursorLog } from "@/lib/cursor";
import { countKeyNames } from "@/lib/keystrokes";
import { OverlaysPanel } from "@/components/editor/sidebar/panels/OverlaysPanel";
import { addMediaWithTranscript, newProject } from "@/lib/edl";
import { useProjectStore } from "@/stores/projectStore";
import { usePlayerStore } from "@/stores/playerStore";

beforeEach(() => {
  const p = addMediaWithTranscript(
    newProject("panel"),
    {
      id: "m",
      path: "/tmp/demo.mp4",
      duration: 20,
      width: 1920,
      height: 1080,
      fps: 30,
      audioSampleRate: 48000,
      sha256: "x",
    },
    [],
  );
  useProjectStore.setState({ project: p, dirty: false });
  useProjectStore.temporal.getState().clear();
  usePlayerStore.getState().reset();
  usePlayerStore.getState().setCurrentTime(4);
});
afterEach(cleanup);

const notes = () => useProjectStore.getState().project.annotations ?? [];

it("adds at the playhead, edits on commit (one undo step) and deletes", () => {
  render(<OverlaysPanel />);
  fireEvent.click(screen.getByRole("button", { name: /add text/i }));
  expect(notes()[0]).toMatchObject({ kind: "text", start: 4, end: 7 });
  const steps = useProjectStore.temporal.getState().pastStates.length;

  const text = screen.getByLabelText("Text") as HTMLTextAreaElement;
  fireEvent.change(text, { target: { value: "Click here" } });
  expect(notes()[0]!.text).toBe("Text"); // not committed while typing
  fireEvent.blur(text);
  expect(notes()[0]!.text).toBe("Click here");

  const x = screen.getByLabelText("X (%)") as HTMLInputElement;
  fireEvent.change(x, { target: { value: "40" } });
  fireEvent.keyDown(x, { key: "Enter" });
  fireEvent.blur(x);
  expect(notes()[0]!.x).toBeCloseTo(0.4);

  fireEvent.click(screen.getByRole("radio", { name: "Blue" }));
  expect(notes()[0]!.color).toBe("#0a84ff");
  expect(useProjectStore.temporal.getState().pastStates.length).toBe(steps + 3);

  fireEvent.click(screen.getByRole("button", { name: /delete text at/i }));
  expect(notes()).toHaveLength(0);
});

it("keystrokes are off by default and 'all keys' shows a privacy note", () => {
  render(<OverlaysPanel />);
  // The masks section has its own (static region) note; look only at the keystroke section.
  const keys = within(screen.getByRole("region", { name: "Keystroke overlay" }));
  const toggle = keys.getByRole("checkbox", { name: /show keyboard shortcuts/i });
  expect(toggle).not.toBeChecked();
  expect(keys.queryByRole("note")).toBeNull();
  fireEvent.click(toggle);
  expect(useProjectStore.getState().project.keystrokes).toEqual({
    enabled: true,
    mode: "shortcuts",
  });
  expect(keys.queryByRole("note")).toBeNull();
  fireEvent.click(keys.getByRole("radio", { name: /all key presses/i }));
  expect(useProjectStore.getState().project.keystrokes?.mode).toBe("all");
  expect(keys.getByRole("note").textContent).toMatch(
    /shows exactly what you typed.*hidden or missing.*Terminal or iTerm sudo and ssh.*Secure Keyboard Entry/,
  );
  expect(screen.getByText(/No key presses in this project/)).toBeInTheDocument();
  expect(
    screen.getByText(/shortcut shows as “⌘ key”.*any app.*spell out what you typed/),
  ).toBeInTheDocument();
});

it("strips key names in one undo step after a confirmation, keeping timing and modifiers", () => {
  const log = [
    '{"type":"key","t":1,"mods":["cmd"],"name":"k"}',
    '{"type":"key","t":2,"secure":true}',
  ].join("\n");
  const p = useProjectStore.getState().project;
  useProjectStore.setState({
    project: {
      ...p,
      cursor: { style: p.cursor?.style, tracks: { m: parseCursorLog(log) } } as never,
    },
  });
  useProjectStore.temporal.getState().clear();
  render(<OverlaysPanel />);
  const button = screen.getByRole("button", { name: /strip key names/i });
  const confirm = vi.spyOn(window, "confirm").mockReturnValueOnce(false);
  fireEvent.click(button);
  expect(countKeyNames(useProjectStore.getState().project)).toBe(2);
  confirm.mockReturnValueOnce(true);
  fireEvent.click(button);
  const events = useProjectStore.getState().project.cursor!.tracks.m!.events;
  expect(events).toEqual([
    { type: "key", t: 1, mods: ["cmd"] },
    { type: "key", t: 2, mods: [] },
  ]);
  expect(useProjectStore.temporal.getState().pastStates.length).toBe(1);
  act(() => useProjectStore.temporal.getState().undo());
  expect(countKeyNames(useProjectStore.getState().project)).toBe(2);
  confirm.mockRestore();
});

it("swatches are named, use one tab stop and move with arrow keys", () => {
  render(<OverlaysPanel />);
  fireEvent.click(screen.getByRole("button", { name: /add box/i }));
  const red = screen.getByRole("radio", { name: "Red" });
  expect(red).toHaveAttribute("tabindex", "0");
  expect(screen.getByRole("radio", { name: "White" })).toHaveAttribute("tabindex", "-1");
  fireEvent.keyDown(red, { key: "ArrowRight" });
  expect(notes()[0]!.color).toBe("#ffcc00");
  expect(screen.getByRole("radio", { name: "Yellow" })).toHaveFocus();
  fireEvent.keyDown(screen.getByRole("radio", { name: "Yellow" }), { key: "ArrowLeft" });
  fireEvent.keyDown(screen.getByRole("radio", { name: "Red" }), { key: "ArrowLeft" });
  expect(notes()[0]!.color).toBe("#000000");
});

it("explains removed emoji and the annotation limit", () => {
  render(<OverlaysPanel />);
  fireEvent.click(screen.getByRole("button", { name: /add text/i }));
  const text = screen.getByLabelText("Text") as HTMLTextAreaElement;
  fireEvent.change(text, { target: { value: "Ship it 🚀" } });
  fireEvent.blur(text);
  expect(notes()[0]!.text).toBe("Ship it ");
  expect(screen.getByText(/Emoji were removed/)).toBeInTheDocument();

  const many = Array.from({ length: 500 }, (_, i) => ({
    id: `b${i}`,
    kind: "box",
    start: 0,
    end: 1,
  }));
  act(() => {
    useProjectStore.setState((s) => ({ project: { ...s.project, annotations: many as never } }));
  });
  expect(useProjectStore.getState().addAnnotation("box", 1)).toBeNull();
  expect(screen.getByText(/at most 500 annotations/)).toBeInTheDocument();
  expect(screen.getByRole("button", { name: /add box/i })).toBeDisabled();
});
