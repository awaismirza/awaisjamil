import { beforeEach, describe, expect, it } from "vitest";
import {
  latestRecordingTimeline,
  markRecordingStage,
  recordingTimeline,
  resetRecordingTimelines,
} from "../src/lib/recordingTimeline";

describe("recordingTimeline", () => {
  beforeEach(resetRecordingTimelines);

  it("reports elapsed time from Stop for each stage reached", () => {
    markRecordingStage("a", "stopRequested", 100);
    markRecordingStage("a", "finishedReceived", 1100);
    markRecordingStage("a", "inserted", 1300);
    expect(recordingTimeline("a")).toEqual({
      stopRequested: 0,
      finishedReceived: 1000,
      inserted: 1200,
    });
  });

  it("keeps the first mark of a stage", () => {
    markRecordingStage("a", "stopRequested", 0);
    markRecordingStage("a", "firstFrame", 50);
    markRecordingStage("a", "firstFrame", 900);
    expect(recordingTimeline("a").firstFrame).toBe(50);
  });

  it("is empty without a Stop mark and bounds retained sessions", () => {
    markRecordingStage("x", "inserted", 5);
    expect(recordingTimeline("x")).toEqual({});
    for (let i = 0; i < 40; i++) markRecordingStage(`s${i}`, "stopRequested", i);
    expect(recordingTimeline("s0")).toEqual({});
    expect(latestRecordingTimeline()?.sessionId).toBe("s39");
  });
});
