import { act, cleanup, render } from "@testing-library/react";
import { afterEach, beforeEach, expect, it, vi } from "vitest";
import { VideoPreview } from "@/components/VideoPreview/VideoPreview";
import { addMediaWithTranscript, newProject } from "@/lib/edl";
import { parseCursorLog } from "@/lib/cursor";
import { useProjectStore } from "@/stores/projectStore";
import { usePlayerStore } from "@/stores/playerStore";
import { syntheticCursorLog } from "./fixtures/cursorLogs";
vi.mock("@tauri-apps/api/core", () => ({ convertFileSrc: (path: string) => path }));
beforeEach(() => {
  vi.spyOn(HTMLMediaElement.prototype, "pause").mockImplementation(() => {});
  vi.spyOn(HTMLMediaElement.prototype, "load").mockImplementation(() => {});
  const p = addMediaWithTranscript(
    newProject("cursor"),
    {
      id: "m",
      path: "/tmp/demo.mp4",
      duration: 20,
      width: 1920,
      height: 1080,
      fps: 30,
      audioSampleRate: 48000,
      sha256: "x",
    },
    [],
  );
  useProjectStore.setState({ project: p, dirty: false });
  usePlayerStore.getState().reset();
});
afterEach(() => {
  cleanup();
  vi.restoreAllMocks();
});
it("keeps the same video while cursor/scene/zoom settings change and transforms the cursor with it", () => {
  const { container } = render(<VideoPreview />);
  const video = container.querySelector("video")!;
  act(() => {
    useProjectStore.getState().setCursorTrack("m", parseCursorLog(syntheticCursorLog()));
    useProjectStore.getState().setCursorStyle({ shape: "ring" });
    useProjectStore.getState().addZoomRegion({ start: 0, end: 5, scale: 2, easeMs: 0 });
    useProjectStore.getState().setScene({ paddingPct: 12 });
    usePlayerStore.getState().setCurrentTime(2);
  });
  expect(container.querySelector("video")).toBe(video);
  expect(video.parentElement?.style.transform).toContain("scale(2)");
  expect(video.parentElement?.querySelector(".cursor-overlay")).toBeInTheDocument();
  act(() => {
    useProjectStore.getState().setCursorStyle({ show: false });
  });
  expect(container.querySelector(".cursor-overlay")).not.toBeInTheDocument();
  expect(container.querySelector("video")).toBe(video);
});
