import { describe, expect, it } from "vitest";
import { defaultScene, sceneLayout, type SceneSettings } from "@/lib/scene";
import { backgroundCss, sceneCss } from "@/lib/sceneCss";

const SRC = { w: 1920, h: 1080 };
const scene = (patch: Partial<SceneSettings> = {}): SceneSettings => ({
  ...defaultScene(),
  enabled: true,
  aspect: "16:9",
  ...patch,
});

describe("backgroundCss", () => {
  it("renders a solid colour", () => {
    expect(backgroundCss({ kind: "solid", color: "#112233" })).toEqual({ backgroundColor: "#112233" });
  });

  it("renders a CSS-angle gradient", () => {
    expect(backgroundCss({ kind: "gradient", from: "#000000", to: "#ffffff", angle: 135 })).toEqual({
      backgroundImage: "linear-gradient(135deg, #000000, #ffffff)",
    });
  });

  it("covers the stage with an image, or falls back to black until it is known", () => {
    const withUrl = backgroundCss({ kind: "image", path: "/a.png" }, "asset://localhost/a.png");
    expect(withUrl.backgroundImage).toBe('url("asset://localhost/a.png")');
    expect(withUrl.backgroundSize).toBe("cover");
    expect(backgroundCss({ kind: "image", path: "/a.png" })).toEqual({ backgroundColor: "#000000" });
  });
});

describe("sceneCss", () => {
  it("positions the content exactly where sceneLayout puts it", () => {
    const s = scene({ paddingPct: 10 });
    const l = sceneLayout(s, SRC);
    const css = sceneCss(s, SRC);
    expect(css.content.left).toBe(`${((l.content.x / l.canvasW) * 100).toFixed(4)}%`);
    expect(css.content.top).toBe(`${((l.content.y / l.canvasH) * 100).toFixed(4)}%`);
    expect(css.content.width).toBe(`${((l.content.w / l.canvasW) * 100).toFixed(4)}%`);
    expect(css.content.height).toBe(`${((l.content.h / l.canvasH) * 100).toFixed(4)}%`);
  });

  it("gives the stage the canvas aspect", () => {
    expect(sceneCss(scene({ aspect: "9:16" }), SRC).stage.aspectRatio).toBe("1080 / 1920");
    expect(sceneCss(scene({ aspect: "1:1" }), SRC).stage.aspectRatio).toBe("1080 / 1080");
  });

  it("scales radius with the stage, not with pixels", () => {
    const css = sceneCss(scene({ radiusPct: 3 }), SRC);
    expect(String(css.content.borderRadius)).toMatch(/cqw$/);
  });

  it("omits the shadow when strength is zero", () => {
    expect(sceneCss(scene({ shadow: 0 }), SRC).content.boxShadow).toBe("none");
    expect(String(sceneCss(scene({ shadow: 0.8 }), SRC).content.boxShadow)).toContain("rgba(0, 0, 0,");
  });

  it("applies the background to the stage", () => {
    const css = sceneCss(scene({ background: { kind: "solid", color: "#abcdef" } }), SRC);
    expect(css.stage.backgroundColor).toBe("#abcdef");
  });
});
