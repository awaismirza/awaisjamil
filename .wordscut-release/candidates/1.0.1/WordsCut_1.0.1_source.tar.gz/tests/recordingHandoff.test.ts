/**
 * Recording hand-off (4.49): a take is inserted from ffprobe metadata alone;
 * its checksum and (screen + camera) its camera composite arrive later and are
 * attached with project / media / path guards, never as an undo step.
 */
import { beforeEach, describe, expect, it, vi } from "vitest";
import { newProject, type Project, type SourceMedia, type Word } from "@/lib/edl";
import type { RecordingResult } from "@/lib/ipc";

const ipc = vi.hoisted(() => ({
  probeMedia: vi.fn(),
  hashMedia: vi.fn(),
  compositeRecordingCamera: vi.fn(),
  discardRecordingComposite: vi.fn(async () => {}),
  cancelJob: vi.fn(async () => {}),
  ackRecordingResult: vi.fn(async () => {}),
  listModels: vi.fn(),
  transcribe: vi.fn(),
  detectPauses: vi.fn(async () => []),
}));
vi.mock("@/lib/ipc", async (orig) => ({ ...(await orig<object>()), ...ipc }));
vi.mock("@/lib/cursorImport", () => ({ loadRecordingCursorTrack: vi.fn() }));

import {
  appendRecordingToProject,
  importFinishedRecording,
  resumePendingCameras,
} from "@/stores/recordingStore";
import {
  attachDeferredChecksum,
  clearPendingCamera,
  compositeMismatch,
  sharesFile,
  resetRecordingHandoff,
  resolveRecordingSource,
  swapToComposite,
} from "@/lib/recordingHandoff";
import { readTranscriptCache, writeTranscriptCache } from "@/lib/transcriptCache";
import { sameFile } from "@/lib/masks";
import { useProjectStore } from "@/stores/projectStore";
import { usePlayerStore } from "@/stores/playerStore";
import { useSettingsStore } from "@/stores/settingsStore";
import { useUIStore } from "@/stores/uiStore";
import {
  markRecordingStage,
  recordingTimeline,
  resetRecordingTimelines,
} from "@/lib/recordingTimeline";

const SHA = "a".repeat(64);
const SHA2 = "b".repeat(64);
const take: SourceMedia = {
  id: "take",
  path: "/rec/rec-1/screen-camera-1.mp4",
  duration: 30,
  fps: 30,
  width: 2560,
  height: 1440,
  audioSampleRate: 48000,
  sha256: "",
};
const composite: SourceMedia = { ...take, id: "probe-id", path: "/rec/rec-1/screen-camera-2.mp4" };
const words: Word[] = [0, 1].map((i) => ({
  id: `w${i}`,
  text: `w${i}`,
  start: i,
  end: i + 1,
  confidence: 1,
}));

function deferred<T>() {
  let resolve!: (v: T) => void;
  let reject!: (e: unknown) => void;
  const promise = new Promise<T>((res, rej) => {
    resolve = res;
    reject = rej;
  });
  return { promise, resolve, reject };
}
const flush = () => new Promise((r) => setTimeout(r, 0));
const state = () => useProjectStore.getState();
const history = () => useProjectStore.temporal.getState();
const lastToast = () => useUIStore.getState().toasts.at(-1)?.title;

beforeEach(() => {
  vi.clearAllMocks();
  localStorage.clear();
  resetRecordingHandoff();
  resetRecordingTimelines();
  useProjectStore.setState({ project: newProject("rec"), dirty: false, filePath: null });
  history().clear();
  usePlayerStore.getState().setPlaying(false);
  useSettingsStore.getState().setRecording({ autoTranscribe: false, markersBecomeChapters: false });
  useUIStore.setState({ toasts: [], backgroundTranscriptions: {} });
  ipc.probeMedia.mockImplementation(async (path: string) =>
    path === take.path ? { ...take } : { ...composite, path },
  );
  ipc.listModels.mockResolvedValue([
    { name: "tiny", installed: true, sizeMb: 1, engine: "whisper-cpp" },
  ]);
});

describe("deferred checksum", () => {
  it("inserts from the probe alone and attaches the hash later without an undo step", async () => {
    const hash = deferred<string>();
    ipc.hashMedia.mockReturnValue(hash.promise);
    const added = await appendRecordingToProject(take.path, [], undefined, "s1");
    expect(ipc.probeMedia).toHaveBeenCalledWith(take.path);
    const id = added!.media.id;
    expect(state().project.media[id]!.sha256).toBe("");
    const steps = history().pastStates.length;
    useProjectStore.setState({ dirty: false });
    hash.resolve(SHA);
    await vi.waitFor(() => expect(state().project.media[id]!.sha256).toBe(SHA));
    expect(history().pastStates.length).toBe(steps);
    expect(state().dirty).toBe(false);
    // Every undo state that held the entry now holds the same checksummed object.
    const objects = new Set(
      history()
        .pastStates.map((s) => s.project?.media[id])
        .filter(Boolean),
    );
    for (const m of objects) expect(m).toBe(state().project.media[id]);
  });

  it("never attaches to another project, a relinked entry, or over an existing checksum", () => {
    const p = { ...newProject("a"), media: { take: { ...take } } };
    useProjectStore.setState({ project: p });
    expect(attachDeferredChecksum("other-project", "take", take.path, SHA)).toBe(false);
    expect(attachDeferredChecksum(p.id, "missing", take.path, SHA)).toBe(false);
    expect(attachDeferredChecksum(p.id, "take", "/somewhere/else.mp4", SHA)).toBe(false);
    expect(attachDeferredChecksum(p.id, "take", take.path, "not-a-hash")).toBe(false);
    expect(attachDeferredChecksum(p.id, "take", take.path, "")).toBe(false);
    expect(state().project.media.take!.sha256).toBe("");
    expect(attachDeferredChecksum(p.id, "take", take.path, SHA)).toBe(true);
    expect(attachDeferredChecksum(p.id, "take", take.path, SHA2)).toBe(false);
    expect(state().project.media.take!.sha256).toBe(SHA);
  });

  it("drops a hash that arrives after the project changed", async () => {
    const hash = deferred<string>();
    ipc.hashMedia.mockReturnValue(hash.promise);
    await appendRecordingToProject(take.path);
    const other = newProject("other");
    useProjectStore.setState({ project: other });
    hash.resolve(SHA);
    await flush();
    expect(state().project).toBe(other);
  });

  it("reaches a take whose append was undone, so redo brings it back hashed", async () => {
    const hash = deferred<string>();
    ipc.hashMedia.mockReturnValue(hash.promise);
    const added = await appendRecordingToProject(take.path);
    history().undo();
    expect(state().project.media[added!.media.id]).toBeUndefined();
    hash.resolve(SHA);
    await vi.waitFor(() =>
      expect(history().futureStates.at(-1)?.project?.media[added!.media.id]?.sha256).toBe(SHA),
    );
    history().redo();
    expect(state().project.media[added!.media.id]!.sha256).toBe(SHA);
  });

  it("keeps background words attached (and undoable) when the checksum lands first", async () => {
    useSettingsStore.getState().setRecording({ autoTranscribe: true });
    const recognised = deferred<{ mediaId: string; words: Word[]; engine: "whisper-cpp" }>();
    ipc.transcribe.mockReturnValue(recognised.promise);
    ipc.hashMedia.mockResolvedValue(SHA);
    const added = await appendRecordingToProject(take.path);
    const id = added!.media.id;
    await vi.waitFor(() => expect(state().project.media[id]!.sha256).toBe(SHA));
    const seg = state().project.segments[0]!;
    state().trimClip(seg.id, "start", 1);
    recognised.resolve({ mediaId: id, words, engine: "whisper-cpp" });
    await vi.waitFor(() => expect(state().project.originalTranscripts?.[id]).toEqual(words));
    expect(state().project.segments[0]!.words.map((w) => w.id)).toEqual(["w1"]);
    history().undo(); // the trim
    expect(state().project.segments[0]!.words.map((w) => w.id)).toEqual(["w0", "w1"]);
    // The cache is keyed by the attached checksum.
    expect(readTranscriptCache(state().project.media[id]!)).toEqual(words);
  });

  it("writes the transcript cache only once a checksum is known", async () => {
    useSettingsStore.getState().setRecording({ autoTranscribe: true });
    ipc.transcribe.mockResolvedValue({ mediaId: "x", words, engine: "whisper-cpp" });
    const hash = deferred<string>();
    ipc.hashMedia.mockReturnValue(hash.promise);
    const added = await appendRecordingToProject(take.path);
    const id = added!.media.id;
    await vi.waitFor(() => expect(state().project.originalTranscripts?.[id]).toEqual(words));
    expect(Object.keys(localStorage).filter((k) => k.startsWith("yusafcut.transcript"))).toEqual(
      [],
    );
    hash.resolve(SHA);
    await vi.waitFor(() => expect(readTranscriptCache(state().project.media[id]!)).toEqual(words));
  });

  it("an absent checksum never keys the transcript cache", () => {
    writeTranscriptCache({ ...take, sha256: "" }, words);
    expect(Object.keys(localStorage).filter((k) => k.startsWith("yusafcut.transcript"))).toEqual(
      [],
    );
    expect(readTranscriptCache({ ...take, id: "other", path: "/other.mp4" })).toBeNull();
  });

  it("masks match an unhashed take by path only until its checksum is attached", () => {
    const copy = { path: "/Desktop/copy.mp4", sha256: SHA };
    expect(sameFile({ path: take.path, sha256: "" }, { path: take.path, sha256: SHA })).toBe(true);
    expect(sameFile({ path: take.path, sha256: "" }, copy)).toBe(false);
    expect(sameFile({ path: take.path, sha256: "" }, { path: "/x.mp4", sha256: "" })).toBe(false);
    expect(sameFile({ path: take.path, sha256: SHA }, copy)).toBe(true);
  });
});

describe("camera composite hand-off", () => {
  const result = (over: Partial<RecordingResult> = {}): RecordingResult => ({
    sessionId: `cam-${Math.random()}`,
    path: take.path,
    durationSec: 30,
    mode: "screen-camera",
    tracksDir: "/rec/rec-1/tracks",
    markers: [],
    camera: {
      path: "/rec/rec-1/tracks/camera.mp4",
      offsetSec: 0,
      pipCorner: "top-left",
      pipSize: "small",
    },
    ...over,
  });

  it("plays the screen clip at once and points it at the composite later", async () => {
    ipc.hashMedia.mockResolvedValue(SHA);
    const job = deferred<string>();
    ipc.compositeRecordingCamera.mockImplementation((_req, onStarted) => {
      onStarted("job-1");
      return job.promise;
    });
    const r = result();
    markRecordingStage(r.sessionId, "stopRequested");
    await importFinishedRecording(r);
    expect(ipc.compositeRecordingCamera).toHaveBeenCalledWith(
      {
        tracksDir: "/rec/rec-1/tracks",
        screenPath: take.path,
        pipCorner: "top-left",
        pipSize: "small",
        // Paths the project references: leftover composites among them are never swept.
        keep: [take.path],
      },
      expect.any(Function),
    );
    const id = Object.keys(state().project.media)[0]!;
    expect(state().project.media[id]!.path).toBe(take.path);
    // Saved with the project until the composite is swapped in.
    expect(state().project.media[id]!.pendingCamera).toEqual({
      tracksDir: "/rec/rec-1/tracks",
      pipCorner: "top-left",
      pipSize: "small",
    });
    await vi.waitFor(() => expect(state().project.media[id]!.sha256).toBe(SHA));
    const steps = history().pastStates.length;
    ipc.hashMedia.mockResolvedValue(SHA2);
    job.resolve(composite.path);
    await vi.waitFor(() => expect(state().project.media[id]!.path).toBe(composite.path));
    // The composite's own checksum replaces the screen file's, never reused.
    await vi.waitFor(() => expect(state().project.media[id]!.sha256).toBe(SHA2));
    expect(history().pastStates.length).toBe(steps);
    expect(state().dirty).toBe(true);
    expect(lastToast()).toBe("Camera added to the recording");
    expect(state().project.media[id]!.pendingCamera).toBeUndefined();
    expect(ipc.discardRecordingComposite).not.toHaveBeenCalled();
    expect(recordingTimeline(r.sessionId).cameraComposited).toBeGreaterThanOrEqual(0);
    // Undo history references the composite too: undo never brings back the screen-only file.
    for (const s of history().pastStates)
      if (s.project?.media[id]) expect(s.project.media[id]!.path).toBe(composite.path);
  });

  it("keeps the screen clip when the composite does not line up", async () => {
    ipc.hashMedia.mockResolvedValue(SHA);
    ipc.compositeRecordingCamera.mockResolvedValue(composite.path);
    ipc.probeMedia.mockImplementation(async (path: string) =>
      path === take.path ? { ...take } : { ...composite, duration: 29 },
    );
    await importFinishedRecording(result());
    await vi.waitFor(() => expect(lastToast()).toBe("Camera kept as a separate file"));
    const m = Object.values(state().project.media)[0]!;
    expect(m.path).toBe(take.path);
    // Given up: the marker is cleared and the unused composite deleted.
    expect(m.pendingCamera).toBeUndefined();
    await vi.waitFor(() =>
      expect(ipc.discardRecordingComposite).toHaveBeenCalledWith(composite.path),
    );
  });

  it("refuses a composite that would add sound to a silent hand-off", async () => {
    ipc.hashMedia.mockResolvedValue(SHA);
    ipc.compositeRecordingCamera.mockResolvedValue(composite.path);
    ipc.probeMedia.mockImplementation(async (path: string) =>
      path === take.path ? { ...take, audioSampleRate: 0 } : { ...composite },
    );
    await importFinishedRecording(result());
    await vi.waitFor(() => expect(lastToast()).toBe("Camera kept as a separate file"));
    expect(Object.values(state().project.media)[0]!.path).toBe(take.path);
  });

  it("refuses to move a recording whose screen file another clip also uses", async () => {
    ipc.hashMedia.mockResolvedValue(SHA);
    const job = deferred<string>();
    ipc.compositeRecordingCamera.mockReturnValue(job.promise);
    await importFinishedRecording(result());
    const id = Object.keys(state().project.media)[0]!;
    // The same file imported again as its own media entry (masks match it by path).
    useProjectStore.setState({
      project: {
        ...state().project,
        media: { ...state().project.media, twin: { ...take, id: "twin" } },
      },
    });
    expect(sharesFile(state().project.id, id, take.path)).toBe(true);
    job.resolve(composite.path);
    await vi.waitFor(() => expect(lastToast()).toBe("Camera kept as a separate file"));
    expect(state().project.media[id]!.path).toBe(take.path);
    expect(state().project.media.twin!.path).toBe(take.path);
  });

  it("cancels the job and swaps nothing when the project changes", async () => {
    ipc.hashMedia.mockResolvedValue(SHA);
    const job = deferred<string>();
    ipc.compositeRecordingCamera.mockImplementation((_req, onStarted) => {
      onStarted("job-2");
      return job.promise;
    });
    await importFinishedRecording(result());
    const other = newProject("other");
    useProjectStore.setState({ project: other });
    expect(ipc.cancelJob).toHaveBeenCalledWith("job-2");
    job.reject("cancelled");
    await vi.waitFor(() => expect(lastToast()).toBe("Camera not added yet"));
    expect(state().project).toBe(other);
  });

  it("deletes a composite that finished just after the project changed", async () => {
    ipc.hashMedia.mockResolvedValue(SHA);
    const job = deferred<string>();
    ipc.compositeRecordingCamera.mockReturnValue(job.promise);
    await importFinishedRecording(result());
    useProjectStore.setState({ project: newProject("other") });
    job.resolve(composite.path);
    await vi.waitFor(() =>
      expect(ipc.discardRecordingComposite).toHaveBeenCalledWith(composite.path),
    );
  });

  it("resumes a pending camera saved with the project when it is opened again", async () => {
    ipc.hashMedia.mockResolvedValue(SHA);
    const job = deferred<string>();
    ipc.compositeRecordingCamera.mockReturnValue(job.promise);
    await importFinishedRecording(result());
    // Save (the marker is part of the project JSON) and switch away mid-job.
    const saved = JSON.parse(JSON.stringify(state().project)) as Project;
    useProjectStore.setState({ project: newProject("other") });
    job.reject("cancelled");
    await vi.waitFor(() => expect(lastToast()).toBe("Camera not added yet"));
    // Reopen: the composite runs again, guarded, and swaps.
    ipc.compositeRecordingCamera.mockResolvedValue(composite.path);
    useProjectStore.setState({ project: saved, dirty: false });
    history().clear();
    resumePendingCameras();
    const id = Object.keys(saved.media)[0]!;
    await vi.waitFor(() => expect(state().project.media[id]!.path).toBe(composite.path));
    expect(state().project.media[id]!.pendingCamera).toBeUndefined();
    expect(ipc.compositeRecordingCamera).toHaveBeenLastCalledWith(
      expect.objectContaining({ tracksDir: "/rec/rec-1/tracks", screenPath: take.path }),
      expect.any(Function),
    );
  });

  it("runs one composite per entry even if resumed twice", async () => {
    const job = deferred<string>();
    ipc.compositeRecordingCamera.mockReturnValue(job.promise);
    ipc.hashMedia.mockResolvedValue(SHA);
    await importFinishedRecording(result());
    resumePendingCameras();
    resumePendingCameras();
    expect(ipc.compositeRecordingCamera).toHaveBeenCalledTimes(1);
    job.resolve(composite.path);
    await vi.waitFor(() => expect(lastToast()).toBe("Camera added to the recording"));
  });

  it("waits for playback to pause before switching the clip's file", async () => {
    ipc.hashMedia.mockResolvedValue(SHA);
    ipc.compositeRecordingCamera.mockResolvedValue(composite.path);
    usePlayerStore.getState().setPlaying(true);
    const r = result();
    const pending = importFinishedRecording(r);
    // The append itself pauses playback; play again while the job runs.
    await pending;
    usePlayerStore.getState().setPlaying(true);
    await flush();
    await flush();
    const id = Object.keys(state().project.media)[0]!;
    expect(state().project.media[id]!.path).toBe(take.path);
    usePlayerStore.getState().setPlaying(false);
    await vi.waitFor(() => expect(state().project.media[id]!.path).toBe(composite.path));
  });

  it("does not start a composite for a take without a separate camera", async () => {
    ipc.hashMedia.mockResolvedValue(SHA);
    await importFinishedRecording(result({ camera: undefined, mode: "screen" }));
    expect(ipc.compositeRecordingCamera).not.toHaveBeenCalled();
  });

  it("still tells the user where the camera is when the take could not be inserted", async () => {
    ipc.probeMedia.mockRejectedValue(new Error("probe failed"));
    await importFinishedRecording(result());
    expect(ipc.compositeRecordingCamera).not.toHaveBeenCalled();
    expect(lastToast()).toBe("Camera recording kept");
  });
});

describe("camera composite: interruptions and failures (second review)", () => {
  const result = (): RecordingResult => ({
    sessionId: `cam2-${Math.random()}`,
    path: take.path,
    durationSec: 30,
    mode: "screen-camera",
    tracksDir: "/rec/rec-1/tracks",
    markers: [],
    camera: {
      path: "/rec/rec-1/tracks/camera.mp4",
      offsetSec: 0,
      pipCorner: "top-left",
      pipSize: "small",
    },
  });
  const firstId = () => Object.keys(state().project.media)[0]!;

  it("restarts at once when the project comes back while the cancelled run settles (A -> B -> A)", async () => {
    ipc.hashMedia.mockResolvedValue(SHA);
    const first = deferred<string>();
    ipc.compositeRecordingCamera.mockImplementationOnce((_req, onStarted) => {
      onStarted("job-a");
      return first.promise;
    });
    await importFinishedRecording(result());
    const a = state().project;
    const id = firstId();
    useProjectStore.setState({ project: newProject("b") });
    useProjectStore.setState({ project: a });
    expect(ipc.cancelJob).toHaveBeenCalledWith("job-a");
    // Probe of the reviewer: a resume while the old run settles must not be lost.
    resumePendingCameras();
    expect(ipc.compositeRecordingCamera).toHaveBeenCalledTimes(1);
    ipc.compositeRecordingCamera.mockResolvedValue(composite.path);
    first.reject("cancelled");
    await vi.waitFor(() => expect(ipc.compositeRecordingCamera).toHaveBeenCalledTimes(2));
    await vi.waitFor(() => expect(state().project.media[id]!.path).toBe(composite.path));
    expect(state().project.media[id]!.pendingCamera).toBeUndefined();
  });

  it.each([
    ["cancelled from the Jobs list", "cancelled"],
    ["ffmpeg killed", "ffmpeg: Killed"],
    ["ffprobe failure", "ffprobe failed"],
    ["missing clip file", "the clip's file is missing"],
  ])("keeps the marker after a transient failure (%s)", async (_label, error) => {
    ipc.hashMedia.mockResolvedValue(SHA);
    ipc.compositeRecordingCamera.mockRejectedValue(error);
    await importFinishedRecording(result());
    await vi.waitFor(() => expect(lastToast()).toBe("Camera not added yet"));
    expect(state().project.media[firstId()]!.pendingCamera).toBeDefined();
  });

  it("clears the marker on a definite refusal from Rust", async () => {
    ipc.hashMedia.mockResolvedValue(SHA);
    ipc.compositeRecordingCamera.mockRejectedValue(
      "camera composite refused: the take's tracks folder is gone",
    );
    await importFinishedRecording(result());
    await vi.waitFor(() => expect(lastToast()).toBe("Camera kept as a separate file"));
    expect(state().project.media[firstId()]!.pendingCamera).toBeUndefined();
    expect(useUIStore.getState().toasts.at(-1)?.description).not.toContain("refused:");
  });

  it("does not swap or announce when the insertion was undone meanwhile", async () => {
    ipc.hashMedia.mockResolvedValue(SHA);
    const job = deferred<string>();
    ipc.compositeRecordingCamera.mockReturnValue(job.promise);
    await importFinishedRecording(result());
    const id = firstId();
    history().undo();
    expect(state().project.media[id]).toBeUndefined();
    job.resolve(composite.path);
    await vi.waitFor(() => expect(lastToast()).toBe("Camera not added yet"));
    await vi.waitFor(() =>
      expect(ipc.discardRecordingComposite).toHaveBeenCalledWith(composite.path),
    );
    history().redo();
    expect(state().project.media[id]).toMatchObject({ path: take.path });
    expect(state().project.media[id]!.pendingCamera).toBeDefined();
    expect(useUIStore.getState().toasts.map((t) => t.title)).not.toContain(
      "Camera added to the recording",
    );
  });
});

describe("hand-off guards (pure)", () => {
  it("accepts only a composite with the clip's size and length", () => {
    expect(compositeMismatch(take, { ...composite })).toBeNull();
    expect(compositeMismatch(take, { ...composite, duration: 30.05 })).toBeNull();
    expect(compositeMismatch(take, { ...composite, duration: 29.5 })).toMatch(/length/);
    expect(compositeMismatch(take, { ...composite, width: 1280 })).toMatch(/picture size/);
    expect(compositeMismatch(take, { ...composite, duration: Number.NaN })).toMatch(/length/);
    expect(compositeMismatch(take, { ...composite, audioSampleRate: 0 })).toMatch(/sound/);
    expect(compositeMismatch({ ...take, audioSampleRate: 0 }, composite)).toMatch(/sound/);
  });

  it("refreshes fps and sample rate on a swap and clears the marker; give-up clears it too", () => {
    const pendingCamera = { tracksDir: "/rec/rec-1/tracks" };
    const p = { ...newProject("a"), media: { take: { ...take, pendingCamera } } };
    useProjectStore.setState({ project: p, dirty: false });
    expect(swapToComposite(p.id, "take", take.path, { ...composite, fps: 60 })).toBe(true);
    expect(state().project.media.take).toMatchObject({ path: composite.path, fps: 60, sha256: "" });
    expect(state().project.media.take!.pendingCamera).toBeUndefined();
    useProjectStore.setState({ project: p, dirty: false });
    expect(clearPendingCamera(p.id, "take", take.path)).toBe(true);
    expect(state().project.media.take!.pendingCamera).toBeUndefined();
    expect(state().dirty).toBe(true);
  });

  it("never swaps an entry only undo / redo states hold", () => {
    const p = { ...newProject("a"), media: { take: { ...take } } };
    useProjectStore.setState({ project: p });
    history().clear();
    useProjectStore.setState({ project: { ...p, media: {} } }); // tracked: p is in the past
    expect(swapToComposite(p.id, "take", take.path, composite)).toBe(false);
    expect(history().pastStates.at(-1)?.project?.media.take?.path).toBe(take.path);
  });

  it("swaps only the entry still at the screen file", () => {
    const p = { ...newProject("a"), media: { take: { ...take, path: "/relinked.mp4" } } };
    useProjectStore.setState({ project: p, dirty: false });
    expect(swapToComposite(p.id, "take", take.path, composite)).toBe(false);
    expect(state().dirty).toBe(false);
    expect(swapToComposite("other", "take", "/relinked.mp4", composite)).toBe(false);
  });

  it("resolves an inserted object to its later, rewritten self (and nothing unrelated)", () => {
    const original = { ...take };
    const p = { ...newProject("a"), media: { take: original } };
    useProjectStore.setState({ project: p });
    expect(resolveRecordingSource(p.id, original)).toBe(original);
    attachDeferredChecksum(p.id, "take", take.path, SHA);
    const hashed = state().project.media.take!;
    expect(hashed).not.toBe(original);
    expect(resolveRecordingSource(p.id, original)).toBe(hashed);
    swapToComposite(p.id, "take", take.path, composite);
    expect(resolveRecordingSource(p.id, original)).toBe(state().project.media.take);
    // A relink to an unrelated file (rewritten everywhere, as relink does) is
    // not "the same recording".
    useProjectStore.setState({
      project: { ...state().project, media: { take: { ...take, path: "/unrelated.mp4" } } },
    });
    history().clear();
    expect(resolveRecordingSource(p.id, original)).toBe(original);
  });
});
