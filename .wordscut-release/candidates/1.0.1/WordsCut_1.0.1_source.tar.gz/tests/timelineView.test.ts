import { beforeEach, describe, expect, it } from "vitest";
import {
  DETAILED,
  LANE_IDS,
  resetView,
  resolveVisibleLanes,
  sanitizePrefs,
} from "@/lib/timelineView";
import { TIMELINE_VIEW_KEY, useTimelineViewStore } from "@/stores/timelineViewStore";
import { addMediaWithTranscript, newProject } from "@/lib/edl";
import { useProjectStore } from "@/stores/projectStore";

const media = {
  id: "m",
  path: "/m.mp4",
  duration: 4,
  fps: 25,
  width: 100,
  height: 100,
  audioSampleRate: 8000,
  sha256: "x",
};

describe("timelineView model", () => {
  it("Simple shows zoom only when regions exist; detailed shows everything", () => {
    const simple = resetView();
    expect(resolveVisibleLanes(simple, { clips: true })).toEqual(["clips"]);
    expect(resolveVisibleLanes(simple, { clips: true, zoom: true })).toEqual(["clips", "zoom"]);
    expect(simple.lanes.cutMap).toBe(false);
    expect(simple.lanes.waveform).toBe(true);
    expect(resolveVisibleLanes(DETAILED, {})).toEqual([...LANE_IDS]);
  });

  it("falls back to Simple on malformed stored data", () => {
    expect(sanitizePrefs("junk")).toEqual(resetView());
    expect(sanitizePrefs({ lanes: { clips: false } }).lanes.clips).toBe(false);
  });
});

describe("timelineViewStore", () => {
  beforeEach(() => {
    localStorage.clear();
    useTimelineViewStore.getState().reset();
    useProjectStore.temporal.getState().resume();
    useProjectStore.setState({ project: addMediaWithTranscript(newProject("v"), media, []) });
    useProjectStore.temporal.getState().clear();
  });

  it("any manual toggle switches to custom and persists", () => {
    useTimelineViewStore.getState().setLane("zoom", false);
    const { prefs } = useTimelineViewStore.getState();
    expect(prefs.preset).toBe("custom");
    expect(JSON.parse(localStorage.getItem(TIMELINE_VIEW_KEY)!).lanes.zoom).toBe(false);
  });

  it("hide empty / show populated / reset", () => {
    const s = useTimelineViewStore.getState();
    s.setPreset("detailed");
    s.setHideEmpty(true);
    expect(resolveVisibleLanes(useTimelineViewStore.getState().prefs, { clips: true })).toEqual([
      "clips",
    ]);
    s.showPopulated({ clips: true, chapters: true });
    const p = useTimelineViewStore.getState().prefs;
    expect(LANE_IDS.filter((i) => p.lanes[i])).toEqual(["clips", "chapters"]);
    s.reset();
    expect(useTimelineViewStore.getState().prefs).toEqual(resetView());
  });

  it("changing the view creates no undo step and leaves the project untouched", () => {
    const before = useProjectStore.getState().project;
    const s = useTimelineViewStore.getState();
    s.setPreset("detailed");
    s.setLane("clips", false);
    s.setHideEmpty(true);
    s.reset();
    expect(useProjectStore.temporal.getState().pastStates).toHaveLength(0);
    expect(useProjectStore.getState().project).toBe(before);
  });
});
