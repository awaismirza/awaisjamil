import { describe, expect, it } from "vitest";
import type { RecordOptions, RecordingDevices } from "@/lib/ipc";
import {
  areaFromDrag,
  clampArea,
  deviceChanges,
  effectiveSource,
  isValidArea,
  matchWebDevice,
  micLevel,
  modeFor,
  permissionIssues,
  requiredPermissions,
  startBlocker,
  toStartOptions,
  uiModeOf,
} from "@/lib/recorderSetup";

const native: RecordingDevices = {
  backend: "native",
  video: [
    { index: 1000, name: "Built-in Display", isScreen: true },
    { index: 1001, name: "FaceTime HD Camera", isScreen: false },
  ],
  audio: [{ index: 1000, name: "MacBook Pro Microphone" }],
  windows: [{ id: 42, title: "Doc", app: "Pages" }],
  displays: [{ index: 1000, width: 1000, height: 600 }],
  permissions: {
    screenRecording: "granted",
    camera: "granted",
    microphone: "granted",
    inputMonitoring: "notDetermined",
  },
};
const ffmpeg: RecordingDevices = {
  ...native,
  backend: "ffmpeg",
  windows: [],
  displays: [],
  permissions: null,
};
const screen: RecordOptions = { mode: "screen", screenIndex: 1000, audioIndex: 1000 };

describe("mode mapping", () => {
  it("maps the three UI modes onto the four recorder modes", () => {
    expect(uiModeOf("screen")).toBe("screen");
    expect(uiModeOf("screen-camera")).toBe("screen");
    expect(uiModeOf("camera")).toBe("camera");
    expect(uiModeOf("voiceover")).toBe("audio");
    expect(modeFor("screen", true)).toBe("screen-camera");
    expect(modeFor("screen", false)).toBe("screen");
    expect(modeFor("camera", true)).toBe("camera");
    expect(modeFor("audio", false)).toBe("voiceover");
  });
});

describe("source selection", () => {
  it("window and area need the native recorder", () => {
    expect(effectiveSource({ ...screen, sourceKind: "area" }, native)).toBe("area");
    expect(effectiveSource({ ...screen, sourceKind: "area" }, ffmpeg)).toBe("display");
    expect(effectiveSource(screen, native)).toBe("display");
  });

  it("sends only the fields of the chosen source", () => {
    const stale: RecordOptions = {
      ...screen,
      windowId: 42,
      area: { x: 0, y: 0, width: 100, height: 100 },
    };
    expect(toStartOptions({ ...stale, sourceKind: "display" }, native)).toEqual(screen);
    expect(toStartOptions({ ...stale, sourceKind: "window" }, native)).toEqual({
      ...screen,
      windowId: 42,
    });
    expect(toStartOptions({ ...stale, sourceKind: "area" }, native).area).toEqual(stale.area);
    expect(toStartOptions({ ...stale, sourceKind: "area" }, native).windowId).toBeUndefined();
    // The ffmpeg backend can only record a display.
    expect(toStartOptions({ ...stale, sourceKind: "window" }, ffmpeg)).toEqual(screen);
  });

  it("drops screen-only options for camera and voice-over takes", () => {
    const out = toStartOptions(
      { mode: "camera", cameraIndex: 1001, systemAudio: true, windowId: 42, sourceKind: "window" },
      native,
    );
    expect(out).toEqual({ mode: "camera", cameraIndex: 1001 });
  });
});

describe("key identity options", () => {
  it("are sent only when opted in, natively, for a screen take; the second needs the first", () => {
    const on = { ...screen, recordKeyIdentity: true, recordAllCharacters: true };
    expect(toStartOptions(on, native)).toMatchObject({
      recordKeyIdentity: true,
      recordAllCharacters: true,
    });
    const out = toStartOptions({ ...screen, recordAllCharacters: true }, native);
    expect(out.recordKeyIdentity).toBeUndefined();
    expect(out.recordAllCharacters).toBeUndefined();
    expect(toStartOptions(screen, native).recordKeyIdentity).toBeUndefined();
    expect(toStartOptions(on, ffmpeg).recordKeyIdentity).toBeUndefined();
    const cam = toStartOptions({ ...on, mode: "camera", cameraIndex: 1001 }, native);
    expect(cam.recordKeyIdentity).toBeUndefined();
  });
});

describe("permissions", () => {
  it("lists what each mode needs", () => {
    expect(requiredPermissions(screen)).toEqual(["screenRecording", "microphone"]);
    expect(requiredPermissions({ mode: "camera", cameraIndex: 1001 })).toEqual(["camera"]);
    expect(requiredPermissions({ mode: "voiceover" })).toEqual(["microphone"]);
  });

  it("reports only ungranted, required, native permissions", () => {
    const d = {
      ...native,
      permissions: { screenRecording: "denied", microphone: "granted" },
    } as RecordingDevices;
    expect(permissionIssues(screen, d)).toEqual([{ kind: "screenRecording", state: "denied" }]);
    expect(permissionIssues(screen, ffmpeg)).toEqual([]);
  });
});

describe("startBlocker", () => {
  it("is null for a valid display take", () => {
    expect(startBlocker(screen, native, null)).toBeNull();
  });

  it("explains loading and errors", () => {
    expect(startBlocker(screen, null, null)).toMatch(/looking/i);
    expect(startBlocker(screen, null, "boom")).toMatch(/could not be read/i);
  });

  it("asks for a window or an area before allowing Start", () => {
    expect(startBlocker({ ...screen, sourceKind: "window" }, native, null)).toMatch(/window/i);
    expect(
      startBlocker({ ...screen, sourceKind: "window", windowId: 42 }, native, null),
    ).toBeNull();
    expect(startBlocker({ ...screen, sourceKind: "window", windowId: 7 }, native, null)).toMatch(
      /window/i,
    );
    expect(startBlocker({ ...screen, sourceKind: "area" }, native, null)).toMatch(/area/i);
    const ok = {
      ...screen,
      sourceKind: "area" as const,
      area: { x: 10, y: 10, width: 200, height: 100 },
    };
    expect(startBlocker(ok, native, null)).toBeNull();
    expect(
      startBlocker({ ...ok, area: { x: 900, y: 10, width: 200, height: 100 } }, native, null),
    ).toMatch(/area/i);
  });

  it("blocks on a missing camera, a missing mic for audio, and denied permissions", () => {
    const noCam = { ...native, video: native.video.filter((v) => v.isScreen) };
    expect(startBlocker({ mode: "camera", cameraIndex: 1001 }, noCam, null)).toMatch(/no camera/i);
    expect(startBlocker({ mode: "voiceover" }, native, null)).toMatch(/microphone/i);
    expect(startBlocker({ mode: "voiceover" }, { ...native, audio: [] }, null)).toMatch(
      /no microphone/i,
    );
    const denied = {
      ...native,
      permissions: { ...native.permissions, screenRecording: "denied" },
    } as RecordingDevices;
    expect(startBlocker(screen, denied, null)).toMatch(/Screen Recording/);
  });

  it("does not block on a permission that was never asked (Start asks)", () => {
    const fresh = {
      ...native,
      permissions: { ...native.permissions, screenRecording: "notDetermined" },
    } as RecordingDevices;
    expect(startBlocker(screen, fresh, null)).toBeNull();
  });

  it("blocks when the selected microphone vanished", () => {
    expect(startBlocker({ ...screen, audioIndex: 1005 }, native, null)).toMatch(/microphone/i);
  });
});

describe("capture area", () => {
  const display = { index: 1000, width: 1000, height: 600 };

  it("turns a drag into display points in any direction, clamped to the preview", () => {
    expect(areaFromDrag({ x: 0.1, y: 0.2 }, { x: 0.6, y: 0.7 }, display)).toEqual({
      x: 100,
      y: 120,
      width: 500,
      height: 300,
    });
    expect(areaFromDrag({ x: 0.6, y: 0.7 }, { x: 0.1, y: 0.2 }, display)).toEqual({
      x: 100,
      y: 120,
      width: 500,
      height: 300,
    });
    expect(areaFromDrag({ x: -1, y: -1 }, { x: 2, y: 2 }, display)).toEqual({
      x: 0,
      y: 0,
      width: 1000,
      height: 600,
    });
  });

  it("validates size and bounds like the Rust side", () => {
    expect(isValidArea({ x: 0, y: 0, width: 31, height: 100 }, display)).toBe(false);
    expect(isValidArea({ x: 0, y: 0, width: 1000, height: 600 }, display)).toBe(true);
    expect(isValidArea({ x: 1, y: 0, width: 1000, height: 600 }, display)).toBe(false);
    expect(isValidArea({ x: 0, y: 0, width: Number.NaN, height: 100 }, display)).toBe(false);
    expect(isValidArea(undefined, display)).toBe(false);
  });

  it("clamps typed values back inside the display", () => {
    expect(clampArea({ x: 990, y: -5, width: 5000, height: 10 }, display)).toEqual({
      x: 0,
      y: 0,
      width: 1000,
      height: 32,
    });
    expect(clampArea({ x: 900, y: 0, width: 300, height: 100 }, display)).toEqual({
      x: 700,
      y: 0,
      width: 300,
      height: 100,
    });
  });
});

describe("deviceChanges", () => {
  it("reports devices that disappeared, matched by name", () => {
    const next = { ...native, video: [native.video[0]], audio: [] };
    expect(
      deviceChanges({ ...screen, mode: "screen-camera", cameraIndex: 1001 }, native, next),
    ).toEqual([
      "Camera “FaceTime HD Camera” was disconnected.",
      "Microphone “MacBook Pro Microphone” was disconnected.",
    ]);
  });

  it("is quiet on the first listing and when indices merely shift", () => {
    expect(deviceChanges(screen, null, native)).toEqual([]);
    const shifted = { ...native, audio: [{ index: 1003, name: "MacBook Pro Microphone" }] };
    expect(deviceChanges(screen, native, shifted)).toEqual([]);
  });
});

describe("preview helpers", () => {
  it("matches browser devices to recorder names", () => {
    const list = [{ label: "" }, { label: "FaceTime HD Camera (05ac:8514)" }, { label: "Other" }];
    expect(matchWebDevice(list, "FaceTime HD Camera")?.label).toContain("FaceTime");
    expect(matchWebDevice(list, "Nope")).toBeUndefined();
    expect(matchWebDevice(list, undefined)).toBeUndefined();
  });

  it("measures loudness from 8-bit samples", () => {
    expect(micLevel([])).toBe(0);
    expect(micLevel(new Uint8Array(64).fill(128))).toBe(0);
    expect(micLevel(Uint8Array.from({ length: 64 }, (_, i) => (i % 2 ? 255 : 1)))).toBe(1);
    const quiet = micLevel(Uint8Array.from({ length: 64 }, (_, i) => (i % 2 ? 136 : 120)));
    expect(quiet).toBeGreaterThan(0);
    expect(quiet).toBeLessThan(0.5);
  });
});
