import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@tauri-apps/plugin-dialog", () => ({ open: vi.fn() }));

import { ScenePanel } from "@/components/editor/sidebar/panels/ScenePanel";
import { MusicTracksDialog } from "@/components/Toolbox/MusicTracksDialog";
import { addMediaWithTranscript, newProject, type AudioTrack } from "@/lib/edl";
import { useProjectStore } from "@/stores/projectStore";

const media = (id: string, path: string) => ({
  id,
  path,
  duration: 20,
  width: 1920,
  height: 1080,
  fps: 30,
  audioSampleRate: 48000,
  sha256: id,
});

beforeEach(() => {
  const p = addMediaWithTranscript(newProject("t"), media("m", "/tmp/demo.mp4"), [
    { id: "w0", text: "hi", start: 0, end: 0.5, confidence: 1 },
  ]);
  p.media["bed"] = media("bed", "/tmp/bed.m4a");
  p.audioTracks = [{ id: "t1", mediaId: "bed", gainDb: 0, offsetSec: 0, ducks: false }];
  useProjectStore.setState({ project: p, dirty: false });
  useProjectStore.temporal.getState().clear();
});
afterEach(cleanup);

const past = () => useProjectStore.temporal.getState().pastStates.length;
const track = () => useProjectStore.getState().project.audioTracks?.[0] as AudioTrack;

describe("slider drags are one undo step", () => {
  it("scene padding commits once on release", () => {
    render(<ScenePanel />);
    const padding = screen.getByText("Padding").closest("label")!.querySelector("input")!;
    for (const v of ["2", "5", "9"]) fireEvent.change(padding, { target: { value: v } });
    expect(past()).toBe(0);
    expect(screen.getByText("9%")).toBeTruthy();
    fireEvent.pointerUp(padding);
    expect(useProjectStore.getState().project.scene?.paddingPct).toBe(9);
    expect(past()).toBe(1);
  });

  it("music gain commits once on release, fades once on blur", () => {
    render(<MusicTracksDialog open onOpenChange={() => {}} />);
    const gain = screen.getByRole("slider", { name: /gain/i });
    for (const v of ["-1", "-3", "-6"]) fireEvent.change(gain, { target: { value: v } });
    expect(track().gainDb).toBe(0);
    expect(screen.getByText("-6.0 dB")).toBeTruthy();
    fireEvent.pointerUp(gain);
    expect(track().gainDb).toBe(-6);
    expect(past()).toBe(1);

    const fadeIn = screen.getByRole("spinbutton", { name: /fade in/i });
    for (const v of ["1", "1.", "1.5"]) fireEvent.change(fadeIn, { target: { value: v } });
    expect(track().fadeInSec).toBeUndefined();
    fireEvent.blur(fadeIn);
    expect(track().fadeInSec).toBe(1.5);
    expect(past()).toBe(2);
  });
});
