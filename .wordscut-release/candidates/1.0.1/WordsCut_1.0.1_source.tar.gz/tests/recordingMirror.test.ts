import { beforeEach, describe, expect, it, vi } from "vitest";
import {
  derivePhase,
  idleSnapshot,
  importFinishedRecording,
  useRecordingStore,
} from "@/stores/recordingStore";
import * as ipc from "@/lib/ipc";

vi.mock("@/lib/ipc", async (original) => ({
  ...(await original<typeof import("@/lib/ipc")>()),
  ackRecordingResult: vi.fn(async () => {}),
  probeMedia: vi.fn(async () => {
    throw new Error("probe failed");
  }),
}));

const snap = (revision: number, over: Partial<ipc.RecordingSnapshot> = {}) => ({
  ...idleSnapshot(revision),
  ...over,
});

beforeEach(() => {
  useRecordingStore.setState({
    phase: "idle",
    session: idleSnapshot(),
    sessionId: null,
    revision: 0,
    local: null,
    elapsedSec: 0,
    markers: [],
  });
});

describe("snapshot mirror", () => {
  it("keeps the newest revision when the initial fetch races an event", () => {
    const { applySnapshot } = useRecordingStore.getState();
    // The event (rev 5) lands first; the slower initial fetch (rev 3) must not win.
    expect(applySnapshot(snap(5, { sessionId: "a", phase: "recording", elapsedSec: 9 }))).toBe(
      true,
    );
    expect(applySnapshot(snap(3, { sessionId: "a", phase: "starting" }))).toBe(false);
    expect(useRecordingStore.getState().phase).toBe("recording");
    expect(useRecordingStore.getState().elapsedSec).toBe(9);
  });

  it("ignores a duplicate revision", () => {
    const { applySnapshot } = useRecordingStore.getState();
    applySnapshot(snap(2, { sessionId: "a", phase: "recording" }));
    expect(applySnapshot(snap(2, { sessionId: "a", phase: "paused" }))).toBe(false);
    expect(useRecordingStore.getState().phase).toBe("recording");
  });

  it("maps every Rust phase to a UI phase", () => {
    const phases = {
      starting: "countdown",
      recording: "recording",
      paused: "paused",
      interrupted: "paused",
      finalizing: "finalizing",
      idle: "idle",
    } as const;
    for (const [rust, ui] of Object.entries(phases))
      expect(derivePhase(snap(1, { phase: rust as ipc.SessionPhase }), null)).toBe(ui);
    expect(derivePhase(snap(1), "processing")).toBe("processing");
  });

  it("shows processing only while Rust is idle", () => {
    useRecordingStore.setState({ local: "processing", phase: "processing" });
    useRecordingStore
      .getState()
      .applySnapshot(snap(1, { sessionId: "n", phase: "recording" }));
    expect(useRecordingStore.getState().phase).toBe("recording");
  });
});

describe("import ownership", () => {
  it("imports a finished session once even if the event and the pending list both deliver it", async () => {
    const result: ipc.RecordingResult = {
      sessionId: "done-1",
      path: "/tmp/x.mp4",
      durationSec: 1,
      mode: "screen",
      markers: [],
    };
    await importFinishedRecording(result);
    await importFinishedRecording(result);
    expect(ipc.probeMedia).toHaveBeenCalledTimes(1);
    expect(ipc.ackRecordingResult).toHaveBeenCalledWith("done-1");
    expect(useRecordingStore.getState().phase).toBe("idle");
  });
});
