import { describe, expect, it } from "vitest";
import { cursorAt, parseCursorLog, sanitizeCursorTrack, smoothCursorTrack } from "@/lib/cursor";
import { cursorFixtureKinds, syntheticCursorLog } from "./fixtures/cursorLogs";
const log = (...events: object[]) => events.map((e) => JSON.stringify(e)).join("\n");
describe("cursor log", () => {
  it("ignores malformed, negative/nonfinite times and future events; sorts and clamps", () => {
    const t = parseCursorLog(
      "bad\nnull\n\n" +
        log(
          { type: "move", t: 2, x: 9, y: -3 },
          { type: "future", t: 0 },
          { type: "move", t: -1, x: 0, y: 0 },
          { type: "move", t: 1, x: 0.2, y: 0.4 },
          { type: "move", t: 3, x: "a", y: 0 },
          { type: "key", t: 4, key: "SECRET", mods: ["cmd", "bad"] },
        ) +
        '\n{"type":',
    );
    expect(t.points.map((p) => p.t)).toEqual([1, 2]);
    expect(t.points[1]).toMatchObject({ x: 1, y: 0 });
    expect(t.events.at(-1)).toEqual({ type: "key", t: 4, mods: ["cmd"] });
  });
  it("interpolates, resolves ties to the final position, holds ends, and handles empty data", () => {
    const t = parseCursorLog(
      log(
        { type: "move", t: 1, x: 0, y: 0 },
        { type: "down", t: 1, x: 0.2, y: 0.2, button: "left" },
        { type: "move", t: 3, x: 0.8, y: 1 },
      ),
    );
    expect(cursorAt(t, 0)).toBeNull();
    expect(cursorAt(t, 2)?.x).toBeCloseTo(0.5);
    expect(cursorAt(t, 5)?.x).toBe(0.8);
    expect(cursorAt(t, NaN)).toBeNull();
    expect(cursorAt(parseCursorLog(""), 3)).toBeNull();
  });
  it("holds visibility until an actual boundary event", () => {
    const t = parseCursorLog(
      log(
        { type: "move", t: 0, x: 0.5, y: 0.5 },
        { type: "move", t: 2, x: 1, y: 1, outside: true },
        { type: "move", t: 4, x: 0.2, y: 0.5 },
      ),
    );
    expect(cursorAt(t, 1)).toMatchObject({ outside: false, x: 0.5 });
    expect(cursorAt(t, 3)?.outside).toBe(true);
    expect(cursorAt(t, 4)?.outside).toBe(false);
  });
  it("smooths jitter deterministically, preserves endpoints and stays within input bounds", () => {
    const t = parseCursorLog(syntheticCursorLog("clicks"));
    const s = smoothCursorTrack(t);
    const variation = (p: typeof t.points) =>
      p.slice(1).reduce((v, x, i) => v + Math.abs(x.x - p[i].x), 0);
    expect(variation(s.points)).toBeLessThan(variation(t.points) / 2);
    expect(s.points[0]).toEqual(t.points[0]);
    expect(s.points.at(-1)).toEqual(t.points.at(-1));
    const xs = t.points.map((p) => p.x),
      ys = t.points.map((p) => p.y);
    for (const p of s.points) {
      expect(p.x).toBeGreaterThanOrEqual(Math.min(...xs) - 1e-10);
      expect(p.x).toBeLessThanOrEqual(Math.max(...xs) + 1e-10);
      expect(p.y).toBeGreaterThanOrEqual(Math.min(...ys) - 1e-10);
      expect(p.y).toBeLessThanOrEqual(Math.max(...ys) + 1e-10);
    }
    expect(s).toEqual(smoothCursorTrack(t));
    expect(t).toEqual(parseCursorLog(syntheticCursorLog("clicks")));
  });
  it("does not smooth across a brief excursion outside the capture", () => {
    const t = parseCursorLog(
      log(
        ...[0, 0.02, 0.04, 0.06, 0.08, 0.1].map((time, i) => ({
          type: "move",
          t: time,
          x: i === 2 ? 1 : 0.2,
          y: 0.3,
          outside: i === 2,
        })),
      ),
    );
    const s = smoothCursorTrack(t, 0.1);
    for (const p of s.points) if (!p.outside) expect(p.x).toBeCloseTo(0.2);
  });
  it.each(cursorFixtureKinds)("processes the %s fixture and validates saved tracks", (kind) => {
    const t = parseCursorLog(syntheticCursorLog(kind));
    expect(t.header?.version).toBe(1);
    expect(sanitizeCursorTrack(JSON.parse(JSON.stringify(t)))).toEqual(t);
    expect(sanitizeCursorTrack({ points: [{ t: 0, x: 99, y: 4 }] }).points).toEqual([]);
  });
});
