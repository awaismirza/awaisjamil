/** Reproducible version-1 logs, also importable by the dev-fixture script. */
const header = {
  type: "header",
  version: 1,
  display: { width: 1920, height: 1080, scale: 2 },
  captured: { x: 0, y: 0, width: 1920, height: 1080 },
  target: "display",
};
export function syntheticCursorLog(
  kind: "clicks" | "typing" | "idle" | "flicks" | "outside" = "clicks",
): string {
  const events: object[] = [header];
  for (let i = 0; i <= 600; i++) {
    if (kind === "idle" && i > 0) continue;
    const t = i / 30;
    const outside = kind === "outside" && t >= 5 && t < 10;
    const x = kind === "flicks" ? (i % 30) / 29 : 0.35 + 0.012 * Math.sin(i * 2);
    events.push({ type: "move", t, x: outside ? 1 : x, y: 0.4 + 0.008 * Math.cos(i), outside });
  }
  if (kind !== "idle") {
    for (const t of [2, 2.2, 2.5, 6, 6.2, 13, 13.3]) {
      events.push({
        type: "down",
        t,
        x: kind === "flicks" ? t % 1 : kind === "outside" && t < 10 && t > 5 ? 1 : 0.35,
        y: 0.4,
        outside: kind === "outside" && t >= 5 && t < 10,
        button: "left",
      });
      events.push({ type: "up", t: t + 0.08, x: 0.35, y: 0.4, button: "left" });
    }
  }
  if (kind === "typing") for (let i = 0; i < 12; i++) events.push({ type: "key", t: 9 + i * 0.12 });
  return events.map((e) => JSON.stringify(e)).join("\n") + "\n";
}
export const cursorFixtureKinds = ["clicks", "typing", "idle", "flicks", "outside"] as const;
