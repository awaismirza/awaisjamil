// Generates tests/fixtures/maskSpansParity.json: 400 seeded random timelines
// (speed, freeze frames, the same file under two media ids, files without a
// checksum) with privacy masks and the spans masks.ts derives for them.
// `tests/masks.test.ts` re-runs this and must get the file back unchanged;
// `layers_export.rs` must derive the same spans from it (TS-vs-Rust parity).
// Regenerate: WRITE_PARITY=1 npx vite-node tests/fixtures/maskSpansParity.gen.ts
import { computeTimeline, type Project } from "../../src/lib/edl";
import { maskOutputSpans, sanitizeMasks } from "../../src/lib/masks";

function mulberry32(seed: number) {
  return () => {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const r3 = (n: number) => Math.round(n * 1000) / 1000;

export function generateMaskSpanCases(count = 400) {
  const rnd = mulberry32(4243);
  const pick = <T>(xs: readonly T[]) => xs[Math.floor(rnd() * xs.length)]!;
  const media = (id: string, path: string, sha256: string) => ({
    id,
    path,
    sha256,
    duration: 30,
    fps: 30,
    width: 640,
    height: 360,
    audioSampleRate: 48000,
  });
  const cases = [];
  for (let i = 0; i < count; i++) {
    const m2Path = pick(["/a.mp4", "/b.mp4"]);
    const project = {
      version: 1,
      id: `p${i}`,
      name: "parity",
      createdAt: "",
      updatedAt: "",
      media: {
        m1: media("m1", "/a.mp4", "a".repeat(64)),
        m2: media("m2", m2Path, pick(["", "a".repeat(64), "b".repeat(64)])),
        m3: media("m3", "/c.mp4", "c".repeat(64)),
      },
      segments: Array.from({ length: 1 + Math.floor(rnd() * 5) }, (_, k) => {
        const sourceIn = r3(rnd() * 20);
        const seg: Record<string, unknown> = {
          id: `s${k}`,
          mediaId: pick(["m1", "m2", "m3"]),
          sourceIn,
          sourceOut: r3(sourceIn + 0.05 + rnd() * 5),
          words: [],
        };
        const speed = pick([1, 1, 0.5, 2, 4, 1.5]);
        if (speed !== 1) seg.speed = speed;
        if (rnd() < 0.3) seg.holdSec = r3(0.5 + rnd() * 1.5);
        return seg;
      }),
      settings: { exportPreset: "youtube-1080p", paddingMs: 0 },
      masks: Array.from({ length: 1 + Math.floor(rnd() * 3) }, (_, k) => {
        const srcStart = r3(rnd() * 22);
        return {
          id: `k${k}`,
          mediaId: pick(["m1", "m2", "m3"]),
          srcStart,
          srcEnd: r3(srcStart + pick([0.001, 0.01, 0.07, 1, 3, 6])),
        };
      }),
    };
    const p = project as unknown as Project;
    const tl = computeTimeline(p);
    const expected = sanitizeMasks(project.masks).map((m) => maskOutputSpans(tl, m, p.media));
    cases.push({ project, expected });
  }
  return cases;
}

if (process.env.WRITE_PARITY) {
  const { writeFileSync } = await import("node:fs");
  writeFileSync(
    new URL("./maskSpansParity.json", import.meta.url),
    JSON.stringify(generateMaskSpanCases()) + "\n",
  );
}
