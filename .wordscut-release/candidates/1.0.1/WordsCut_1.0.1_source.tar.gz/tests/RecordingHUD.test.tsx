import { act, cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { RecordingHUD } from "@/components/Recorder/RecordingHUD";
import { runRecorderAction, useRecordingStore } from "@/stores/recordingStore";
import { useSettingsStore } from "@/stores/settingsStore";
import { defaultSettings } from "@/lib/settings";
vi.mock("@/hooks/useShortcutLabel", () => ({ useShortcutLabel: () => "Shortcut" }));
vi.mock("@/stores/recordingStore", async () => {
  const { create } = await import("zustand");
  return {
    useRecordingStore: create(() => ({
      phase: "recording",
      opts: { mode: "camera" },
      countdown: 3,
      elapsedSec: 10,
      markers: [],
      cancel: vi.fn(),
    })),
    runRecorderAction: vi.fn(),
  };
});
beforeEach(() => {
  vi.clearAllMocks();
  vi.stubGlobal("innerWidth", 1000);
  vi.stubGlobal("innerHeight", 600);
  vi.stubGlobal(
    "PointerEvent",
    class extends MouseEvent {
      pointerId: number;
      constructor(type: string, options: MouseEventInit & { pointerId?: number } = {}) {
        super(type, options);
        this.pointerId = options.pointerId ?? 1;
      }
    },
  );
  vi.spyOn(globalThis.HTMLElement.prototype, "getBoundingClientRect").mockReturnValue({
    width: 360,
    height: 40,
    left: 0,
    top: 0,
    right: 360,
    bottom: 40,
    x: 0,
    y: 0,
    toJSON: () => ({}),
  });
  globalThis.HTMLElement.prototype.setPointerCapture = vi.fn();
  useSettingsStore.setState(defaultSettings());
  useRecordingStore.setState({
    phase: "recording",
    countdown: 3,
    opts: { mode: "camera", fps: 30, pipCorner: "bottom-right", pipSize: "medium" },
  });
});
afterEach(() => {
  cleanup();
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
});
describe("recording HUD", () => {
  it.each(["recording", "paused", "finalizing", "processing"] as const)(
    "hides both screen capture modes during %s",
    (phase) => {
      for (const mode of ["screen", "screen-camera"] as const) {
        useRecordingStore.setState({ phase, opts: { ...useRecordingStore.getState().opts, mode } });
        const view = render(<RecordingHUD />);
        expect(screen.queryByRole("status")).not.toBeInTheDocument();
        expect(
          screen.queryByRole("button", { name: "Hide recording controls" }),
        ).not.toBeInTheDocument();
        view.unmount();
      }
    },
  );

  it("shows cancellable startup only for non-screen capture", () => {
    useRecordingStore.setState({ phase: "countdown", countdown: 0 });
    const view = render(<RecordingHUD />);
    expect(screen.getByRole("status", { name: "Starting capture" })).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "Cancel capture startup" }));
    expect(useRecordingStore.getState().cancel).toHaveBeenCalledOnce();
    act(() => {
      useRecordingStore.setState({
        opts: { ...useRecordingStore.getState().opts, mode: "screen" },
      });
    });
    view.rerender(<RecordingHUD />);
    expect(screen.queryByRole("status")).not.toBeInTheDocument();
  });

  it("honors showHUD and only displays a positive countdown", () => {
    useRecordingStore.setState({ phase: "countdown", countdown: 0 });
    const view = render(<RecordingHUD />);
    expect(screen.queryByText("Recording starts… click to cancel")).not.toBeInTheDocument();
    act(() => {
      useRecordingStore.setState({ countdown: 2 });
    });
    view.rerender(<RecordingHUD />);
    expect(screen.getByText("2")).toBeInTheDocument();
    fireEvent.click(screen.getByTitle("Click to cancel countdown"));
    expect(useRecordingStore.getState().cancel).toHaveBeenCalledOnce();
    act(() => {
      useSettingsStore.getState().setRecording({ showHUD: false });
    });
    view.rerender(<RecordingHUD />);
    expect(view.container).toBeEmptyDOMElement();
  });

  it("hides camera/audio controls without cancelling the take", () => {
    useRecordingStore.setState({
      opts: { ...useRecordingStore.getState().opts, mode: "voiceover" },
    });
    render(<RecordingHUD />);
    fireEvent.click(screen.getByRole("button", { name: "Hide recording controls" }));
    expect(useSettingsStore.getState().recording.showHUD).toBe(false);
    expect(useRecordingStore.getState().cancel).not.toHaveBeenCalled();
    expect(runRecorderAction).not.toHaveBeenCalled();
    expect(screen.queryByRole("status")).not.toBeInTheDocument();
  });

  it("routes pause, markers, restart, stop and discard through the dispatcher", () => {
    render(<RecordingHUD />);
    for (const name of [
      "Pause recording",
      "Mark a moment",
      "Restart recording",
      "Stop recording",
      "Discard recording",
    ]) {
      fireEvent.click(screen.getByRole("button", { name }));
    }
    expect(vi.mocked(runRecorderAction).mock.calls.map((call) => call[0])).toEqual([
      "pause",
      "mark",
      "rerecord",
      "record",
      "cancel",
    ]);
    expect(useRecordingStore.getState().cancel).not.toHaveBeenCalled();
  });

  it("moves by ten pixels with keyboard and resets to the top centre", () => {
    render(<RecordingHUD />);
    const grip = screen.getByRole("button", { name: "Move recording controls" });
    const hud = screen.getByRole("status");
    expect(hud.style.left).toBe("320px");
    expect(hud.style.top).toBe("8px");
    fireEvent.keyDown(grip, { key: "ArrowRight" });
    expect(parseFloat(hud.style.left)).toBeCloseTo(330);
    fireEvent.keyDown(grip, { key: "ArrowDown" });
    expect(parseFloat(hud.style.top)).toBeCloseTo(18);
    fireEvent.doubleClick(grip);
    expect(useSettingsStore.getState().recording.hudPosition).toEqual({ x: 0.5, y: 0 });
    expect(hud.style.left).toBe("320px");
  });

  it("keeps pointer drafts local, clamps them, and persists once on release", () => {
    render(<RecordingHUD />);
    const grip = screen.getByRole("button", { name: "Move recording controls" });
    fireEvent.pointerDown(grip, { button: 0, pointerId: 4, clientX: 320, clientY: 8 });
    fireEvent.pointerMove(grip, { pointerId: 4, clientX: 3000, clientY: 3000 });
    expect(useSettingsStore.getState().recording.hudPosition).toBeUndefined();
    expect(screen.getByRole("status").style.left).toBe("632px");
    expect(screen.getByRole("status").style.top).toBe("552px");
    fireEvent.pointerUp(grip, { pointerId: 4 });
    expect(useSettingsStore.getState().recording.hudPosition).toEqual({ x: 1, y: 1 });
    vi.stubGlobal("innerWidth", 600);
    vi.stubGlobal("innerHeight", 300);
    fireEvent(window, new Event("resize"));
    expect(screen.getByRole("status").style.left).toBe("232px");
    expect(screen.getByRole("status").style.top).toBe("252px");
  });

  it("cancels lost pointer capture without persisting a moved draft", () => {
    render(<RecordingHUD />);
    const grip = screen.getByRole("button", { name: "Move recording controls" });
    fireEvent.pointerDown(grip, { button: 0, pointerId: 1, clientX: 320, clientY: 8 });
    fireEvent.pointerMove(grip, { pointerId: 1, clientX: 400, clientY: 40 });
    fireEvent.lostPointerCapture(grip, { pointerId: 1 });
    expect(useSettingsStore.getState().recording.hudPosition).toBeUndefined();
    expect(screen.getByRole("status").style.left).toBe("320px");
  });
});
