import { describe, expect, it } from "vitest";
import { PANELS } from "@/components/editor/sidebar/registry";
import { DEFAULT_PANEL } from "@/stores/editorUiStore";

describe("panel registry", () => {
  it("has unique panel ids", () => {
    const ids = PANELS.map((p) => p.id);
    expect(new Set(ids).size).toBe(ids.length);
  });

  it("lists every panel in rail order, with no workspace modes", () => {
    expect(PANELS.map((p) => p.id)).toEqual([
      "media",
      "transcribe",
      "cleanup",
      "chapters",
      "zoom",
      "timing",
      "look",
      "captions",
      "overlays",
      "find",
      "edit-tools",
      "music",
      "export",
      "settings",
    ]);
  });

  it("pins Settings to the bottom of the rail", () => {
    expect(PANELS.filter((p) => p.placement === "bottom").map((p) => p.id)).toEqual(["settings"]);
  });

  it("the default panel exists", () => {
    expect(PANELS.some((p) => p.id === DEFAULT_PANEL)).toBe(true);
  });
});
