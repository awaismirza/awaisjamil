import { act, cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { RecorderDialog } from "@/components/Recorder/RecorderDialog";
import { defaultSettings } from "@/lib/settings";
import type { RecordingDevices } from "@/lib/ipc";
import * as ipc from "@/lib/ipc";
import { idleSnapshot, useRecordingStore } from "@/stores/recordingStore";
import { useSettingsStore } from "@/stores/settingsStore";

vi.mock("@/hooks/useShortcutLabel", () => ({ useShortcutLabel: () => "⌥⌘R" }));
vi.mock("@/lib/ipc", async (orig) => ({
  ...(await orig<typeof import("@/lib/ipc")>()),
  listRecordingDevices: vi.fn(),
  recordingThumbnail: vi.fn().mockResolvedValue("data:image/jpeg;base64,AAAA"),
  requestRecordingPermissions: vi.fn().mockResolvedValue({}),
  openPrivacySettings: vi.fn().mockResolvedValue(undefined),
}));

const devices: RecordingDevices = {
  backend: "native",
  video: [
    { index: 1000, name: "Built-in Display", isScreen: true },
    { index: 1001, name: "FaceTime HD Camera", isScreen: false },
  ],
  audio: [{ index: 1000, name: "MacBook Pro Microphone" }],
  windows: [{ id: 42, title: "Doc", app: "Pages" }],
  displays: [{ index: 1000, width: 1000, height: 600 }],
  permissions: { screenRecording: "granted", camera: "granted", microphone: "granted" },
};

function open(
  d: RecordingDevices | null,
  extra: Partial<ReturnType<typeof useRecordingStore.getState>> = {},
) {
  vi.mocked(ipc.listRecordingDevices).mockResolvedValue(d ?? devices);
  useRecordingStore.setState({
    phase: "idle",
    session: idleSnapshot(),
    dialogOpen: true,
    devices: d,
    devicesError: null,
    deviceNotices: [],
    opts: { mode: "screen", screenIndex: 1000, audioIndex: 1000, fps: 30 },
    ...extra,
  });
  return render(<RecorderDialog />);
}

describe("RecorderDialog (compact setup)", () => {
  beforeEach(() => {
    window.localStorage.clear();
    useSettingsStore.setState(defaultSettings());
    // jsdom has no media devices: previews report "unavailable" instead of throwing.
    vi.stubGlobal("navigator", { ...navigator, mediaDevices: undefined });
  });
  afterEach(() => {
    cleanup();
    vi.unstubAllGlobals();
  });

  it("is one compact panel with Screen / Camera / Audio and one Start button", async () => {
    open(devices);
    const group = screen.getByRole("radiogroup", { name: "Recording type" });
    expect(group.querySelectorAll('[role="radio"]')).toHaveLength(3);
    expect(screen.getByRole("radiogroup", { name: "What to record" })).toBeTruthy();
    const start = screen.getByRole("button", { name: /start recording/i }) as HTMLButtonElement;
    expect(start.disabled).toBe(false);
    expect(screen.getByText(/Recorded locally/)).toBeTruthy();
    await act(async () => {});
  });

  it("says whether automatic transcription is on", async () => {
    useSettingsStore.getState().setRecording({ autoTranscribe: false });
    open(devices);
    expect(screen.getByText(/Not transcribed automatically/)).toBeTruthy();
    await act(async () => {});
  });

  it("switching to Audio selects a microphone and renames the action", async () => {
    open(devices, { opts: { mode: "screen", screenIndex: 1000 } });
    fireEvent.click(screen.getByRole("radio", { name: "Audio" }));
    expect(useRecordingStore.getState().opts.mode).toBe("voiceover");
    expect(useRecordingStore.getState().opts.audioIndex).toBe(1000);
    expect(screen.getByRole("button", { name: /start audio/i })).toBeTruthy();
    await act(async () => {});
  });

  it("the camera switch turns Screen into screen + camera", async () => {
    open(devices);
    fireEvent.click(screen.getByRole("switch", { name: "Include camera" }));
    expect(useRecordingStore.getState().opts.mode).toBe("screen-camera");
    await act(async () => {});
  });

  it("window source keeps Start disabled with a visible reason until one is chosen", async () => {
    open(devices);
    fireEvent.click(screen.getByRole("radio", { name: "Window" }));
    const start = screen.getByRole("button", { name: /start recording/i }) as HTMLButtonElement;
    expect(start.disabled).toBe(true);
    expect(screen.getByText("Choose a window to record.")).toBeTruthy();
    expect(start.getAttribute("aria-describedby")).toBeTruthy();
    fireEvent.change(screen.getByRole("combobox", { name: /window/i }), {
      target: { value: "42" },
    });
    expect(useRecordingStore.getState().opts.windowId).toBe(42);
    expect(start.disabled).toBe(false);
    await act(async () => {});
  });

  it("area source needs a drawn area", async () => {
    open(devices);
    fireEvent.click(screen.getByRole("radio", { name: "Area" }));
    expect(screen.getByText("Drag on the preview to choose an area.")).toBeTruthy();
    fireEvent.change(screen.getByLabelText("Area width"), { target: { value: "300" } });
    fireEvent.change(screen.getByLabelText("Area height"), { target: { value: "200" } });
    expect(useRecordingStore.getState().opts.area).toMatchObject({ width: 300, height: 200 });
    expect(
      (screen.getByRole("button", { name: /start recording/i }) as HTMLButtonElement).disabled,
    ).toBe(false);
    await act(async () => {});
  });

  it("window and area are disabled on the ffmpeg fallback", async () => {
    open({ ...devices, backend: "ffmpeg", windows: [], displays: [], permissions: null });
    expect((screen.getByRole("radio", { name: "Window" }) as HTMLButtonElement).disabled).toBe(
      true,
    );
    expect((screen.getByRole("radio", { name: "Area" }) as HTMLButtonElement).disabled).toBe(true);
    await act(async () => {});
  });

  it("offers Allow for a permission that was never asked and Open Settings for a denied one", async () => {
    open({
      ...devices,
      permissions: {
        ...devices.permissions,
        screenRecording: "notDetermined",
        microphone: "denied",
      },
    });
    fireEvent.click(screen.getByRole("button", { name: "Allow" }));
    await act(async () => {});
    expect(ipc.requestRecordingPermissions).toHaveBeenCalledWith(["screenRecording"]);
    fireEvent.click(screen.getByRole("button", { name: "Open Settings" }));
    expect(ipc.openPrivacySettings).toHaveBeenCalledWith("microphone");
    expect(screen.getAllByText(/Microphone access is off/).length).toBeGreaterThan(0);
  });

  it("explains an empty camera list", async () => {
    open(
      { ...devices, video: devices.video.filter((v) => v.isScreen) },
      {
        opts: { mode: "camera", audioIndex: 1000 },
      },
    );
    expect(screen.getAllByText(/No camera found/).length).toBeGreaterThan(0);
    expect(
      (screen.getByRole("button", { name: /start recording/i }) as HTMLButtonElement).disabled,
    ).toBe(true);
    await act(async () => {});
  });

  it("shows loading before devices arrive and the error when listing fails", async () => {
    vi.mocked(ipc.listRecordingDevices).mockReturnValue(new Promise(() => {}));
    open(null);
    expect(screen.getAllByText(/Looking for screens and devices/).length).toBeGreaterThan(0);
    cleanup();
    open(null, { devicesError: "helper crashed" });
    expect(screen.getByRole("alert").textContent).toContain("helper crashed");
    await act(async () => {});
  });

  it("keeps advanced settings collapsed until opened, and the shortcut help behind a button", async () => {
    open(devices);
    expect(screen.queryByRole("radiogroup", { name: "Countdown seconds" })).toBeNull();
    fireEvent.click(screen.getByRole("button", { name: "Advanced" }));
    expect(screen.getByRole("radiogroup", { name: "Countdown seconds" })).toBeTruthy();
    expect(screen.queryByText("pause")).toBeNull();
    fireEvent.click(screen.getByRole("button", { name: "Keyboard shortcuts" }));
    expect(screen.getByText("pause")).toBeTruthy();
    await act(async () => {});
  });

  it("moves the segmented choice with the arrow keys", async () => {
    open(devices);
    const screenRadio = screen.getByRole("radio", { name: "Screen" });
    fireEvent.keyDown(screenRadio, { key: "ArrowRight" });
    expect(useRecordingStore.getState().opts.mode).toBe("camera");
    await act(async () => {});
  });

  it("key names are off by default; the character option appears only after the first", async () => {
    open(devices);
    const identity = screen.getByRole("switch", { name: "Record key names" });
    expect(identity).toHaveAttribute("aria-checked", "false");
    expect(
      screen.getByText(/Password fields are normally hidden or missing/),
    ).toBeTruthy();
    expect(screen.queryByRole("switch", { name: /all characters/i })).toBeNull();
    fireEvent.click(identity);
    expect(useRecordingStore.getState().opts.recordKeyIdentity).toBe(true);
    fireEvent.click(screen.getByRole("switch", { name: "Also record all characters" }));
    expect(useRecordingStore.getState().opts.recordAllCharacters).toBe(true);
    await act(async () => {});
  });
});
