import { describe, expect, it } from "vitest";
import {
  addChapter,
  addMediaWithTranscript,
  computeTimeline,
  deleteWords,
  deletedWords,
  newProject,
  projectChapters,
  restoreWords,
  restoreWordsDetailed,
  RESTORE_LEGACY_MESSAGE,
  totalDuration,
  type Project,
  type Segment,
  type SourceMedia,
  type Word,
} from "@/lib/edl";
import {
  deleteClip,
  dropBoundaries,
  dropIndexAt,
  duplicateClip,
  moveClip,
  moveClipBy,
  trimClipEdge,
  rollEdit,
  splitClipAt,
} from "@/lib/clipEdit";

const media = (id: string, duration: number): SourceMedia => ({
  id,
  path: `/tmp/${id}.mp4`,
  duration,
  fps: 30,
  width: 1920,
  height: 1080,
  audioSampleRate: 48000,
  sha256: "x",
});
const words = (n: number, prefix = "w"): Word[] =>
  Array.from({ length: n }, (_, i) => ({
    id: `${prefix}${i}`,
    text: `${prefix}${i}`,
    start: i,
    end: i + 1,
    confidence: 1,
  }));
const mid = (w: Word) => (w.start + w.end) / 2;

/** Seeded PRNG so a failure reproduces. */
function rng(seed: number) {
  return () => {
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function base(): Project {
  const p = addMediaWithTranscript(newProject("t"), media("m", 20), words(20));
  return { ...p, settings: { ...p.settings, paddingMs: 0 } };
}

/** Several clips of one media, produced by deleting some words. */
function clips(): Project {
  return deleteWords(base(), new Set(["w3", "w4", "w9", "w10", "w11", "w15"]));
}

const ranges = (p: Project) =>
  p.segments.map((s) => `${s.mediaId}:${s.sourceIn}-${s.sourceOut}`).sort();

function checkInvariants(p: Project) {
  const tl = computeTimeline(p);
  let t = 0;
  for (const e of tl) {
    expect(e.outputStart).toBeCloseTo(t, 9);
    expect(e.outputEnd).toBeGreaterThanOrEqual(e.outputStart);
    t = e.outputEnd;
  }
  expect(t).toBeCloseTo(totalDuration(p), 9);
  for (const s of p.segments) {
    for (const w of s.words) {
      // A word belongs to the clip containing its midpoint.
      expect(mid(w)).toBeGreaterThanOrEqual(s.sourceIn);
      expect(mid(w)).toBeLessThan(s.sourceOut);
    }
  }
  // Word ids stay unique across the project.
  const ids = p.segments.flatMap((s) => s.words.map((w) => w.id));
  expect(new Set(ids).size).toBe(ids.length);
}

describe("moveClip", () => {
  it("reorders without changing length, ranges or words", () => {
    const p = clips();
    const first = p.segments[0]!.id;
    const out = moveClip(p, first, p.segments.length - 1);
    expect(out.segments.at(-1)!.id).toBe(first);
    expect(totalDuration(out)).toBeCloseTo(totalDuration(p), 9);
    expect(ranges(out)).toEqual(ranges(p));
    expect(out.segments.find((s) => s.id === first)!.words).toEqual(p.segments[0]!.words);
    checkInvariants(out);
  });

  it("is a no-op for the same place, unknown clips and bad indices", () => {
    const p = clips();
    expect(moveClip(p, p.segments[1]!.id, 1)).toBe(p);
    expect(moveClip(p, "nope", 0)).toBe(p);
    expect(moveClip(p, p.segments[1]!.id, Number.NaN)).toBe(p);
    expect(moveClipBy(p, p.segments[0]!.id, -1)).toBe(p);
  });

  it("clamps an out-of-range index", () => {
    const p = clips();
    const id = p.segments[0]!.id;
    expect(moveClip(p, id, 999).segments.at(-1)!.id).toBe(id);
  });

  it("keeps chapters and zoom with their clip", () => {
    let p = clips();
    const [a, b] = p.segments;
    const aLen = a!.sourceOut - a!.sourceIn;
    p = addChapter(p, 0.5, "in A");
    p = addChapter(p, aLen + 0.5, "in B");
    p = { ...p, zoomRegions: [{ id: "z", start: 0, end: 1, scale: 2, focusX: 0.5, focusY: 0.5 }] as never };
    const out = moveClip(p, a!.id, 1);
    const chapters = projectChapters(out);
    const bLen = b!.sourceOut - b!.sourceIn;
    expect(chapters.find((c) => c.title === "in B")!.outputTime).toBeCloseTo(0.5, 9);
    expect(chapters.find((c) => c.title === "in A")!.outputTime).toBeCloseTo(bLen + 0.5, 9);
    expect(out.zoomRegions?.[0]?.start).toBeCloseTo(bLen, 9);
  });

  it("moves a music bed with the clip it started in", () => {
    let p = clips();
    const [a, b] = p.segments;
    const aLen = a!.sourceOut - a!.sourceIn;
    p = {
      ...p,
      audioTracks: [{ id: "t", mediaId: "m", gainDb: 0, offsetSec: aLen + 1, ducks: false }],
    };
    const out = moveClip(p, b!.id, 0);
    expect(out.audioTracks![0]!.offsetSec).toBeCloseTo(1, 9);
  });

  it("random moves keep every invariant", () => {
    const rand = rng(7);
    let p = clips();
    const total = totalDuration(p);
    const baseRanges = ranges(p);
    for (let n = 0; n < 200; n++) {
      const seg = p.segments[Math.floor(rand() * p.segments.length)]!;
      p = moveClip(p, seg.id, Math.floor(rand() * p.segments.length));
      checkInvariants(p);
      expect(totalDuration(p)).toBeCloseTo(total, 9);
      expect(ranges(p)).toEqual(baseRanges);
    }
  });
});

describe("dropIndexAt / dropBoundaries", () => {
  it("goes by the nearest cut to the ghost start, so a long clip passes shorter ones", () => {
    // A is 10 s, B and C 1 s each.
    const p0 = addMediaWithTranscript(newProject("t"), media("m", 12), words(12));
    const seg = (id: string, from: number, to: number): Segment => ({
      id,
      mediaId: "m",
      sourceIn: from,
      sourceOut: to,
      words: words(12).filter((w) => mid(w) >= from && mid(w) < to),
    });
    const p: Project = { ...p0, segments: [seg("A", 0, 10), seg("B", 10, 11), seg("C", 11, 12)] };
    expect(dropBoundaries(p, "A")).toEqual([0, 1, 2]);
    // Starts the UI can produce (clamped to 0..2): index follows the nearest cut.
    expect(dropIndexAt(p, "A", 0)).toBe(0);
    expect(dropIndexAt(p, "A", 0.4)).toBe(0);
    expect(dropIndexAt(p, "A", 0.6)).toBe(1);
    expect(dropIndexAt(p, "A", 1.4)).toBe(1);
    expect(dropIndexAt(p, "A", 1.6)).toBe(2);
    expect(dropIndexAt(p, "A", 2)).toBe(2);
    expect(dropIndexAt(p, "A", -5)).toBe(0);
    // The indicator (boundary at the index) is where the docked ghost starts, and
    // moveClip puts the clip exactly there.
    for (const idx of [0, 1, 2]) {
      const out = moveClip(p, "A", idx);
      expect(computeTimeline(out).find((e) => e.segmentId === "A")!.outputStart).toBe(
        dropBoundaries(p, "A")[idx],
      );
    }
  });

  it("agrees with moveClip on the usual clips", () => {
    const p = clips();
    const id = p.segments[0]!.id;
    const idx = dropIndexAt(p, id, 1e9);
    expect(idx).toBe(p.segments.length - 1);
    expect(moveClip(p, id, idx).segments.at(-1)!.id).toBe(id);
    expect(dropIndexAt(p, id, -5)).toBe(0);
  });

  it("lists the cuts of the timeline without the dragged clip", () => {
    const p = clips();
    const b = dropBoundaries(p, p.segments[0]!.id);
    expect(b[0]).toBe(0);
    expect(b).toHaveLength(p.segments.length);
    expect(b.at(-1)).toBeCloseTo(totalDuration(p) - (p.segments[0]!.sourceOut - p.segments[0]!.sourceIn), 9);
  });
});

describe("duplicateClip", () => {
  it("adds a copy of the same source range right after, with fresh ids", () => {
    const p = clips();
    const src = p.segments[1]!;
    const out = duplicateClip(p, src.id);
    expect(out.segments).toHaveLength(p.segments.length + 1);
    const copy = out.segments[2]!;
    expect(copy.id).not.toBe(src.id);
    expect([copy.sourceIn, copy.sourceOut]).toEqual([src.sourceIn, src.sourceOut]);
    expect(copy.words.map((w) => w.text)).toEqual(src.words.map((w) => w.text));
    expect(copy.words.every((w) => !src.words.some((s) => s.id === w.id))).toBe(true);
    expect(totalDuration(out)).toBeCloseTo(totalDuration(p) + (src.sourceOut - src.sourceIn), 9);
    checkInvariants(out);
  });

  it("deleting a word in one copy leaves the other copy intact", () => {
    const p = clips();
    const out = duplicateClip(p, p.segments[0]!.id);
    const copyWord = out.segments[1]!.words[0]!;
    const after = deleteWords(out, new Set([copyWord.id]));
    expect(after.segments[0]!.words).toEqual(out.segments[0]!.words);
  });

  it("shifts later chapters by the clip length and leaves earlier ones", () => {
    let p = clips();
    const len = p.segments[0]!.sourceOut - p.segments[0]!.sourceIn;
    p = addChapter(p, 0.5, "early");
    p = addChapter(p, len + 0.5, "late");
    const out = duplicateClip(p, p.segments[0]!.id);
    const ch = projectChapters(out);
    expect(ch.find((c) => c.title === "early")!.outputTime).toBeCloseTo(0.5, 9);
    expect(ch.find((c) => c.title === "late")!.outputTime).toBeCloseTo(2 * len + 0.5, 9);
  });

  it("is a no-op for an unknown clip", () => {
    const p = clips();
    expect(duplicateClip(p, "nope")).toBe(p);
  });
});

describe("deleteClip (ripple)", () => {
  it("closes the gap, drops chapters inside and keeps later ones on their content", () => {
    let p = clips();
    const [a, b] = p.segments;
    const aLen = a!.sourceOut - a!.sourceIn;
    p = addChapter(p, 0.5, "gone");
    p = addChapter(p, aLen + 0.5, "kept");
    const out = deleteClip(p, a!.id);
    expect(out.segments[0]!.id).toBe(b!.id);
    expect(totalDuration(out)).toBeCloseTo(totalDuration(p) - aLen, 9);
    expect(projectChapters(out).map((c) => [c.title, c.outputTime])).toEqual([["kept", 0.5]]);
  });

  it("works on a clip whose source range is repeated", () => {
    const p = duplicateClip(clips(), clips().segments[0]!.id);
    const out = deleteClip(p, p.segments[1]!.id);
    expect(out.segments).toHaveLength(p.segments.length - 1);
    checkInvariants(out);
  });

  it("never empties the project", () => {
    const p = base();
    expect(deleteClip(p, p.segments[0]!.id)).toBe(p);
  });
});

describe("random clip operations", () => {
  it("keep timelines monotonic, ownership by midpoint, and repeated ranges legal", () => {
    for (const seed of [1, 2, 3, 4, 5]) {
      const rand = rng(seed);
      let p = clips();
      p = addChapter(p, 1, "c");
      for (let n = 0; n < 120; n++) {
        const seg = p.segments[Math.floor(rand() * p.segments.length)]!;
        const r = rand();
        const before = p;
        if (r < 0.35) p = duplicateClip(p, seg.id);
        else if (r < 0.7) p = moveClip(p, seg.id, Math.floor(rand() * p.segments.length));
        else p = deleteClip(p, seg.id);
        checkInvariants(p);
        expect(p.segments.length).toBeGreaterThanOrEqual(1);
        for (const c of p.chapters ?? []) {
          expect(c.outputTime).toBeGreaterThanOrEqual(0);
          expect(c.outputTime).toBeLessThan(totalDuration(p) + 1e-9);
        }
        // Source ranges of surviving original clips never change.
        for (const s of p.segments) {
          const was = before.segments.find((x) => x.id === s.id);
          if (was) expect([s.sourceIn, s.sourceOut]).toEqual([was.sourceIn, was.sourceOut]);
        }
      }
    }
  });
});

describe("restoreWords", () => {
  const ids = (p: Project) => p.segments.flatMap((s) => s.words.map((w) => w.id));

  it("restores a deleted word into a clip between its neighbours", () => {
    const p = deleteWords(base(), new Set(["w5"]));
    expect(ids(p)).not.toContain("w5");
    const out = restoreWords(p, new Set(["w5"]));
    expect(ids(out)).toContain("w5");
    expect(totalDuration(out)).toBeGreaterThan(totalDuration(p));
    checkInvariants(out);
  });

  it("round-trips delete -> restore for a run of words back to the whole range", () => {
    const orig = base();
    const del = deleteWords(orig, new Set(["w5", "w6", "w7"]));
    const out = restoreWords(del, new Set(["w5", "w6", "w7"]));
    expect(ids(out).sort()).toEqual(ids(orig).sort());
    expect(out.segments).toHaveLength(1);
    expect([out.segments[0]!.sourceIn, out.segments[0]!.sourceOut]).toEqual([0, 20]);
    expect(totalDuration(out)).toBeCloseTo(20, 9);
  });

  it("restores only the requested words of a deleted run", () => {
    const del = deleteWords(base(), new Set(["w5", "w6", "w7"]));
    const out = restoreWords(del, new Set(["w5", "w7"]));
    expect(ids(out)).toContain("w5");
    expect(ids(out)).toContain("w7");
    expect(ids(out)).not.toContain("w6");
    checkInvariants(out);
  });

  it("keeps later chapters on their content", () => {
    let del = deleteWords(base(), new Set(["w5"]));
    del = addChapter(del, 10, "later");
    const out = restoreWords(del, new Set(["w5"]));
    const grown = totalDuration(out) - totalDuration(del);
    expect(projectChapters(out)[0]!.outputTime).toBeCloseTo(10 + grown, 9);
  });

  it("ignores live words and reports unknown ids", () => {
    const p = deleteWords(base(), new Set(["w5"]));
    const r = restoreWordsDetailed(p, new Set(["w1", "nope"]));
    expect(r.project).toBe(p);
    expect(r.restored).toBe(0);
    expect(r.unavailable).toBe(1);
  });

  it("random delete/restore keeps the invariants and never duplicates words", () => {
    const rand = rng(11);
    let p = base();
    const all = words(20).map((w) => w.id);
    for (let n = 0; n < 150; n++) {
      const pick = new Set(all.filter(() => rand() < 0.25));
      p = rand() < 0.5 ? deleteWords(p, pick) : restoreWords(p, pick);
      if (p.segments.length === 0) p = base();
      checkInvariants(p);
      // No two clips of one media overlap in source time.
      const sorted = [...p.segments].sort((a, b) => a.sourceIn - b.sourceIn);
      for (let i = 1; i < sorted.length; i++)
        expect(sorted[i]!.sourceIn).toBeGreaterThanOrEqual(sorted[i - 1]!.sourceOut - 1e-6);
    }
    // Everything is recoverable at the end.
    const restored = restoreWords(p, new Set(all));
    expect(ids(restored).sort()).toEqual([...all].sort());
  });

  it("explains the limitation on a legacy project and changes nothing", () => {
    const legacy: Project = { ...deleteWords(base(), new Set(["w5"])) };
    delete legacy.originalTranscripts;
    const r = restoreWordsDetailed(legacy, new Set(["w5"]));
    expect(r.project).toBe(legacy);
    expect(r.limitation).toBe(RESTORE_LEGACY_MESSAGE);
    expect(r.unavailable).toBe(1);
    expect(deletedWords(legacy)).toEqual([]);
  });

  it("lists deleted words from the originals", () => {
    const p = deleteWords(base(), new Set(["w5", "w6"]));
    expect(deletedWords(p).map((w) => w.id)).toEqual(["w5", "w6"]);
  });
});

describe("types", () => {
  it("keeps Segment usable by tests", () => {
    const s: Segment = { id: "a", mediaId: "m", words: [], sourceIn: 0, sourceOut: 1 };
    expect(s.id).toBe("a");
  });
});

const zoom = (id: string, start: number, end: number) =>
  ({ id, start, end, scale: 2, focusX: 0.5, focusY: 0.5 }) as never;

describe("duplicated clips keep their own word ids", () => {
  const allIds = (p: Project) => p.segments.flatMap((s) => s.words.map((w) => w.id));
  const unique = (p: Project) => expect(new Set(allIds(p)).size).toBe(allIds(p).length);

  it("A -> A', trim A' inward past 3 words, drag back out, delete a word in A'", () => {
    const original = base();
    const dup = duplicateClip(original, original.segments[0]!.id);
    const [a, b] = dup.segments;
    const inward = trimClipEdge(dup, b!.id, "end", 17, WORDS20);
    expect(inward.segments[1]!.words).toHaveLength(17);
    const out = trimClipEdge(inward, b!.id, "end", 20, WORDS20);
    expect(out.segments[1]!.words).toHaveLength(20);
    unique(out);
    // The three pulled-back words clash with A's, so they carry suffixes.
    expect(out.segments[1]!.words.slice(17).every((w) => w.id.includes("#"))).toBe(true);
    expect(out.segments[0]!.words).toEqual(a!.words);
    const victim = out.segments[1]!.words[18]!;
    const after = deleteWords(out, new Set([victim.id]));
    expect(after.segments[0]!.words).toEqual(a!.words); // A untouched
    expect(after.segments.flatMap((s) => s.words).filter((w) => w.text === victim.text)).toHaveLength(1);
  });

  it("roll pulling originals into a clip beside a duplicate also stays unique", () => {
    const p0 = splitClipAt(base(), 10);
    const dup = duplicateClip(p0, p0.segments[1]!.id); // S1 S2 S2'
    const out = rollEdit(dup, dup.segments[0]!.id, 2, { m: WORDS20 });
    unique(out);
    expect(totalDuration(out)).toBeCloseTo(totalDuration(dup), 9);
  });
});

const WORDS20 = words(20);

describe("retiming follows the clip, not the source time", () => {
  /** One clip A [0,20] duplicated to A' with content pinned to the copy. */
  function withContent() {
    const b0 = base();
    let p = duplicateClip(b0, b0.segments[0]!.id);
    p = addChapter(p, 25, "on copy"); // A' src 5
    p = addChapter(p, 5, "on original"); // A src 5
    p = { ...p, zoomRegions: [zoom("z", 22, 26)] };
    p = { ...p, audioTracks: [{ id: "t", mediaId: "m", gainDb: 0, offsetSec: 30, ducks: false }] };
    return p;
  }
  const chap = (p: Project, t: string) => projectChapters(p).find((c) => c.title === t)!.outputTime;

  it("survives a word delete in the copy", () => {
    const p = withContent();
    const copy = p.segments[1]!;
    const out = deleteWords(p, new Set([copy.words[0]!.id])); // copy starts at src 1
    expect(chap(out, "on copy")).toBeCloseTo(24, 9);
    expect(chap(out, "on original")).toBeCloseTo(5, 9);
    expect(out.zoomRegions).toHaveLength(1);
    expect(out.zoomRegions![0]!.start).toBeCloseTo(21, 9);
    expect(out.audioTracks![0]!.offsetSec).toBeCloseTo(29, 9);
  });

  it("survives a word delete in the original", () => {
    const p = withContent();
    const out = deleteWords(p, new Set([p.segments[0]!.words[0]!.id]));
    // The original shrank by 1 s, so the copy and everything on it moves up 1 s.
    expect(chap(out, "on copy")).toBeCloseTo(24, 9);
    expect(chap(out, "on original")).toBeCloseTo(4, 9);
    expect(out.zoomRegions).toHaveLength(1);
    expect(out.zoomRegions![0]!.start).toBeCloseTo(21, 9);
  });

  it("survives trimming the copy and the original", () => {
    const p = withContent();
    const t1 = trimClipEdge(p, p.segments[1]!.id, "start", 2);
    expect(chap(t1, "on copy")).toBeCloseTo(23, 9);
    expect(chap(t1, "on original")).toBeCloseTo(5, 9);
    expect(t1.zoomRegions).toHaveLength(1);
    const t2 = trimClipEdge(p, p.segments[0]!.id, "end", 15);
    expect(chap(t2, "on copy")).toBeCloseTo(20, 9);
    expect(chap(t2, "on original")).toBeCloseTo(5, 9);
  });

  it("survives a roll between the original and its neighbour", () => {
    let p = splitClipAt(base(), 10); // S1 [0,10] S2 [10,20]
    p = duplicateClip(p, p.segments[1]!.id); // S1 S2 S2'
    p = addChapter(p, 25, "on copy"); // S2' src 15
    p = { ...p, zoomRegions: [zoom("z", 22, 27)] };
    const out = rollEdit(p, p.segments[0]!.id, -3);
    expect(chap(out, "on copy")).toBeCloseTo(25, 9);
    expect(out.zoomRegions).toHaveLength(1);
    expect(out.zoomRegions![0]!.start).toBeCloseTo(22, 9);
  });

  it("survives a delete range that rebuilds both copies (no recorded lineage fallback aside)", () => {
    const p = withContent();
    const out = deleteWords(p, new Set([p.segments[1]!.words[10]!.id])); // src 10..11 in copy
    expect(chap(out, "on copy")).toBeCloseTo(25, 9);
    expect(chap(out, "on original")).toBeCloseTo(5, 9);
  });

  it("restoring words keeps content on the copy", () => {
    const p = withContent();
    const cut = deleteWords(p, new Set(["w2"])); // only the original has exact id w2
    const back = restoreWords(cut, new Set(["w2"]));
    expect(chap(back, "on copy")).toBeCloseTo(25, 9);
  });

  it("splitting a clip keeps retiming through its halves", () => {
    const p = withContent();
    const split = splitClipAt(p, 30); // copy src 10: A, A'a, A'b
    expect(split.segments).toHaveLength(3);
    const out = deleteClip(split, split.segments[0]!.id); // drop the original
    expect(projectChapters(out).map((c) => c.title)).toEqual(["on copy"]);
    expect(chap(out, "on copy")).toBeCloseTo(5, 9);
    expect(out.zoomRegions![0]!.start).toBeCloseTo(2, 9);
  });
});

describe("opening stays put on a move", () => {
  it("a chapter at 0:00 and a bed starting at the first cut stay; others follow", () => {
    let p = clips();
    const [a, b] = p.segments;
    const aLen = a!.sourceOut - a!.sourceIn;
    p = addChapter(p, 0, "intro");
    p = addChapter(p, aLen + 0.5, "in B");
    p = {
      ...p,
      audioTracks: [
        { id: "bed", mediaId: "m", gainDb: 0, offsetSec: 0.25, ducks: false },
        { id: "late", mediaId: "m", gainDb: 0, offsetSec: aLen + 1, ducks: false },
      ],
    };
    const out = moveClip(p, b!.id, 0);
    const bLen = b!.sourceOut - b!.sourceIn;
    expect(projectChapters(out).find((c) => c.title === "intro")!.outputTime).toBe(0);
    expect(projectChapters(out).find((c) => c.title === "in B")!.outputTime).toBeCloseTo(0.5, 9);
    expect(out.audioTracks!.find((t) => t.id === "bed")!.offsetSec).toBe(0.25);
    expect(out.audioTracks!.find((t) => t.id === "late")!.offsetSec).toBeCloseTo(1, 9);
    expect(bLen).toBeGreaterThan(0);
  });
});

describe("restore with duplicates", () => {
  it("never gives a clip a word it already has under a suffix", () => {
    const p0 = base();
    const dup = duplicateClip(p0, p0.segments[0]!.id); // A, A' (w5#x)
    const cut = deleteWords(dup, new Set(["w5"])); // only A has the exact id
    const copyBefore = cut.segments.at(-1)!.words;
    const out = restoreWords(cut, new Set(["w5"]));
    const ids = out.segments.flatMap((s) => s.words.map((w) => w.id));
    expect(new Set(ids).size).toBe(ids.length);
    expect(ids.filter((id) => id === "w5")).toHaveLength(1);
    // The copy kept exactly its own words: it never received w5 a second time.
    const copy = out.segments.find((s) => s.words.some((w) => w.id.startsWith("w5#")))!;
    expect(copy.words.filter((w) => w.id.split("#")[0] === "w5")).toHaveLength(1);
    expect(copyBefore.filter((w) => w.id.split("#")[0] === "w5")).toHaveLength(1);
    expect(totalDuration(out)).toBeGreaterThan(totalDuration(cut));
  });
});
