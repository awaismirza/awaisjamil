import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { renderHook } from "@testing-library/react";
import { useKeyboardShortcuts } from "@/hooks/useKeyboardShortcuts";
import { defaultEditorShortcuts } from "@/lib/editorShortcuts";
import { defaultShortcuts } from "@/lib/shortcuts";
import { usePlayerStore } from "@/stores/playerStore";
import { useSettingsStore } from "@/stores/settingsStore";
import { useUIStore } from "@/stores/uiStore";

function press(init: KeyboardEventInit & { code: string }, target: EventTarget = window) {
  const e = new KeyboardEvent("keydown", { bubbles: true, cancelable: true, ...init });
  target.dispatchEvent(e);
  return e;
}
const SPACE = { code: "Space", key: " " };

let events: string[];
const listeners: Array<[string, EventListener]> = [];

beforeEach(() => {
  Object.defineProperty(navigator, "platform", { value: "MacIntel", configurable: true });
  useSettingsStore.setState({
    shortcuts: defaultShortcuts(),
    editorShortcuts: defaultEditorShortcuts(),
  });
  useUIStore.setState({ isProcessingEdit: false });
  usePlayerStore.getState().setSelectedWordIds([]);
  events = [];
  for (const name of ["toggle-play", "save", "export", "pause", "play"]) {
    const fn: EventListener = () => events.push(name);
    window.addEventListener(`yusafcut:${name}`, fn);
    listeners.push([`yusafcut:${name}`, fn]);
  }
});

afterEach(() => {
  for (const [n, fn] of listeners.splice(0)) window.removeEventListener(n, fn);
  document.body.innerHTML = "";
});

describe("useKeyboardShortcuts", () => {
  it("runs the default bindings and prevents the browser default", () => {
    renderHook(() => useKeyboardShortcuts());
    expect(press(SPACE).defaultPrevented).toBe(true);
    press({ code: "KeyK", key: "k" });
    press({ code: "KeyS", key: "s", metaKey: true });
    press({ code: "KeyE", key: "e", metaKey: true });
    expect(events).toEqual(["toggle-play", "pause", "save", "export"]);
  });

  it("follows a rebinding and drops the old key", () => {
    renderHook(() => useKeyboardShortcuts());
    expect(useSettingsStore.getState().setEditorShortcut("playPause", "P")).toEqual({ ok: true });
    press(SPACE);
    expect(events).toEqual([]);
    press({ code: "KeyP", key: "p" });
    expect(events).toEqual(["toggle-play"]);
  });

  it("does not match extra modifiers or a different modifier set", () => {
    renderHook(() => useKeyboardShortcuts());
    press({ code: "KeyK", key: "k", metaKey: true });
    press({ code: "KeyK", key: "k", altKey: true });
    expect(events).toEqual([]);
  });

  it("ignores hotkeys while a modal dialog or menu is open, but not a non-modal popover", () => {
    renderHook(() => useKeyboardShortcuts());
    const dialog = document.createElement("div");
    dialog.setAttribute("role", "dialog");
    document.body.appendChild(dialog);
    press(SPACE);
    expect(events).toEqual([]);
    // save / export still work over a modal
    press({ code: "KeyS", key: "s", metaKey: true });
    expect(events).toEqual(["save"]);

    dialog.setAttribute("aria-modal", "false");
    press(SPACE);
    expect(events).toEqual(["save", "toggle-play"]);

    dialog.remove();
    const menu = document.createElement("div");
    menu.setAttribute("role", "menu");
    document.body.appendChild(menu);
    press(SPACE);
    expect(events).toEqual(["save", "toggle-play"]);
  });

  it("ignores IME composition", () => {
    renderHook(() => useKeyboardShortcuts());
    press({ ...SPACE, isComposing: true });
    press({ ...SPACE, keyCode: 229 });
    expect(events).toEqual([]);
  });

  it("ignores key auto-repeat for toggle actions", () => {
    renderHook(() => useKeyboardShortcuts());
    press({ ...SPACE, repeat: true });
    press({ code: "KeyS", key: "s", metaKey: true, repeat: true });
    expect(events).toEqual([]);
  });

  it("blocks plain keys in inputs and contenteditable, but allows save everywhere", () => {
    renderHook(() => useKeyboardShortcuts());
    const input = document.createElement("input");
    const editable = document.createElement("div");
    editable.setAttribute("contenteditable", "true");
    document.body.append(input, editable);

    press(SPACE, input);
    press(SPACE, editable);
    expect(events).toEqual([]);

    press({ code: "KeyS", key: "s", metaKey: true }, input);
    press({ code: "KeyS", key: "s", metaKey: true }, editable);
    expect(events).toEqual(["save", "save"]);
  });

  it("swallows transport keys while an edit is processing, without running them", () => {
    renderHook(() => useKeyboardShortcuts());
    useUIStore.setState({ isProcessingEdit: true });
    expect(press(SPACE).defaultPrevented).toBe(true);
    expect(events).toEqual([]);
  });

  it("leaves a recorder global shortcut combination to the recorder", () => {
    renderHook(() => useKeyboardShortcuts());
    // Force a clash that setShortcut would refuse, to prove the hook is defensive.
    useSettingsStore.setState({ shortcuts: { ...defaultShortcuts(), record: "Space" } });
    press(SPACE);
    expect(events).toEqual([]);
  });

  it("removes its listener on unmount", () => {
    const { unmount } = renderHook(() => useKeyboardShortcuts());
    unmount();
    press(SPACE);
    expect(events).toEqual([]);
  });
});
