import { describe, expect, it } from "vitest";
import { buildSrt, buildVtt, flattenWordsInOutputTime } from "@/lib/captions";
import {
  cueAt,
  layoutCaptions,
  layoutProjectCaptions,
  limitsFor,
  stripEmoji,
  toExportCues,
  type TimedWord,
} from "@/lib/captionLayout";
import { DEFAULT_CAPTION_STYLE, sanitizeCaptionStyle } from "@/lib/captionStyle";
import { addMediaWithTranscript, deleteWords, newProject, type Word } from "@/lib/edl";
import { buildExportOptions, captionBurnNotes, type ExportUiSettings } from "@/lib/exportOptions";

const L = limitsFor({ maxCharsPerLine: 20, maxLines: 2 });
const tw = (spec: Array<[string, number, number]>): TimedWord[] =>
  spec.map(([text, start, end]) => ({ text, start, end }));
const words = (spec: Array<[string, number, number]>): Word[] =>
  spec.map(([text, start, end], i) => ({ id: `w${i}`, text, start, end, confidence: 1 }));
const media = () => ({
  id: "m1",
  path: "/tmp/x.mp4",
  duration: 60,
  fps: 30,
  width: 1920,
  height: 1080,
  audioSampleRate: 48000,
  sha256: "abc",
});
/** n words of 0.3 s, back to back. */
const run = (n: number, len = 5): TimedWord[] =>
  Array.from({ length: n }, (_, i) => ({
    text: "w".repeat(len),
    start: i * 0.3,
    end: i * 0.3 + 0.3,
  }));

describe("caption layout", () => {
  it("wraps within the line limit and never splits a word", () => {
    const input = tw([
      ["Hello", 0, 0.3],
      ["wonderful", 0.3, 0.7],
      ["people", 0.7, 1.0],
      ["everywhere", 1.0, 1.5],
    ]);
    const { cues } = layoutCaptions(input, L);
    const out = cues.flatMap((c) => c.lines.flat().map((w) => w.text));
    expect(out).toEqual(input.map((w) => w.text));
    for (const c of cues) {
      expect(c.lines.length).toBeLessThanOrEqual(2);
      for (const line of c.lines)
        expect(line.map((w) => w.text).join(" ").length).toBeLessThanOrEqual(20);
    }
  });

  it("starts a new cue instead of exceeding the line count", () => {
    const { cues } = layoutCaptions(run(12), limitsFor({ maxCharsPerLine: 12, maxLines: 2 }));
    expect(cues.length).toBeGreaterThan(1);
    expect(cues.every((c) => c.lines.length <= 2)).toBe(true);
    expect(cues.flatMap((c) => c.lines.flat()).length).toBe(12);
  });

  it("keeps a word longer than the line whole, on its own line, with a warning", () => {
    const long = "Pneumonoultramicroscopicsilicovolcanoconiosis";
    const { cues, warnings } = layoutCaptions(
      tw([
        ["a", 0, 0.3],
        [long, 0.3, 1.5],
        ["b", 1.5, 1.8],
      ]),
      L,
    );
    expect(cues.flatMap((c) => c.lines.flat().map((w) => w.text))).toContain(long);
    const line = cues.flatMap((c) => c.lines).find((l) => l.some((w) => w.text === long))!;
    expect(line).toHaveLength(1);
    expect(warnings.some((w) => w.kind === "long-word")).toBe(true);
  });

  it("glues stand-alone punctuation to the previous word and breaks after a sentence", () => {
    const { cues } = layoutCaptions(
      tw([
        ["Hello", 0, 0.8],
        [",", 0.8, 0.85],
        ["world", 0.85, 1.4],
        [".", 1.4, 1.45],
        ["Next", 1.5, 2.0],
        ["one", 2.0, 2.4],
      ]),
      L,
    );
    expect(cues.map((c) => c.text)).toEqual(["Hello, world.", "Next one"]);
    expect(cues[0]!.end).toBeCloseTo(1.45, 6);
  });

  it("breaks on a silence and on the maximum cue length", () => {
    const gap = layoutCaptions(
      tw([
        ["a", 0, 0.3],
        ["b", 1.5, 1.8],
      ]),
      L,
    );
    expect(gap.cues).toHaveLength(2);
    const slow = Array.from(
      { length: 20 },
      (_, i): TimedWord => ({ text: "ab", start: i * 0.5, end: i * 0.5 + 0.45 }),
    );
    const { cues } = layoutCaptions(slow, limitsFor({ maxCharsPerLine: 60, maxLines: 3 }));
    expect(cues.length).toBeGreaterThan(1);
    for (const c of cues) expect(c.end - c.start).toBeLessThanOrEqual(6);
  });

  it("warns about fast speech and very short cues, and never moves the times", () => {
    const fast = tw([
      ["incomprehensibilities", 0, 0.2],
      ["notwithstanding", 0.2, 0.4],
    ]);
    const { cues, warnings } = layoutCaptions(
      fast,
      limitsFor({ maxCharsPerLine: 40, maxLines: 2 }),
    );
    expect(warnings.map((w) => w.kind).sort()).toEqual(["fast", "short"]);
    expect(cues[0]!.start).toBe(0);
    expect(cues[0]!.end).toBe(0.4);
    expect(
      layoutCaptions(
        tw([
          ["calm", 0, 1.5],
          ["words", 1.5, 3],
        ]),
        L,
      ).warnings,
    ).toEqual([]);
  });

  it("is deterministic and ignores empty or non-finite words", () => {
    const input = [
      ...tw([
        ["x", 0, 0.3],
        ["  ", 0.3, 0.4],
        ["y", 0.4, 0.7],
      ]),
      { text: "z", start: NaN, end: 1 },
    ];
    const a = layoutCaptions(input, L);
    expect(layoutCaptions(input, L)).toEqual(a);
    expect(a.cues.map((c) => c.text)).toEqual(["x y"]);
  });

  it("trims overlapping ASR boundaries so two cues never show at once", () => {
    const { cues } = layoutCaptions(
      tw([
        ["a", 0, 1.2],
        ["b", 1, 1.5],
        ["c", 3, 3.4],
      ]),
      L,
    );
    expect(cues[0]!.lines[0]![0]!.end).toBeCloseTo(1, 6);
    for (let i = 1; i < cues.length; i++)
      expect(cues[i]!.start).toBeGreaterThanOrEqual(cues[i - 1]!.end);
  });

  it("finds the cue and the spoken word at a time", () => {
    const { cues } = layoutCaptions(
      tw([
        ["one", 1, 1.5],
        ["two", 1.6, 2.0],
        ["three", 5, 5.5],
      ]),
      L,
    );
    expect(cueAt(cues, 0.5)).toBeNull();
    const hit = cueAt(cues, 1.2)!;
    expect([hit.line, hit.word]).toEqual([0, 0]);
    // The highlight stays on a word through the pause up to the next word.
    expect(cueAt(cues, 1.55)!.word).toBe(0);
    expect(cueAt(cues, 1.7)!.word).toBe(1);
    expect(cueAt(cues, 3)).toBeNull();
    expect(cueAt(cues, 5.2)!.cue.text).toBe("three");
  });

  it("exports cue and word times for the burner", () => {
    const { cues } = layoutCaptions(
      tw([
        ["one", 1, 1.5],
        ["two", 1.6, 2],
      ]),
      L,
    );
    expect(toExportCues(cues)).toEqual([
      {
        start: 1,
        end: 2,
        lines: [
          [
            { t: "one", s: 1, e: 1.6 },
            { t: "two", s: 1.6, e: 2 },
          ],
        ],
      },
    ]);
  });
});

describe("caption layout on an edited project (output time)", () => {
  const base = () =>
    addMediaWithTranscript(
      newProject("p"),
      media(),
      words([
        ["keep", 0, 0.5],
        ["delete", 0.55, 3.0],
        ["this", 3.05, 3.5],
        ["too", 3.55, 4.0],
      ]),
    );

  it("takes times from the words in output order, after cuts", () => {
    const edited = deleteWords(base(), new Set(["w1"]));
    const out = flattenWordsInOutputTime(edited);
    const { cues } = layoutProjectCaptions(edited, DEFAULT_CAPTION_STYLE);
    const flat = cues.flatMap((c) => c.lines.flat());
    expect(flat.map((w) => w.text)).toEqual(["keep", "this", "too"]);
    flat.forEach((w, i) => {
      expect(w.start).toBeCloseTo(out[i]!.start, 9);
      expect(w.start).toBeLessThan(3); // the 2.45 s hole is gone
    });
    expect(cues[cues.length - 1]!.end).toBeLessThan(2);
  });

  it("leaves SRT and VTT output exactly as before", () => {
    const p = base();
    expect(buildSrt(p)).toBe("1\n00:00:00,000 --> 00:00:04,000\nkeep delete this too\n");
    expect(buildVtt(p)).toBe("WEBVTT\n\n00:00:00.000 --> 00:00:04.000\nkeep delete this too\n");
  });
});

describe("caption style and export options", () => {
  const ui: ExportUiSettings = {
    resolution: "original",
    customWidth: 1920,
    customHeight: 1080,
    codec: "auto",
  };
  const project = () =>
    addMediaWithTranscript(
      newProject("p"),
      media(),
      words([
        ["hi", 0, 0.5],
        ["there", 0.5, 1],
      ]),
    );

  it("falls back to defaults for missing or hostile values", () => {
    expect(sanitizeCaptionStyle(undefined)).toEqual(DEFAULT_CAPTION_STYLE);
    const s = sanitizeCaptionStyle({
      font: "Comic Sans",
      size: 1e9,
      color: "red",
      position: "left",
      maxLines: 99,
      boxOpacity: NaN,
    });
    expect(s).toMatchObject({
      font: "Helvetica Neue",
      size: 140,
      color: "#ffffff",
      position: "bottom",
      maxLines: 3,
      boxOpacity: 0.7,
    });
  });

  it("sends captions only when burn-in is on, and never for audio formats", () => {
    expect("captions" in buildExportOptions(project(), ui, "/o.mp4")).toBe(false);
    const on = buildExportOptions(project(), { ...ui, burnCaptions: true }, "/o.mp4");
    expect(on.captions?.cues).toHaveLength(1);
    expect(on.captions?.style).toEqual(DEFAULT_CAPTION_STYLE);
    const audio = buildExportOptions(
      project(),
      { ...ui, burnCaptions: true, format: "wav" },
      "/o.wav",
    );
    expect("captions" in audio).toBe(false);
  });
});

describe("caption layout: overlap, invisible cues, glyph coverage", () => {
  it("never lets a swallowed or out-of-order word show two cues at once", () => {
    const { cues, warnings } = layoutCaptions(
      tw([
        ["a", 1, 2],
        ["b", 0.5, 0.8], // starts before the previous word, fully inside it
        ["c", 5, 5.5],
      ]),
      limitsFor({ maxCharsPerLine: 20, maxLines: 2 }),
    );
    for (let i = 1; i < cues.length; i++)
      expect(cues[i]!.start).toBeGreaterThanOrEqual(cues[i - 1]!.end);
    const flat = cues.flatMap((c) => c.lines.flat());
    for (let i = 1; i < flat.length; i++)
      expect(flat[i]!.start).toBeGreaterThanOrEqual(flat[i - 1]!.end);
    expect(warnings.some((w) => w.kind === "invisible")).toBe(true);
  });

  it("reports a zero-length cue instead of dropping it silently", () => {
    const { warnings } = layoutCaptions(
      tw([
        ["blink", 2, 2],
        ["x", 5, 5.5],
      ]),
      L,
    );
    expect(warnings.find((w) => w.kind === "invisible")?.message).toContain("will not be drawn");
  });

  it("flags emoji and uncovered scripts, but not Latin, Cyrillic, CJK or Hangul", () => {
    const kinds = (t: string) =>
      layoutCaptions(tw([[t, 0, 2]]), limitsFor({ maxCharsPerLine: 60, maxLines: 2 })).warnings.map(
        (w) => w.kind,
      );
    expect(kinds("Hello 😀")).toContain("emoji");
    expect(kinds("Hello 👍🏽 ❤️")).toContain("emoji");
    expect(kinds("café Привет 你好 ありがとう 한국어 © 100%")).toEqual([]);
    expect(kinds("שלום")).toContain("glyph");
    expect(kinds("Hi 😀")).not.toContain("glyph");
  });

  it("strips emoji from export cues and drops cues left empty", () => {
    const { cues } = layoutCaptions(
      tw([
        ["Hi", 0, 1],
        ["😀", 1, 1.5],
        ["there👍", 1.5, 2.5],
        ["🎉", 5, 6],
      ]),
      L,
    );
    const out = stripEmoji(cues);
    expect(out.map((c) => c.text)).toEqual(["Hi there"]);
    expect(out[0]!.index).toBe(1);
  });

  it("export options strip emoji only when asked, and note problems", () => {
    const p = addMediaWithTranscript(
      newProject("p"),
      media(),
      words([
        ["hi", 0, 0.5],
        ["😀", 0.5, 1],
      ]),
    );
    const ui: ExportUiSettings = {
      resolution: "original",
      customWidth: 1920,
      customHeight: 1080,
      codec: "auto",
      burnCaptions: true,
    };
    expect(
      buildExportOptions(p, ui, "/o.mp4").captions?.cues[0]!.lines[0]!.map((w) => w.t),
    ).toEqual(["hi", "😀"]);
    expect(
      buildExportOptions(
        p,
        { ...ui, stripCaptionEmoji: true },
        "/o.mp4",
      ).captions?.cues[0]!.lines[0]!.map((w) => w.t),
    ).toEqual(["hi"]);
    expect(captionBurnNotes(p)).toMatchObject({ noTranscript: false, emojiCues: 1 });
    expect(captionBurnNotes(newProject("empty")).noTranscript).toBe(true);
  });
});
