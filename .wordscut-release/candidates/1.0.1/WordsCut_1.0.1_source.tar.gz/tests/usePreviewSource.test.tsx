import { act, cleanup, renderHook } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { usePreviewSource } from "@/hooks/usePreviewSource";
import { generatePreviewProxy } from "@/lib/ipc";
import type { SourceMedia } from "@/lib/edl";
vi.mock("@/lib/ipc", () => ({ generatePreviewProxy: vi.fn() }));
const media = (id: string): SourceMedia => ({
  id,
  path: `/${id}.mov`,
  sha256: id,
  duration: 10,
  fps: 30,
  width: 1920,
  height: 1080,
  audioSampleRate: 48000,
});
function deferred() {
  let resolve!: (path: string) => void;
  let reject!: (error: Error) => void;
  const promise = new Promise<string>((yes, no) => {
    resolve = yes;
    reject = no;
  });
  return { promise, resolve, reject };
}
beforeEach(() => {
  vi.mocked(generatePreviewProxy).mockReset();
});
afterEach(cleanup);
describe("preview source cache", () => {
  it("opens originals immediately and keeps them playable during generation", async () => {
    const pending = deferred();
    vi.mocked(generatePreviewProxy).mockReturnValue(pending.promise);
    const a = media("a");
    const { result } = renderHook(() => usePreviewSource(a));
    expect(result.current.path).toBe(a.path);
    expect(generatePreviewProxy).not.toHaveBeenCalled();
    act(() => result.current.setQuality("balanced"));
    expect(result.current.path).toBe(a.path);
    expect(result.current.status).toContain("Preparing preview");
    await act(async () => {
      pending.resolve("/a-proxy.mp4");
      await pending.promise;
    });
    expect(result.current.path).toBe("/a-proxy.mp4");
  });

  it("reuses ready A -> B -> A proxies without an intermediate original path", async () => {
    vi.mocked(generatePreviewProxy).mockImplementation(async (source) => `/${source.id}-proxy.mp4`);
    const a = media("a"),
      b = media("b");
    const observed: (string | undefined)[] = [];
    const { result, rerender } = renderHook(
      ({ source }) => {
        const value = usePreviewSource(source);
        observed.push(value.path);
        return value;
      },
      { initialProps: { source: a } },
    );
    await act(async () => result.current.setQuality("balanced"));
    expect(result.current.path).toBe("/a-proxy.mp4");
    await act(async () => rerender({ source: b }));
    expect(result.current.path).toBe("/b-proxy.mp4");
    observed.length = 0;
    act(() => rerender({ source: a }));
    expect(result.current.path).toBe("/a-proxy.mp4");
    expect(observed).toEqual(["/a-proxy.mp4"]);
    expect(generatePreviewProxy).toHaveBeenCalledTimes(2);
  });

  it("ignores late source results and rejoins in-flight requests", async () => {
    const aRequest = deferred(),
      bRequest = deferred();
    vi.mocked(generatePreviewProxy)
      .mockReturnValueOnce(aRequest.promise)
      .mockReturnValueOnce(bRequest.promise);
    const a = media("a"),
      b = media("b");
    const { result, rerender } = renderHook(({ source }) => usePreviewSource(source), {
      initialProps: { source: a },
    });
    act(() => result.current.setQuality("balanced"));
    act(() => rerender({ source: b }));
    await act(async () => {
      aRequest.resolve("/a-proxy.mp4");
      await aRequest.promise;
    });
    expect(result.current.path).toBe(b.path);
    act(() => rerender({ source: a }));
    expect(result.current.path).toBe("/a-proxy.mp4");
    act(() => rerender({ source: b }));
    await act(async () => {
      bRequest.resolve("/b-proxy.mp4");
      await bRequest.promise;
    });
    expect(result.current.path).toBe("/b-proxy.mp4");
    expect(generatePreviewProxy).toHaveBeenCalledTimes(2);
  });

  it("falls back on playback failure and retries after a quality toggle", async () => {
    vi.mocked(generatePreviewProxy).mockResolvedValue("/proxy.mp4");
    const a = media("a");
    const { result } = renderHook(() => usePreviewSource(a));
    await act(async () => result.current.setQuality("balanced"));
    act(() => result.current.fallback());
    expect(result.current.path).toBe(a.path);
    expect(result.current.usingProxy).toBe(false);
    expect(result.current.status).toContain("Proxy could not play");
    act(() => result.current.setQuality("original"));
    await act(async () => result.current.setQuality("balanced"));
    expect(result.current.path).toBe("/proxy.mp4");
    expect(generatePreviewProxy).toHaveBeenCalledTimes(2);
  });

  it("retries failed generation without leaking paths across quality changes", async () => {
    vi.mocked(generatePreviewProxy)
      .mockRejectedValueOnce(new Error("cancelled"))
      .mockResolvedValueOnce("/low.mp4");
    const a = media("a");
    const { result } = renderHook(() => usePreviewSource(a));
    await act(async () => result.current.setQuality("balanced"));
    expect(result.current.path).toBe(a.path);
    expect(result.current.status).toContain("cancelled");
    await act(async () => result.current.setQuality("low"));
    expect(result.current.path).toBe("/low.mp4");
    expect(vi.mocked(generatePreviewProxy).mock.calls.map((call) => call[1])).toEqual([
      "balanced",
      "low",
    ]);
  });
});
