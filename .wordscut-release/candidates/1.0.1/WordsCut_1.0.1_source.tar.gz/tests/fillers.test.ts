import { beforeEach, describe, expect, it } from "vitest";
import { addMediaWithTranscript, newProject, type Word } from "@/lib/edl";
import {
  OPT_IN_FILLERS,
  SAFE_FILLERS,
  fillerWordIds,
  findFillerMatches,
  normaliseFillerToken,
} from "@/lib/fillers";
import { useFillerStore } from "@/stores/fillerStore";
import { useProjectStore } from "@/stores/projectStore";

/** Build contiguous words from text; each lasts 0.3 s with 0.05 s gaps. */
function words(text: string): Word[] {
  let t = 0;
  return text.split(" ").map((tok, i) => {
    const w: Word = { id: `w${i}`, text: tok, start: t, end: t + 0.3, confidence: 1 };
    t += 0.35;
    return w;
  });
}

const ids = (m: { wordIds: string[] }[]) => m.map((x) => x.wordIds);

describe("filler lists", () => {
  it("keeps the default list to hesitation sounds, with real words opt-in", () => {
    for (const real of ["like", "so", "right", "actually", "literally", "basically", "okay"]) {
      expect(SAFE_FILLERS).not.toContain(real);
      expect(OPT_IN_FILLERS).toContain(real);
    }
    expect(SAFE_FILLERS).toEqual(
      expect.arrayContaining(["um", "uh", "er", "erm", "ah", "hmm", "mm", "mhm"]),
    );
  });

  it("normalises punctuation and case", () => {
    expect(normaliseFillerToken(" Um, ")).toBe("um");
  });
});

describe("findFillerMatches", () => {
  it("matches single-word fillers ignoring case and punctuation", () => {
    const m = findFillerMatches(words("So Um, the Uh. plan"), SAFE_FILLERS);
    expect(ids(m)).toEqual([["w1"], ["w3"]]);
  });

  it("does not match real words unless opted in", () => {
    const w = words("I like the right plan so far");
    expect(findFillerMatches(w, SAFE_FILLERS)).toEqual([]);
    expect(ids(findFillerMatches(w, ["like", "so"]))).toEqual([["w1"], ["w5"]]);
  });

  it("matches multi-word fillers on consecutive words", () => {
    const m = findFillerMatches(words("it is you know kind of fine"), ["you know", "kind of"]);
    expect(m.map((x) => x.phrase)).toEqual(["you know", "kind of"]);
    expect(ids(m)).toEqual([
      ["w2", "w3"],
      ["w4", "w5"],
    ]);
  });

  it("prefers the longer phrase and never overlaps matches", () => {
    const m = findFillerMatches(words("you know you"), ["you", "you know"]);
    expect(ids(m)).toEqual([["w0", "w1"], ["w2"]]);
  });

  it("does not match a phrase broken by punctuation or a long pause", () => {
    expect(findFillerMatches(words("you, know"), ["you know"])).toEqual([]);
    const w = words("you know");
    w[1] = { ...w[1]!, start: 5, end: 5.3 };
    expect(findFillerMatches(w, ["you know"])).toEqual([]);
  });

  it("returns nothing for an empty phrase set", () => {
    expect(findFillerMatches(words("um uh"), [])).toEqual([]);
  });
});

describe("fillerWordIds / deleteFillers", () => {
  beforeEach(() => {
    const media = {
      id: "m",
      path: "/tmp/m.mp4",
      duration: 10,
      fps: 30,
      width: 1920,
      height: 1080,
      audioSampleRate: 48000,
      sha256: "x",
    };
    useProjectStore.setState({
      project: addMediaWithTranscript(newProject("t"), media, words("so um you know it works")),
      dirty: false,
    });
  });

  it("highlight ids match exactly what deleteFillers removes", () => {
    const phrases = ["um", "you know"];
    const before = useProjectStore.getState().project;
    const highlighted = fillerWordIds(before.segments, phrases);
    expect([...highlighted].sort()).toEqual(["w1", "w2", "w3"]);

    expect(useProjectStore.getState().deleteFillers(phrases)).toBe(2);
    const left = useProjectStore
      .getState()
      .project.segments.flatMap((s) => s.words.map((w) => w.text));
    expect(left).toEqual(["so", "it", "works"]);
  });

  it("is a no-op when nothing matches", () => {
    const before = useProjectStore.getState().project;
    expect(useProjectStore.getState().deleteFillers(["hmm"])).toBe(0);
    expect(useProjectStore.getState().project).toBe(before);
    expect(useProjectStore.getState().dirty).toBe(false);
  });
});

describe("fillerStore", () => {
  it("selects only the safe fillers by default and toggles phrases", () => {
    expect([...useFillerStore.getState().selected].sort()).toEqual([...SAFE_FILLERS].sort());
    useFillerStore.getState().toggle("like");
    expect(useFillerStore.getState().selected.has("like")).toBe(true);
    useFillerStore.getState().toggle("like");
    expect(useFillerStore.getState().selected.has("like")).toBe(false);
  });
});
