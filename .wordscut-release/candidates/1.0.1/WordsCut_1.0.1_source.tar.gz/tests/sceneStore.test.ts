import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { newProject } from "@/lib/edl";
import { defaultScene } from "@/lib/scene";
import { useProjectStore } from "@/stores/projectStore";

describe("project scene", () => {
  beforeEach(() => {
    vi.useFakeTimers();
    useProjectStore.setState({ project: newProject("t"), dirty: false });
    useProjectStore.temporal.getState().clear();
  });
  afterEach(() => {
    vi.useRealTimers();
  });

  it("has no scene until one is set", () => {
    expect(useProjectStore.getState().project.scene).toBeUndefined();
  });

  it("the first change turns the scene on", () => {
    useProjectStore.getState().setScene({ paddingPct: 12 });
    const s = useProjectStore.getState().project.scene!;
    expect(s.enabled).toBe(true);
    expect(s.paddingPct).toBe(12);
    expect(useProjectStore.getState().dirty).toBe(true);
  });

  it("keeps the rest of the scene when one field changes", () => {
    useProjectStore.getState().setScene({ paddingPct: 12, aspect: "9:16" });
    useProjectStore.getState().setScene({ shadow: 0.2 });
    const s = useProjectStore.getState().project.scene!;
    expect(s.paddingPct).toBe(12);
    expect(s.aspect).toBe("9:16");
    expect(s.shadow).toBe(0.2);
  });

  it("can be switched off without losing its settings", () => {
    useProjectStore.getState().setScene({ radiusPct: 9 });
    useProjectStore.getState().setScene({ enabled: false });
    const s = useProjectStore.getState().project.scene!;
    expect(s.enabled).toBe(false);
    expect(s.radiusPct).toBe(9);
  });

  it("clamps and repairs bad values", () => {
    useProjectStore.getState().setScene({ paddingPct: 500, shadow: -1 });
    const s = useProjectStore.getState().project.scene!;
    expect(s.paddingPct).toBe(30);
    expect(s.shadow).toBe(0);
  });

  it("clearScene removes it, and is a no-op when there is none", () => {
    useProjectStore.getState().clearScene();
    expect(useProjectStore.getState().dirty).toBe(false);
    useProjectStore.getState().setScene({ paddingPct: 4 });
    useProjectStore.getState().clearScene();
    expect(useProjectStore.getState().project.scene).toBeUndefined();
    expect("scene" in useProjectStore.getState().project).toBe(false);
  });

  it("survives saving to JSON and loading back", () => {
    useProjectStore.getState().setScene({
      aspect: "1:1",
      background: { kind: "gradient", from: "#112233", to: "#445566", angle: 45 },
    });
    const round = JSON.parse(JSON.stringify(useProjectStore.getState().project));
    expect(round.scene).toEqual(useProjectStore.getState().project.scene);
  });

  it("is undoable", () => {
    useProjectStore.getState().setScene({ paddingPct: 20 });
    vi.advanceTimersByTime(200);
    useProjectStore.temporal.getState().undo();
    expect(useProjectStore.getState().project.scene).toBeUndefined();
  });

  it("starts from the defaults", () => {
    useProjectStore.getState().setScene({});
    expect(useProjectStore.getState().project.scene).toEqual({ ...defaultScene(), enabled: true });
  });
});
