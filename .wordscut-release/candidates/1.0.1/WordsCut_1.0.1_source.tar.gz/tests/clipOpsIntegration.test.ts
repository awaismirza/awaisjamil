// Integration (qa/integration-2): clip ops (duplicate/move) x captions, zoom,
// chapters, music, scene crop / transparent background.
import { describe, expect, it } from "vitest";
import {
  addChapter,
  addMediaWithTranscript,
  deleteWords,
  newProject,
  type Project,
  type SourceMedia,
  type Word,
} from "@/lib/edl";
import { duplicateClip, moveClip, rollEdit, splitClipAt, trimClipEdge } from "@/lib/clipEdit";
import type { Annotation } from "@/lib/annotations";
import { flattenWordsInOutputTime } from "@/lib/captions";
import { layoutProjectCaptions } from "@/lib/captionLayout";
import { DEFAULT_CAPTION_STYLE } from "@/lib/captionStyle";
import { sceneSourceMedia, type SceneSettings } from "@/lib/scene";

const media: SourceMedia = {
  id: "m",
  path: "/tmp/m.mp4",
  duration: 20,
  fps: 30,
  width: 1920,
  height: 1080,
  audioSampleRate: 48000,
  sha256: "x",
};
const words: Word[] = Array.from({ length: 20 }, (_, i) => ({
  id: `w${i}`,
  text: `w${i}`,
  start: i,
  end: i + 1,
  confidence: 1,
}));

const scene: SceneSettings = {
  enabled: true,
  aspect: "9:16",
  background: { kind: "transparent" },
  paddingPct: 5,
  radiusPct: 4,
  shadow: 0.5,
  crop: { x: 0.1, y: 0, w: 0.5, h: 1 },
};

/** Clips A [0,4) B [5,9) C [10,20) -> output A 0-4, B 4-8, C 8-18. */
function setup(): Project {
  let p = addMediaWithTranscript(newProject("t"), media, words);
  p = { ...p, settings: { ...p.settings, paddingMs: 0 } };
  p = deleteWords(p, new Set(["w4", "w9"]));
  p = addChapter(p, 8, "C starts");
  return {
    ...p,
    zoomRegions: [
      { id: "z", start: 4.5, end: 6, scale: 1.6, focusX: 0.5, focusY: 0.5, easeMs: 450 },
    ],
    audioTracks: [{ id: "t", mediaId: "music", gainDb: 0, offsetSec: 8, ducks: false }],
    scene,
    captions: DEFAULT_CAPTION_STYLE,
    annotations: [note("on-b", 4.5, 6)],
  };
}

function note(id: string, start: number, end: number): Annotation {
  return {
    id,
    kind: "box",
    start,
    end,
    x: 0.1,
    y: 0.1,
    w: 0.2,
    h: 0.2,
    color: "#ffffff",
    stroke: 4,
    fontSize: 48,
  };
}

describe("duplicate then move: output-time consumers follow clip order", () => {
  const p0 = setup();
  const dup = duplicateClip(p0, p0.segments[0]!.id); // A A' B C
  const out = moveClip(dup, dup.segments[1]!.id, dup.segments.length - 1); // A B C A'

  it("captions words and cues follow output order, monotonic and gapless", () => {
    expect(p0.segments).toHaveLength(3);
    const ow = flattenWordsInOutputTime(out);
    expect(ow.map((w) => w.word.text)).toEqual([
      ...["w0", "w1", "w2", "w3"],
      ...["w5", "w6", "w7", "w8"],
      ...words.slice(10).map((w) => w.text),
      ...["w0", "w1", "w2", "w3"],
    ]);
    ow.forEach((w, i) => {
      expect(w.start).toBeCloseTo(i, 9);
      expect(w.end).toBeCloseTo(i + 1, 9);
    });
    expect(new Set(ow.map((w) => w.word.id)).size).toBe(ow.length);

    const { cues } = layoutProjectCaptions(out, DEFAULT_CAPTION_STYLE);
    expect(cues.length).toBeGreaterThan(1);
    for (let i = 1; i < cues.length; i++)
      expect(cues[i]!.start).toBeGreaterThanOrEqual(cues[i - 1]!.end - 1e-9);
    expect(cues.at(-1)!.end).toBeCloseTo(22, 9);
    // The duplicate now plays last: its words are spoken from 18 s.
    const tail = cues.flatMap((c) => c.lines.flat()).filter((w) => w.start >= 18 - 1e-9);
    expect(tail.map((w) => w.text)).toEqual(["w0", "w1", "w2", "w3"]);
    expect(tail[0]!.start).toBeCloseTo(18, 9);
  });

  it("zoom, chapter and music shift on duplicate and come back after the move", () => {
    expect(dup.zoomRegions![0]!.start).toBeCloseTo(8.5, 9);
    expect(dup.chapters![0]!.outputTime).toBeCloseTo(12, 9);
    expect(dup.audioTracks![0]!.offsetSec).toBeCloseTo(12, 9);
    expect(out.zoomRegions![0]!.start).toBeCloseTo(4.5, 9);
    expect(out.zoomRegions![0]!.end).toBeCloseTo(6, 9);
    expect(out.chapters![0]!.outputTime).toBeCloseTo(8, 9);
    expect(out.audioTracks![0]!.offsetSec).toBeCloseTo(8, 9);
    expect(dup.annotations!.map((a) => [a.start, a.end])).toEqual([[8.5, 10]]);
    expect(out.annotations).toHaveLength(1);
    expect(out.annotations![0]!.start).toBeCloseTo(4.5, 9);
    expect(out.annotations![0]!.end).toBeCloseTo(6, 9);
  });

  it("scene crop, transparent background and caption style are untouched", () => {
    expect(dup.scene).toEqual(scene);
    expect(out.scene).toEqual(scene);
    expect(out.captions).toEqual(DEFAULT_CAPTION_STYLE);
    expect(sceneSourceMedia(out)?.id).toBe("m");
  });
});

describe("an annotation on a duplicated clip's copy stays on the copy", () => {
  // A [0,4) A' [4,8) B [8,12) C [12,22); the note sits on A' at 4.5-6 (A' source 0.5-2).
  const base = setup();
  const p0 = duplicateClip({ ...base, annotations: undefined }, base.segments[0]!.id);
  const [a, copy] = [p0.segments[0]!, p0.segments[1]!];
  const p = { ...p0, annotations: [note("n", 4.5, 6)] };
  const span = (q: Project) => q.annotations?.map((n) => [n.start, n.end]) ?? [];
  const expectSpan = (q: Project, start: number, end: number) => {
    expect(q.annotations).toHaveLength(1);
    expect(q.annotations![0]!.id).toBe("n");
    expect(q.annotations![0]!.start).toBeCloseTo(start, 9);
    expect(q.annotations![0]!.end).toBeCloseTo(end, 9);
  };

  it("is not cloned onto the original by the duplicate", () => {
    const again = duplicateClip(p, copy.id); // A A' A'' B C
    expectSpan(again, 4.5, 6);
  });

  it("follows word deletes in either clip and closes up over cuts", () => {
    expectSpan(deleteWords(p, new Set(["w0"])), 3.5, 5); // cut in the original: shifts left
    expectSpan(deleteWords(p, new Set([copy.words[0]!.id])), 4, 5); // cut under it: trimmed
    // A cut inside the note closes up: source 0.5-3.5 minus 2-3 is 2.5 s, one piece.
    const wide = { ...p, annotations: [note("n", 4.5, 7.5)] };
    expectSpan(deleteWords(wide, new Set([copy.words[2]!.id])), 4.5, 6.5);
  });

  it("is removed when all of its content is cut", () => {
    const q = deleteWords(p, new Set(copy.words.map((w) => w.id)));
    expect(q.annotations).toBeUndefined();
    // Deleting the original's words instead never touches the copy's note.
    expectSpan(deleteWords(p, new Set(a.words.map((w) => w.id))), 0.5, 2);
  });

  it("follows trim, roll and split of either clip", () => {
    expectSpan(trimClipEdge(p, copy.id, "start", 1), 4, 5);
    expectSpan(trimClipEdge(p, a.id, "end", 3), 3.5, 5);
    const rolled = rollEdit(p, copy.id, -1); // A' ends at 3, B starts 1 s earlier
    expect(rolled).not.toBe(p);
    expectSpan(rolled, 4.5, 6);
    const split = splitClipAt(p, 5);
    expect(split.segments).toHaveLength(5);
    expectSpan(split, 4.5, 6);
    expectSpan(splitClipAt(p, 2), 4.5, 6); // splitting the original
  });

  it("moves with the copy, not with the original", () => {
    expectSpan(moveClip(p, copy.id, 3), 18.5, 20); // A B C A'
    expectSpan(moveClip(p, a.id, 3), 0.5, 2); // A' B C A
    expect(span(moveClip(moveClip(p, copy.id, 3), copy.id, 1))).toEqual([[4.5, 6]]);
  });
});
