import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { AgentConnectDialog } from "@/components/Agent/AgentConnectDialog";
import type { ServerInfo } from "@/lib/agent/protocol";
import * as ipc from "@/lib/agent/serverIpc";

vi.mock("@/lib/agent/serverIpc", () => ({
  agentServerInfo: vi.fn(),
  agentSetEnabled: vi.fn(),
  agentRegenerateToken: vi.fn(),
}));

const BIN = "/Apps/WordsCut.app/Contents/MacOS/WordsCut";
const base: ServerInfo = {
  available: true,
  unavailableReason: null,
  enabled: true,
  running: true,
  port: 5555,
  mcpUrl: "http://127.0.0.1:5555/mcp",
  token: "secret-token-value",
  binaryPath: BIN,
  connectionFile: "/x/connection.json",
  appVersion: "4.27.0",
};

const writeText = vi.fn().mockResolvedValue(undefined);

beforeEach(() => {
  Object.assign(navigator, { clipboard: { writeText } });
  writeText.mockClear();
});
afterEach(() => {
  cleanup();
  vi.clearAllMocks();
});

const show = async (info: ServerInfo) => {
  vi.mocked(ipc.agentServerInfo).mockResolvedValue(info);
  render(<AgentConnectDialog open onOpenChange={() => {}} />);
  await waitFor(() => expect(screen.getByTestId("agent-status")).not.toHaveTextContent("Loading"));
};

describe("AgentConnectDialog", () => {
  it("shows Running, Off and Unavailable", async () => {
    await show(base);
    expect(screen.getByTestId("agent-status")).toHaveTextContent("Running · 127.0.0.1:5555");
    cleanup();
    await show({ ...base, enabled: false, running: false, port: null, token: null });
    expect(screen.getByTestId("agent-status")).toHaveTextContent("Off");
    cleanup();
    await show({
      ...base,
      available: false,
      enabled: false,
      running: false,
      unavailableReason: "No MAS",
    });
    expect(screen.getByTestId("agent-status")).toHaveTextContent("Unavailable");
    expect(screen.getByRole("switch")).toBeDisabled();
  });

  it("toggle calls agent_set_enabled", async () => {
    await show(base);
    vi.mocked(ipc.agentSetEnabled).mockResolvedValue({ ...base, enabled: false, running: false });
    fireEvent.click(screen.getByRole("switch"));
    await waitFor(() => expect(ipc.agentSetEnabled).toHaveBeenCalledWith(false));
    await waitFor(() => expect(screen.getByTestId("agent-status")).toHaveTextContent("Off"));
  });

  it("copies the start command and binary path", async () => {
    await show(base);
    fireEvent.click(screen.getByRole("button", { name: "Copy Start here" }));
    expect(writeText).toHaveBeenCalledWith(`"${BIN}" agent readme`);
    fireEvent.click(screen.getByRole("button", { name: "Copy Binary path" }));
    expect(writeText).toHaveBeenCalledWith(BIN);
  });

  it("copies MCP snippets and masks the token until revealed", async () => {
    await show(base);
    fireEvent.click(screen.getByRole("tab", { name: /MCP/ }));
    fireEvent.click(screen.getByRole("button", { name: "Copy Terminal" }));
    expect(writeText).toHaveBeenCalledWith(`claude mcp add yusafcut -- "${BIN}" mcp`);

    fireEvent.click(screen.getByRole("tab", { name: "Other (HTTP)" }));
    expect(screen.getByTestId("agent-token")).not.toHaveTextContent("secret-token-value");
    fireEvent.click(screen.getByRole("button", { name: /Reveal/ }));
    expect(screen.getByTestId("agent-token")).toHaveTextContent("secret-token-value");
    fireEvent.click(screen.getByRole("button", { name: "Copy header" }));
    expect(writeText).toHaveBeenLastCalledWith("Authorization: Bearer secret-token-value");
  });
});
