import { beforeEach, describe, expect, it } from "vitest";
import { parseCursorLog } from "@/lib/cursor";
import { sanitizeProjectCursor } from "@/lib/cursorStyle";
import { addMediaWithTranscript, newProject } from "@/lib/edl";
import type { RecordOptions, RecordingDevices } from "@/lib/ipc";
import { countKeyNames, keystrokeCaptions, captionLabel, stripKeyNames } from "@/lib/keystrokes";
import { OPTS_STORAGE_KEY, loadStoredOpts, persistOpts } from "@/lib/recorderOpts";
import { requiredPermissions, startBlocker } from "@/lib/recorderSetup";
import { defaultShortcuts } from "@/lib/shortcuts";
import { trayModel } from "@/lib/trayModel";

describe("recorder options storage", () => {
  beforeEach(() => window.localStorage.clear());

  it("never stores 'all characters', but keeps 'key names' across launches", () => {
    persistOpts({ mode: "screen", recordKeyIdentity: true, recordAllCharacters: true });
    const raw = JSON.parse(window.localStorage.getItem(OPTS_STORAGE_KEY)!) as RecordOptions;
    expect(raw.recordKeyIdentity).toBe(true);
    expect("recordAllCharacters" in raw).toBe(false);
    // An older stored value is ignored on load too.
    window.localStorage.setItem(
      OPTS_STORAGE_KEY,
      JSON.stringify({ mode: "screen", recordKeyIdentity: true, recordAllCharacters: true }),
    );
    const loaded = loadStoredOpts();
    expect(loaded.recordKeyIdentity).toBe(true);
    expect(loaded.recordAllCharacters).toBeUndefined();
  });
});

describe("Input Monitoring for key names", () => {
  const devices = {
    backend: "native",
    video: [{ index: 1000, name: "Display", isScreen: true }],
    audio: [],
    permissions: { screenRecording: "granted", inputMonitoring: "denied" },
  } as unknown as RecordingDevices;
  const opts: RecordOptions = { mode: "screen", screenIndex: 1000, recordKeyIdentity: true };

  it("is required and its denial blocks Start with a clear sentence", () => {
    expect(requiredPermissions(opts)).toContain("inputMonitoring");
    expect(startBlocker(opts, devices, null)).toMatch(/key names cannot be recorded/);
    expect(startBlocker({ ...opts, recordKeyIdentity: false }, devices, null)).toBeNull();
  });
});

describe("recording indicator", () => {
  it("shows Key names ON / All characters ON in the menu-bar title and tooltip", () => {
    const base = {
      phase: "recording" as const,
      elapsedSec: 5,
      countdown: 0,
      shortcuts: defaultShortcuts(),
    };
    expect(trayModel(base).title).toBe("● 00:05");
    expect(trayModel({ ...base, keyNames: "names" }).title).toBe("● 00:05 · Key names ON");
    expect(trayModel({ ...base, keyNames: "all" }).tooltip).toBe(
      "Recording 00:05 · All characters ON",
    );
    expect(trayModel({ ...base, phase: "paused", keyNames: "names" }).tooltip).toMatch(
      /Key names ON/,
    );
  });
});

describe("strip key names", () => {
  it("removes name and secure from key events only, and is a no-op without any", () => {
    const p0 = addMediaWithTranscript(
      newProject("k"),
      {
        id: "m",
        path: "/x.mp4",
        duration: 10,
        fps: 30,
        width: 1920,
        height: 1080,
        audioSampleRate: 48000,
        sha256: "",
      },
      [],
    );
    const log = [
      '{"type":"key","t":1,"mods":["cmd"],"name":"k"}',
      '{"type":"key","t":2,"secure":true}',
      '{"type":"move","t":3,"x":0.5,"y":0.5}',
    ].join("\n");
    const p = {
      ...p0,
      cursor: { ...sanitizeProjectCursor(undefined), tracks: { m: parseCursorLog(log) } },
    };
    expect(countKeyNames(p)).toBe(2);
    const out = stripKeyNames(p);
    expect(countKeyNames(out)).toBe(0);
    expect(out.cursor!.tracks.m!.events).toEqual([
      { type: "key", t: 1, mods: ["cmd"] },
      { type: "key", t: 2, mods: [] },
      expect.objectContaining({ type: "move", t: 3 }),
    ]);
    expect(stripKeyNames(out)).toBe(out);
    const caps = keystrokeCaptions(out, { enabled: true, mode: "shortcuts" });
    expect(caps.map(captionLabel)).toEqual(["⌘ key"]);
  });
});
