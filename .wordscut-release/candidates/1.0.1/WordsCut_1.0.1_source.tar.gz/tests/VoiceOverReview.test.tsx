import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@tauri-apps/api/core", async (orig) => ({
  ...(await orig<typeof import("@tauri-apps/api/core")>()),
  convertFileSrc: (p: string) => `asset://${p}`,
}));

import { VoiceOverReviewDialog } from "@/components/Recorder/VoiceOver";
import { newProject, type Project } from "@/lib/edl";
import { defaultSettings } from "@/lib/settings";
import { useProjectStore } from "@/stores/projectStore";
import { useSettingsStore } from "@/stores/settingsStore";
import {
  resetVoiceOverForTests,
  useVoiceOverStore,
  type VoiceOverDraft,
} from "@/stores/voiceOverStore";

function project(): Project {
  return {
    ...newProject("p"),
    id: "p",
    media: {
      m: {
        id: "m",
        path: "/v.mp4",
        duration: 10,
        fps: 30,
        width: 1,
        height: 1,
        audioSampleRate: 48000,
        sha256: "m",
      },
    },
    segments: [{ id: "s", mediaId: "m", sourceIn: 0, sourceOut: 10, words: [] }],
  };
}
const draft: VoiceOverDraft = {
  id: "d",
  projectId: "p",
  projectName: "p",
  anchor: { outputTime: 9, segmentId: "s", mediaId: "m", sourceTime: 9 },
  sessionId: "S",
  path: "/rec/rec-S/take.m4a",
  durationSec: 2.5,
  mode: "overlay",
  overrideOriginal: false,
};

describe("voice-over review dialog: keyboard only", () => {
  let keep: ReturnType<typeof vi.fn>;
  let discard: ReturnType<typeof vi.fn>;
  let retake: ReturnType<typeof vi.fn>;
  beforeEach(() => {
    resetVoiceOverForTests();
    useSettingsStore.setState(defaultSettings());
    useProjectStore.setState({ project: project() });
    keep = vi.fn(async () => {});
    discard = vi.fn(async () => {});
    retake = vi.fn(async () => {});
    useVoiceOverStore.setState({
      phase: "review",
      draft,
      pending: [draft],
      reviewOpen: true,
      keep,
      discard,
      retake,
    });
  });
  afterEach(cleanup);

  const press = (code: string, key?: string) =>
    fireEvent.keyDown(screen.getByRole("dialog"), { code, key: key ?? code });

  it("M switches placement, O toggles override, Return keeps, R retakes, D discards", () => {
    render(<VoiceOverReviewDialog />);
    // Overflow is shown explicitly: 9 s + 2.5 s on a 10 s video.
    expect(screen.getByRole("alert").textContent).toMatch(/1\.5 s runs past the end/);
    press("KeyM", "m");
    expect(useVoiceOverStore.getState().draft!.mode).toBe("insert");
    press("KeyO", "o");
    expect(useVoiceOverStore.getState().draft!.overrideOriginal).toBe(true);
    // The choice is per draft and saved with the pending take.
    expect(useVoiceOverStore.getState().pending[0]!.overrideOriginal).toBe(true);
    press("Enter");
    expect(keep).toHaveBeenCalledTimes(1);
    press("KeyR", "r");
    expect(retake).toHaveBeenCalledTimes(1);
    const ok = vi.spyOn(window, "confirm").mockReturnValue(true);
    press("KeyD", "d");
    expect(ok).toHaveBeenCalledTimes(1);
    ok.mockRestore();
    expect(discard).toHaveBeenCalledTimes(1);
  });

  it("D asks before deleting a real take; a tiny take goes without asking", () => {
    const confirm = vi.spyOn(window, "confirm").mockReturnValue(false);
    render(<VoiceOverReviewDialog />);
    press("KeyD", "d");
    expect(confirm).toHaveBeenCalledTimes(1);
    expect(discard).not.toHaveBeenCalled();
    cleanup();
    confirm.mockClear();
    useVoiceOverStore.setState({ draft: { ...draft, durationSec: 1 } });
    render(<VoiceOverReviewDialog />);
    press("KeyD", "d");
    expect(confirm).not.toHaveBeenCalled();
    expect(discard).toHaveBeenCalledTimes(1);
    confirm.mockRestore();
  });

  it("Return and Space on a focused control act on that control, not Keep / Play", () => {
    vi.spyOn(window, "confirm").mockReturnValue(true);
    render(<VoiceOverReviewDialog />);
    const discardButton = screen.getByRole("button", { name: /Discard/ });
    discardButton.focus();
    fireEvent.keyDown(discardButton, { key: "Enter", code: "Enter" });
    expect(keep).not.toHaveBeenCalled();
    fireEvent.click(discardButton); // what the browser does for Return on a button
    expect(discard).toHaveBeenCalledTimes(1);
    const box = screen.getByRole("checkbox");
    fireEvent.keyDown(box, { key: " ", code: "Space" });
    expect(useVoiceOverStore.getState().draft!.overrideOriginal).toBe(false); // not hijacked
    // With the dialog itself focused, Return keeps.
    fireEvent.keyDown(screen.getByRole("dialog"), { key: "Enter", code: "Enter" });
    expect(keep).toHaveBeenCalledTimes(1);
    vi.restoreAllMocks();
  });

  it("Escape closes the review and keeps the take pending", () => {
    render(<VoiceOverReviewDialog />);
    fireEvent.keyDown(screen.getByRole("dialog"), { key: "Escape", code: "Escape" });
    expect(useVoiceOverStore.getState().reviewOpen).toBe(false);
    expect(useVoiceOverStore.getState().pending).toHaveLength(1);
    expect(discard).not.toHaveBeenCalled();
  });

  it("explains that a mixed recording cannot be separated, and never promises isolated narration", () => {
    render(<VoiceOverReviewDialog />);
    const text = screen.getByRole("dialog").textContent ?? "";
    expect(text).toMatch(/cannot be separated automatically/);
    expect(text).not.toMatch(/isolat/i);
  });
});
