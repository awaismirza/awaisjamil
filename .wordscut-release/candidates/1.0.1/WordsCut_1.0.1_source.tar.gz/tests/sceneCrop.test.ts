import { describe, expect, it } from "vitest";
import { buildExportOptions, transparencyWarning } from "@/lib/exportOptions";
import {
  cropForRatio,
  cropPixels,
  defaultScene,
  resolveSceneForExport,
  sanitizeCrop,
  sanitizeScene,
  sceneLayout,
  sceneSourceMedia,
  sceneTransparent,
  type SceneSettings,
} from "@/lib/scene";
import { backgroundCss, sceneCss } from "@/lib/sceneCss";
import { makeProject } from "./agent/helpers";

const SRC = { w: 1920, h: 1080 };
const scene = (patch: Partial<SceneSettings> = {}): SceneSettings => ({
  ...defaultScene(),
  enabled: true,
  ...patch,
});

describe("crop sanitising", () => {
  it("drops missing, malformed and full-frame crops", () => {
    expect(sanitizeCrop(undefined)).toBeUndefined();
    expect(sanitizeCrop({ x: 0, y: 0, w: "1", h: 1 })).toBeUndefined();
    expect(sanitizeCrop({ x: 0, y: 0, w: 1, h: 1 })).toBeUndefined();
    expect(sanitizeCrop({ x: NaN, y: 0, w: 0.5, h: 0.5 })).toBeUndefined();
  });

  it("keeps the rectangle inside the frame and above the minimum size", () => {
    expect(sanitizeCrop({ x: 0.9, y: -1, w: 0.5, h: 0.001 })).toEqual({
      x: 0.5,
      y: 0,
      w: 0.5,
      h: 0.05,
    });
  });

  it("old projects without a crop load unchanged", () => {
    const s = sanitizeScene({ enabled: true, aspect: "9:16" });
    expect("crop" in s).toBe(false);
    expect(sanitizeScene({ enabled: true, crop: { x: 0.25, y: 0, w: 0.5, h: 1 } }).crop).toEqual({
      x: 0.25,
      y: 0,
      w: 0.5,
      h: 1,
    });
  });
});

describe("crop geometry", () => {
  it("snaps to even whole pixels inside the source", () => {
    const px = cropPixels({ x: 0.333, y: 0.1, w: 0.5, h: 0.9 }, SRC);
    for (const v of Object.values(px)) expect(v % 2).toBe(0);
    expect(px.x + px.w).toBeLessThanOrEqual(1920);
    expect(px.y + px.h).toBeLessThanOrEqual(1080);
  });

  it("layout treats the cropped size as the source (orientation and aspect follow it)", () => {
    const crop = cropForRatio(9 / 16, SRC)!;
    const l = sceneLayout(scene({ crop, paddingPct: 0, radiusPct: 0 }), SRC);
    expect(l.crop).toEqual(cropPixels(crop, SRC));
    expect(l.canvasW).toBeLessThan(l.canvasH);
    expect(l.canvasW).toBe(l.crop!.w);
    expect(l.content).toMatchObject({ x: 0, y: 0, w: l.canvasW, h: l.canvasH });
  });

  it("a square crop letterboxes into a 16:9 canvas, centred", () => {
    const l = sceneLayout(
      scene({ crop: cropForRatio(1, SRC)!, aspect: "16:9", paddingPct: 0 }),
      SRC,
    );
    expect(l.content.w).toBe(l.content.h);
    expect(l.content.x).toBe(Math.round((l.canvasW - l.content.w) / 2));
  });

  it("presets give the exact ratio centred, and nothing when already that ratio", () => {
    const c = cropForRatio(1, SRC)!;
    expect(c.x).toBeCloseTo((1 - 1080 / 1920) / 2, 6);
    expect((c.w * 1920) / (c.h * 1080)).toBeCloseTo(1, 6);
    expect(cropForRatio(16 / 9, SRC)).toBeNull();
  });
});

describe("preview and export agree on the crop", () => {
  const s = scene({ crop: { x: 0.25, y: 0.1, w: 0.5, h: 0.6 }, paddingPct: 6, aspect: "1:1" });

  it("export payload carries the same pixel rect the layout uses", () => {
    const r = resolveSceneForExport(s, SRC);
    expect(r.crop).toEqual(sceneLayout(s, SRC).crop);
    expect(r.crop).toEqual(cropPixels(s.crop!, SRC));
  });

  it("the preview's crop layer maps the kept pixels onto the content box exactly", () => {
    const css = sceneCss(s, SRC);
    const px = cropPixels(s.crop!, SRC);
    const num = (v: unknown) => parseFloat(String(v)) / 100;
    expect(num(css.crop!.width)).toBeCloseTo(SRC.w / px.w, 3);
    expect(num(css.crop!.height)).toBeCloseTo(SRC.h / px.h, 3);
    expect(num(css.crop!.left)).toBeCloseTo(-px.x / px.w, 3);
    expect(num(css.crop!.top)).toBeCloseTo(-px.y / px.h, 3);
  });

  it("no crop means no crop layer and no crop in the payload", () => {
    expect(sceneCss(scene(), SRC).crop).toBeNull();
    expect(resolveSceneForExport(scene(), SRC).crop).toBeUndefined();
  });
});

describe("transparent background", () => {
  const transparent = scene({ background: { kind: "transparent" } });

  it("sanitises, resolves and previews as a checkerboard", () => {
    expect(sanitizeScene(transparent).background).toEqual({ kind: "transparent" });
    expect(resolveSceneForExport(transparent, SRC).background).toEqual({ kind: "transparent" });
    expect(String(backgroundCss({ kind: "transparent" }).background)).toContain("conic-gradient");
    expect(String(sceneCss(transparent, SRC).stage.background)).toContain("conic-gradient");
  });

  it("is only transparent when the scene is on", () => {
    expect(sceneTransparent(transparent)).toBe(true);
    expect(sceneTransparent({ ...transparent, enabled: false })).toBe(false);
    expect(sceneTransparent(scene())).toBe(false);
  });

  it("warns for formats that would flatten it, and not for ProRes 4444 or audio", () => {
    const p = { ...makeProject("a b c", 10), scene: transparent };
    for (const f of ["mp4", "mov", "prores-422", "prores-422-hq", "gif"] as const)
      expect(transparencyWarning(p, f), f).toMatch(/black background/);
    expect(transparencyWarning(p, "prores-4444")).toBeNull();
    expect(transparencyWarning(p, "wav")).toBeNull();
    expect(transparencyWarning({ ...p, scene: scene() }, "mp4")).toBeNull();
    expect(transparencyWarning(makeProject("a b", 10), "mp4")).toBeNull();
  });

  it("the export request carries the format and the transparent scene", () => {
    const p = { ...makeProject("a b c", 10), scene: transparent };
    const o = buildExportOptions(
      p,
      {
        resolution: "original",
        customWidth: 0,
        customHeight: 0,
        codec: "auto",
        format: "prores-4444",
      },
      "/o/x.mov",
    );
    expect(o.format).toBe("prores-4444");
    expect(o.scene?.background).toEqual({ kind: "transparent" });
  });
});

describe("the scene source is the first segment's media", () => {
  it("export sizes the crop from it, not from the first import", () => {
    const base = makeProject("a b c", 10);
    const seg = base.segments[0]!;
    const first = Object.values(base.media)[0]!;
    const project = {
      ...base,
      media: {
        imported: { ...first, id: "imported", width: 1920, height: 1080 },
        used: { ...first, id: "used", width: 1280, height: 720 },
      },
      segments: [{ ...seg, mediaId: "used" }],
      scene: scene({ crop: { x: 0.5, y: 0, w: 0.5, h: 1 } }),
    };
    expect(sceneSourceMedia(project)?.id).toBe("used");
    const o = buildExportOptions(
      project,
      { resolution: "original", customWidth: 0, customHeight: 0, codec: "auto" },
      "/o/x.mp4",
    );
    expect(o.scene?.crop).toEqual({ x: 640, y: 0, w: 640, h: 720 });
  });
});
