import { afterEach, expect, it } from "vitest";
import {
  diagnosticsReport,
  recordTiming,
  resetDiagnostics,
  setDiagnosticsEnabled,
} from "@/lib/playbackDiagnostics";
afterEach(() => {
  setDiagnosticsEnabled(false);
  resetDiagnostics();
});
it("is opt-in, bounded and reports percentiles without content", () => {
  recordTiming("seek", 999);
  expect(diagnosticsReport().metrics).toEqual({});
  setDiagnosticsEnabled(true);
  for (let i = 1; i <= 100; i++) recordTiming("seek", i);
  expect(diagnosticsReport().metrics.seek).toEqual({ count: 100, p50: 50, p95: 95, max: 100 });
  for (let i = 0; i < 10000; i++) recordTiming("frameWork", i);
  expect(diagnosticsReport().metrics.frameWork.count).toBeLessThanOrEqual(4096);
  recordTiming("cut", NaN);
  expect(diagnosticsReport().metrics.cut).toBeUndefined();
});
