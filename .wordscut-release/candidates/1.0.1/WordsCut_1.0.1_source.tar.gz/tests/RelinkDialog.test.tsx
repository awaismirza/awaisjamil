import { act, cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const ipc = vi.hoisted(() => ({ relinkMedia: vi.fn(), findMissingMedia: vi.fn() }));
const dialog = vi.hoisted(() => ({ open: vi.fn() }));
vi.mock("@/lib/ipc", () => ipc);
vi.mock("@tauri-apps/plugin-dialog", () => dialog);

import { RelinkDialog } from "@/components/RelinkDialog";
import { addMediaWithTranscript, newProject, type SourceMedia } from "@/lib/edl";
import { checkMissingMedia, missingSources, relinkErrorMessage } from "@/lib/relink";
import { useProjectStore } from "@/stores/projectStore";
import { useRelinkStore } from "@/stores/relinkStore";

const media = (id: string, path: string): SourceMedia => ({
  id,
  path,
  duration: 12,
  fps: 30,
  width: 1280,
  height: 720,
  audioSampleRate: 48000,
  sha256: `sha-${id}`,
});

function load() {
  let p = newProject("p");
  p = addMediaWithTranscript(p, media("a", "/gone/a.mp4"), []);
  p = addMediaWithTranscript(p, media("b", "/here/b.mp4"), []);
  p = addMediaWithTranscript(p, media("c", "/gone/c.mp4"), []);
  useProjectStore.setState({ project: p });
  useProjectStore.temporal.getState().clear();
  return p;
}

beforeEach(() => {
  ipc.relinkMedia.mockReset();
  ipc.findMissingMedia.mockReset();
  dialog.open.mockReset();
  useRelinkStore.getState().clear();
});
afterEach(cleanup);

describe("missingSources / relinkErrorMessage", () => {
  it("picks the media whose path is reported missing, in path order", () => {
    const p = load();
    expect(missingSources(p, ["/gone/c.mp4", "/gone/a.mp4"]).map((m) => m.id)).toEqual(["a", "c"]);
    expect(missingSources(p, [])).toEqual([]);
  });

  it("strips Error prefixes and falls back to a sentence", () => {
    expect(relinkErrorMessage(new Error("Error: length differs"))).toBe("length differs");
    expect(relinkErrorMessage("boom")).toBe("boom");
    expect(relinkErrorMessage("")).toBe("That file could not be used.");
  });
});

describe("checkMissingMedia", () => {
  it("records the missing sources of the open project", async () => {
    const p = load();
    ipc.findMissingMedia.mockResolvedValue(["/gone/a.mp4", "/gone/c.mp4"]);
    await checkMissingMedia(p);
    expect(ipc.findMissingMedia).toHaveBeenCalledWith(
      expect.arrayContaining(["/gone/a.mp4", "/here/b.mp4", "/gone/c.mp4"]),
    );
    expect(useRelinkStore.getState().missingIds.sort()).toEqual(["a", "c"]);
  });

  it("stays quiet when nothing is missing or the check fails", async () => {
    const p = load();
    ipc.findMissingMedia.mockResolvedValue([]);
    await checkMissingMedia(p);
    expect(useRelinkStore.getState().missingIds).toEqual([]);
    ipc.findMissingMedia.mockRejectedValue(new Error("nope"));
    await expect(checkMissingMedia(p)).resolves.toEqual([]);
  });

  it("ignores the result when another project was opened meanwhile", async () => {
    const p = load();
    let release: (v: string[]) => void = () => {};
    ipc.findMissingMedia.mockReturnValue(new Promise((r) => (release = r)));
    const pending = checkMissingMedia(p);
    useProjectStore.setState({ project: newProject("other") });
    release(["/gone/a.mp4"]);
    await pending;
    expect(useRelinkStore.getState().missingIds).toEqual([]);
  });
});

describe("RelinkDialog", () => {
  async function openWithMissing() {
    const p = load();
    ipc.findMissingMedia.mockResolvedValue(["/gone/a.mp4", "/gone/c.mp4"]);
    render(<RelinkDialog />);
    await act(async () => {
      await checkMissingMedia(p);
    });
    return p;
  }

  it("lists each missing source with a Locate button and not the present ones", async () => {
    await openWithMissing();
    expect(screen.getByText("a.mp4")).toBeTruthy();
    expect(screen.getByText("c.mp4")).toBeTruthy();
    expect(screen.queryByText("b.mp4")).toBeNull();
    expect(screen.getAllByRole("button", { name: /^Locate / })).toHaveLength(2);
  });

  it("is not shown when nothing is missing", () => {
    load();
    render(<RelinkDialog />);
    expect(screen.queryByText("Some media is missing")).toBeNull();
  });

  it("relinks a file the backend accepts and drops it from the list", async () => {
    const p = await openWithMissing();
    dialog.open.mockResolvedValue("/new/a.mp4");
    ipc.relinkMedia.mockResolvedValue({ ...media("a", "/new/a.mp4") });
    fireEvent.click(screen.getByRole("button", { name: "Locate a.mp4" }));
    await waitFor(() => expect(screen.queryByText("a.mp4")).toBeNull());
    expect(ipc.relinkMedia).toHaveBeenCalledWith("/new/a.mp4", p.media.a);
    expect(useProjectStore.getState().project.media.a!.path).toBe("/new/a.mp4");
    expect(screen.getByText("c.mp4")).toBeTruthy();
  });

  it("refuses a mismatching file, shows the reason and leaves the project alone", async () => {
    await openWithMissing();
    dialog.open.mockResolvedValue("/other/take2.mp4");
    ipc.relinkMedia.mockRejectedValue(
      new Error("This is not the original file: length is 30.00 s but the project expects 12.00 s."),
    );
    fireEvent.click(screen.getByRole("button", { name: "Locate a.mp4" }));
    const alert = await screen.findByRole("alert");
    expect(alert.textContent).toContain("not the original file");
    expect(useProjectStore.getState().project.media.a!.path).toBe("/gone/a.mp4");
    expect(screen.getByText("a.mp4")).toBeTruthy();
  });

  it("cancelling the file picker changes nothing and never calls the backend", async () => {
    await openWithMissing();
    dialog.open.mockResolvedValue(null);
    fireEvent.click(screen.getByRole("button", { name: "Locate a.mp4" }));
    await waitFor(() => expect(dialog.open).toHaveBeenCalled());
    expect(ipc.relinkMedia).not.toHaveBeenCalled();
    expect(screen.queryByRole("alert")).toBeNull();
    expect(useProjectStore.getState().project.media.a!.path).toBe("/gone/a.mp4");
  });

  it("Skip for now closes the dialog without touching the project", async () => {
    await openWithMissing();
    const before = useProjectStore.getState().project;
    fireEvent.click(screen.getByRole("button", { name: "Skip for now" }));
    await waitFor(() => expect(screen.queryByText("Some media is missing")).toBeNull());
    expect(useProjectStore.getState().project).toBe(before);
  });

  it("forgets errors and the old list when another project opens", async () => {
    await openWithMissing();
    dialog.open.mockResolvedValue("/other/take2.mp4");
    ipc.relinkMedia.mockRejectedValue(new Error("This is not the original file."));
    fireEvent.click(screen.getByRole("button", { name: "Locate a.mp4" }));
    await screen.findByRole("alert");
    act(() => useProjectStore.setState({ project: newProject("next") }));
    await waitFor(() => expect(screen.queryByRole("alert")).toBeNull());
    expect(useRelinkStore.getState().missingIds).toEqual([]);
  });

  it("a relink is not an undo step and undo never re-breaks the path", async () => {
    await openWithMissing();
    useProjectStore.getState().rename("renamed"); // an undoable edit before the relink
    dialog.open.mockResolvedValue("/new/a.mp4");
    ipc.relinkMedia.mockResolvedValue(media("a", "/new/a.mp4"));
    fireEvent.click(screen.getByRole("button", { name: "Locate a.mp4" }));
    await waitFor(() => expect(screen.queryByText("a.mp4")).toBeNull());
    act(() => useProjectStore.temporal.getState().undo());
    expect(useProjectStore.getState().project.name).toBe("p");
    expect(useProjectStore.getState().project.media.a!.path).toBe("/new/a.mp4");
  });
});
