import { describe, expect, it } from "vitest";
import {
  addChapter,
  computeTimeline,
  entrySourceAt,
  insertOwnedHold,
  MAX_HOLD_SEC,
  segmentHold,
  setSegmentTiming,
  newProject,
  removeAudioTrack,
  totalDuration,
  updateAudioTrack,
  type Project,
  type Segment,
  type SourceMedia,
  type Word,
} from "@/lib/edl";
import {
  addVoiceOverTake,
  captureAnchor,
  insertHoldAt,
  originalAudioGainAt,
  resolveAnchor,
  setVoiceOverMode,
  voiceOverOverflow,
} from "@/lib/voiceover";
import { envelopeGain, previewVoices, replacementIntervals, suppressorsOf } from "@/lib/audioMix";
import { flattenWordsInOutputTime, MAX_TAKE_WORDS } from "@/lib/captions";
import { deleteClip, duplicateClip } from "@/lib/clipEdit";
import fixture from "./fixtures/voiceoverProject.json";

const media = (id: string, duration: number, extra: Partial<SourceMedia> = {}): SourceMedia => ({
  id,
  path: `/${id}`,
  duration,
  fps: 30,
  width: 1280,
  height: 720,
  audioSampleRate: 48000,
  sha256: id,
  ...extra,
});
const take = (duration = 3) =>
  media("take", duration, { path: "/take.m4a", fps: 0, width: 0, height: 0 });
const word = (id: string, start: number, end: number): Word => ({
  id,
  text: id,
  start,
  end,
  confidence: 1,
});

/** One 10 s clip of media m with a word every second. */
function base(): Project {
  const p = newProject("vo");
  return {
    ...p,
    media: { m: media("m", 10) },
    segments: [
      {
        id: "s",
        mediaId: "m",
        sourceIn: 0,
        sourceOut: 10,
        words: Array.from({ length: 10 }, (_, i) => word(`w${i}`, i, i + 0.5)),
      },
    ],
  };
}

/** Source frame (media, time) shown at output time t. */
function frameAt(p: Project, t: number): [string, number] | null {
  const e = computeTimeline(p).find((x) => t >= x.outputStart && t < x.outputEnd);
  return e ? [e.mediaId, entrySourceAt(e, t)] : null;
}

describe("insert: the anchor frame is held for the take, later content moves by its length", () => {
  it("splits at the anchor and holds the frame there", () => {
    const p = addChapter(base(), 6, "later");
    const { project, id } = addVoiceOverTake(p, {
      media: take(3),
      at: 4,
      mode: "insert",
      overrideOriginal: false,
    });
    expect(totalDuration(project)).toBeCloseTo(13);
    const t = project.audioTracks!.find((x) => x.id === id)!;
    expect(t).toMatchObject({ kind: "voiceover", mode: "insert", offsetSec: 4, insertSec: 3 });
    // During the take the picture is the anchor frame; afterwards it resumes there.
    for (const x of [4, 5.5, 6.99]) expect(frameAt(project, x)).toEqual(["m", 4]);
    expect(frameAt(project, 7)).toEqual(["m", 4]);
    expect(frameAt(project, 8)?.[1]).toBeCloseTo(5);
    // Chapters and captions follow the timeline.
    expect(project.chapters?.[0]!.outputTime).toBeCloseTo(9);
    const w6 = flattenWordsInOutputTime(project).find((w) => w.word.id === "w6")!;
    expect(w6.start).toBeCloseTo(9);
    const w2 = flattenWordsInOutputTime(project).find((w) => w.word.id === "w2")!;
    expect(w2.start).toBeCloseTo(2);
  });

  it("at the end holds the last frame; on a cut holds the clip that ends there", () => {
    const end = addVoiceOverTake(base(), {
      media: take(2),
      at: 10,
      mode: "insert",
      overrideOriginal: false,
    });
    expect(totalDuration(end.project)).toBeCloseTo(12);
    expect(frameAt(end.project, 11)).toEqual(["m", 10]);
    expect(end.project.segments).toHaveLength(1);

    const two: Project = {
      ...base(),
      segments: [
        { id: "a", mediaId: "m", sourceIn: 0, sourceOut: 3, words: [] },
        { id: "b", mediaId: "m", sourceIn: 6, sourceOut: 10, words: [] },
      ],
    };
    const cut = insertHoldAt(two, 3.01, 1.5);
    expect(cut.at).toBeCloseTo(3);
    expect(cut.project.segments.map((s) => s.holdSec)).toEqual([1.5, undefined]);
    expect(totalDuration(cut.project)).toBeCloseTo(8.5);
  });

  it("a long take is held in full (beyond the Timing panel's 30 s)", () => {
    const r = addVoiceOverTake(base(), {
      media: take(95),
      at: 5,
      mode: "insert",
      overrideOriginal: false,
    });
    expect(totalDuration(r.project)).toBeCloseTo(105);
  });

  it("random projects: output = original + take; before the anchor unchanged; after it shifted exactly", () => {
    let seed = 7;
    const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
    for (let run = 0; run < 200; run++) {
      const segments: Segment[] = [];
      let src = 0;
      const n = 1 + Math.floor(rnd() * 4);
      for (let i = 0; i < n; i++) {
        const len = 0.2 + rnd() * 3;
        const seg: Segment = {
          id: `s${i}`,
          mediaId: "m",
          sourceIn: src,
          sourceOut: src + len,
          words: [],
        };
        if (rnd() < 0.3) seg.speed = [0.5, 2][Math.floor(rnd() * 2)];
        if (rnd() < 0.3) seg.holdSec = rnd() * 1.5;
        segments.push(seg);
        src += len + rnd();
      }
      const p: Project = { ...base(), media: { m: media("m", src + 5) }, segments };
      const total = totalDuration(p);
      const t = rnd() * total;
      const len = 0.1 + rnd() * 4;
      const { project: q, at } = insertHoldAt(p, t, len);
      expect(totalDuration(q)).toBeCloseTo(total + len, 6);
      // Snaps to a cut or clip edge only, or (anchor inside a hold) to the end of that hold.
      const inHold = computeTimeline(p).some(
        (e) =>
          e.holdSec && t >= e.outputEnd - e.holdSec - 0.05 && Math.abs(at - e.outputEnd) < 1e-9,
      );
      expect(inHold || Math.abs(at - t) < 0.1).toBe(true);
      for (let k = 0; k < 25; k++) {
        const s = rnd() * total;
        const before = frameAt(p, s);
        if (s < at - 1e-6) expect(frameAt(q, s)).toEqual(before);
        else if (s > at + 1e-6) {
          const after = frameAt(q, s + len)!;
          expect(after[0]).toBe(before![0]);
          expect(after[1]).toBeCloseTo(before![1], 6);
        }
        // Inside the inserted span the picture never moves.
        const h = frameAt(q, at + (k / 25) * len * 0.999)!;
        const h0 = frameAt(q, at)!;
        expect(h[1]).toBeCloseTo(h0[1], 9);
      }
    }
  });

  it("removing the take removes its hold; trimming it resizes the hold; offset stays pinned", () => {
    const p = base();
    const { project, id } = addVoiceOverTake(p, {
      media: take(3),
      at: 4,
      mode: "insert",
      overrideOriginal: false,
    });
    const trimmed = updateAudioTrack(project, id, { sourceOut: 2, offsetSec: 1 });
    expect(totalDuration(trimmed)).toBeCloseTo(12);
    expect(trimmed.audioTracks![0]).toMatchObject({ offsetSec: 4, insertSec: 2, sourceOut: 2 });
    const removed = removeAudioTrack(trimmed, id);
    expect(totalDuration(removed)).toBeCloseTo(10);
    expect(removed.segments.every((s) => !s.holdSec)).toBe(true);
    for (const x of [1, 4, 7.5]) expect(frameAt(removed, x)?.[1]).toBeCloseTo(x);
  });

  it("a second insert at the same playhead goes after the first, never on top of it", () => {
    const one = addVoiceOverTake(base(), {
      id: "a",
      media: take(3),
      at: 4,
      mode: "insert",
      overrideOriginal: false,
    });
    const two = addVoiceOverTake(one.project, {
      id: "b",
      media: { ...take(2), id: "take2", path: "/take2.m4a" },
      at: 4,
      mode: "insert",
      overrideOriginal: false,
    });
    const offs = () => Object.fromEntries(two.project.audioTracks!.map((t) => [t.id, t.offsetSec]));
    expect(offs()).toEqual({ a: 4, b: 7 });
    expect(totalDuration(two.project)).toBeCloseTo(15);
    expect(frameAt(two.project, 8)).toEqual(["m", 4]);
    expect(frameAt(two.project, 9.5)?.[1]).toBeCloseTo(4.5);
    // Removing the first closes it up: the second moves to the anchor.
    const noA = removeAudioTrack(two.project, "a");
    expect(noA.audioTracks!.map((t) => [t.id, t.offsetSec, t.insertSec])).toEqual([["b", 4, 2]]);
    expect(totalDuration(noA)).toBeCloseTo(12);
    // Removing the second leaves the first exactly as it was.
    const noB = removeAudioTrack(two.project, "b");
    expect(noB.audioTracks!.map((t) => [t.id, t.offsetSec, t.insertSec])).toEqual([["a", 4, 3]]);
    expect(totalDuration(noB)).toBeCloseTo(13);
    // Trimming the first moves the second with it.
    const trimmed = updateAudioTrack(two.project, "a", { sourceOut: 1 });
    expect(trimmed.audioTracks!.map((t) => t.offsetSec)).toEqual([4, 5]);
    expect(totalDuration(trimmed)).toBeCloseTo(13);
  });

  it("the narration's hold is not the Timing panel's, and is not copied by Duplicate", () => {
    const { project } = addVoiceOverTake(base(), {
      id: "a",
      media: take(3),
      at: 4,
      mode: "insert",
      overrideOriginal: false,
    });
    const held = project.segments[0]!;
    expect(insertOwnedHold(project, held.id)).toBeCloseTo(3);
    // Setting the freeze to 0 keeps the narration's 3 s; adding 1 s stacks on top.
    expect(
      segmentHold(setSegmentTiming(project, held.id, { holdSec: 0 }).segments[0]!),
    ).toBeCloseTo(3);
    const user = setSegmentTiming(project, held.id, { holdSec: 4 });
    expect(segmentHold(user.segments[0]!)).toBeCloseTo(4);
    expect(insertOwnedHold(user, held.id)).toBeCloseTo(3);
    // Duplicate copies only the user's own second, not the narration's 3 s.
    const dup = duplicateClip(user, held.id);
    expect(segmentHold(dup.segments[1]!)).toBeCloseTo(1);
    expect(totalDuration(dup)).toBeCloseTo(totalDuration(user) + 4 + 1);
    expect(duplicateClip(project, held.id).segments[1]!.holdSec).toBeUndefined();
  });

  it("a take whose held clip was deleted owns nothing, so removing it never shrinks a user's hold", () => {
    const two: Project = {
      ...base(),
      segments: [
        { id: "a", mediaId: "m", sourceIn: 0, sourceOut: 4, words: [] },
        { id: "b", mediaId: "m", sourceIn: 6, sourceOut: 8, words: [], holdSec: 5 },
      ],
    };
    const { project } = addVoiceOverTake(two, {
      id: "vo",
      media: take(3),
      at: 2,
      mode: "insert",
      overrideOriginal: false,
    });
    const heldClip = project.segments[0]!.id; // left piece of the split clip a
    const gone = deleteClip(project, heldClip);
    expect(gone.audioTracks![0]).toMatchObject({ mode: "overlay" });
    expect(gone.audioTracks![0]!.insertSec).toBeUndefined();
    const removed = removeAudioTrack(gone, "vo");
    expect(removed.segments.at(-1)!.holdSec).toBe(5); // the user's freeze is untouched
    expect(totalDuration(removed)).toBeCloseTo(totalDuration(gone));
  });

  it("a hold never exceeds the model limit; the excess is not claimed", () => {
    const r = addVoiceOverTake(base(), {
      media: take(5000),
      at: 5,
      mode: "insert",
      overrideOriginal: false,
    });
    expect(r.project.audioTracks![0]!.insertSec).toBe(MAX_HOLD_SEC);
    expect(totalDuration(r.project)).toBeCloseTo(10 + MAX_HOLD_SEC);
  });

  it("switches overlay <-> insert, keeping the take where it is", () => {
    const { project, id } = addVoiceOverTake(base(), {
      media: take(2),
      at: 3,
      mode: "overlay",
      overrideOriginal: false,
    });
    expect(totalDuration(project)).toBe(10);
    const ins = setVoiceOverMode(project, id, "insert");
    expect(totalDuration(ins)).toBeCloseTo(12);
    expect(ins.audioTracks![0]).toMatchObject({ mode: "insert", offsetSec: 3, insertSec: 2 });
    const back = setVoiceOverMode(ins, id, "overlay");
    expect(totalDuration(back)).toBeCloseTo(10);
    expect(back.audioTracks![0]!.insertSec).toBeUndefined();
    expect(back.audioTracks![0]!.offsetSec).toBeCloseTo(3);
  });

  it("writes exactly the shape Rust reads (tests/fixtures/voiceoverProject.json)", () => {
    const p: Project = {
      ...newProject("voice-over fixture"),
      id: "p",
      media: { m: media("m", 10, { path: "/video.mp4", sha256: "m" }) },
      segments: [{ id: "s", mediaId: "m", sourceIn: 0, sourceOut: 10, words: [] }],
      chapters: undefined,
      audioTracks: undefined,
    };
    const { project } = addVoiceOverTake(p, {
      id: "vo",
      media: { ...take(3), sha256: "t" },
      at: 2,
      mode: "insert",
      overrideOriginal: true,
      sourceIn: 0.25,
    });
    const track = { ...project.audioTracks![0]!, words: fixture.audioTracks[0]!.words };
    expect(JSON.parse(JSON.stringify(track))).toEqual(fixture.audioTracks[0]);
    const segs = JSON.parse(JSON.stringify(project.segments)).map((s: Segment) => ({
      ...s,
      id: "x",
    }));
    expect(segs).toEqual(fixture.segments.map((s) => ({ ...s, id: "x" })));
    expect(project.media.take).toEqual(fixture.media.take);
  });
});

describe("override: original audio silent only inside the replacement interval", () => {
  const withTakes = (...specs: Array<{ at: number; over: boolean; len?: number }>) => {
    let p = base();
    specs.forEach((s, i) => {
      p = addVoiceOverTake(p, {
        id: `t${i}`,
        media: { ...take(s.len ?? 2), id: `take${i}`, path: `/take${i}.m4a` },
        at: s.at,
        mode: "overlay",
        overrideOriginal: s.over,
      }).project;
    });
    return p;
  };

  it("envelope: 0 inside, ramps outside, 1 elsewhere; the take never mutes itself", () => {
    const p = withTakes({ at: 2, over: true });
    expect(originalAudioGainAt(p, 1)).toBe(1);
    expect(originalAudioGainAt(p, 1.975)).toBeCloseTo(0.5);
    expect(originalAudioGainAt(p, 2)).toBe(0);
    expect(originalAudioGainAt(p, 3.99)).toBe(0);
    expect(originalAudioGainAt(p, 4.025)).toBeCloseTo(0.5);
    expect(originalAudioGainAt(p, 5)).toBe(1);
    const v = previewVoices(p.audioTracks!, p.media, 10, 3);
    expect(v.map((x) => [x.trackId, x.gain])).toEqual([["t0", 1]]);
  });

  it("muting or removing the take restores the original; overlay takes replace nothing", () => {
    const p = withTakes({ at: 2, over: true });
    expect(originalAudioGainAt(updateAudioTrack(p, "t0", { muted: true }), 3)).toBe(1);
    expect(originalAudioGainAt(removeAudioTrack(p, "t0"), 3)).toBe(1);
    expect(originalAudioGainAt(withTakes({ at: 2, over: false }), 3)).toBe(1);
  });

  it("overlapping replacements: the newest take wins, deterministically", () => {
    const p = withTakes({ at: 2, over: true, len: 3 }, { at: 4, over: true, len: 2 });
    const tracks = p.audioTracks!;
    const iv = replacementIntervals(tracks, p.media, 10);
    expect(iv.map((r) => [r.trackId, r.start, r.end])).toEqual([
      ["t0", 2, 5],
      ["t1", 4, 6],
    ]);
    expect(suppressorsOf(tracks, iv, "t0").map((r) => r.trackId)).toEqual(["t1"]);
    expect(suppressorsOf(tracks, iv, "t1")).toEqual([]);
    const at = (t: number) =>
      Object.fromEntries(previewVoices(tracks, p.media, 10, t).map((v) => [v.trackId, v.gain]));
    expect(at(3)).toEqual({ t0: 1 });
    expect(at(4.5)).toEqual({ t1: 1 });
    expect(envelopeGain(iv, 5.5)).toBe(0);
    // Same input, same answer.
    expect(replacementIntervals(tracks, p.media, 10)).toEqual(iv);
  });

  it("captions follow what is heard: replaced words drop out, take words come in", () => {
    let p = withTakes({ at: 2, over: true, len: 3 });
    p = {
      ...p,
      audioTracks: p.audioTracks!.map((t) => ({
        ...t,
        words: [word("vo1", 0.2, 0.6), word("vo2", 1.5, 2)],
      })),
    };
    const ids = flattenWordsInOutputTime(p).map((w) => w.word.id);
    expect(ids).toEqual(["w0", "w1", "vo1", "vo2", "w5", "w6", "w7", "w8", "w9"]);
    const vo2 = flattenWordsInOutputTime(p).find((w) => w.word.id === "vo2")!;
    expect([vo2.start, vo2.end]).toEqual([3.5, 4]);
    // Muted take: original words again, take words gone.
    const muted = updateAudioTrack(p, "t0", { muted: true });
    expect(flattenWordsInOutputTime(muted).map((w) => w.word.id)).toEqual(
      Array.from({ length: 10 }, (_, i) => `w${i}`),
    );
  });

  it("malformed take words from a project file never throw or produce NaN", () => {
    const p = withTakes({ at: 2, over: false, len: 3 });
    for (const words of [
      [null],
      "abc",
      7,
      [{ id: "x", text: 3, start: 0, end: 1 }],
      [{ id: "y", text: "ok", start: "0", end: 1 }],
      [{ id: "z", text: "nan", start: Number.NaN, end: 1 }],
      [{ id: "r", text: "rev", start: 2, end: 1 }],
    ]) {
      const bad = {
        ...p,
        audioTracks: p.audioTracks!.map((t) => ({ ...t, words: words as never })),
      };
      const out = flattenWordsInOutputTime(bad);
      expect(out.every((w) => Number.isFinite(w.start) && Number.isFinite(w.end))).toBe(true);
      expect(out.map((w) => w.word.id)).toEqual(Array.from({ length: 10 }, (_, i) => `w${i}`));
    }
    const many = Array.from({ length: MAX_TAKE_WORDS + 50 }, (_, i) => word(`v${i}`, 0.1, 0.2));
    const capped = { ...p, audioTracks: p.audioTracks!.map((t) => ({ ...t, words: many })) };
    expect(flattenWordsInOutputTime(capped).length).toBe(10 + MAX_TAKE_WORDS);
  });

  it("overflow past the end is reported, never silently dropped", () => {
    const p = withTakes({ at: 9, over: false, len: 3 });
    expect(voiceOverOverflow(p, p.audioTracks![0]!)).toBeCloseTo(2);
  });
});

describe("anchors survive edits made during the take", () => {
  it("follows a split, falls back (flagged) when the clip is deleted", () => {
    const p: Project = {
      ...base(),
      segments: [
        { id: "a", mediaId: "m", sourceIn: 0, sourceOut: 4, words: [] },
        { id: "b", mediaId: "m", sourceIn: 6, sourceOut: 10, words: [] },
      ],
    };
    const anchor = captureAnchor(p, 5); // 1 s into clip b (source 7)
    expect(anchor).toMatchObject({ segmentId: "b", sourceTime: 7, outputTime: 5 });
    // Clip a deleted while recording: the anchor moves with its content.
    const shifted = deleteClip(p, "a");
    expect(resolveAnchor(shifted, anchor)).toEqual({ outputTime: 1, moved: false });
    // Clip b deleted: stored output time, flagged.
    const gone = deleteClip(p, "b");
    expect(resolveAnchor(gone, anchor)).toEqual({ outputTime: 4, moved: true });
  });
});
