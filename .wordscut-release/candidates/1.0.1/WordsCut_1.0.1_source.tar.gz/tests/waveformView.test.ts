import { describe, expect, it } from "vitest";
import { getTimelineIndex } from "@/lib/timelineIndex";
import { waveformColumns } from "@/lib/waveformView";
const index = getTimelineIndex([
  { id: "one", mediaId: "m", sourceIn: 1, sourceOut: 2, words: [] },
  { id: "repeat", mediaId: "m", sourceIn: 1, sourceOut: 2, words: [] },
  { id: "n", mediaId: "n", sourceIn: 0, sourceOut: 1, words: [] },
]);
const pyramid = {
  version: 1,
  sampleRate: 4,
  samplesPerPeak: 1,
  levels: [{ samplesPerPeak: 1, peaks: [0, 0, 0, 0, 0.2, 0.4, 0.6, 1] }],
};
describe("source-aligned waveform", () => {
  it("draws the same source amplitudes for repeated output ranges", () => {
    const peaks = waveformColumns(index, { m: pyramid }, 0, 8, 4);
    expect([...peaks.slice(0, 4)]).toEqual([...peaks.slice(4, 8)]);
    expect(peaks[0]).toBeCloseTo(0.2);
    expect(peaks[3]).toBe(1);
  });
  it("uses maxima across cut boundaries, with no invented amplitude for unavailable media", () => {
    expect(waveformColumns(index, { m: pyramid }, 0, 1, 0.5)[0]).toBe(1);
    expect([...waveformColumns(index, { m: pyramid }, 8, 4, 4)]).toEqual([0, 0, 0, 0]);
  });
  it("handles a scrolled viewport and unavailable layout", () => {
    expect(waveformColumns(index, { m: pyramid }, 4, 1, 4)[0]).toBeCloseTo(0.2);
    expect([...waveformColumns(index, { m: pyramid }, 0, 2, 0)]).toEqual([0, 0]);
  });
});
