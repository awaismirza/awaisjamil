import { afterEach, describe, expect, it, vi } from "vitest";
import { addMediaWithTranscript, deleteWords, newProject, type SourceMedia } from "@/lib/edl";
import { cacheProjectTranscripts, readTranscriptCache } from "@/lib/transcriptCache";
import { replaceProjectBaseline, useProjectStore } from "@/stores/projectStore";
const media: SourceMedia = {
  id: "m",
  path: "/m.mp4",
  duration: 3,
  fps: 30,
  width: 100,
  height: 100,
  audioSampleRate: 8000,
  sha256: "original-test",
};
const words = [0, 1, 2].map((i) => ({
  id: `w${i}`,
  text: `word${i}`,
  start: i,
  end: i + 1,
  confidence: 1,
}));
afterEach(() => {
  vi.useRealTimers();
  localStorage.clear();
});
describe("source transcription preservation", () => {
  it("retains full words after edits and caches originals rather than surviving EDL words", () => {
    const p = addMediaWithTranscript(newProject("p"), media, words);
    const edited = deleteWords(p, new Set(["w1"]));
    expect(edited.originalTranscripts?.m).toEqual(words);
    cacheProjectTranscripts(edited);
    expect(readTranscriptCache(media)).toEqual(words);
  });
  it("does not call legacy edited words or an old cache complete originals", () => {
    const p = addMediaWithTranscript(newProject("p"), media, words.slice(0, 1));
    delete p.originalTranscripts;
    localStorage.setItem("yusafcut.transcript.v1.original-test", JSON.stringify({ words }));
    cacheProjectTranscripts(p);
    expect(readTranscriptCache(media)).toBeNull();
  });
  it("marks undo after save dirty, but keeps loaded baselines clean", () => {
    vi.useFakeTimers();
    const p = addMediaWithTranscript(newProject("p"), media, words);
    replaceProjectBaseline(p, { filePath: "/p.scribe" });
    vi.advanceTimersByTime(200);
    expect(useProjectStore.getState().dirty).toBe(false);
    useProjectStore.getState().rename("edit");
    vi.advanceTimersByTime(200);
    useProjectStore.getState().markSaved("/p.scribe");
    useProjectStore.temporal.getState().undo();
    expect(useProjectStore.getState().project.name).toBe("p");
    expect(useProjectStore.getState().dirty).toBe(true);
  });
  it("recognition rebases undo/redo snapshots rather than becoming an undo step", () => {
    vi.useFakeTimers();
    const p = addMediaWithTranscript(newProject("p"), media, []);
    replaceProjectBaseline(p);
    vi.advanceTimersByTime(200);
    const id = useProjectStore.getState().project.segments[0].id;
    useProjectStore.getState().trimClip(id, "start", 1);
    const before = useProjectStore.temporal.getState().pastStates.length;
    useProjectStore.getState().attachTranscript(p.id, media.id, words, media);
    expect(useProjectStore.temporal.getState().pastStates).toHaveLength(before);
    useProjectStore.temporal.getState().undo();
    expect(useProjectStore.getState().project.segments[0].sourceIn).toBe(0);
    expect(useProjectStore.getState().project.segments[0].words).toEqual(words);
    useProjectStore.temporal.getState().redo();
    expect(useProjectStore.getState().project.segments[0].words.map((w) => w.id)).toEqual([
      "w1",
      "w2",
    ]);
  });
  it("recognition reaches a future append if it was undone while Whisper ran", () => {
    vi.useFakeTimers();
    const p = newProject("p");
    replaceProjectBaseline(p);
    vi.advanceTimersByTime(200);
    useProjectStore.getState().addMediaWithTranscript(media, []);
    useProjectStore.temporal.getState().undo();
    useProjectStore.getState().attachTranscript(p.id, media.id, words, media);
    expect(useProjectStore.getState().project.segments).toEqual([]);
    useProjectStore.temporal.getState().redo();
    expect(useProjectStore.getState().project.segments[0].words).toEqual(words);
  });
});
