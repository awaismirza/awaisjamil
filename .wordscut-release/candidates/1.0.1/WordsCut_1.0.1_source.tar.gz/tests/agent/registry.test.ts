import { describe, expect, it } from "vitest";
import { callTool, catalog, describeTool } from "@/lib/agent/registry";
import type { ToolOutcome } from "@/lib/agent/protocol";
import { fakeCtx, makeProject } from "./helpers";

const data = (o: ToolOutcome) => {
  if (!o.ok) throw new Error(`${o.error.code}: ${o.error.message}`);
  return o.data;
};

describe("catalog", () => {
  it("has 20 well-formed tools", () => {
    const c = catalog();
    expect(c).toHaveLength(20);
    expect(new Set(c.map((t) => t.name)).size).toBe(20);
    for (const t of c) {
      expect(t.name).toMatch(/^[a-z][a-z0-9_]{1,63}$/);
      expect(t.inputSchema.type).toBe("object");
      expect(t.inputSchema.additionalProperties).toBe(false);
      expect(t.description.length).toBeGreaterThan(10);
      expect(() => JSON.stringify(t)).not.toThrow();
    }
    expect(describeTool("edit_cut_words")?.mutates).toBe(true);
    expect(describeTool("project_info")?.mutates).toBe(false);
  });

  it("matches the snapshot of names, mutability and required keys", () => {
    expect(
      catalog().map((t) => ({
        name: t.name,
        mutates: t.mutates,
        props: Object.keys(t.inputSchema.properties ?? {}),
        required: t.inputSchema.required ?? [],
      })),
    ).toMatchSnapshot();
  });
});

describe("plan / apply flow", () => {
  const text = "hello um world uh again this is fine";

  it("confirm:false never applies; confirm:true applies exactly once", async () => {
    const ctx = fakeCtx(makeProject(text));
    const plan = data(await callTool("edit_cut_fillers", {}, ctx));
    expect(ctx.applyProject).not.toHaveBeenCalled();
    expect(plan).toMatchObject({ applied: false, revision: 1, removedWordCount: 2 });
    expect(plan.next).toContain("confirm:true");
    expect((plan.removedWords as { text: string }[]).map((w) => w.text)).toEqual(["um", "uh"]);
    expect(plan.durationAfter as number).toBeLessThan(plan.durationBefore as number);

    const done = data(await callTool("edit_cut_fillers", { confirm: true, baseRevision: 1 }, ctx));
    expect(ctx.applyProject).toHaveBeenCalledTimes(1);
    expect(done).toMatchObject({ applied: true, revision: 2, undo: "history {action:'undo'}" });
  });

  it("a no-op never applies", async () => {
    const ctx = fakeCtx(makeProject("nothing to remove here"));
    const out = data(await callTool("edit_cut_fillers", { confirm: true }, ctx));
    expect(out).toMatchObject({ applied: false, summary: "Nothing to do" });
    expect(ctx.applyProject).not.toHaveBeenCalled();
  });

  it("edit_batch of 3 steps applies once; later steps see earlier results", async () => {
    const ctx = fakeCtx(makeProject(text));
    const out = data(
      await callTool(
        "edit_batch",
        {
          confirm: true,
          steps: [
            { name: "edit_cut_fillers", input: {} },
            { name: "edit_replace_text", input: { find: "world", replace: "there" } },
            { name: "chapters_edit", input: { add: [{ time: 0, title: "Intro" }] } },
          ],
        },
        ctx,
      ),
    );
    expect(ctx.applyProject).toHaveBeenCalledTimes(1);
    expect(out.applied).toBe(true);
    expect((out.details as { steps: unknown[] }).steps).toHaveLength(3);
    const words = ctx.state.project.segments.flatMap((s) => s.words.map((w) => w.text));
    expect(words).toEqual(["hello", "there", "again", "this", "is", "fine"]);
    expect(ctx.state.project.chapters).toHaveLength(1);
  });

  it("edit_batch reports the failing step with a pointer", async () => {
    const ctx = fakeCtx(makeProject(text));
    const out = await callTool(
      "edit_batch",
      { steps: [{ name: "edit_cut_range", input: { start: 5 } }] },
      ctx,
    );
    expect(out).toMatchObject({ ok: false, error: { code: "INVALID_INPUT" } });
    expect(!out.ok && out.error.message).toContain("/steps/0/input/end");
    expect(ctx.applyProject).not.toHaveBeenCalled();
  });

  it("rejects a stale baseRevision", async () => {
    const ctx = fakeCtx(makeProject(text));
    const out = await callTool("edit_cut_fillers", { confirm: true, baseRevision: 0 }, ctx);
    expect(out).toMatchObject({ ok: false, error: { code: "STALE_REVISION" } });
    expect(ctx.applyProject).not.toHaveBeenCalled();
  });

  it("rejects bad input with a JSON pointer", async () => {
    const ctx = fakeCtx(makeProject(text));
    const out = await callTool("edit_cut_range", { start: "a", end: 2 }, ctx);
    expect(out).toMatchObject({ ok: false, error: { code: "INVALID_INPUT" } });
    expect(!out.ok && out.error.message).toContain("/start");
    const unknown = await callTool("nope", {}, ctx);
    expect(unknown).toMatchObject({ ok: false, error: { code: "UNKNOWN_TOOL" } });
  });

  it("reports BUSY, NO_PROJECT, NO_TRANSCRIPT", async () => {
    const busy = fakeCtx(makeProject(text), { busy: "export running" });
    expect(await callTool("edit_cut_fillers", {}, busy)).toMatchObject({ error: { code: "BUSY" } });
    const empty = fakeCtx(makeProject(text));
    empty.state.project = { ...empty.state.project, segments: [], media: {} };
    expect(await callTool("edit_cut_fillers", {}, empty)).toMatchObject({
      error: { code: "NO_PROJECT" },
    });
    const bare = fakeCtx({
      ...makeProject(text),
      segments: makeProject(text).segments.map((s) => ({ ...s, words: [] })),
    });
    expect(await callTool("edit_cut_fillers", {}, bare)).toMatchObject({
      error: { code: "NO_TRANSCRIPT" },
    });
  });

  it("turns thrown errors into INTERNAL", async () => {
    const ctx = fakeCtx(makeProject(text));
    ctx.detectPauses = async () => {
      throw new Error("ffmpeg died");
    };
    const out = await callTool("edit_trim_silences", {}, ctx);
    expect(out).toMatchObject({ ok: false, error: { code: "INTERNAL", message: "ffmpeg died" } });
  });

  it("caps oversized responses", async () => {
    const big = Array.from({ length: 200000 }, (_, i) => `word${i}`).join(" ");
    const ctx = fakeCtx(makeProject(big, 100000));
    const out = data(await callTool("transcript_get", { format: "words", limit: 5000 }, ctx));
    expect(out.total).toBe(200000);
    expect(JSON.stringify(out).length).toBeLessThan(4 * 1024 * 1024);
  });
});
