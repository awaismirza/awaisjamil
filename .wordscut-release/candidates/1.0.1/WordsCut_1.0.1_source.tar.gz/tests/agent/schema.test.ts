import { describe, expect, it } from "vitest";
import { validate } from "@/lib/agent/schema";
import type { JsonSchema } from "@/lib/agent/protocol";

const schema: JsonSchema = {
  type: "object",
  additionalProperties: false,
  required: ["n"],
  properties: {
    n: { type: "integer", minimum: 1, maximum: 5 },
    s: { type: "string", maxLength: 3, default: "ab" },
    mode: { type: "string", enum: ["a", "b"], default: "a" },
    list: {
      type: "array",
      maxItems: 2,
      items: {
        type: "object",
        additionalProperties: false,
        properties: { x: { type: "number", default: 7 } },
      },
    },
  },
};

describe("schema validate", () => {
  it("applies defaults, including nested ones", () => {
    const r = validate(schema, { n: 2, list: [{}] });
    expect(r).toEqual({ ok: true, value: { n: 2, s: "ab", mode: "a", list: [{ x: 7 }] } });
  });

  it("reports JSON pointers", () => {
    expect(validate(schema, {})).toMatchObject({ ok: false, pointer: "/n" });
    expect(validate(schema, { n: 9 })).toMatchObject({ ok: false, pointer: "/n" });
    expect(validate(schema, { n: 1.5 })).toMatchObject({ ok: false, pointer: "/n" });
    expect(validate(schema, { n: 1, extra: 1 })).toMatchObject({ ok: false, pointer: "/extra" });
    expect(validate(schema, { n: 1, list: [{ y: 1 }] })).toMatchObject({
      ok: false,
      pointer: "/list/0/y",
    });
    expect(validate(schema, { n: 1, mode: "z" })).toMatchObject({ ok: false, pointer: "/mode" });
    expect(validate(schema, { n: 1, list: [{}, {}, {}] })).toMatchObject({
      ok: false,
      pointer: "/list",
    });
    expect(validate(schema, "no")).toMatchObject({ ok: false, pointer: "" });
  });

  it("rejects NaN and does not mutate input", () => {
    expect(validate(schema, { n: Number.NaN })).toMatchObject({ ok: false });
    const input = { n: 1 };
    validate(schema, input);
    expect(input).toEqual({ n: 1 });
  });
});
