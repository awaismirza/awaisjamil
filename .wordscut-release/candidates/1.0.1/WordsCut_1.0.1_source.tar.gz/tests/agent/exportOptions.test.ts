import { describe, expect, it } from "vitest";
import { totalDuration } from "@/lib/edl";
import {
  buildExportOptions,
  EXPORT_FORMATS,
  effectiveFormat,
  exportRequestProblem,
  GIF_MAX_SECONDS,
  type ExportUiSettings,
} from "@/lib/exportOptions";
import { resolveSceneForExport, sanitizeScene, sceneActive } from "@/lib/scene";
import { sanitizeZoomRegions } from "@/lib/zoom";
import { makeProject } from "./helpers";

/** Verbatim copy of the pre-refactor Toolbar.runExport argument construction. */
function legacy(
  project: ReturnType<typeof makeProject>,
  exportSettings: ExportUiSettings,
  outPath: string,
) {
  const resolution = exportSettings.resolution;
  const dims: { width?: number; height?: number } =
    resolution === "original"
      ? {}
      : resolution === "720p"
        ? { width: 1280, height: 720 }
        : resolution === "1080p"
          ? { width: 1920, height: 1080 }
          : resolution === "4k"
            ? { width: 3840, height: 2160 }
            : {
                width: Math.max(16, exportSettings.customWidth),
                height: Math.max(16, exportSettings.customHeight),
              };
  const sceneSettings = sanitizeScene(project.scene);
  const firstMedia = Object.values(project.media)[0];
  const scene =
    sceneActive(sceneSettings) && firstMedia
      ? resolveSceneForExport(
          sceneSettings,
          { w: firstMedia.width, h: firstMedia.height },
          dims.width !== undefined && dims.height !== undefined
            ? { w: dims.width, h: dims.height }
            : undefined,
        )
      : undefined;
  const zoomRegions = sanitizeZoomRegions(project.zoomRegions, totalDuration(project));
  return {
    project,
    outputPath: outPath,
    preset: project.settings.exportPreset,
    ...dims,
    codec: exportSettings.codec === "auto" ? undefined : exportSettings.codec,
    fps: exportSettings.fps ? Number(exportSettings.fps) : undefined,
    videoBitrateKbps: exportSettings.videoBitrateKbps,
    audioBitrateKbps: exportSettings.audioBitrateKbps,
    forceReencode: exportSettings.forceReencode,
    scene,
    zoomRegions: zoomRegions.length > 0 ? zoomRegions : undefined,
    drawCursor: project.cursor?.style.show ?? false,
  };
}

describe("buildExportOptions", () => {
  const plain = makeProject("a b c d e f g h i j", 60);
  const fancy = {
    ...plain,
    scene: sanitizeScene({ enabled: true }),
    zoomRegions: [
      { id: "z", start: 0.5, end: 1.5, scale: 2, focusX: 0.4, focusY: 0.6, easeMs: 300 },
    ],
  };

  for (const resolution of ["original", "720p", "1080p", "4k", "custom"] as const) {
    for (const [label, project] of [
      ["plain", plain],
      ["scene+zoom", fancy],
    ] as const) {
      it(`matches the Toolbar output for ${resolution} (${label})`, () => {
        const s: ExportUiSettings = {
          resolution,
          customWidth: 10,
          customHeight: 900,
          codec: "hevc",
          fps: "30",
          videoBitrateKbps: 8000,
          audioBitrateKbps: 192,
          forceReencode: true,
        };
        expect(buildExportOptions(project, s, "/o/x.mp4")).toEqual(legacy(project, s, "/o/x.mp4"));
      });
    }
  }

  it("treats auto codec and missing fps as unset", () => {
    const o = buildExportOptions(
      plain,
      { resolution: "original", customWidth: 0, customHeight: 0, codec: "auto" },
      "/o/y.mp4",
    );
    expect(o.codec).toBeUndefined();
    expect(o.fps).toBeUndefined();
    expect(o.width).toBeUndefined();
  });
});

describe("export formats", () => {
  const plain = makeProject("a b c d e f g h i j", 60);
  const base: ExportUiSettings = {
    resolution: "original",
    customWidth: 0,
    customHeight: 0,
    codec: "auto",
  };

  it("leaves the default MP4 request without format, range or stems", () => {
    const o = buildExportOptions(plain, base, "/o/a.mp4");
    expect("format" in o || "range" in o || "stems" in o).toBe(false);
  });

  it("maps the podcast preset to m4a unless a format is chosen", () => {
    expect(effectiveFormat("podcast-audio")).toBe("m4a");
    expect(effectiveFormat("podcast-audio", "wav")).toBe("wav");
    expect(effectiveFormat("youtube-1080p")).toBe("mp4");
    const pod = {
      ...plain,
      settings: { ...plain.settings, exportPreset: "podcast-audio" as const },
    };
    expect(buildExportOptions(pod, base, "/o/a.m4a").format).toBe("m4a");
  });

  it("sends format, a range with defaults, and stems only for audio", () => {
    const o = buildExportOptions(
      plain,
      { ...base, format: "prores-422-hq", rangeStart: 1, stems: true },
      "/o/a.mov",
    );
    expect(o.format).toBe("prores-422-hq");
    expect(o.range).toEqual({ start: 1, end: totalDuration(plain) });
    expect(o.stems).toBeUndefined();
    const w = buildExportOptions(plain, { ...base, format: "wav", stems: true }, "/o/a.wav");
    expect(w.stems).toBe(true);
  });

  it("every format has an extension, ProRes lives in MOV", () => {
    expect(EXPORT_FORMATS["prores-422"].ext).toBe("mov");
    expect(Object.values(EXPORT_FORMATS).filter((f) => f.audio)).toHaveLength(2);
  });

  it("reports bad ranges and over-long GIFs before export", () => {
    const total = totalDuration(plain);
    const ok = (s: Partial<ExportUiSettings>) => exportRequestProblem(plain, { ...base, ...s });
    expect(ok({})).toBeNull();
    expect(ok({ rangeStart: 1, rangeEnd: 2 })).toBeNull();
    expect(ok({ rangeStart: total })).toMatch(/start/);
    expect(ok({ rangeStart: -1 })).toMatch(/zero or more/);
    expect(ok({ rangeStart: Number.NaN })).toMatch(/zero or more/);
    expect(ok({ rangeEnd: 0 })).toMatch(/after its start/);
    expect(ok({ rangeStart: 3, rangeEnd: 2 })).toMatch(/after its start/);
    expect(ok({ rangeEnd: total + 1 })).toMatch(/past the end/);
    expect(total).toBeGreaterThan(GIF_MAX_SECONDS - 10);
    const long = makeProject("a b", GIF_MAX_SECONDS + 30);
    expect(exportRequestProblem(long, { ...base, format: "gif" })).toMatch(/limited to 60 s/);
    expect(exportRequestProblem(long, { ...base, format: "gif", rangeEnd: 10 })).toBeNull();
    expect(exportRequestProblem(long, { ...base, format: "mp4" })).toBeNull();
  });
});
