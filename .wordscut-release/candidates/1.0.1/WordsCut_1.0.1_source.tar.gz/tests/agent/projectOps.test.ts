import { describe, expect, it } from "vitest";
import {
  deleteBySourceRange,
  deleteWordsByText,
  findWords,
  normaliseToken,
  replaceText,
  setChapters,
  withZoom,
} from "@/lib/projectOps";
import { makeProject } from "./helpers";

const texts = (p: ReturnType<typeof makeProject>) =>
  p.segments.flatMap((s) => s.words.map((w) => w.text));

describe("projectOps", () => {
  it("normaliseToken", () => {
    expect(normaliseToken(' "Hello," ')).toBe("hello");
  });

  it("replaceText modes and no-op identity", () => {
    const p = makeProject("Cat cats, CAT.");
    const whole = replaceText(p, "cat", "dog");
    expect(texts(whole.project)).toEqual(["dog", "cats,", "dog."]);
    expect(whole.count).toBe(2);
    const sub = replaceText(p, "cat", "dog", { wholeWord: false });
    expect(texts(sub.project)).toEqual(["dog", "dogs,", "dog."]);
    const cs = replaceText(p, "CAT", "dog", { caseSensitive: true });
    expect(texts(cs.project)).toEqual(["Cat", "cats,", "dog."]);
    const none = replaceText(p, "zzz", "y");
    expect(none.project).toBe(p);
    expect(replaceText(p, "", "y").count).toBe(0);
  });

  it("deleteWordsByText and deleteBySourceRange", () => {
    const p = makeProject("a um b um c");
    const r = deleteWordsByText(p, new Set(["um"]));
    expect(r.count).toBe(2);
    expect(texts(r.project)).toEqual(["a", "b", "c"]);
    expect(deleteWordsByText(p, new Set(["zz"])).project).toBe(p);
    const s = deleteBySourceRange(p, 0.34, 0.66);
    expect(s.count).toBe(1);
    expect(texts(s.project)).toEqual(["a", "b", "um", "c"]);
    expect(deleteBySourceRange(p, 100, 200).project).toBe(p);
  });

  it("findWords handles phrases within a segment", () => {
    const p = makeProject("you know what you know");
    const m = findWords(p, "you know");
    expect(m.map((x) => x.wordIds)).toEqual([
      ["w0", "w1"],
      ["w3", "w4"],
    ]);
    expect(m[0]!.context).toBe("you know what you know");
    expect(findWords(p, "  ")).toEqual([]);
  });

  it("withZoom drops the field when empty; setChapters assigns ids", () => {
    const p = makeProject("a b");
    const z = withZoom(p, [
      { id: "z", start: 0, end: 1, scale: 2, focusX: 0.5, focusY: 0.5, easeMs: 0 },
    ]);
    expect(z.zoomRegions).toHaveLength(1);
    expect("zoomRegions" in withZoom(z, [])).toBe(false);
    const c = setChapters(p, [{ title: "A", outputTime: 0 }]);
    expect(c.chapters![0]).toMatchObject({ title: "A", outputTime: 0 });
    expect(c.chapters![0]!.id).toBeTruthy();
  });
});
