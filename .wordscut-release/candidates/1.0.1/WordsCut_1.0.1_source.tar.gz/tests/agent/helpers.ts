import { vi } from "vitest";
import { newProject, type Project, type SourceMedia, type Word } from "@/lib/edl";
import { addMediaWithTranscript } from "@/lib/edl";
import type { AgentContext, PathInfo } from "@/lib/agent/protocol";

/** Contiguous words from text; each lasts 0.3 s with 0.05 s gaps unless `gap` is given. */
export function makeWords(text: string, gap = 0.05, startAt = 0): Word[] {
  let t = startAt;
  return text.split(" ").map((tok, i) => {
    const w: Word = { id: `w${i}`, text: tok, start: t, end: t + 0.3, confidence: 0.9 };
    t += 0.3 + gap;
    return w;
  });
}

export function makeMedia(duration = 60): SourceMedia {
  return {
    id: "m1",
    path: "/media/clip.mp4",
    duration,
    fps: 30,
    width: 1920,
    height: 1080,
    audioSampleRate: 48000,
    sha256: "x",
  };
}

export function makeProject(text: string, duration = 60, gap = 0.05): Project {
  return addMediaWithTranscript(newProject("Demo"), makeMedia(duration), makeWords(text, gap));
}

export interface FakeCtx extends AgentContext {
  applyProject: ReturnType<typeof vi.fn<AgentContext["applyProject"]>>;
  state: {
    project: Project;
    revision: number;
    dirty: boolean;
    filePath: string | null;
    busy: string | null;
    fillers: string[];
    pauses: { id: string; start: number; end: number; duration: number }[];
    paths: Record<string, Partial<PathInfo>>;
    exportRunning: boolean;
    started: unknown[];
    written: { path: string; contents: string; overwrite: boolean }[];
  };
}

export function fakeCtx(project: Project, over: Partial<FakeCtx["state"]> = {}): FakeCtx {
  const state: FakeCtx["state"] = {
    project,
    revision: 1,
    dirty: false,
    filePath: null,
    busy: null,
    fillers: ["um", "uh"],
    pauses: [],
    paths: {},
    exportRunning: false,
    started: [],
    written: [],
    ...over,
  };
  const ctx = {
    state,
    getProject: () => state.project,
    getFilePath: () => state.filePath,
    isDirty: () => state.dirty,
    revision: () => state.revision,
    busyReason: () => state.busy,
    applyProject: vi.fn(async (next: Project) => {
      state.project = next;
      state.revision += 1;
      return state.revision;
    }),
    undo: vi.fn(() => 1),
    redo: vi.fn(() => 1),
    selectedFillers: () => state.fillers,
    detectPauses: vi.fn(async () => state.pauses),
    openProject: vi.fn(async () => {}),
    saveProject: vi.fn(async () => ({ current: true })),
    startExport: vi.fn((o: unknown) => {
      state.started.push(o);
    }),
    exportStatus: () => ({ running: state.exportRunning, progress: null, lastResult: null }),
    cancelExport: vi.fn(async () => {}),
    pathInfo: vi.fn(
      async (path: string): Promise<PathInfo> => ({
        path,
        absolute: path.startsWith("/"),
        exists: false,
        isDir: false,
        isFile: false,
        parentExists: true,
        canonical: null,
        ...state.paths[path],
      }),
    ),
    writeTextFile: vi.fn(async (path: string, contents: string, overwrite: boolean) => {
      state.written.push({ path, contents, overwrite });
    }),
  };
  return ctx as unknown as FakeCtx;
}
