import { beforeEach, describe, expect, it } from "vitest";
import { callTool } from "@/lib/agent/registry";
import type { ToolOutcome } from "@/lib/agent/protocol";
import { cutSilences, keepOutputRange, totalDuration } from "@/lib/edl";
import { useProjectStore, replaceProjectBaseline } from "@/stores/projectStore";
import { parseCursorLog } from "@/lib/cursor";
import { sanitizeProjectCursor } from "@/lib/cursorStyle";
import { fakeCtx, makeProject } from "./helpers";
import { syntheticCursorLog } from "../fixtures/cursorLogs";

const data = (o: ToolOutcome) => {
  if (!o.ok) throw new Error(`${o.error.code}: ${o.error.message}`);
  return o.data;
};
const code = (o: ToolOutcome) => (o.ok ? "ok" : o.error.code);
const texts = (p: ReturnType<typeof makeProject>) =>
  p.segments.flatMap((s) => s.words.map((w) => w.text));

describe("read tools", () => {
  it("project_info", async () => {
    const ctx = fakeCtx(makeProject("a b c d"), { filePath: "/x/y.scribe", dirty: true });
    const d = data(await callTool("project_info", {}, ctx));
    expect(d).toMatchObject({
      name: "Demo",
      filePath: "/x/y.scribe",
      dirty: true,
      revision: 1,
      wordCount: 4,
      segmentCount: 1,
      busy: null,
    });
    expect((d.media as { hasTranscript: boolean }[])[0]!.hasTranscript).toBe(true);
  });

  it("transcript_get pages words, sentences and text", async () => {
    const ctx = fakeCtx(makeProject("Hello there. How are you? Fine"));
    const words = data(await callTool("transcript_get", { format: "words", limit: 2 }, ctx));
    expect(words.total).toBe(6);
    expect(words.nextOffset).toBe(2);
    expect((words.words as unknown[]).length).toBe(2);
    const last = data(
      await callTool("transcript_get", { format: "words", offset: 4, limit: 10 }, ctx),
    );
    expect(last.nextOffset).toBeNull();
    const s = data(await callTool("transcript_get", {}, ctx));
    expect((s.sentences as { text: string }[]).map((x) => x.text)).toEqual([
      "Hello there.",
      "How are you?",
      "Fine",
    ]);
    const t = data(await callTool("transcript_get", { format: "text" }, ctx));
    expect(t.text).toMatch(/^\[00:00\] Hello there\.\n/);
    const r = data(
      await callTool("transcript_get", { format: "words", range: { start: 0, end: 0.2 } }, ctx),
    );
    expect(r.total).toBe(1);
  });

  it("transcript_search matches phrases, whole words and case", async () => {
    const ctx = fakeCtx(makeProject("The cat sat. The Cat ran, cats too"));
    const one = data(await callTool("transcript_search", { query: "cat" }, ctx));
    expect(one.total).toBe(2);
    const cs = data(
      await callTool("transcript_search", { query: "Cat", caseSensitive: true }, ctx),
    );
    expect(cs.total).toBe(1);
    const sub = data(await callTool("transcript_search", { query: "cat", wholeWord: false }, ctx));
    expect(sub.total).toBe(3);
    const phrase = data(await callTool("transcript_search", { query: "the cat" }, ctx));
    const m = (phrase.matches as { wordIds: string[]; start: number }[])[0]!;
    expect(m.wordIds).toHaveLength(2);
    expect(m.start).toBe(0);
    const capped = data(await callTool("transcript_search", { query: "cat", maxResults: 1 }, ctx));
    expect(capped).toMatchObject({ total: 2 });
    expect((capped.matches as unknown[]).length).toBe(1);
  });

  it("edl_get honours include", async () => {
    const ctx = fakeCtx(makeProject("a b c"));
    const d = data(await callTool("edl_get", { include: ["segments"] }, ctx));
    expect(d.segments).toHaveLength(1);
    expect(d.timeline).toBeUndefined();
    expect((d.segments as { wordCount: number; firstWordId: string }[])[0]).toMatchObject({
      wordCount: 3,
      firstWordId: "w0",
    });
    const def = data(await callTool("edl_get", {}, ctx));
    expect(def.timeline).toBeDefined();
    expect(def.chapters).toEqual([]);
    expect(def.zoomRegions).toEqual([]);
  });

  it("chapters_suggest returns suggestions", async () => {
    const words = Array.from({ length: 200 }, (_, i) => (i % 40 === 39 ? "next." : "word")).join(
      " ",
    );
    const ctx = fakeCtx(makeProject(words, 120, 0.3));
    const d = data(await callTool("chapters_suggest", { count: 3, minChapterSec: 5 }, ctx));
    const sug = d.suggestions as { time: number; title: string }[];
    expect(sug.length).toBeGreaterThan(0);
    expect(sug[0]!.time).toBe(0);
  });
});

describe("edit tools", () => {
  it("edit_cut_words by ids, unknown ids and ranges", async () => {
    const ctx = fakeCtx(makeProject("one two three four"));
    const d = data(
      await callTool("edit_cut_words", { wordIds: ["w1", "nope"], confirm: true }, ctx),
    );
    expect(d.details).toMatchObject({ unknownIds: ["nope"] });
    expect(texts(ctx.state.project)).toEqual(["one", "three", "four"]);
    expect(code(await callTool("edit_cut_words", { wordIds: ["nope"] }, ctx))).toBe("NOT_FOUND");
    expect(code(await callTool("edit_cut_words", {}, ctx))).toBe("INVALID_INPUT");
    expect(
      code(
        await callTool("edit_cut_words", { wordIds: ["w0"], ranges: [{ start: 0, end: 1 }] }, ctx),
      ),
    ).toBe("INVALID_INPUT");
    const r = fakeCtx(makeProject("one two three four"));
    await callTool("edit_cut_words", { ranges: [{ start: 0.4, end: 0.9 }], confirm: true }, r);
    expect(texts(r.state.project)).toEqual(["one", "four"]);
  });

  it("edit_cut_range delete and keep (keep matches keepOutputRange)", async () => {
    const project = makeProject("one two three four five six");
    const ctx = fakeCtx(project);
    await callTool("edit_cut_range", { start: 1, end: 1.9, mode: "keep", confirm: true }, ctx);
    const expected = keepOutputRange(project, 1, 1.9);
    expect(ctx.state.project.segments.map((s) => [s.sourceIn, s.sourceOut])).toEqual(
      expected.segments.map((s) => [s.sourceIn, s.sourceOut]),
    );
    expect(totalDuration(ctx.state.project)).toBeCloseTo(0.9);

    const del = fakeCtx(project);
    await callTool("edit_cut_range", { start: 0.7, end: 1.3, confirm: true }, del);
    expect(texts(del.state.project)).toEqual(["one", "two", "five", "six"]);
    expect(code(await callTool("edit_cut_range", { start: 2, end: 1 }, del))).toBe("INVALID_INPUT");
  });

  it("edit_cut_fillers matches projectStore.deleteFillers", async () => {
    const project = makeProject("so um you know this uh is you know fine");
    const phrases = ["um", "uh", "you know"];
    replaceProjectBaseline(project);
    useProjectStore.getState().deleteFillers(phrases);
    const viaStore = useProjectStore.getState().project;

    const ctx = fakeCtx(project);
    const out = data(await callTool("edit_cut_fillers", { phrases, confirm: true }, ctx));
    expect(out.details).toEqual({ byPhrase: { um: 1, uh: 1, "you know": 2 } });
    expect(texts(ctx.state.project)).toEqual(texts(viaStore));
    expect(ctx.state.project.segments.map((s) => [s.sourceIn, s.sourceOut])).toEqual(
      viaStore.segments.map((s) => [s.sourceIn, s.sourceOut]),
    );
  });

  it("edit_cut_fillers defaults to the selected fillers", async () => {
    const ctx = fakeCtx(makeProject("hello um world like this"), { fillers: ["um"] });
    await callTool("edit_cut_fillers", { confirm: true }, ctx);
    expect(texts(ctx.state.project)).toEqual(["hello", "world", "like", "this"]);
  });

  it("edit_trim_silences matches cutSilences with injected silences", async () => {
    const project = makeProject("a b c d e f", 60, 0.1);
    // words end at 0.3,0.7,... ; put silences in the gaps and after the last word
    const pauses = [
      { id: "p1", start: 1.0, end: 3.0, duration: 2 },
      { id: "p2", start: 4.0, end: 4.3, duration: 0.3 },
      { id: "p3", start: 5.0, end: 9.0, duration: 4 },
    ];
    const ctx = fakeCtx(project, { pauses });
    const plan = data(await callTool("edit_trim_silences", {}, ctx));
    expect(ctx.applyProject).not.toHaveBeenCalled();
    expect(plan.details).toMatchObject({ silencesFound: 3, mediaId: "m1" });
    expect(ctx.detectPauses).toHaveBeenCalledWith({
      mediaPath: "/media/clip.mp4",
      noiseThreshold: -35,
      minDuration: 0.6,
    });

    await callTool("edit_trim_silences", { confirm: true }, ctx);
    const [expected, cut] = cutSilences(project, "m1", pauses, { minDuration: 0.6, keepSec: 0.16 });
    expect(cut).toBeGreaterThan(0);
    expect(totalDuration(ctx.state.project)).toBeCloseTo(totalDuration(expected));
    expect(ctx.state.project.segments.map((s) => [s.sourceIn, s.sourceOut])).toEqual(
      expected.segments.map((s) => [s.sourceIn, s.sourceOut]),
    );
  });

  it("edit_trim_silences with no silences is a no-op and needs media", async () => {
    const ctx = fakeCtx(makeProject("a b c"));
    const out = data(await callTool("edit_trim_silences", { confirm: true }, ctx));
    expect(out.summary).toBe("Nothing to do");
    expect(ctx.applyProject).not.toHaveBeenCalled();
    ctx.state.project = { ...ctx.state.project, media: {} };
    expect(code(await callTool("edit_trim_silences", {}, ctx))).toBe("NO_MEDIA");
  });

  it("edit_replace_text keeps punctuation and timing", async () => {
    const project = makeProject("Hello wurld, wurld!");
    const ctx = fakeCtx(project);
    const d = data(
      await callTool("edit_replace_text", { find: "wurld", replace: "world", confirm: true }, ctx),
    );
    expect(d.details).toEqual({ replaced: 2 });
    expect(texts(ctx.state.project)).toEqual(["Hello", "world,", "world!"]);
    expect(ctx.state.project.segments[0]!.words[1]!.start).toBe(
      project.segments[0]!.words[1]!.start,
    );
    const none = data(
      await callTool("edit_replace_text", { find: "zzz", replace: "y", confirm: true }, ctx),
    );
    expect(none.applied).toBe(false);
  });

  it("chapters_edit: add, rename, remove, set, fromSuggestions", async () => {
    const ctx = fakeCtx(makeProject("a b c d e f g h", 60, 0.05));
    await callTool(
      "chapters_edit",
      { add: [{ time: 0, title: "Intro" }, { time: 1 }], confirm: true },
      ctx,
    );
    const ch = ctx.state.project.chapters!;
    expect(ch.map((c) => c.title)).toEqual(["Intro", "Chapter"]);
    const rn = data(
      await callTool(
        "chapters_edit",
        {
          rename: [
            { id: ch[1]!.id, title: "Two" },
            { id: "zz", title: "x" },
          ],
          removeIds: [ch[0]!.id],
          confirm: true,
        },
        ctx,
      ),
    );
    expect(rn.details).toMatchObject({ unknownIds: ["zz"] });
    expect(ctx.state.project.chapters!.map((c) => c.title)).toEqual(["Two"]);
    await callTool(
      "chapters_edit",
      {
        set: [
          { time: 2, title: "B" },
          { time: 0, title: "A" },
        ],
        confirm: true,
      },
      ctx,
    );
    expect(ctx.state.project.chapters!.map((c) => c.title)).toEqual(["A", "B"]);
    expect(code(await callTool("chapters_edit", { set: [], fromSuggestions: {} }, ctx))).toBe(
      "INVALID_INPUT",
    );
    const sug = data(
      await callTool("chapters_edit", { fromSuggestions: { count: 1 }, confirm: true }, ctx),
    );
    expect(sug.applied).toBe(true);
    expect(code(await callTool("chapters_edit", {}, ctx))).toBe("ok");
  });

  it("zoom_edit: add, reject short, remove, clear, auto without cursor", async () => {
    const ctx = fakeCtx(makeProject("a ".repeat(60).trim(), 60, 0.05));
    const r = data(
      await callTool(
        "zoom_edit",
        {
          add: [
            { start: 2, end: 5 },
            { start: 8, end: 8.2 },
          ],
          confirm: true,
        },
        ctx,
      ),
    );
    expect(r.details).toMatchObject({ rejected: [{ index: 1 }] });
    const regions = ctx.state.project.zoomRegions!;
    expect(regions).toHaveLength(1);
    expect(regions[0]).toMatchObject({ scale: 1.6, focusX: 0.5, easeMs: 450 });
    const auto = data(await callTool("zoom_edit", { auto: {} }, ctx));
    expect(auto.details).toMatchObject({ autoSkipped: "no cursor data" });
    expect(auto.summary).toBe("Nothing to do");
    await callTool("zoom_edit", { clearRanges: [{ start: 0, end: 10 }], confirm: true }, ctx);
    expect(ctx.state.project.zoomRegions).toBeUndefined();
    await callTool("zoom_edit", { add: [{ start: 2, end: 5 }], confirm: true }, ctx);
    const id = ctx.state.project.zoomRegions![0]!.id;
    const rm = data(await callTool("zoom_edit", { removeIds: [id, "nope"], confirm: true }, ctx));
    expect(rm.details).toMatchObject({ unknownIds: ["nope"] });
    expect(ctx.state.project.zoomRegions).toBeUndefined();
  });
});

describe("zoom_edit auto", () => {
  it("proposes zoom from cursor tracks and replace clears old regions", async () => {
    const base = makeProject("a ".repeat(60).trim(), 20, 0.05);
    const cursor = sanitizeProjectCursor(undefined);
    cursor.tracks = { m1: parseCursorLog(syntheticCursorLog("clicks")) };
    const ctx = fakeCtx({ ...base, cursor });
    const out = data(await callTool("zoom_edit", { auto: {}, confirm: true }, ctx));
    expect(out.applied).toBe(true);
    expect(ctx.state.project.zoomRegions!.length).toBeGreaterThan(0);
    const manual = ctx.state.project.zoomRegions!.length;
    const again = data(await callTool("zoom_edit", { auto: { replace: true } }, ctx));
    expect(again.zoomRegions).toEqual({ before: manual, after: manual });
  });
});

describe("action tools", () => {
  beforeEach(() => replaceProjectBaseline(makeProject("a b")));

  it("history", async () => {
    const ctx = fakeCtx(makeProject("a b c"));
    const d = data(await callTool("history", { action: "undo", steps: 3 }, ctx));
    expect(ctx.undo).toHaveBeenCalledWith(3);
    expect(d).toMatchObject({ done: 1, revision: 1 });
    await callTool("history", { action: "redo" }, ctx);
    expect(ctx.redo).toHaveBeenCalledWith(1);
    expect(code(await callTool("history", { action: "sideways" }, ctx))).toBe("INVALID_INPUT");
  });

  it("project_open guards dirty state and paths", async () => {
    const path = "/p/demo.scribe";
    const ctx = fakeCtx(makeProject("a"), {
      dirty: true,
      paths: { [path]: { exists: true, isDir: true } },
    });
    expect(code(await callTool("project_open", { path }, ctx))).toBe("DIRTY_PROJECT");
    expect(code(await callTool("project_open", { path: "relative.scribe" }, ctx))).toBe(
      "PATH_REJECTED",
    );
    expect(code(await callTool("project_open", { path: "/p/missing.scribe" }, ctx))).toBe(
      "NOT_FOUND",
    );
    const ok = data(await callTool("project_open", { path, discardUnsaved: true }, ctx));
    expect(ctx.openProject).toHaveBeenCalledWith(path);
    expect(ok.name).toBe("Demo");
    const other = fakeCtx(makeProject("a"), {
      paths: { "/p/x.txt": { exists: true, isDir: true } },
    });
    expect(code(await callTool("project_open", { path: "/p/x.txt" }, other))).toBe("PATH_REJECTED");
  });

  it("project_save", async () => {
    const ctx = fakeCtx(makeProject("a"));
    expect(code(await callTool("project_save", {}, ctx))).toBe("INVALID_INPUT");
    expect(code(await callTool("project_save", { path: "/p/a.mov" }, ctx))).toBe("PATH_REJECTED");
    const d = data(await callTool("project_save", { path: "/p/a.scribe" }, ctx));
    expect(ctx.saveProject).toHaveBeenCalledWith("/p/a.scribe");
    expect(d).toMatchObject({ saved: true, current: true });
    ctx.state.filePath = "/p/b.scribe";
    await callTool("project_save", {}, ctx);
    expect(ctx.saveProject).toHaveBeenLastCalledWith("/p/b.scribe");
  });

  it("captions_export returns content or writes a file", async () => {
    const ctx = fakeCtx(makeProject("Hello there. Bye"));
    const inline = data(await callTool("captions_export", { format: "srt" }, ctx));
    expect(inline.content).toContain("-->");
    expect(inline.cueCount).toBeGreaterThan(0);
    expect(data(await callTool("captions_export", { format: "vtt" }, ctx)).content).toMatch(
      /^WEBVTT/,
    );
    const w = data(
      await callTool("captions_export", { format: "srt", outputPath: "/o/a.srt" }, ctx),
    );
    expect(w.outputPath).toBe("/o/a.srt");
    expect(ctx.state.written[0]).toMatchObject({ path: "/o/a.srt", overwrite: false });
    expect(
      code(await callTool("captions_export", { format: "srt", outputPath: "/o/a.vtt" }, ctx)),
    ).toBe("PATH_REJECTED");
    ctx.state.paths["/o/e.srt"] = { exists: true, isFile: true };
    expect(
      code(await callTool("captions_export", { format: "srt", outputPath: "/o/e.srt" }, ctx)),
    ).toBe("PATH_REJECTED");
    await callTool(
      "captions_export",
      { format: "srt", outputPath: "/o/e.srt", overwrite: true },
      ctx,
    );
    expect(ctx.state.written[1]).toMatchObject({ overwrite: true });
    const bare = fakeCtx({ ...makeProject("a"), segments: [] });
    expect(code(await callTool("captions_export", { format: "srt" }, bare))).toBe("NO_TRANSCRIPT");
  });

  it("export_start plans, starts, and guards", async () => {
    const ctx = fakeCtx(makeProject("a b c"));
    const plan = data(
      await callTool("export_start", { outputPath: "/o/out.mp4", resolution: "720p" }, ctx),
    );
    expect(ctx.startExport).not.toHaveBeenCalled();
    expect(plan.started).toBe(false);
    expect(plan.options).toMatchObject({ width: 1280, height: 720, outputPath: "/o/out.mp4" });
    expect((plan.options as Record<string, unknown>).project).toBeUndefined();
    const go = data(
      await callTool("export_start", { outputPath: "/o/out.mp4", confirm: true, fps: 30 }, ctx),
    );
    expect(go).toEqual({ started: true, outputPath: "/o/out.mp4" });
    expect(ctx.state.started).toHaveLength(1);
    expect(ctx.state.started[0]).toMatchObject({ fps: 30 });
    expect(code(await callTool("export_start", { outputPath: "/o/out.avi" }, ctx))).toBe(
      "PATH_REJECTED",
    );
    expect(code(await callTool("export_start", { outputPath: "/o/out.mp4", fps: 31 }, ctx))).toBe(
      "INVALID_INPUT",
    );
    // Formats: extension must match, .mov infers mov, stems only for audio.
    const prores = data(
      await callTool("export_start", { outputPath: "/o/out.mov", format: "prores-422" }, ctx),
    );
    expect(prores.options).toMatchObject({ format: "prores-422" });
    const mov = data(await callTool("export_start", { outputPath: "/o/out.mov" }, ctx));
    expect(mov.options).toMatchObject({ format: "mov" });
    expect(
      code(await callTool("export_start", { outputPath: "/o/out.mp4", format: "gif" }, ctx)),
    ).toBe("PATH_REJECTED");
    expect(
      code(await callTool("export_start", { outputPath: "/o/out.mp4", stems: true }, ctx)),
    ).toBe("INVALID_INPUT");
    const wav = data(
      await callTool(
        "export_start",
        { outputPath: "/o/out.wav", format: "wav", stems: true, rangeStart: 0.5, rangeEnd: 1 },
        ctx,
      ),
    );
    expect(wav.options).toMatchObject({
      format: "wav",
      stems: true,
      range: { start: 0.5, end: 1 },
    });
    expect(
      code(
        await callTool(
          "export_start",
          { outputPath: "/o/out.wav", format: "wav", rangeStart: 2, rangeEnd: 1 },
          ctx,
        ),
      ),
    ).toBe("INVALID_INPUT");
    // Each end alone is checked against the edit's length.
    const total = totalDuration(ctx.state.project);
    for (const range of [{ rangeStart: total }, { rangeEnd: total + 5 }, { rangeEnd: 0 }])
      expect(
        code(
          await callTool(
            "export_start",
            { outputPath: "/o/out.wav", format: "wav", ...range },
            ctx,
          ),
        ),
      ).toBe("INVALID_INPUT");
    const tail = data(
      await callTool(
        "export_start",
        { outputPath: "/o/out.wav", format: "wav", rangeStart: 1 },
        ctx,
      ),
    );
    expect(tail.options).toMatchObject({ range: { start: 1, end: total } });
    ctx.state.exportRunning = true;
    expect(
      code(await callTool("export_start", { outputPath: "/o/out.mp4", confirm: true }, ctx)),
    ).toBe("BUSY");
    const st = data(await callTool("export_status", {}, ctx));
    expect(st).toMatchObject({ running: true });
    expect(data(await callTool("export_cancel", {}, ctx))).toEqual({ cancelled: true });
    ctx.state.exportRunning = false;
    expect(data(await callTool("export_cancel", {}, ctx))).toEqual({ cancelled: false });
  });
});
