import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { CaptionsPanel } from "@/components/editor/sidebar/panels/CaptionsPanel";
import { addMediaWithTranscript, newProject } from "@/lib/edl";
import { useProjectStore } from "@/stores/projectStore";

beforeEach(() => {
  const words = ["Hello", "there", "friend 😀"].map((text, i) => ({
    id: `w${i}`,
    text,
    start: i * 0.5,
    end: i * 0.5 + 0.45,
    confidence: 1,
  }));
  const p = addMediaWithTranscript(
    newProject("test"),
    {
      id: "m",
      path: "/tmp/demo.mp4",
      duration: 20,
      width: 1920,
      height: 1080,
      fps: 30,
      audioSampleRate: 48000,
      sha256: "x",
    },
    words,
  );
  useProjectStore.setState({ project: p, dirty: false });
  useProjectStore.temporal.getState().clear();
});
afterEach(cleanup);

describe("Captions panel", () => {
  it("a slider drag is one undo step, committed on release", () => {
    render(<CaptionsPanel />);
    const size = screen.getAllByRole("slider")[0]!;
    fireEvent.change(size, { target: { value: "60" } });
    fireEvent.change(size, { target: { value: "70" } });
    fireEvent.change(size, { target: { value: "80" } });
    expect(useProjectStore.getState().project.captions).toBeUndefined();
    fireEvent.pointerUp(size);
    expect(useProjectStore.getState().project.captions?.size).toBe(80);
    expect(useProjectStore.temporal.getState().pastStates).toHaveLength(1);
  });

  it("position is a radio group with arrow keys and roving tabindex", () => {
    render(<CaptionsPanel />);
    const bottom = screen.getByRole("radio", { name: "Bottom" });
    expect(bottom).toHaveAttribute("tabindex", "0");
    expect(screen.getByRole("radio", { name: "Top" })).toHaveAttribute("tabindex", "-1");
    fireEvent.keyDown(bottom, { key: "ArrowLeft" });
    expect(useProjectStore.getState().project.captions?.position).toBe("middle");
  });

  it("flags emoji cues, with a count, since the preview draws them but the video will not", () => {
    render(<CaptionsPanel />);
    expect(screen.getByText(/will not appear in the burned-in video/)).toBeInTheDocument();
  });
});
