import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { addMediaWithTranscript, deleteWords, newProject, type SourceMedia, type Word } from "@/lib/edl";
import { useEditorUiStore } from "@/stores/editorUiStore";
import { useProjectStore } from "@/stores/projectStore";
import { DEFAULT_ZOOM_SCALE } from "@/lib/zoom";

const media: SourceMedia = {
  id: "m",
  path: "/tmp/m.mp4",
  duration: 20,
  fps: 30,
  width: 1920,
  height: 1080,
  audioSampleRate: 48000,
  sha256: "x",
};

/** Twenty one-second words w0..w19 over a 20 s clip, no padding so cuts are exact. */
function load() {
  const words: Word[] = Array.from({ length: 20 }, (_, i) => ({
    id: `w${i}`,
    text: `w${i}`,
    start: i,
    end: i + 1,
    confidence: 1,
  }));
  const p = addMediaWithTranscript(newProject("t"), media, words);
  useProjectStore.setState({
    project: { ...p, settings: { ...p.settings, paddingMs: 0 } },
    dirty: false,
  });
  useProjectStore.temporal.getState().clear();
}

describe("zoom regions in the project store", () => {
  beforeEach(() => {
    vi.useFakeTimers();
    load();
  });
  afterEach(() => vi.useRealTimers());

  const regions = () => useProjectStore.getState().project.zoomRegions ?? [];

  it("starts with none, and the field is absent", () => {
    expect(regions()).toEqual([]);
    expect("zoomRegions" in useProjectStore.getState().project).toBe(false);
  });

  it("adds a region and returns its id", () => {
    const id = useProjectStore.getState().addZoomRegion({ start: 2, end: 6, scale: 2 });
    expect(id).not.toBeNull();
    expect(regions()).toHaveLength(1);
    expect(regions()[0]).toMatchObject({ id, start: 2, end: 6, scale: 2 });
    expect(useProjectStore.getState().dirty).toBe(true);
  });

  it("refuses a span that is too short", () => {
    expect(useProjectStore.getState().addZoomRegion({ start: 2, end: 2.1 })).toBeNull();
    expect(regions()).toEqual([]);
  });

  it("clamps to the timeline length", () => {
    useProjectStore.getState().addZoomRegion({ start: 18, end: 40 });
    expect(regions()[0]!.end).toBe(20);
  });

  it("a new region replaces what it overlaps", () => {
    const s = useProjectStore.getState();
    s.addZoomRegion({ start: 2, end: 8 });
    s.addZoomRegion({ start: 6, end: 12 });
    const spans = regions().map((r) => [r.start, r.end]);
    expect(spans).toEqual([[2, 6], [6, 12]]);
  });

  it("updates scale and focus", () => {
    const id = useProjectStore.getState().addZoomRegion({ start: 2, end: 6 })!;
    useProjectStore.getState().updateZoomRegion(id, { scale: 3, focusX: 0.9 });
    expect(regions()[0]).toMatchObject({ scale: 3, focusX: 0.9 });
  });

  it("removes a region, and drops the field when none are left", () => {
    const id = useProjectStore.getState().addZoomRegion({ start: 2, end: 6 })!;
    useProjectStore.getState().removeZoomRegion(id);
    expect("zoomRegions" in useProjectStore.getState().project).toBe(false);
  });

  it("clears a span, splitting a region that surrounds it", () => {
    useProjectStore.getState().addZoomRegion({ start: 1, end: 15 });
    useProjectStore.getState().clearZoomRange(6, 9);
    expect(regions().map((r) => [r.start, r.end])).toEqual([[1, 6], [9, 15]]);
  });

  it("clearing where there is no zoom changes nothing", () => {
    useProjectStore.getState().clearZoomRange(0, 5);
    expect(useProjectStore.getState().dirty).toBe(false);
  });

  it("repairs overlapping data loaded from a file", () => {
    useProjectStore.setState((s) => ({
      project: {
        ...s.project,
        zoomRegions: [
          { id: "a", start: 0, end: 10, scale: 2, focusX: 0.5, focusY: 0.5, easeMs: 400 },
          { id: "b", start: 5, end: 15, scale: 2, focusX: 0.5, focusY: 0.5, easeMs: 400 },
        ],
      },
    }));
    useProjectStore.getState().addZoomRegion({ start: 17, end: 19 });
    const rs = regions();
    for (let i = 1; i < rs.length; i++) expect(rs[i]!.start).toBeGreaterThanOrEqual(rs[i - 1]!.end);
  });

  it("is undoable", () => {
    useProjectStore.getState().addZoomRegion({ start: 2, end: 6 });
    vi.advanceTimersByTime(200);
    useProjectStore.temporal.getState().undo();
    expect(regions()).toEqual([]);
  });

  it("survives saving to JSON and loading back", () => {
    useProjectStore.getState().addZoomRegion({ start: 2, end: 6, scale: 2.5, focusX: 0.3 });
    const round = JSON.parse(JSON.stringify(useProjectStore.getState().project));
    expect(round.zoomRegions).toEqual(regions());
  });
});

describe("zoom regions follow edits", () => {
  beforeEach(() => {
    vi.useFakeTimers();
    load();
  });
  afterEach(() => vi.useRealTimers());

  it("a region after a deleted word moves earlier by its length", () => {
    useProjectStore.getState().addZoomRegion({ start: 10, end: 14, id: "z" });
    const p = useProjectStore.getState().project;
    useProjectStore.setState({ project: deleteWords(p, new Set(["w2", "w3"])) });
    const z = useProjectStore.getState().project.zoomRegions![0]!;
    expect(z.start).toBeCloseTo(8, 3);
    expect(z.end).toBeCloseTo(12, 3);
  });

  it("a region whose words were all deleted disappears", () => {
    useProjectStore.getState().addZoomRegion({ start: 10, end: 14, id: "z" });
    const p = useProjectStore.getState().project;
    useProjectStore.setState({ project: deleteWords(p, new Set(["w10", "w11", "w12", "w13"])) });
    expect(useProjectStore.getState().project.zoomRegions).toBeUndefined();
  });

  it("a region keeps covering the same words when a cut falls inside it", () => {
    useProjectStore.getState().addZoomRegion({ start: 8, end: 16, id: "z" });
    const p = useProjectStore.getState().project;
    useProjectStore.setState({ project: deleteWords(p, new Set(["w10", "w11"])) });
    const z = useProjectStore.getState().project.zoomRegions![0]!;
    expect(z.start).toBeCloseTo(8, 3);
    expect(z.end).toBeCloseTo(14, 3);
  });

  it("the editor remembers the zoom level for the next region", () => {
    expect(useEditorUiStore.getState().zoomLevel).toBe(DEFAULT_ZOOM_SCALE);
    useEditorUiStore.getState().setZoomLevel(9);
    expect(useEditorUiStore.getState().zoomLevel).toBe(4);
    useEditorUiStore.getState().setZoomLevel(0.2);
    expect(useEditorUiStore.getState().zoomLevel).toBe(1.2);
  });
});
