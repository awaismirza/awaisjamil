import { cleanup, render } from "@testing-library/react";
import { afterEach, describe, expect, it } from "vitest";
import { CursorOverlay } from "@/components/VideoPreview/CursorOverlay";
import { parseCursorLog, smoothCursorTrack } from "@/lib/cursor";
import { cursorAppearance, DEFAULT_CURSOR_STYLE } from "@/lib/cursorStyle";
const style = DEFAULT_CURSOR_STYLE;
const track = parseCursorLog(
  [
    { type: "move", t: 0, x: 0.2, y: 0.4 },
    { type: "move", t: 1, x: 0.5, y: 0.6 },
    { type: "down", t: 1, x: 0.5, y: 0.6, button: "left" },
    { type: "key", t: 4 },
    { type: "move", t: 6, x: 1, y: 1, outside: true },
  ]
    .map((e) => JSON.stringify(e))
    .join("\n"),
);
afterEach(cleanup);
describe("cursor styling preview", () => {
  it("is deterministic, hides outside and idle samples, and typing keeps it visible", () => {
    const smooth = smoothCursorTrack(track);
    expect(cursorAppearance(track, smooth, 1, style).visible).toBe(true);
    expect(cursorAppearance(track, smooth, 1, { ...style, show: false }).visible).toBe(false);
    expect(cursorAppearance(track, smooth, 3, { ...style, hideWhenIdle: true }).visible).toBe(
      false,
    );
    expect(cursorAppearance(track, smooth, 4.5, { ...style, hideWhenIdle: true }).visible).toBe(
      true,
    );
    expect(cursorAppearance(track, smooth, 6, style).visible).toBe(false);
    expect(cursorAppearance(track, smooth, 1.2, style)).toEqual(
      cursorAppearance(track, smooth, 1.2, style),
    );
  });
  it("samples click effects from source time and excludes effects from removed footage", () => {
    const sample = cursorAppearance(track, track, 1.2, style);
    expect(sample.clicks[0].progress).toBeCloseTo(0.2 / 0.45);
    expect(cursorAppearance(track, track, 1.2, style, 1.1).clicks).toEqual([]);
    expect(cursorAppearance(track, track, 1.8, style).clicks).toEqual([]);
    expect(cursorAppearance(track, track, 1.2, { ...style, clickEffect: "none" }).clicks).toEqual(
      [],
    );
    expect(
      cursorAppearance(track, track, 1.2, { ...style, clickEffect: "bounce" }).bounce,
    ).toBeLessThan(1);
  });
  it("uses source-pixel geometry with the video aspect and preserves the SVG node on style changes", () => {
    const props = {
      track,
      style: { ...style, smoothing: 0 },
      t: 1,
      clipStart: 0,
      width: 1920,
      height: 1080,
    };
    const { container, rerender } = render(<CursorOverlay {...props} />);
    const svg = container.querySelector("svg");
    expect(svg).toHaveAttribute("viewBox", "0 0 1920 1080");
    expect(container.querySelector("[data-cursor-shape]")).toHaveAttribute(
      "transform",
      "translate(960 648) scale(1)",
    );
    for (const shape of ["dot", "arrow", "pointer", "ring", "crosshair", "macos"] as const) {
      rerender(<CursorOverlay {...props} style={{ ...props.style, shape }} />);
      expect(container.querySelector("svg")).toBe(svg);
      expect(container.querySelector("[data-cursor-shape]")).toHaveAttribute(
        "data-cursor-shape",
        shape,
      );
    }
  });
});
