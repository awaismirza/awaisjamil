import { act, cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import * as ipc from "@/lib/ipc";
import type { RecordingDevices } from "@/lib/ipc";
import { defaultSettings } from "@/lib/settings";
import { useSettingsStore } from "@/stores/settingsStore";
import { initialBarState, useBarStore } from "@/recorderBar/barStore";
import { RecorderBarApp } from "@/recorderBar/RecorderBarApp";

vi.mock("@tauri-apps/api/event", () => ({
  emitTo: vi.fn().mockResolvedValue(undefined),
  listen: vi.fn().mockResolvedValue(() => {}),
}));
vi.mock("@/lib/ipc", async (orig) => ({
  ...(await orig<typeof import("@/lib/ipc")>()),
  listRecordingDevices: vi.fn(),
  startRecording: vi.fn().mockResolvedValue({ sessionId: "s" }),
  cancelRecording: vi.fn().mockResolvedValue(undefined),
  openRecorderBar: vi.fn().mockResolvedValue(undefined),
  closeRecorderBar: vi.fn().mockResolvedValue(undefined),
  hideRecorderBar: vi.fn().mockResolvedValue(undefined),
  setRecorderBarHeight: vi.fn().mockResolvedValue(undefined),
  onRecorderBarVisibility: vi.fn().mockResolvedValue(() => {}),
  openRecordingsFolder: vi.fn().mockResolvedValue(undefined),
  recordingThumbnail: vi.fn().mockResolvedValue("data:image/jpeg;base64,AAAA"),
  requestRecordingPermissions: vi.fn().mockResolvedValue({}),
  openPrivacySettings: vi.fn().mockResolvedValue(undefined),
}));
vi.mock("@/components/Recorder/useMediaPreview", () => ({
  useCameraPreview: () => ({ status: "off", reason: null, value: null }),
  useMicLevel: () => ({ status: "off", reason: null, value: 0 }),
}));

const devices: RecordingDevices = {
  backend: "native",
  video: [
    { index: 1000, name: "Built-in Display", isScreen: true },
    { index: 1001, name: "FaceTime", isScreen: false },
  ],
  audio: [{ index: 1000, name: "Mic" }],
  windows: [
    { id: 42, title: "Doc", app: "Pages" },
    { id: 43, title: "WordsCut Recording Controls — Setup", app: "WordsCut" },
  ],
  displays: [{ index: 1000, width: 1000, height: 600 }],
  permissions: { screenRecording: "granted", camera: "granted", microphone: "granted" },
};

async function mount(d: RecordingDevices = devices) {
  vi.mocked(ipc.listRecordingDevices).mockResolvedValue(d);
  render(<RecorderBarApp />);
  await act(async () => {});
}

beforeEach(() => {
  vi.clearAllMocks();
  window.localStorage.clear();
  useSettingsStore.setState({ recording: { ...defaultSettings().recording, countdownSec: 0 } });
  useBarStore.setState(initialBarState());
});
afterEach(cleanup);

describe("RecorderBarApp", () => {
  it("renders the modes and chips", async () => {
    await mount();
    for (const name of ["Display", "Window", "Area", "Camera", "System audio", "Microphone"]) {
      expect(screen.getByRole("button", { name })).toBeInTheDocument();
    }
    expect(screen.getByRole("button", { name: "Open recordings folder" })).toBeInTheDocument();
  });

  it("the window picker lists windows but not the app's own", async () => {
    await mount();
    fireEvent.click(screen.getByRole("button", { name: "Window" }));
    expect(screen.getByText("Doc")).toBeInTheDocument();
    expect(screen.queryByText(/Recording Controls/)).toBeNull();
  });

  it("Record area is disabled until an area is valid", async () => {
    await mount();
    fireEvent.click(screen.getByRole("button", { name: "Area" }));
    const record = screen.getByRole("button", { name: "Record area" });
    expect(record).toBeDisabled();
    act(() => useBarStore.getState().setArea({ x: 10, y: 10, width: 200, height: 100 }));
    expect(screen.getByRole("button", { name: "Record area" })).toBeEnabled();
    fireEvent.click(screen.getByRole("button", { name: "Record area" }));
    await vi.waitFor(() => expect(ipc.startRecording).toHaveBeenCalled());
    expect(vi.mocked(ipc.startRecording).mock.calls[0][0].area).toEqual({
      x: 10,
      y: 10,
      width: 200,
      height: 100,
    });
  });

  it("Esc during the countdown cancels without starting", async () => {
    useSettingsStore.setState({ recording: { ...defaultSettings().recording, countdownSec: 3 } });
    await mount();
    fireEvent.click(screen.getByRole("button", { name: "Display" }));
    await vi.waitFor(() => expect(screen.getByRole("status")).toBeInTheDocument());
    fireEvent.keyDown(window, { key: "Escape" });
    await vi.waitFor(() => expect(screen.getByRole("button", { name: "Display" })).toBeEnabled());
    expect(ipc.startRecording).not.toHaveBeenCalled();
    expect(ipc.closeRecorderBar).not.toHaveBeenCalled();
  });

  it("Esc in setup closes the bar and restores the editor", async () => {
    await mount();
    fireEvent.keyDown(window, { key: "Escape" });
    expect(ipc.closeRecorderBar).toHaveBeenCalledWith(true);
  });

  it("shows the permission chip for each state", async () => {
    await mount({ ...devices, permissions: { screenRecording: "notDetermined" } });
    fireEvent.click(screen.getByRole("button", { name: "Allow screen recording" }));
    expect(ipc.requestRecordingPermissions).toHaveBeenCalledWith(["screenRecording"]);
    cleanup();
    useBarStore.setState(initialBarState());
    await mount({ ...devices, permissions: { screenRecording: "denied" } });
    fireEvent.click(screen.getByRole("button", { name: "Open Settings" }));
    expect(ipc.openPrivacySettings).toHaveBeenCalledWith("screenRecording");
    await vi.waitFor(() =>
      expect(screen.getByText("Restart WordsCut to apply")).toBeInTheDocument(),
    );
  });

  it("hides the system audio chip on the ffmpeg backend", async () => {
    await mount({ ...devices, backend: "ffmpeg" });
    expect(screen.queryByRole("button", { name: "System audio" })).toBeNull();
    expect(screen.getByRole("button", { name: "Window" })).toBeDisabled();
  });

  it("grows the window for a popover", async () => {
    await mount();
    fireEvent.click(screen.getByRole("button", { name: "Recording settings" }));
    expect(ipc.setRecorderBarHeight).toHaveBeenCalled();
    expect(screen.getByRole("dialog", { name: "Recording settings" })).toBeInTheDocument();
  });

  it("offers key-name recording off by default, with the privacy note, and persists it", async () => {
    await mount();
    fireEvent.click(screen.getByRole("button", { name: "Recording settings" }));
    const identity = screen.getByRole("switch", { name: "Record key names" });
    expect(identity).toHaveAttribute("aria-checked", "false");
    expect(screen.queryByRole("switch", { name: /all characters/i })).toBeNull();
    expect(screen.getAllByRole("note")[0]!.textContent).toMatch(
      /any app while recording.*Terminal or iTerm sudo and ssh/,
    );
    fireEvent.click(identity);
    expect(useBarStore.getState().opts.recordKeyIdentity).toBe(true);
    const all = screen.getByRole("switch", { name: "Also record all characters" });
    expect(all).toHaveAttribute("aria-checked", "false");
    fireEvent.click(all);
    expect(useBarStore.getState().opts.recordAllCharacters).toBe(true);
    fireEvent.click(identity);
    expect(useBarStore.getState().opts.recordAllCharacters).toBe(false);
  });

  it("does not offer key-name recording on the ffmpeg backend", async () => {
    await mount({ ...devices, backend: "ffmpeg" });
    fireEvent.click(screen.getByRole("button", { name: "Recording settings" }));
    expect(screen.queryByRole("switch", { name: "Record key names" })).toBeNull();
  });
});
