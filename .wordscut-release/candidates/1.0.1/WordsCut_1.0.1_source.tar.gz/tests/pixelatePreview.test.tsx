/** The pixelate mask preview redraws on every presented video frame, not only when `t` changes. */

import { cleanup, render } from "@testing-library/react";
import { afterEach, expect, it, vi } from "vitest";
import { MaskLayer } from "@/components/VideoPreview/LayerOverlays";
import { sanitizeMasks } from "@/lib/masks";

afterEach(cleanup);

it("redraws the pixelated region on each requestVideoFrameCallback", () => {
  const drawImage = vi.fn();
  vi.spyOn(HTMLCanvasElement.prototype, "getContext").mockReturnValue({
    drawImage,
    fillRect: vi.fn(),
  } as unknown as CanvasRenderingContext2D);
  let onFrame: (() => void) | null = null;
  const cancel = vi.fn();
  const el = Object.assign(document.createElement("video"), {
    requestVideoFrameCallback: (cb: () => void) => ((onFrame = cb), 7),
    cancelVideoFrameCallback: cancel,
  });
  Object.defineProperties(el, {
    readyState: { value: 4 },
    videoWidth: { value: 1920 },
    videoHeight: { value: 1080 },
  });
  const m = sanitizeMasks([
    { id: "k", mediaId: "m", srcStart: 0, srcEnd: 9, effect: "pixelate" },
  ])[0]!;
  const { unmount } = render(
    <MaskLayer
      masks={[{ m, spans: [[0, 9]], width: 1920, height: 1080 }]}
      currentTime={1}
      playing={false}
      video={{ current: el }}
    />,
  );
  const drawn = drawImage.mock.calls.length;
  expect(drawn).toBeGreaterThan(0);
  // A new frame (e.g. the seeked frame decoding after `t` moved) with the same `t`.
  onFrame!();
  onFrame!();
  expect(drawImage.mock.calls.length).toBe(drawn * 3);
  unmount();
  expect(cancel).toHaveBeenCalledWith(7);
  vi.restoreAllMocks();
});
