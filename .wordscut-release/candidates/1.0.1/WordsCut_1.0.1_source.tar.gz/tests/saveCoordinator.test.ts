import { beforeEach, describe, expect, it, vi } from "vitest";
import { newProject } from "@/lib/edl";
import { useProjectStore } from "@/stores/projectStore";
import { saveProjectRevision } from "@/lib/saveCoordinator";
import { saveProject } from "@/lib/ipc";
vi.mock("@/lib/ipc", () => ({ saveProject: vi.fn() }));
beforeEach(() => {
  vi.mocked(saveProject).mockReset();
});
describe("snapshot-aware saving", () => {
  it("does not clear an edit made while the earlier revision is saving", async () => {
    let finish!: () => void;
    vi.mocked(saveProject).mockImplementation(
      () =>
        new Promise((resolve) => {
          finish = resolve;
        }),
    );
    const p = newProject("old");
    useProjectStore.setState({ project: p, dirty: true, filePath: "/tmp/revision.scribe" });
    const saving = saveProjectRevision(p, "/tmp/revision.scribe", "/tmp/revision.scribe");
    useProjectStore.getState().rename("new edit");
    finish();
    expect((await saving).current).toBe(false);
    expect(useProjectStore.getState().dirty).toBe(true);
  });
  it("clears dirty only for the same project snapshot and adopts a first save path", async () => {
    vi.mocked(saveProject).mockResolvedValue();
    const p = newProject("same");
    useProjectStore.setState({ project: p, dirty: true, filePath: null });
    expect((await saveProjectRevision(p, "/tmp/first.scribe", null)).current).toBe(true);
    expect(useProjectStore.getState()).toMatchObject({
      filePath: "/tmp/first.scribe",
      dirty: false,
    });
  });
  it("ignores completion after another project opens and preserves dirty on a failed save", async () => {
    let finish!: () => void;
    vi.mocked(saveProject).mockImplementation(
      () =>
        new Promise((resolve) => {
          finish = resolve;
        }),
    );
    const p = newProject("old");
    useProjectStore.setState({ project: p, dirty: true, filePath: null });
    const saving = saveProjectRevision(p, "/tmp/closed.scribe", null);
    const next = newProject("next");
    useProjectStore.setState({ project: next, dirty: true, filePath: null });
    finish();
    await saving;
    expect(useProjectStore.getState()).toMatchObject({
      project: next,
      dirty: true,
      filePath: null,
    });
    vi.mocked(saveProject).mockRejectedValue(new Error("disk full"));
    await expect(saveProjectRevision(next, "/tmp/failure.scribe", null)).rejects.toThrow(
      "disk full",
    );
    expect(useProjectStore.getState().dirty).toBe(true);
  });
  it("clears dirty for the latest queued first save after the earlier save adopts its path", async () => {
    const finishes: Array<() => void> = [];
    vi.mocked(saveProject).mockImplementation(
      () => new Promise((resolve) => finishes.push(resolve)),
    );
    const p = newProject("first");
    useProjectStore.setState({ project: p, dirty: true, filePath: null });
    const first = saveProjectRevision(p, "/tmp/queued-first.scribe", null);
    useProjectStore.getState().rename("newer");
    const latest = saveProjectRevision(
      useProjectStore.getState().project,
      "/tmp/queued-first.scribe",
      null,
    );
    finishes.shift()!();
    await first;
    finishes.shift()!();
    expect((await latest).current).toBe(true);
    expect(useProjectStore.getState().dirty).toBe(false);
  });
});
