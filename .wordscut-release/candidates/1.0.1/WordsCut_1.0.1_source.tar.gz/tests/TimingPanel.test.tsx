import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { TimingPanel } from "@/components/editor/sidebar/panels/TimingPanel";
import { newProject, type Project } from "@/lib/edl";
import { useEditorUiStore } from "@/stores/editorUiStore";
import { usePlayerStore } from "@/stores/playerStore";
import { useProjectStore } from "@/stores/projectStore";

const project: Project = {
  ...newProject("t"),
  media: {
    m: {
      id: "m",
      path: "/tmp/m.mp4",
      duration: 20,
      fps: 30,
      width: 1280,
      height: 720,
      audioSampleRate: 48000,
      sha256: "x",
    },
  },
  segments: [
    { id: "a", mediaId: "m", words: [], sourceIn: 0, sourceOut: 4 },
    { id: "b", mediaId: "m", words: [], sourceIn: 6, sourceOut: 10 },
  ],
};

const history = () => useProjectStore.temporal.getState().pastStates.length;

beforeEach(() => {
  useProjectStore.setState({ project, dirty: false });
  useProjectStore.temporal.getState().clear();
  useEditorUiStore.setState({ selectedClipId: null });
  usePlayerStore.setState({ currentTime: 5 });
});
afterEach(cleanup);

describe("Timing panel", () => {
  it("edits the clip under the playhead with labelled native controls, one undo step each", () => {
    render(<TimingPanel />);
    expect(screen.getByText("Clip 2 timing")).toBeTruthy();
    fireEvent.change(screen.getByLabelText("Speed"), { target: { value: "2" } });
    expect(useProjectStore.getState().project.segments[1]!.speed).toBe(2);
    expect(history()).toBe(1);

    // Typing a hold commits once, on Enter, not per keystroke.
    const hold = screen.getByLabelText("Freeze last frame (s)");
    fireEvent.change(hold, { target: { value: "1" } });
    fireEvent.change(hold, { target: { value: "1.5" } });
    expect(history()).toBe(1);
    fireEvent.keyDown(hold, { key: "Enter" });
    expect(useProjectStore.getState().project.segments[1]!.holdSec).toBe(1.5);
    expect(history()).toBe(2);

    fireEvent.change(screen.getByLabelText("Transition in"), { target: { value: "dip" } });
    expect(useProjectStore.getState().project.segments[1]!.transitionIn).toEqual({
      kind: "dip",
      duration: 0.5,
    });
    fireEvent.click(screen.getByLabelText("Mute this clip"));
    expect(useProjectStore.getState().project.segments[1]!.muted).toBe(true);
    expect(history()).toBe(4);
  });

  it("disables the transition on the first clip", () => {
    useEditorUiStore.setState({ selectedClipId: "a" });
    render(<TimingPanel />);
    expect((screen.getByLabelText("Transition in") as HTMLSelectElement).disabled).toBe(true);
  });
});
