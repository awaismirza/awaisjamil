import { describe, expect, it } from "vitest";
import {
  acceleratorFromEvent,
  defaultShortcuts,
  findShortcutConflict,
  formatAccelerator,
  normalizeAccelerator,
  SHORTCUT_DEFS,
  shortcutProblem,
} from "@/lib/shortcuts";

const key = (code: string, mods: Partial<Record<"metaKey" | "ctrlKey" | "altKey" | "shiftKey", boolean>> = {}) => ({
  code,
  metaKey: false,
  ctrlKey: false,
  altKey: false,
  shiftKey: false,
  ...mods,
});

describe("normalizeAccelerator", () => {
  it("orders modifiers and upper-cases letters", () => {
    expect(normalizeAccelerator("shift+alt+cmdorctrl+r")).toBe("CmdOrCtrl+Alt+Shift+R");
  });

  it("accepts the aliases people type", () => {
    expect(normalizeAccelerator("Command+Option+K")).toBe("CmdOrCtrl+Alt+K");
    expect(normalizeAccelerator("Control+f5")).toBe("Ctrl+F5");
  });

  it("treats the same shortcut spelled differently as equal", () => {
    expect(normalizeAccelerator("Alt+CmdOrCtrl+R")).toBe(normalizeAccelerator("cmd+option+r"));
  });

  it("rejects malformed input", () => {
    expect(normalizeAccelerator("")).toBeNull();
    expect(normalizeAccelerator("+")).toBeNull();
    expect(normalizeAccelerator("Hyper+R")).toBeNull();
    expect(normalizeAccelerator("CmdOrCtrl+Shift")).toBeNull();
    expect(normalizeAccelerator("CmdOrCtrl+F13")).toBeNull();
    expect(normalizeAccelerator("CmdOrCtrl+Ö")).toBeNull();
  });

  it("keeps named keys in their canonical spelling", () => {
    expect(normalizeAccelerator("alt+space")).toBe("Alt+Space");
    expect(normalizeAccelerator("alt+arrowup")).toBe("Alt+ArrowUp");
  });
});

describe("shortcutProblem", () => {
  it("accepts every default", () => {
    for (const d of SHORTCUT_DEFS) expect(shortcutProblem(d.default)).toBeNull();
  });

  it("requires a modifier unless it is a function key", () => {
    expect(shortcutProblem("R")).toBe("needs-modifier");
    expect(shortcutProblem("F5")).toBeNull();
  });

  it("refuses combinations the system owns", () => {
    expect(shortcutProblem("CmdOrCtrl+Q")).toBe("reserved");
    expect(shortcutProblem("cmd+c")).toBe("reserved");
  });

  it("flags unusable keys as invalid", () => {
    expect(shortcutProblem("CmdOrCtrl+Hyper")).toBe("invalid");
  });
});

describe("findShortcutConflict", () => {
  it("finds another action on the same accelerator, however it is spelled", () => {
    const map = defaultShortcuts();
    expect(findShortcutConflict(map, "pause", "option+cmd+r")).toBe("record");
  });

  it("does not conflict with itself", () => {
    const map = defaultShortcuts();
    expect(findShortcutConflict(map, "record", map.record)).toBeNull();
  });

  it("has no conflicts among the defaults", () => {
    const map = defaultShortcuts();
    for (const d of SHORTCUT_DEFS) expect(findShortcutConflict(map, d.action, map[d.action])).toBeNull();
  });
});

describe("formatAccelerator", () => {
  it("prints Mac symbols in macOS order", () => {
    expect(formatAccelerator("CmdOrCtrl+Alt+R")).toBe("⌥⌘R");
    expect(formatAccelerator("CmdOrCtrl+Shift+Ctrl+Alt+K")).toBe("⌃⌥⇧⌘K");
  });

  it("prints named keys as symbols", () => {
    expect(formatAccelerator("CmdOrCtrl+Alt+Backspace")).toBe("⌥⌘⌫");
    expect(formatAccelerator("Alt+ArrowLeft")).toBe("⌥←");
  });

  it("falls back to the raw text when it cannot be parsed", () => {
    expect(formatAccelerator("nonsense+++")).toBe("nonsense+++");
  });
});

describe("acceleratorFromEvent", () => {
  it("builds an accelerator from a modified key", () => {
    expect(acceleratorFromEvent(key("KeyR", { metaKey: true, altKey: true }))).toBe("CmdOrCtrl+Alt+R");
  });

  it("uses the physical key, so Option+letter still resolves", () => {
    // On a Mac, Option+R types a special character in `key`; `code` stays KeyR.
    expect(acceleratorFromEvent(key("KeyR", { altKey: true }))).toBe("Alt+R");
  });

  it("returns null while only a modifier is held", () => {
    expect(acceleratorFromEvent(key("MetaLeft", { metaKey: true }))).toBeNull();
    expect(acceleratorFromEvent(key("AltLeft", { altKey: true }))).toBeNull();
  });

  it("reads digits, function keys and arrows", () => {
    expect(acceleratorFromEvent(key("Digit7", { metaKey: true }))).toBe("CmdOrCtrl+7");
    expect(acceleratorFromEvent(key("F9", { shiftKey: true }))).toBe("Shift+F9");
    expect(acceleratorFromEvent(key("ArrowUp", { altKey: true }))).toBe("Alt+ArrowUp");
  });

  it("keeps Ctrl distinct from Cmd", () => {
    expect(acceleratorFromEvent(key("KeyK", { ctrlKey: true }))).toBe("Ctrl+K");
  });
});
