import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { ZoomPanel } from "@/components/editor/sidebar/panels/ZoomPanel";
import { addMediaWithTranscript, newProject } from "@/lib/edl";
import { parseCursorLog } from "@/lib/cursor";
import { useProjectStore } from "@/stores/projectStore";
import { syntheticCursorLog } from "./fixtures/cursorLogs";
beforeEach(() => {
  const p = addMediaWithTranscript(
    newProject("test"),
    {
      id: "m",
      path: "/tmp/demo.mp4",
      duration: 20,
      width: 1920,
      height: 1080,
      fps: 30,
      audioSampleRate: 48000,
      sha256: "x",
    },
    [],
  );
  useProjectStore.setState({ project: p, dirty: false });
  useProjectStore.temporal.getState().clear();
});
afterEach(() => {
  cleanup();
  vi.restoreAllMocks();
});
describe("Zoom panel", () => {
  it("hides cursor tools for a clip without cursor data", () => {
    render(<ZoomPanel />);
    expect(screen.getByText(/This clip has no cursor data/)).toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "Generate from cursor" })).toBeNull();
    expect(screen.queryByLabelText("Follow cursor")).toBeNull();
    expect(screen.queryByLabelText("Cursor styling")).toBeNull();
  });
  it("shows cursor tools once the clip has cursor data", () => {
    useProjectStore.getState().setCursorTrack("m", parseCursorLog(syntheticCursorLog()));
    render(<ZoomPanel />);
    fireEvent.click(screen.getByLabelText("Follow cursor"));
    expect(useProjectStore.getState().project.cursor?.autoZoom.follow).toBe(true);
    expect(screen.getByLabelText("Cursor styling")).toBeInTheDocument();
  });
  it("reviews, plays, keeps/removes and applies suggestions; invalidates stale review after edits", async () => {
    useProjectStore.getState().setCursorTrack("m", parseCursorLog(syntheticCursorLog()));
    render(<ZoomPanel />);
    fireEvent.click(screen.getByRole("button", { name: "Generate from cursor" }));
    await waitFor(() =>
      expect(screen.getByRole("button", { name: "Add 3 zoom regions" })).toBeInTheDocument(),
    );
    const dispatch = vi.spyOn(window, "dispatchEvent");
    fireEvent.click(screen.getByRole("button", { name: "Play zoom at 1.6" }));
    expect(dispatch).toHaveBeenCalledWith(
      expect.objectContaining({ type: "yusafcut:seek-output", detail: { time: 1.6, play: true } }),
    );
    fireEvent.click(screen.getByLabelText("Keep zoom at 1.6"));
    fireEvent.click(screen.getByRole("button", { name: "Remove suggestion at 5.6" }));
    fireEvent.click(screen.getByRole("button", { name: "Add 1 zoom regions" }));
    expect(useProjectStore.getState().project.zoomRegions).toHaveLength(1);
    fireEvent.click(screen.getByRole("button", { name: "Generate from cursor" }));
    await waitFor(() =>
      expect(
        screen.getByRole("button", { name: "Replace existing zoom regions" }),
      ).toBeInTheDocument(),
    );
    fireEvent.change(screen.getByLabelText("Sensitivity"), { target: { value: "low" } });
    expect(
      screen.queryByRole("button", { name: "Replace existing zoom regions" }),
    ).not.toBeInTheDocument();
  });
});
