import { describe, expect, it } from "vitest";
import { SeekQueue, type IssuedSeek, type SeekTarget } from "@/lib/seekQueue";

function target(time: number, patch: Partial<SeekTarget> = {}): SeekTarget {
  return { mediaId: "media-a", sourceId: "original-a", time, exact: false, ...patch };
}

function issued(value: IssuedSeek | null): IssuedSeek {
  expect(value).not.toBeNull();
  return value!;
}

describe("SeekQueue", () => {
  it("issues one seek and coalesces a burst to its latest target", () => {
    const queue = new SeekQueue();
    const first = issued(queue.request(target(1)));
    for (let time = 2; time <= 100; time += 1) {
      expect(queue.request(target(time))).toBeNull();
    }
    const latest = issued(queue.complete(first.token));
    expect(latest.time).toBe(100);
    expect(latest.token.sequence).toBeGreaterThan(first.token.sequence);
    expect(queue.complete(latest.token)).toBeNull();
    expect(issued(queue.request(target(101))).time).toBe(101);
  });

  it("ignores duplicate and mismatched completions while retaining queued work", () => {
    const queue = new SeekQueue();
    const first = issued(queue.request(target(1)));
    queue.request(target(2));
    const second = issued(queue.complete(first.token));
    queue.request(target(3));
    expect(queue.complete(first.token)).toBeNull();
    expect(queue.complete({ ...second.token, mediaId: "other" })).toBeNull();
    expect(queue.complete({ ...second.token, sourceId: "other" })).toBeNull();
    expect(queue.complete({ ...second.token, generation: -1 })).toBeNull();
    expect(issued(queue.complete(second.token)).time).toBe(3);
  });

  it("applies exact release after a late approximate seek, even at the same time", () => {
    const queue = new SeekQueue();
    const approximate = issued(queue.request(target(7)));
    queue.request(target(8));
    expect(queue.request(target(7, { exact: true }))).toBeNull();
    const exact = issued(queue.complete(approximate.token));
    expect(exact.time).toBe(7);
    expect(exact.exact).toBe(true);
    queue.request(target(9));
    expect(queue.complete(approximate.token)).toBeNull();
    expect(issued(queue.complete(exact.token)).time).toBe(9);
  });

  it("starts a new media seek immediately and ignores old-media completion", () => {
    const queue = new SeekQueue();
    const old = issued(queue.request(target(1)));
    queue.request(target(2, { exact: true }));
    const next = issued(queue.request(target(3, { mediaId: "media-b", sourceId: "original-b" })));
    expect(next.token.generation).toBeGreaterThan(old.token.generation);
    queue.request(target(4, { mediaId: "media-b", sourceId: "original-b" }));
    expect(queue.complete(old.token)).toBeNull();
    expect(issued(queue.complete(next.token)).time).toBe(4);
  });

  it("invalidates an old original when switching the same media to a proxy", () => {
    const queue = new SeekQueue();
    const original = issued(queue.request(target(1)));
    const proxy = issued(queue.request(target(1, { sourceId: "proxy-a", exact: true })));
    expect(queue.complete(original.token)).toBeNull();
    expect(queue.complete(proxy.token)).toBeNull();
    expect(issued(queue.request(target(2, { sourceId: "proxy-a" }))).time).toBe(2);
  });

  it("reset cancels pending and queued work, including on the same source", () => {
    const queue = new SeekQueue();
    const old = issued(queue.request(target(1)));
    queue.request(target(2));
    queue.reset();
    expect(queue.complete(old.token)).toBeNull();
    const next = issued(queue.request(target(3)));
    queue.request(target(4));
    expect(queue.complete(old.token)).toBeNull();
    expect(issued(queue.complete(next.token)).time).toBe(4);
  });

  it("snapshots requests so caller mutation cannot alter queued targets", () => {
    const queue = new SeekQueue();
    const first = issued(queue.request(target(1)));
    const mutable = { ...target(2, { exact: true }) };
    queue.request(mutable);
    mutable.time = 20;
    mutable.sourceId = "different";
    const next = issued(queue.complete(first.token));
    expect(next).toMatchObject({ time: 2, sourceId: "original-a", exact: true });
    expect(Object.isFrozen(next)).toBe(true);
    expect(Object.isFrozen(next.token)).toBe(true);
  });

  it("rejects invalid times without disturbing an issued or queued seek", () => {
    const queue = new SeekQueue();
    const first = issued(queue.request(target(1)));
    queue.request(target(2));
    for (const time of [-1, NaN, Infinity]) {
      expect(() => queue.request(target(time))).toThrow(RangeError);
    }
    expect(issued(queue.complete(first.token)).time).toBe(2);
  });
});
