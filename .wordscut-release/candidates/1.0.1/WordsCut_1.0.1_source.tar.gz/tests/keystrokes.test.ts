import { describe, expect, it } from "vitest";
import fixture from "./fixtures/keystroke-identity.json";
import { addMediaWithTranscript, newProject, type Project } from "@/lib/edl";
import { parseCursorLog } from "@/lib/cursor";
import { sanitizeProjectCursor } from "@/lib/cursorStyle";
import {
  captionLabel,
  keyCaps,
  keyCaptionAt,
  keystrokeCaptions,
  sanitizeKeystrokes,
} from "@/lib/keystrokes";

function project(log: string, segments: Array<[number, number]>): Project {
  const p = addMediaWithTranscript(
    newProject("k"),
    {
      id: "m",
      path: "/x.mp4",
      duration: 10,
      fps: 30,
      width: 1920,
      height: 1080,
      audioSampleRate: 48000,
      sha256: "",
    },
    [],
  );
  const seg = p.segments[0]!;
  const cursor = sanitizeProjectCursor(undefined);
  return {
    ...p,
    segments: segments.map(([a, b], i) => ({ ...seg, id: `s${i}`, sourceIn: a, sourceOut: b })),
    cursor: { ...cursor, tracks: { m: parseCursorLog(log) } },
  };
}

// Same events as `keystrokes_are_opt_in_shortcut_only_and_follow_cuts` in annotations_export.rs.
const LOG = [
  '{"type":"key","t":0.5}',
  '{"type":"key","t":1.0,"mods":["shift"]}',
  '{"type":"key","t":1.2,"mods":["cmd","shift"]}',
  '{"type":"key","t":1.6,"mods":["shift","cmd"]}',
  '{"type":"key","t":2.5,"mods":["ctrl"]}',
  '{"type":"key","t":3.5,"mods":["alt"]}',
].join("\n");

describe("keystroke captions", () => {
  it("are opt-in and default to shortcuts only", () => {
    expect(sanitizeKeystrokes(undefined)).toEqual({ enabled: false, mode: "shortcuts" });
    expect(sanitizeKeystrokes({ enabled: "yes", mode: "everything" })).toEqual({
      enabled: false,
      mode: "shortcuts",
    });
    const p = project(LOG, [[0, 4]]);
    expect(keystrokeCaptions(p, sanitizeKeystrokes(p.keystrokes))).toEqual([]);
  });

  it("show modifiers in macOS order plus a generic key; plain typing only in all mode", () => {
    expect(keyCaps(["cmd", "shift"], "shortcuts")).toEqual(["⇧", "⌘", "key"]);
    expect(keyCaps(["alt", "ctrl", "cmd"], "shortcuts")).toEqual(["⌃", "⌥", "⌘", "key"]);
    expect(keyCaps(["shift"], "shortcuts")).toBeNull();
    expect(keyCaps([], "shortcuts")).toBeNull();
    expect(keyCaps(["shift"], "all")).toEqual(["Typing"]);
  });

  it("merge repeats, end at the next combination and follow cuts (shared with Rust)", () => {
    const p = project(LOG, [
      [0, 2],
      [3, 4],
    ]);
    const c = keystrokeCaptions(p, { enabled: true, mode: "shortcuts" });
    expect(c.map((x) => [x.start, x.end, captionLabel(x)])).toEqual([
      [1.2, 2.5, "⇧ ⌘ key ×2"],
      [2.5, 3, "⌥ key"],
    ]);
    expect(keyCaptionAt(c, 2)).toBe(c[0]);
    expect(keyCaptionAt(c, 3)).toBeNull();
    const all = keystrokeCaptions(p, { enabled: true, mode: "all" });
    expect(all[0]).toMatchObject({ start: 0.5, end: 1.2, caps: ["Typing"], count: 2 });
    expect(captionLabel(all[0]!)).toBe("Typing");
  });

  it("presses further apart than the merge window are separate captions", () => {
    const p = project('{"type":"key","t":1,"mods":["cmd"]}\n{"type":"key","t":3,"mods":["cmd"]}', [
      [0, 10],
    ]);
    const c = keystrokeCaptions(p, { enabled: true, mode: "shortcuts" });
    expect(c.map((x) => [x.start, x.end, x.count])).toEqual([
      [1, 2, 1],
      [3, 4, 1],
    ]);
  });
});

describe("key identity (shared with Rust)", () => {
  for (const c of fixture.cases) {
    it(`${c.name} matches the shared fixture`, () => {
      const p = project(c.events.map((e) => JSON.stringify(e)).join("\n"), [[0, 10]]);
      const got = keystrokeCaptions(p, { enabled: true, mode: c.mode as "shortcuts" | "all" });
      expect(got.map((x) => [x.start, x.end, captionLabel(x)])).toEqual(
        c.expected.map((x) => [expect.closeTo(x.start, 9), expect.closeTo(x.end, 9), x.label]),
      );
    });
  }

  it("parses name and secure tolerantly and drops hostile values", () => {
    const t = parseCursorLog(
      [
        '{"type":"key","t":1,"mods":["cmd"],"name":"k","future":1}',
        '{"type":"key","t":2,"name":5,"secure":"yes"}',
        '{"type":"key","t":3,"name":"","secure":true}',
        '{"type":"key","t":4,"name":"a\\u0000b"}',
        '{"type":"key","t":5,"name":"12345678901234567"}',
        '{"type":"key","t":6,"name":"\\uf700"}',
        "not json",
      ].join("\n"),
    );
    expect(t.events).toEqual([
      { type: "key", t: 1, mods: ["cmd"], name: "k" },
      { type: "key", t: 2, mods: [] },
      { type: "key", t: 3, mods: [], secure: true },
      { type: "key", t: 4, mods: [] },
      { type: "key", t: 5, mods: [] },
      { type: "key", t: 6, mods: [] },
    ]);
  });

  it("old logs without name or secure render exactly as before", () => {
    expect(keyCaps(["cmd"], "shortcuts")).toEqual(["⌘", "key"]);
    expect(keyCaps([], "all")).toEqual(["Typing"]);
    expect(keyCaps(["cmd"], "shortcuts", "__proto__")).toEqual(["⌘", "key"]);
    expect(keyCaps([], "all", "insert")).toEqual(["Ins"]);
    expect(keyCaps(["ctrl"], "shortcuts", "clear")).toEqual(["⌃", "Clear"]);
  });
});
