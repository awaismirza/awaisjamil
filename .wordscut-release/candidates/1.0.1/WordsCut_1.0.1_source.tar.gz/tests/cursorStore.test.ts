import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { sanitizeProjectCursor } from "@/lib/cursorStyle";
import { parseCursorLog } from "@/lib/cursor";
import { addMediaWithTranscript, computeTimeline, newProject } from "@/lib/edl";
import { generateAutoZoom } from "@/lib/autoZoom";
import { useProjectStore } from "@/stores/projectStore";
import { syntheticCursorLog } from "./fixtures/cursorLogs";
export function cursorProject() {
  return addMediaWithTranscript(
    newProject("cursor"),
    {
      id: "m",
      path: "/tmp/demo.mp4",
      duration: 20,
      width: 1920,
      height: 1080,
      fps: 30,
      audioSampleRate: 48000,
      sha256: "x",
    },
    [],
  );
}
beforeEach(() => {
  vi.useFakeTimers();
  useProjectStore.setState({ project: cursorProject(), dirty: false });
  useProjectStore.temporal.getState().clear();
});
afterEach(() => {
  vi.runOnlyPendingTimers();
  vi.useRealTimers();
});
describe("cursor project settings", () => {
  it("sanitizes settings and tracks without trusting derived points or unknown fields", () => {
    const c = sanitizeProjectCursor({
      style: { size: 999, color: "url(bad)", smoothing: Infinity, clickEffect: "bad" },
      autoZoom: { scale: 90, sensitivity: "bad" },
      tracks: { m: { points: [{ t: 0, x: 9, y: 9 }] } },
    });
    expect(c.style).toMatchObject({
      size: 96,
      color: "#ffffff",
      smoothing: 0.1,
      clickEffect: "ripple",
    });
    expect(c.autoZoom).toMatchObject({ scale: 4, sensitivity: "medium" });
    expect(c.tracks).toEqual({});
  });
  it("persists source tracks/settings, is undoable and never mutates old project snapshots", () => {
    const first = useProjectStore.getState().project;
    const track = parseCursorLog(syntheticCursorLog());
    useProjectStore.getState().setCursorTrack("m", track);
    const before = useProjectStore.getState().project;
    useProjectStore.getState().setCursorStyle({ shape: "ring" });
    vi.advanceTimersByTime(200);
    useProjectStore.getState().setAutoZoom({ follow: true });
    vi.advanceTimersByTime(200);
    const after = useProjectStore.getState().project;
    expect(first.cursor).toBeUndefined();
    expect(before.cursor?.style.shape).toBe("macos");
    expect(after.cursor?.style.shape).toBe("ring");
    expect(after.cursor?.autoZoom.follow).toBe(true);
    useProjectStore.temporal.getState().undo();
    expect(useProjectStore.getState().project.cursor?.autoZoom.follow).toBe(false);
    useProjectStore.getState().setProject(JSON.parse(JSON.stringify(after)));
    expect(useProjectStore.getState().project.cursor).toEqual(after.cursor);
    expect(useProjectStore.getState().dirty).toBe(true);
  });
  it("ignores unknown media and removes a cleared track", () => {
    useProjectStore.getState().setCursorTrack("no", parseCursorLog(syntheticCursorLog()));
    expect(useProjectStore.getState().dirty).toBe(false);
    useProjectStore.getState().setCursorTrack("m", parseCursorLog(syntheticCursorLog()));
    useProjectStore.getState().setCursorTrack("m", parseCursorLog(""));
    expect(useProjectStore.getState().project.cursor?.tracks).toEqual({});
  });
  it("adds/replaces a reviewed set in one undo step and does not duplicate ids on regeneration", () => {
    const p = useProjectStore.getState().project;
    const suggestions = generateAutoZoom(
      { m: parseCursorLog(syntheticCursorLog()) },
      computeTimeline(p),
      { follow: true },
    );
    useProjectStore.getState().addZoomRegion({ id: "manual", start: 17, end: 19 });
    vi.advanceTimersByTime(200);
    useProjectStore.temporal.getState().clear();
    useProjectStore.getState().applyZoomSuggestions(suggestions, false);
    expect(useProjectStore.getState().project.zoomRegions).toHaveLength(4);
    vi.advanceTimersByTime(200);
    useProjectStore.temporal.getState().undo();
    expect(useProjectStore.getState().project.zoomRegions?.map((r) => r.id)).toEqual(["manual"]);
    useProjectStore.getState().applyZoomSuggestions(suggestions, true);
    expect(useProjectStore.getState().project.zoomRegions).toEqual(suggestions);
    useProjectStore.getState().applyZoomSuggestions(suggestions, false);
    const regions = useProjectStore.getState().project.zoomRegions!;
    expect(new Set(regions.map((r) => r.id)).size).toBe(regions.length);
  });
});
