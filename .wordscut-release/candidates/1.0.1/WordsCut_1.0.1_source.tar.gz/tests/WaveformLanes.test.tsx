import { act, cleanup, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, expect, it, vi } from "vitest";

vi.mock("@/lib/ipc", () => ({
  generateWaveform: vi.fn(async () => ({
    version: 1,
    sampleRate: 100,
    samplesPerPeak: 1,
    levels: [{ samplesPerPeak: 1, peaks: [0.5, 0.5, 0.5, 0.5] }],
  })),
}));

import { generateWaveform } from "@/lib/ipc";
import { Waveform } from "@/components/Waveform/Waveform";
import { addMediaWithTranscript, newProject, type Project } from "@/lib/edl";
import { useProjectStore } from "@/stores/projectStore";
import { useTimelineViewStore } from "@/stores/timelineViewStore";

const media = {
  id: "m",
  path: "/m.mp4",
  duration: 4,
  fps: 25,
  width: 100,
  height: 100,
  audioSampleRate: 8000,
  sha256: "x",
};

/** Two surviving pieces with 1 s of source removed between them: one cut. */
function projectWithCut(): Project {
  const p = addMediaWithTranscript(newProject("w"), media, []);
  const a = p.segments[0]!;
  return {
    ...p,
    segments: [
      { ...a, id: "a", sourceIn: 0, sourceOut: 1 },
      { ...a, id: "b", sourceIn: 2, sourceOut: 4 },
    ],
  };
}

beforeEach(() => {
  class RO {
    observe() {}
    disconnect() {}
  }
  vi.stubGlobal("ResizeObserver", RO);
  Object.defineProperty(HTMLElement.prototype, "clientWidth", { configurable: true, value: 600 });
  useTimelineViewStore.getState().reset();
  useProjectStore.temporal.getState().resume();
  useProjectStore.setState({ project: projectWithCut() });
  useProjectStore.temporal.getState().clear();
});
afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
  delete (HTMLElement.prototype as { clientWidth?: number }).clientWidth;
});

const lane = (name: string) => document.querySelector(`[data-lane="${name}"]`);
const setLane = (
  id: Parameters<ReturnType<typeof useTimelineViewStore.getState>["setLane"]>[0],
  on: boolean,
) => act(() => useTimelineViewStore.getState().setLane(id, on));

it("renders waveform once peaks load, cut map only when enabled", async () => {
  render(<Waveform />);
  await waitFor(() => expect(lane("waveform")).not.toBeNull());
  expect(lane("cutMap")).toBeNull();
  setLane("cutMap", true);
  expect(lane("cutMap")).not.toBeNull();
  expect(screen.getByRole("button", { name: /^Cut 1 at / })).toBeTruthy();
  setLane("waveform", false);
  expect(lane("waveform")).toBeNull();
});

it("uses the subtle waveform in Simple and full height in Detailed", async () => {
  render(<Waveform />);
  await waitFor(() => expect(lane("waveform")).not.toBeNull());
  expect(lane("waveform")!.className).toContain("is-subtle");
  act(() => useTimelineViewStore.getState().setPreset("detailed"));
  expect(lane("waveform")!.className).not.toContain("is-subtle");
});

it("toggling lanes leaves the time-to-pixel mapping and playhead untouched", async () => {
  render(<Waveform />);
  await waitFor(() => expect(lane("waveform")).not.toBeNull());
  const rail = () => document.querySelector<HTMLElement>(".timeline-rail")!;
  const head = () => document.querySelector<HTMLElement>(".timeline-playhead")!;
  const before = [rail().style.width, head().style.transform];
  expect(before[0]).toBe("600px");
  setLane("clips", false);
  setLane("waveform", false);
  setLane("zoom", false);
  setLane("cutMap", true);
  expect(rail()).toBeTruthy();
  expect([rail().style.width, head().style.transform]).toEqual(before);
  expect(useProjectStore.temporal.getState().pastStates).toHaveLength(0);
});

it("does not decode audio while the waveform lane is off, and decodes once on enabling", async () => {
  const gen = vi.mocked(generateWaveform);
  gen.mockClear();
  setLane("waveform", false);
  render(<Waveform />);
  await act(async () => {});
  expect(gen).not.toHaveBeenCalled();
  setLane("waveform", true);
  await waitFor(() => expect(lane("waveform")).not.toBeNull());
  expect(gen).toHaveBeenCalledTimes(1);
});

it("cut ticks are not tab stops; the cut map group is the single one", () => {
  render(<Waveform />);
  setLane("cutMap", true);
  const tick = screen.getByRole("button", { name: /^Cut 1 at / });
  expect(tick.getAttribute("tabindex")).toBe("-1");
  expect(lane("cutMap")!.getAttribute("tabindex")).toBe("0");
});
