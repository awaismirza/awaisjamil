import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { ScenePanel } from "@/components/editor/sidebar/panels/ScenePanel";
import { addMediaWithTranscript, newProject } from "@/lib/edl";
import { useProjectStore } from "@/stores/projectStore";

beforeEach(() => {
  const p = addMediaWithTranscript(
    newProject("test"),
    {
      id: "m",
      path: "/tmp/demo.mp4",
      duration: 20,
      width: 1920,
      height: 1080,
      fps: 30,
      audioSampleRate: 48000,
      sha256: "x",
    },
    [{ id: "w0", text: "Hello", start: 0, end: 0.4, confidence: 1 }],
  );
  useProjectStore.setState({ project: p, dirty: false });
  useProjectStore.temporal.getState().clear();
});
afterEach(cleanup);

const frame = () => useProjectStore.getState().project.scene?.frame;
const undoSteps = () => useProjectStore.temporal.getState().pastStates.length;

describe("Look panel: device frame", () => {
  it("offers None and the four devices as named radios, and picking one turns the look on", () => {
    render(<ScenePanel />);
    const group = screen.getByRole("radiogroup", { name: "Device frame type" });
    expect(group).toBeInTheDocument();
    expect(screen.getByRole("radio", { name: "None" })).toHaveAttribute("aria-checked", "true");
    for (const name of ["Browser", "Laptop", "Phone", "Tablet"]) {
      expect(screen.getByRole("radio", { name })).toBeInTheDocument();
    }
    fireEvent.click(screen.getByRole("radio", { name: "Phone" }));
    expect(frame()).toEqual({ kind: "phone", theme: "light" });
    expect(useProjectStore.getState().project.scene?.enabled).toBe(true);
    expect(screen.getByRole("radio", { name: "Phone" })).toHaveAttribute("aria-checked", "true");
    expect(undoSteps()).toBe(1);
  });

  it("the phone has a generic camera cutout choice: dot (default), notch or none", () => {
    render(<ScenePanel />);
    fireEvent.click(screen.getByRole("radio", { name: "Phone" }));
    expect(screen.getByRole("radio", { name: "Dot" })).toHaveAttribute("aria-checked", "true");
    fireEvent.click(screen.getByRole("radio", { name: "Notch" }));
    expect(frame()?.cutout).toBe("notch");
    fireEvent.click(screen.getByRole("radio", { name: "No cutout" }));
    expect(frame()?.cutout).toBe("none");
    fireEvent.click(screen.getByRole("radio", { name: "Laptop" }));
    expect(screen.queryByRole("radio", { name: "Notch" })).toBeNull();
  });

  it("None removes the device without switching a disabled look on", () => {
    useProjectStore
      .getState()
      .setScene({ frame: { kind: "laptop", theme: "light" }, enabled: false });
    useProjectStore.temporal.getState().clear();
    render(<ScenePanel />);
    fireEvent.click(screen.getByRole("radio", { name: "None" }));
    expect(frame()).toBeUndefined();
    expect(useProjectStore.getState().project.scene?.enabled).toBe(false);
  });

  it("the browser has a style, an address text field and a colour; the text is one undo step", () => {
    render(<ScenePanel />);
    fireEvent.click(screen.getByRole("radio", { name: "Browser" }));
    fireEvent.click(screen.getByRole("radio", { name: "Dark" }));
    expect(frame()).toEqual({ kind: "browser", theme: "dark" });
    const input = screen.getByRole("textbox", { name: "Address bar text" });
    const before = undoSteps();
    fireEvent.change(input, { target: { value: "ex" } });
    fireEvent.change(input, { target: { value: "example.com {\\N}" } });
    expect(frame()?.title).toBeUndefined();
    fireEvent.keyDown(input, { key: "Enter" });
    expect(frame()?.title).toBe("example.com {\\N}");
    expect(undoSteps()).toBe(before + 1);
    // Escape reverts an unsent edit.
    fireEvent.change(input, { target: { value: "other" } });
    fireEvent.keyDown(input, { key: "Escape" });
    expect((input as HTMLInputElement).value).toBe("example.com {\\N}");
    // Other devices have no address text.
    fireEvent.click(screen.getByRole("radio", { name: "Laptop" }));
    expect(screen.queryByRole("textbox", { name: "Address bar text" })).toBeNull();
  });

  it("the default-colour button is only enabled once a colour was chosen", () => {
    useProjectStore.getState().setScene({ frame: { kind: "tablet", theme: "light" } });
    render(<ScenePanel />);
    const reset = screen.getByRole("button", { name: "Use the default colour" });
    expect(reset).toBeDisabled();
    cleanup();
    useProjectStore
      .getState()
      .setScene({ frame: { kind: "tablet", theme: "light", color: "#336699" } });
    render(<ScenePanel />);
    const enabled = screen.getByRole("button", { name: "Use the default colour" });
    expect(enabled).toBeEnabled();
    fireEvent.click(enabled);
    expect(frame()).toEqual({ kind: "tablet", theme: "light" });
  });

  it("the corner slider gives way to the device, and returns without one", () => {
    render(<ScenePanel />);
    expect(screen.getByText("Rounded corners")).toBeInTheDocument();
    fireEvent.click(screen.getByRole("radio", { name: "Laptop" }));
    expect(screen.queryByText("Rounded corners")).toBeNull();
    expect(screen.getByText(/comes from the device frame/)).toBeInTheDocument();
    fireEvent.click(screen.getByRole("radio", { name: "None" }));
    expect(screen.getByText("Rounded corners")).toBeInTheDocument();
  });

  it("a slider drag with a device on is still one undo step", () => {
    useProjectStore.getState().setScene({ frame: { kind: "phone", theme: "light" } });
    useProjectStore.temporal.getState().clear();
    render(<ScenePanel />);
    const padding = screen.getAllByRole("slider")[0]!;
    fireEvent.change(padding, { target: { value: "12" } });
    fireEvent.change(padding, { target: { value: "14" } });
    expect(useProjectStore.getState().project.scene?.paddingPct).toBe(8);
    fireEvent.pointerUp(padding);
    expect(useProjectStore.getState().project.scene?.paddingPct).toBe(14);
    expect(undoSteps()).toBe(1);
    expect(frame()?.kind).toBe("phone");
  });
});
