import { beforeEach, describe, expect, it } from "vitest";
import {
  addMediaWithTranscript,
  computeTimeline,
  deleteWords,
  newProject,
  retimeAfterEdit,
  type Project,
  type SourceMedia,
  type Word,
} from "@/lib/edl";
import {
  annotationOpacity,
  arrowPolygon,
  cleanText,
  makeAnnotation,
  retimeAnnotations,
  sanitizeAnnotations,
  type Annotation,
  MAX_ANNOTATIONS,
} from "@/lib/annotations";

describe("review fixes", () => {
  it("strips colour emoji (export cannot draw them) but keeps symbols, CJK and Hangul", () => {
    // Same input and output as emoji_are_stripped_symbols_kept_and_count_capped in Rust.
    expect(cleanText("👍🏽 ok ©™ ⌘⇧ ✓ 日本 한국 ❤️ 🇬🇧")).toBe(" ok ©™ ⌘⇧ ✓ 日本 한국 ❤ ");
    expect(sanitizeAnnotations([{ kind: "text", start: 0, end: 1, text: "🎉" }], 4)).toEqual([]);
  });

  it("caps the number of annotations", () => {
    const many = Array.from({ length: 600 }, (_, i) => ({
      id: `${i}`,
      kind: "box",
      start: 0,
      end: 1,
    }));
    expect(sanitizeAnnotations(many, 4)).toHaveLength(MAX_ANNOTATIONS);
  });

  it("hostile stored zoom/annotation JSON cannot make an edit throw", () => {
    for (const junk of [[null], { length: 1 }, [{ start: "x" }], "nope"]) {
      const p = { ...base(), annotations: junk, zoomRegions: junk } as unknown as Project;
      const after = deleteWords(p, new Set(["w5"]));
      expect(after.annotations).toBeUndefined();
      expect(after.zoomRegions).toBeUndefined();
    }
  });

  it("a split annotation fades in only on its first piece and out only on its last", () => {
    const p = base();
    const seg = p.segments[0]!;
    const twice: Project = {
      ...p,
      segments: [
        { ...seg, id: "a", sourceIn: 0, sourceOut: 5 },
        { ...seg, id: "b", sourceIn: 2, sourceOut: 4 },
      ],
    };
    const a = { ...box("x", 2, 4), fadeInMs: 300, fadeOutMs: 400 };
    const [first, last] = retimeAnnotations([a], computeTimeline(p), computeTimeline(twice), 7);
    expect([first!.fadeInMs, first!.fadeOutMs]).toEqual([300, undefined]);
    expect([last!.fadeInMs, last!.fadeOutMs]).toEqual([undefined, 400]);
  });
});
import { replaceProjectBaseline, useProjectStore } from "@/stores/projectStore";

const media: SourceMedia = {
  id: "m",
  path: "/tmp/m.mp4",
  duration: 20,
  fps: 30,
  width: 1920,
  height: 1080,
  audioSampleRate: 48000,
  sha256: "x",
};
const words: Word[] = Array.from({ length: 20 }, (_, i) => ({
  id: `w${i}`,
  text: `w${i}`,
  start: i,
  end: i + 1,
  confidence: 1,
}));
function base(): Project {
  const p = addMediaWithTranscript(newProject("t"), media, words);
  return { ...p, settings: { ...p.settings, paddingMs: 0 } };
}
const box = (id: string, start: number, end: number): Annotation =>
  sanitizeAnnotations([{ id, kind: "box", start, end }], 20)[0]!;

describe("annotation model", () => {
  it("drops junk, clamps geometry and keeps unicode text", () => {
    const list = sanitizeAnnotations(
      [
        {
          kind: "text",
          start: 1,
          end: 3,
          x: 2,
          y: -1,
          text: "Héllo 日本\u0007 {x}",
          fadeInMs: 3000,
          fadeOutMs: 3000,
          color: "#ABCDEF",
        },
        { kind: "text", start: 0, end: 1, text: "  " },
        { kind: "box", start: 0, end: 0.1 },
        { kind: "circle", start: 0, end: 2 },
        { kind: "arrow", start: 0, end: 99, x: 0.9, y: 0.5, w: 0.5, h: 0.1, stroke: 100 },
        "junk",
        null,
      ],
      4,
    );
    expect(list.map((a) => a.kind)).toEqual(["arrow", "text"]);
    expect(list[0]).toMatchObject({ end: 4, stroke: 40 });
    expect(list[0]!.w).toBeCloseTo(0.1);
    expect(list[1]).toMatchObject({ x: 1, y: 0, text: "Héllo 日本 {x}", color: "#abcdef" });
    expect(list[1]!.fadeInMs! + list[1]!.fadeOutMs!).toBe(2000);
  });

  it("strips control characters like Rust's char::is_control and caps length", () => {
    expect(cleanText("a\r\nb\u0085c\td")).toBe("a\nbcd");
    expect(Array.from(cleanText("𠀀".repeat(600)))).toHaveLength(500);
  });

  it("fades linearly in and out", () => {
    const a = { ...box("a", 1, 3), fadeInMs: 1000, fadeOutMs: 500 };
    expect(annotationOpacity(a, 0.5)).toBe(0);
    expect(annotationOpacity(a, 1.5)).toBeCloseTo(0.5);
    expect(annotationOpacity(a, 2)).toBe(1);
    expect(annotationOpacity(a, 2.75)).toBeCloseTo(0.5);
    expect(annotationOpacity(a, 3)).toBe(0);
  });

  it("arrow polygon has a shaft of the stroke width and a head ending at the tip", () => {
    const p = arrowPolygon(0, 0, 100, 0, 10);
    expect(p).toHaveLength(7);
    expect(p[3]).toEqual([100, 0]);
    expect(p[0]![1]).toBeCloseTo(5);
    expect(p[2]![1]).toBeCloseTo(20);
    expect(p[1]![0]).toBeCloseTo(60);
    expect(arrowPolygon(1, 1, 1, 1, 5)).toEqual([]);
  });

  it("new annotations start at the playhead and fit the timeline", () => {
    expect(makeAnnotation("text", 19.9, 20)).toMatchObject({ start: 19.75, end: 20, text: "Text" });
    expect(makeAnnotation("box", 2, 0.1)).toBeNull();
  });
});

describe("annotations through cuts", () => {
  it("close up over a cut, vanish when their content is cut, and shift after it", () => {
    const before = {
      ...base(),
      annotations: [box("over", 4, 10), box("inside", 6, 7), box("after", 12, 14)],
    };
    // Cut source 5..8 (words w5..w7).
    const after = deleteWords(before, new Set(["w5", "w6", "w7"]));
    const list = after.annotations!;
    expect(list.map((a) => a.id)).toEqual(["over", "after"]);
    expect(list[0]).toMatchObject({ start: 4, end: 7 });
    expect(list[1]).toMatchObject({ start: 9, end: 11 });
  });

  it("an annotation whose content is all cut is removed and the field dropped", () => {
    const before = { ...base(), annotations: [box("x", 6, 7)] };
    const after = deleteWords(before, new Set(["w6"]));
    expect("annotations" in after).toBe(false);
  });

  it("content moved to two places gives two copies with distinct ids", () => {
    const p = base();
    const seg = p.segments[0]!;
    const twice: Project = {
      ...p,
      segments: [
        { ...seg, id: "a", sourceIn: 0, sourceOut: 5 },
        { ...seg, id: "b", sourceIn: 2, sourceOut: 4 },
      ],
    };
    const moved = retimeAnnotations(
      [box("x", 2, 4)],
      computeTimeline(p),
      computeTimeline(twice),
      7,
    );
    expect(moved.map((a) => [a.start, a.end])).toEqual([
      [2, 4],
      [5, 7],
    ]);
    expect(new Set(moved.map((a) => a.id)).size).toBe(2);
    // retimeAfterEdit wires it in for every timeline edit.
    expect(
      retimeAfterEdit(
        { ...p, annotations: [box("x", 2, 4)] },
        { ...twice, annotations: [box("x", 2, 4)] },
      ).annotations,
    ).toHaveLength(2);
  });
});

describe("annotations in the project store", () => {
  beforeEach(() => {
    useProjectStore.setState({ project: base(), dirty: false });
    useProjectStore.temporal.getState().clear();
  });
  const list = () => useProjectStore.getState().project.annotations ?? [];
  const undo = () => useProjectStore.temporal.getState().undo();
  const redo = () => useProjectStore.temporal.getState().redo();

  it("add, edit and delete are one undo step each", () => {
    const s = useProjectStore.getState();
    const id = s.addAnnotation("text", 2)!;
    expect(list()).toHaveLength(1);
    useProjectStore.getState().updateAnnotation(id, { text: "Hello" });
    useProjectStore.getState().updateAnnotation(id, { color: "#34c759", followZoom: true });
    useProjectStore.getState().removeAnnotation(id);
    expect(list()).toHaveLength(0);
    undo();
    expect(list()[0]).toMatchObject({ text: "Hello", color: "#34c759", followZoom: true });
    undo();
    expect(list()[0]).toMatchObject({ text: "Hello", color: "#ff3b30" });
    undo();
    expect(list()[0]!.text).toBe("Text");
    undo();
    expect(list()).toHaveLength(0);
    redo();
    expect(list()).toHaveLength(1);
    expect(useProjectStore.temporal.getState().pastStates).toHaveLength(1);
  });

  it("refuses an edit that would make the annotation invalid", () => {
    const id = useProjectStore.getState().addAnnotation("text", 2)!;
    const steps = useProjectStore.temporal.getState().pastStates.length;
    useProjectStore.getState().updateAnnotation(id, { text: "   " });
    expect(list()[0]!.text).toBe("Text");
    expect(useProjectStore.temporal.getState().pastStates).toHaveLength(steps);
  });

  it("keystrokes are off by default and toggling is undoable", () => {
    expect(useProjectStore.getState().project.keystrokes).toBeUndefined();
    useProjectStore.getState().setKeystrokes({ enabled: true });
    useProjectStore.getState().setKeystrokes({ mode: "all" });
    expect(useProjectStore.getState().project.keystrokes).toEqual({ enabled: true, mode: "all" });
    undo();
    expect(useProjectStore.getState().project.keystrokes).toEqual({
      enabled: true,
      mode: "shortcuts",
    });
  });

  it("survives save and reopen (JSON round trip)", () => {
    useProjectStore.getState().addAnnotation("arrow", 1);
    useProjectStore.getState().setKeystrokes({ enabled: true });
    const saved = JSON.parse(JSON.stringify(useProjectStore.getState().project)) as Project;
    replaceProjectBaseline(base());
    replaceProjectBaseline(saved);
    expect(sanitizeAnnotations(useProjectStore.getState().project.annotations, 20)).toEqual(
      saved.annotations,
    );
    expect(useProjectStore.getState().project.keystrokes).toEqual({
      enabled: true,
      mode: "shortcuts",
    });
    // Old projects have neither field and stay that way.
    expect(Object.keys(base())).not.toContain("annotations");
  });
});
