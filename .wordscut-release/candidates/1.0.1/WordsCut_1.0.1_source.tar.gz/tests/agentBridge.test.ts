import { beforeEach, describe, expect, it, vi } from "vitest";
import type { RelayRequest, RelayResponse, ToolOutcome } from "@/lib/agent/protocol";

const h = vi.hoisted(() => ({
  handler: null as null | ((req: RelayRequest) => void),
  unlisten: vi.fn(),
  order: [] as string[],
  responses: [] as RelayResponse[],
  readyArgs: [] as unknown[],
  callTool: vi.fn(),
}));

vi.mock("@/lib/agent/bridgeIpc", () => ({
  onAgentRequest: vi.fn(async (fn: (req: RelayRequest) => void) => {
    h.order.push("listen");
    h.handler = fn;
    return h.unlisten;
  }),
  agentReady: vi.fn(async (catalog: unknown) => {
    h.order.push("ready");
    h.readyArgs.push(catalog);
  }),
  agentRespond: vi.fn(async (r: RelayResponse) => {
    h.responses.push(r);
  }),
  agentPathInfo: vi.fn(),
  agentWriteTextFile: vi.fn(),
}));

vi.mock("@/lib/agent/registry", () => ({
  catalog: () => [{ name: "project_info" }],
  callTool: h.callTool,
}));

import { startAgentBridge } from "@/lib/agent/bridge";
import { AgentContextError, stopRevisionTracking } from "@/lib/agent/liveContext";

const flush = () => new Promise((r) => setTimeout(r, 0));
const req = (id: string): RelayRequest => ({ id, name: "project_info", input: {}, deadlineMs: 1 });

describe("agent bridge", () => {
  beforeEach(() => {
    h.handler = null;
    h.order.length = 0;
    h.responses.length = 0;
    h.readyArgs.length = 0;
    h.unlisten.mockClear();
    h.callTool.mockReset();
    stopRevisionTracking();
  });

  it("calls agent_ready with the catalog after listen", async () => {
    await startAgentBridge();
    expect(h.order).toEqual(["listen", "ready"]);
    expect(h.readyArgs[0]).toEqual([{ name: "project_info" }]);
  });

  it("answers one request with exactly one response carrying the same id", async () => {
    const outcome: ToolOutcome = { ok: true, tool: "project_info", data: { x: 1 } };
    h.callTool.mockResolvedValue(outcome);
    await startAgentBridge();
    h.handler!(req("abc"));
    await flush();
    expect(h.callTool).toHaveBeenCalledTimes(1);
    expect(h.callTool.mock.calls[0].slice(0, 2)).toEqual(["project_info", {}]);
    expect(h.responses).toEqual([{ id: "abc", outcome }]);
  });

  it("maps a throwing tool to INTERNAL", async () => {
    h.callTool.mockRejectedValue(new Error("boom"));
    await startAgentBridge();
    h.handler!(req("e1"));
    await flush();
    expect(h.responses).toHaveLength(1);
    const o = h.responses[0].outcome;
    expect(o.ok).toBe(false);
    if (!o.ok) {
      expect(o.error.code).toBe("INTERNAL");
      expect(o.error.message).toBe("boom");
    }
  });

  it("keeps the code of a live-context error", async () => {
    h.callTool.mockRejectedValue(new AgentContextError("BUSY", "An export is running"));
    await startAgentBridge();
    h.handler!(req("e2"));
    await flush();
    const o = h.responses[0].outcome;
    expect(!o.ok && o.error.code).toBe("BUSY");
  });

  it("unlisten cleans up", async () => {
    const dispose = await startAgentBridge();
    dispose();
    expect(h.unlisten).toHaveBeenCalledTimes(1);
  });
});
