import { describe, expect, it, vi } from "vitest";
import { controllerModel } from "@/lib/controllerModel";
import { idleSnapshot } from "@/lib/snapshotDefaults";
import { startSnapshotMirror } from "@/lib/snapshotMirror";
import type { RecordingSnapshot, SessionPhase } from "@/lib/ipc";

const at = (phase: SessionPhase, elapsedSec = 75): RecordingSnapshot => ({
  ...idleSnapshot(1),
  sessionId: "s",
  phase,
  mode: "screen",
  elapsedSec,
});

describe("controllerModel", () => {
  it("offers pause, mark, stop and the overflow actions while recording", () => {
    const m = controllerModel(at("recording"));
    expect(m).toMatchObject({
      status: "recording",
      time: "01:15",
      canPause: true,
      canMark: true,
      canStop: true,
      canRestart: true,
      canDiscard: true,
      canResume: false,
    });
  });

  it("offers resume instead of pause when paused, and no marking", () => {
    const m = controllerModel(at("paused"));
    expect(m).toMatchObject({ canResume: true, canPause: false, canMark: false, canStop: true });
  });

  it("an interrupted take can only be saved or discarded", () => {
    const m = controllerModel(at("interrupted"));
    expect(m.canStop).toBe(true);
    expect(m.canDiscard).toBe(true);
    expect([m.canPause, m.canResume, m.canMark, m.canRestart]).toEqual([
      false,
      false,
      false,
      false,
    ]);
  });

  it("starting can only be cancelled; finalizing offers nothing", () => {
    const starting = controllerModel(at("starting", 0));
    expect([starting.canStop, starting.canPause, starting.canDiscard]).toEqual([
      false,
      false,
      true,
    ]);
    const saving = controllerModel(at("finalizing"));
    expect(Object.values(saving).filter((v) => v === true)).toHaveLength(0);
    expect(saving.label).toBe("Saving…");
  });
});

describe("startSnapshotMirror", () => {
  it("subscribes before fetching and keeps the newest revision", async () => {
    const order: string[] = [];
    let push!: (s: RecordingSnapshot) => void;
    const applied: number[] = [];
    await startSnapshotMirror((s) => applied.push(s.revision), {
      subscribe: async (handler) => {
        order.push("subscribe");
        push = handler;
        return () => {};
      },
      fetch: async () => {
        order.push("fetch");
        push({ ...idleSnapshot(9), phase: "recording", sessionId: "s" }); // event beats the fetch
        return { ...idleSnapshot(4), phase: "starting", sessionId: "s" };
      },
    });
    expect(order).toEqual(["subscribe", "fetch"]);
    expect(applied).toEqual([9]);
  });

  it("survives a failed fetch and still applies later events", async () => {
    let push!: (s: RecordingSnapshot) => void;
    const apply = vi.fn();
    await startSnapshotMirror(apply, {
      subscribe: async (h) => ((push = h), () => {}),
      fetch: async () => {
        throw new Error("backend not ready");
      },
    });
    push(idleSnapshot(1));
    expect(apply).toHaveBeenCalledTimes(1);
  });
});
