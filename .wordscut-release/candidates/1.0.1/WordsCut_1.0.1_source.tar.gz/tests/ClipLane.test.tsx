import { act, cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, expect, it } from "vitest";
import { ClipLane } from "@/components/Waveform/ClipLane";
import { addMediaWithTranscript, newProject } from "@/lib/edl";
import { useProjectStore } from "@/stores/projectStore";
import { usePlayerStore } from "@/stores/playerStore";
const media = {
  id: "m",
  path: "/m.mp4",
  duration: 4,
  fps: 25,
  width: 100,
  height: 100,
  audioSampleRate: 8000,
  sha256: "x",
};
beforeEach(() => {
  useProjectStore.temporal.getState().resume();
  useProjectStore.setState({ project: addMediaWithTranscript(newProject("clip"), media, []) });
  useProjectStore.temporal.getState().clear();
});
afterEach(cleanup);
it("nudges by one source frame and reverses the edit in one undo step", () => {
  render(
    <ClipLane project={useProjectStore.getState().project} pxPerSecond={100} from={0} to={4} />,
  );
  fireEvent.keyDown(screen.getByRole("button", { name: "Trim clip 1 end" }), { key: "ArrowLeft" });
  expect(useProjectStore.getState().project.segments[0].sourceOut).toBeCloseTo(3.96);
  act(() => useProjectStore.temporal.getState().undo());
  expect(useProjectStore.getState().project.segments[0].sourceOut).toBe(4);
});
it("does not bubble clip button releases into timeline seeks", () => {
  let seeks = 0;
  render(
    <div onMouseUp={() => seeks++}>
      <ClipLane project={useProjectStore.getState().project} pxPerSecond={100} from={0} to={4} />
    </div>,
  );
  const button = screen.getByRole("button", { name: "Clip 1" });
  fireEvent.mouseDown(button);
  fireEvent.mouseUp(button);
  fireEvent.click(button);
  expect(seeks).toBe(0);
  expect(screen.getByRole("button", { name: "Split at playhead" })).toBeTruthy();
});
it("at 2x, edge drag and playhead snap go through the clip's speed", () => {
  const p = useProjectStore.getState().project;
  useProjectStore.setState({
    project: { ...p, segments: p.segments.map((s) => ({ ...s, speed: 2 })) },
  });
  usePlayerStore.setState({ currentTime: 1 }); // output 1 s = source 2 s at 2x
  const proto = HTMLElement.prototype as unknown as Record<string, unknown>;
  proto.setPointerCapture ??= () => {};
  render(
    <ClipLane project={useProjectStore.getState().project} pxPerSecond={100} from={0} to={4} />,
  );
  const handle = screen.getByRole("button", { name: "Trim clip 1 end" });
  const pointer = (type: string, clientX: number) =>
    fireEvent(
      handle,
      Object.assign(new MouseEvent(type, { bubbles: true, cancelable: true, clientX, button: 0 }), {
        pointerId: 1,
      }),
    );
  // 95 px left = 0.95 output s = 1.9 source s -> 2.1, which snaps to the playhead's 2.0.
  pointer("pointerdown", 200);
  pointer("pointermove", 105);
  pointer("pointerup", 105);
  expect(useProjectStore.getState().project.segments[0].sourceOut).toBeCloseTo(2, 6);
});
