import { describe, expect, it } from "vitest";
import { readFileSync, readdirSync } from "node:fs";
import path from "node:path";
import { defaultDevicePatch } from "@/lib/recorderOpts";
import { modeBlocker, screenPermissionChip, visibleWindows } from "@/recorderBar/barModel";
import type { RecordingDevices } from "@/lib/ipc";

const devices: RecordingDevices = {
  backend: "native",
  video: [{ index: 1, name: "Display", isScreen: true }],
  audio: [{ index: 5, name: "Mic" }],
  windows: [
    { id: 1, title: "Doc", app: "Pages" },
    { id: 2, title: "WordsCut Recording Controls — Setup", app: "WordsCut" },
    { id: 3, title: "WordsCut Recording Controls", app: "WordsCut" },
  ],
  displays: [{ index: 1, width: 800, height: 600 }],
  permissions: { screenRecording: "granted" },
};

describe("recorder bar model", () => {
  it("window picker hides the app's own recording windows", () => {
    expect(visibleWindows(devices).map((w) => w.id)).toEqual([1]);
  });

  it("window and area are disabled on the ffmpeg backend, display is not", () => {
    const ff = { ...devices, backend: "ffmpeg" as const };
    const opts = { mode: "screen" as const, screenIndex: 1 };
    expect(modeBlocker("window", opts, ff, null)).toMatch(/native recorder/);
    expect(modeBlocker("area", opts, ff, null)).toMatch(/native recorder/);
    expect(modeBlocker("display", opts, ff, null)).toBeNull();
  });

  it("modes are enabled when only a pick is missing", () => {
    const opts = { mode: "screen" as const, screenIndex: 1 };
    expect(modeBlocker("window", opts, devices, null)).toBeNull();
    expect(modeBlocker("area", opts, devices, null)).toBeNull();
  });

  it("modes are blocked when screen recording is denied", () => {
    const denied = { ...devices, permissions: { screenRecording: "denied" as const } };
    const opts = { mode: "screen" as const, screenIndex: 1 };
    expect(modeBlocker("display", opts, denied, null)).toMatch(/Screen Recording/);
  });

  it("permission chip states", () => {
    const with_ = (s: "granted" | "notDetermined" | "denied") => ({
      ...devices,
      permissions: { screenRecording: s },
    });
    expect(screenPermissionChip(with_("granted"), false)).toBe("none");
    expect(screenPermissionChip(with_("notDetermined"), false)).toBe("allow");
    expect(screenPermissionChip(with_("denied"), false)).toBe("settings");
    expect(screenPermissionChip(with_("denied"), true)).toBe("restart");
    expect(screenPermissionChip({ ...devices, backend: "ffmpeg" }, false)).toBe("none");
  });

  it("defaultDevicePatch fills unset devices and honours micOff", () => {
    expect(defaultDevicePatch({ mode: "screen" }, devices)).toEqual({
      screenIndex: 1,
      audioIndex: 5,
    });
    expect(defaultDevicePatch({ mode: "screen" }, devices, { micOff: true })).toEqual({
      screenIndex: 1,
    });
  });

  it("the bar does not import recordingStore", () => {
    const dir = path.resolve("src/recorderBar");
    for (const f of readdirSync(dir).filter((n) => /\.tsx?$/.test(n))) {
      expect(readFileSync(path.join(dir, f), "utf8"), f).not.toMatch(
        /from\s+["'][^"']*recordingStore["']/,
      );
    }
  });
});
