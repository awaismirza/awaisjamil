import { beforeEach, describe, expect, it } from "vitest";
import {
  addMediaWithTranscript,
  cutSilences,
  newProject,
  totalDuration,
  type Project,
  type SourceMedia,
  type Word,
} from "@/lib/edl";
import { useProjectStore } from "@/stores/projectStore";

function media(duration: number): SourceMedia {
  return {
    id: "media-1",
    path: "/tmp/media-1.mp4",
    duration,
    fps: 30,
    width: 1920,
    height: 1080,
    audioSampleRate: 48000,
    sha256: "deadbeef",
  };
}

function word(id: string, start: number, end: number): Word {
  return { id, text: id, start, end, confidence: 1 };
}

/** w0 0–1, silence 1–3, w1 3–4, silence 4–5, w2 5–6 (media 7 s). */
function project(words: Word[] = [word("w0", 0, 1), word("w1", 3, 4), word("w2", 5, 6)]): Project {
  return addMediaWithTranscript(newProject("t"), media(7), words);
}

const allWordIds = (p: Project) => p.segments.flatMap((s) => s.words.map((w) => w.id));

describe("cutSilences", () => {
  it("cuts silences longer than minDuration and keeps every word", () => {
    const p = project();
    const [next, cut] = cutSilences(
      p,
      "media-1",
      [
        { start: 1, end: 3 },
        { start: 4, end: 4.5 },
      ],
      { minDuration: 0.6 },
    );
    expect(cut).toBe(1);
    expect(totalDuration(next)).toBeCloseTo(5, 9);
    expect(allWordIds(next)).toEqual(["w0", "w1", "w2"]);
  });

  it("leaves keepSec of silence in place", () => {
    const [next] = cutSilences(project(), "media-1", [{ start: 1, end: 3 }], {
      minDuration: 0.6,
      keepSec: 0.4,
    });
    expect(totalDuration(next)).toBeCloseTo(7 - 1.6, 9);
  });

  it("cuts silence that DTW word spans have not absorbed, even without word gaps", () => {
    // Words are contiguous (no gap between w0 and w1), as with absorbed silences
    // the word-gap path saw nothing to remove. The 3–4 s silence is outside both.
    const p = project([word("w0", 0, 3), word("w1", 4, 5), word("w2", 5, 6)]);
    const [next, cut] = cutSilences(p, "media-1", [{ start: 3, end: 4 }], { minDuration: 0.6 });
    expect(cut).toBe(1);
    expect(totalDuration(next)).toBeCloseTo(6, 9);
  });

  it("is a no-op (same project) when the silence lies inside a word", () => {
    const p = project([word("w0", 0, 3), word("w1", 3, 7)]);
    const [next, cut] = cutSilences(p, "media-1", [{ start: 1, end: 2.5 }], { minDuration: 0.6 });
    expect(cut).toBe(0);
    expect(next).toBe(p);
  });
});

describe("pause token actions", () => {
  beforeEach(() => {
    useProjectStore.setState({
      project: project(),
      dirty: false,
      pauseTokens: [
        { id: "p1", start: 1, end: 3, duration: 2 },
        { id: "p2", start: 4, end: 5, duration: 1 },
      ],
    });
  });

  it("deletePauseById cuts the time from the EDL and removes the badge", () => {
    expect(useProjectStore.getState().deletePauseById("p1")).toBe(true);
    const { project: next, pauseTokens, dirty } = useProjectStore.getState();
    expect(dirty).toBe(true);
    expect(totalDuration(next)).toBeCloseTo(5, 9);
    expect(allWordIds(next)).toEqual(["w0", "w1", "w2"]);
    expect(pauseTokens.map((p) => p.id)).toEqual(["p2"]);
  });

  it("deletePauseById keeps the badge and the project when nothing can be cut", () => {
    const covered = project([word("w0", 0, 3.5), word("w1", 3.5, 7)]);
    useProjectStore.setState({ project: covered });
    expect(useProjectStore.getState().deletePauseById("p1")).toBe(false);
    const { project: next, pauseTokens, dirty } = useProjectStore.getState();
    expect(next).toBe(covered);
    expect(dirty).toBe(false);
    expect(pauseTokens.map((p) => p.id)).toEqual(["p1", "p2"]);
  });

  it("deletePausesLongerThan cuts only the long pauses and returns the real count", () => {
    expect(useProjectStore.getState().deletePausesLongerThan(1.5)).toBe(1);
    const { project: next, pauseTokens } = useProjectStore.getState();
    expect(totalDuration(next)).toBeCloseTo(5, 9);
    expect(pauseTokens.map((p) => p.id)).toEqual(["p2"]);
  });

  it("deletePausesLongerThan honours keepSec", () => {
    expect(useProjectStore.getState().deletePausesLongerThan(0, 0.5)).toBe(2);
    expect(totalDuration(useProjectStore.getState().project)).toBeCloseTo(7 - 1.5 - 0.5, 9);
  });

  it("deletePausesLongerThan leaves uncut badges in place", () => {
    // p2 (4–5) is swallowed by w1's span, p1 is free.
    useProjectStore.setState({
      project: project([word("w0", 0, 1), word("w1", 3, 5.5), word("w2", 5.5, 6)]),
    });
    expect(useProjectStore.getState().deletePausesLongerThan(0)).toBe(1);
    expect(useProjectStore.getState().pauseTokens.map((p) => p.id)).toEqual(["p2"]);
  });

  it("trimSilences cuts detected silences through the store", () => {
    const n = useProjectStore.getState().trimSilences(
      [
        { start: 1, end: 3 },
        { start: 4, end: 4.2 },
      ],
      { minDuration: 0.6 },
    );
    expect(n).toBe(1);
    expect(totalDuration(useProjectStore.getState().project)).toBeCloseTo(5, 9);
  });
});
