import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, expect, it } from "vitest";
import { TimelineViewMenu } from "@/components/Waveform/TimelineViewMenu";
import { useTimelineViewStore } from "@/stores/timelineViewStore";

beforeEach(() => useTimelineViewStore.getState().reset());
afterEach(cleanup);

it("opens, toggles a lane by accessible name, and Escape restores focus", () => {
  render(<TimelineViewMenu content={{ clips: true }} />);
  const button = screen.getByRole("button", { name: "View" });
  fireEvent.click(button);
  fireEvent.click(screen.getByRole("checkbox", { name: "Zoom regions" }));
  expect(useTimelineViewStore.getState().prefs.preset).toBe("custom");
  fireEvent.keyDown(screen.getByRole("dialog", { name: "Timeline view" }), { key: "Escape" });
  expect(screen.queryByRole("dialog")).toBeNull();
  expect(document.activeElement).toBe(button);
});

it("Reset view restores Simple", () => {
  useTimelineViewStore.getState().setPreset("detailed");
  render(<TimelineViewMenu content={{}} />);
  fireEvent.click(screen.getByRole("button", { name: "View" }));
  fireEvent.click(screen.getByRole("button", { name: "Reset view" }));
  expect(useTimelineViewStore.getState().prefs.preset).toBe("simple");
});

it("is a non-modal popover so editor hotkeys keep working", () => {
  render(<TimelineViewMenu content={{}} />);
  fireEvent.click(screen.getByRole("button", { name: "View" }));
  expect(screen.getByRole("dialog", { name: "Timeline view" }).getAttribute("aria-modal")).toBe(
    "false",
  );
});
