// Overlays panel sections (media overlays, privacy masks) and their preview layers.
import { act, cleanup, fireEvent, render, screen, within } from "@testing-library/react";
import { afterEach, beforeEach, expect, it, vi } from "vitest";
import { OverlaysPanel } from "@/components/editor/sidebar/panels/OverlaysPanel";
import { VideoPreview } from "@/components/VideoPreview/VideoPreview";
import { addMediaWithTranscript, newProject } from "@/lib/edl";
import { useProjectStore } from "@/stores/projectStore";
import { usePlayerStore } from "@/stores/playerStore";
import { useUIStore } from "@/stores/uiStore";
import { FcpxmlMaskDialog } from "@/components/Toolbar/FcpxmlMaskDialog";

vi.mock("@tauri-apps/api/core", () => ({ convertFileSrc: (path: string) => path }));
vi.mock("@/lib/ipc", async (orig) => ({
  ...(await orig<typeof import("@/lib/ipc")>()),
  findMissingMedia: vi.fn(async (paths: string[]) => paths.filter((p) => p.includes("gone"))),
  maskCoverageSheet: vi.fn(async () => new ArrayBuffer(8)),
}));

beforeEach(() => {
  vi.spyOn(HTMLMediaElement.prototype, "pause").mockImplementation(() => {});
  vi.spyOn(HTMLMediaElement.prototype, "load").mockImplementation(() => {});
  const p = addMediaWithTranscript(
    newProject("layers"),
    {
      id: "m",
      path: "/tmp/demo.mp4",
      duration: 20,
      width: 1920,
      height: 1080,
      fps: 30,
      audioSampleRate: 48000,
      sha256: "x",
    },
    [],
  );
  useProjectStore.setState({ project: p, dirty: false });
  usePlayerStore.getState().reset();
  useUIStore.setState({ previewMasks: true });
});
afterEach(() => {
  cleanup();
  vi.restoreAllMocks();
});

it("masks: static-region note, keyboard-usable editor, follow-zoom warning and coverage check", async () => {
  globalThis.URL.createObjectURL = vi.fn(() => "blob:sheet");
  globalThis.URL.revokeObjectURL = vi.fn();
  render(<OverlaysPanel />);
  const section = within(screen.getByRole("region", { name: "Privacy masks" }));
  expect(section.getByRole("note").textContent).toMatch(
    /Static region.*does not follow moving content.*do not redact the transcript, captions, SRT \/ VTT files, chapters/,
  );
  fireEvent.click(section.getByRole("button", { name: "Add mask" }));
  expect(useProjectStore.getState().project.masks).toHaveLength(1);
  expect(useProjectStore.getState().project.masks![0]!.effect).toBe("solid");
  const effect = section.getByRole("combobox", { name: "Effect" });
  fireEvent.change(effect, { target: { value: "pixelate" } });
  expect(useProjectStore.getState().project.masks![0]!).toMatchObject({
    effect: "pixelate",
    strength: 32,
  });
  expect(section.getByLabelText("Block size (px @1080)")).toBeInTheDocument();
  expect(section.getByRole("button", { name: /Delete pixelate mask at/ })).toBeInTheDocument();
  expect(section.queryByRole("alert")).toBeNull();
  // Below the safe-for-text level: a red warning (floors still apply: 16 is the minimum).
  const block = section.getByLabelText("Block size (px @1080)");
  fireEvent.change(block, { target: { value: "16" } });
  fireEvent.blur(block);
  expect(useProjectStore.getState().project.masks![0]!.strength).toBe(16);
  expect(section.getByRole("alert").textContent).toMatch(/Below the safe-for-text level \(24\)/);
  expect(section.queryByText(/overlaps a zoom that follows the cursor/)).toBeNull();
  act(() => {
    useProjectStore
      .getState()
      .addZoomRegion({ start: 0, end: 4, scale: 2, easeMs: 0, follow: true });
  });
  expect(section.getByText(/overlaps a zoom that follows the cursor/)).toBeInTheDocument();

  fireEvent.click(section.getByRole("button", { name: "Check coverage" }));
  expect(
    await section.findByRole("img", { name: /Coverage check: sampled 1 of 1 place this mask/ }),
  ).toHaveAttribute("src", "blob:sheet");

  const toggle = section.getByRole("checkbox", { name: /show masks in preview/i });
  fireEvent.click(toggle);
  expect(useUIStore.getState().previewMasks).toBe(false);
});

it("FCPXML with masks asks first, with Cancel as the default", () => {
  const cancel = vi.fn();
  const ok = vi.fn();
  render(<FcpxmlMaskDialog open onCancel={cancel} onConfirm={ok} />);
  expect(screen.getByRole("dialog")).toHaveTextContent(/PRIVACY MASKS ARE NOT APPLIED in FCPXML/);
  expect(screen.getByRole("dialog")).toHaveTextContent(/will show the masked content/);
  expect(screen.getByRole("button", { name: "Cancel" })).toHaveFocus();
  fireEvent.click(screen.getByRole("button", { name: "Cancel" }));
  expect(cancel).toHaveBeenCalled();
  expect(ok).not.toHaveBeenCalled();
});

it("preview: a mask on a 4:3 source is placed on that source; pixelate starts as a solid fill", () => {
  const { container } = render(<VideoPreview />);
  act(() => {
    const s = useProjectStore.getState();
    s.addMediaWithTranscript(
      {
        id: "m2",
        path: "/tmp/four3.mp4",
        duration: 20,
        width: 1440,
        height: 1080,
        fps: 30,
        audioSampleRate: 48000,
        sha256: "y",
      },
      [],
    );
    const m = s.addMask(25)!;
    s.updateMask(m, { effect: "pixelate" });
    usePlayerStore.getState().setCurrentTime(2);
  });
  expect(container.querySelector('[data-testid="privacy-masks"]')).toBeNull(); // the 16:9 clip plays
  act(() => usePlayerStore.getState().setCurrentTime(25));
  const box = container.querySelector('[data-testid="privacy-mask-box"] > div') as HTMLElement;
  expect(box.style.aspectRatio).toBe("1440 / 1080");
  const canvas = container.querySelector('[data-mask="pixelate"] canvas') as HTMLElement;
  expect(canvas.style.background).not.toBe("");
});

it("overlays: a missing file is flagged in the list and offers Relink", async () => {
  useProjectStore.setState((s) => ({
    project: {
      ...s.project,
      overlays: [
        {
          id: "a",
          kind: "image",
          path: "/gone/logo.png",
          srcW: 0,
          srcH: 0,
          start: 0,
          end: 2,
          x: 0.1,
          y: 0.1,
          w: 0.2,
          h: 0.2,
          opacity: 1,
        },
      ],
    },
  }));
  render(<OverlaysPanel />);
  const section = within(screen.getByRole("region", { name: "Images and videos" }));
  expect(await section.findByText(/Missing ·/)).toBeInTheDocument();
  fireEvent.click(within(section.getByRole("list")).getAllByRole("button")[0]!);
  expect(section.getByRole("alert").textContent).toMatch(/file is missing/);
  expect(section.getByRole("button", { name: "Relink…" })).toBeInTheDocument();
  expect(section.getByRole("button", { name: /Delete overlay logo.png at/ })).toBeInTheDocument();
});

it("preview: masks inside the zoom layer (below the cursor), overlays fixed or following zoom", () => {
  const { container } = render(<VideoPreview />);
  const video = container.querySelector("video")!;
  act(() => {
    const s = useProjectStore.getState();
    s.addZoomRegion({ start: 0, end: 5, scale: 2, easeMs: 0 });
    const m = s.addMask(1)!;
    s.updateMask(m, { effect: "solid", color: "#00ff00", shape: "ellipse" });
    s.addOverlay(
      { path: "/a/fixed.png", width: 100, height: 100, duration: 0, hasAudio: false },
      1,
      16 / 9,
    );
    const f = s.addOverlay(
      { path: "/a/follow.mp4", width: 100, height: 100, duration: 3, hasAudio: true },
      1,
      16 / 9,
    )!;
    s.updateOverlay(f, { followZoom: true });
    usePlayerStore.getState().setCurrentTime(2);
  });
  expect(container.querySelector("video")).toBe(video);
  const zoomLayer = video.parentElement!;
  const masks = zoomLayer.querySelector('[data-testid="privacy-masks"]')!;
  expect(masks.querySelector('[data-mask="solid"]')).toHaveStyle({ background: "#00ff00" });
  // Masks come right after the picture, before every other layer in the zoom wrapper.
  expect(video.nextElementSibling).toBe(masks);
  const layers = [...container.querySelectorAll('[data-testid="media-overlays"]')];
  expect(layers).toHaveLength(2);
  const inside = layers.find((l) => zoomLayer.contains(l))!;
  expect(inside.querySelector('[data-overlay="video"] video')).toBeInTheDocument();
  const fixed = layers.find((l) => l !== inside)!;
  expect(zoomLayer.contains(fixed)).toBe(false);
  // A file that fails to load shows a clear placeholder.
  fireEvent.error(fixed.querySelector("img")!);
  expect(
    within(fixed as HTMLElement).getByRole("img", {
      name: /Missing overlay file fixed.png/,
      hidden: true,
    }),
  ).toBeInTheDocument();

  act(() => useUIStore.getState().setPreviewMasks(false));
  expect(container.querySelector('[data-testid="privacy-masks"]')).toBeNull();
  act(() => {
    useUIStore.getState().setPreviewMasks(true);
    usePlayerStore.getState().setCurrentTime(15);
  });
  expect(container.querySelector('[data-testid="privacy-masks"]')).toBeNull();
  expect(container.querySelector('[data-testid="media-overlays"]')).toBeNull();
  expect(container.querySelector("video")).toBe(video);
});

it("masks panel: duplicate-file note, tiny-mask warning and refused sizes; overlay of masked footage", () => {
  useProjectStore.setState((s) => {
    const m = s.project.media.m!;
    return {
      project: {
        ...s.project,
        media: { ...s.project.media, m2: { ...m, id: "m2" } },
        masks: [
          {
            id: "k",
            mediaId: "m",
            srcStart: 1,
            srcEnd: 2,
            x: 0.1,
            y: 0.1,
            w: 0.02,
            h: 0.5,
            shape: "rect",
            effect: "solid",
            strength: 0,
            color: "#000000",
          },
        ],
        overlays: [
          {
            id: "o",
            kind: "video",
            path: m.path,
            srcW: 0,
            srcH: 0,
            start: 0,
            end: 2,
            x: 0.1,
            y: 0.1,
            w: 0.2,
            h: 0.2,
            opacity: 1,
          },
        ],
      },
    };
  });
  render(<OverlaysPanel />);
  const masks = within(screen.getByRole("region", { name: "Privacy masks" }));
  fireEvent.click(within(masks.getByRole("list")).getAllByRole("button")[0]!);
  expect(masks.getByText(/also imported as 1 other source/)).toBeInTheDocument();
  expect(masks.getByRole("alert").textContent).toMatch(/under 3 %/);
  const width = masks.getByLabelText("Width (%)");
  fireEvent.change(width, { target: { value: "0" } });
  fireEvent.blur(width);
  expect(masks.getByText(/at least 1 % wide and high/)).toBeInTheDocument();
  expect(useProjectStore.getState().project.masks![0]!.w).toBe(0.02);
  const overlays = within(screen.getByRole("region", { name: "Images and videos" }));
  fireEvent.click(within(overlays.getByRole("list")).getAllByRole("button")[0]!);
  expect(overlays.getByText(/applied to this overlay in the export/)).toBeInTheDocument();
});
