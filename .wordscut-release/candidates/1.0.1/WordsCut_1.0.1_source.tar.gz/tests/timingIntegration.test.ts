// Speed / hold / transitions combined with clip ops, lineage, annotations,
// keystrokes and styled captions (integration of speed-freeze-transitions).
import { describe, expect, it } from "vitest";
import {
  computeTimeline,
  deleteWords,
  keepOutputRange,
  newProject,
  restoreWords,
  trimSourceRanges,
  type Project,
  type Segment,
  type Word,
} from "@/lib/edl";
import { duplicateClip, splitClipAt } from "@/lib/clipEdit";
import { retimeAnnotations } from "@/lib/annotations";
import { keystrokeCaptions } from "@/lib/keystrokes";
import { parseCursorLog } from "@/lib/cursor";
import { sanitizeProjectCursor } from "@/lib/cursorStyle";
import { layoutProjectCaptions } from "@/lib/captionLayout";
import { DEFAULT_CAPTION_STYLE } from "@/lib/captionStyle";

const w = (id: string, start: number, end = start + 1): Word => ({
  id,
  text: id,
  start,
  end,
  confidence: 1,
});
const words = (n: number) => Array.from({ length: n }, (_, i) => w(`w${i}`, i));

function project(segments: Segment[], extra: Partial<Project> = {}): Project {
  const p = newProject("t");
  return {
    ...p,
    settings: { ...p.settings, paddingMs: 0 },
    media: {
      m: {
        id: "m",
        path: "/tmp/m.mp4",
        duration: 100,
        fps: 30,
        width: 1280,
        height: 720,
        audioSampleRate: 48000,
        sha256: "x",
      },
    },
    segments,
    ...extra,
  };
}

/** One 2x clip of six 1 s words with a 1 s hold, then its duplicate. */
function dupProject(): Project {
  const p = project([
    { id: "a", mediaId: "m", words: words(6), sourceIn: 0, sourceOut: 6, speed: 2, holdSec: 1 },
  ]);
  return duplicateClip(p, "a");
}

describe("lineage + timing through edits (A, B)", () => {
  it("a duplicated sped-up clip's copy keeps lineage and timing through a word delete and a split", () => {
    let p = dupProject();
    const copy = p.segments[1]!;
    expect(computeTimeline(p).map((e) => [e.outputStart, e.outputEnd])).toEqual([
      [0, 4],
      [4, 8],
    ]);
    // Chapters on the copy: one in footage (source 3), one in its hold.
    p = {
      ...p,
      chapters: [
        { id: "c1", outputTime: 5.5, title: "foot" },
        { id: "c2", outputTime: 7.5, title: "hold" },
      ],
    };
    // Delete the second word in BOTH copies at once, so source-time fallback
    // alone could not tell the pieces apart: only lineage keeps the chapters.
    const second = copy.words[1]!.id;
    p = deleteWords(p, new Set(["w1", second]));
    expect(p.segments.map((s) => [s.sourceIn, s.sourceOut, s.speed, s.holdSec])).toEqual([
      [0, 1, 2, undefined],
      [2, 6, 2, 1],
      [0, 1, 2, undefined],
      [2, 6, 2, 1],
    ]);
    // Copy now starts at 3.5: piece [0,1) = 0.5 s, piece [2,6) = 2 s + 1 s hold.
    const chapters = Object.fromEntries(p.chapters!.map((c) => [c.id, c.outputTime]));
    expect(chapters.c1).toBeCloseTo(3.5 + 0.5 + 0.5, 9); // source 3 at 2x after source 2
    expect(chapters.c2).toBeCloseTo(3.5 + 0.5 + 2 + 0.5, 9); // same offset into the copy's hold

    // Split the copy's last piece at source 4: both halves stay 2x, the hold goes right.
    p = splitClipAt(p, 3.5 + 0.5 + 1);
    expect(p.segments.slice(3).map((s) => [s.sourceIn, s.sourceOut, s.speed, s.holdSec])).toEqual([
      [2, 4, 2, undefined],
      [4, 6, 2, 1],
    ]);
    // Lineage still drives later edits: delete in the copy's right half only.
    const before = p.chapters!.find((c) => c.id === "c2")!.outputTime;
    const right = p.segments[4]!;
    p = deleteWords(p, new Set([right.words[0]!.id]));
    expect(p.chapters!.find((c) => c.id === "c2")!.outputTime).toBeCloseTo(before - 0.5, 9);
  });

  it("keepOutputRange and trimSourceRanges keep timing and route by lineage", () => {
    let p = dupProject();
    p = { ...p, chapters: [{ id: "c", outputTime: 7.5, title: "hold" }] };
    const [trimmed] = trimSourceRanges(p, "m", [{ start: 0.2, end: 0.8 }]);
    // Trims avoid words, so nothing is cut here; use a range keep instead.
    expect(trimmed).toBe(p);
    const kept = keepOutputRange(p, 4.5, 8);
    expect(kept.segments.map((s) => [s.sourceIn, s.sourceOut, s.speed, s.holdSec])).toEqual([
      [1, 6, 2, 1],
    ]);
    expect(kept.chapters![0]!.outputTime).toBeCloseTo(3, 9);
  });

  it("a hold-time annotation on a duplicated clip lands on the copy's hold", () => {
    const p = dupProject();
    const oldTl = computeTimeline(p).map((e) => ({ ...e, mediaId: e.segmentId }));
    // New timeline: original shortened (lost 2 s source = 1 s), copy unchanged.
    const ids = p.segments.map((s) => s.id);
    const newTl = [
      { ...oldTl[0]!, sourceIn: 2, outputEnd: 3, mediaId: ids[0]! },
      { ...oldTl[1]!, outputStart: 3, outputEnd: 7, mediaId: ids[1]! },
    ];
    const moved = retimeAnnotations(
      [{ id: "n", kind: "text", start: 7.2, end: 7.8, text: "x" } as never],
      oldTl,
      newTl,
      7,
    );
    expect(moved[0]!.start).toBeCloseTo(6.2, 6);
    expect(moved[0]!.end).toBeCloseTo(6.8, 6);
  });
});

describe("restore joins only like clips (C)", () => {
  it("a restored 1x piece next to a 2x clip stays its own clip; like clips still join", () => {
    const all = words(6);
    const base = project(
      [{ id: "s", mediaId: "m", words: all.slice(0, 3), sourceIn: 0, sourceOut: 3, speed: 2 }],
      { originalTranscripts: { m: all } },
    );
    const r = restoreWords(base, new Set(["w3"]));
    expect(r.segments.map((s) => [s.sourceIn, s.sourceOut, s.speed])).toEqual([
      [0, 3, 2],
      [3, 4, undefined],
    ]);
    const plain = project(
      [{ id: "s", mediaId: "m", words: all.slice(0, 3), sourceIn: 0, sourceOut: 3 }],
      { originalTranscripts: { m: all } },
    );
    expect(
      restoreWords(plain, new Set(["w3"])).segments.map((s) => [s.sourceIn, s.sourceOut]),
    ).toEqual([[0, 4]]);
  });

  it("never merges across a hold or into a transition", () => {
    const all = words(6);
    const held = project(
      [{ id: "s", mediaId: "m", words: all.slice(0, 3), sourceIn: 0, sourceOut: 3, holdSec: 1 }],
      { originalTranscripts: { m: all } },
    );
    expect(restoreWords(held, new Set(["w3"])).segments).toHaveLength(2);
  });
});

describe("annotations and keystrokes under speed / hold (F)", () => {
  it("retimeAnnotations goes through source time at speed", () => {
    const p = project([
      { id: "s", mediaId: "m", words: words(10), sourceIn: 0, sourceOut: 10, speed: 2 },
    ]);
    const after = deleteWords(
      { ...p, annotations: [{ id: "n", kind: "text", start: 3, end: 4, text: "x" } as never] },
      new Set(["w0"]),
    );
    // Annotation was over source 6..8; source 1..10 at 2x puts that at 2.5..3.5.
    expect(after.annotations![0]!.start).toBeCloseTo(2.5, 6);
    expect(after.annotations![0]!.end).toBeCloseTo(3.5, 6);
  });

  it("keystroke captions map press times through speed and holds", () => {
    const cursor = sanitizeProjectCursor(undefined);
    const log = ['{"type":"key","t":2,"mods":["cmd"]}', '{"type":"key","t":5,"mods":["alt"]}'];
    const p = project(
      [
        { id: "a", mediaId: "m", words: [], sourceIn: 0, sourceOut: 4, speed: 2, holdSec: 1 },
        { id: "b", mediaId: "m", words: [], sourceIn: 4, sourceOut: 8 },
      ],
      { cursor: { ...cursor, tracks: { m: parseCursorLog(log.join("\n")) } } },
    );
    const c = keystrokeCaptions(p, { enabled: true, mode: "shortcuts" });
    // Source 2 at 2x = output 1; clip a is 2 + 1 s long, so source 5 = 3 + 1 = 4.
    expect(c.map((x) => x.start)).toEqual([1, 4]);
  });
});

describe("styled captions under speed / hold (G)", () => {
  const style = DEFAULT_CAPTION_STYLE;
  it("a 2x clip halves cue times (same cues as the same words spoken twice as fast)", () => {
    const two = project([
      { id: "s", mediaId: "m", words: words(12), sourceIn: 0, sourceOut: 12, speed: 2 },
    ]);
    const fast = Array.from({ length: 12 }, (_, i) => w(`w${i}`, i / 2, i / 2 + 0.5));
    const half = project([{ id: "s", mediaId: "m", words: fast, sourceIn: 0, sourceOut: 6 }]);
    const b = layoutProjectCaptions(two, style).cues;
    const a = layoutProjectCaptions(half, style).cues;
    expect(b.length).toBe(a.length);
    expect(b.length).toBeGreaterThan(0);
    b.forEach((cue, i) => {
      expect(cue.start).toBeCloseTo(a[i]!.start, 6);
      expect(cue.end).toBeCloseTo(a[i]!.end, 6);
      expect(cue.text).toBe(a[i]!.text);
    });
    expect(b[b.length - 1]!.end).toBeLessThanOrEqual(6 + 1e-6);
  });

  it("a hold inserts a gap with no extra cues", () => {
    const ws = words(12);
    const segs = (hold?: number): Segment[] => [
      { id: "a", mediaId: "m", words: ws.slice(0, 6), sourceIn: 0, sourceOut: 6, holdSec: hold },
      { id: "b", mediaId: "m", words: ws.slice(6), sourceIn: 6, sourceOut: 12 },
    ];
    const a = layoutProjectCaptions(project(segs()), style).cues;
    const b = layoutProjectCaptions(project(segs(3)), style).cues;
    expect(b.length).toBe(a.length);
    for (const [i, cue] of b.entries()) {
      const shift = a[i]!.start >= 6 ? 3 : 0;
      expect(cue.start).toBeCloseTo(a[i]!.start + shift, 6);
      // Nothing is on screen during the frozen frame (6..9).
      expect(cue.end <= 6 + 1e-6 || cue.start >= 9 - 1e-6).toBe(true);
    }
  });
});
