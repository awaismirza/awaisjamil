/** Background backfills on open (checksum, probed size) never mark the project unsaved. */

import { beforeEach, describe, expect, it, vi } from "vitest";
import { addMediaWithTranscript, newProject, type Project, type SourceMedia } from "@/lib/edl";

const ipc = vi.hoisted(() => ({ hashMedia: vi.fn(), probeMediaSize: vi.fn() }));
vi.mock("@/lib/ipc", async (orig) => ({ ...(await orig<object>()), ...ipc }));

import { backfillChecksums, refreshMediaSizes } from "@/lib/relink";
import { replaceProjectBaseline, useProjectStore } from "@/stores/projectStore";

const SHA = "a".repeat(64);
const media: SourceMedia = {
  id: "m",
  path: "/tmp/m.mp4",
  duration: 2,
  fps: 30,
  width: 1920,
  height: 1080,
  audioSampleRate: 48000,
  sha256: "",
};
const word = { id: "w0", text: "hi", start: 0, end: 1, confidence: 1 };

function open(): Project {
  replaceProjectBaseline(addMediaWithTranscript(newProject("t"), media, [word]), {
    dirty: false,
    filePath: "/tmp/p.scribe",
  });
  return useProjectStore.getState().project;
}

describe("backfills on open", () => {
  beforeEach(() => vi.clearAllMocks());

  it("a backfilled checksum stays clean and adds no undo step", async () => {
    const p = open();
    ipc.hashMedia.mockResolvedValue(SHA);
    expect(await backfillChecksums(p)).toBe(1);
    const s = useProjectStore.getState();
    expect(s.project.media.m!.sha256).toBe(SHA);
    expect(s.dirty).toBe(false);
    expect(useProjectStore.temporal.getState().pastStates).toHaveLength(0);
  });

  it("a refreshed size stays clean and adds no undo step", async () => {
    const p = open();
    ipc.probeMediaSize.mockResolvedValue([1080, 1920]);
    expect(await refreshMediaSizes(p)).toBe(1);
    const s = useProjectStore.getState();
    expect(s.project.media.m).toMatchObject({ width: 1080, height: 1920 });
    expect(s.dirty).toBe(false);
    expect(useProjectStore.temporal.getState().pastStates).toHaveLength(0);
  });

  it("a size probed for a path that was relinked meanwhile is dropped", async () => {
    const p = open();
    ipc.probeMediaSize.mockImplementation(async () => {
      useProjectStore
        .getState()
        .relinkMediaPath(p.id, "m", "/tmp/new.mp4", { width: 640, height: 360 });
      return [1080, 1920];
    });
    expect(await refreshMediaSizes(p)).toBe(0);
    expect(useProjectStore.getState().project.media.m).toMatchObject({
      path: "/tmp/new.mp4",
      width: 640,
      height: 360,
    });
  });

  it("a user relink still marks the project unsaved", () => {
    const p = open();
    useProjectStore.getState().relinkMediaPath(p.id, "m", "/tmp/new.mp4");
    expect(useProjectStore.getState().dirty).toBe(true);
  });
});
