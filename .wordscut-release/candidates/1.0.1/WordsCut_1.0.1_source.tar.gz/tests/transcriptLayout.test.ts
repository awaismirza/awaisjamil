import { describe, expect, it } from "vitest";
import type { Segment, Word } from "@/lib/edl";
import { getTimelineIndex } from "@/lib/timelineIndex";
import { layoutTranscript, zoomWordMap } from "@/lib/transcriptLayout";

const w = (id: string, start: number, end = start + 0.3): Word => ({
  id,
  text: id,
  start,
  end,
  confidence: 1,
});
const seg = (id: string, mediaId: string, words: Word[], out = 10): Segment => ({
  id,
  mediaId,
  words,
  sourceIn: 0,
  sourceOut: out,
});

describe("layoutTranscript", () => {
  it("keeps an appended clip after earlier clips even with overlapping source times", () => {
    const paragraphs = layoutTranscript(
      [seg("s1", "a", [w("a1", 1), w("a2", 5)]), seg("s2", "b", [w("b1", 0.5), w("b2", 2)])],
      [],
      "a",
    );
    expect(paragraphs.flatMap((p) => p.words.map((x) => x.id))).toEqual(["a1", "a2", "b1", "b2"]);
  });

  it("starts a new paragraph at a clip boundary", () => {
    const paragraphs = layoutTranscript(
      [seg("s1", "a", [w("a1", 1)]), seg("s2", "b", [w("b1", 1.4)])],
      [],
      "a",
    );
    expect(paragraphs).toHaveLength(2);
  });

  it("anchors pauses only inside segments of the pause media", () => {
    const pause = { id: "p", start: 2, end: 3, duration: 1 };
    const paragraphs = layoutTranscript(
      [seg("s1", "a", [w("a1", 1), w("a2", 3.1)]), seg("s2", "b", [w("b1", 2.5)])],
      [pause],
      "a",
    );
    const kinds = paragraphs.flatMap((p) => p.tokens.map((t) => t.kind));
    expect(kinds).toEqual(["word", "pause", "word", "word"]);
  });
});

describe("zoomWordMap", () => {
  it("marks words by output time, so an appended clip is matched at its output position", () => {
    const segments = [seg("s1", "a", [w("a1", 1)], 4), seg("s2", "b", [w("b1", 1)], 4)];
    const entries = getTimelineIndex(segments).entries;
    const map = zoomWordMap(entries, [{ id: "z", start: 5, end: 6 }]);
    expect([...map.keys()]).toEqual(["b1"]);
    expect(map.get("b1")).toBe("z");
  });
});
