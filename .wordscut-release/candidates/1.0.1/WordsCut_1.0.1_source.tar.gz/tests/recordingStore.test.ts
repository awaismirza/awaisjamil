import { beforeEach, describe, expect, it, vi } from "vitest";
import { defaultSettings } from "@/lib/settings";
import {
  handleSnapshot,
  idleSnapshot,
  runRecorderAction,
  useRecordingStore,
} from "@/stores/recordingStore";
import { useUIStore } from "@/stores/uiStore";
import { useSettingsStore } from "@/stores/settingsStore";
import * as ipc from "@/lib/ipc";

describe("recordingStore", () => {
  beforeEach(() => {
    window.localStorage.clear();
    useRecordingStore.setState({
      phase: "idle",
      session: idleSnapshot(),
      sessionId: null,
      revision: 0,
      error: null,
      local: null,
      dialogOpen: false,
      countdown: 0,
      elapsedSec: 0,
      markers: [],
      devices: null,
      devicesError: null,
    });
    useSettingsStore.setState(defaultSettings());
  });

  describe("options", () => {
    it("defaults to screen mode with a bottom-right medium camera bubble", () => {
      const { opts } = useRecordingStore.getState();
      expect(opts.mode).toBe("screen");
      expect(opts.pipCorner).toBe("bottom-right");
      expect(opts.pipSize).toBe("medium");
      expect(opts.fps).toBe(30);
    });

    it("setOpts merges a patch and persists it for the next session", () => {
      useRecordingStore.getState().setOpts({ mode: "screen-camera", pipCorner: "top-left" });
      const { opts } = useRecordingStore.getState();
      expect(opts.mode).toBe("screen-camera");
      expect(opts.pipCorner).toBe("top-left");
      // Untouched fields survive the merge.
      expect(opts.pipSize).toBe("medium");

      const stored = JSON.parse(
        window.localStorage.getItem("yusafcut.recorderOptions") ?? "{}",
      ) as Record<string, unknown>;
      expect(stored.mode).toBe("screen-camera");
      expect(stored.pipCorner).toBe("top-left");
    });
  });

  describe("device selection", () => {
    const native: ipc.RecordingDevices = {
      backend: "native",
      video: [
        { index: 1000, name: "Built-in Retina Display", isScreen: true },
        { index: 1001, name: "FaceTime HD Camera", isScreen: false },
      ],
      audio: [{ index: 1000, name: "MacBook Pro Microphone" }],
    };

    it("replaces indices from another backend with the first device of each kind", async () => {
      // 2 / 0 / 1 were avfoundation indices, 1000+ are the native helper's.
      useRecordingStore.getState().setOpts({ screenIndex: 2, cameraIndex: 0, audioIndex: 1 });
      vi.spyOn(ipc, "listRecordingDevices").mockResolvedValue(native);
      await useRecordingStore.getState().refreshDevices();
      const { opts } = useRecordingStore.getState();
      expect([opts.screenIndex, opts.cameraIndex, opts.audioIndex]).toEqual([1000, 1001, 1000]);
    });

    it("keeps a still-valid selection", async () => {
      useRecordingStore
        .getState()
        .setOpts({ screenIndex: 1000, cameraIndex: 1001, audioIndex: 1000 });
      vi.spyOn(ipc, "listRecordingDevices").mockResolvedValue({
        ...native,
        video: [...native.video, { index: 1002, name: "LG", isScreen: true }],
      });
      await useRecordingStore.getState().refreshDevices();
      expect(useRecordingStore.getState().opts.screenIndex).toBe(1000);
    });
  });

  describe("phase guards", () => {
    it("openDialog is ignored while a session is live", () => {
      useRecordingStore.setState({ phase: "recording" });
      useRecordingStore.getState().openDialog();
      expect(useRecordingStore.getState().dialogOpen).toBe(false);
    });

    it("pause / resume / stop are no-ops outside their valid phases", async () => {
      await useRecordingStore.getState().pause();
      expect(useRecordingStore.getState().phase).toBe("idle");

      await useRecordingStore.getState().resume();
      expect(useRecordingStore.getState().phase).toBe("idle");

      await useRecordingStore.getState().stop();
      expect(useRecordingStore.getState().phase).toBe("idle");
    });

    it("beginCountdown enters countdown at 3 and cancel aborts before capture starts", async () => {
      useRecordingStore.getState().beginCountdown();
      const s = useRecordingStore.getState();
      expect(s.phase).toBe("countdown");
      expect(s.countdown).toBe(3);
      expect(s.dialogOpen).toBe(false);

      await useRecordingStore.getState().cancel();
      expect(useRecordingStore.getState().phase).toBe("idle");
      expect(useRecordingStore.getState().countdown).toBe(0);
    });

    it("beginCountdown is ignored when a session is already live", () => {
      useRecordingStore.setState({ phase: "paused" });
      useRecordingStore.getState().beginCountdown();
      expect(useRecordingStore.getState().phase).toBe("paused");
    });
  });

  describe("countdown length", () => {
    it("uses the countdown from Settings", () => {
      useSettingsStore.getState().setRecording({ countdownSec: 5 });
      useRecordingStore.getState().beginCountdown();
      expect(useRecordingStore.getState().countdown).toBe(5);
    });
  });

  describe("mark a moment", () => {
    it("asks Rust to mark the take's own media time, naming the session", async () => {
      const mark = vi.spyOn(ipc, "markRecording").mockResolvedValue(12);
      useRecordingStore.setState({ phase: "recording", sessionId: "s1" });
      await useRecordingStore.getState().mark();
      expect(mark).toHaveBeenCalledWith("s1");
    });

    it("ignores presses when idle, paused or finishing", async () => {
      const mark = vi.spyOn(ipc, "markRecording").mockResolvedValue(1);
      for (const phase of ["idle", "paused", "finalizing"] as const) {
        useRecordingStore.setState({ phase, sessionId: "s1" });
        await useRecordingStore.getState().mark();
      }
      expect(mark).not.toHaveBeenCalled();
    });

    it("mirrors the markers Rust recorded", () => {
      handleSnapshot({ ...live("s1", 1), markers: [3, 4.5] });
      expect(useRecordingStore.getState().markers).toEqual([3, 4.5]);
    });
  });

  describe("runRecorderAction", () => {
    it("opens the setup dialog on record when quick start is off", () => {
      useSettingsStore.getState().setRecording({ quickStart: false });
      runRecorderAction("record");
      expect(useRecordingStore.getState().dialogOpen).toBe(true);
    });

    it("quick-starts on record when quick start is on", () => {
      const quickStart = vi.fn(async () => {});
      useRecordingStore.setState({ quickStart });
      runRecorderAction("record");
      expect(quickStart).toHaveBeenCalledTimes(1);
      expect(useRecordingStore.getState().dialogOpen).toBe(false);
    });

    it("starts the countdown from an open dialog regardless of quick start", () => {
      useRecordingStore.setState({ dialogOpen: true });
      runRecorderAction("record");
      expect(useRecordingStore.getState().phase).toBe("countdown");
    });

    it("cancels a running countdown", () => {
      useRecordingStore.getState().beginCountdown();
      runRecorderAction("record");
      expect(useRecordingStore.getState().phase).toBe("idle");
    });

    it("marks a moment from the mark action", () => {
      const mark = vi.fn(async () => {});
      useRecordingStore.setState({ mark });
      runRecorderAction("mark");
      expect(mark).toHaveBeenCalledTimes(1);
    });
  });

  describe("capture errors", () => {
    it("stops the take once to keep what was written when the capture source dies", () => {
      const stop = vi.fn(async () => {});
      useRecordingStore.setState({ stop });
      handleSnapshot({ ...live("s1", 1), phase: "interrupted", error: "display lost" });
      handleSnapshot({ ...live("s1", 2), phase: "interrupted", error: "display lost" });
      expect(stop).toHaveBeenCalledTimes(1);
    });

    it("only reports (does not stop) a problem on a healthy take", () => {
      const stop = vi.fn(async () => {});
      useRecordingStore.setState({ stop });
      useUIStore.setState({ toasts: [] });
      handleSnapshot({ ...live("s1", 1), error: "Check Screen Recording permission." });
      expect(stop).not.toHaveBeenCalled();
      const toasts = useUIStore.getState().toasts;
      expect(toasts[toasts.length - 1]?.description).toBe("Check Screen Recording permission.");
      expect(toasts[toasts.length - 1]?.variant).toBe("destructive");
    });
  });
});

function live(sessionId: string, revision: number): ipc.RecordingSnapshot {
  return { ...idleSnapshot(revision), sessionId, phase: "recording", mode: "screen" };
}

describe("recordingStore source options (compact setup)", () => {
  it("reports a device that vanished between refreshes", async () => {
    const before: ipc.RecordingDevices = {
      backend: "native",
      video: [
        { index: 1000, name: "Display", isScreen: true },
        { index: 1001, name: "USB Cam", isScreen: false },
      ],
      audio: [],
    };
    useRecordingStore.setState({
      devices: before,
      opts: { mode: "screen-camera", screenIndex: 1000, cameraIndex: 1001 },
    });
    vi.spyOn(ipc, "listRecordingDevices").mockResolvedValue({
      ...before,
      video: [before.video[0]],
    });
    await useRecordingStore.getState().refreshDevices();
    expect(useRecordingStore.getState().deviceNotices).toEqual([
      "Camera “USB Cam” was disconnected.",
    ]);
  });

  it("requestPermissions asks the helper then re-reads devices", async () => {
    const ask = vi.spyOn(ipc, "requestRecordingPermissions").mockResolvedValue({});
    const list = vi
      .spyOn(ipc, "listRecordingDevices")
      .mockResolvedValue({ backend: "native", video: [], audio: [] });
    await useRecordingStore.getState().requestPermissions(["camera"]);
    expect(ask).toHaveBeenCalledWith(["camera"]);
    expect(list).toHaveBeenCalled();
  });
});
