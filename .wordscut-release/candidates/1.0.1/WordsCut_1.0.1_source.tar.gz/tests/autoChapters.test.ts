import { describe, expect, it } from "vitest";
import { addMediaWithTranscript, newProject, type Project, type SourceMedia, type Word } from "@/lib/edl";
import { defaultChapterCount, suggestChapters } from "@/lib/autoChapters";

function media(duration: number): SourceMedia {
  return {
    id: "m",
    path: "/tmp/m.mp4",
    duration,
    fps: 30,
    width: 1920,
    height: 1080,
    audioSampleRate: 48000,
    sha256: "x",
  };
}

/** Sentences of 5 words, 5 s each, optional pause before. Returns words. */
function transcript(sentences: string[], gapAfter = 0): Word[] {
  const words: Word[] = [];
  let t = 0;
  let n = 0;
  for (const s of sentences) {
    const parts = s.split(" ");
    parts.forEach((text, i) => {
      const start = t + i * 0.9;
      words.push({ id: `w${n++}`, text, start, end: start + 0.8, confidence: 1 });
    });
    t += parts.length * 0.9 + gapAfter;
  }
  return words;
}

function projectOf(words: Word[]): Project {
  const dur = words[words.length - 1]!.end + 1;
  return addMediaWithTranscript(newProject("t"), media(dur), words);
}

// Real speech repeats its topic words, so each topic reuses its own vocabulary.
const COOKING = [
  "Chop the onions for the pasta sauce.",
  "Heat olive oil for the pasta sauce.",
  "Fry the onions in the pasta pan.",
  "Add tomatoes to the pasta sauce.",
  "Season the pasta sauce with basil.",
  "Stir the pasta into the sauce gently.",
];
const GUITAR = [
  "Tune every guitar string carefully.",
  "Press the guitar strings near the fret.",
  "Strum the guitar chords with your wrist.",
  "Practice guitar scales every morning.",
  "Pluck each guitar string with fingertips.",
  "Slide along the guitar neck for vibrato.",
];

describe("suggestChapters", () => {
  const words = transcript([...COOKING, ...GUITAR]);
  const project = projectOf(words);

  it("always starts at 0:00", () => {
    const out = suggestChapters(project, { count: 2 });
    expect(out[0]!.outputTime).toBe(0);
  });

  it("puts the second chapter where the topic changes", () => {
    const out = suggestChapters(project, { count: 2, minChapterSec: 10 });
    expect(out).toHaveLength(2);
    const switchTime = words[COOKING.join(" ").split(" ").length]!.start;
    expect(Math.abs(out[1]!.outputTime - switchTime)).toBeLessThan(0.5);
  });

  it("never makes a chapter shorter than the minimum", () => {
    const out = suggestChapters(project, { count: 6, minChapterSec: 12 });
    for (let i = 1; i < out.length; i++) {
      expect(out[i]!.outputTime - out[i - 1]!.outputTime).toBeGreaterThanOrEqual(12 - 1e-9);
    }
  });

  it("returns one chapter when the video is too short to split", () => {
    const short = projectOf(transcript(["Hey welcome to this video."]));
    expect(suggestChapters(short, { count: 5 })).toHaveLength(1);
  });

  it("returns nothing without a transcript", () => {
    expect(suggestChapters(newProject("empty"))).toEqual([]);
  });

  it("titles chapters from their opening sentence, without leading filler", () => {
    const p = projectOf(transcript(["Okay so we start the guitar tune up.", ...GUITAR, ...COOKING]));
    const out = suggestChapters(p, { count: 2 });
    expect(out[0]!.title.toLowerCase().startsWith("okay")).toBe(false);
    expect(out[1]!.title).toMatch(/^[A-Z]/);
  });

  it("calls a greeting opener Introduction", () => {
    const p = projectOf(transcript(["Hey welcome to this video.", ...COOKING, ...GUITAR]));
    expect(suggestChapters(p, { count: 2 })[0]!.title).toBe("Introduction");
  });

  it("prefers a cue phrase when topics are otherwise equally close", () => {
    const flat = Array.from({ length: 12 }, () => "The same plain words repeat again.");
    flat[6] = "Next let's talk about something else.";
    const p = projectOf(transcript(flat));
    const out = suggestChapters(p, { count: 2, minChapterSec: 10 });
    const cueTime = transcript(flat).find((w) => w.text === "Next")!.start;
    expect(Math.abs(out[1]!.outputTime - cueTime)).toBeLessThan(0.5);
  });

  it("follows the edit: chapter times are on the output timeline", () => {
    const out = suggestChapters(project, { count: 2 });
    expect(out[1]!.outputTime).toBeGreaterThan(0);
    expect(out[1]!.outputTime).toBeLessThan(project.media.m!.duration);
  });
});

describe("defaultChapterCount", () => {
  it("is one for very short videos", () => {
    expect(defaultChapterCount(8)).toBe(1);
  });
  it("grows with length and is capped", () => {
    expect(defaultChapterCount(300)).toBe(3);
    expect(defaultChapterCount(60 * 60)).toBe(12);
  });
  it("needs at least two chapters worth of time for the default of two", () => {
    expect(defaultChapterCount(25)).toBe(2);
    expect(defaultChapterCount(15)).toBe(1);
  });
});
