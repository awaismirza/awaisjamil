import { readFileSync, writeFileSync, existsSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";
import {
  cleanFrameTitle,
  defaultScene,
  FRAME_KINDS,
  FRAME_TITLE_MAX,
  fitText,
  fixedScreenRatio,
  frameColor,
  resolveSceneForExport,
  sanitizeFrame,
  sanitizeScene,
  sceneLayout,
  SCENE_ASPECTS,
  type DeviceFrame,
  type FrameKind,
  type PxRect,
  type SceneSettings,
} from "@/lib/scene";
import { sceneCss } from "@/lib/sceneCss";

const scene = (
  frame: DeviceFrame | undefined,
  patch: Partial<SceneSettings> = {},
): SceneSettings => ({
  ...defaultScene(),
  enabled: true,
  ...(frame ? { frame } : {}),
  ...patch,
});
const frameOf = (kind: FrameKind, extra: Partial<DeviceFrame> = {}): DeviceFrame => ({
  kind,
  theme: "light",
  ...extra,
});

describe("sanitizeFrame", () => {
  it("drops anything that is not a known frame", () => {
    for (const bad of [
      null,
      undefined,
      3,
      "phone",
      [],
      {},
      { kind: "toaster" },
      { kind: "__proto__" },
    ]) {
      expect(sanitizeFrame(bad)).toBeUndefined();
    }
  });

  it("keeps a valid frame and defaults the theme", () => {
    expect(sanitizeFrame({ kind: "phone" })).toEqual({ kind: "phone", theme: "light" });
    expect(sanitizeFrame({ kind: "browser", theme: "dark", color: "#ABCDEF" })).toEqual({
      kind: "browser",
      theme: "dark",
      color: "#abcdef",
    });
    expect(sanitizeFrame({ kind: "laptop", theme: "neon" })?.theme).toBe("light");
    expect(sanitizeFrame({ kind: "phone", cutout: "notch" })?.cutout).toBe("notch");
    expect(sanitizeFrame({ kind: "phone", cutout: "island" })).not.toHaveProperty("cutout");
    expect(sanitizeFrame({ kind: "laptop", cutout: "notch" })).not.toHaveProperty("cutout");
  });

  it("rejects colours that are not #rrggbb", () => {
    for (const c of ["red", "#fff", "#12345g", "#123456;movie=x", 5, null, {}]) {
      expect(sanitizeFrame({ kind: "tablet", color: c })).toEqual({
        kind: "tablet",
        theme: "light",
      });
    }
  });

  it("cleans the title: single line, no control characters or emoji, capped; browser only", () => {
    expect(cleanFrameTitle("  hi\n\tthere\u0000  ")).toBe("hi there");
    expect(cleanFrameTitle("a\u{1F600}b")).toBe("ab");
    expect(cleanFrameTitle("x".repeat(500))).toHaveLength(FRAME_TITLE_MAX);
    expect(cleanFrameTitle(42)).toBe("");
    expect(sanitizeFrame({ kind: "browser", title: "docs {\\an7} \\N" })?.title).toBe(
      "docs {\\an7} \\N",
    );
    expect(sanitizeFrame({ kind: "phone", title: "nope" })).not.toHaveProperty("title");
    expect(sanitizeFrame({ kind: "browser", title: "   " })).not.toHaveProperty("title");
  });

  it("is wired into sanitizeScene; old scenes have no frame and are unchanged", () => {
    expect(sanitizeScene({ enabled: true, frame: { kind: "laptop" } }).frame).toEqual({
      kind: "laptop",
      theme: "light",
    });
    expect(sanitizeScene({ enabled: true, frame: "laptop" })).not.toHaveProperty("frame");
    expect(sanitizeScene({ enabled: true })).not.toHaveProperty("frame");
    expect(sanitizeScene({ frame: { kind: "x" }, paddingPct: 4 }).paddingPct).toBe(4);
    const old = { ...defaultScene(), enabled: true };
    expect(sanitizeScene(old)).toEqual(old);
  });

  it("survives hostile frame JSON", () => {
    const hostile = {
      kind: "browser",
      theme: { toString: 1 },
      color: ["#ffffff"],
      title: { length: 1e9 },
      extra: "x".repeat(10),
    };
    expect(sanitizeFrame(hostile)).toEqual({ kind: "browser", theme: "light" });
  });
});

const SOURCES = [
  { w: 1920, h: 1080 },
  { w: 1080, h: 1920 },
  { w: 1000, h: 1000 },
  { w: 3840, h: 1080 },
  { w: 1280, h: 720 },
];

const inside = (a: PxRect, b: PxRect, tol = 0) =>
  a.x >= b.x - tol &&
  a.y >= b.y - tol &&
  a.x + a.w <= b.x + b.w + tol &&
  a.y + a.h <= b.y + b.h + tol;

describe("device frame geometry (aspect x orientation x padding matrix)", () => {
  for (const kind of FRAME_KINDS) {
    for (const aspect of SCENE_ASPECTS) {
      for (const src of SOURCES) {
        for (const paddingPct of [0, 8, 30]) {
          it(`${kind} / ${aspect} / ${src.w}x${src.h} / pad ${paddingPct}`, () => {
            const s = scene(frameOf(kind, { title: "example.com/docs" }), { aspect, paddingPct });
            const l = sceneLayout(s, src);
            const f = l.frame!;
            const canvas = { x: 0, y: 0, w: l.canvasW, h: l.canvasH };
            expect(f).toBeDefined();
            // The device fits the canvas, is centred, and respects the padding (a few px of rounding).
            expect(inside(f.outer, canvas)).toBe(true);
            expect(Math.abs(f.outer.x * 2 + f.outer.w - l.canvasW)).toBeLessThanOrEqual(2);
            expect(Math.abs(f.outer.y * 2 + f.outer.h - l.canvasH)).toBeLessThanOrEqual(2);
            const pad = (paddingPct / 100) * Math.min(l.canvasW, l.canvasH);
            expect(f.outer.w).toBeLessThanOrEqual(l.canvasW - 2 * pad + 4);
            expect(f.outer.h).toBeLessThanOrEqual(l.canvasH - 2 * pad + 4);
            // Screen inside the device, picture inside the screen, centred, even sizes.
            expect(inside(f.screen, f.outer)).toBe(true);
            expect(inside(l.content, f.screen)).toBe(true);
            expect(l.content.w % 2).toBe(0);
            expect(l.content.h % 2).toBe(0);
            expect(
              Math.abs(l.content.x * 2 + l.content.w - (f.screen.x * 2 + f.screen.w)),
            ).toBeLessThanOrEqual(2);
            expect(
              Math.abs(l.content.y * 2 + l.content.h - (f.screen.y * 2 + f.screen.h)),
            ).toBeLessThanOrEqual(2);
            // Every shape stays on the device and its radii fit.
            for (const sh of [...f.below, ...f.above]) {
              expect(inside(sh, f.outer)).toBe(true);
              for (const r of sh.radii) {
                expect(r).toBeGreaterThanOrEqual(0);
                expect(r).toBeLessThanOrEqual(Math.min(sh.w, sh.h) / 2);
              }
              expect(Number.isInteger(sh.x + sh.y + sh.w + sh.h)).toBe(true);
            }
            expect(f.below.some((b) => b.silhouette)).toBe(true);
            // 4:2:0 video places overlays on even pixels: every offset and size is even.
            const evens = [f.outer, f.screen, l.content, ...f.below, ...f.above].flatMap((q) => [
              q.x,
              q.y,
              q.w,
              q.h,
            ]);
            expect(evens.filter((n) => n % 2 !== 0)).toEqual([]);
            expect(l.radiusPx).toBe(0);
            // Screen aspect: fixed for phone/tablet, the picture's for browser/laptop.
            const fixed = fixedScreenRatio(kind);
            const ratio = f.screen.w / f.screen.h;
            if (fixed !== null) expect(Math.abs(ratio / fixed - 1)).toBeLessThan(0.02);
            else {
              const pic = l.content.w / l.content.h;
              expect(Math.abs(ratio / pic - 1)).toBeLessThan(0.005);
            }
          });
        }
      }
    }
  }
});

describe("phone with a landscape source", () => {
  it("is portrait, with the 16:9 picture letterboxed in the screen", () => {
    const s = scene(frameOf("phone"), { aspect: "9:16", paddingPct: 6 });
    const l = sceneLayout(s, { w: 1920, h: 1080 });
    const f = l.frame!;
    expect(f.outer.h).toBeGreaterThan(f.outer.w * 1.8);
    expect(f.screen.w / f.screen.h).toBeCloseTo(9 / 19.5, 2);
    // Full screen width, 16:9 tall, equal black bars above and below.
    expect(l.content.w).toBe(f.screen.w);
    expect(l.content.h / l.content.w).toBeCloseTo(9 / 16, 2);
    const above = l.content.y - f.screen.y;
    const below = f.screen.y + f.screen.h - (l.content.y + l.content.h);
    expect(Math.abs(above - below)).toBeLessThanOrEqual(2);
    expect(above).toBeGreaterThan(f.screen.h * 0.2);
    // The camera dot sits over the top letterbox bar, not over the picture.
    const dot = f.above[0]!;
    expect(dot.w).toBe(dot.h);
    expect(dot.y + dot.h).toBeLessThanOrEqual(l.content.y);
    const withCutout = (cutout: "none" | "dot" | "notch") =>
      sceneLayout(scene(frameOf("phone", { cutout }), { aspect: "9:16", paddingPct: 6 }), {
        w: 1920,
        h: 1080,
      }).frame!;
    expect(withCutout("none").above).toHaveLength(0);
    const notch = withCutout("notch").above[0]!;
    expect(notch.w).toBeGreaterThan(notch.h * 4);
    expect(notch.radii.slice(0, 2)).toEqual([0, 0]);
    // The picture is part of the framed 9:16 canvas: same 1080x1920 canvas as without a frame.
    expect([l.canvasW, l.canvasH]).toEqual([1080, 1920]);
  });

  it("fills a portrait phone screen with a portrait source (small letterbox)", () => {
    const l = sceneLayout(scene(frameOf("phone"), { aspect: "9:16" }), { w: 1080, h: 1920 });
    expect(l.content.w).toBe(l.frame!.screen.w);
    expect(l.content.h).toBeLessThan(l.frame!.screen.h);
  });

  it("a portrait crop of a landscape source is framed as portrait", () => {
    const s = scene(frameOf("browser"), {
      crop: { x: 0.35, y: 0, w: 0.3, h: 1 },
      aspect: "source",
    });
    const l = sceneLayout(s, { w: 1920, h: 1080 });
    expect(l.content.w).toBeLessThan(l.content.h);
    expect(l.frame!.screen.w / l.frame!.screen.h).toBeCloseTo(l.content.w / l.content.h, 2);
  });
});

describe("frame and the rest of the scene", () => {
  it("no frame: the layout has no frame and keeps its box and radius", () => {
    const l = sceneLayout(scene(undefined, { aspect: "16:9" }), { w: 1920, h: 1080 });
    expect(l.frame).toBeUndefined();
    expect(l.radiusPx).toBeGreaterThan(0);
    const r = resolveSceneForExport(scene(undefined), { w: 1920, h: 1080 });
    expect(r).not.toHaveProperty("frame");
  });

  it("a frame follows a custom export canvas", () => {
    const s = scene(frameOf("laptop"), { aspect: "16:9" });
    const a = resolveSceneForExport(s, { w: 1920, h: 1080 });
    const b = resolveSceneForExport(s, { w: 1920, h: 1080 }, { w: 960, h: 540 });
    expect(b.canvasW).toBe(960);
    expect(b.frame!.screen.w).toBeLessThan(a.frame!.screen.w);
  });

  it("default colours per kind; custom colour wins", () => {
    expect(frameColor(frameOf("browser"))).toBe("#e6e6e9");
    expect(frameColor(frameOf("browser", { theme: "dark" }))).toBe("#2c2c2f");
    expect(frameColor(frameOf("phone", { theme: "dark" }))).toBe("#18181a");
    expect(frameColor(frameOf("phone", { color: "#336699" }))).toBe("#336699");
    const l = sceneLayout(scene(frameOf("phone", { color: "#336699" })), { w: 1920, h: 1080 });
    expect(l.frame!.below[0]!.color).toBe("#336699");
  });

  it("browser: traffic lights and an address pill with text when a title is set", () => {
    const withTitle = sceneLayout(scene(frameOf("browser", { title: "example.com" })), {
      w: 1920,
      h: 1080,
    }).frame!;
    expect(withTitle.above.map((a) => a.color).slice(0, 3)).toEqual([
      "#b4b4ba",
      "#b4b4ba",
      "#b4b4ba",
    ]);
    expect(withTitle.above).toHaveLength(4);
    expect(withTitle.texts).toHaveLength(1);
    expect(withTitle.texts[0]!.text).toBe("example.com");
    const t = withTitle.texts[0]!;
    // Centred in the title bar, above the screen.
    expect(t.cy).toBeLessThan(withTitle.screen.y);
    expect(t.cx).toBeCloseTo(withTitle.outer.x + withTitle.outer.w / 2, 0);
    const bare = sceneLayout(scene(frameOf("browser")), { w: 1920, h: 1080 }).frame!;
    expect(bare.texts).toHaveLength(0);
    expect(bare.above).toHaveLength(3);
    // The title bar is the first `silhouette` shape and the screen starts below it.
    expect(bare.screen.y).toBeGreaterThan(bare.outer.y);
    expect(bare.screenRadii.slice(0, 2)).toEqual([0, 0]);
  });

  it("text is cut with an ellipsis rather than overflowing the pill", () => {
    const long = "https://example.com/" + "very-long-path/".repeat(20);
    const l = sceneLayout(scene(frameOf("browser", { title: long })), { w: 1920, h: 1080 }).frame!;
    const shown = l.texts[0]!.text;
    expect(shown.endsWith("…")).toBe(true);
    expect(shown.length).toBeLessThan(long.length);
    expect(fitText("short", 10, 500)).toBe("short");
    expect(fitText("abcdefghij", 10, 30)).toMatch(/…$/);
  });
});

describe("preview and export read the same geometry", () => {
  const px = (css: string | number | undefined, total: number) =>
    (parseFloat(String(css)) / 100) * total;
  for (const kind of FRAME_KINDS) {
    for (const [aspect, src] of [
      ["16:9", { w: 1920, h: 1080 }],
      ["9:16", { w: 1920, h: 1080 }],
      ["1:1", { w: 1080, h: 1920 }],
    ] as const) {
      it(`${kind} / ${aspect} / ${src.w}x${src.h}: CSS boxes, layout and export payload agree`, () => {
        const s = scene(frameOf(kind, { title: "example.com", theme: "dark" }), { aspect });
        const l = sceneLayout(s, src);
        const css = sceneCss(s, src);
        const f = l.frame!;
        const W = l.canvasW;
        const H = l.canvasH;
        // Screen = the `content` box (it clips the picture to the screen's corners).
        expect(px(css.content.left, W)).toBeCloseTo(f.screen.x, 2);
        expect(px(css.content.top, H)).toBeCloseTo(f.screen.y, 2);
        expect(px(css.content.width, W)).toBeCloseTo(f.screen.w, 2);
        expect(px(css.content.height, H)).toBeCloseTo(f.screen.h, 2);
        // The picture box inside it reproduces layout.content.
        const inset = css.frame!.inset;
        expect(f.screen.x + (px(inset.left, 100) / 100) * f.screen.w).toBeCloseTo(l.content.x, 2);
        expect(f.screen.y + (px(inset.top, 100) / 100) * f.screen.h).toBeCloseTo(l.content.y, 2);
        expect((px(inset.width, 100) / 100) * f.screen.w).toBeCloseTo(l.content.w, 2);
        expect((px(inset.height, 100) / 100) * f.screen.h).toBeCloseTo(l.content.h, 2);
        // Every shape's CSS box is the layout shape, in the same order.
        const shapes = [...f.below, ...f.above];
        const nodes = [...css.frame!.below, ...css.frame!.above.filter((n) => !n.text)];
        expect(nodes).toHaveLength(shapes.length);
        nodes.forEach((n, i) => {
          const sh = shapes[i]!;
          expect(px(n.style.left, W)).toBeCloseTo(sh.x, 2);
          expect(px(n.style.top, H)).toBeCloseTo(sh.y, 2);
          expect(px(n.style.width, W)).toBeCloseTo(sh.w, 2);
          expect(px(n.style.height, H)).toBeCloseTo(sh.h, 2);
          expect(n.style.backgroundColor).toBe(sh.color);
          const radii = String(n.style.borderRadius)
            .split(" ")
            .map((v) => (parseFloat(v) / 100) * W);
          radii.forEach((v, k) => expect(v).toBeCloseTo(sh.radii[k]!, 2));
        });
        const texts = css.frame!.above.filter((n) => n.text);
        expect(texts.map((t) => t.text)).toEqual(f.texts.map((t) => t.text));
        texts.forEach((n, i) => {
          expect(px(n.style.left, W)).toBeCloseTo(f.texts[i]!.cx, 2);
          expect(px(n.style.top, H)).toBeCloseTo(f.texts[i]!.cy, 2);
          expect(parseFloat(String(n.style.fontSize))).toBeCloseTo(
            (f.texts[i]!.fontPx / W) * 100,
            3,
          );
        });
        // The export payload is these same numbers.
        const r = resolveSceneForExport(s, src);
        expect(r.frame).toEqual({
          screen: f.screen,
          screenRadii: f.screenRadii,
          below: f.below,
          above: f.above,
          texts: f.texts,
        });
        expect([r.contentX, r.contentY, r.contentW, r.contentH]).toEqual([
          l.content.x,
          l.content.y,
          l.content.w,
          l.content.h,
        ]);
        // Zoom, cursor and annotations keep working in the picture's and the canvas's own space:
        // the stage is still the full canvas.
        expect(css.stage.aspectRatio).toBe(`${W} / ${H}`);
      });
    }
  }

  it("a frame casts its shadow as a filter on the outline group, not a box-shadow", () => {
    const css = sceneCss(scene(frameOf("laptop"), { shadow: 0.8 }), { w: 1920, h: 1080 });
    expect(String(css.frame!.belowGroup.filter)).toContain("drop-shadow(");
    expect(css.content.boxShadow).toBeUndefined();
    const none = sceneCss(scene(frameOf("laptop"), { shadow: 0 }), { w: 1920, h: 1080 });
    expect(none.frame!.belowGroup.filter).toBe("none");
  });

  it("without a frame the CSS has no frame parts", () => {
    expect(sceneCss(scene(undefined), { w: 1920, h: 1080 }).frame).toBeNull();
  });
});

// The Rust side renders these exact payloads with the real ffmpeg (scene.rs tests).
// Regenerate with UPDATE_FIXTURES=1 npx vitest run tests/deviceFrame.test.ts.
describe("export payload fixtures for the Rust pixel tests", () => {
  const SRC = { w: 640, h: 360 };
  const cases: Record<string, [SceneSettings, { w: number; h: number }]> = {
    browser: [
      scene(frameOf("browser", { theme: "dark", title: "example.com/docs" }), {
        aspect: "16:9",
        background: { kind: "transparent" },
        paddingPct: 6,
        shadow: 0,
      }),
      { w: 960, h: 540 },
    ],
    phone: [
      scene(frameOf("phone"), {
        aspect: "9:16",
        background: { kind: "transparent" },
        paddingPct: 6,
        shadow: 0,
      }),
      { w: 540, h: 960 },
    ],
    laptop: [
      scene(frameOf("laptop", { color: "#202040" }), {
        aspect: "16:9",
        background: { kind: "transparent" },
        paddingPct: 6,
        shadow: 0.5,
      }),
      { w: 960, h: 540 },
    ],
    // A layout that used to land on odd offsets (4:2:0 video would then slip it by 1 px).
    browserOdd: [
      scene(frameOf("browser", { title: "x.test" }), {
        aspect: "16:9",
        background: { kind: "solid", color: "#336699" },
        paddingPct: 7,
        shadow: 0,
      }),
      { w: 1002, h: 564 },
    ],
    laptop4k: [
      scene(frameOf("laptop"), {
        aspect: "16:9",
        background: { kind: "solid", color: "#203040" },
        paddingPct: 6,
        shadow: 0.6,
      }),
      { w: 3840, h: 2160 },
    ],
    tablet: [
      scene(frameOf("tablet"), {
        aspect: "1:1",
        background: { kind: "solid", color: "#0000ff" },
        paddingPct: 6,
        shadow: 0,
      }),
      { w: 600, h: 600 },
    ],
  };
  const file = resolve(__dirname, "fixtures/deviceFrameRender.json");
  const current = Object.fromEntries(
    Object.entries(cases).map(([k, [s, canvas]]) => [k, resolveSceneForExport(s, SRC, canvas)]),
  );
  it("matches the checked-in fixture", () => {
    if (process.env.UPDATE_FIXTURES) writeFileSync(file, JSON.stringify(current, null, 2) + "\n");
    // A missing fixture is a failure, never silently regenerated.
    expect(existsSync(file)).toBe(true);
    expect(JSON.parse(readFileSync(file, "utf8"))).toEqual(JSON.parse(JSON.stringify(current)));
  });
});
