import { afterEach, beforeEach, expect, it, vi } from "vitest";
import { idleSnapshot, useRecordingStore } from "@/stores/recordingStore";
import { useSettingsStore } from "@/stores/settingsStore";
import { startRecording, cancelRecording, type RecordingSnapshot } from "@/lib/ipc";
vi.mock("@/lib/ipc", async (original) => ({
  ...(await original<typeof import("@/lib/ipc")>()),
  startRecording: vi.fn(),
  cancelRecording: vi.fn(async () => {}),
}));
vi.mock("@tauri-apps/api/window", () => ({
  getCurrentWindow: () => ({ unminimize: async () => {}, setFocus: async () => {} }),
}));
const snap = (revision: number, over: Partial<RecordingSnapshot> = {}): RecordingSnapshot => ({
  ...idleSnapshot(revision),
  ...over,
});
beforeEach(() => {
  vi.useFakeTimers();
  vi.mocked(startRecording).mockReset();
  vi.mocked(cancelRecording).mockClear();
  vi.stubGlobal("requestAnimationFrame", (callback: () => void) => setTimeout(callback, 16));
  useRecordingStore.setState({
    phase: "idle",
    session: idleSnapshot(),
    sessionId: null,
    revision: 0,
    local: null,
    opts: { mode: "voiceover" },
  });
  useSettingsStore.getState().setRecording({ countdownSec: 0 });
});
afterEach(() => {
  vi.clearAllTimers();
  vi.useRealTimers();
  vi.unstubAllGlobals();
});
it("cancelling while countdown controls paint away cannot start capture later", async () => {
  useRecordingStore.getState().beginCountdown();
  await useRecordingStore.getState().cancel();
  await vi.advanceTimersByTimeAsync(40);
  expect(startRecording).not.toHaveBeenCalled();
  expect(useRecordingStore.getState().phase).toBe("idle");
});
it("cancel during native startup names the session Rust already published", async () => {
  vi.mocked(startRecording).mockImplementation(() => new Promise(() => {}));
  useRecordingStore.getState().beginCountdown();
  await vi.advanceTimersByTimeAsync(40);
  expect(startRecording).toHaveBeenCalledTimes(1);
  // Rust publishes the Starting snapshot before the start command resolves.
  useRecordingStore.getState().applySnapshot(snap(1, { sessionId: "s1", phase: "starting" }));
  expect(useRecordingStore.getState().phase).toBe("countdown");
  await useRecordingStore.getState().cancel();
  expect(cancelRecording).toHaveBeenCalledWith("s1");
  // Rust confirms the take ended; the UI returns to idle without a local guess.
  useRecordingStore.getState().applySnapshot(snap(2));
  expect(useRecordingStore.getState().phase).toBe("idle");
});
it("cancels by id when the start request returns after the user already cancelled", async () => {
  let finish!: (s: RecordingSnapshot) => void;
  vi.mocked(startRecording).mockImplementation(
    () =>
      new Promise((resolve) => {
        finish = resolve;
      }),
  );
  useRecordingStore.getState().beginCountdown();
  await vi.advanceTimersByTimeAsync(40);
  await useRecordingStore.getState().cancel(); // no session id published yet
  expect(cancelRecording).not.toHaveBeenCalled();
  expect(useRecordingStore.getState().phase).toBe("idle");
  finish(snap(3, { sessionId: "late", phase: "recording" }));
  await vi.advanceTimersByTimeAsync(1);
  expect(cancelRecording).toHaveBeenCalledWith("late");
});
it("a cancelled start is not reported as a failure", async () => {
  vi.mocked(startRecording).mockRejectedValue("Recording cancelled");
  useRecordingStore.getState().beginCountdown();
  await vi.advanceTimersByTimeAsync(40);
  expect(useRecordingStore.getState().phase).toBe("idle");
});
it("sends only the chosen source to Rust, never the panel's UI-only choices", async () => {
  vi.mocked(startRecording).mockResolvedValue(snap(1));
  useRecordingStore.setState({
    devices: {
      backend: "native",
      video: [{ index: 1000, name: "Display", isScreen: true }],
      audio: [],
      windows: [{ id: 42, title: "Doc", app: "Pages" }],
    },
    opts: { mode: "screen", screenIndex: 1000, sourceKind: "display", windowId: 42 },
  });
  useSettingsStore.getState().setRecording({ hideWindow: false });
  useRecordingStore.getState().beginCountdown();
  await vi.advanceTimersByTimeAsync(40);
  expect(startRecording).toHaveBeenCalledWith({ mode: "screen", screenIndex: 1000 });
});
