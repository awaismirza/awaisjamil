import { beforeEach, describe, expect, it } from "vitest";
import { defaultSettings, sanitizeSettings } from "@/lib/settings";
import { defaultShortcuts } from "@/lib/shortcuts";
import { useSettingsStore } from "@/stores/settingsStore";

describe("sanitizeSettings", () => {
  it("returns defaults for missing or non-object input", () => {
    expect(sanitizeSettings(null)).toEqual(defaultSettings());
    expect(sanitizeSettings("nope")).toEqual(defaultSettings());
    expect(sanitizeSettings([])).toEqual(defaultSettings());
  });

  it("keeps valid custom shortcuts, canonicalised", () => {
    const s = sanitizeSettings({ shortcuts: { record: "option+cmd+k" } });
    expect(s.shortcuts.record).toBe("CmdOrCtrl+Alt+K");
    expect(s.shortcuts.pause).toBe(defaultShortcuts().pause);
  });

  it("drops invalid, reserved and modifier-less shortcuts", () => {
    const s = sanitizeSettings({
      shortcuts: { record: "R", pause: "cmd+q", rerecord: "garbage+++", mark: 5 },
    });
    expect(s.shortcuts).toEqual(defaultShortcuts());
  });

  it("never lets two actions share a shortcut", () => {
    const s = sanitizeSettings({ shortcuts: { record: "cmd+alt+j", pause: "alt+cmd+j" } });
    const values = Object.values(s.shortcuts);
    expect(new Set(values).size).toBe(values.length);
  });

  it("rejects a custom shortcut that collides with another action's default", () => {
    // Default pause is CmdOrCtrl+Alt+P; binding record to it must not leave both on it.
    const s = sanitizeSettings({ shortcuts: { record: "cmd+alt+p" } });
    const values = Object.values(s.shortcuts);
    expect(new Set(values).size).toBe(values.length);
  });

  it("accepts only the offered countdown values", () => {
    expect(sanitizeSettings({ recording: { countdownSec: 5 } }).recording.countdownSec).toBe(5);
    expect(sanitizeSettings({ recording: { countdownSec: 7 } }).recording.countdownSec).toBe(3);
    expect(sanitizeSettings({ recording: { countdownSec: "5" } }).recording.countdownSec).toBe(3);
  });

  it("ignores wrongly typed toggles", () => {
    const s = sanitizeSettings({ recording: { hideWindow: "yes", autoTranscribe: false } });
    expect(s.recording.hideWindow).toBe(true);
    expect(s.recording.autoTranscribe).toBe(false);
  });
});

describe("settingsStore", () => {
  beforeEach(() => {
    window.localStorage.clear();
    useSettingsStore.setState(defaultSettings());
  });

  it("binds a free shortcut and persists it", () => {
    const res = useSettingsStore.getState().setShortcut("pause", "alt+shift+p");
    expect(res).toEqual({ ok: true });
    expect(useSettingsStore.getState().shortcuts.pause).toBe("Alt+Shift+P");
    const stored = JSON.parse(window.localStorage.getItem("yusafcut.settings") ?? "{}");
    expect(stored.shortcuts.pause).toBe("Alt+Shift+P");
  });

  it("refuses a shortcut another action already uses", () => {
    const res = useSettingsStore.getState().setShortcut("pause", "CmdOrCtrl+Alt+R");
    expect(res.ok).toBe(false);
    expect(useSettingsStore.getState().shortcuts.pause).toBe(defaultShortcuts().pause);
  });

  it("refuses reserved and modifier-less shortcuts with a reason", () => {
    const reserved = useSettingsStore.getState().setShortcut("mark", "cmd+q");
    const bare = useSettingsStore.getState().setShortcut("mark", "m");
    expect(reserved.ok).toBe(false);
    expect(bare.ok).toBe(false);
    if (!bare.ok) expect(bare.reason).toMatch(/⌘|modifier|typing/i);
  });

  it("resets one shortcut, handing back a default another action took", () => {
    const s = useSettingsStore.getState();
    s.setShortcut("pause", "alt+shift+p");
    s.setShortcut("mark", "CmdOrCtrl+Alt+P"); // takes pause's old default
    useSettingsStore.getState().resetShortcut("pause");
    const values = Object.values(useSettingsStore.getState().shortcuts);
    expect(new Set(values).size).toBe(values.length);
    expect(useSettingsStore.getState().shortcuts.pause).toBe(defaultShortcuts().pause);
  });

  it("resets every shortcut", () => {
    useSettingsStore.getState().setShortcut("record", "alt+shift+k");
    useSettingsStore.getState().resetShortcuts();
    expect(useSettingsStore.getState().shortcuts).toEqual(defaultShortcuts());
  });

  it("merges recording settings and keeps the rest", () => {
    useSettingsStore.getState().setRecording({ countdownSec: 0 });
    const r = useSettingsStore.getState().recording;
    expect(r.countdownSec).toBe(0);
    expect(r.hideWindow).toBe(true);
  });
});
