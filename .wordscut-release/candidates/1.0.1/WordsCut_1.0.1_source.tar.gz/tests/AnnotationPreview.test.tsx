import { act, cleanup, render } from "@testing-library/react";
import { afterEach, beforeEach, expect, it, vi } from "vitest";
import { VideoPreview } from "@/components/VideoPreview/VideoPreview";
import { addMediaWithTranscript, newProject } from "@/lib/edl";
import { parseCursorLog } from "@/lib/cursor";
import { useProjectStore } from "@/stores/projectStore";
import { useUIStore } from "@/stores/uiStore";
import { usePlayerStore } from "@/stores/playerStore";
vi.mock("@tauri-apps/api/core", () => ({ convertFileSrc: (path: string) => path }));
beforeEach(() => {
  vi.spyOn(HTMLMediaElement.prototype, "pause").mockImplementation(() => {});
  vi.spyOn(HTMLMediaElement.prototype, "load").mockImplementation(() => {});
  const p = addMediaWithTranscript(
    newProject("annotations"),
    {
      id: "m",
      path: "/tmp/demo.mp4",
      duration: 20,
      width: 1920,
      height: 1080,
      fps: 30,
      audioSampleRate: 48000,
      sha256: "x",
    },
    [],
  );
  useProjectStore.setState({ project: p, dirty: false });
  usePlayerStore.getState().reset();
});
afterEach(() => {
  cleanup();
  vi.restoreAllMocks();
});

it("draws fixed annotations outside the zoom layer, follow-zoom ones inside it, and keystroke caps", () => {
  const { container, getByTestId } = render(<VideoPreview />);
  const video = container.querySelector("video")!;
  act(() => {
    const s = useProjectStore.getState();
    s.addZoomRegion({ start: 0, end: 5, scale: 2, easeMs: 0 });
    const fixed = s.addAnnotation("text", 1)!;
    s.updateAnnotation(fixed, { text: "Hi {there}\nline 2" });
    const follow = s.addAnnotation("box", 1)!;
    s.updateAnnotation(follow, { followZoom: true, filled: true });
    s.addAnnotation("arrow", 1);
    s.setCursorTrack("m", parseCursorLog('{"type":"key","t":1.5,"mods":["cmd"]}'));
    s.setKeystrokes({ enabled: true });
    usePlayerStore.getState().setCurrentTime(2);
  });
  expect(container.querySelector("video")).toBe(video);
  const layers = container.querySelectorAll('[data-testid="annotation-overlay"]');
  expect(layers).toHaveLength(2);
  const zoomLayer = video.parentElement!;
  expect(zoomLayer.style.transform).toContain("scale(2)");
  const inside = zoomLayer.querySelector('[data-testid="annotation-overlay"]')!;
  expect(inside.querySelector('[data-annotation="box"]')).toBeInTheDocument();
  expect(inside.querySelector('[data-annotation="text"]')).toBeNull();
  const fixedLayer = [...layers].find((l) => l !== inside)!;
  expect(zoomLayer.contains(fixedLayer)).toBe(false);
  const text = fixedLayer.querySelector("text")!;
  expect([...text.querySelectorAll("tspan")].map((t) => t.textContent)).toEqual([
    "Hi {there}",
    "line 2",
  ]);
  expect(fixedLayer.querySelector('[data-annotation="arrow"]')).toBeInTheDocument();
  expect(getByTestId("keystroke-caption").textContent).toBe("⌘ key");

  // Outside their time nothing is drawn; keystrokes off removes the caps.
  act(() => {
    usePlayerStore.getState().setCurrentTime(10);
    useProjectStore.getState().setKeystrokes({ enabled: false });
  });
  expect(container.querySelector("[data-annotation]")).toBeNull();
  expect(container.querySelector('[data-testid="keystroke-caption"]')).toBeNull();
  expect(container.querySelector("video")).toBe(video);
});

it("lifts the key caps above bottom captions only when the export burns them in", () => {
  const words = [{ id: "w0", text: "hello", start: 0, end: 3, confidence: 1 }];
  const p = addMediaWithTranscript(
    newProject("caps"),
    useProjectStore.getState().project.media["m"]!,
    words,
  );
  useProjectStore.setState({ project: p });
  useUIStore.getState().setBurnCaptions(false);
  const { getByTestId } = render(<VideoPreview />);
  act(() => {
    const s = useProjectStore.getState();
    s.setCursorTrack("m", parseCursorLog('{"type":"key","t":1.5,"mods":["cmd"]}'));
    s.setKeystrokes({ enabled: true });
    usePlayerStore.getState().setCurrentTime(2);
  });
  const bottom = () => parseFloat(getByTestId("keystroke-caption").style.bottom);
  const low = bottom();
  act(() => useUIStore.getState().setBurnCaptions(true));
  expect(bottom()).toBeGreaterThan(low);
  act(() => useUIStore.getState().setBurnCaptions(false));
  expect(bottom()).toBe(low);
});
