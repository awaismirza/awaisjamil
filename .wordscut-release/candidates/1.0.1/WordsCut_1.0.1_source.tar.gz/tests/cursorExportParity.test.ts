import { describe, expect, it } from "vitest";
import fixture from "./fixtures/cursor-export-parity.json";
import { sanitizeCursorTrack, smoothCursorTrack } from "@/lib/cursor";
import { cursorAppearance, sanitizeCursorStyle } from "@/lib/cursorStyle";
describe("shared cursor export samples", () => {
  it("retains the preview's deterministic source-time appearance", () => {
    const track = sanitizeCursorTrack({ events: fixture.events });
    const style = sanitizeCursorStyle(fixture.style);
    const smooth = smoothCursorTrack(track, style.smoothing);
    for (const expected of fixture.samples) {
      const actual = cursorAppearance(track, smooth, expected.t, style);
      expect(actual.visible).toBe(expected.visible);
      expect(actual.bounce).toBeCloseTo(expected.bounce, 10);
      expect(actual.clicks).toEqual(expected.clicks);
      expect(actual.point?.x).toBeCloseTo(expected.point.x, 10);
      expect(actual.point?.y).toBeCloseTo(expected.point.y, 10);
      expect(actual.point?.outside).toBe(expected.point.outside);
    }
  });
});
