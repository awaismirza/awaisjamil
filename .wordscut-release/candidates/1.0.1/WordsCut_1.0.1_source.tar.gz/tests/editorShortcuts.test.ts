import { beforeEach, describe, expect, it } from "vitest";
import {
  defaultEditorShortcuts,
  EDITOR_SHORTCUT_DEFS,
  editorShortcutProblem,
  findEditorConflict,
  matchEditorShortcut,
  matchReviewShortcut,
  editorDefsIn,
} from "@/lib/editorShortcuts";
import { defaultSettings, sanitizeSettings } from "@/lib/settings";
import {
  acceleratorFromEvent,
  defaultShortcuts,
  normalizeAccelerator,
  SHORTCUT_DEFS,
} from "@/lib/shortcuts";
import { useSettingsStore } from "@/stores/settingsStore";

const key = (
  code: string,
  mods: Partial<Record<"meta" | "ctrl" | "alt" | "shift", boolean>> = {},
) => ({
  code,
  metaKey: !!mods.meta,
  ctrlKey: !!mods.ctrl,
  altKey: !!mods.alt,
  shiftKey: !!mods.shift,
});

describe("editor shortcut registry", () => {
  it("has canonical defaults, unique within each scope, that never touch a recorder default", () => {
    const map = defaultEditorShortcuts();
    for (const scope of ["editor", "review"] as const) {
      const values = editorDefsIn(scope).map((d) => map[d.action]);
      for (const v of values) expect(normalizeAccelerator(v)).toBe(v);
      expect(new Set(values).size).toBe(values.length);
      for (const v of Object.values(defaultShortcuts())) expect(values).not.toContain(v);
    }
  });

  it("voice-over defaults: Cmd+Option+V in the editor, plain keys only inside the review", () => {
    const m = defaultEditorShortcuts();
    expect(m.voiceOver).toBe("CmdOrCtrl+Alt+V");
    expect(editorShortcutProblem(m.voiceOver)).toBeNull();
    expect(editorDefsIn("review").map((d) => [d.action, m[d.action]])).toEqual([
      ["voKeep", "Enter"],
      ["voMode", "M"],
      ["voOverride", "O"],
      ["voAudition", "Space"],
      ["voRetake", "R"],
      ["voDiscard", "D"],
    ]);
    // O and Space mean Set Out / Play in the editor and the review keys in the dialog.
    expect(matchEditorShortcut(m, key("KeyO"), true)?.action).toBe("markOut");
    expect(matchReviewShortcut(m, key("KeyO"), true)).toBe("voOverride");
    expect(matchReviewShortcut(m, key("Space"), true)).toBe("voAudition");
    expect(matchReviewShortcut(m, key("Enter"), true)).toBe("voKeep");
    expect(matchEditorShortcut(m, key("KeyV", { meta: true, alt: true }), true)?.action).toBe(
      "voiceOver",
    );
    expect(matchReviewShortcut(m, key("KeyV", { meta: true, alt: true }), true)).toBeNull();
    // Conflicts are per scope: O is free for a review action only against review keys.
    const r = defaultShortcuts();
    expect(findEditorConflict(m, r, SHORTCUT_DEFS, "voKeep", "O")).toBe(
      "Override existing narration on / off",
    );
    expect(findEditorConflict(m, r, SHORTCUT_DEFS, "voKeep", "I")).toBeNull();
    expect(findEditorConflict(m, r, SHORTCUT_DEFS, "markIn", "D")).toBeNull();
    expect(findEditorConflict(m, r, SHORTCUT_DEFS, "voKeep", "alt+cmd+r")).toBe(
      "Start / stop recording",
    );
  });

  it("stored review keys survive sanitising even when they equal editor keys", () => {
    const s = sanitizeSettings({ editorShortcuts: { voDiscard: "X", voKeep: "Enter" } });
    expect(s.editorShortcuts.voDiscard).toBe("X"); // X also clears the selection in the editor
    const clash = sanitizeSettings({ editorShortcuts: { voDiscard: "R" } });
    expect(clash.editorShortcuts.voDiscard).toBe("D"); // R is the retake key: default kept
  });

  it("keeps today's bindings", () => {
    const m = defaultEditorShortcuts();
    expect(m).toMatchObject({
      playPause: "Space",
      rewind: "J",
      pause: "K",
      forward: "L",
      markIn: "I",
      markOut: "O",
      addChapter: "B",
      clearSelection: "X",
      extractRange: "CmdOrCtrl+Shift+X",
      deleteWords: "Backspace",
      deleteWordsAlt: "Delete",
      undo: "CmdOrCtrl+Z",
      redo: "CmdOrCtrl+Shift+Z",
      save: "CmdOrCtrl+S",
      export: "CmdOrCtrl+E",
    });
  });

  it("matches events exactly, with the platform command key as CmdOrCtrl", () => {
    const m = defaultEditorShortcuts();
    expect(matchEditorShortcut(m, key("KeyZ", { meta: true }), true)?.action).toBe("undo");
    expect(matchEditorShortcut(m, key("KeyZ", { meta: true, shift: true }), true)?.action).toBe(
      "redo",
    );
    expect(matchEditorShortcut(m, key("KeyZ", { ctrl: true }), false)?.action).toBe("undo");
    expect(matchEditorShortcut(m, key("KeyZ", { ctrl: true }), true)).toBeNull();
    expect(matchEditorShortcut(m, key("KeyZ"), true)).toBeNull();
    expect(matchEditorShortcut(m, key("Space"), true)?.action).toBe("playPause");
    expect(matchEditorShortcut(m, key("Delete", { meta: true }), true)?.action).toBe(
      "deleteRangeAlt",
    );
  });

  it("treats Shift+rewind as slow rewind, unless Shift+key is bound", () => {
    const m = defaultEditorShortcuts();
    expect(matchEditorShortcut(m, key("KeyJ", { shift: true }), true)).toEqual({
      action: "rewind",
      slow: true,
    });
    expect(matchEditorShortcut(m, key("KeyK", { shift: true }), true)).toBeNull();
  });

  it("allows plain keys but refuses macOS-reserved combinations that aren't our defaults", () => {
    expect(editorShortcutProblem("P")).toBeNull();
    expect(editorShortcutProblem("CmdOrCtrl+S")).toBeNull();
    expect(editorShortcutProblem("CmdOrCtrl+Q")).toBe("reserved");
    expect(editorShortcutProblem("garbage++")).toBe("invalid");
  });

  it("reports conflicts with other editor actions and with recorder shortcuts", () => {
    const e = defaultEditorShortcuts();
    const r = defaultShortcuts();
    expect(findEditorConflict(e, r, SHORTCUT_DEFS, "markIn", "O")).toBe("Set Out");
    expect(findEditorConflict(e, r, SHORTCUT_DEFS, "markIn", "i")).toBeNull();
    expect(findEditorConflict(e, r, SHORTCUT_DEFS, "markIn", "alt+cmd+r")).toBe(
      "Start / stop recording",
    );
  });

  it("covers every action exactly once", () => {
    const actions = EDITOR_SHORTCUT_DEFS.map((d) => d.action);
    expect(new Set(actions).size).toBe(actions.length);
    expect(actions).toHaveLength(24);
  });
});

describe("editor shortcut settings", () => {
  beforeEach(() => {
    useSettingsStore.setState(defaultSettings());
  });

  it("sanitizes stored editor shortcuts, falling back to defaults", () => {
    const s = sanitizeSettings({
      editorShortcuts: { markIn: "p", markOut: "garbage++", undo: "cmd+q", save: "p" },
    });
    expect(s.editorShortcuts.markIn).toBe("P");
    expect(s.editorShortcuts.markOut).toBe("O");
    expect(s.editorShortcuts.undo).toBe("CmdOrCtrl+Z");
    expect(s.editorShortcuts.save).toBe("CmdOrCtrl+S"); // "P" already taken by markIn
  });

  it("falls back to defaults for old settings without editor shortcuts", () => {
    expect(sanitizeSettings({ shortcuts: {} }).editorShortcuts).toEqual(defaultEditorShortcuts());
  });

  it("restores editor defaults when a stored editor key clashes with a recorder key", () => {
    const s = sanitizeSettings({
      shortcuts: { record: "cmd+shift+x" },
      editorShortcuts: { markIn: "q" },
    });
    expect(s.editorShortcuts).toEqual(defaultEditorShortcuts());
  });

  it("rebinds, rejects conflicts, and resets", () => {
    const st = () => useSettingsStore.getState();
    expect(st().setEditorShortcut("markIn", "P")).toEqual({ ok: true });
    expect(st().editorShortcuts.markIn).toBe("P");
    const clash = st().setEditorShortcut("markOut", "P");
    expect(clash).toEqual({ ok: false, reason: 'Already used by "Set In".' });
    expect(st().setEditorShortcut("markOut", "CmdOrCtrl+Q").ok).toBe(false);

    st().setEditorShortcut("markOut", "I"); // free now that markIn moved
    st().resetEditorShortcut("markIn"); // default I is held by markOut: handed back
    expect(st().editorShortcuts.markIn).toBe("I");
    expect(st().editorShortcuts.markOut).toBe("O");

    st().setEditorShortcut("markIn", "P");
    st().resetEditorShortcuts();
    expect(st().editorShortcuts).toEqual(defaultEditorShortcuts());
  });

  it("refuses a recorder shortcut that equals an editor hotkey", () => {
    const r = useSettingsStore.getState().setShortcut("record", "CmdOrCtrl+Shift+X");
    expect(r).toEqual({ ok: false, reason: 'Already used by "Extract marked range".' });
  });
});

describe("layout-aware letter matching", () => {
  it("matches on e.key, so AZERTY Cmd+Z (code KeyW) is undo", () => {
    const hit = matchEditorShortcut(
      defaultEditorShortcuts(),
      { ...key("KeyW", { meta: true }), key: "z" },
      true,
    );
    expect(hit?.action).toBe("undo");
    const upper = matchEditorShortcut(
      defaultEditorShortcuts(),
      { ...key("KeyW", { meta: true, shift: true }), key: "Z" },
      true,
    );
    expect(upper?.action).toBe("redo");
  });

  it("falls back to code for non-printable keys and Option-mangled characters", () => {
    const map = defaultEditorShortcuts();
    expect(matchEditorShortcut(map, { ...key("Space"), key: " " }, true)?.action).toBe("playPause");
    expect(matchEditorShortcut(map, { ...key("Backspace"), key: "Backspace" }, true)?.action).toBe(
      "deleteWords",
    );
    expect(acceleratorFromEvent({ ...key("KeyR", { alt: true }), key: "®" })).toBe("Alt+R");
  });
});
