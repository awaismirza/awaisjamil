import { describe, expect, it, vi } from "vitest";
import { normalizeSaveDestination, SaveQueue } from "@/lib/saveQueue";

function deferred() {
  let resolve!: () => void;
  let reject!: (error: unknown) => void;
  const promise = new Promise<void>((yes, no) => { resolve = yes; reject = no; });
  return { promise, resolve, reject };
}

describe("save queue", () => {
  it("serializes normalized destinations and explicitly supersedes waiting snapshots", async () => {
    const firstWrite = deferred();
    const lastWrite = deferred();
    const write = vi.fn().mockImplementationOnce(() => firstWrite.promise)
      .mockImplementationOnce(() => lastWrite.promise);
    const queue = new SaveQueue<number>(write);
    const first = queue.enqueue("/projects/./a.scribe/", 1);
    const second = queue.enqueue("/projects/a.scribe", 2);
    const third = queue.enqueue("/projects/tmp/../a.scribe", 3);
    expect(await second).toEqual({ status: "superseded", destination: "/projects/a.scribe", snapshot: 2 });
    expect(write).toHaveBeenCalledTimes(1);
    firstWrite.resolve();
    expect((await first).status).toBe("saved");
    expect(write.mock.calls).toEqual([[1, "/projects/a.scribe"], [3, "/projects/a.scribe"]]);
    lastWrite.resolve();
    expect(await third).toEqual({ status: "saved", destination: "/projects/a.scribe", snapshot: 3 });
  });

  it("allows distinct destinations to save concurrently", async () => {
    const writes = [deferred(), deferred()];
    const write = vi.fn().mockImplementationOnce(() => writes[0]!.promise)
      .mockImplementationOnce(() => writes[1]!.promise);
    const queue = new SaveQueue<number>(write);
    const a = queue.enqueue("/a", 1);
    const b = queue.enqueue("/b", 2);
    expect(write).toHaveBeenCalledTimes(2);
    writes.forEach((pending) => pending.resolve());
    expect((await a).status).toBe("saved");
    expect((await b).status).toBe("saved");
  });

  it("rejects the failed snapshot and continues its waiting save", async () => {
    const pending = deferred();
    const write = vi.fn().mockImplementationOnce(() => pending.promise).mockResolvedValue(undefined);
    const queue = new SaveQueue<number>(write);
    const first = queue.enqueue("/a", 1);
    const failure = expect(first).rejects.toThrow("disk full");
    const next = queue.enqueue("/a", 2);
    pending.reject(new Error("disk full"));
    await failure;
    expect((await next).status).toBe("saved");
    expect((await queue.enqueue("/a", 3)).snapshot).toBe(3);
    expect(write).toHaveBeenCalledTimes(3);
  });

  it("recovers from synchronous writer errors and isolates timing callback failures", async () => {
    let clock = 10;
    const timing = vi.fn(() => { throw new Error("diagnostics unavailable"); });
    const write = vi.fn().mockImplementationOnce(() => { clock = 25; throw new Error("write failed"); })
      .mockImplementationOnce(async () => { clock = 40; });
    const queue = new SaveQueue<number>(write, timing, () => clock);
    await expect(queue.enqueue("/a", 1)).rejects.toThrow("write failed");
    expect((await queue.enqueue("/a", 2)).status).toBe("saved");
    expect(timing.mock.calls).toEqual([
      [{ destination: "/a", durationMs: 15, succeeded: false }],
      [{ destination: "/a", durationMs: 15, succeeded: true }],
    ]);
  });

  it("normalizes parent segments without traversing above root", () => {
    expect(normalizeSaveDestination("/../../a//./b/../")).toBe("/a");
    expect(normalizeSaveDestination("../a/../b")).toBe("../b");
    expect(() => normalizeSaveDestination("")).toThrow();
    expect(() => normalizeSaveDestination("a\0b")).toThrow();
  });
});
