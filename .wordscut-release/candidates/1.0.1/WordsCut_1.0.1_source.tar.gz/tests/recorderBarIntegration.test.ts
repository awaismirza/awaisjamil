import { beforeEach, describe, expect, it, vi } from "vitest";
import { defaultSettings } from "@/lib/settings";
import { idleSnapshot, runRecorderAction, useRecordingStore } from "@/stores/recordingStore";
import { useSettingsStore } from "@/stores/settingsStore";
import { openRecorderBar, listRecordingDevices } from "@/lib/ipc";

const handlers = new Map<string, (e: { payload: unknown }) => void>();
const emitTo = vi.fn(async () => {});
vi.mock("@tauri-apps/api/event", () => ({
  emitTo: (...a: unknown[]) => (emitTo as (...x: unknown[]) => Promise<void>)(...a),
  emit: vi.fn(async () => {}),
  listen: vi.fn(async (name: string, cb: (e: { payload: unknown }) => void) => {
    handlers.set(name, cb);
    return () => handlers.delete(name);
  }),
}));
const win = {
  unminimize: vi.fn(async () => {}),
  show: vi.fn(async () => {}),
  setFocus: vi.fn(async () => {}),
  isVisible: vi.fn(async () => false),
};
vi.mock("@tauri-apps/api/window", () => ({ getCurrentWindow: () => win }));
vi.mock("@/lib/ipc", async (original) => ({
  ...(await original<typeof import("@/lib/ipc")>()),
  openRecorderBar: vi.fn(async () => {}),
  listRecordingDevices: vi.fn(async () => ({ backend: "native", video: [], audio: [] })),
  getRecordingSnapshot: vi.fn(async () => idleSnapshot(0)),
  pendingRecordingResults: vi.fn(async () => []),
  onRecordSnapshot: vi.fn(async () => () => {}),
  onRecordFinished: vi.fn(async () => () => {}),
  onTrayAction: vi.fn(async () => () => {}),
  updateTray: vi.fn(async () => {}),
  onRecorderBarVisibility: vi.fn(async (cb: (v: boolean) => void) => {
    handlers.set("visibility", (e) => cb(e.payload as boolean));
    return () => {};
  }),
}));
vi.mock("@tauri-apps/plugin-global-shortcut", () => ({
  register: vi.fn(async () => {}),
  unregister: vi.fn(async () => {}),
}));

beforeEach(() => {
  handlers.clear();
  emitTo.mockClear();
  vi.mocked(openRecorderBar).mockReset().mockResolvedValue(undefined);
  vi.mocked(listRecordingDevices).mockClear();
  Object.values(win).forEach((f) => f.mockClear());
  window.localStorage.clear();
  (window as unknown as Record<string, unknown>).__TAURI_INTERNALS__ = {};
  useSettingsStore.setState(defaultSettings());
  useRecordingStore.setState({
    phase: "idle",
    session: idleSnapshot(),
    sessionId: null,
    revision: 0,
    local: null,
    dialogOpen: false,
    barOpen: false,
  });
});

describe("recorder bar routing", () => {
  it("opens the bar by default in Tauri", () => {
    useRecordingStore.getState().openDialog();
    expect(openRecorderBar).toHaveBeenCalledOnce();
    expect(useRecordingStore.getState().dialogOpen).toBe(false);
  });

  it("opens the dialog when the style is dialog", () => {
    useSettingsStore.getState().setRecording({ setupStyle: "dialog" });
    useRecordingStore.getState().openDialog();
    expect(openRecorderBar).not.toHaveBeenCalled();
    expect(useRecordingStore.getState().dialogOpen).toBe(true);
  });

  it("falls back to the dialog when the bar fails to open", async () => {
    vi.mocked(openRecorderBar).mockRejectedValue("nope");
    useRecordingStore.getState().openDialog();
    await vi.waitFor(() => expect(useRecordingStore.getState().dialogOpen).toBe(true));
  });

  it("uses the dialog outside Tauri", () => {
    delete (window as unknown as Record<string, unknown>).__TAURI_INTERNALS__;
    useRecordingStore.getState().openDialog();
    expect(openRecorderBar).not.toHaveBeenCalled();
    expect(useRecordingStore.getState().dialogOpen).toBe(true);
  });

  it("openSetupDialog always opens the dialog", () => {
    useRecordingStore.getState().openSetupDialog();
    expect(useRecordingStore.getState().dialogOpen).toBe(true);
  });
});

describe("recorder bar events", () => {
  it("applies bar options without re-persisting them", async () => {
    const { initRecorder } = await import("@/stores/recordingStore");
    const dispose = await initRecorder();
    const opts = { mode: "screen-camera", fps: 60, pipCorner: "top-left", pipSize: "small" };
    handlers.get("recorder-bar:opts")!({ payload: opts });
    expect(useRecordingStore.getState().opts).toEqual(opts);
    expect(window.localStorage.getItem("yusafcut.recorderOptions")).toBeNull();
    handlers.get("visibility")!({ payload: true });
    expect(useRecordingStore.getState().barOpen).toBe(true);
    handlers.get("recorder:open-dialog")!({ payload: null });
    expect(useRecordingStore.getState().dialogOpen).toBe(true);
    dispose();
  });

  it("forwards the record shortcut to the bar while it is open", () => {
    useRecordingStore.setState({ barOpen: true });
    runRecorderAction("record");
    expect(emitTo).toHaveBeenCalledWith("recorder-bar", "recorder-bar:record", null);
    expect(useRecordingStore.getState().dialogOpen).toBe(false);
  });

  it("restores the main window with show() when a take ends", async () => {
    const { handleSnapshot } = await import("@/stores/recordingStore");
    handleSnapshot({ ...idleSnapshot(1), phase: "recording", mode: "voiceover" });
    handleSnapshot(idleSnapshot(2));
    await vi.waitFor(() => expect(win.show).toHaveBeenCalled());
    expect(win.unminimize).toHaveBeenCalled();
  });
});

describe("settings sync across windows", () => {
  it("reloads the editor copy when another window changes settings", () => {
    const next = defaultSettings();
    next.recording.countdownSec = 10;
    next.recording.autoTranscribe = false;
    window.localStorage.setItem("yusafcut.settings", JSON.stringify(next));
    window.dispatchEvent(new StorageEvent("storage", { key: "yusafcut.settings" }));
    expect(useSettingsStore.getState().recording.countdownSec).toBe(10);
    expect(useSettingsStore.getState().recording.autoTranscribe).toBe(false);
  });

  it("sanitizes setupStyle", async () => {
    const { sanitizeSettings } = await import("@/lib/settings");
    expect(sanitizeSettings({ recording: { setupStyle: "dialog" } }).recording.setupStyle).toBe(
      "dialog",
    );
    expect(sanitizeSettings({ recording: { setupStyle: "x" } }).recording.setupStyle).toBe("bar");
  });
});
