import { describe, expect, it } from "vitest";
import fixture from "./fixtures/native-engine-timing.json";
import {
  fixtureProject,
  generateNativeEngineTimingFixture,
} from "./fixtures/nativeEngineTiming.gen";
import { newProject, totalDuration, type AudioTrack, type Project } from "@/lib/edl";
import {
  chooseEngine,
  compileRenderPlan,
  frameCounts,
  frameTicks,
  GenerationGate,
  planDurationTicks,
  planLayout,
  rationalFps,
  REQUIRE_ORDER,
  TICKS_PER_SECOND,
  unsupportedFeatures,
  type NativeEngineCapabilities,
  type RenderPlan,
} from "@/lib/nativeEngine";

const CAPS: NativeEngineCapabilities = {
  available: true,
  reason: null,
  planVersion: 1,
  levels: ["probe"],
};

function plainProject(): Project {
  return fixtureProject([{ mediaId: "m1", sourceIn: 0, sourceOut: 2 }]);
}

function bed(over: Partial<AudioTrack> = {}): AudioTrack {
  return { id: "t1", mediaId: "m2", gainDb: -6, offsetSec: 1, ducks: false, ...over };
}

describe("native engine timing parity fixture", () => {
  it("is exactly what the generator produces (regenerate with WRITE_PARITY=1)", () => {
    expect(JSON.parse(JSON.stringify(generateNativeEngineTimingFixture()))).toEqual(fixture);
  });

  for (const c of fixture.cases) {
    describe(c.name, () => {
      const project = fixtureProject(c.segments as Parameters<typeof fixtureProject>[0]);
      const plan = c.plan as RenderPlan;
      const ft = frameTicks(plan.fps)!;

      it("matches the EDL output length from src/lib/edl.ts", () => {
        expect(totalDuration(project)).toBeCloseTo(c.expected.edlDuration, 12);
      });

      it("compiles one clip per segment with the EDL's ranges, speed and hold", () => {
        expect(plan.clips).toHaveLength(project.segments.length);
        plan.clips.forEach((cl, i) => {
          const seg = project.segments[i]!;
          expect(cl.sourceId).toBe(seg.mediaId);
          expect(cl.sourceIn).toBe(seg.sourceIn);
          expect(cl.sourceOut).toBe(seg.sourceOut);
          expect(cl.speed ?? 1).toBe(seg.speed ?? 1);
          expect(cl.holdSec ?? 0).toBe(seg.holdSec ?? 0);
        });
      });

      it("quantised: whole frames, within half a frame of the EDL", () => {
        const ticks = planDurationTicks(plan);
        expect(ticks).toBe(c.expected.quantizedTicks);
        expect(ticks % ft).toBe(0);
        expect(Math.abs(ticks / TICKS_PER_SECOND - c.expected.edlDuration)).toBeLessThanOrEqual(
          0.5 / 30 + 1e-9,
        );
        const sum = c.expected.frames.reduce((a, b) => a + b, 0);
        expect(sum * ft).toBe(ticks);
      });

      it("unquantised: within one tick per clip of the EDL", () => {
        const ticks = planDurationTicks({ ...plan, quantize: false });
        expect(ticks).toBe(c.expected.unquantizedTicks);
        expect(Math.abs(ticks - c.expected.edlDuration * TICKS_PER_SECOND)).toBeLessThanOrEqual(
          plan.clips.length * 2,
        );
      });

      it("running output never drifts more than half a frame (quantised)", () => {
        let edl = 0;
        const layout = planLayout(plan);
        for (const t of layout) {
          const cl = plan.clips[t.clipIndex]!;
          edl += (cl.sourceOut - cl.sourceIn) / (cl.speed ?? 1) + (cl.holdSec ?? 0);
          const out = (t.outputStart + t.play + t.hold) / TICKS_PER_SECOND;
          expect(Math.abs(out - edl)).toBeLessThanOrEqual(0.5 / 30 + 1e-9);
        }
      });
    });
  }
});

describe("frameCounts (mirror of export_plan.rs)", () => {
  it("keeps whole-frame ranges and spreads sub-frame ones", () => {
    expect(frameCounts([2 / 30, 0.066667, 10], 30)).toEqual([2, 2, 300]);
    const n = frameCounts(Array(200).fill(0.04), 30);
    expect(n.reduce((a, b) => a + b, 0)).toBe(240);
  });
  it("never makes a non-empty list all zero", () => {
    expect(frameCounts([0.01], 30)).toEqual([1]);
    expect(frameCounts([0], 30)).toEqual([0]);
    expect(frameCounts([Number.NaN, -1], 30)).toEqual([0, 0]);
  });
});

describe("rationalFps / frameTicks", () => {
  it("maps NTSC rates to x000/1001 and integers to n/1", () => {
    expect(rationalFps(29.97)).toEqual({ num: 30000, den: 1001 });
    expect(rationalFps(23.976)).toEqual({ num: 24000, den: 1001 });
    expect(rationalFps(59.94)).toEqual({ num: 60000, den: 1001 });
    expect(rationalFps(30)).toEqual({ num: 30, den: 1 });
    expect(rationalFps(25)).toEqual({ num: 25, den: 1 });
    expect(rationalFps(0)).toEqual({ num: 30, den: 1 });
  });
  it("whole ticks per frame for common rates, null otherwise", () => {
    expect(frameTicks({ num: 30000, den: 1001 })).toBe(3003);
    expect(frameTicks({ num: 24, den: 1 })).toBe(3750);
    expect(frameTicks({ num: 7, den: 1 })).toBeNull();
  });
});

describe("compileRenderPlan", () => {
  it("drops empty segments, keeps mute, and carries the generation", () => {
    const p = plainProject();
    p.segments.push({ ...p.segments[0]!, id: "z", sourceIn: 1, sourceOut: 1 });
    p.segments.push({ ...p.segments[0]!, id: "m", muted: true });
    const plan = compileRenderPlan(p, { generation: 7 });
    expect(plan.generation).toBe(7);
    expect(plan.clips).toHaveLength(2);
    expect(plan.clips[1]!.muted).toBe(true);
    expect(plan.requires).toBeUndefined();
    expect(plan.sources.map((s) => s.id)).toEqual(["m1"]);
  });

  it("resolves mute / solo for beds and keeps voice-over out of them", () => {
    const p = plainProject();
    p.audioTracks = [
      bed({ id: "a", mediaId: "m2" }),
      bed({ id: "b", mediaId: "m3", muted: true }),
      { ...bed({ id: "v", mediaId: "m3" }), kind: "voiceover", mode: "overlay" },
    ];
    const plan = compileRenderPlan(p);
    expect(plan.audioBeds).toEqual([{ sourceId: "m2", offsetSec: 1, gainDb: -6 }]);
    expect(plan.requires).toEqual(["voice-over"]);
    p.audioTracks[1]!.solo = true;
    expect(compileRenderPlan(p).audioBeds).toEqual([{ sourceId: "m3", offsetSec: 1, gainDb: -6 }]);
  });

  it("reports every unsupported feature in REQUIRE_ORDER", () => {
    const p = plainProject();
    p.segments.push({
      ...p.segments[0]!,
      id: "b",
      transitionIn: { kind: "crossfade", duration: 0.5 },
    });
    p.zoomRegions = [{ id: "z" } as never];
    p.cursor = { style: { show: true }, tracks: { m1: { points: [] } } } as never;
    p.scene = { enabled: true, frame: {}, crop: {} } as never;
    p.annotations = [{} as never];
    p.keystrokes = { enabled: true, mode: "shortcuts" };
    p.overlays = [{} as never];
    p.masks = [{} as never];
    p.audioTracks = [
      { ...bed({ id: "v" }), kind: "voiceover" },
      bed({ id: "d", ducks: true, fadeInSec: 1 }),
    ];
    expect(unsupportedFeatures(p, { burnCaptions: true })).toEqual([...REQUIRE_ORDER]);
  });

  it("ignores a disabled scene, hidden cursor and an unused cursor track", () => {
    const p = plainProject();
    p.scene = { enabled: false, frame: {}, crop: {} } as never;
    p.cursor = { style: { show: true }, tracks: { other: { points: [] } } } as never;
    expect(unsupportedFeatures(p)).toEqual([]);
  });

  it("an empty project compiles to an empty plan the choice refuses", () => {
    const plan = compileRenderPlan(newProject("x"));
    expect(plan.clips).toEqual([]);
    expect(
      chooseEngine(plan, CAPS, { settings: { enabled: true }, operation: "probe" }).reason,
    ).toBe("plan-empty");
  });
});

describe("chooseEngine", () => {
  const plan = compileRenderPlan(plainProject());

  it("is fallback by default, whatever the helper can do", () => {
    expect(chooseEngine(plan, CAPS)).toEqual({ engine: "fallback", reason: "disabled-by-setting" });
    expect(chooseEngine(plan, { ...CAPS, levels: ["probe", "preview", "export"] })).toEqual({
      engine: "fallback",
      reason: "disabled-by-setting",
    });
  });

  it("falls back with the helper's own reason when it is missing or unable", () => {
    const on = { settings: { enabled: true }, operation: "probe" as const };
    expect(chooseEngine(plan, null, on).reason).toBe("helper-missing");
    expect(chooseEngine(plan, { available: false, reason: "helper-missing" }, on).reason).toBe(
      "helper-missing",
    );
    expect(chooseEngine(plan, { available: false, reason: "not-apple-silicon" }, on).reason).toBe(
      "not-apple-silicon",
    );
    expect(chooseEngine(plan, { ...CAPS, planVersion: 2 }, on).reason).toBe(
      "plan-version-unsupported",
    );
  });

  it("routes the first unsupported feature to fallback", () => {
    const on = { settings: { enabled: true }, operation: "probe" as const };
    expect(chooseEngine({ ...plan, requires: ["zoom", "captions"] }, CAPS, on).reason).toBe("zoom");
    expect(chooseEngine({ ...plan, requires: ["hologram"] }, CAPS, on).reason).toBe(
      "unknown-feature",
    );
    const cropped = {
      ...plan,
      sources: [{ ...plan.sources[0]!, crop: { x: 0, y: 0, width: 1, height: 1 } }],
    };
    expect(chooseEngine(cropped, CAPS, on).reason).toBe("crop");
  });

  it("needs the helper to implement the requested level", () => {
    const on = { settings: { enabled: true } };
    expect(chooseEngine(plan, CAPS, on).reason).toBe("level-unavailable");
    expect(chooseEngine(plan, CAPS, { ...on, operation: "export" }).reason).toBe(
      "level-unavailable",
    );
    expect(chooseEngine(plan, CAPS, { ...on, operation: "probe" })).toEqual({
      engine: "native",
      reason: null,
    });
  });
});

describe("GenerationGate", () => {
  it("only the latest request is current; invalidate drops everything", () => {
    const g = new GenerationGate();
    const a = g.next();
    const b = g.next();
    expect(g.isCurrent(a)).toBe(false);
    expect(g.isCurrent(b)).toBe(true);
    g.invalidate();
    expect(g.isCurrent(b)).toBe(false);
    expect(g.isCurrent(undefined)).toBe(false);
  });
});
