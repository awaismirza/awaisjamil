import { beforeEach, describe, expect, it } from "vitest";
import fixture from "./fixtures/timingProject.json";
import hostile from "./fixtures/hostileTiming.json";
import {
  addChapter,
  computeTimeline,
  deleteWords,
  entryOutputAt,
  entryPlayEnd,
  entrySourceAt,
  hasTimingEffects,
  keepOutputRange,
  newProject,
  outputTimeToSource,
  segmentHold,
  segmentSpeed,
  setSegmentTiming,
  sourceTimeToOutput,
  totalDuration,
  transitionHalf,
  wordIdToOutputTime,
  type Project,
  type Segment,
} from "@/lib/edl";
import { getTimelineIndex, indexedSource, playbackPosition } from "@/lib/timelineIndex";
import { splitClipAt } from "@/lib/clipEdit";
import { flattenWordsInOutputTime } from "@/lib/captions";
import { timingMarks } from "@/lib/cuts";
import { buildFcpxml } from "@/lib/fcpxml";
import { useProjectStore } from "@/stores/projectStore";

const fx = fixture as unknown as { project: Project; expected: Record<string, number[] | number> };

function word(id: string, start: number, end: number) {
  return { id, text: id, start, end, confidence: 1 };
}

function project(segments: Segment[]): Project {
  return {
    ...newProject("t"),
    media: {
      m: {
        id: "m",
        path: "/tmp/m.mp4",
        duration: 100,
        fps: 30,
        width: 1280,
        height: 720,
        audioSampleRate: 48000,
        sha256: "x",
      },
    },
    segments,
  };
}

/** Deterministic PRNG so failures reproduce. */
function rng(seed: number) {
  return () => {
    seed = (seed * 1664525 + 1013904223) % 4294967296;
    return seed / 4294967296;
  };
}

function randomProject(rand: () => number): Project {
  const segs: Segment[] = [];
  let src = 0;
  const n = 1 + Math.floor(rand() * 6);
  for (let i = 0; i < n; i++) {
    src += rand() * 2;
    const len = 0.1 + rand() * 4;
    const s: Segment = {
      id: `s${i}`,
      mediaId: "m",
      words: [],
      sourceIn: src,
      sourceOut: src + len,
    };
    if (rand() < 0.6) s.speed = [0.25, 0.5, 0.75, 1.5, 2, 3, 4][Math.floor(rand() * 7)];
    if (rand() < 0.4) s.holdSec = rand() * 3;
    if (i > 0 && rand() < 0.4)
      s.transitionIn = { kind: rand() < 0.5 ? "dip" : "crossfade", duration: rand() * 2 };
    segs.push(s);
    src += len;
  }
  return project(segs);
}

describe("speed / hold time mapping", () => {
  it("matches the shared fixture (the Rust test reads the same file)", () => {
    const p = fx.project;
    expect(totalDuration(p)).toBe(fx.expected.outputDuration);
    expect(computeTimeline(p).map((e) => e.outputEnd)).toEqual(fx.expected.outputEnds);
    expect(p.segments.map((_, i) => transitionHalf(p.segments, i))).toEqual(
      fx.expected.transitionHalves,
    );
  });

  it("leaves old projects' timeline entries exactly as before", () => {
    const p = project([{ id: "a", mediaId: "m", words: [], sourceIn: 1, sourceOut: 3 }]);
    expect(computeTimeline(p)).toEqual([
      { segmentId: "a", mediaId: "m", sourceIn: 1, sourceOut: 3, outputStart: 0, outputEnd: 2 },
    ]);
  });

  it("maps footage at speed and a hold onto the last frame", () => {
    const p = fx.project; // a: 0-2 @2x -> 0-1; b: 3-5 @0.5x -> 1-5, hold 5-6
    expect(outputTimeToSource(p, 0.5)?.sourceTime).toBe(1);
    expect(outputTimeToSource(p, 3)?.sourceTime).toBe(4);
    expect(outputTimeToSource(p, 5.5)?.sourceTime).toBe(5);
    expect(sourceTimeToOutput(p, "m", 4)?.outputTime).toBe(3);
    expect(wordIdToOutputTime(p, "w1")?.outputTime).toBe(2);
    const index = getTimelineIndex(p.segments);
    expect(indexedSource(index, 5.5)?.sourceTime).toBe(5);
    // Footage ends at 5.0 (hold start), not at the entry's end.
    expect(playbackPosition(index, 1, 5)).toMatchObject({ ended: true, outputTime: 5 });
    expect(playbackPosition(index, 1, 4)).toMatchObject({ ended: false, outputTime: 3 });
  });

  it("holds random invariants: monotonic, round-trips, index agrees with timeline", () => {
    const rand = rng(42);
    for (let k = 0; k < 300; k++) {
      const p = randomProject(rand);
      const tl = computeTimeline(p);
      const index = getTimelineIndex(p.segments);
      const total = totalDuration(p);
      expect(index.duration).toBeCloseTo(total, 9);
      expect(tl.at(-1)!.outputEnd).toBeCloseTo(total, 9);
      tl.forEach((e, i) => {
        const ie = index.entries[i]!;
        expect([ie.outputStart, ie.outputEnd, ie.speed, ie.holdSec]).toEqual([
          e.outputStart,
          e.outputEnd,
          e.speed,
          e.holdSec,
        ]);
      });
      // Output -> source is monotonic in (clip, source time) as output time grows.
      let last = { clip: -1, src: -Infinity };
      for (let t = 0; t < total; t += total / 97) {
        const m = indexedSource(index, t)!;
        expect(m).not.toBeNull();
        const cur = { clip: m.entry.index, src: m.sourceTime };
        expect(cur.clip > last.clip || (cur.clip === last.clip && cur.src >= last.src)).toBe(true);
        last = cur;
        // Footage round-trips exactly; a hold maps to the end of the footage.
        const back = entryOutputAt(m.entry, m.sourceTime);
        if (t < entryPlayEnd(m.entry)) expect(back).toBeCloseTo(t, 9);
        else expect(back).toBeCloseTo(entryPlayEnd(m.entry), 9);
      }
      // Source -> output -> source round-trips inside every clip.
      for (const e of tl) {
        for (const f of [0.1, 0.5, 0.9]) {
          const s = e.sourceIn + f * (e.sourceOut - e.sourceIn);
          expect(entrySourceAt(e, entryOutputAt(e, s))).toBeCloseTo(s, 9);
        }
      }
      // Transitions are overlap-neutral: never more than half of either neighbour.
      p.segments.forEach((_, i) => {
        const h = transitionHalf(p.segments, i);
        if (i === 0) expect(h).toBe(0);
        expect(h).toBeLessThanOrEqual(tl[i]!.outputEnd - tl[i]!.outputStart);
      });
    }
  });
});

describe("timing edits", () => {
  const base = () =>
    project([
      {
        id: "a",
        mediaId: "m",
        words: [word("w1", 0.2, 0.8), word("w2", 1.2, 1.8), word("w3", 2.2, 2.8)],
        sourceIn: 0,
        sourceOut: 3,
      },
      { id: "b", mediaId: "m", words: [word("w4", 5.2, 5.8)], sourceIn: 5, sourceOut: 7 },
    ]);

  it("clamps, stores defaults as absent and is a no-op when nothing changes", () => {
    const p = base();
    const fast = setSegmentTiming(p, "a", { speed: 100, holdSec: -2, muted: false });
    expect(fast.segments[0]).toMatchObject({ speed: 4 });
    expect("holdSec" in fast.segments[0]! || "muted" in fast.segments[0]!).toBe(false);
    expect(setSegmentTiming(fast, "a", { speed: 4 })).toBe(fast);
    const back = setSegmentTiming(fast, "a", { speed: 1 });
    expect(back.segments[0]).toEqual(p.segments[0]);
    expect(setSegmentTiming(p, "a", { transitionIn: { kind: "dip", duration: 1 } })).toBe(p);
    const t = setSegmentTiming(p, "b", { transitionIn: { kind: "crossfade", duration: 9 } });
    expect(t.segments[1]!.transitionIn).toEqual({ kind: "crossfade", duration: 2 });
    expect(totalDuration(t)).toBe(totalDuration(p)); // overlap-neutral
    expect(setSegmentTiming(t, "b", { transitionIn: null }).segments[1]).toEqual(p.segments[1]);
  });

  it("moves chapters with their content when speed or hold changes the timeline", () => {
    let p = addChapter(base(), 1.5, "middle of a");
    p = addChapter(p, 3.5, "inside b"); // source 5.5
    const sped = setSegmentTiming(p, "a", { speed: 2, holdSec: 1 });
    // 1.5 s of a's source plays at 0.75; b now starts at 1.5 + 1 = 2.5.
    expect(sped.chapters!.map((c) => c.outputTime)).toEqual([0.75, 3]);
    // A chapter inside the hold follows the hold; removing it drops the chapter.
    const inHold = addChapter(sped, 2, "on freeze");
    const longer = setSegmentTiming(inHold, "a", { speed: 1 });
    expect(longer.chapters!.find((c) => c.title === "on freeze")!.outputTime).toBeCloseTo(3.5, 9);
    const gone = setSegmentTiming(inHold, "a", { holdSec: 0 });
    expect(gone.chapters!.some((c) => c.title === "on freeze")).toBe(false);
  });

  it("zoom regions and music offsets follow speed changes through source time", () => {
    const p: Project = {
      ...base(),
      zoomRegions: [
        { id: "z", start: 1.5, end: 3, scale: 2, focusX: 0.5, focusY: 0.5, easeMs: 300 },
      ],
      audioTracks: [{ id: "t", mediaId: "m", gainDb: 0, offsetSec: 4, ducks: false }],
    };
    const sped = setSegmentTiming(p, "a", { speed: 2 });
    expect(sped.zoomRegions!.map((z) => [z.start, z.end])).toEqual([[0.75, 1.5]]);
    expect(sped.audioTracks![0]!.offsetSec).toBe(2.5); // source 6 in b, which now starts at 1.5
  });

  it("deleting words keeps speed on every piece, transition first, hold last", () => {
    let p = setSegmentTiming(base(), "a", { speed: 2, holdSec: 1, muted: true });
    p = setSegmentTiming(p, "b", { transitionIn: { kind: "dip", duration: 0.5 } });
    const next = deleteWords(p, new Set(["w2", "w4"]));
    const [l, r] = next.segments;
    expect([l!.speed, r!.speed, l!.muted, r!.muted]).toEqual([2, 2, true, true]);
    expect([l!.holdSec, r!.holdSec]).toEqual([undefined, 1]);
    expect(next.segments.length).toBe(2); // b had only w4
    const p2 = setSegmentTiming(base(), "b", { transitionIn: { kind: "dip", duration: 0.5 } });
    const split = deleteWords(p2, new Set(["w2"]));
    expect(split.segments.map((s) => !!s.transitionIn)).toEqual([false, false, true]);
  });

  it("split and keep-range respect speed and holds", () => {
    const p = setSegmentTiming(base(), "a", { speed: 2, holdSec: 1 }); // a: 0-1.5 play, 1.5-2.5 hold
    const split = splitClipAt(p, 0.75);
    expect(split.segments.slice(0, 2).map((s) => [s.sourceIn, s.sourceOut, s.holdSec])).toEqual([
      [0, 1.5, undefined],
      [1.5, 3, 1],
    ]);
    expect(totalDuration(split)).toBe(totalDuration(p));
    const kept = keepOutputRange(p, 1, 2);
    expect(kept.segments).toHaveLength(1);
    expect(kept.segments[0]).toMatchObject({ sourceIn: 2, sourceOut: 3, speed: 2, holdSec: 0.5 });
    expect(totalDuration(kept)).toBeCloseTo(1, 9);
    // A range wholly inside the hold keeps one real source frame (30 fps) to
    // freeze, and the hold gives up that frame's time so the length is unchanged.
    const inHold = keepOutputRange(p, 1.8, 2.3);
    expect(inHold.segments).toHaveLength(1);
    const s = inHold.segments[0]!;
    expect(s.sourceOut - s.sourceIn).toBeCloseTo(1 / 30, 9);
    expect(s.holdSec).toBeCloseTo(0.5 - 1 / 60, 9);
    expect(totalDuration(inHold)).toBeCloseTo(0.5, 9);
  });

  it("captions, markers and FCPXML follow the same mapping", () => {
    const p = setSegmentTiming(setSegmentTiming(base(), "a", { speed: 2, holdSec: 1 }), "b", {
      transitionIn: { kind: "crossfade", duration: 0.4 },
    });
    const words = flattenWordsInOutputTime(p);
    expect(words.map((w) => [w.start, w.end])).toEqual([
      [0.1, 0.4],
      [0.6, 0.9],
      [1.1, 1.4],
      [2.7, 3.3],
    ]);
    expect(timingMarks(p).map((m) => [m.kind, m.start, m.end])).toEqual([
      ["speed", 0, 1.5],
      ["hold", 1.5, 2.5],
      ["transition", 2.3, 2.7],
    ]);
    const { unsupported } = buildFcpxml(p);
    expect(unsupported.join("\n")).toMatch(/speed change/);
    expect(unsupported.join("\n")).toMatch(/freeze frame/);
    expect(unsupported.join("\n")).toMatch(/transition/);
  });
});

describe("timing undo / redo", () => {
  beforeEach(() => {
    useProjectStore.setState({ project: project(fx.project.segments.slice(0, 2)), dirty: false });
    useProjectStore.temporal.getState().clear();
  });

  it("each timing change is one undo step", () => {
    const store = useProjectStore.getState();
    const before = useProjectStore.getState().project;
    store.setSegmentTiming("a", { speed: 4 });
    store.setSegmentTiming("b", { holdSec: 3 });
    store.setSegmentTiming("b", { holdSec: 3 }); // no-op: no history entry
    expect(useProjectStore.temporal.getState().pastStates).toHaveLength(2);
    expect(totalDuration(useProjectStore.getState().project)).toBe(0.5 + 4 + 3);
    useProjectStore.temporal.getState().undo();
    expect(useProjectStore.getState().project.segments[1]!.holdSec).toBe(1);
    useProjectStore.temporal.getState().undo();
    expect(useProjectStore.getState().project).toEqual(before);
    useProjectStore.temporal.getState().redo();
    expect(useProjectStore.getState().project.segments[0]!.speed).toBe(4);
  });
});

describe("hostile timing values (shared with edl.rs)", () => {
  // Rust's lenient load turns `raw` into `sanitized`; the frontend only ever sees the latter.
  const raw = hostile.raw as unknown as Segment[];
  const clean = hostile.sanitized as unknown as Segment[];
  it("frontend timing helpers give the same lengths on raw and sanitized clips", () => {
    const total = (segs: Segment[]) => totalDuration({ ...newProject("x"), segments: segs });
    expect(total(raw)).toBe(hostile.outputDuration);
    expect(total(clean)).toBe(hostile.outputDuration);
    raw.forEach((seg, i) => {
      expect(segmentSpeed(seg)).toBe(segmentSpeed(clean[i]!));
      expect(segmentHold(seg)).toBe(segmentHold(clean[i]!));
    });
    expect(clean.map(hasTimingEffects)).toEqual([false, false, true, true]);
    expect(clean.map((_, i) => transitionHalf(clean, i))).toEqual([0, 0, 0, 0]);
  });
});
