import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@/lib/agent/bridgeIpc", () => ({
  agentPathInfo: vi.fn(),
  agentWriteTextFile: vi.fn(),
}));
vi.mock("@/lib/ipc", async (importOriginal) => ({
  ...(await importOriginal<typeof import("@/lib/ipc")>()),
  cancelExport: vi.fn(),
  detectPauses: vi.fn(),
  exportVideo: vi.fn(),
  loadProject: vi.fn(),
}));

import { createLiveContext, resetRevision, stopRevisionTracking } from "@/lib/agent/liveContext";
import { useProjectStore } from "@/stores/projectStore";
import { useRecordingStore } from "@/stores/recordingStore";
import { useUIStore } from "@/stores/uiStore";

function resetStores() {
  useUIStore.setState({
    exportingProgress: null,
    isProcessingEdit: false,
    processingEditLabel: null,
    mediaLoading: false,
    transcribeProgress: null,
  });
  const t = useProjectStore.temporal.getState();
  t.resume();
  t.clear();
}

describe("live context", () => {
  beforeEach(() => {
    resetStores();
    stopRevisionTracking();
    resetRevision();
  });
  afterEach(() => vi.useRealTimers());

  it("applyProject adds one undo state, bumps revision and resolves without rAF", async () => {
    vi.stubGlobal("requestAnimationFrame", () => 0); // never fires
    const ctx = createLiveContext();
    const before = ctx.getProject();
    const next = { ...before, name: "Agent edit" };
    const pastBefore = useProjectStore.temporal.getState().pastStates.length;
    const rev0 = ctx.revision();
    const rev = await ctx.applyProject(next, "rename");
    expect(useProjectStore.temporal.getState().pastStates.length).toBe(pastBefore + 1);
    expect(rev).toBe(rev0 + 1);
    expect(ctx.revision()).toBe(rev);
    expect(ctx.getProject().name).toBe("Agent edit");
    expect(useUIStore.getState().isProcessingEdit).toBe(false);
    vi.unstubAllGlobals();
  });

  it("refuses BUSY while exporting", async () => {
    const ctx = createLiveContext();
    useUIStore.setState({ exportingProgress: 0.3 });
    expect(ctx.busyReason()).not.toBeNull();
    await expect(ctx.applyProject({ ...ctx.getProject(), name: "x" }, "x")).rejects.toMatchObject({
      code: "BUSY",
    });
  });

  it("refuses BUSY while the recorder is not idle", async () => {
    const ctx = createLiveContext();
    useRecordingStore.setState({ phase: "recording" });
    expect(ctx.busyReason()).toMatch(/recorder/i);
    await expect(ctx.applyProject({ ...ctx.getProject(), name: "x" }, "x")).rejects.toMatchObject({
      code: "BUSY",
    });
    useRecordingStore.setState({ phase: "idle" });
    expect(ctx.busyReason()).toBeNull();
  });

  it("undo reverts an applied edit", async () => {
    const ctx = createLiveContext();
    const orig = ctx.getProject().name;
    await ctx.applyProject({ ...ctx.getProject(), name: "Changed" }, "rename");
    ctx.undo(1);
    expect(ctx.getProject().name).toBe(orig);
  });
});
