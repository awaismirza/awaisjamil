import { describe, it, expect } from "vitest";
import { newProject } from "@/lib/edl";
import {
  buildExportOptions,
  describeAudioReport,
  type ExportUiSettings,
} from "@/lib/exportOptions";

const ui: ExportUiSettings = {
  resolution: "original",
  customWidth: 0,
  customHeight: 0,
  codec: "auto",
};

describe("export loudness target", () => {
  it("is absent by default so the request is unchanged", () => {
    const o = buildExportOptions(newProject("p"), ui, "/o/a.mp4");
    expect("loudnessLufs" in o).toBe(false);
  });
  it("is sent when set, but never for GIF", () => {
    const p = newProject("p");
    expect(buildExportOptions(p, { ...ui, loudnessLufs: -16 }, "/o/a.mp4").loudnessLufs).toBe(-16);
    expect(
      "loudnessLufs" in
        buildExportOptions(p, { ...ui, format: "gif", loudnessLufs: -16 }, "/o/a.gif"),
    ).toBe(false);
  });
});

describe("describeAudioReport", () => {
  const none = {
    integratedLufs: null,
    loudnessRangeLu: null,
    truePeakDbtp: null,
    samplePeakDb: null,
    clipped: false,
  };
  it("never throws on null levels from a silent export", () => {
    expect(describeAudioReport({ ...none, integratedLufs: -70, loudnessRangeLu: 0 })).toEqual({
      clipped: false,
      text: "-70.0 LUFS",
    });
    expect(describeAudioReport(none)?.text).toBe("silent");
  });
  it("is null without a report and flags clipping", () => {
    expect(describeAudioReport(null)).toBeNull();
    expect(describeAudioReport(undefined)).toBeNull();
    const r = describeAudioReport({ ...none, integratedLufs: 2.3, samplePeakDb: 0, clipped: true });
    expect(r?.clipped).toBe(true);
    expect(r?.text).toContain("2.3 LUFS");
  });
});
