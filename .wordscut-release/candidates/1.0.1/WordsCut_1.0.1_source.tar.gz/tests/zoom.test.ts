import { describe, expect, it } from "vitest";
import {
  addZoomRegion,
  clampScale,
  clearZoomRange,
  MIN_REGION_SEC,
  normalizeRegions,
  removeZoomRegion,
  retimeZoomRegions,
  sampleZoom,
  sanitizeZoomRegions,
  smooth,
  updateZoomRegion,
  viewWindow,
  ZOOM_MAX_SCALE,
  ZOOM_MIN_SCALE,
  zoomEnvelope,
  type ZoomRegion,
} from "@/lib/zoom";
import type { TimelineEntry } from "@/lib/edl";

const TOTAL = 60;
const R = (id: string, start: number, end: number, extra: Partial<ZoomRegion> = {}): ZoomRegion => ({
  id,
  start,
  end,
  scale: 2,
  focusX: 0.5,
  focusY: 0.5,
  easeMs: 500,
  ...extra,
});

const spans = (rs: ZoomRegion[]) => rs.map((r) => [r.start, r.end]);

describe("clampScale", () => {
  it("keeps scale within the supported range", () => {
    expect(clampScale(0.5)).toBe(ZOOM_MIN_SCALE);
    expect(clampScale(9)).toBe(ZOOM_MAX_SCALE);
    expect(clampScale(2)).toBe(2);
    expect(clampScale(Number.NaN)).toBeGreaterThanOrEqual(ZOOM_MIN_SCALE);
  });
});

describe("normalizeRegions", () => {
  it("sorts and clamps to the timeline", () => {
    const out = normalizeRegions([R("b", 20, 30), R("a", -5, 5)], TOTAL);
    expect(spans(out)).toEqual([[0, 5], [20, 30]]);
  });

  it("shortens a later region that starts inside an earlier one", () => {
    const out = normalizeRegions([R("a", 10, 20), R("b", 15, 30)], TOTAL);
    expect(spans(out)).toEqual([[10, 20], [20, 30]]);
  });

  it("drops regions that end up too short", () => {
    expect(normalizeRegions([R("a", 10, 10.2)], TOTAL)).toEqual([]);
    expect(normalizeRegions([R("a", 10, 20), R("b", 19.9, 20.1)], TOTAL)).toHaveLength(1);
  });
});

describe("sanitizeZoomRegions", () => {
  it("returns nothing for junk", () => {
    expect(sanitizeZoomRegions(undefined, TOTAL)).toEqual([]);
    expect(sanitizeZoomRegions("x", TOTAL)).toEqual([]);
    expect(sanitizeZoomRegions([null, 3, {}, { start: "a", end: 2 }], TOTAL)).toEqual([]);
  });

  it("clamps scale, focus and ease, and fills missing fields", () => {
    const [r] = sanitizeZoomRegions(
      [{ id: "z", start: 1, end: 5, scale: 99, focusX: -3, focusY: 7, easeMs: 99999 }],
      TOTAL,
    );
    expect(r!.scale).toBe(ZOOM_MAX_SCALE);
    expect(r!.focusX).toBe(0);
    expect(r!.focusY).toBe(1);
    expect(r!.easeMs).toBe(2000);
    const [d] = sanitizeZoomRegions([{ start: 1, end: 5 }], TOTAL);
    expect(d!.id.length).toBeGreaterThan(0);
    expect(d!.focusX).toBe(0.5);
  });

  it("repairs overlaps in stored data", () => {
    const out = sanitizeZoomRegions(
      [
        { start: 0, end: 10 },
        { start: 5, end: 15 },
      ],
      TOTAL,
    );
    expect(spans(out)).toEqual([[0, 10], [10, 15]]);
  });
});

describe("addZoomRegion", () => {
  it("adds to an empty list, sorted", () => {
    const out = addZoomRegion([], { start: 10, end: 14 }, TOTAL);
    expect(out).toHaveLength(1);
    expect(out[0]!.scale).toBeGreaterThanOrEqual(ZOOM_MIN_SCALE);
  });

  it("accepts a reversed span", () => {
    expect(spans(addZoomRegion([], { start: 14, end: 10 }, TOTAL))).toEqual([[10, 14]]);
  });

  it("ignores a span that is too short", () => {
    const existing = [R("a", 1, 5)];
    expect(addZoomRegion(existing, { start: 10, end: 10 + MIN_REGION_SEC / 2 }, TOTAL)).toEqual(existing);
  });

  it("clamps to the timeline", () => {
    expect(spans(addZoomRegion([], { start: 55, end: 80 }, TOTAL))).toEqual([[55, 60]]);
  });

  it("wins an overlap: covered regions vanish and partly covered ones are trimmed", () => {
    const out = addZoomRegion(
      [R("a", 5, 10), R("b", 12, 18), R("c", 25, 30)],
      { start: 8, end: 20, id: "n" },
      TOTAL,
    );
    expect(spans(out)).toEqual([[5, 8], [8, 20], [25, 30]]);
    expect(out.map((r) => r.id)).toEqual(["a", "n", "c"]);
  });

  it("splits a region the new one sits inside, with unique ids", () => {
    const out = addZoomRegion([R("a", 0, 30)], { start: 10, end: 14, id: "n" }, TOTAL);
    expect(spans(out)).toEqual([[0, 10], [10, 14], [14, 30]]);
    expect(new Set(out.map((r) => r.id)).size).toBe(3);
  });

  it("never leaves overlaps, whatever is added", () => {
    let rs: ZoomRegion[] = [];
    const adds: Array<[number, number]> = [[3, 9], [7, 15], [1, 40], [20, 22], [21, 35], [0, 60], [30, 31]];
    for (const [s, e] of adds) {
      rs = addZoomRegion(rs, { start: s, end: e }, TOTAL);
      for (let i = 1; i < rs.length; i++) expect(rs[i]!.start).toBeGreaterThanOrEqual(rs[i - 1]!.end - 1e-9);
    }
  });
});

describe("updateZoomRegion and removal", () => {
  const base = [R("a", 5, 10), R("b", 20, 30)];

  it("changes scale and focus without touching the span", () => {
    const out = updateZoomRegion(base, "a", { scale: 3, focusX: 0.2 }, TOTAL);
    expect(out[0]).toMatchObject({ id: "a", start: 5, end: 10, scale: 3, focusX: 0.2 });
  });

  it("moves a region and trims a neighbour it lands on", () => {
    const out = updateZoomRegion(base, "a", { start: 18, end: 23 }, TOTAL);
    expect(spans(out)).toEqual([[18, 23], [23, 30]]);
  });

  it("holds the minimum length when a drag would invert the span", () => {
    const out = updateZoomRegion(base, "a", { end: 5.1 }, TOTAL);
    expect(out.find((r) => r.id === "a")!.end - 5).toBeGreaterThanOrEqual(MIN_REGION_SEC - 1e-9);
  });

  it("keeps a dragged region on the timeline", () => {
    const out = updateZoomRegion(base, "b", { start: 55, end: 65 }, TOTAL);
    const b = out.find((r) => r.id === "b")!;
    expect(b.end).toBeLessThanOrEqual(TOTAL);
    expect(b.end - b.start).toBeGreaterThanOrEqual(MIN_REGION_SEC);
  });

  it("ignores an unknown id", () => {
    expect(updateZoomRegion(base, "zzz", { scale: 3 }, TOTAL)).toEqual(base);
  });

  it("removes by id", () => {
    expect(removeZoomRegion(base, "a").map((r) => r.id)).toEqual(["b"]);
  });
});

describe("clearZoomRange", () => {
  it("removes, trims and splits as needed", () => {
    const out = clearZoomRange([R("a", 0, 30), R("b", 40, 50)], 10, 14);
    expect(spans(out)).toEqual([[0, 10], [14, 30], [40, 50]]);
    const out2 = clearZoomRange([R("a", 10, 20)], 0, 100);
    expect(out2).toEqual([]);
  });

  it("leaves regions outside the range alone", () => {
    const rs = [R("a", 0, 5)];
    expect(clearZoomRange(rs, 10, 20)).toEqual(rs);
  });
});

describe("motion", () => {
  const r = R("a", 10, 20, { scale: 2, focusX: 0.8, focusY: 0.2, easeMs: 1000 });

  it("smooth is 0 at 0, 1 at 1, and has zero slope at the ends", () => {
    expect(smooth(0)).toBe(0);
    expect(smooth(1)).toBe(1);
    expect(smooth(0.001)).toBeLessThan(0.00001);
    expect(smooth(0.5)).toBeCloseTo(0.5);
  });

  it("is 1x with no regions or outside every region", () => {
    expect(sampleZoom([], 5)).toEqual({ scale: 1, cx: 0.5, cy: 0.5 });
    expect(sampleZoom([r], 5).scale).toBe(1);
    expect(sampleZoom([r], 25).scale).toBe(1);
  });

  it("eases in, holds, then eases out", () => {
    expect(sampleZoom([r], 10).scale).toBeCloseTo(1);
    const mid = sampleZoom([r], 10.5).scale;
    expect(mid).toBeGreaterThan(1);
    expect(mid).toBeLessThan(2);
    expect(sampleZoom([r], 15).scale).toBeCloseTo(2);
    expect(sampleZoom([r], 19.5).scale).toBeLessThan(2);
    expect(sampleZoom([r], 20).scale).toBeCloseTo(1);
  });

  it("is smooth: scale never jumps between close samples", () => {
    let prev = sampleZoom([r], 9).scale;
    for (let t = 9.01; t <= 21; t += 0.01) {
      const s = sampleZoom([r], t).scale;
      expect(Math.abs(s - prev)).toBeLessThan(0.02);
      prev = s;
    }
  });

  it("drifts the centre toward the focus as it zooms", () => {
    const plateau = sampleZoom([r], 15);
    expect(plateau.cx).toBeCloseTo(0.8);
    expect(plateau.cy).toBeCloseTo(0.2);
    const early = sampleZoom([r], 10.2);
    expect(early.cx).toBeGreaterThan(0.5);
    expect(early.cx).toBeLessThan(0.8);
  });

  it("uses a shorter ease for a short region so it still reaches its plateau", () => {
    const short = R("s", 0, 1, { scale: 3, easeMs: 2000 });
    expect(sampleZoom([short], 0.5).scale).toBeCloseTo(3);
  });

  it("handles a region with no ease", () => {
    const hard = R("h", 5, 10, { easeMs: 0, scale: 2 });
    expect(zoomEnvelope(hard, 5)).toBe(1);
    expect(sampleZoom([hard], 7).scale).toBe(2);
    expect(sampleZoom([hard], 10.1).scale).toBe(1);
  });

  it("keeps the visible window inside the picture", () => {
    const w = viewWindow({ scale: 2, cx: 0.95, cy: 0.02 });
    expect(w.x0 + w.w).toBeCloseTo(1);
    expect(w.y0).toBe(0);
    expect(w.w).toBeCloseTo(0.5);
    const centred = viewWindow({ scale: 2, cx: 0.5, cy: 0.5 });
    expect(centred.x0).toBeCloseTo(0.25);
    expect(viewWindow({ scale: 1, cx: 0.9, cy: 0.9 })).toMatchObject({ x0: 0, y0: 0, w: 1 });
  });
});

describe("retimeZoomRegions", () => {
  const entry = (
    outputStart: number,
    outputEnd: number,
    sourceIn: number,
    sourceOut: number,
    mediaId = "m",
  ): TimelineEntry => ({ segmentId: `s${outputStart}`, mediaId, sourceIn, sourceOut, outputStart, outputEnd });

  // Old: one segment, source 0..60 = output 0..60.
  const oldTl = [entry(0, 60, 0, 60)];

  it("shifts a region left when earlier content is cut", () => {
    // New: source 0..10 and 20..60 kept; the 10..20 cut collapses.
    const newTl = [entry(0, 10, 0, 10), entry(10, 50, 20, 60)];
    const out = retimeZoomRegions([R("a", 30, 40)], oldTl, newTl, 50);
    expect(spans(out)).toEqual([[20, 30]]);
    expect(out[0]!.id).toBe("a");
  });

  it("closes up over a cut inside the region", () => {
    const newTl = [entry(0, 10, 0, 10), entry(10, 50, 20, 60)];
    const out = retimeZoomRegions([R("a", 5, 30)], oldTl, newTl, 50);
    expect(out).toHaveLength(1);
    expect(out[0]!.start).toBeCloseTo(5);
    expect(out[0]!.end).toBeCloseTo(20);
  });

  it("trims a region whose tail was cut", () => {
    const newTl = [entry(0, 10, 0, 10), entry(10, 50, 20, 60)];
    const out = retimeZoomRegions([R("a", 5, 15)], oldTl, newTl, 50);
    expect(spans(out)).toEqual([[5, 10]]);
  });

  it("drops a region whose content was entirely cut", () => {
    const newTl = [entry(0, 10, 0, 10), entry(10, 50, 20, 60)];
    expect(retimeZoomRegions([R("a", 11, 18)], oldTl, newTl, 50)).toEqual([]);
  });

  it("drops a region that keeps only a sliver", () => {
    const newTl = [entry(0, 10.1, 0, 10.1), entry(10.1, 50, 20, 59.9)];
    expect(retimeZoomRegions([R("a", 10, 15)], oldTl, newTl, 50)).toEqual([]);
  });

  it("leaves regions in untouched content where they were", () => {
    const newTl = [entry(0, 10, 0, 10), entry(10, 50, 20, 60)];
    const out = retimeZoomRegions([R("a", 0.5, 4)], oldTl, newTl, 50);
    expect(spans(out)).toEqual([[0.5, 4]]);
  });

  it("keeps scale, focus and ease", () => {
    const newTl = [entry(0, 10, 0, 10), entry(10, 50, 20, 60)];
    const out = retimeZoomRegions([R("a", 30, 40, { scale: 3, focusX: 0.1, easeMs: 200 })], oldTl, newTl, 50);
    expect(out[0]).toMatchObject({ scale: 3, focusX: 0.1, easeMs: 200 });
  });

  it("returns nothing for no regions", () => {
    expect(retimeZoomRegions([], oldTl, oldTl, 60)).toEqual([]);
  });
});
