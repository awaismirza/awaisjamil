import { beforeEach, describe, expect, it } from "vitest";
import { DEFAULT_PANEL, useEditorUiStore } from "@/stores/editorUiStore";

describe("editorUiStore", () => {
  beforeEach(() => {
    useEditorUiStore.setState({
      activePanel: DEFAULT_PANEL,
      inspectorOpen: true,
      aspectRatio: "16:9",
      previewZoom: 1,
      autoZoomEnabled: true,
    });
  });

  describe("panels", () => {
    it("clicking the active panel toggles the inspector", () => {
      useEditorUiStore.getState().setActivePanel(DEFAULT_PANEL);
      expect(useEditorUiStore.getState().inspectorOpen).toBe(false);
      useEditorUiStore.getState().setActivePanel(DEFAULT_PANEL);
      expect(useEditorUiStore.getState().inspectorOpen).toBe(true);
    });

    it("clicking a different panel activates it and opens the inspector", () => {
      useEditorUiStore.setState({ inspectorOpen: false });
      useEditorUiStore.getState().setActivePanel("export");
      const s = useEditorUiStore.getState();
      expect(s.activePanel).toBe("export");
      expect(s.inspectorOpen).toBe(true);
    });
  });

  describe("openPanel", () => {
    it("shows the panel and opens a closed inspector", () => {
      useEditorUiStore.setState({ inspectorOpen: false, activePanel: "media" });
      useEditorUiStore.getState().openPanel("find");
      const s = useEditorUiStore.getState();
      expect(s.activePanel).toBe("find");
      expect(s.inspectorOpen).toBe(true);
    });

    it("never closes the inspector, even for the active panel", () => {
      useEditorUiStore.setState({ inspectorOpen: true, activePanel: "find" });
      useEditorUiStore.getState().openPanel("find");
      expect(useEditorUiStore.getState().inspectorOpen).toBe(true);
    });
  });

  describe("misc ui state", () => {

    it("setPreviewZoom updates previewZoom", () => {
      useEditorUiStore.getState().setPreviewZoom(0.75);
      expect(useEditorUiStore.getState().previewZoom).toBe(0.75);
    });

    it("setAspectRatio updates aspectRatio", () => {
      useEditorUiStore.getState().setAspectRatio("9:16");
      expect(useEditorUiStore.getState().aspectRatio).toBe("9:16");
    });
  });
});
