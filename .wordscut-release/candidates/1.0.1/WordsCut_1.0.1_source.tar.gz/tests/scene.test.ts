import { describe, expect, it } from "vitest";
import {
  canvasSize,
  defaultScene,
  gradientLine,
  resolveSceneForExport,
  sanitizeScene,
  sceneActive,
  sceneLayout,
  SCENE_PRESETS,
  type SceneSettings,
} from "@/lib/scene";

const SRC = { w: 1920, h: 1080 };
const scene = (patch: Partial<SceneSettings> = {}): SceneSettings => ({
  ...defaultScene(),
  enabled: true,
  ...patch,
});

describe("canvasSize", () => {
  it("keeps the source size for 'source'", () => {
    expect(canvasSize("source", { w: 2560, h: 1440 })).toEqual({ w: 2560, h: 1440 });
  });

  it("rounds odd source sizes to even", () => {
    expect(canvasSize("source", { w: 1281, h: 721 })).toEqual({ w: 1282, h: 722 });
  });

  it("gives the standard sizes for each aspect", () => {
    expect(canvasSize("16:9", SRC)).toEqual({ w: 1920, h: 1080 });
    expect(canvasSize("9:16", SRC)).toEqual({ w: 1080, h: 1920 });
    expect(canvasSize("1:1", SRC)).toEqual({ w: 1080, h: 1080 });
    expect(canvasSize("4:3", SRC)).toEqual({ w: 1440, h: 1080 });
  });
});

describe("sceneLayout", () => {
  it("centres the video and keeps its aspect inside the padding", () => {
    const l = sceneLayout(scene({ aspect: "16:9", paddingPct: 10 }), SRC);
    const pad = 0.1 * 1080;
    expect(l.content.w).toBeLessThanOrEqual(1920 - 2 * pad + 1);
    expect(l.content.h).toBeLessThanOrEqual(1080 - 2 * pad + 1);
    expect(l.content.x + l.content.w / 2).toBeCloseTo(1920 / 2, 0);
    expect(l.content.y + l.content.h / 2).toBeCloseTo(1080 / 2, 0);
    expect(l.content.w / l.content.h).toBeCloseTo(16 / 9, 1);
  });

  it("is full-bleed with no padding", () => {
    const l = sceneLayout(scene({ aspect: "16:9", paddingPct: 0 }), SRC);
    expect(l.content).toEqual({ x: 0, y: 0, w: 1920, h: 1080 });
  });

  it("letterboxes a landscape video inside a portrait canvas", () => {
    const l = sceneLayout(scene({ aspect: "9:16", paddingPct: 5 }), SRC);
    expect(l.canvasW).toBe(1080);
    expect(l.canvasH).toBe(1920);
    // Width-limited: the video spans the padded width and has empty bands above and below.
    expect(l.content.w).toBeCloseTo(1080 - 2 * 0.05 * 1080, -1);
    expect(l.content.y).toBeGreaterThan(400);
  });

  it("shrinks the video inside the same canvas for 'source' aspect", () => {
    const l = sceneLayout(scene({ aspect: "source", paddingPct: 10 }), SRC);
    expect(l.canvasW).toBe(1920);
    expect(l.content.w).toBeLessThan(1920);
  });

  it("always yields even sizes that stay on the canvas", () => {
    for (const aspect of ["source", "16:9", "9:16", "1:1", "4:3"] as const) {
      for (const paddingPct of [0, 3, 7.5, 12, 30]) {
        const l = sceneLayout(scene({ aspect, paddingPct }), { w: 1281, h: 721 });
        expect(l.content.w % 2).toBe(0);
        expect(l.content.h % 2).toBe(0);
        expect(l.content.x).toBeGreaterThanOrEqual(0);
        expect(l.content.y).toBeGreaterThanOrEqual(0);
        expect(l.content.x + l.content.w).toBeLessThanOrEqual(l.canvasW);
        expect(l.content.y + l.content.h).toBeLessThanOrEqual(l.canvasH);
      }
    }
  });

  it("caps the radius at half the shorter side", () => {
    const l = sceneLayout(scene({ radiusPct: 30 }), SRC);
    expect(l.radiusPx).toBeLessThanOrEqual(Math.min(l.content.w, l.content.h) / 2);
    expect(sceneLayout(scene({ radiusPct: 0 }), SRC).radiusPx).toBe(0);
  });

  it("scales the shadow with strength and turns it off at zero", () => {
    const none = sceneLayout(scene({ shadow: 0 }), SRC).shadow;
    const some = sceneLayout(scene({ shadow: 0.5 }), SRC).shadow;
    const lots = sceneLayout(scene({ shadow: 1 }), SRC).shadow;
    expect(none.opacity).toBe(0);
    expect(none.sigmaPx).toBe(0);
    expect(some.sigmaPx).toBeGreaterThan(0);
    expect(lots.sigmaPx).toBeGreaterThan(some.sigmaPx);
    expect(lots.opacity).toBeGreaterThan(some.opacity);
    expect(lots.opacity).toBeLessThanOrEqual(1);
  });

  it("honours an explicit export canvas", () => {
    const l = sceneLayout(scene({ aspect: "16:9" }), SRC, { w: 1280, h: 720 });
    expect(l.canvasW).toBe(1280);
    expect(l.canvasH).toBe(720);
  });
});

describe("gradientLine", () => {
  it("points up for 0 degrees and right for 90", () => {
    const up = gradientLine(100, 100, 0);
    expect(up.x0).toBeCloseTo(50);
    expect(up.y0).toBeGreaterThan(up.y1);
    const right = gradientLine(100, 100, 90);
    expect(right.y0).toBeCloseTo(50);
    expect(right.x1).toBeGreaterThan(right.x0);
  });

  it("spans corner to corner at 135 degrees on a square", () => {
    const g = gradientLine(100, 100, 135);
    expect(g.x0).toBeCloseTo(0);
    expect(g.y0).toBeCloseTo(0);
    expect(g.x1).toBeCloseTo(100);
    expect(g.y1).toBeCloseTo(100);
  });
});

describe("sanitizeScene", () => {
  it("returns a disabled default for junk", () => {
    expect(sanitizeScene(undefined)).toEqual(defaultScene());
    expect(sanitizeScene("x")).toEqual(defaultScene());
    expect(sanitizeScene(defaultScene()).enabled).toBe(false);
  });

  it("keeps good values and clamps out-of-range numbers", () => {
    const s = sanitizeScene({ enabled: true, aspect: "1:1", paddingPct: 99, radiusPct: -4, shadow: 3 });
    expect(s.enabled).toBe(true);
    expect(s.aspect).toBe("1:1");
    expect(s.paddingPct).toBe(30);
    expect(s.radiusPct).toBe(0);
    expect(s.shadow).toBe(1);
  });

  it("replaces bad colours and unknown aspects", () => {
    const s = sanitizeScene({
      aspect: "5:4",
      background: { kind: "solid", color: "red" },
    });
    expect(s.aspect).toBe("source");
    expect(s.background).toEqual({ kind: "solid", color: "#0f0f12" });
  });

  it("accepts a gradient and an image background", () => {
    expect(
      sanitizeScene({ background: { kind: "gradient", from: "#FFAA00", to: "#00AAFF", angle: 45 } })
        .background,
    ).toEqual({ kind: "gradient", from: "#ffaa00", to: "#00aaff", angle: 45 });
    expect(sanitizeScene({ background: { kind: "image", path: "/tmp/a.png" } }).background).toEqual({
      kind: "image",
      path: "/tmp/a.png",
    });
  });

  it("every preset is already valid", () => {
    for (const p of SCENE_PRESETS) {
      expect(sanitizeScene({ background: p.background }).background).toEqual(p.background);
    }
  });
});

describe("export payload", () => {
  it("only a scene that is enabled is active", () => {
    expect(sceneActive(undefined)).toBe(false);
    expect(sceneActive(defaultScene())).toBe(false);
    expect(sceneActive(scene())).toBe(true);
  });

  it("resolves geometry and gradient endpoints in pixels", () => {
    const r = resolveSceneForExport(
      scene({ background: { kind: "gradient", from: "#000000", to: "#ffffff", angle: 90 } }),
      SRC,
    );
    expect(r.canvasW).toBe(1920);
    expect(r.contentW).toBeGreaterThan(0);
    expect(r.background.kind).toBe("gradient");
    if (r.background.kind === "gradient") expect(r.background.x1).toBeGreaterThan(r.background.x0);
  });

  it("passes solid and image backgrounds through", () => {
    expect(resolveSceneForExport(scene({ background: { kind: "solid", color: "#123456" } }), SRC).background).toEqual({
      kind: "solid",
      color: "#123456",
    });
    expect(
      resolveSceneForExport(scene({ background: { kind: "image", path: "/x.png" } }), SRC).background,
    ).toEqual({ kind: "image", path: "/x.png" });
  });
});
