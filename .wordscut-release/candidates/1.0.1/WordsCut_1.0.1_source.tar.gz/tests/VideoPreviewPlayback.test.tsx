import { act, cleanup, fireEvent, render } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { VideoPreview } from "@/components/VideoPreview/VideoPreview";
import { newProject } from "@/lib/edl";
import { useProjectStore } from "@/stores/projectStore";
import { usePlayerStore } from "@/stores/playerStore";
const clock = vi.hoisted(() => ({ tick: (_time: number) => {} }));
vi.mock("@tauri-apps/api/core", () => ({ convertFileSrc: (path: string) => path }));
vi.mock("@/hooks/useVideoFrameClock", () => ({
  useVideoFrameClock: (_ref: unknown, callback: (t: number) => void) => {
    clock.tick = callback;
  },
}));
let paused = true;
beforeEach(() => {
  paused = true;
  vi.spyOn(HTMLMediaElement.prototype, "pause").mockImplementation(() => {
    paused = true;
  });
  vi.spyOn(HTMLMediaElement.prototype, "play").mockImplementation(() => {
    paused = false;
    return Promise.resolve();
  });
  vi.spyOn(HTMLMediaElement.prototype, "load").mockImplementation(() => {});
  vi.spyOn(HTMLMediaElement.prototype, "readyState", "get").mockReturnValue(4);
  vi.spyOn(HTMLMediaElement.prototype, "paused", "get").mockImplementation(() => paused);
  const media = (id: string) => ({
    id,
    path: `/tmp/${id}.mp4`,
    duration: 3,
    width: 1920,
    height: 1080,
    fps: 30,
    audioSampleRate: 48000,
    sha256: id,
  });
  const p = newProject("repeated");
  p.media = { m: media("m"), n: media("n") };
  p.segments = ["a", "repeat", "other"].map((id, i) => ({
    id,
    mediaId: i === 2 ? "n" : "m",
    sourceIn: 0,
    sourceOut: 1,
    words: [{ id: `word-${id}`, text: id, start: 0, end: 1, confidence: 1 }],
  }));
  useProjectStore.setState({ project: p, dirty: false });
  usePlayerStore.getState().reset();
});
afterEach(() => {
  cleanup();
  vi.restoreAllMocks();
});
describe("indexed preview transport", () => {
  it("anchors repeated source playback to the selected EDL entry and ignores playing timeupdate events", () => {
    const { container } = render(<VideoPreview />);
    const video = container.querySelector("video")!;
    fireEvent.loadedMetadata(video);
    act(() => {
      window.dispatchEvent(
        new CustomEvent("yusafcut:seek-output", { detail: { time: 1.2, play: true } }),
      );
    });
    expect(video.currentTime).toBeCloseTo(0.2);
    fireEvent.seeked(video);
    act(() => clock.tick(0.2));
    act(() => clock.tick(0.4));
    expect(usePlayerStore.getState().currentTime).toBeCloseTo(1.2); // UI cadence can retain the same word's last timecode
    video.currentTime = 0.7;
    fireEvent.timeUpdate(video);
    expect(usePlayerStore.getState().currentTime).toBeCloseTo(1.2);
    act(() => {
      window.dispatchEvent(new CustomEvent("yusafcut:seek-output", { detail: { time: 1.6 } }));
    });
    expect(usePlayerStore.getState().currentTime).toBeCloseTo(1.6);
  });
  it("advances from a source endpoint to the next repeated entry, then switches media without remounting video", () => {
    const { container } = render(<VideoPreview />);
    const video = container.querySelector("video")!;
    fireEvent.loadedMetadata(video);
    act(() => {
      window.dispatchEvent(
        new CustomEvent("yusafcut:seek-output", { detail: { time: 0.5, play: true } }),
      );
      fireEvent.seeked(video);
      clock.tick(0.5);
      clock.tick(1);
    });
    expect(video.currentTime).toBe(0);
    expect(usePlayerStore.getState().currentTime).toBe(1);
    fireEvent.seeked(video);
    act(() => clock.tick(0));
    act(() => clock.tick(0.2));
    expect(usePlayerStore.getState().currentTime).toBeCloseTo(1);
    act(() => clock.tick(1));
    expect(container.querySelector("video")).toBe(video);
    expect(video.getAttribute("src")).toBe("/tmp/n.mp4");
  });
  it("crosses a continuous split without seeking or restarting the decoder", () => {
    const p = useProjectStore.getState().project;
    p.segments = [
      p.segments[0],
      {
        ...p.segments[1],
        sourceIn: 1,
        sourceOut: 2,
        words: [{ ...p.segments[1].words[0], start: 1, end: 2 }],
      },
    ];
    const { container } = render(<VideoPreview />);
    const video = container.querySelector("video")!;
    fireEvent.loadedMetadata(video);
    act(() => {
      window.dispatchEvent(
        new CustomEvent("yusafcut:seek-output", { detail: { time: 0.5, play: true } }),
      );
    });
    fireEvent.seeked(video);
    act(() => clock.tick(0.5));
    const playCount = vi.mocked(HTMLMediaElement.prototype.play).mock.calls.length;
    act(() => clock.tick(1.2));
    expect(video.currentTime).toBe(0.5);
    expect(vi.mocked(HTMLMediaElement.prototype.play).mock.calls.length).toBe(playCount);
    expect(usePlayerStore.getState().currentTime).toBeCloseTo(1.2);
  });
  it("initialises a trimmed project at its first kept source frame", () => {
    const p = useProjectStore.getState().project;
    p.segments = [{ ...p.segments[0], sourceIn: 0.5 }];
    const { container } = render(<VideoPreview />);
    const video = container.querySelector("video")!;
    expect(video.currentTime).toBe(0.5);
    fireEvent.loadedMetadata(video);
    expect(usePlayerStore.getState().currentTime).toBe(0);
  });
  it("keeps the latest target when another seek arrives during cross-media loading", () => {
    const { container } = render(<VideoPreview />);
    const video = container.querySelector("video")!;
    fireEvent.loadedMetadata(video);
    act(() =>
      window.dispatchEvent(new CustomEvent("yusafcut:seek-output", { detail: { time: 2.1 } })),
    );
    act(() =>
      window.dispatchEvent(new CustomEvent("yusafcut:seek-output", { detail: { time: 2.7 } })),
    );
    fireEvent.loadedMetadata(video);
    expect(video.currentTime).toBeCloseTo(0.7);
    expect(usePlayerStore.getState().currentTime).toBeCloseTo(2.7);
  });
  it("rejects a high stale frame after a backward cut instead of skipping the new entry", () => {
    const { container } = render(<VideoPreview />);
    const video = container.querySelector("video")!;
    fireEvent.loadedMetadata(video);
    act(() =>
      window.dispatchEvent(
        new CustomEvent("yusafcut:seek-output", { detail: { time: 1.1, play: true } }),
      ),
    );
    fireEvent.seeked(video);
    act(() => clock.tick(1));
    expect(video.getAttribute("src")).toBe("/tmp/m.mp4");
    expect(usePlayerStore.getState().currentTime).toBeCloseTo(1.1);
    act(() => clock.tick(0.1));
    expect(usePlayerStore.getState().currentTime).toBeCloseTo(1.1);
  });
  it("does not resume a pending cross-media load after an explicit pause", () => {
    const { container } = render(<VideoPreview />);
    const video = container.querySelector("video")!;
    fireEvent.loadedMetadata(video);
    act(() =>
      window.dispatchEvent(
        new CustomEvent("yusafcut:seek-output", { detail: { time: 2.4, play: true } }),
      ),
    );
    act(() => window.dispatchEvent(new CustomEvent("yusafcut:pause")));
    const before = vi.mocked(HTMLMediaElement.prototype.play).mock.calls.length;
    fireEvent.loadedMetadata(video);
    expect(vi.mocked(HTMLMediaElement.prototype.play)).toHaveBeenCalledTimes(before);
    expect(usePlayerStore.getState().playing).toBe(false);
  });
});
