import { afterEach, describe, expect, it, vi } from "vitest";
import { nextPaint } from "../src/lib/paint";

describe("nextPaint", () => {
  afterEach(() => {
    vi.useRealTimers();
    vi.unstubAllGlobals();
  });

  it("resolves on the timeout when requestAnimationFrame never fires (hidden window)", async () => {
    vi.useFakeTimers();
    vi.stubGlobal("requestAnimationFrame", () => 0);
    let resolved = false;
    void nextPaint(100).then(() => (resolved = true));
    await vi.advanceTimersByTimeAsync(99);
    expect(resolved).toBe(false);
    await vi.advanceTimersByTimeAsync(2);
    expect(resolved).toBe(true);
  });

  it("resolves on the frame when one is painted", async () => {
    vi.useFakeTimers();
    vi.stubGlobal("requestAnimationFrame", (cb: () => void) => {
      cb();
      return 1;
    });
    await expect(nextPaint(10_000)).resolves.toBeUndefined();
  });
});
