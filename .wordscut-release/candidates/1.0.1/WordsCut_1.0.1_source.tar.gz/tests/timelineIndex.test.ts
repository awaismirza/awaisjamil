import { describe, expect, it } from "vitest";
import {
  entryAtOutput,
  getTimelineIndex,
  indexedSource,
  indexedWord,
  playbackPosition,
} from "@/lib/timelineIndex";
import type { Segment } from "@/lib/edl";
const segment = (id: string, sourceIn: number, sourceOut: number, mediaId = "m"): Segment => ({
  id,
  mediaId,
  sourceIn,
  sourceOut,
  words: [
    { id: "a", text: "one", start: sourceIn, end: sourceIn + 0.3, confidence: 1 },
    { id: "b", text: "two", start: sourceIn + 0.5, end: sourceIn + 0.8, confidence: 1 },
  ],
});
describe("derived timeline index", () => {
  it("caches by segment revision, invalidates on edit, and retains duplicate word occurrences", () => {
    const segments = [segment("s", 0, 1), segment("repeat", 0, 1)];
    const index = getTimelineIndex(segments);
    expect(getTimelineIndex(segments)).toBe(index);
    expect(getTimelineIndex([...segments])).not.toBe(index);
    expect(index.byWordId.get("a")).toHaveLength(2);
    expect(index.duration).toBe(2);
  });
  it("maps cut boundaries and repeated source ranges to the correct entry", () => {
    const index = getTimelineIndex([
      segment("a", 5, 6),
      segment("repeat", 5, 6),
      segment("other", 2, 3, "n"),
    ]);
    expect(entryAtOutput(index, 1)?.segmentId).toBe("repeat");
    expect(indexedSource(index, 1.25)?.sourceTime).toBe(5.25);
    expect(entryAtOutput(index, -1)).toBeNull();
    expect(entryAtOutput(index, 3)).toBeNull();
    expect(entryAtOutput(index, NaN)).toBeNull();
    expect(playbackPosition(index, 1, 5.5)?.outputTime).toBe(1.5);
    expect(playbackPosition(index, 1, 6)?.next?.mediaId).toBe("n");
    expect(playbackPosition(index, 2, 3)).toMatchObject({ ended: true, next: null, outputTime: 3 });
  });
  it("finds active words and silence without scanning all words; preserves overlapping-word priority", () => {
    const s = segment("s", 0, 1),
      index = getTimelineIndex([s]);
    expect(indexedWord(index, 0.2)).toMatchObject({ word: { id: "a" }, silence: false });
    expect(indexedWord(index, 0.4)).toMatchObject({ word: { id: "a" }, silence: true });
    expect(indexedWord(index, 0.5)).toMatchObject({ word: { id: "b" }, silence: false });
    const overlap = { ...s, words: [{ ...s.words[0], end: 0.7 }, s.words[1]] };
    expect(indexedWord(getTimelineIndex([overlap]), 0.6)?.word.id).toBe("a");
  });
  it("handles empty and zero-duration segments and never mutates source words", () => {
    const s = segment("zero", 0, 0),
      before = JSON.stringify(s);
    expect(getTimelineIndex([s]).entries).toEqual([]);
    expect(entryAtOutput(getTimelineIndex([]), 0)).toBeNull();
    expect(JSON.stringify(s)).toBe(before);
  });
});
