import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import * as ipc from "@/lib/ipc";
import type { RecordingDevices } from "@/lib/ipc";
import { OPTS_STORAGE_KEY } from "@/lib/recorderOpts";
import { defaultSettings } from "@/lib/settings";
import { useSettingsStore } from "@/stores/settingsStore";
import { initialBarState, useBarStore } from "@/recorderBar/barStore";

const emitTo = vi.fn().mockResolvedValue(undefined);
vi.mock("@tauri-apps/api/event", () => ({
  emitTo: (...a: unknown[]) => emitTo(...a),
  listen: vi.fn().mockResolvedValue(() => {}),
}));
vi.mock("@/lib/ipc", async (orig) => ({
  ...(await orig<typeof import("@/lib/ipc")>()),
  listRecordingDevices: vi.fn(),
  startRecording: vi.fn(),
  cancelRecording: vi.fn().mockResolvedValue(undefined),
  openRecorderBar: vi.fn().mockResolvedValue(undefined),
  closeRecorderBar: vi.fn().mockResolvedValue(undefined),
  hideRecorderBar: vi.fn().mockResolvedValue(undefined),
  setRecorderBarHeight: vi.fn().mockResolvedValue(undefined),
  openRecordingsFolder: vi.fn().mockResolvedValue(undefined),
  requestRecordingPermissions: vi.fn().mockResolvedValue({}),
  openPrivacySettings: vi.fn().mockResolvedValue(undefined),
}));

const screen = (index: number, name: string) => ({ index, name, isScreen: true });
export const oneScreen: RecordingDevices = {
  backend: "native",
  video: [screen(1000, "Built-in Display"), { index: 1001, name: "FaceTime", isScreen: false }],
  audio: [{ index: 1000, name: "Mic" }],
  windows: [
    { id: 42, title: "Doc", app: "Pages" },
    { id: 43, title: "WordsCut Recording Controls — Setup", app: "WordsCut" },
  ],
  displays: [{ index: 1000, width: 1000, height: 600 }],
  permissions: { screenRecording: "granted", camera: "granted", microphone: "granted" },
};
const twoScreens: RecordingDevices = {
  ...oneScreen,
  video: [screen(1000, "Built-in Display"), screen(1002, "LG"), ...oneScreen.video.slice(1)],
};

const snapshot = { sessionId: "s1" } as ipc.RecordingSnapshot;

async function load(devices: RecordingDevices) {
  vi.mocked(ipc.listRecordingDevices).mockResolvedValue(devices);
  await useBarStore.getState().refreshDevices();
}

beforeEach(() => {
  vi.clearAllMocks();
  window.localStorage.clear();
  useSettingsStore.setState({ recording: { ...defaultSettings().recording, countdownSec: 0 } });
  useBarStore.setState(initialBarState());
  vi.mocked(ipc.startRecording).mockResolvedValue(snapshot);
});
afterEach(() => vi.useRealTimers());

describe("barStore start sequence", () => {
  it("Display with one screen starts without a picker", async () => {
    await load(oneScreen);
    useBarStore.getState().chooseMode("display");
    await vi.waitFor(() => expect(ipc.closeRecorderBar).toHaveBeenCalledWith(false));
    expect(useBarStore.getState().popover).toBeNull();
    expect(ipc.startRecording).toHaveBeenCalledTimes(1);
  });

  it("Display with several screens opens the picker instead", async () => {
    await load(twoScreens);
    useBarStore.getState().chooseMode("display");
    expect(useBarStore.getState().popover).toBe("display");
    expect(ipc.startRecording).not.toHaveBeenCalled();
    useBarStore.getState().pickDisplay(1002);
    await vi.waitFor(() => expect(ipc.startRecording).toHaveBeenCalled());
    expect(vi.mocked(ipc.startRecording).mock.calls[0][0].screenIndex).toBe(1002);
  });

  it("hides the bar before startRecording and closes without restoring after", async () => {
    await load(oneScreen);
    const order: string[] = [];
    vi.mocked(ipc.hideRecorderBar).mockImplementation(async () => void order.push("hide"));
    vi.mocked(ipc.startRecording).mockImplementation(async () => {
      order.push("start");
      return snapshot;
    });
    vi.mocked(ipc.closeRecorderBar).mockImplementation(async () => void order.push("close"));
    await useBarStore.getState().start();
    expect(order).toEqual(["hide", "start", "close"]);
    expect(ipc.closeRecorderBar).toHaveBeenCalledWith(false);
  });

  it("re-opens the bar and shows the error when starting fails", async () => {
    await load(oneScreen);
    vi.mocked(ipc.startRecording).mockRejectedValue("Error: no space left");
    await useBarStore.getState().start();
    expect(ipc.openRecorderBar).toHaveBeenCalled();
    expect(ipc.closeRecorderBar).not.toHaveBeenCalled();
    expect(useBarStore.getState().error).toBe("no space left");
    expect(useBarStore.getState().phase).toBe("setup");
  });

  it("cancelling during the countdown never calls startRecording", async () => {
    vi.useFakeTimers();
    useSettingsStore.setState({ recording: { ...defaultSettings().recording, countdownSec: 3 } });
    await load(oneScreen);
    const run = useBarStore.getState().start();
    expect(useBarStore.getState().phase).toBe("countdown");
    expect(useBarStore.getState().countdown).toBe(3);
    await vi.advanceTimersByTimeAsync(1000);
    expect(useBarStore.getState().countdown).toBe(2);
    await useBarStore.getState().cancel();
    await vi.advanceTimersByTimeAsync(5000);
    await run;
    expect(useBarStore.getState().phase).toBe("setup");
    expect(ipc.startRecording).not.toHaveBeenCalled();
    expect(ipc.hideRecorderBar).not.toHaveBeenCalled();
  });

  it("does not start while a blocker applies", async () => {
    await load(oneScreen);
    useBarStore.getState().setOpts({ sourceKind: "window", windowId: undefined });
    await useBarStore.getState().start();
    expect(ipc.startRecording).not.toHaveBeenCalled();
    expect(useBarStore.getState().error).toBe("Choose a window to record.");
  });
});

describe("barStore options", () => {
  it("setOpts persists under the shared key and emits to the editor", async () => {
    useBarStore.getState().setOpts({ fps: 60 });
    expect(JSON.parse(window.localStorage.getItem(OPTS_STORAGE_KEY)!).fps).toBe(60);
    expect(emitTo).toHaveBeenCalledWith(
      "main",
      "recorder-bar:opts",
      expect.objectContaining({ fps: 60 }),
    );
  });

  it("camera toggle maps to screen-camera and back", async () => {
    await load(oneScreen);
    useBarStore.getState().setCamera(1001);
    expect(useBarStore.getState().opts.mode).toBe("screen-camera");
    useBarStore.getState().setCamera(null);
    expect(useBarStore.getState().opts.mode).toBe("screen");
  });

  it("a microphone switched off stays off after a device refresh", async () => {
    await load(oneScreen);
    expect(useBarStore.getState().opts.audioIndex).toBe(1000);
    useBarStore.getState().setMic(null);
    await load(oneScreen);
    expect(useBarStore.getState().opts.audioIndex).toBeUndefined();
  });

  it("Open Settings is remembered so the chip can ask for a restart", async () => {
    await useBarStore.getState().openSettings("screenRecording");
    expect(ipc.openPrivacySettings).toHaveBeenCalledWith("screenRecording");
    expect(useBarStore.getState().openedSettings).toBe(true);
  });
});
