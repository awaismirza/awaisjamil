import { describe, expect, it } from "vitest";
import {
  addZoomRegion,
  clearZoomRange,
  focusAt,
  retimeZoomRegions,
  sampleZoom,
  sanitizeZoomRegions,
  updateZoomRegion,
} from "@/lib/zoom";
import { generateAutoZoom } from "@/lib/autoZoom";
import { parseCursorLog } from "@/lib/cursor";
import fixture from "./fixtures/followZoom.json";
import { syntheticCursorLog } from "./fixtures/cursorLogs";
const region = fixture.region;
const entry = (sourceIn: number, sourceOut: number, outputStart = 0) => ({
  segmentId: `s${sourceIn}`,
  mediaId: "m",
  sourceIn,
  sourceOut,
  outputStart,
  outputEnd: outputStart + sourceOut - sourceIn,
});
describe("follow cursor motion", () => {
  it("matches the shared preview/export samples through ease and moving plateau", () => {
    for (const { t, ...sample } of fixture.samples) expect(sampleZoom([region], t)).toEqual(sample);
    expect(focusAt(region, -1)).toEqual({ x: 0.25, y: 0.5 });
    expect(focusAt(region, 8)).toEqual({ x: 0.75, y: 0.5 });
    expect(focusAt({ ...region, follow: false }, 2.5)).toEqual({ x: 0.5, y: 0.5 });
  });
  it("sanitizes invalid keys, sorts, clamps and keeps the last duplicate", () => {
    const [r] = sanitizeZoomRegions(
      [
        {
          ...region,
          focusKeys: [
            null,
            {},
            { t: NaN, x: 0, y: 0 },
            { t: 3, x: 9, y: -1 },
            { t: 1, x: 0.1, y: 0.5 },
            { t: 1, x: 0.2, y: 0.5 },
          ],
        },
      ],
      10,
    );
    expect(r.focusKeys?.[0]).toEqual({ t: 1, x: 0.2, y: 0.5 });
    expect(focusAt(r, 3)).toEqual({ x: 1, y: 0 });
  });
  it("keeps keys when adding and dragging; resizing and splitting preserve boundary focus", () => {
    const rs = addZoomRegion([], region, 20);
    expect(sampleZoom(rs, 2.5)).toEqual(sampleZoom([region], 2.5));
    const moved = updateZoomRegion(rs, region.id, { start: 6, end: 9 }, 20);
    expect(sampleZoom(moved, 7.5)).toEqual(sampleZoom([region], 2.5));
    const clamped = updateZoomRegion(rs, region.id, { start: -1, end: 2 }, 20);
    expect(focusAt(clamped[0], 1.5)).toEqual(focusAt(region, 2.5));
    const resized = updateZoomRegion(rs, region.id, { start: 2 }, 20);
    expect(focusAt(resized[0], 2)).toEqual(focusAt(region, 2));
    const split = clearZoomRange(rs, 2, 3);
    expect(focusAt(split[0], 2)).toEqual(focusAt(region, 2));
    expect(focusAt(split[1], 3)).toEqual(focusAt(region, 3));
  });
  it("lets a manual focus choice replace automatic following", () => {
    const [r] = updateZoomRegion([region], region.id, { focusX: 0.8 }, 20);
    expect(r.follow).toBe(false);
    expect(sampleZoom([r], 2.5).cx).toBeCloseTo(0.8);
  });
  it("retimes keys with the surviving source and jumps across a cut", () => {
    const [r] = retimeZoomRegions([region], [entry(0, 5)], [entry(0, 2), entry(3, 5, 2)], 4);
    expect(r.start).toBe(1);
    expect(r.end).toBe(3);
    expect(focusAt(r, 1.5).x).toBeCloseTo(focusAt(region, 1.5).x, 5);
    expect(focusAt(r, 2).x).toBeCloseTo(focusAt(region, 3).x);
    expect(focusAt(r, 2.5)).toEqual(focusAt(region, 3.5));
  });
  it("generates smoothed follow keys at quarter-second intervals in output time", () => {
    const rs = generateAutoZoom({ m: parseCursorLog(syntheticCursorLog()) }, [entry(5, 20)], {
      follow: true,
    });
    expect(rs.length).toBeGreaterThan(0);
    for (const r of rs) {
      expect(r.follow).toBe(true);
      expect(r.focusKeys?.[0].t).toBe(r.start);
      expect(r.focusKeys?.at(-1)?.t).toBe(r.end);
      for (let i = 1; i < r.focusKeys!.length; i++)
        expect(r.focusKeys![i].t - r.focusKeys![i - 1].t).toBeLessThanOrEqual(0.25 + 1e-9);
    }
  });
});
