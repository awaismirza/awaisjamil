import { describe, expect, it } from "vitest";
import {
  claudeCodeCommand,
  clientSnippets,
  cliStartCommand,
  codexToml,
  httpHeader,
  maskToken,
  mcpServersJson,
  shellQuote,
} from "@/lib/agent/connectSnippets";

const BIN = "/Applications/WordsCut.app/Contents/MacOS/WordsCut";
const ODD = '/Users/a b/"x"/$HOME/`y`/WordsCut';

describe("connectSnippets", () => {
  it("builds exact Claude Code command and .mcp.json", () => {
    expect(claudeCodeCommand(BIN)).toBe(`claude mcp add yusafcut -- "${BIN}" mcp`);
    expect(JSON.parse(mcpServersJson(BIN))).toEqual({
      mcpServers: { yusafcut: { command: BIN, args: ["mcp"] } },
    });
  });

  it("builds Codex TOML", () => {
    expect(codexToml(BIN)).toBe(`[mcp_servers.yusafcut]\ncommand = "${BIN}"\nargs = ["mcp"]`);
  });

  it("escapes awkward paths for shell, JSON and TOML", () => {
    expect(shellQuote(ODD)).toBe('"/Users/a b/\\"x\\"/\\$HOME/\\`y\\`/WordsCut"');
    expect(JSON.parse(mcpServersJson(ODD)).mcpServers.yusafcut.command).toBe(ODD);
    expect(codexToml(ODD)).toContain(`command = ${JSON.stringify(ODD)}`);
    expect(cliStartCommand(ODD)).toMatch(/ agent readme$/);
  });

  it("gemini reuses the JSON config; HTTP header and masking", () => {
    expect(clientSnippets("gemini", BIN)[0].text).toBe(mcpServersJson(BIN));
    expect(clientSnippets("claude", BIN)).toHaveLength(2);
    expect(httpHeader("abc")).toBe("Authorization: Bearer abc");
    expect(maskToken("abcdef0123456789")).not.toContain("a");
  });
});
