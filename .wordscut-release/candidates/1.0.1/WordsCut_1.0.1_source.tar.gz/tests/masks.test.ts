// Privacy masks are SOURCE-ANCHORED: spans on the output timeline are derived
// from the timeline at every use, so edits can never unmask content.
import { beforeEach, describe, expect, it } from "vitest";
import fixture from "./fixtures/layersSanitize.json";
import parity from "./fixtures/maskSpansParity.json";
import { generateMaskSpanCases } from "./fixtures/maskSpansParity.gen";
import {
  addMediaWithTranscript,
  computeTimeline,
  deleteWords,
  newProject,
  restoreWords,
  setSegmentTiming,
  type Project,
  type SourceMedia,
  type Word,
} from "@/lib/edl";
import { duplicateClip, moveClip } from "@/lib/clipEdit";
import {
  sameFile,
  coveragePlaces,
  duplicateSources,
  masksOnOverlayFile,
  makeMask,
  maskFollowZoomOverlap,
  maskOutputSpans,
  MAX_MASKS,
  migrateMasks,
  MIN_SPAN_SEC,
  projectMaskSpans,
  sanitizeMasks,
  sourceTimeAt,
  type PrivacyMask,
} from "@/lib/masks";
import { keystrokeCaptions } from "@/lib/keystrokes";
import { addVoiceOverTake } from "@/lib/voiceover";
import { buildFcpxml } from "@/lib/fcpxml";
import { parseCursorLog } from "@/lib/cursor";
import { useProjectStore } from "@/stores/projectStore";
import { useUIStore } from "@/stores/uiStore";

const strip = ({ id: _id, ...rest }: { id: string }) => rest;
const media: SourceMedia = {
  id: "m",
  path: "/tmp/m.mp4",
  duration: 20,
  fps: 30,
  width: 1920,
  height: 1080,
  audioSampleRate: 48000,
  sha256: "x",
};
const words: Word[] = Array.from({ length: 20 }, (_, i) => ({
  id: `w${i}`,
  text: `w${i}`,
  start: i,
  end: i + 1,
  confidence: 1,
}));
function base(): Project {
  const p = addMediaWithTranscript(newProject("t"), media, words);
  return { ...p, settings: { ...p.settings, paddingMs: 0 } };
}
const mask = (srcStart: number, srcEnd: number, extra = {}): PrivacyMask =>
  sanitizeMasks([{ id: "k", mediaId: "m", srcStart, srcEnd, ...extra }])[0]!;
const spans = (p: Project, m: PrivacyMask) => projectMaskSpans(p, m);

describe("model", () => {
  it("sanitizer and legacy conversion match the fixture shared with layers_export.rs", () => {
    expect(sanitizeMasks(fixture.masks.input).map(strip)).toEqual(fixture.masks.expected);
    expect(migrateMasks(fixture.legacy.project as never).masks.map(strip)).toEqual(
      fixture.legacy.expected,
    );
    const { converted, dropped } = migrateMasks(fixture.legacy.project as never);
    expect([converted, dropped]).toEqual([1, 1]);
  });

  it("never throws on junk, caps at 200, defaults to a solid fill and enforces strength floors", () => {
    for (const junk of [null, 1, "x", {}, [null, [], { srcStart: "1" }]])
      expect(() => sanitizeMasks(junk)).not.toThrow();
    const many = Array.from({ length: 300 }, () => ({ mediaId: "m", srcStart: 0, srcEnd: 1 }));
    expect(sanitizeMasks(many)).toHaveLength(MAX_MASKS);
    expect(mask(0, 1).effect).toBe("solid");
    expect(mask(0, 1, { effect: "blur", strength: 2 }).strength).toBe(12);
    expect(mask(0, 1, { effect: "pixelate", strength: 2 }).strength).toBe(16);
  });
});

describe("every occurrence is masked, whatever the edit (derived spans)", () => {
  it("a duplicated then moved clip: both copies (review item 2)", () => {
    // Clips A [0,4) B [5,9) C [10,20): mask on B's source 5.5..7.
    const p0 = { ...deleteWords(base(), new Set(["w4", "w9"])), masks: [mask(5.5, 7)] };
    expect(spans(p0, p0.masks![0]!)).toEqual([[4.5, 6]]);
    const b = p0.segments[1]!.id;
    const dup = duplicateClip(p0, b); // A B B' C
    expect(dup.masks).toEqual(p0.masks); // never rewritten
    expect(spans(dup, dup.masks![0]!)).toEqual([
      [4.5, 6],
      [8.5, 10],
    ]);
    const moved = moveClip(dup, dup.segments[2]!.id, 0); // B' A B C
    expect(spans(moved, moved.masks![0]!)).toEqual([
      [0.5, 2],
      [8.5, 10],
    ]);
  });

  it("restoring words never unmasks (review item 3)", () => {
    const p = { ...base(), masks: [mask(3, 10)] };
    const cut = deleteWords(p, new Set(["w5", "w6"]));
    expect(spans(cut, cut.masks![0]!)).toEqual([[3, 8]]);
    const back = restoreWords(cut, new Set(["w5", "w6"]));
    expect(spans(back, back.masks![0]!)).toEqual([[3, 10]]);
  });

  it("a tiny mask at 4x and slivers left by edits are extended, never dropped (review item 4)", () => {
    const p = { ...base(), masks: [mask(1.0, 1.07)] };
    const fast = setSegmentTiming(p, p.segments[0]!.id, { speed: 4 });
    const [s] = spans(fast, fast.masks![0]!);
    expect(s![0]).toBeCloseTo(0.25, 9);
    expect(s![1] - s![0]).toBeCloseTo(MIN_SPAN_SEC, 9);
    // Cut 3..10 leaving 0.01 s slivers of a 2.99..10.01 mask on each side of the cut.
    const sliver = { ...deleteWords(base(), new Set(["w3", "w4", "w5", "w6", "w7", "w8", "w9"])) };
    const m = mask(2.99, 10.01);
    const [only] = maskOutputSpans(computeTimeline(sliver), m, sliver.media);
    expect(only![0]).toBeCloseTo(2.99, 9);
    expect(only![1]).toBeGreaterThanOrEqual(3.01);
  });

  it("speed and freeze frames", () => {
    const p = { ...base(), masks: [mask(18, 20)] };
    const held = setSegmentTiming(p, p.segments[0]!.id, { speed: 2, holdSec: 1 });
    expect(spans(held, held.masks![0]!)).toEqual([[9, 11]]); // 18..20 at 2x, then the 1 s hold
  });

  it("output-time edits map back to source; another source is refused", () => {
    const p = deleteWords(base(), new Set(["w4"])); // A [0,4) B [5,20)
    expect(sourceTimeAt(p, "m", 4.5)).toBeCloseTo(5.5, 9);
    expect(sourceTimeAt(p, "other", 4.5)).toBeNull();
    const m = makeMask(p, 4.5)!;
    expect([m.mediaId, m.srcStart, m.srcEnd, m.effect]).toEqual(["m", 5.5, 8.5, "solid"]);
    expect(maskFollowZoomOverlap(spans(p, m), [{ start: 0, end: 5, follow: true }])).toBe(true);
    expect(maskFollowZoomOverlap(spans(p, m), [{ start: 0, end: 5 }])).toBe(false);
  });
});

it("key caps are suppressed for presses under a mask and while one shows (review item 8)", () => {
  const p0 = base();
  const p: Project = {
    ...p0,
    cursor: {
      ...(p0.cursor ?? ({} as never)),
      tracks: {
        m: parseCursorLog(
          [
            '{"type":"key","t":0.5,"mods":["cmd"]}',
            '{"type":"key","t":3.5,"mods":["cmd"]}',
            '{"type":"key","t":8,"mods":["alt"]}',
          ].join("\n"),
        ),
      },
    } as never,
    masks: [mask(1, 4)],
  };
  const caps = keystrokeCaptions(p, { enabled: true, mode: "shortcuts" });
  expect(caps.map((c) => [c.start, c.end])).toEqual([
    [0.5, 1], // cut where the mask starts
    [8, 9],
  ]);
});

it("FCPXML says plainly that masks are not applied", () => {
  const p = { ...base(), masks: [mask(1, 2)] };
  expect(buildFcpxml(p).unsupported.join("\n")).toMatch(/PRIVACY MASKS NOT APPLIED \(1\)/);
});

describe("store", () => {
  beforeEach(() => {
    useProjectStore.getState().setProject(base());
    useProjectStore.temporal.getState().clear();
    useProjectStore.temporal.getState().resume();
    useUIStore.setState({ toasts: [] });
  });
  const history = () => useProjectStore.temporal.getState().pastStates.length;

  it("add / update / remove are one undo step each and refuse an empty span", () => {
    const s = useProjectStore.getState();
    const id = s.addMask(2)!;
    expect(useProjectStore.getState().project.masks![0]).toMatchObject({
      mediaId: "m",
      srcStart: 2,
      srcEnd: 5,
      effect: "solid",
    });
    expect(history()).toBe(1);
    s.updateMask(id, { effect: "pixelate", strength: 50 });
    expect(history()).toBe(2);
    s.updateMask(id, { srcEnd: 2 });
    expect(useProjectStore.getState().project.masks![0]!.srcEnd).toBe(5);
    expect(history()).toBe(2);
    useProjectStore.temporal.getState().undo();
    expect(useProjectStore.getState().project.masks![0]!.effect).toBe("solid");
    s.removeMask(id);
    expect("masks" in useProjectStore.getState().project).toBe(false);
  });

  it("old output-time masks are converted on load, with a warning", () => {
    const legacy = {
      ...base(),
      masks: [
        { id: "L", start: 2, end: 4 },
        { id: "Z", start: 90, end: 99 },
      ],
    };
    useProjectStore.getState().setProject(legacy as never);
    expect(useProjectStore.getState().project.masks).toEqual([
      expect.objectContaining({ id: "L", mediaId: "m", srcStart: 2, srcEnd: 4 }),
    ]);
    const toast = useUIStore.getState().toasts.at(-1)!;
    expect(toast.variant).toBe("destructive");
    expect(toast.description).toMatch(/1 covered nothing/);
  });
});

describe("second review", () => {
  it("the same file imported twice is one content: masked in both media items (P3)", () => {
    const p0 = base();
    const twin = { ...p0.media.m!, id: "m2" };
    const p: Project = {
      ...p0,
      media: { ...p0.media, m2: twin },
      segments: [...p0.segments, { ...p0.segments[0]!, id: "s2", mediaId: "m2" }],
      masks: [mask(1, 2)],
    };
    expect(duplicateSources(p.media, "m")).toEqual(["m2"]);
    expect(spans(p, p.masks![0]!)).toEqual([
      [1, 2],
      [21, 22],
    ]);
    // Different checksum and path: a different file, not masked.
    const other = { ...p, media: { ...p.media, m2: { ...twin, sha256: "y", path: "/tmp/o.mp4" } } };
    expect(spans(other, other.masks![0]!)).toEqual([[1, 2]]);
  });

  it("an overlay of masked footage is recognised by path or checksum (P11)", () => {
    const p = { ...base(), masks: [mask(1, 2)] };
    expect(masksOnOverlayFile(p, { path: "/tmp/m.mp4" })).toHaveLength(1);
    expect(masksOnOverlayFile(p, { path: "/elsewhere.mp4", sha256: "x" })).toHaveLength(1);
    expect(masksOnOverlayFile(p, { path: "/elsewhere.mp4", sha256: "z" })).toHaveLength(0);
  });

  it("a stored size under 1 % is rejected, not grown (P12); coverage samples all places up to 12", () => {
    expect(sanitizeMasks([{ mediaId: "m", srcStart: 0, srcEnd: 1, w: 0, h: 0 }])).toEqual([]);
    expect(sanitizeMasks([{ mediaId: "m", srcStart: 0, srcEnd: 1, w: 0.005, h: 0.5 }])).toEqual([]);
    expect([coveragePlaces(12), coveragePlaces(13)]).toEqual([12, 6]);
  });

  it("a probed size replaces a stale stored one without an undo step (C6)", () => {
    useProjectStore.getState().setProject(base());
    const p = useProjectStore.getState().project;
    useProjectStore.temporal.getState().clear();
    expect(
      useProjectStore
        .getState()
        .relinkMediaPath(p.id, "m", "/tmp/m.mp4", { width: 1080, height: 1920 }),
    ).toBe(true);
    expect(useProjectStore.getState().project.media.m).toMatchObject({ width: 1080, height: 1920 });
    expect(useProjectStore.temporal.getState().pastStates).toHaveLength(0);
  });
});

describe("third review", () => {
  it("same file: checksums decide when both are known, else paths (shared with Rust)", () => {
    for (const pair of fixture.contentPairs) expect(sameFile(pair.a, pair.b)).toBe(pair.same);
  });

  it("400 seeded random timelines: spans unchanged (Rust derives the same, layers_export.rs)", () => {
    expect(generateMaskSpanCases()).toEqual(parity);
  });

  it("a 1 ms mask and the 1 ms pieces of a legacy conversion are kept", () => {
    expect(sanitizeMasks([{ mediaId: "m", srcStart: 0.3, srcEnd: 0.301 }])).toHaveLength(1);
    // An old 2 ms output span on a 0.5x clip converts to a 1 ms source piece.
    const p = base();
    const slow = setSegmentTiming(p, p.segments[0]!.id, { speed: 0.5 });
    const { masks, converted, dropped } = migrateMasks({
      ...slow,
      masks: [{ id: "L", start: 0.6, end: 0.602 }] as never,
    });
    expect([masks.length, converted, dropped]).toEqual([1, 1, 0]);
    expect(masks[0]!.srcEnd - masks[0]!.srcStart).toBeCloseTo(0.001, 9);
  });

  it("an old project without checksums and a new import of the same path are one file", () => {
    const p0 = base();
    const old = { ...p0.media.m!, sha256: "" };
    const p: Project = {
      ...p0,
      media: { m: old, m2: { ...old, id: "m2", sha256: "f".repeat(64) } },
      segments: [...p0.segments, { ...p0.segments[0]!, id: "s2", mediaId: "m2" }],
      masks: [mask(1, 2)],
    };
    expect(spans(p, p.masks![0]!)).toHaveLength(2);
  });
});

it("final gate: a recording overwritten at the same path and imported again is one file", () => {
  const p0 = base();
  const old = { ...p0.media.m!, sha256: "a".repeat(64) };
  const p: Project = {
    ...p0,
    media: { m: old, m2: { ...old, id: "m2", sha256: "b".repeat(64) } },
    segments: [...p0.segments, { ...p0.segments[0]!, id: "s2", mediaId: "m2" }],
    masks: [mask(1, 2)],
  };
  expect(spans(p, p.masks![0]!)).toHaveLength(2);
  expect(duplicateSources(p.media, "m")).toEqual(["m2"]);
});

describe("wave-2 integration", () => {
  it("a voice-over insert hold of masked footage is covered, and later spans move by the take", () => {
    const takeMedia: SourceMedia = {
      ...media,
      id: "take",
      path: "/take.m4a",
      duration: 3,
      fps: 0,
      width: 0,
      height: 0,
      sha256: "t",
    };
    const { project } = addVoiceOverTake(base(), {
      media: takeMedia,
      at: 4,
      mode: "insert",
      overrideOriginal: false,
    });
    // The held anchor frame (source 4) is on screen from output 4 to 7.
    const held = spans(project, mask(3.5, 4.2));
    expect(held[0]![0]).toBeCloseTo(3.5);
    expect(held[held.length - 1]![1]).toBeCloseTo(7.2);
    expect(held).toHaveLength(1);
    // Later footage moved by the take; a mask before the anchor does not cover the hold.
    expect(spans(project, mask(10, 11))[0]![0]).toBeCloseTo(13);
    expect(spans(project, mask(1, 2))).toEqual([[1, 2]]);
  });

  it("named key caps (key identity) under a mask are suppressed", () => {
    const p0 = base();
    const p: Project = {
      ...p0,
      cursor: {
        ...(p0.cursor ?? ({} as never)),
        tracks: {
          m: parseCursorLog(
            [
              '{"type":"key","t":0.5,"mods":["cmd"],"name":"k"}',
              '{"type":"key","t":2,"mods":["cmd"],"name":"p"}',
              '{"type":"key","t":2.5,"secure":true}',
            ].join("\n"),
          ),
        },
      } as never,
      masks: [mask(1.5, 3)],
    };
    const caps = keystrokeCaptions(p, { enabled: true, mode: "all" });
    expect(caps.map((c) => c.caps.join(" "))).toEqual(["⌘ K"]);
  });
});
