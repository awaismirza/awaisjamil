import { loadRecordingCursorTrack } from "@/lib/cursorImport";
import { parseCursorLog, type CursorTrack } from "@/lib/cursor";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { appendRecordingToProject } from "@/stores/recordingStore";
import { newProject, totalDuration, type Word } from "@/lib/edl";
import { useProjectStore } from "@/stores/projectStore";
import { useSettingsStore } from "@/stores/settingsStore";
import { useUIStore } from "@/stores/uiStore";
import {
  probeMedia as importMedia,
  listModels,
  transcribe,
  detectPauses,
  hashMedia,
} from "@/lib/ipc";
vi.mock("@/lib/cursorImport", () => ({ loadRecordingCursorTrack: vi.fn() }));
vi.mock("@/lib/ipc", () => ({
  probeMedia: vi.fn(),
  hashMedia: vi.fn(),
  listModels: vi.fn(),
  transcribe: vi.fn(),
  detectPauses: vi.fn(),
}));
const media = {
  id: "take",
  path: "/take.mp4",
  duration: 3,
  width: 1920,
  height: 1080,
  fps: 30,
  audioSampleRate: 48000,
  sha256: "take",
};
const words: Word[] = [0, 1, 2].map((i) => ({
  id: `w${i}`,
  text: `word${i}`,
  start: i,
  end: i + 1,
  confidence: 1,
}));
let resolveTranscript: (value: { mediaId: string; words: Word[]; engine: "whisper-cpp" }) => void;
beforeEach(() => {
  vi.clearAllMocks();
  localStorage.clear();
  useProjectStore.setState({ project: newProject("recorded"), dirty: false, filePath: null });
  useSettingsStore.getState().setRecording({ autoTranscribe: true, markersBecomeChapters: true });
  useUIStore.setState({ transcribeProgress: null, backgroundTranscriptions: {}, toasts: [] });
  vi.mocked(importMedia).mockResolvedValue(media);
  vi.mocked(hashMedia).mockRejectedValue(new Error("not hashed in these tests"));
  vi.mocked(listModels).mockResolvedValue([
    { name: "tiny", installed: true, sizeMb: 1, engine: "whisper-cpp" },
  ] as Awaited<ReturnType<typeof listModels>>);
  vi.mocked(transcribe).mockImplementation(
    () =>
      new Promise((resolve) => {
        resolveTranscript = resolve;
      }),
  );
  vi.mocked(detectPauses).mockResolvedValue([]);
});
async function finish() {
  resolveTranscript({ mediaId: media.id, words, engine: "whisper-cpp" });
  await vi.waitFor(() => expect(useUIStore.getState().backgroundTranscriptions).toEqual({}));
}
describe("recording becomes playable before recognition finishes", () => {
  it("keeps media immediately playable and rebases delayed cursor data through trim/undo", async () => {
    useSettingsStore.getState().setRecording({ autoTranscribe: false });
    useProjectStore.temporal.getState().clear();
    let resolveCursor!: (track: CursorTrack) => void;
    vi.mocked(loadRecordingCursorTrack).mockImplementation(
      () =>
        new Promise((resolve) => {
          resolveCursor = resolve;
        }),
    );
    await appendRecordingToProject(media.path, [], "/take/events.jsonl");
    expect(totalDuration(useProjectStore.getState().project)).toBe(3);
    expect(useProjectStore.getState().project.cursor?.tracks.take).toBeUndefined();
    const segment = useProjectStore.getState().project.segments[0];
    useProjectStore.getState().trimClip(segment.id, "start", 1);
    resolveCursor(parseCursorLog('{"type":"move","t":1,"x":0.4,"y":0.5}'));
    await vi.waitFor(() =>
      expect(useProjectStore.getState().project.cursor?.tracks.take.points).toHaveLength(1),
    );
    expect(useProjectStore.getState().project.segments[0].sourceIn).toBe(1);
    useProjectStore.temporal.getState().undo();
    expect(useProjectStore.getState().project.segments[0].sourceIn).toBe(0);
    expect(useProjectStore.getState().project.cursor?.tracks.take.points).toHaveLength(1);
  });
  it("keeps cursor data on a take restored after undoing its append", async () => {
    useSettingsStore.getState().setRecording({ autoTranscribe: false });
    useProjectStore.temporal.getState().clear();
    let resolveCursor!: (track: CursorTrack) => void;
    vi.mocked(loadRecordingCursorTrack).mockImplementation(
      () =>
        new Promise((resolve) => {
          resolveCursor = resolve;
        }),
    );
    await appendRecordingToProject(media.path, [], "/take/events.jsonl");
    useProjectStore.temporal.getState().undo();
    expect(useProjectStore.getState().project.segments).toHaveLength(0);
    resolveCursor(parseCursorLog('{"type":"move","t":1,"x":0.4,"y":0.5}'));
    await vi.waitFor(() =>
      expect(
        useProjectStore.temporal
          .getState()
          .futureStates.some((s) => !!s.project?.cursor?.tracks.take),
      ).toBe(true),
    );
    useProjectStore.temporal.getState().redo();
    expect(useProjectStore.getState().project.cursor?.tracks.take.points).toHaveLength(1);
  });
  it("keeps the recording playable if cursor data fails to load", async () => {
    useSettingsStore.getState().setRecording({ autoTranscribe: false });
    vi.mocked(loadRecordingCursorTrack).mockRejectedValue(new Error("missing log"));
    await appendRecordingToProject(media.path, [], "/take/events.jsonl");
    await vi.waitFor(() =>
      expect(useUIStore.getState().toasts.at(-1)?.title).toBe(
        "Recording added without cursor data",
      ),
    );
    expect(totalDuration(useProjectStore.getState().project)).toBe(3);
  });
  it("aborts cursor import when the document changes", async () => {
    useSettingsStore.getState().setRecording({ autoTranscribe: false });
    let resolveCursor!: (track: CursorTrack) => void;
    vi.mocked(loadRecordingCursorTrack).mockImplementation(
      () =>
        new Promise((resolve) => {
          resolveCursor = resolve;
        }),
    );
    await appendRecordingToProject(media.path, [], "/take/events.jsonl");
    const signal = vi.mocked(loadRecordingCursorTrack).mock.calls[0][1];
    const other = newProject("other");
    useProjectStore.setState({ project: other });
    expect(signal.aborted).toBe(true);
    resolveCursor(parseCursorLog('{"type":"move","t":1,"x":0.4,"y":0.5}'));
    await Promise.resolve();
    await Promise.resolve();
    expect(useProjectStore.getState().project).toBe(other);
  });
  it("publishes media and markers immediately, and adds words later without resetting an intervening trim", async () => {
    await appendRecordingToProject(media.path, [1]);
    expect(totalDuration(useProjectStore.getState().project)).toBe(3);
    expect(useProjectStore.getState().project.chapters?.[0].outputTime).toBe(1);
    expect(useProjectStore.getState().project.segments[0].words).toEqual([]);
    expect(useUIStore.getState().transcribeProgress).toBeNull();
    const segment = useProjectStore.getState().project.segments[0];
    useProjectStore.getState().trimClip(segment.id, "start", 1);
    useProjectStore.getState().rename("edited while recognizing");
    await finish();
    const p = useProjectStore.getState().project;
    expect(p.name).toBe("edited while recognizing");
    expect(p.segments[0].sourceIn).toBe(1);
    expect(p.segments[0].words.map((w) => w.id)).toEqual(["w1", "w2"]);
    expect(p.originalTranscripts?.take).toEqual(words);
  });
  it("does not append to a different project if the user switches during import", async () => {
    let resolveImport!: (value: typeof media) => void;
    vi.mocked(importMedia).mockImplementation(
      () =>
        new Promise((resolve) => {
          resolveImport = resolve;
        }),
    );
    const pending = appendRecordingToProject(media.path);
    useProjectStore.setState({ project: newProject("other") });
    resolveImport(media);
    await pending;
    expect(useProjectStore.getState().project.segments).toEqual([]);
    expect(transcribe).not.toHaveBeenCalled();
  });
  it("keeps a new document untouched if background words arrive after switching", async () => {
    await appendRecordingToProject(media.path);
    const next = newProject("other");
    useProjectStore.setState({ project: next });
    await finish();
    expect(useProjectStore.getState().project).toBe(next);
  });
  it("keeps the already playable recording after a transcription failure", async () => {
    vi.mocked(transcribe).mockRejectedValue(new Error("recognizer failed"));
    await appendRecordingToProject(media.path);
    await vi.waitFor(() => expect(useUIStore.getState().backgroundTranscriptions).toEqual({}));
    expect(totalDuration(useProjectStore.getState().project)).toBe(3);
    expect(useUIStore.getState().toasts.at(-1)?.title).toBe("Recording kept; transcription failed");
  });
});
