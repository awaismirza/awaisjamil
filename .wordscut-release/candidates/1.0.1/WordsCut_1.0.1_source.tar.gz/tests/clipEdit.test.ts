import { describe, expect, it } from "vitest";
import {
  addChapter,
  addMediaWithTranscript,
  computeTimeline,
  deleteWords,
  newProject,
  projectChapters,
  totalDuration,
  type Project,
  type SourceMedia,
  type Word,
} from "@/lib/edl";
import {
  deleteClip,
  edgeLimits,
  listClips,
  MIN_CLIP_SEC,
  rollEdit,
  snapCandidates,
  snapTo,
  splitClipAt,
  trimClipEdge,
} from "@/lib/clipEdit";

function media(duration: number): SourceMedia {
  return {
    id: "m",
    path: "/tmp/m.mp4",
    duration,
    fps: 30,
    width: 1920,
    height: 1080,
    audioSampleRate: 48000,
    sha256: "x",
  };
}

/** w0..w9, one per second: w{i} spans [i, i+1]. */
const WORDS: Word[] = Array.from({ length: 10 }, (_, i) => ({
  id: `w${i}`,
  text: `w${i}`,
  start: i,
  end: i + 1,
  confidence: 1,
}));

function base(): Project {
  const p = addMediaWithTranscript(newProject("t"), media(10), WORDS);
  return { ...p, settings: { ...p.settings, paddingMs: 0 } };
}

/** w3 and w4 deleted: clips [0,3] (w0-w2) and [5,10] (w5-w9). */
function cut(): Project {
  return deleteWords(base(), new Set(["w3", "w4"]));
}

const ids = (p: Project, k: number) => p.segments[k]!.words.map((w) => w.id);

describe("edgeLimits", () => {
  it("stops an edge at the neighbouring clip and at the media", () => {
    const p = cut();
    const [a, b] = p.segments;
    expect(edgeLimits(p, a!.id, "start")).toEqual({ min: 0, max: 3 - MIN_CLIP_SEC });
    expect(edgeLimits(p, a!.id, "end")).toEqual({ min: 0 + MIN_CLIP_SEC, max: 5 });
    expect(edgeLimits(p, b!.id, "start")).toEqual({ min: 3, max: 10 - MIN_CLIP_SEC });
    expect(edgeLimits(p, b!.id, "end")).toEqual({ min: 5 + MIN_CLIP_SEC, max: 10 });
  });

  it("is null for an unknown clip", () => {
    expect(edgeLimits(cut(), "nope", "end")).toBeNull();
  });
});

describe("trimClipEdge", () => {
  it("extends a clip over audio the transcript had dropped, bringing the words back", () => {
    const p = cut();
    const out = trimClipEdge(p, p.segments[0]!.id, "end", 5, WORDS);
    expect(out.segments[0]!.sourceOut).toBe(5);
    expect(ids(out, 0)).toEqual(["w0", "w1", "w2", "w3", "w4"]);
    expect(totalDuration(out)).toBeCloseTo(10, 9);
  });

  it("extends over audio with no words and keeps the words it has", () => {
    // No original transcript to draw from: only the range grows.
    const p = cut();
    const out = trimClipEdge(p, p.segments[0]!.id, "end", 4);
    expect(out.segments[0]!.sourceOut).toBe(4);
    expect(ids(out, 0)).toEqual(["w0", "w1", "w2"]);
  });

  it("trims inward and drops the words that fall outside", () => {
    const p = base();
    const out = trimClipEdge(p, p.segments[0]!.id, "start", 1.2);
    expect(out.segments[0]!.sourceIn).toBe(1.2);
    expect(ids(out, 0)[0]).toBe("w1"); // w0's midpoint 0.5 is before 1.2; w1's 1.5 is after
    expect(totalDuration(out)).toBeCloseTo(8.8, 9);
  });

  it("clamps at the neighbour so no audio plays twice", () => {
    const p = cut();
    const out = trimClipEdge(p, p.segments[0]!.id, "end", 9, WORDS);
    expect(out.segments[0]!.sourceOut).toBe(5);
  });

  it("clamps at the start and end of the media", () => {
    const p = base();
    expect(trimClipEdge(p, p.segments[0]!.id, "start", -4).segments[0]!.sourceIn).toBe(0);
    expect(trimClipEdge(p, p.segments[0]!.id, "end", 99).segments[0]!.sourceOut).toBe(10);
  });

  it("never makes a clip shorter than the minimum", () => {
    const p = base();
    const out = trimClipEdge(p, p.segments[0]!.id, "end", -1);
    expect(out.segments[0]!.sourceOut - out.segments[0]!.sourceIn).toBeCloseTo(MIN_CLIP_SEC, 9);
  });

  it("returns the same project when nothing changes", () => {
    const p = base();
    expect(trimClipEdge(p, p.segments[0]!.id, "end", 10)).toBe(p);
    expect(trimClipEdge(p, "nope", "end", 5)).toBe(p);
    expect(trimClipEdge(p, p.segments[0]!.id, "end", Number.NaN)).toBe(p);
  });

  it("never mutates a word or the input project", () => {
    const p = cut();
    const before = JSON.stringify(p);
    const wordsBefore = JSON.stringify(WORDS);
    trimClipEdge(p, p.segments[0]!.id, "end", 5, WORDS);
    expect(JSON.stringify(p)).toBe(before);
    expect(JSON.stringify(WORDS)).toBe(wordsBefore);
  });

  it("moves later chapters with their content", () => {
    let p = cut(); // output: clip A 0-3, clip B 3-8
    p = addChapter(p, 6, "later"); // inside clip B
    const out = trimClipEdge(p, p.segments[0]!.id, "end", 5, WORDS); // A grows by 2 s
    expect(projectChapters(out)[0]!.outputTime).toBeCloseTo(8, 9);
  });

  it("does not let two clips own the same word", () => {
    const p = cut();
    const out = trimClipEdge(p, p.segments[0]!.id, "end", 5, WORDS);
    const all = out.segments.flatMap((s) => s.words.map((w) => w.id));
    expect(new Set(all).size).toBe(all.length);
  });
});

describe("splitClipAt", () => {
  it("splits into two touching clips without changing the length", () => {
    const p = base();
    const out = splitClipAt(p, 4.6);
    expect(out.segments).toHaveLength(2);
    expect(out.segments[0]!.sourceOut).toBe(4.6);
    expect(out.segments[1]!.sourceIn).toBe(4.6);
    expect(totalDuration(out)).toBe(totalDuration(p));
    expect(ids(out, 0)).toEqual(["w0", "w1", "w2", "w3", "w4"]);
    expect(ids(out, 1)).toEqual(["w5", "w6", "w7", "w8", "w9"]);
  });

  it("splits a later clip at the right source time", () => {
    const out = splitClipAt(cut(), 4); // output 4 = source 6 in clip B
    expect(out.segments).toHaveLength(3);
    expect(out.segments[1]!.sourceOut).toBe(6);
    expect(out.segments[2]!.sourceIn).toBe(6);
  });

  it("does nothing on an edge, past the end or too near an end", () => {
    const p = base();
    expect(splitClipAt(p, 0)).toBe(p);
    expect(splitClipAt(p, 10)).toBe(p);
    expect(splitClipAt(p, 99)).toBe(p);
    expect(splitClipAt(p, 0.01)).toBe(p);
  });

  it("gives a word to the clip that holds its midpoint, never to both", () => {
    // w4 spans 4-5, midpoint 4.5: a split exactly at 4.5 puts it on the right.
    const out = splitClipAt(base(), 4.5);
    expect(ids(out, 0)).not.toContain("w4");
    expect(ids(out, 1)).toContain("w4");
  });

  it("is not a cut, so no word is lost", () => {
    const out = splitClipAt(base(), 3.3);
    expect(
      out.segments
        .flatMap((s) => s.words)
        .map((w) => w.id)
        .sort(),
    ).toEqual(WORDS.map((w) => w.id).sort());
  });
});

describe("deleteClip", () => {
  it("removes a clip and closes the gap", () => {
    const p = cut();
    const out = deleteClip(p, p.segments[0]!.id);
    expect(out.segments).toHaveLength(1);
    expect(totalDuration(out)).toBeCloseTo(5, 9);
    expect(computeTimeline(out)[0]!.outputStart).toBe(0);
  });

  it("never empties the project", () => {
    const p = base();
    expect(deleteClip(p, p.segments[0]!.id)).toBe(p);
  });

  it("ignores an unknown clip", () => {
    const p = cut();
    expect(deleteClip(p, "nope")).toBe(p);
  });
});

describe("rollEdit", () => {
  it.each([1, -1])("rolls a touching split atomically by %s and transfers its words", (delta) => {
    const p = splitClipAt(base(), 5);
    const out = rollEdit(p, p.segments[0]!.id, delta);
    expect(out.segments[0]!.sourceOut).toBe(5 + delta);
    expect(out.segments[1]!.sourceIn).toBe(5 + delta);
    expect(totalDuration(out)).toBe(totalDuration(p));
    expect(out.segments.flatMap((s) => s.words.map((w) => w.id))).toEqual(WORDS.map((w) => w.id));
    expect(p.segments[0]!.sourceOut).toBe(5);
  });

  it.each([100, -100])("clamps both touching edges jointly for delta %s", (delta) => {
    const p = splitClipAt(base(), 5);
    const out = rollEdit(p, p.segments[0]!.id, delta);
    expect(out.segments[0]!.sourceOut).toBeCloseTo(delta > 0 ? 10 - MIN_CLIP_SEC : MIN_CLIP_SEC);
    expect(out.segments[0]!.sourceOut).toBe(out.segments[1]!.sourceIn);
    expect(totalDuration(out)).toBeCloseTo(10);
    out.segments.forEach((s) =>
      expect(s.sourceOut - s.sourceIn).toBeGreaterThanOrEqual(MIN_CLIP_SEC - 1e-9),
    );
  });

  it("restores each media's own words across a cross-media roll", () => {
    const aWord = { ...WORDS[3]!, id: "a-original" };
    const bWord = { ...WORDS[6]!, id: "b-original" };
    const p = {
      ...base(),
      media: { ...base().media, b: { ...media(10), id: "b" } },
      segments: [
        { id: "a", mediaId: "m", sourceIn: 0, sourceOut: 3, words: [] },
        { id: "b", mediaId: "b", sourceIn: 5, sourceOut: 10, words: [] },
      ],
    };
    const out = rollEdit(p, "a", 1, { m: [aWord], b: [bWord] });
    expect(out.segments[0]!.words).toEqual([aWord]);
    expect(out.segments[1]!.words).toEqual([bWord]);
    const legacy = rollEdit(p, "a", 1, [aWord, bWord]);
    expect(legacy.segments[1]!.words).toEqual([]);
  });

  it("recovers deleted words from a per-media originals map", () => {
    const p = cut();
    const out = rollEdit(p, p.segments[0]!.id, 1, { m: WORDS });
    expect(ids(out, 0)).toEqual(["w0", "w1", "w2", "w3"]);
    expect(ids(out, 1)).toEqual(["w6", "w7", "w8", "w9"]);
    expect(totalDuration(out)).toBe(totalDuration(p));
  });

  it("moves the cut without changing the length", () => {
    const p = cut(); // A [0,3], B [5,10]
    const out = rollEdit(p, p.segments[0]!.id, 0.5);
    expect(out.segments[0]!.sourceOut).toBe(3.5);
    expect(out.segments[1]!.sourceIn).toBe(5.5);
    expect(totalDuration(out)).toBeCloseTo(totalDuration(p), 9);
  });

  it("rolls the other way", () => {
    const p = cut();
    const out = rollEdit(p, p.segments[0]!.id, -0.5);
    expect(out.segments[0]!.sourceOut).toBe(2.5);
    expect(out.segments[1]!.sourceIn).toBe(4.5);
  });

  it("is limited by the clip that would run out of room", () => {
    // B can only start 4.96 s later before it is down to the minimum length.
    const p = cut();
    const out = rollEdit(p, p.segments[0]!.id, 50);
    expect(out.segments[1]!.sourceOut - out.segments[1]!.sourceIn).toBeGreaterThanOrEqual(
      MIN_CLIP_SEC - 1e-9,
    );
    expect(totalDuration(out)).toBeCloseTo(totalDuration(p), 9);
  });

  it("does nothing for the last clip or a zero delta", () => {
    const p = cut();
    expect(rollEdit(p, p.segments[1]!.id, 1)).toBe(p);
    expect(rollEdit(p, p.segments[0]!.id, 0)).toBe(p);
  });
});

describe("snapping", () => {
  it("excludes other media's word times from fallback candidates", () => {
    const p = addMediaWithTranscript(base(), { ...media(10), id: "other" }, [
      { ...WORDS[0]!, id: "other-word", start: 0.123, end: 0.456 },
    ]);
    const candidates = snapCandidates(p, "m");
    expect(candidates).not.toContain(0.123);
    expect(candidates).not.toContain(0.456);
    expect(candidates).toContain(1);
  });

  it("snaps to the nearest candidate inside the tolerance", () => {
    expect(snapTo(4.93, [3, 5, 7], 0.1)).toBe(5);
    expect(snapTo(4.6, [3, 5, 7], 0.1)).toBeNull();
    expect(snapTo(4.9, [4.85, 5], 0.2)).toBe(4.85); // the nearer of two in range
  });

  it("offers word edges and the other clips' edges, but not the clip being dragged", () => {
    const p = cut();
    const c = snapCandidates(p, "m", WORDS, p.segments[0]!.id);
    expect(c).toContain(3); // w2 end
    expect(c).toContain(5); // clip B start
    expect(c).not.toContain(0.04);
    // Clip A's own edges (0 and 3) still appear as word edges, but its range edge is not added twice.
    expect(new Set(c).size).toBe(c.length);
  });
});

describe("listClips", () => {
  it("describes each clip on both timelines", () => {
    const c = listClips(cut());
    expect(c).toHaveLength(2);
    expect(c[0]).toMatchObject({
      sourceIn: 0,
      sourceOut: 3,
      outputStart: 0,
      outputEnd: 3,
      wordCount: 3,
    });
    expect(c[1]).toMatchObject({
      sourceIn: 5,
      sourceOut: 10,
      outputStart: 3,
      outputEnd: 8,
      wordCount: 5,
    });
  });
});

describe("invariants under random clip edits", () => {
  function rng(seed: number) {
    let s = seed;
    return () => {
      s = (s * 1664525 + 1013904223) % 4294967296;
      return s / 4294967296;
    };
  }

  it("keeps clips ordered, inside the media, with unique words and a consistent length", () => {
    for (let seed = 1; seed <= 40; seed++) {
      const r = rng(seed);
      let p = base();
      for (let step = 0; step < 30; step++) {
        const clips = p.segments;
        const pick = clips[Math.floor(r() * clips.length)]!;
        const op = Math.floor(r() * 5);
        if (op === 0) p = trimClipEdge(p, pick.id, "start", r() * 10, WORDS);
        else if (op === 1) p = trimClipEdge(p, pick.id, "end", r() * 10, WORDS);
        else if (op === 2) p = splitClipAt(p, r() * totalDuration(p));
        else if (op === 3) p = deleteClip(p, pick.id);
        else p = rollEdit(p, pick.id, (r() - 0.5) * 3, WORDS);

        let sum = 0;
        const seen = new Set<string>();
        p.segments.forEach((s, k) => {
          expect(s.sourceIn).toBeGreaterThanOrEqual(0);
          expect(s.sourceOut).toBeLessThanOrEqual(10 + 1e-9);
          expect(s.sourceOut - s.sourceIn).toBeGreaterThanOrEqual(MIN_CLIP_SEC - 1e-9);
          if (k > 0) expect(s.sourceIn).toBeGreaterThanOrEqual(p.segments[k - 1]!.sourceOut - 1e-9);
          sum += s.sourceOut - s.sourceIn;
          for (const w of s.words) {
            const m = (w.start + w.end) / 2;
            expect(m).toBeGreaterThanOrEqual(s.sourceIn - 1e-9);
            expect(m).toBeLessThan(s.sourceOut + 1e-9);
            expect(seen.has(w.id)).toBe(false);
            seen.add(w.id);
          }
        });
        expect(totalDuration(p)).toBeCloseTo(sum, 9);
      }
    }
  });
});
