import { describe, it, expect } from "vitest";
import { buildFcpxml, frameDuration } from "@/lib/fcpxml";
import { newProject, type Project, type SourceMedia } from "@/lib/edl";

const media = (id: string, fps = 30000 / 1001, extra: Partial<SourceMedia> = {}): SourceMedia => ({
  id,
  path: `/tmp/my clip ${id}&.mp4`,
  duration: 60,
  fps,
  width: 1920,
  height: 1080,
  audioSampleRate: 48000,
  sha256: "x",
  ...extra,
});
const seg = (id: string, mediaId: string, a: number, b: number) => ({
  id,
  mediaId,
  words: [],
  sourceIn: a,
  sourceOut: b,
});

function proj(): Project {
  const p = newProject("Demo <1>");
  p.media = { m1: media("m1"), m2: media("m2") };
  p.segments = [seg("s1", "m2", 10, 12), seg("s2", "m1", 0, 1.5), seg("s3", "m1", 0, 1.5)];
  return p;
}
const parse = (xml: string) => new DOMParser().parseFromString(xml, "application/xml");

describe("fcpxml", () => {
  it("is well-formed", () => {
    const doc = parse(buildFcpxml(proj()).xml);
    expect(doc.getElementsByTagName("parsererror")).toHaveLength(0);
    expect(doc.documentElement.getAttribute("version")).toBe("1.10");
  });

  it("maps frame rates to rational frame durations", () => {
    expect(frameDuration(29.97)).toEqual([1001, 30000]);
    expect(frameDuration(23.976)).toEqual([1001, 24000]);
    expect(frameDuration(25)).toEqual([1, 25]);
  });

  it("writes frame-aligned rational times in EDL order, repeats and multiple sources", () => {
    const doc = parse(buildFcpxml(proj()).xml);
    const clips = [...doc.querySelectorAll("spine > asset-clip")];
    expect(clips.map((c) => c.getAttribute("ref"))).toEqual(["a_m2", "a_m1", "a_m1"]);
    for (const c of clips) {
      for (const a of ["offset", "start", "duration"]) {
        const v = c.getAttribute(a)!;
        expect(v).toMatch(/^(0s|\d+\/30000s)$/);
        if (v !== "0s") expect(parseInt(v) % 1001).toBe(0);
      }
    }
    // 2s -> 60 frames, then 1.5s -> 45 frames; offsets contiguous
    expect(clips[0]!.getAttribute("duration")).toBe("60060/30000s");
    expect(clips[1]!.getAttribute("offset")).toBe("60060/30000s");
    expect(clips[2]!.getAttribute("offset")).toBe("105105/30000s");
    expect(clips[1]!.getAttribute("start")).toBe(clips[2]!.getAttribute("start"));
    expect(doc.querySelectorAll("asset")).toHaveLength(2);
    expect(doc.querySelector("asset media-rep")!.getAttribute("src")).toContain("my%20clip");
  });

  it("emits chapters as markers and escapes titles", () => {
    const p = proj();
    p.chapters = [{ id: "c", outputTime: 2.5, title: 'A "b" <c>' }];
    const doc = parse(buildFcpxml(p).xml);
    const m = doc.querySelectorAll("chapter-marker");
    expect(m).toHaveLength(1);
    expect(m[0]!.getAttribute("value")).toBe('A "b" <c>');
    expect(m[0]!.parentElement!.getAttribute("offset")).toBe("60060/30000s");
  });

  it("adds music with gain and reports unsupported features", () => {
    const p = proj();
    p.media.mu = media("mu", 30, { width: 0, height: 0 });
    p.audioTracks = [{ id: "t", mediaId: "mu", gainDb: -6, offsetSec: 0, ducks: true }];
    p.scene = { enabled: true } as Project["scene"];
    p.zoomRegions = [{ id: "z" } as never];
    p.cursor = { tracks: { m1: {} } } as never;
    const { xml, unsupported } = buildFcpxml(p);
    const doc = parse(xml);
    expect(doc.querySelector('asset-clip[lane="-1"] adjust-volume')!.getAttribute("amount")).toBe(
      "-6dB",
    );
    expect(unsupported.join("|")).toMatch(/Scene.*Zoom regions.*Cursor.*ducking/);
    expect(buildFcpxml(proj()).unsupported).toEqual([]);
  });

  it("does not drift: 100 x 0.35 s at 30 fps totals exactly 1050 frames", () => {
    const p = newProject("drift");
    p.media = { m1: media("m1", 30, { duration: 600 }) };
    p.segments = Array.from({ length: 100 }, (_, i) => seg(`s${i}`, "m1", i, i + 0.35));
    const doc = parse(buildFcpxml(p).xml);
    const clips = [...doc.querySelectorAll("spine > asset-clip")];
    const f = (v: string) => (v === "0s" ? 0 : parseInt(v));
    const last = clips[clips.length - 1]!;
    expect(f(last.getAttribute("offset")!) + f(last.getAttribute("duration")!)).toBe(1050);
    expect(f(doc.querySelector("sequence")!.getAttribute("duration")!)).toBe(1050);
  });

  it("drops sub-frame segments and reports them", () => {
    const p = newProject("tiny");
    p.media = { m1: media("m1", 30) };
    p.segments = [seg("a", "m1", 0, 1), seg("b", "m1", 2, 2.01), seg("c", "m1", 3, 4)];
    const r = buildFcpxml(p);
    expect(parse(r.xml).querySelectorAll("spine > asset-clip")).toHaveLength(2);
    expect(r.unsupported.join()).toContain("shorter than one frame");
  });

  it("keeps clips inside the asset", () => {
    const p = newProject("edge");
    p.media = { m1: media("m1", 30, { duration: 10 }) };
    p.segments = [seg("a", "m1", 5, 10)];
    const c = parse(buildFcpxml(p).xml).querySelector("spine > asset-clip")!;
    const f = (a: string) => (c.getAttribute(a) === "0s" ? 0 : parseInt(c.getAttribute(a)!));
    expect(f("start") + f("duration")).toBeLessThanOrEqual(300);
  });

  it("snaps an odd frame rate to a standard one and says so", () => {
    expect(frameDuration(59.87)).toEqual([1001, 60000]);
    const p = newProject("odd");
    p.media = { m1: media("m1", 59.87) };
    p.segments = [seg("a", "m1", 0, 1)];
    const r = buildFcpxml(p);
    expect(r.xml).toContain('frameDuration="1001/60000s"');
    expect(r.unsupported.join()).toContain("snapped");
  });

  it("strips illegal control chars, keeps asset ids unique, and never prints undefined", () => {
    const p = newProject("x\u0001y");
    p.media = {
      "a b": media("a b", 30, { path: "/t/a\u0002.mp4", audioSampleRate: 0 }),
      "a_b": media("a_b", 30),
    };
    p.segments = [seg("a", "a b", 0, 1), seg("b", "a_b", 0, 1)];
    p.audioTracks = [
      { id: "t", mediaId: "a_b", offsetSec: 0, gainDb: undefined as unknown as number } as never,
    ];
    const r = buildFcpxml(p);
    const doc = parse(r.xml);
    expect(doc.getElementsByTagName("parsererror")).toHaveLength(0);
    const ids = [...doc.querySelectorAll("asset")].map((a) => a.getAttribute("id"));
    expect(new Set(ids).size).toBe(2);
    expect(r.xml).not.toContain("undefined");
    expect(doc.querySelector("asset")!.hasAttribute("hasAudio")).toBe(false);
  });
});
