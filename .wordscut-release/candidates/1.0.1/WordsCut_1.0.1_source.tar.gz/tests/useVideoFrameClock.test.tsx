import { renderHook } from "@testing-library/react";
import { afterEach, expect, it, vi } from "vitest";
import { useVideoFrameClock } from "@/hooks/useVideoFrameClock";
afterEach(() => vi.useRealTimers());
it("uses the audio fallback even when the media element exposes rVFC", () => {
  vi.useFakeTimers();
  const video = document.createElement("video");
  video.currentTime = 2;
  const rvfc = vi.fn();
  Object.defineProperty(video, "requestVideoFrameCallback", { value: rvfc });
  const tick = vi.fn(),
    ref = { current: video };
  const { unmount } = renderHook(() => useVideoFrameClock(ref, tick, true, false));
  vi.advanceTimersByTime(35);
  expect(tick).toHaveBeenCalledWith(2);
  expect(rvfc).not.toHaveBeenCalled();
  unmount();
  const count = tick.mock.calls.length;
  vi.advanceTimersByTime(35);
  expect(tick).toHaveBeenCalledTimes(count);
});
