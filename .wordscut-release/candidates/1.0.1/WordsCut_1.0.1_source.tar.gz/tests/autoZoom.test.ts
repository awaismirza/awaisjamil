import { describe, expect, it } from "vitest";
import { generateAutoZoom } from "@/lib/autoZoom";
import { parseCursorLog } from "@/lib/cursor";
import type { TimelineEntry } from "@/lib/edl";
import { MIN_REGION_SEC } from "@/lib/zoom";
import { cursorFixtureKinds, syntheticCursorLog } from "./fixtures/cursorLogs";
const entry = (
  sourceIn = 0,
  sourceOut = 20,
  outputStart = 0,
  mediaId = "m",
  segmentId = "s",
): TimelineEntry => ({
  mediaId,
  segmentId,
  sourceIn,
  sourceOut,
  outputStart,
  outputEnd: outputStart + sourceOut - sourceIn,
});
describe("automatic zoom proposals", () => {
  it.each(cursorFixtureKinds)("is valid, deterministic and nonoverlapping for %s", (kind) => {
    const tracks = { m: parseCursorLog(syntheticCursorLog(kind)) };
    for (const sensitivity of ["low", "medium", "high"] as const) {
      const regions = generateAutoZoom(tracks, [entry()], { sensitivity });
      expect(regions).toEqual(generateAutoZoom(tracks, [entry()], { sensitivity }));
      let end = 0;
      for (const r of regions) {
        expect(r.start).toBeGreaterThanOrEqual(end);
        expect(r.end).toBeLessThanOrEqual(20);
        expect(r.end - r.start).toBeGreaterThanOrEqual(MIN_REGION_SEC - 1e-9);
        expect(r.focusX).toBeGreaterThanOrEqual(0.5 / r.scale);
        expect(r.focusX).toBeLessThanOrEqual(1 - 0.5 / r.scale);
        end = r.end;
      }
    }
  });
  it("finds click clusters with lead/hold and ignores idle and fast travel", () => {
    const clicks = generateAutoZoom({ m: parseCursorLog(syntheticCursorLog("clicks")) }, [entry()]);
    expect(clicks).toHaveLength(3);
    expect(clicks[0].start).toBeCloseTo(1.6);
    expect(clicks[0].end).toBeCloseTo(3.7);
    for (const kind of ["idle", "flicks"] as const)
      expect(generateAutoZoom({ m: parseCursorLog(syntheticCursorLog(kind)) }, [entry()])).toEqual(
        [],
      );
  });
  it("supports clicks/typing switches and sensitivity, without using outside events", () => {
    const tracks = { m: parseCursorLog(syntheticCursorLog("typing")) };
    expect(generateAutoZoom(tracks, [entry()], { enabled: false })).toEqual([]);
    expect(generateAutoZoom(tracks, [entry()], { clicks: false, typing: false })).toEqual([]);
    const typing = generateAutoZoom(tracks, [entry()], { clicks: false });
    expect(typing).toHaveLength(1);
    expect(typing[0].start).toBeCloseTo(8.6);
    expect(
      generateAutoZoom({ m: parseCursorLog(syntheticCursorLog("outside")) }, [entry()]),
    ).toHaveLength(2);
    const one = { m: parseCursorLog('{"type":"down","t":3,"x":0.5,"y":0.5,"button":"left"}') };
    expect(generateAutoZoom(one, [entry()], { sensitivity: "low" })).toEqual([]);
    expect(generateAutoZoom(one, [entry()], { sensitivity: "high" })).toHaveLength(1);
  });
  it("removes cut triggers and shifts surviving regions through the EDL", () => {
    const tracks = { m: parseCursorLog(syntheticCursorLog("clicks")) };
    const original = generateAutoZoom(tracks, [entry()]);
    const cut = generateAutoZoom(tracks, [entry(0, 1), entry(5, 20, 1, "m", "s2")]);
    expect(cut).toHaveLength(2);
    expect(cut[0].start).toBeCloseTo(original[1].start - 4);
    expect(cut[1].start).toBeCloseTo(original[2].start - 4);
    expect(generateAutoZoom(tracks, [entry(8, 10)])).toEqual([]);
  });
  it("does not cross media boundaries and supports repeated source clips", () => {
    const tracks = { m: parseCursorLog(syntheticCursorLog("clicks")) };
    const rs = generateAutoZoom(tracks, [
      entry(0, 3, 0),
      entry(0, 3, 3, "other", "o"),
      entry(0, 3, 6, "m", "repeat"),
    ]);
    expect(rs).toHaveLength(2);
    expect(rs[0].end).toBe(3);
    expect(rs[1].start).toBeCloseTo(7.6);
    expect(new Set(rs.map((r) => r.id)).size).toBe(2);
  });
  it("drops too-short tail regions and safely handles no data", () => {
    const tracks = { m: parseCursorLog('{"type":"down","t":0.1,"x":0.5,"y":0.5,"button":"left"}') };
    expect(generateAutoZoom(tracks, [entry(0, 0.2)])).toEqual([]);
    expect(generateAutoZoom({}, [entry()])).toEqual([]);
    expect(generateAutoZoom(tracks, [])).toEqual([]);
  });
});
