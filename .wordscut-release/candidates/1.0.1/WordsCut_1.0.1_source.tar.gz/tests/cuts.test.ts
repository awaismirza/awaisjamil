import { describe, expect, it } from "vitest";
import {
  addMediaWithTranscript,
  deleteWords,
  newProject,
  type Project,
  type SourceMedia,
  type Word,
} from "@/lib/edl";
import { captionAt, cutPoints, nextCutTarget, prevCutTarget } from "@/lib/cuts";

function media(duration: number): SourceMedia {
  return {
    id: "m",
    path: "/tmp/m.mp4",
    duration,
    fps: 30,
    width: 1920,
    height: 1080,
    audioSampleRate: 48000,
    sha256: "x",
  };
}

function word(id: string, start: number, end: number): Word {
  return { id, text: id, start, end, confidence: 1 };
}

/** Ten one-second words w0..w9 over a 10 s clip. */
function project(): Project {
  const words = Array.from({ length: 10 }, (_, i) => word(`w${i}`, i, i + 1));
  const p = addMediaWithTranscript(newProject("t"), media(10), words);
  return { ...p, settings: { ...p.settings, paddingMs: 0 } };
}

describe("cutPoints", () => {
  it("is empty for an uncut project", () => {
    expect(cutPoints(project())).toEqual([]);
  });

  it("reports the output time of each removed span", () => {
    const p = deleteWords(project(), new Set(["w3", "w4"]));
    // w0..w2 survive (3 s), then a jump over w3 and w4.
    expect(cutPoints(p)).toHaveLength(1);
    expect(cutPoints(p)[0]).toBeCloseTo(3, 6);
  });

  it("reports two cuts for two removed spans", () => {
    const p = deleteWords(project(), new Set(["w2", "w6"]));
    expect(cutPoints(p)).toHaveLength(2);
  });
});

describe("cut navigation", () => {
  const points = [3, 8];

  it("next cut lands one second before the cut ahead", () => {
    expect(nextCutTarget(points, 0)).toBe(2);
    expect(nextCutTarget(points, 2)).toBe(7);
  });

  it("next cut is null after the last cut", () => {
    expect(nextCutTarget(points, 7)).toBeNull();
  });

  it("previous cut lands one second before the cut behind", () => {
    expect(prevCutTarget(points, 9)).toBe(7);
    expect(prevCutTarget(points, 7)).toBe(2);
  });

  it("previous cut is null before the first lead-in", () => {
    expect(prevCutTarget(points, 2)).toBeNull();
  });

  it("clamps the lead-in at zero", () => {
    expect(nextCutTarget([0.4], -1)).toBe(0);
  });
});

describe("captionAt", () => {
  it("shows the words around the playhead", () => {
    const text = captionAt(project(), 4.5, 1, 1);
    expect(text).toBe("w3 w4 w5");
  });

  it("is null past the end of the timeline", () => {
    expect(captionAt(project(), 99)).toBeNull();
  });

  it("follows the edit: removed words are not in the caption", () => {
    const p = deleteWords(project(), new Set(["w4"]));
    const text = captionAt(p, 3.5, 1, 2);
    expect(text).not.toContain("w4");
  });
});
