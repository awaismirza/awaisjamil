// Media overlays: sanitizers (shared fixture with layers_export.rs), retiming
// through cuts / clip ops / speed, store actions. Privacy masks: masks.test.ts.
import { beforeEach, describe, expect, it } from "vitest";
import fixture from "./fixtures/layersSanitize.json";
import {
  addMediaWithTranscript,
  deleteWords,
  newProject,
  setSegmentTiming,
  type Project,
  type SourceMedia,
  type Word,
} from "@/lib/edl";
import { duplicateClip, moveClip } from "@/lib/clipEdit";
import {
  makeOverlay,
  MAX_OVERLAYS,
  overlayMediaTime,
  overlayOpacity,
  sanitizeOverlays,
  type MediaOverlay,
} from "@/lib/layers";
import { buildFcpxml } from "@/lib/fcpxml";
import { useProjectStore } from "@/stores/projectStore";

const strip = ({ id: _id, ...rest }: { id: string }) => rest;

describe("sanitizers", () => {
  it("match the fixture shared with layers_export.rs (hostile values included)", () => {
    expect(sanitizeOverlays(fixture.overlays.input, fixture.total).map(strip)).toEqual(
      fixture.overlays.expected,
    );
  });

  it("never throw on junk and cap both lists at 200", () => {
    for (const junk of [null, 1, "x", {}, [null, [], { start: "1" }], { length: 5 }])
      expect(() => sanitizeOverlays(junk, 5)).not.toThrow();
    const many = Array.from({ length: 300 }, () => ({ path: "/a.png", start: 0, end: 1 }));
    expect(sanitizeOverlays(many, 4)).toHaveLength(MAX_OVERLAYS);
    // Images over 16384 px are refused.
    expect(sanitizeOverlays([{ path: "/a.png", start: 0, end: 1, srcW: 16385 }], 4)).toEqual([]);
  });

  it("opacity fades like annotations and video time starts at trimIn", () => {
    const o = sanitizeOverlays(
      [{ path: "/v.mov", start: 2, end: 6, opacity: 0.5, fadeInMs: 1000, trimIn: 3 }],
      10,
    )[0]!;
    expect(overlayOpacity(o, 1.9)).toBe(0);
    expect(overlayOpacity(o, 2.5)).toBeCloseTo(0.25, 9);
    expect(overlayOpacity(o, 4)).toBe(0.5);
    expect(overlayOpacity(o, 6)).toBe(0);
    expect(overlayMediaTime(o, 4)).toBe(5);
  });

  it("new overlays keep the file's aspect in the frame and videos run their own length", () => {
    const img = makeOverlay(
      { path: "/a/logo.png", width: 400, height: 200, duration: 0.04, hasAudio: false },
      1,
      20,
      16 / 9,
    )!;
    expect(img.kind).toBe("image");
    expect(img.end - img.start).toBe(5);
    // 30 % of the width; a 2:1 image in a 16:9 frame is 0.3 * 0.5 * 16/9 high.
    expect(img.h).toBeCloseTo(0.3 * 0.5 * (16 / 9), 9);
    const vid = makeOverlay(
      { path: "/a/clip.MOV", width: 1920, height: 1080, duration: 7, hasAudio: true },
      0,
      20,
      16 / 9,
    )!;
    expect([vid.kind, vid.end, vid.hasAudio, vid.includeAudio]).toEqual([
      "video",
      7,
      true,
      undefined,
    ]);
    expect(
      makeOverlay(
        { path: "/a/x.webp", width: 1, height: 1, duration: 0, hasAudio: false },
        0,
        9,
        1,
      ),
    ).toBeNull();
  });
});

const media: SourceMedia = {
  id: "m",
  path: "/tmp/m.mp4",
  duration: 20,
  fps: 30,
  width: 1920,
  height: 1080,
  audioSampleRate: 48000,
  sha256: "x",
};
const words: Word[] = Array.from({ length: 20 }, (_, i) => ({
  id: `w${i}`,
  text: `w${i}`,
  start: i,
  end: i + 1,
  confidence: 1,
}));

function base(): Project {
  const p = addMediaWithTranscript(newProject("t"), media, words);
  return { ...p, settings: { ...p.settings, paddingMs: 0 } };
}
const overlay = (id: string, start: number, end: number, extra = {}): MediaOverlay =>
  sanitizeOverlays([{ id, path: "/o/clip.mp4", start, end, ...extra }], 20)[0]!;

describe("retiming", () => {
  it("overlays close up over a cut", () => {
    const p = { ...base(), overlays: [overlay("o", 4, 10)] };
    const after = deleteWords(p, new Set(["w5", "w6"])); // cut 5..7
    expect(after.overlays!.map((o) => [o.start, o.end])).toEqual([[4, 8]]);
  });

  it("follow their clip through duplicate and move (segment-id lineage)", () => {
    // Clips A [0,4) B [5,9) C [10,20) -> output A 0-4, B 4-8, C 8-18.
    const cut = deleteWords(base(), new Set(["w4", "w9"]));
    const p0 = { ...cut, overlays: [overlay("ov-b", 4.5, 6)] };
    const dup = duplicateClip(p0, p0.segments[0]!.id); // A A' B C: B now at 8-12
    expect(dup.overlays!.map((o) => [o.start, o.end])).toEqual([[8.5, 10]]);
    const moved = moveClip(dup, dup.segments[1]!.id, dup.segments.length - 1); // A B C A'
    expect(moved.overlays![0]!.end).toBeCloseTo(6, 9);
  });

  it("go through source time at speed", () => {
    const p = { ...base(), overlays: [overlay("o", 4, 6)] };
    const fast = setSegmentTiming(p, p.segments[0]!.id, { speed: 2 });
    expect(fast.overlays![0]!.end).toBeCloseTo(3, 9);
  });

  it("a video overlay split by a move continues its own file in the later piece", () => {
    // Overlay 2..6 across A (output 0-4) and B (4-8); moving B first splits it in two.
    const cut = deleteWords(base(), new Set(["w4", "w9"]));
    const p0 = {
      ...cut,
      overlays: [overlay("v", 2, 6, { trimIn: 1, fadeInMs: 300, fadeOutMs: 300 })],
    };
    const moved = moveClip(p0, p0.segments[1]!.id, 0); // B A C: B 0-4, A 4-8
    const [first, second] = moved.overlays!;
    // In output order: the first piece keeps the id and trimIn, the next continues the file.
    expect(first!.id).toBe("v");
    expect([first!.start, first!.end, first!.trimIn]).toEqual([0, 2, 1]);
    expect([second!.start, second!.end]).toEqual([6, 8]);
    expect(second!.trimIn).toBeCloseTo(3, 9);
    expect([first!.fadeInMs, first!.fadeOutMs]).toEqual([300, undefined]);
    expect([second!.fadeInMs, second!.fadeOutMs]).toEqual([undefined, 300]);
  });
});

describe("store", () => {
  beforeEach(() => {
    useProjectStore.getState().setProject(base());
    useProjectStore.temporal.getState().clear();
    useProjectStore.temporal.getState().resume();
  });
  const history = () => useProjectStore.temporal.getState().pastStates.length;

  it("add / update are one undo step each", () => {
    const s = useProjectStore.getState();
    const ov = s.addOverlay(
      { path: "/a/logo.png", width: 10, height: 10, duration: 0, hasAudio: false },
      0,
      16 / 9,
    )!;
    expect(history()).toBe(1);
    s.updateOverlay(ov, { opacity: 0.4 });
    expect(history()).toBe(2);
    expect(useProjectStore.getState().project.overlays![0]!.opacity).toBe(0.4);
  });

  it("relinking an overlay rewrites history so undo never re-breaks it", () => {
    const s = useProjectStore.getState();
    const file = {
      path: "/old/a.png",
      sha256: "a".repeat(64),
      width: 10,
      height: 10,
      duration: 0,
      hasAudio: false,
    };
    const id = s.addOverlay(file, 0, 1)!;
    s.updateOverlay(id, { opacity: 0.5 });
    const p = useProjectStore.getState().project;
    expect(s.relinkOverlayPath(p.id, "/old/a.png", { ...file, path: "/new/a.png" })).toBe(true);
    useProjectStore.temporal.getState().undo();
    const after = useProjectStore.getState().project.overlays![0]!;
    expect([after.path, after.opacity]).toEqual(["/new/a.png", 1]);
    expect(s.relinkOverlayPath("other", "/new/a.png", file)).toBe(false);
  });
});

it("FCPXML lists overlays as unsupported", () => {
  const p = { ...base(), overlays: [overlay("o", 1, 2)] };
  expect(buildFcpxml(p).unsupported.join("\n")).toMatch(/Image\/video overlays \(1\)/);
});
