import { describe, expect, it } from "vitest";
import { defaultShortcuts } from "@/lib/shortcuts";
import { trayModel, type TrayPhase } from "@/lib/trayModel";

const model = (phase: TrayPhase, elapsedSec = 0, countdown = 0) =>
  trayModel({ phase, elapsedSec, countdown, shortcuts: defaultShortcuts() });

const item = (m: ReturnType<typeof model>, id: string) => m.items.find((i) => i.id === id)!;

describe("trayModel", () => {
  it("shows only the icon when idle, and only Start is enabled", () => {
    const m = model("idle");
    expect(m.title).toBeNull();
    expect(item(m, "record").label).toMatch(/^Start Recording/);
    expect(m.items.filter((i) => i.enabled).map((i) => i.id)).toEqual(["record"]);
  });

  it("shows a red dot and the elapsed time while recording", () => {
    const m = model("recording", 83);
    expect(m.title).toBe("● 01:23");
    expect(item(m, "record").label).toMatch(/^Stop and Add to Video/);
    expect(item(m, "pause").label).toMatch(/^Pause Recording/);
  });

  it("enables every session control while recording (controller row needs a controller)", () => {
    const m = model("recording", 5);
    expect(m.items.filter((i) => i.id !== "controller").every((i) => i.enabled)).toBe(true);
    expect(item(m, "controller").enabled).toBe(false);
  });

  it("toggles the desktop controller from the menu bar during a native screen take", () => {
    const withController = (hidden: boolean, phase: TrayPhase = "recording") =>
      trayModel({
        phase,
        elapsedSec: 3,
        countdown: 0,
        shortcuts: defaultShortcuts(),
        controller: { available: true, hidden },
      });
    expect(item(withController(false), "controller")).toMatchObject({
      label: "Hide Recording Controls",
      enabled: true,
    });
    // Stays usable to restore the controller while paused, and after hiding it.
    expect(item(withController(true, "paused"), "controller")).toMatchObject({
      label: "Show Recording Controls",
      enabled: true,
    });
    expect(item(withController(false, "idle"), "controller").enabled).toBe(false);
  });

  it("offers Resume, and disables Mark, while paused", () => {
    const m = model("paused", 61);
    expect(m.title).toBe("❚❚ 01:01");
    expect(item(m, "pause").label).toMatch(/^Resume Recording/);
    expect(item(m, "mark").enabled).toBe(false);
    expect(item(m, "record").enabled).toBe(true);
  });

  it("shows the countdown number and locks the controls", () => {
    const m = model("countdown", 0, 2);
    expect(m.title).toBe("2");
    expect(m.items.every((i) => !i.enabled)).toBe(true);
  });

  it("keeps capture startup distinct from a running timer", () => {
    const m = model("countdown", 0, 0);
    expect(m.title).toBe("…");
    expect(m.tooltip).toBe("Starting capture…");
    expect(m.items.every((i) => !i.enabled)).toBe(true);
  });

  it("locks every control while finishing, with a status label", () => {
    const fin = model("finalizing");
    const proc = model("processing");
    expect(fin.items.every((i) => !i.enabled)).toBe(true);
    expect(item(fin, "record").label).toBe("Finishing up…");
    expect(item(proc, "record").label).toBe("Adding recording…");
    expect(fin.title).toBe("…");
  });

  it("prints the configured shortcut next to each action", () => {
    const m = trayModel({
      phase: "idle",
      elapsedSec: 0,
      countdown: 0,
      shortcuts: { ...defaultShortcuts(), record: "Alt+Shift+K" },
    });
    expect(item(m, "record").label).toContain("⌥⇧K");
  });
});
