/**
 * The voice-over review flow and its races, against mocked IPC (no microphone,
 * no hardware): anchor capture, start/stop races, duplicate completion events,
 * short takes, keep / discard / retake / Escape, project switches, recovery
 * after a reload, and routing that never appends a take to the timeline.
 */
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { defaultSettings } from "@/lib/settings";
import { newProject, totalDuration, type Project } from "@/lib/edl";
import type { RecordingResult, RecordingSnapshot } from "@/lib/ipc";
import * as ipc from "@/lib/ipc";
import { useProjectStore } from "@/stores/projectStore";
import { usePlayerStore } from "@/stores/playerStore";
import { useSettingsStore } from "@/stores/settingsStore";
import { useUIStore } from "@/stores/uiStore";
import {
  idleSnapshot,
  importFinishedRecording,
  runRecorderAction,
  useRecordingStore,
} from "@/stores/recordingStore";
import { initVoiceOver, resetVoiceOverForTests, useVoiceOverStore } from "@/stores/voiceOverStore";

vi.mock("@/lib/ipc", async (orig) => ({
  ...(await orig<typeof import("@/lib/ipc")>()),
  ackRecordingResult: vi.fn(async () => {}),
  cancelRecording: vi.fn(async () => idle(99)),
  discardRecordingTake: vi.fn(async () => {}),
  importMedia: vi.fn(),
  listRecordingDevices: vi.fn(async () => ({ video: [], audio: [{ index: 3, name: "USB Mic" }] })),
  listModels: vi.fn(async () => []),
  startRecording: vi.fn(),
  stopRecording: vi.fn(),
  transcribe: vi.fn(),
  pauseRecording: vi.fn(async () => {}),
  restartRecording: vi.fn(),
}));

function idle(revision: number): RecordingSnapshot {
  return { ...idleSnapshot(), revision };
}
let revision = 10;
function live(sessionId: string): RecordingSnapshot {
  return {
    revision: ++revision,
    sessionId,
    phase: "recording",
    backend: "native",
    mode: "voiceover",
    elapsedSec: 0,
    markers: [],
    error: null,
    controllerHidden: false,
  };
}
function result(sessionId: string, durationSec = 2): RecordingResult {
  return {
    sessionId,
    path: `/rec/rec-${sessionId}/voiceover.m4a`,
    durationSec,
    mode: "voiceover",
    markers: [],
    purpose: "voiceover-take",
  };
}
const takeMedia = (path: string, duration = 2) => ({
  id: `media-${path}`,
  path,
  duration,
  fps: 0,
  width: 0,
  height: 0,
  audioSampleRate: 48000,
  sha256: path,
});

function videoProject(): Project {
  return {
    ...newProject("talk"),
    media: {
      m: {
        id: "m",
        path: "/v.mp4",
        duration: 10,
        fps: 30,
        width: 1280,
        height: 720,
        audioSampleRate: 48000,
        sha256: "m",
      },
    },
    segments: [{ id: "s", mediaId: "m", sourceIn: 0, sourceOut: 10, words: [] }],
  };
}

const events: Array<{ type: string; detail?: unknown }> = [];
const record = (e: Event) => events.push({ type: e.type, detail: (e as CustomEvent).detail });
const vo = () => useVoiceOverStore.getState();
const flush = async () => {
  for (let i = 0; i < 6; i++) await Promise.resolve();
};
let dispose: () => void = () => {};

beforeEach(() => {
  vi.clearAllMocks();
  window.localStorage.clear();
  resetVoiceOverForTests();
  useSettingsStore.setState({
    ...defaultSettings(),
    recording: { ...defaultSettings().recording, countdownSec: 0, autoTranscribe: false },
  });
  useRecordingStore.setState({
    phase: "idle",
    session: idleSnapshot(),
    sessionId: null,
    revision: 0,
  });
  useProjectStore.setState({ project: videoProject(), dirty: false, filePath: null });
  useProjectStore.temporal.getState().clear();
  usePlayerStore.setState({ currentTime: 4 });
  useUIStore.setState({ toasts: [] });
  vi.mocked(ipc.startRecording).mockImplementation(async () => live("S1"));
  // Rust's order: `record:finished`, then the idle snapshot, then the command reply.
  vi.mocked(ipc.stopRecording).mockImplementation(async (id: string) => {
    const r = result(id);
    void importFinishedRecording(r);
    useRecordingStore.getState().applySnapshot(idle(++revision));
    return r;
  });
  vi.mocked(ipc.importMedia).mockImplementation(async (path: string) => takeMedia(path));
  for (const t of ["yusafcut:seek-output", "yusafcut:pause"]) window.addEventListener(t, record);
  events.length = 0;
  dispose = initVoiceOver();
});
afterEach(() => {
  dispose();
  for (const t of ["yusafcut:seek-output", "yusafcut:pause"]) window.removeEventListener(t, record);
});

const toasts = () => useUIStore.getState().toasts.map((t) => t.title);

describe("voice-over recording", () => {
  it("captures the anchor before recording, starts with the remembered mic and a voice-over purpose", async () => {
    await vo().start();
    expect(vo().phase).toBe("recording");
    expect(vo().draft!.anchor).toMatchObject({ outputTime: 4, segmentId: "s", sourceTime: 4 });
    expect(ipc.startRecording).toHaveBeenCalledWith({
      mode: "voiceover",
      audioIndex: 3,
      purpose: "voiceover-take",
    });
    expect(vo().prefs.micName).toBe("USB Mic");
    // Paused + seeked to the anchor first, playback only after the take is live.
    const seeks = events.filter((e) => e.type === "yusafcut:seek-output").map((e) => e.detail);
    expect(seeks).toEqual([
      { time: 4, play: false },
      { time: 4, play: true },
    ]);
    // Playback moving the playhead does not move the anchor.
    usePlayerStore.setState({ currentTime: 9 });
    await vo().stop();
    expect(vo().phase).toBe("review");
    expect(vo().draft!.anchor.outputTime).toBe(4);
  });

  it("stores the finished take before acknowledging it to Rust", async () => {
    let storedAtAck: string | null = null;
    vi.mocked(ipc.ackRecordingResult).mockImplementation(async () => {
      storedAtAck = window.localStorage.getItem("yusafcut.voiceover.v1");
    });
    await vo().start();
    await vo().stop();
    expect(JSON.parse(storedAtAck!).pending).toHaveLength(1);
  });

  it("a stop pressed while the microphone starts is honoured once it is live", async () => {
    let resolveStart!: (s: RecordingSnapshot) => void;
    vi.mocked(ipc.startRecording).mockImplementation(() => new Promise((r) => (resolveStart = r)));
    const started = vo().start();
    await flush();
    expect(vo().phase).toBe("starting");
    vo().toggle(); // stop during startup
    vo().toggle(); // and again
    resolveStart(live("S2"));
    await started;
    await flush();
    expect(ipc.stopRecording).toHaveBeenCalledTimes(1);
    expect(vo().phase).toBe("review");
  });

  it("cancelling the countdown never starts capture; repeated presses are harmless", async () => {
    useSettingsStore.getState().setRecording({ countdownSec: 3 });
    vi.useFakeTimers();
    try {
      void vo().start();
      expect(vo().phase).toBe("countdown");
      vo().toggle(); // cancel
      vo().toggle(); // starts a new countdown
      vo().toggle(); // cancels it again
      await vi.advanceTimersByTimeAsync(5000);
      expect(ipc.startRecording).not.toHaveBeenCalled();
      expect(vo().phase).toBe("idle");
    } finally {
      vi.useRealTimers();
    }
  });

  it("duplicate completion events (stop reply, record:finished, pending replay) make one draft", async () => {
    await vo().start();
    const r = result("S1");
    await Promise.all([vo().stop(), importFinishedRecording(r), importFinishedRecording(r)]);
    await vo().handleFinished(r);
    expect(vo().pending).toHaveLength(1);
    expect(useProjectStore.getState().project.segments).toHaveLength(1); // never appended
  });

  it("a stop from elsewhere that loses the race waits for the event instead of failing", async () => {
    await vo().start();
    vi.mocked(ipc.stopRecording).mockRejectedValueOnce("the recording is already being saved");
    await vo().stop();
    expect(vo().phase).toBe("stopping");
    await importFinishedRecording(result("S1"));
    expect(vo().phase).toBe("review");
    expect(toasts()).not.toContain("Voice-over was not saved");
  });

  it("Stop follows Rust's live session id (a restart elsewhere changed it) and is never stuck", async () => {
    await vo().start();
    useRecordingStore.getState().applySnapshot(live("S9")); // restarted from another window
    await vo().stop();
    expect(ipc.stopRecording).toHaveBeenCalledWith("S9");
    expect(vo().phase).toBe("review");
  });

  it("a stale stop retries once with the live id; with nothing live it recovers with a message", async () => {
    await vo().start();
    // Rust moved on to S9 after our stop was sent with S1.
    vi.mocked(ipc.stopRecording).mockImplementationOnce(async () => {
      useRecordingStore.getState().applySnapshot(live("S9"));
      throw "stale session";
    });
    await vo().stop();
    expect(vi.mocked(ipc.stopRecording).mock.calls.map((c) => c[0])).toEqual(["S1", "S9"]);
    expect(vo().phase).toBe("review");

    // Nothing live and no result: back to idle with the error, not "Saving…" forever.
    resetVoiceOverForTests();
    vi.mocked(ipc.startRecording).mockImplementation(async () => live("S4"));
    await vo().start();
    vi.mocked(ipc.stopRecording).mockImplementationOnce(async () => {
      useRecordingStore.setState({ session: idle(++revision), revision });
      throw "no recording is running";
    });
    await vo().stop();
    expect(vo().phase).toBe("idle");
    expect(toasts()).toContain("Voice-over was not saved");
  });

  it("global pause and restart are refused during a take; the record shortcut stops it", async () => {
    await vo().start();
    runRecorderAction("pause");
    runRecorderAction("rerecord");
    expect(ipc.pauseRecording).not.toHaveBeenCalled();
    expect(ipc.restartRecording).not.toHaveBeenCalled();
    expect(toasts()).toContain("Pause is off during a voice-over");
    runRecorderAction("record");
    await flush();
    expect(ipc.stopRecording).toHaveBeenCalledWith("S1");
  });

  it("an empty or very short take is discarded with a message", async () => {
    vi.mocked(ipc.stopRecording).mockImplementation(async (id: string) => result(id, 0.1));
    await vo().start();
    await vo().stop();
    await flush();
    expect(vo().phase).toBe("idle");
    expect(vo().pending).toEqual([]);
    expect(ipc.discardRecordingTake).toHaveBeenCalledWith("/rec/rec-S1/voiceover.m4a");
    expect(toasts()).toContain("Take too short, discarded");
  });

  it("a session that ends without a take (device lost) frees the workflow", async () => {
    await vo().start();
    useRecordingStore
      .getState()
      .applySnapshot({ ...idle(++revision), error: "microphone disconnected" });
    expect(vo().phase).toBe("idle");
    expect(toasts()).toContain("Voice-over was not saved");
  });
});

describe("review", () => {
  async function reviewed() {
    await vo().start();
    await vo().stop();
    expect(vo().phase).toBe("review");
  }

  it("Keep adds the take as one undo step; undo and redo are exact and keep the file", async () => {
    await reviewed();
    vo().setDraft({ mode: "insert", overrideOriginal: true });
    const before = useProjectStore.getState().project;
    const steps = useProjectStore.temporal.getState().pastStates.length;
    await vo().keep();
    const after = useProjectStore.getState().project;
    expect(after.audioTracks).toHaveLength(1);
    expect(after.audioTracks![0]).toMatchObject({
      kind: "voiceover",
      mode: "insert",
      overrideOriginal: true,
      offsetSec: 4,
      insertSec: 2,
    });
    expect(totalDuration(after)).toBeCloseTo(12);
    expect(useProjectStore.temporal.getState().pastStates.length).toBe(steps + 1);
    useProjectStore.temporal.getState().undo();
    expect(useProjectStore.getState().project).toEqual(before);
    useProjectStore.temporal.getState().redo();
    expect(useProjectStore.getState().project).toEqual(after);
    expect(ipc.discardRecordingTake).not.toHaveBeenCalled();
    expect(vo().pending).toEqual([]);
    expect(vo().phase).toBe("idle");
  });

  it("two insert takes at one playhead sit back to back; undo removes each exactly", async () => {
    const original = useProjectStore.getState().project;
    await reviewed();
    vo().setDraft({ mode: "insert" });
    await vo().keep();
    const afterOne = useProjectStore.getState().project;
    usePlayerStore.setState({ currentTime: 4 });
    vi.mocked(ipc.startRecording).mockImplementation(async () => live("S2"));
    await vo().start();
    await vo().stop();
    vo().setDraft({ mode: "insert" });
    await vo().keep();
    const p = useProjectStore.getState().project;
    expect(p.audioTracks!.map((t) => [t.offsetSec, t.insertSec])).toEqual([
      [4, 2],
      [6, 2],
    ]);
    expect(totalDuration(p)).toBeCloseTo(14);
    useProjectStore.temporal.getState().undo();
    expect(useProjectStore.getState().project).toEqual(afterOne);
    useProjectStore.temporal.getState().undo();
    expect(useProjectStore.getState().project).toEqual(original);
  });

  it("Keep twice keeps once", async () => {
    await reviewed();
    await Promise.all([vo().keep(), vo().keep()]);
    expect(useProjectStore.getState().project.audioTracks).toHaveLength(1);
  });

  it("Escape keeps the take pending; the shortcut reopens it; Discard deletes only unreferenced media", async () => {
    await reviewed();
    vo().closeReview();
    expect(vo().reviewOpen).toBe(false);
    expect(vo().pending).toHaveLength(1);
    vo().toggle(); // reopens the review instead of starting a take
    expect(vo().reviewOpen).toBe(true);
    expect(ipc.startRecording).toHaveBeenCalledTimes(1);
    await vo().discard();
    expect(ipc.discardRecordingTake).toHaveBeenCalledTimes(1);
    expect(vo().pending).toEqual([]);
  });

  it("Discard never deletes a file the project (or its history) uses", async () => {
    await reviewed();
    const path = vo().draft!.path!;
    const p = useProjectStore.getState().project;
    useProjectStore.setState({
      project: { ...p, media: { ...p.media, x: { ...p.media.m!, id: "x", path } } },
    });
    await vo().discard();
    expect(ipc.discardRecordingTake).not.toHaveBeenCalled();
  });

  it("Retake discards this take and records again at the original anchor with the same choices", async () => {
    await reviewed();
    vo().setDraft({ mode: "insert" });
    const anchor = vo().draft!.anchor;
    usePlayerStore.setState({ currentTime: 8 });
    vi.mocked(ipc.startRecording).mockImplementation(async () => live("S3"));
    await vo().retake();
    expect(ipc.discardRecordingTake).toHaveBeenCalledTimes(1);
    expect(vo().phase).toBe("recording");
    expect(vo().draft!.anchor).toEqual(anchor);
    expect(vo().draft!.mode).toBe("insert");
  });

  it("an anchor clip deleted during review places the take at the stored time, flagged", async () => {
    await reviewed();
    useProjectStore.setState({
      project: {
        ...useProjectStore.getState().project,
        segments: [{ id: "other", mediaId: "m", sourceIn: 6, sourceOut: 10, words: [] }],
      },
    });
    await vo().keep();
    expect(useProjectStore.getState().project.audioTracks![0]!.offsetSec).toBe(4);
    expect(useUIStore.getState().toasts.at(-1)?.description).toMatch(/removed/);
  });
});

describe("project switches and recovery", () => {
  it("a take finished after a project switch waits for its own project", async () => {
    await vo().start();
    const original = useProjectStore.getState().project;
    useProjectStore.setState({ project: { ...videoProject(), id: "other" } });
    await vo().stop();
    expect(vo().phase).toBe("idle");
    expect(vo().reviewOpen).toBe(false);
    expect(vo().pending[0]!.projectId).toBe(original.id);
    expect(vo().openReview()).toBe(false); // not this project's take
    useProjectStore.setState({ project: original });
    expect(vo().openReview()).toBe(true);
  });

  it("switching projects during review closes it and keeps the take", async () => {
    await vo().start();
    await vo().stop();
    useProjectStore.setState({ project: { ...videoProject(), id: "other" } });
    expect(vo().reviewOpen).toBe(false);
    expect(vo().pending).toHaveLength(1);
  });

  it("a result replayed after a reload finds the stored take and its anchor", async () => {
    await vo().start();
    const anchor = vo().draft!.anchor;
    // Reload: in-memory state is gone, localStorage and Rust's pending result remain.
    useVoiceOverStore.setState({ phase: "idle", draft: null });
    await importFinishedRecording(result("S1"));
    expect(vo().phase).toBe("review");
    expect(vo().draft!.anchor).toEqual(anchor);
  });

  it("transcription after Keep attaches to the take, and never to another project", async () => {
    useSettingsStore.getState().setRecording({ autoTranscribe: true });
    vi.mocked(ipc.listModels).mockResolvedValue([{ name: "tiny", installed: true }] as never);
    let finish!: (v: unknown) => void;
    vi.mocked(ipc.transcribe).mockImplementation(() => new Promise((r) => (finish = r)) as never);
    await vo().start();
    await vo().stop();
    await vo().keep();
    await flush();
    const kept = useProjectStore.getState().project;
    useProjectStore.setState({ project: { ...videoProject(), id: "elsewhere" } });
    finish({ mediaId: "x", words: [{ id: "a", text: "hi", start: 0, end: 0.5, confidence: 1 }] });
    await flush();
    expect(useProjectStore.getState().project.audioTracks ?? []).toEqual([]);
    useProjectStore.setState({ project: kept });
    expect(useProjectStore.getState().project.audioTracks![0]!.words).toBeUndefined();
  });
});
