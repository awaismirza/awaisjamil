import { describe, it, expect } from "vitest";
import { audibleTracks, previewVoices, resolveFades, trackGainAt, trackSpan } from "@/lib/audioMix";
import { addAudioTrack, newProject, updateAudioTrack, type AudioTrack } from "@/lib/edl";

const track = (id: string, extra: Partial<AudioTrack> = {}): AudioTrack => ({
  id,
  mediaId: "m",
  gainDb: 0,
  offsetSec: 0,
  ducks: false,
  ...extra,
});
const ids = (ts: AudioTrack[]) => ts.map((t) => t.id);

describe("audibleTracks (mute and solo)", () => {
  it("plays everything when nothing is muted or soloed", () => {
    expect(ids(audibleTracks([track("a"), track("b")]))).toEqual(["a", "b"]);
  });
  it("drops muted tracks", () => {
    expect(ids(audibleTracks([track("a", { muted: true }), track("b")]))).toEqual(["b"]);
    expect(audibleTracks([track("a", { muted: true })])).toEqual([]);
  });
  it("solo isolates the soloed tracks", () => {
    expect(ids(audibleTracks([track("a"), track("b", { solo: true }), track("c")]))).toEqual(["b"]);
    expect(
      ids(audibleTracks([track("a", { solo: true }), track("b", { solo: true }), track("c")])),
    ).toEqual(["a", "b"]);
  });
  it("solo wins over mute on the same track and over other tracks' state", () => {
    expect(ids(audibleTracks([track("a", { muted: true, solo: true }), track("b")]))).toEqual([
      "a",
    ]);
    expect(
      ids(audibleTracks([track("a", { solo: true }), track("b", { muted: true, solo: false })])),
    ).toEqual(["a"]);
  });
});

describe("resolveFades", () => {
  it("keeps sane fades", () => {
    expect(resolveFades(1, 2, 10)).toEqual({ fadeIn: 1, fadeOut: 2 });
  });
  it("treats junk as no fade", () => {
    expect(resolveFades(-1, Number.NaN, 10)).toEqual({ fadeIn: 0, fadeOut: 0 });
    expect(resolveFades(undefined, undefined, 10)).toEqual({ fadeIn: 0, fadeOut: 0 });
  });
  it("clamps to the clip and scales overlapping fades together", () => {
    expect(resolveFades(20, 0, 10)).toEqual({ fadeIn: 10, fadeOut: 0 });
    const r = resolveFades(6, 6, 9);
    expect(r.fadeIn).toBeCloseTo(4.5);
    expect(r.fadeOut).toBeCloseTo(4.5);
    expect(resolveFades(2, 2, 0)).toEqual({ fadeIn: 0, fadeOut: 0 });
  });
});

describe("trackSpan and trackGainAt", () => {
  it("ends with the media or the edit, whichever is first", () => {
    expect(trackSpan(track("a"), 5, 3.5)).toEqual({ start: 0, len: 3.5 });
    expect(trackSpan(track("a", { offsetSec: 2 }), 5, 10)).toEqual({ start: 2, len: 5 });
    expect(trackSpan(track("a", { offsetSec: -4 }), 5, 10)).toEqual({ start: 0, len: 5 });
    expect(trackSpan(track("a", { offsetSec: 20 }), 5, 10).len).toBe(0);
  });
  it("applies gain in dB", () => {
    expect(trackGainAt(track("a", { gainDb: -20 }), 5, 10, 1)).toBeCloseTo(0.1);
    expect(trackGainAt(track("a", { gainDb: 6.0206 }), 5, 10, 1)).toBeCloseTo(2, 3);
  });
  it("is silent outside the track's span", () => {
    const t = track("a", { offsetSec: 2 });
    expect(trackGainAt(t, 3, 10, 1.99)).toBe(0);
    expect(trackGainAt(t, 3, 10, 2.5)).toBeGreaterThan(0);
    expect(trackGainAt(t, 3, 10, 5)).toBe(0);
  });
  it("ramps linearly in and out, monotonically, and stays flat between", () => {
    const t = track("a", { fadeInSec: 1, fadeOutSec: 1 });
    const g = (x: number) => trackGainAt(t, 10, 10, x);
    const up = [0, 0.25, 0.5, 0.75, 1].map(g);
    expect(up[0]).toBe(0);
    expect(up[2]).toBeCloseTo(0.5);
    expect(up.every((v, i) => i === 0 || v > up[i - 1]!)).toBe(true);
    expect(g(5)).toBe(1);
    const down = [9, 9.25, 9.5, 9.75, 9.999].map(g);
    expect(down[0]).toBeCloseTo(1);
    expect(down[2]).toBeCloseTo(0.5);
    expect(down.every((v, i) => i === 0 || v < down[i - 1]!)).toBe(true);
  });
  it("puts the fade-out at the end of a short track, not the end of the edit", () => {
    const t = track("a", { offsetSec: 2, fadeOutSec: 1 }); // media 3 s -> ends at 5 s of 10 s
    expect(trackGainAt(t, 3, 10, 3.5)).toBe(1);
    expect(trackGainAt(t, 3, 10, 4.5)).toBeCloseTo(0.5);
  });
});

describe("previewVoices", () => {
  const media = { m: { duration: 5 }, n: { duration: 5 } };
  it("lists only audible tracks that are inside their span, with media time", () => {
    const tracks = [
      track("a", { offsetSec: 1 }),
      track("b", { mediaId: "n", muted: true }),
      track("c", { mediaId: "gone" }),
    ];
    expect(previewVoices(tracks, media, 10, 0.5)).toEqual([]);
    const v = previewVoices(tracks, media, 10, 2.5);
    expect(v).toHaveLength(1);
    expect(v[0]).toMatchObject({ trackId: "a", mediaId: "m", mediaTime: 1.5, gain: 1 });
  });
  it("honours solo", () => {
    const tracks = [track("a"), track("b", { mediaId: "n", solo: true })];
    expect(previewVoices(tracks, media, 10, 1).map((v) => v.trackId)).toEqual(["b"]);
  });
});

describe("project serialisation of mixer fields", () => {
  const base = () => {
    const p = newProject("p");
    return {
      ...p,
      media: {
        m: {
          id: "m",
          path: "/x.wav",
          duration: 5,
          fps: 0,
          width: 0,
          height: 0,
          audioSampleRate: 48000,
          sha256: "x",
        },
      },
    };
  };
  it("an old track and a track with defaults serialise without the new keys", () => {
    const p = addAudioTrack(base(), { mediaId: "m", gainDb: -12, offsetSec: 0, ducks: true });
    const [t] = p.audioTracks!;
    expect(Object.keys(JSON.parse(JSON.stringify(t))).sort()).toEqual(
      ["ducks", "gainDb", "id", "mediaId", "offsetSec"].sort(),
    );
  });
  it("round-trips mute, solo and fades, and clears them back to absent", () => {
    let p = addAudioTrack(base(), { id: "t", mediaId: "m", gainDb: 0, offsetSec: 0, ducks: false });
    p = updateAudioTrack(p, "t", { muted: true, solo: true, fadeInSec: 1.5, fadeOutSec: 2 });
    const back = JSON.parse(JSON.stringify(p.audioTracks![0]));
    expect(back).toMatchObject({ muted: true, solo: true, fadeInSec: 1.5, fadeOutSec: 2 });
    p = updateAudioTrack(p, "t", { muted: false, solo: false, fadeInSec: 0, fadeOutSec: -3 });
    expect(Object.keys(JSON.parse(JSON.stringify(p.audioTracks![0]))).sort()).toEqual(
      ["ducks", "gainDb", "id", "mediaId", "offsetSec"].sort(),
    );
    p = updateAudioTrack(p, "t", { fadeInSec: Number.NaN });
    expect(p.audioTracks![0]!.fadeInSec).toBeUndefined();
  });
  it("leaves unrelated patches from touching the mixer state", () => {
    let p = addAudioTrack(base(), { id: "t", mediaId: "m", gainDb: 0, offsetSec: 0, ducks: false });
    p = updateAudioTrack(p, "t", { muted: true, fadeInSec: 2 });
    p = updateAudioTrack(p, "t", { gainDb: -6 });
    expect(p.audioTracks![0]).toMatchObject({ muted: true, fadeInSec: 2, gainDb: -6 });
  });
});
