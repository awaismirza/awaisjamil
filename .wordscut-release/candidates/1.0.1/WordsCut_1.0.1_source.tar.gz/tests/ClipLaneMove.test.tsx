import { act, cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, expect, it } from "vitest";
import { ClipLane } from "@/components/Waveform/ClipLane";
import { addMediaWithTranscript, deleteWords, newProject, type Word } from "@/lib/edl";
import { useEditorUiStore } from "@/stores/editorUiStore";
import { useProjectStore } from "@/stores/projectStore";

const media = {
  id: "m",
  path: "/m.mp4",
  duration: 9,
  fps: 25,
  width: 100,
  height: 100,
  audioSampleRate: 8000,
  sha256: "x",
};
const words: Word[] = Array.from({ length: 9 }, (_, i) => ({
  id: `w${i}`,
  text: `w${i}`,
  start: i,
  end: i + 1,
  confidence: 1,
}));
const PX = 100;

/** Three clips: [0,2] [3,5] [6,9] (w2, w5 deleted), 2 + 2 + 3 seconds. */
function load() {
  let p = addMediaWithTranscript(newProject("clip"), media, words);
  p = { ...p, settings: { ...p.settings, paddingMs: 0 } };
  useProjectStore.setState({ project: deleteWords(p, new Set(["w2", "w5"])) });
  useProjectStore.temporal.getState().clear();
}
const ids = () => useProjectStore.getState().project.segments.map((s) => s.words[0]?.id);

function renderLane() {
  return render(
    <ClipLane project={useProjectStore.getState().project} pxPerSecond={PX} from={0} to={9} />,
  );
}
const pointer = (target: Element | Window, type: string, init: Record<string, unknown>) =>
  fireEvent(
    target,
    Object.assign(new MouseEvent(type, { bubbles: true, cancelable: true, ...init }), {
      pointerId: 1,
    }),
  );

beforeEach(() => {
  useProjectStore.temporal.getState().resume();
  useEditorUiStore.setState({ selectedClipId: null });
  load();
});
afterEach(cleanup);

it("drags the first clip past the second and commits one undoable move", () => {
  renderLane();
  expect(ids()).toEqual(["w0", "w3", "w6"]);
  const first = screen.getByRole("button", { name: "Clip 1" });
  pointer(first, "pointerdown", { clientX: 0, button: 0 });
  // Clip 1 is 2 s (200 px). Centre ends at 1 + 2.5 s: past clip 2's midpoint.
  pointer(window, "pointermove", { clientX: 250 });
  expect(screen.getByTestId("clip-drop")).toBeTruthy();
  pointer(window, "pointerup", { clientX: 250 });
  expect(ids()).toEqual(["w3", "w0", "w6"]);
  expect(screen.queryByTestId("clip-drop")).toBeNull();
  act(() => useProjectStore.temporal.getState().undo());
  expect(ids()).toEqual(["w0", "w3", "w6"]);
});

it("treats a small movement as a click, not a drag", () => {
  renderLane();
  const first = screen.getByRole("button", { name: "Clip 1" });
  pointer(first, "pointerdown", { clientX: 0, button: 0 });
  pointer(window, "pointermove", { clientX: 2 });
  pointer(window, "pointerup", { clientX: 2 });
  expect(ids()).toEqual(["w0", "w3", "w6"]);
});

it("Escape cancels the drag and leaves the project untouched", () => {
  renderLane();
  const before = useProjectStore.getState().project;
  pointer(screen.getByRole("button", { name: "Clip 1" }), "pointerdown", {
    clientX: 0,
    button: 0,
  });
  pointer(window, "pointermove", { clientX: 250 });
  fireEvent.keyDown(window, { key: "Escape" });
  expect(screen.queryByTestId("clip-drop")).toBeNull();
  pointer(window, "pointerup", { clientX: 250 });
  expect(useProjectStore.getState().project).toBe(before);
});

it("the pointer leaving the window cancels the drag", () => {
  renderLane();
  const before = useProjectStore.getState().project;
  pointer(screen.getByRole("button", { name: "Clip 1" }), "pointerdown", {
    clientX: 0,
    button: 0,
  });
  pointer(window, "pointermove", { clientX: 250 });
  fireEvent.mouseOut(document.documentElement, { relatedTarget: null });
  pointer(window, "pointerup", { clientX: 250 });
  expect(useProjectStore.getState().project).toBe(before);
});

it("pointer cancel and window blur also end the drag without a commit", () => {
  renderLane();
  const before = useProjectStore.getState().project;
  for (const end of ["pointercancel", "blur"]) {
    pointer(screen.getByRole("button", { name: "Clip 1" }), "pointerdown", {
      clientX: 0,
      button: 0,
    });
    pointer(window, "pointermove", { clientX: 250 });
    fireEvent(window, new Event(end));
    pointer(window, "pointerup", { clientX: 250 });
    expect(useProjectStore.getState().project).toBe(before);
  }
});

it("a drop back where it started does nothing", () => {
  renderLane();
  const before = useProjectStore.getState().project;
  pointer(screen.getByRole("button", { name: "Clip 2" }), "pointerdown", {
    clientX: 300,
    button: 0,
  });
  pointer(window, "pointermove", { clientX: 320 });
  pointer(window, "pointerup", { clientX: 320 });
  expect(useProjectStore.getState().project).toBe(before);
});

it("Option+Arrow moves the focused clip one place, one undo step each", () => {
  renderLane();
  const second = screen.getByRole("button", { name: "Clip 2" });
  fireEvent.keyDown(second, { key: "ArrowLeft", altKey: true });
  expect(ids()).toEqual(["w3", "w0", "w6"]);
  act(() => useProjectStore.temporal.getState().undo());
  expect(ids()).toEqual(["w0", "w3", "w6"]);
  // At the start there is nowhere to go.
  fireEvent.keyDown(screen.getByRole("button", { name: "Clip 1" }), {
    key: "ArrowLeft",
    altKey: true,
  });
  expect(ids()).toEqual(["w0", "w3", "w6"]);
});

it("advertises Option+Arrow and announces moves, duplicates and ripple deletes", () => {
  renderLane();
  const first = screen.getByRole("button", { name: "Clip 1" });
  expect(first.getAttribute("aria-keyshortcuts")).toBe("Alt+ArrowLeft Alt+ArrowRight");
  fireEvent.keyDown(screen.getByRole("button", { name: "Clip 2" }), {
    key: "ArrowLeft",
    altKey: true,
  });
  expect(screen.getByRole("status").textContent).toBe("Clip 2 moved to position 1 of 3");
  fireEvent.click(screen.getByRole("button", { name: "Clip 1" }));
  fireEvent.click(screen.getByRole("button", { name: "Duplicate clip" }));
  expect(screen.getByRole("status").textContent).toMatch(/duplicated/);
});

it("focuses the clip that moves up after a ripple delete", () => {
  const { rerender } = renderLane();
  fireEvent.click(screen.getByRole("button", { name: "Clip 2" }));
  fireEvent.click(screen.getByRole("button", { name: "Ripple delete" }));
  expect(screen.getByRole("status").textContent).toMatch(/deleted/);
  rerender(
    <ClipLane project={useProjectStore.getState().project} pxPerSecond={PX} from={0} to={9} />,
  );
  const survivor = useProjectStore.getState().project.segments[1]!.id; // old clip 3
  expect(document.activeElement).toBe(document.querySelector(`[data-clip-id="${survivor}"]`));
});

it("duplicate and ripple delete from the clip tools are single undo steps", () => {
  renderLane();
  fireEvent.click(screen.getByRole("button", { name: "Clip 2" }));
  fireEvent.click(screen.getByRole("button", { name: "Duplicate clip" }));
  expect(useProjectStore.getState().project.segments).toHaveLength(4);
  act(() => useProjectStore.temporal.getState().undo());
  expect(useProjectStore.getState().project.segments).toHaveLength(3);

  fireEvent.click(screen.getByRole("button", { name: "Clip 2" }));
  fireEvent.click(screen.getByRole("button", { name: "Ripple delete" }));
  expect(ids()).toEqual(["w0", "w6"]);
  act(() => useProjectStore.temporal.getState().undo());
  expect(ids()).toEqual(["w0", "w3", "w6"]);
});
