import { readFileSync } from "node:fs";
import { render, screen, waitFor, fireEvent } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { idleSnapshot } from "@/lib/snapshotDefaults";
import type { RecordingSnapshot } from "@/lib/ipc";

const ipc = vi.hoisted(() => ({
  current: null as null | ((s: RecordingSnapshot) => void),
  pauseRecording: vi.fn(async () => {}),
  resumeRecording: vi.fn(async () => {}),
  stopRecording: vi.fn(async () => ({})),
  cancelRecording: vi.fn(async () => {}),
  restartRecording: vi.fn(async () => ({})),
  markRecording: vi.fn(async () => 1),
  setControllerHidden: vi.fn(async () => {}),
  setControllerExpanded: vi.fn(async () => {}),
  showMainWindow: vi.fn(async () => {}),
}));
vi.mock("@/lib/ipc", () => ({
  ...ipc,
  getRecordingSnapshot: async () => ({
    ...idleSnapshot(1),
    sessionId: "s1",
    phase: "recording",
    mode: "screen",
    backend: "native",
    elapsedSec: 5,
  }),
  onRecordSnapshot: async (h: (s: RecordingSnapshot) => void) => {
    ipc.current = h;
    return () => {};
  },
}));

import { ControllerApp } from "@/controller/ControllerApp";

beforeEach(() => vi.clearAllMocks());

describe("ControllerApp", () => {
  it("sends session-id actions from its buttons", async () => {
    render(<ControllerApp />);
    fireEvent.click(await screen.findByLabelText("Pause recording"));
    expect(ipc.pauseRecording).toHaveBeenCalledWith("s1");
    fireEvent.click(screen.getByLabelText("Mark a moment"));
    expect(ipc.markRecording).toHaveBeenCalledWith("s1");
    fireEvent.click(screen.getByLabelText("Stop and add to video"));
    expect(ipc.stopRecording).toHaveBeenCalledWith("s1");
  });

  it("asks for confirmation before restarting or discarding, and Keep does nothing", async () => {
    render(<ControllerApp />);
    fireEvent.click(await screen.findByLabelText("More actions"));
    await waitFor(() => expect(ipc.setControllerExpanded).toHaveBeenCalledWith(true));
    fireEvent.click(screen.getByText("Discard recording…"));
    expect(ipc.cancelRecording).not.toHaveBeenCalled();
    fireEvent.click(screen.getByText("Keep"));
    expect(ipc.cancelRecording).not.toHaveBeenCalled();
    fireEvent.click(screen.getByLabelText("More actions"));
    fireEvent.click(screen.getByText("Restart take…"));
    fireEvent.click(screen.getByText("Restart"));
    expect(ipc.restartRecording).toHaveBeenCalledWith("s1");
  });

  it("restores the editor explicitly through the main-window command", async () => {
    render(<ControllerApp />);
    fireEvent.click(await screen.findByLabelText("More actions"));
    fireEvent.click(screen.getByText("Show editor"));
    expect(ipc.showMainWindow).toHaveBeenCalled();
  });

  it("follows later snapshots and shows resume when paused", async () => {
    render(<ControllerApp />);
    await screen.findByLabelText("Pause recording");
    ipc.current!({ ...idleSnapshot(2), sessionId: "s1", phase: "paused", mode: "screen" });
    expect(await screen.findByLabelText("Resume recording")).toBeTruthy();
  });
});

describe("controller entry point", () => {
  it("imports no editor App, project store, recording store, import or transcription code", () => {
    for (const file of ["src/controller/main.tsx", "src/controller/ControllerApp.tsx"]) {
      const source = readFileSync(file, "utf8");
      expect(source).not.toMatch(
        /from "(\.\.\/App|@\/App|@\/stores\/(project|recording|ui|player)Store)"/,
      );
      expect(source).not.toMatch(/useAutoSave|initRecorder|transcribe|importMedia/);
    }
  });
});
