import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "node:path";

// @ts-expect-error - process is provided by node at config time
const host = process.env.TAURI_DEV_HOST;

export default defineConfig(async () => ({
  plugins: [react()],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },

  // Three entry points: the editor (index.html), the desktop recording
  // controller (controller.html) and the floating recorder setup bar
  // (recorder-bar.html); the last two mount only their own UI.
  build: {
    rollupOptions: {
      input: {
        main: path.resolve(__dirname, "index.html"),
        controller: path.resolve(__dirname, "controller.html"),
        bar: path.resolve(__dirname, "recorder-bar.html"),
      },
    },
  },

  // Vite options tailored for Tauri
  clearScreen: false,
  server: {
    port: 1420,
    strictPort: true,
    host: host || false,
    hmr: host
      ? { protocol: "ws", host, port: 1421 }
      : undefined,
    watch: {
      ignored: ["**/src-tauri/**"],
    },
  },
  test: {
    environment: "jsdom",
    globals: true,
    setupFiles: ["./tests/setup.ts"],
    include: ["tests/**/*.test.ts", "tests/**/*.test.tsx", "src/**/*.test.ts", "src/**/*.test.tsx"],
  },
}));
