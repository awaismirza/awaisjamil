//! Prints the real production ffmpeg argv for an export, as JSON.
//!
//! usage: export_argv <opts.json> [--cursor-ass <path>]
//! `opts.json` is the same shape the frontend sends to `export_video`
//! (`ExportOpts`). When the options draw a cursor, the activity ASS is written
//! to `--cursor-ass` (default: temp dir) with the production generator.
use std::path::PathBuf;
use yusafcut_lib::commands::export::{
    cursor_overlay_active_for_bench, reencode_argv_for_bench, smart_cut_eligible,
    write_cursor_ass_for_bench, ExportOpts,
};

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let Some(opts_path) = args.first() else {
        eprintln!("usage: export_argv <opts.json> [--cursor-ass <path>]");
        std::process::exit(2);
    };
    let mut ass_path: Option<PathBuf> = None;
    let mut i = 1;
    while i < args.len() {
        if args[i] == "--cursor-ass" {
            ass_path = args.get(i + 1).map(PathBuf::from);
            i += 1;
        }
        i += 1;
    }
    let text = std::fs::read_to_string(opts_path).expect("read opts json");
    let opts: ExportOpts = serde_json::from_str(&text).expect("parse ExportOpts json");
    let total: f64 = opts
        .project
        .segments
        .iter()
        .map(|s| (s.source_out - s.source_in).max(0.0))
        .sum::<f64>()
        .max(0.001);
    let mut cursor_file: Option<PathBuf> = None;
    if cursor_overlay_active_for_bench(&opts) {
        let p = ass_path.unwrap_or_else(|| std::env::temp_dir().join("yusafcut-bench-cursor.ass"));
        if write_cursor_ass_for_bench(&opts, &p).expect("write cursor ass") {
            cursor_file = Some(p);
        }
    }
    let argv = reencode_argv_for_bench(&opts, total, None, cursor_file.as_deref()).expect("argv");
    println!(
        "{}",
        serde_json::json!({
            "argv": argv,
            "totalDuration": total,
            "smartCutEligible": smart_cut_eligible(&opts),
            "cursorAss": cursor_file,
        })
    );
}
