//! Prints the production ffmpeg argv for the analysis/proxy/Stop-to-edit paths as JSON.
//!
//! `--hash FILE` instead times `media::sha256_file` (the import-time hash).
//!
//! usage: cargo run --example analysis_argv -- --src IN.mp4 --proxy-out OUT.mp4 \
//!   --screen S.mp4 --camera C.mp4 --mic M.m4a --final OUT.mp4 [--noise -30 --min-dur 0.5]
//!
//! Real builders: `preview_cache::proxy_args` / `waveform_args`,
//! `native_capture::finalize_args`. Not callable builders today (inline in the
//! command handlers), so mirrored literally and marked `"mirrored": true`:
//! `commands/pauses.rs::detect_pauses` (silencedetect) and
//! `commands/transcribe.rs` 16 kHz WAV extraction.
use serde_json::json;
use std::collections::HashMap;
use std::path::PathBuf;
use yusafcut_lib::native_capture::{finalize_args, NativeTracks};
use yusafcut_lib::preview_cache::{proxy_args, waveform_args, PreviewQuality};
use yusafcut_lib::recorder::{PipCorner, PipSize, RecordMode, RecordOptions};

fn main() {
    let mut a: HashMap<String, String> = HashMap::new();
    let mut it = std::env::args().skip(1);
    while let Some(k) = it.next() {
        let v = it.next().unwrap_or_default();
        a.insert(k.trim_start_matches("--").to_owned(), v);
    }
    if let Some(path) = a.get("hash") {
        // Times the exact `media::sha256_file` used by `import_media`.
        let rt = tokio::runtime::Builder::new_multi_thread().enable_all().build().unwrap();
        let t = std::time::Instant::now();
        let digest = rt
            .block_on(yusafcut_lib::media::sha256_file(std::path::Path::new(path)))
            .expect("hash");
        let ms = t.elapsed().as_secs_f64() * 1000.0;
        println!("{}", json!({ "sha256": digest, "ms": ms }));
        return;
    }
    let get = |k: &str| a.get(k).cloned().unwrap_or_default();
    let src = get("src");
    let noise = a.get("noise").cloned().unwrap_or_else(|| "-30".into());
    let min_dur = a.get("min-dur").cloned().unwrap_or_else(|| "0.5".into());
    let proxy_out = get("proxy-out");
    let wav_out = a.get("wav-out").cloned().unwrap_or_else(|| proxy_out.clone());
    let final_out = PathBuf::from(get("final"));
    let tracks = NativeTracks {
        screen: Some(PathBuf::from(get("screen"))),
        camera: Some(PathBuf::from(get("camera"))),
        microphone: Some(PathBuf::from(get("mic"))),
        system_audio: None,
    };
    let opts = |mode| RecordOptions {
        mode,
        pip_corner: Some(PipCorner::BottomRight),
        pip_size: Some(PipSize::Medium),
        ..Default::default()
    };
    let af = format!("silencedetect=noise={noise}dB:d={min_dur}");
    let out = json!({
        "proxy_balanced": proxy_args(&src, &proxy_out, PreviewQuality::Balanced),
        "proxy_low": proxy_args(&src, &proxy_out, PreviewQuality::Low),
        "waveform": waveform_args(&src),
        "silencedetect": { "mirrored": true,
            "argv": ["-i", &src, "-vn", "-af", &af, "-hide_banner", "-f", "null", "-"] },
        "extract16k": { "mirrored": true,
            "argv": ["-y", "-nostdin", "-i", &src, "-vn", "-ac", "1", "-ar", "16000",
                     "-c:a", "pcm_s16le", &wav_out] },
        "finalize_screen_camera": finalize_args(&opts(RecordMode::ScreenCamera), &tracks, &final_out),
        "finalize_screen": finalize_args(&opts(RecordMode::Screen), &tracks, &final_out),
    });
    println!("{}", serde_json::to_string_pretty(&out).unwrap());
}
