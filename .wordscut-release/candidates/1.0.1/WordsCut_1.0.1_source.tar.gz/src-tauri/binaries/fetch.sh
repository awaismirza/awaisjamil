#!/usr/bin/env bash
# Build and verify native Apple Silicon ARM64 (aarch64-apple-darwin)
# ffmpeg/ffprobe binaries for YusafCut. whisper-cli must be built locally
# (see README.md).
#
# Run from anywhere; the script always cd's into its own directory.

set -euo pipefail
cd "$(dirname "$0")"

REPO_ROOT="$(cd ../.. && pwd)"
ARCH_SUFFIX="aarch64-apple-darwin"

if [[ "$(uname -s)" != "Darwin" ]] || [[ "$(uname -m)" != "arm64" ]]; then
  echo "Refusing to run: YusafCut supports Apple Silicon (arm64) Macs only." >&2
  exit 1
fi

needs_media_build=0
for tool in ffmpeg ffprobe; do
  bin="${tool}-${ARCH_SUFFIX}"
  if [[ ! -x "$bin" ]]; then
    needs_media_build=1
  else
    archs="$(lipo -archs "$bin" 2>/dev/null || true)"
    if [[ "$archs" != "arm64" ]]; then
      echo "Existing $bin has architecture '$archs' (expected arm64); rebuilding native arm64 binary..."
      needs_media_build=1
    fi
  fi
done

if [[ "$needs_media_build" -eq 1 ]]; then
  bash "$REPO_ROOT/scripts/build-arm64-media.sh" --install-dir "$(pwd)"
else
  echo "Existing native arm64 ffmpeg/ffprobe found; running compatibility verification..."
  bash "$REPO_ROOT/scripts/verify-media-binaries.sh" \
    --ffmpeg "$(pwd)/ffmpeg-${ARCH_SUFFIX}" \
    --ffprobe "$(pwd)/ffprobe-${ARCH_SUFFIX}"
fi

if [[ ! -f "whisper-cli-${ARCH_SUFFIX}" ]]; then
  echo "whisper-cli-${ARCH_SUFFIX} not found. Build from source:"
  echo "  https://github.com/ggerganov/whisper.cpp"
  echo "  WHISPER_COREML=1 WHISPER_METAL=1 make -j"
  echo "  cp main <here>/whisper-cli-${ARCH_SUFFIX}"
fi

echo "Done. Files in $(pwd):"
ls -la *-${ARCH_SUFFIX} 2>/dev/null || true
