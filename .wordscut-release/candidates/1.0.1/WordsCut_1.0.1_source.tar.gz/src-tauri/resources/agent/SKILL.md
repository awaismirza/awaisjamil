---
name: yusafcut
description: Edit videos in the running WordsCut app by editing its transcript. Cut words, fillers, silences and ranges, replace text, manage chapters and zoom regions, export video or captions. Use when the user asks to edit, trim, tidy, caption or export a WordsCut project.
---

# WordsCut editing skill

WordsCut is a local text-based video editor. Editing the transcript edits the video. You drive the **running app** through the `WordsCut agent` CLI or the `yusafcut` MCP server; edits appear live in the editor and are undoable.

Run `WordsCut agent readme` for the full guide (tool catalog, conventions, examples). The essentials:

## Workflow loop

1. `project_info` to see what is open (`project_open` with a `.scribe` path if nothing is).
2. `transcript_get` / `transcript_search` / `edl_get` to read. Page long transcripts with `offset`/`limit`.
3. Call an edit tool with `confirm:false` (the default). It changes nothing and returns a **plan**: summary, seconds removed, the words affected, new duration, and a `revision`.
4. Show the user the plan when the edit is large or ambiguous. Prefer small, well-described edits.
5. Call the same tool again with `confirm:true` and `baseRevision` set to the plan's `revision`. If the project changed meanwhile you get `STALE_REVISION`: re-read and re-plan.
6. `project_save` when the user wants it persisted. Undo any applied edit with `history {action:"undo"}`.

## Conventions

- Times are **output-timeline seconds** (what the viewer sees after cuts) unless a field is named `source*`.
- Refer to words by their stable `wordId` from `transcript_get`; do not guess ids.
- `edit_batch` applies several edit steps as one undo step; use it for multi-part cleanups.
- Exports are asynchronous: `export_start` (plan first, then `confirm:true`), then poll `export_status`.
- Never overwrite files unless the user agreed (`overwrite:true`).

## Shell usage

```
WordsCut agent project info --json
WordsCut agent tool call --name edit_cut_fillers --input-json '{"confirm":false}' --json
WordsCut agent tool call --name edit_cut_fillers --input-json '{"confirm":true,"baseRevision":12}' --json
```

Exit codes: 0 ok, 2 usage, 3 app not running, 4 access disabled or unauthorized (ask the user to enable it in WordsCut, Agent (CLI/MCP)), 5 tool error, 6 `STALE_REVISION`.
