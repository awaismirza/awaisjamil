# WordsCut agent guide

WordsCut is a local text-based video editor: editing the transcript edits the video. External agents (Claude Code, Codex, Gemini CLI, scripts) can drive the **running app** through this CLI or an MCP server. Everything is local; nothing leaves the machine.

Edits go through the same code as the UI. They show up live, one agent action = one undo step.

## Setup

1. Start WordsCut and open Agent (CLI/MCP) in the app. Switch "Allow agent access" on. (It is off by default.)
2. Use either interface:
   - **CLI**: `WordsCut agent <command>` (the binary is inside `WordsCut.app/Contents/MacOS/`; the dialog shows the exact path).
   - **MCP (stdio)**: register `WordsCut mcp` as a server, for example `claude mcp add yusafcut -- "<BIN>" mcp`.

If the app is not running the CLI launches it (`--no-launch` disables that) and waits up to 30 s.

## CLI reference

```
WordsCut agent readme
WordsCut agent status [--json]
WordsCut agent project open --path <dir.scribe> [--discard-unsaved] [--json]
WordsCut agent project info [--json]
WordsCut agent project save [--path <p>] [--json]
WordsCut agent project inspect --path <p> [--json]      # headless, read-only, app not needed
WordsCut agent tool list [--json]
WordsCut agent tool describe --name <tool> [--json]
WordsCut agent tool call --name <tool> (--input-json '<json>' | --input-file <file|->) [--json]
WordsCut agent skills [--print <name>] [--write <dir>]
WordsCut agent export --output <p> [--resolution 1080p] [--codec auto] [--confirm] [--json]
WordsCut mcp
Global: --no-launch  --timeout <sec>  --json
```

`--json` prints exactly one line: the tool outcome, `{"ok":true,"tool":"…","data":{…}}` or `{"ok":false,"tool":"…","error":{"code":"…","message":"…","hint":"…"}}`. Prefer it in scripts and agents.

Exit codes: 0 ok, 2 usage, 3 app not running or unreachable, 4 unauthorized or agent access disabled, 5 tool error, 6 `STALE_REVISION`.

`project open|info|save` and `export` are shorthand for `tool call`. Use `--input-file -` to pipe a large JSON input through stdin.

## The plan / confirm workflow loop

Every editing tool takes `confirm` (default `false`) and `baseRevision`.

1. **Read**: `project_info`, `transcript_get`, `transcript_search`, `edl_get`.
2. **Plan**: call the edit tool with `confirm:false`. Nothing changes. The plan has `summary`, `revision`, `durationBefore`/`durationAfter`, `removedSec`, `removedWords` (up to 200, with `removedWordCount`), `chapters` and `zoomRegions` before/after counts, and tool-specific `details`.
3. **Review**: check the plan against the user's intent. If it removes more than expected, narrow the input and plan again.
4. **Apply**: call again with `confirm:true` and `baseRevision` = the plan's `revision`. The result has `applied:true`, the new `revision` and an `undo` hint. If someone edited meanwhile you get `STALE_REVISION` (exit 6): re-read and re-plan.
5. **Undo** if wrong: `history {"action":"undo"}`. **Save** with `project_save`.

A no-op returns `applied:false, summary:"Nothing to do"` and adds no undo entry.

Do not skip step 2 for large edits (fillers, silences, ranges). Ask the user first when a plan removes a lot of content.

## Time conventions

- All times are seconds on the **output timeline**, the video as it plays after cuts, unless a name starts with `source` (original media time).
- After any cut, later times shift earlier. Re-read the transcript (or use word ids) instead of reusing old times.
- `wordId` is the stable `Word.id`; ids survive edits, times do not.

## Tool catalog (20 tools)

Read-only: `project_info`, `transcript_get` (words|sentences|text, paged), `transcript_search`, `edl_get`, `chapters_suggest`, `export_status`.

Edits (all plan/confirm): `edit_cut_words` (wordIds or ranges), `edit_cut_range` (delete or keep a range), `edit_cut_fillers`, `edit_trim_silences`, `edit_replace_text` (text only, not timing), `chapters_edit`, `zoom_edit`, `edit_batch` (several edits, one undo step).

Session and files: `history` (undo/redo), `project_open`, `project_save`, `captions_export` (srt|vtt), `export_start` (plan, then confirm; poll `export_status`), `export_cancel`.

Run `WordsCut agent tool list` and `tool describe --name <tool>` for the live catalog and exact input schemas. Inputs are strict: unknown fields are rejected with `INVALID_INPUT` and a JSON pointer.

Common error codes: `INVALID_INPUT`, `STALE_REVISION`, `BUSY` (export or recording running), `NO_MEDIA`, `NO_TRANSCRIPT`, `NOT_FOUND`, `DIRTY_PROJECT` (save first or pass `discardUnsaved`), `EDITOR_NOT_READY` (retry in a few seconds), `TIMEOUT`.

## Example: tidy a talking-head clip (CLI)

```
WordsCut agent project open --path ~/Movies/demo.scribe --json
WordsCut agent tool call --name project_info --json
WordsCut agent tool call --name transcript_get --input-json '{"format":"text"}' --json
WordsCut agent tool call --name edit_cut_fillers --input-json '{"confirm":false}' --json
# review the plan, then apply with the revision it reported
WordsCut agent tool call --name edit_cut_fillers --input-json '{"confirm":true,"baseRevision":3}' --json
WordsCut agent tool call --name edit_trim_silences --input-json '{"confirm":false,"minDurationSec":0.8}' --json
WordsCut agent project save --json
WordsCut agent export --output ~/Movies/demo.mp4 --resolution 1080p --json     # plan
WordsCut agent export --output ~/Movies/demo.mp4 --resolution 1080p --confirm --json
WordsCut agent tool call --name export_status --json                            # poll until running:false
```

## Example: several edits as one undo step

```
WordsCut agent tool call --name edit_batch --input-file - --json <<'JSON'
{"confirm":false,"steps":[
  {"name":"edit_cut_fillers","input":{}},
  {"name":"edit_replace_text","input":{"find":"YusufCut","replace":"WordsCut"}},
  {"name":"chapters_edit","input":{"fromSuggestions":{"count":5}}}
]}
JSON
```

Then repeat with `"confirm":true,"baseRevision":<revision>`.

## Example: MCP session

Register once (`claude mcp add yusafcut -- "<BIN>" mcp`). The agent then sees the tools natively and the same loop applies: call a tool with `confirm:false`, read `structuredContent`, call again with `confirm:true` and `baseRevision`. If the app is closed the bridge returns JSON-RPC error -32001; if access is off, -32002.

## Safety

- Agent access is off until the user enables it. While on, any process running as the same user can connect, so the connection token is private (file mode 0600) and changes on every launch.
- File access is restricted: open `.scribe` or `project.json`; save `.scribe`; export `.mp4`/`.mov` (`.m4a` for podcast audio); captions `.srt`/`.vtt`. Nothing is overwritten unless `overwrite:true`.
- Not in v1: B-roll/overlays, transcription, recording, music tracks, editing without the app.

Install this guide as a skill for Claude Code and similar tools with `WordsCut agent skills --write ~/.claude/skills`.
