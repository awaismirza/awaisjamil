//! Annotations (text, arrows, boxes) and the keystroke overlay as ASS vectors
//! and text for the bundled libass, like `cursor_export.rs`. Unlike the cursor
//! nothing moves per frame, so each item is one Dialogue line with `\fad`.
//!
//! The project keeps both as raw JSON (`Project::annotations`,
//! `Project::keystrokes`); everything is re-validated here with the rules of
//! `src/lib/annotations.ts` and `src/lib/keystrokes.ts`.
use crate::edl::Project;
use serde_json::Value;
use std::io::{self, Write};

pub const MIN_ANNOTATION_SEC: f64 = 0.25;
const MAX_TEXT_LENGTH: usize = 500;
const MAX_FADE_MS: f64 = 5000.;
pub(crate) const FONT: &str = "Arial Unicode MS";
/// libass sizes a font by its line height; this face's em is 0.754 of that
/// (measured: cap height 54 px at `\fs100`, cap height 0.716 em).
pub(crate) const EM_PER_FS: f64 = 0.754;
const KEY_MERGE_SEC: f64 = 1.;
const KEY_HOLD_SEC: f64 = 1.;
const KEY_FONT_PX: f64 = 44.;
/// At most this many annotations are drawn (same cap as `MAX_ANNOTATIONS` in annotations.ts).
pub const MAX_ANNOTATIONS: usize = 500;
/// Bottom edge of the key cap as a fraction of the frame height; mirrors
/// `KEY_CAP_Y` / `KEY_CAP_Y_ABOVE_CAPTIONS` in keystrokes.ts. Frame-layer order
/// is fixed annotations, then captions, then key caps; when captions sit at
/// the bottom, the caps move up so they never cover them.
pub const KEY_CAP_Y: f64 = 0.94;
pub const KEY_CAP_Y_ABOVE_CAPTIONS: f64 = 0.80;
pub fn key_cap_y(captions_at_bottom: bool) -> f64 {
    if captions_at_bottom {
        KEY_CAP_Y_ABOVE_CAPTIONS
    } else {
        KEY_CAP_Y
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Kind {
    Text,
    Arrow,
    Box,
}

#[derive(Clone, Debug, PartialEq)]
pub struct Annotation {
    pub kind: Kind,
    pub start: f64,
    pub end: f64,
    pub x: f64,
    pub y: f64,
    pub w: f64,
    pub h: f64,
    /// `#rrggbb`.
    pub color: String,
    pub stroke: f64,
    pub font_size: f64,
    pub filled: bool,
    pub text: String,
    pub fade_in_ms: f64,
    pub fade_out_ms: f64,
    pub follow_zoom: bool,
}

fn num(v: &Value, fallback: f64) -> f64 {
    v.as_f64().filter(|n| n.is_finite()).unwrap_or(fallback)
}

/// Control characters except newlines are dropped; length is capped. Unicode is kept.
/// Colour emoji (libass cannot draw Apple Color Emoji: they would export as
/// boxes). Same ranges as `isEmoji` in annotations.ts. BMP symbols, CJK and
/// Hangul are kept: Arial Unicode MS draws them.
pub fn is_emoji(c: char) -> bool {
    matches!(c as u32, 0x1F000..=0x1FAFF | 0xFE0F | 0x20E3 | 0xE0020..=0xE007F)
}

fn clean_text(raw: &str) -> String {
    raw.replace("\r\n", "\n")
        .replace('\r', "\n")
        .chars()
        .filter(|c| *c == '\n' || !(c.is_control() || is_emoji(*c)))
        .take(MAX_TEXT_LENGTH)
        .collect()
}

/// One stored value -> a valid annotation. Mirrors `sanitizeAnnotation` in annotations.ts.
fn sanitize_one(r: &Value, total: f64) -> Option<Annotation> {
    let kind = match r["kind"].as_str()? {
        "text" => Kind::Text,
        "arrow" => Kind::Arrow,
        "box" => Kind::Box,
        _ => return None,
    };
    let start = r["start"]
        .as_f64()
        .filter(|n| n.is_finite())?
        .clamp(0., total);
    let end = r["end"]
        .as_f64()
        .filter(|n| n.is_finite())?
        .clamp(0., total);
    if end - start < MIN_ANNOTATION_SEC - 1e-9 {
        return None;
    }
    let x = num(&r["x"], 0.1).clamp(0., 1.);
    let y = num(&r["y"], 0.1).clamp(0., 1.);
    let (mut w, mut h) = (num(&r["w"], 0.3), num(&r["h"], 0.2));
    if kind == Kind::Arrow {
        w = (x + w).clamp(0., 1.) - x;
        h = (y + h).clamp(0., 1.) - y;
    } else {
        w = w.clamp(0.01, (1. - x).max(0.01));
        h = h.clamp(0.01, (1. - y).max(0.01));
    }
    let text = if kind == Kind::Text {
        let t = clean_text(r["text"].as_str().unwrap_or(""));
        if t.trim().is_empty() {
            return None;
        }
        t
    } else {
        String::new()
    };
    let mut fade_in = num(&r["fadeInMs"], 0.).clamp(0., MAX_FADE_MS);
    let mut fade_out = num(&r["fadeOutMs"], 0.).clamp(0., MAX_FADE_MS);
    let span = (end - start) * 1000.;
    if fade_in + fade_out > span {
        let f = span / (fade_in + fade_out);
        fade_in = (fade_in * f).floor();
        fade_out = (fade_out * f).floor();
    }
    let color = r["color"]
        .as_str()
        .filter(|s| {
            s.len() == 7 && s.starts_with('#') && s[1..].bytes().all(|b| b.is_ascii_hexdigit())
        })
        .unwrap_or("#ff3b30")
        .to_ascii_lowercase();
    Some(Annotation {
        kind,
        start,
        end,
        x,
        y,
        w,
        h,
        color,
        stroke: num(&r["stroke"], 6.).clamp(1., 40.),
        font_size: num(&r["fontSize"], 64.).clamp(8., 200.),
        filled: kind == Kind::Box && r["filled"] == Value::Bool(true),
        text,
        fade_in_ms: fade_in,
        fade_out_ms: fade_out,
        follow_zoom: r["followZoom"] == Value::Bool(true),
    })
}

/// Any stored value -> valid annotations sorted by start; junk is dropped.
pub fn sanitize(raw: Option<&Value>, total: f64) -> Vec<Annotation> {
    let mut out: Vec<_> = raw
        .and_then(Value::as_array)
        .map(|items| {
            items
                .iter()
                .filter_map(|r| sanitize_one(r, total))
                .take(MAX_ANNOTATIONS)
                .collect()
        })
        .unwrap_or_default();
    out.sort_by(|a: &Annotation, b| a.start.total_cmp(&b.start).then(a.end.total_cmp(&b.end)));
    out
}

#[derive(Clone, Debug, PartialEq)]
pub struct KeyCaption {
    pub start: f64,
    pub end: f64,
    pub label: String,
}

const TYPING_HIDDEN: &str = "Typing (hidden)";

/// Mirrors `keyCapText` in keystrokes.ts: the cap for a logged key name, "key"
/// when there is none or it is not understood.
fn key_cap_text(name: Option<&str>) -> String {
    let Some(name) = name else {
        return "key".into();
    };
    let named = match name {
        "return" => "↩",
        "tab" => "⇥",
        "space" => "Space",
        "delete" => "⌫",
        "forwarddelete" => "⌦",
        "esc" => "⎋",
        "left" => "←",
        "right" => "→",
        "up" => "↑",
        "down" => "↓",
        "home" => "Home",
        "end" => "End",
        "pageup" => "PgUp",
        "pagedown" => "PgDn",
        "insert" => "Ins",
        "clear" => "Clear",
        _ => "",
    };
    if !named.is_empty() {
        return named.into();
    }
    // f1..f20, no leading zeros (same as /^f([1-9]|1\d|20)$/).
    let digits = name.strip_prefix('f').unwrap_or("");
    let is_f = !digits.starts_with('0')
        && digits.bytes().all(|b| b.is_ascii_digit())
        && digits.parse::<u8>().is_ok_and(|n| (1..=20).contains(&n));
    if is_f || name.chars().count() == 1 {
        name.to_uppercase()
    } else {
        "key".into()
    }
}

/// The logged `name`, only when it is 1..=16 non-control characters (as `cursor.ts`).
fn key_name(e: &Value) -> Option<&str> {
    e["name"]
        .as_str()
        .filter(|n| (1..=16).contains(&n.chars().count()) && !n.chars().any(|c| c.is_control() || ('\u{F700}'..='\u{F8FF}').contains(&c)))
}

/// Mirrors `keyCaps` in keystrokes.ts. Without a logged name a shortcut is its
/// modifiers plus a generic "key"; a secure-input press never shows its key.
fn key_caps(mods: &[&str], all: bool, name: Option<&str>, secure: bool) -> Option<Vec<String>> {
    if secure {
        return all.then(|| vec![TYPING_HIDDEN.to_string()]);
    }
    if mods.iter().any(|m| matches!(*m, "cmd" | "ctrl" | "alt")) {
        let mut caps: Vec<String> = [("ctrl", "⌃"), ("alt", "⌥"), ("shift", "⇧"), ("cmd", "⌘")]
            .iter()
            .filter(|(m, _)| mods.contains(m))
            .map(|(_, s)| s.to_string())
            .collect();
        caps.push(key_cap_text(name));
        Some(caps)
    } else if all {
        let cap = key_cap_text(name);
        Some(vec![if cap != "key" { cap } else { "Typing".into() }])
    } else {
        None
    }
}

/// Mirrors `keystrokeCaptions` + `captionLabel` in keystrokes.ts. Opt-in:
/// nothing unless `project.keystrokes.enabled` is true.
/// Source -> output time is speed and hold aware (`Segment::output_len`, the
/// inverse of `source_at`), like `keystrokeCaptions` in TypeScript.
pub fn keystroke_captions(project: &Project) -> Vec<KeyCaption> {
    let Some(settings) = project.keystrokes.as_ref() else {
        return Vec::new();
    };
    if settings["enabled"] != Value::Bool(true) {
        return Vec::new();
    }
    let all = settings["mode"].as_str() == Some("all");
    // Privacy: no caps for presses under a mask, none on screen while one shows (`keystrokeCaptions`).
    let masks = crate::layers_export::source_masks(project);
    let masked: Vec<(f64, f64)> = masks.iter().flat_map(|m| crate::layers_export::mask_output_spans(project, m)).collect();
    let empty = Value::Null;
    let cursor = project.cursor.as_ref().unwrap_or(&empty);
    let mut presses: Vec<(f64, Vec<String>)> = Vec::new();
    let mut offset = 0.;
    for seg in &project.segments {
        let len = seg.output_len();
        for e in cursor["tracks"][&seg.media_id]["events"]
            .as_array()
            .into_iter()
            .flatten()
        {
            let Some(t) = e["t"].as_f64().filter(|t| t.is_finite()) else {
                continue;
            };
            if e["type"].as_str() != Some("key") || t < seg.source_in || t >= seg.source_out {
                continue;
            }
            if crate::layers_export::source_masked(&masks, project, &seg.media_id, t) {
                continue;
            }
            let mods: Vec<&str> = e["mods"]
                .as_array()
                .into_iter()
                .flatten()
                .filter_map(Value::as_str)
                .collect();
            let secure = e["secure"] == Value::Bool(true);
            if let Some(caps) = key_caps(&mods, all, key_name(e), secure) {
                presses.push((offset + (t - seg.source_in) / seg.speed(), caps));
            }
        }
        offset += len;
    }
    presses.sort_by(|a, b| a.0.total_cmp(&b.0));
    let mut out: Vec<(f64, f64, Vec<String>, u32)> = Vec::new();
    let mut last_t = f64::NEG_INFINITY;
    for (t, caps) in presses {
        let gap = t - last_t;
        last_t = t;
        if let Some(last) = out.last_mut() {
            if last.2 == caps && gap <= KEY_MERGE_SEC {
                last.1 = offset.min(t + KEY_HOLD_SEC);
                last.3 += 1;
                continue;
            }
            if last.1 > t {
                last.1 = t;
            }
        }
        out.push((t, offset.min(t + KEY_HOLD_SEC), caps, 1));
    }
    for c in &mut out {
        for (a, b) in &masked {
            if *a <= c.0 && *b > c.0 {
                c.1 = c.0;
            } else if *a > c.0 && *a < c.1 {
                c.1 = *a;
            }
        }
    }
    out.into_iter()
        .filter(|c| c.1 - c.0 > 1e-3)
        .map(|(start, end, caps, count)| {
            let typing = caps == ["Typing"] || caps == [TYPING_HIDDEN];
            let mut label = caps.join(" ");
            if count > 1 && !typing {
                label += &format!(" ×{count}");
            }
            KeyCaption { start, end, label }
        })
        .collect()
}

/// What to draw: annotations that zoom with the picture, ones fixed on the
/// frame, and keystroke captions (also fixed).
#[derive(Debug, Default)]
pub struct Overlays {
    pub follow: Vec<Annotation>,
    pub fixed: Vec<Annotation>,
    pub keys: Vec<KeyCaption>,
}
impl Overlays {
    pub fn collect(project: &Project) -> Self {
        let total = project.output_duration();
        let (follow, fixed) = sanitize(project.annotations.as_ref(), total)
            .into_iter()
            .partition(|a| a.follow_zoom);
        Self {
            follow,
            fixed,
            keys: keystroke_captions(project),
        }
    }
    pub fn is_empty(&self) -> bool {
        self.follow.is_empty() && self.fixed.is_empty() && self.keys.is_empty()
    }
}

fn time(t: f64) -> String {
    let cs = (t * 100. + 1e-7).floor().max(0.) as u64;
    format!(
        "{}:{:02}:{:02}.{:02}",
        cs / 360000,
        (cs / 6000) % 60,
        (cs / 100) % 60,
        cs % 100
    )
}

/// `#rrggbb` -> ASS `BBGGRR`.
fn ass_color(s: &str) -> String {
    format!("{}{}{}", &s[5..7], &s[3..5], &s[1..3]).to_ascii_uppercase()
}

/// User text -> ASS dialogue text. `{`/`}` would open override blocks and
/// `\N`, `\n`, `\h` are escapes, so braces are escaped and every backslash is
/// followed by an invisible word joiner. Newlines become `\N`.
pub fn escape_text(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    for c in s.chars() {
        match c {
            '\\' => out.push_str("\\\u{2060}"),
            '{' => out.push_str("\\{"),
            '}' => out.push_str("\\}"),
            '\n' => out.push_str("\\N"),
            c if c.is_control() => {}
            c => out.push(c),
        }
    }
    out
}

/// Shared shape with `arrowPolygon` in annotations.ts.
pub fn arrow_polygon(x1: f64, y1: f64, x2: f64, y2: f64, stroke: f64) -> Vec<(f64, f64)> {
    let len = (x2 - x1).hypot(y2 - y1);
    if len < 1e-6 {
        return Vec::new();
    }
    let (dx, dy) = ((x2 - x1) / len, (y2 - y1) / len);
    let (nx, ny) = (-dy, dx);
    let head = len.min(stroke * 4.);
    let (hw, sw) = (stroke * 2., stroke / 2.);
    let (bx, by) = (x2 - dx * head, y2 - dy * head);
    vec![
        (x1 + nx * sw, y1 + ny * sw),
        (bx + nx * sw, by + ny * sw),
        (bx + nx * hw, by + ny * hw),
        (x2, y2),
        (bx - nx * hw, by - ny * hw),
        (bx - nx * sw, by - ny * sw),
        (x1 - nx * sw, y1 - ny * sw),
    ]
}

fn polygon(points: &[(f64, f64)]) -> String {
    let mut s = String::new();
    for (i, (x, y)) in points.iter().enumerate() {
        s += &match i {
            0 => format!("m {x:.2} {y:.2}"),
            1 => format!(" l {x:.2} {y:.2}"),
            _ => format!(" {x:.2} {y:.2}"),
        };
    }
    s
}

/// Where normalised coordinates live inside the `width` x `height` frame.
#[derive(Clone, Copy, Debug)]
pub struct Rect {
    pub x: f64,
    pub y: f64,
    pub w: f64,
    pub h: f64,
}
impl Rect {
    /// A `src_w` x `src_h` picture fitted (letterboxed) into the frame, as the exporter pads it.
    pub fn fit(width: u32, height: u32, src_w: u32, src_h: u32) -> Self {
        let fit = (width as f64 / src_w.max(1) as f64).min(height as f64 / src_h.max(1) as f64);
        let (w, h) = (src_w.max(1) as f64 * fit, src_h.max(1) as f64 * fit);
        Self {
            x: (width as f64 - w) / 2.,
            y: (height as f64 - h) / 2.,
            w,
            h,
        }
    }
}

/// One ASS script for a layer. Sizes scale with the rect height (1080-line
/// units). `key_y`: bottom of the key caps as a fraction of the rect (`key_cap_y`).
#[allow(clippy::too_many_arguments)]
pub fn write_ass<W: Write>(
    out: &mut W,
    annotations: &[Annotation],
    keys: &[KeyCaption],
    width: u32,
    height: u32,
    rect: Rect,
    key_y: f64,
) -> io::Result<()> {
    let k = rect.h / 1080.;
    writeln!(out, "[Script Info]\nScriptType: v4.00+\nPlayResX: {width}\nPlayResY: {height}\nScaledBorderAndShadow: yes\nWrapStyle: 2\n[V4+ Styles]\nFormat: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\nStyle: Note,{FONT},20,&H00FFFFFF,&H00FFFFFF,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,0,0,7,0,0,0,1\nStyle: Key,{FONT},20,&H00FFFFFF,&H00FFFFFF,&H30202020,&H00000000,1,0,0,0,100,100,0,0,3,0,0,2,0,0,0,1\n[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text")?;
    for a in annotations {
        let (x, y) = (rect.x + a.x * rect.w, rect.y + a.y * rect.h);
        let c = ass_color(&a.color);
        let fade = format!("\\fad({},{})", a.fade_in_ms as u32, a.fade_out_ms as u32);
        let body = match a.kind {
            Kind::Text => {
                let em = a.font_size * k;
                format!(
                    "{{\\an7\\pos({x:.2},{y:.2})\\fs{:.2}\\bord{:.2}\\shad0\\1c&H{c}&\\3c&H000000&{fade}}}{}",
                    em / EM_PER_FS,
                    (em * 0.05).max(1.),
                    escape_text(&a.text)
                )
            }
            Kind::Box => {
                let (x1, y1) = (x + a.w * rect.w, y + a.h * rect.h);
                let shape = if a.filled {
                    polygon(&[(x, y), (x1, y), (x1, y1), (x, y1)])
                } else {
                    // libass borders only grow outwards, so the outline is drawn as a
                    // ring centred on the edge, like an SVG stroke: outer minus inner.
                    let s = a.stroke * k / 2.;
                    let mut ring = polygon(&[
                        (x - s, y - s),
                        (x1 + s, y - s),
                        (x1 + s, y1 + s),
                        (x - s, y1 + s),
                    ]);
                    if x1 - x > 2. * s && y1 - y > 2. * s {
                        ring += " ";
                        ring += &polygon(&[
                            (x + s, y + s),
                            (x + s, y1 - s),
                            (x1 - s, y1 - s),
                            (x1 - s, y + s),
                        ]);
                    }
                    ring
                };
                format!("{{\\an7\\pos(0,0)\\p1\\bord0\\shad0\\1c&H{c}&{fade}}}{shape}")
            }
            Kind::Arrow => {
                let points = arrow_polygon(x, y, x + a.w * rect.w, y + a.h * rect.h, a.stroke * k);
                if points.is_empty() {
                    continue;
                }
                format!(
                    "{{\\an7\\pos(0,0)\\p1\\bord0\\shad0\\1c&H{c}&{fade}}}{}",
                    polygon(&points)
                )
            }
        };
        writeln!(
            out,
            "Dialogue: 1,{},{},Note,,0,0,0,,{body}",
            time(a.start),
            time(a.end)
        )?;
    }
    for key in keys {
        let em = KEY_FONT_PX * k;
        writeln!(
            out,
            "Dialogue: 2,{},{},Key,,0,0,0,,{{\\an2\\pos({:.2},{:.2})\\fs{:.2}\\bord{:.2}}}{}",
            time(key.start),
            time(key.end),
            rect.x + rect.w / 2.,
            rect.y + rect.h * key_y,
            em / EM_PER_FS,
            em * 0.35,
            escape_text(&key.label)
        )?;
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;
    use std::process::Command;

    fn project(extra: Value) -> Project {
        let mut v = json!({"version":1,"id":"p","name":"a","createdAt":"","updatedAt":"",
            "media":{"m":{"id":"m","path":"unused","duration":10,"fps":30,"width":640,"height":360,"audioSampleRate":48000,"sha256":""}},
            "segments":[{"id":"s","mediaId":"m","sourceIn":0,"sourceOut":4,"words":[]}],
            "settings":{"exportPreset":"youtube-1080p","paddingMs":0}});
        for (k, val) in extra.as_object().unwrap() {
            v[k] = val.clone();
        }
        serde_json::from_value(v).unwrap()
    }

    #[test]
    fn sanitize_drops_junk_clamps_and_keeps_unicode() {
        let raw = json!([
            {"kind":"text","start":1,"end":3,"x":2,"y":-1,"text":"Héllo 日本\u{0007}","color":"#ABCDEF","fadeInMs":3000,"fadeOutMs":3000},
            {"kind":"text","start":0,"end":1,"text":"   "},
            {"kind":"box","start":0,"end":0.1},
            {"kind":"circle","start":0,"end":2},
            {"kind":"arrow","start":0,"end":9,"x":0.9,"y":0.5,"w":0.5,"h":0.1,"stroke":100},
            "junk"
        ]);
        let list = sanitize(Some(&raw), 4.);
        assert_eq!(list.len(), 2);
        assert_eq!(list[0].kind, Kind::Arrow);
        assert_eq!(list[0].end, 4.);
        assert!(
            (list[0].w - 0.1).abs() < 1e-9,
            "arrow head clamped inside the frame"
        );
        assert_eq!(list[0].stroke, 40.);
        let t = &list[1];
        assert_eq!((t.x, t.y), (1., 0.));
        assert_eq!(t.text, "Héllo 日本");
        assert_eq!(t.color, "#abcdef");
        assert_eq!(t.fade_in_ms + t.fade_out_ms, 2000., "fades fit the span");
    }

    #[test]
    fn emoji_are_stripped_symbols_kept_and_count_capped() {
        let raw = json!([{"kind":"text","start":0,"end":1,"text":"👍🏽 ok ©™ ⌘⇧ ✓ 日本 한국 ❤️ 🇬🇧"},
                         {"kind":"text","start":0,"end":1,"text":"🎉"}]);
        let list = sanitize(Some(&raw), 4.);
        assert_eq!(list.len(), 1, "emoji-only text is empty and dropped");
        assert_eq!(list[0].text, " ok ©™ ⌘⇧ ✓ 日本 한국 ❤ ");
        let many: Vec<_> = (0..600)
            .map(|i| json!({"kind":"box","start":0,"end":1,"id":i.to_string()}))
            .collect();
        assert_eq!(
            sanitize(Some(&Value::Array(many)), 4.).len(),
            MAX_ANNOTATIONS
        );
        assert_eq!(key_cap_y(true), KEY_CAP_Y_ABOVE_CAPTIONS);
    }

    #[test]
    fn escaping_neutralises_override_blocks_and_escapes() {
        assert_eq!(
            escape_text("{\\b1}a\\Nb\nc"),
            "\\{\\\u{2060}b1\\}a\\\u{2060}Nb\\Nc"
        );
        let p = project(
            json!({"annotations":[{"kind":"text","start":0,"end":2,"text":"}{\\pos(0,0)}x"}]}),
        );
        let o = Overlays::collect(&p);
        let mut buf = Vec::new();
        write_ass(
            &mut buf,
            &o.fixed,
            &[],
            640,
            360,
            Rect::fit(640, 360, 640, 360),
            KEY_CAP_Y,
        )
        .unwrap();
        let line = String::from_utf8(buf)
            .unwrap()
            .lines()
            .last()
            .unwrap()
            .to_string();
        let text = line.split("\\fad(0,0)}").nth(1).unwrap();
        assert_eq!(text, "\\}\\{\\\u{2060}pos(0,0)\\}x");
    }

    #[test]
    fn keystrokes_follow_speed_and_holds() {
        // Mirrors "keystroke captions map press times through speed and holds" in timingIntegration.test.ts.
        let events = json!({"style":{},"tracks":{"m":{"events":[
            {"type":"key","t":2.0,"mods":["cmd"]},
            {"type":"key","t":5.0,"mods":["alt"]}]}}});
        let mut p = project(json!({"cursor": events}));
        p.keystrokes = Some(json!({"enabled":true}));
        let mut tail = p.segments[0].clone();
        p.segments[0].source_in = 0.;
        p.segments[0].source_out = 4.;
        p.segments[0].timing.speed = Some(2.);
        p.segments[0].timing.hold_sec = Some(1.);
        tail.id = "t".into();
        tail.source_in = 4.;
        tail.source_out = 8.;
        p.segments.push(tail);
        let starts: Vec<f64> = keystroke_captions(&p).iter().map(|c| c.start).collect();
        // Source 2 at 2x = output 1; the first clip is 2 s + 1 s hold, so source 5 = 3 + 1 = 4.
        assert_eq!(starts, vec![1.0, 4.0]);
        assert!((p.output_duration() - 7.0).abs() < 1e-9);
    }

    #[test]
    fn keystrokes_are_opt_in_shortcut_only_and_follow_cuts() {
        let events = json!({"style":{},"tracks":{"m":{"events":[
            {"type":"key","t":0.5},
            {"type":"key","t":1.0,"mods":["shift"]},
            {"type":"key","t":1.2,"mods":["cmd","shift"]},
            {"type":"key","t":1.6,"mods":["shift","cmd"]},
            {"type":"key","t":2.5,"mods":["ctrl"]},
            {"type":"key","t":3.5,"mods":["alt"]}]}}});
        let mut p = project(json!({"cursor": events}));
        assert!(keystroke_captions(&p).is_empty(), "off by default");
        p.keystrokes = Some(json!({"enabled":true}));
        // Cut 2..3 s out of the source.
        let mut tail = p.segments[0].clone();
        p.segments[0].source_out = 2.;
        tail.id = "t".into();
        tail.source_in = 3.;
        p.segments.push(tail);
        let c = keystroke_captions(&p);
        // ctrl at 2.5 s was cut; alt at 3.5 s now plays at 2.5 s and ends the ⇧⌘ caption.
        assert_eq!(
            c,
            vec![
                KeyCaption {
                    start: 1.2,
                    end: 2.5,
                    label: "⇧ ⌘ key ×2".into()
                },
                KeyCaption {
                    start: 2.5,
                    end: 3.0,
                    label: "⌥ key".into()
                },
            ]
        );
        p.keystrokes = Some(json!({"enabled":true,"mode":"all"}));
        let all = keystroke_captions(&p);
        assert_eq!(all[0].label, "Typing");
        assert_eq!(all[0].start, 0.5);
        assert_eq!(all[0].end, 1.2, "a shortcut ends the typing caption");
    }

    #[test]
    fn key_identity_matches_the_shared_fixture() {
        // Same fixture and expectations as "key identity (shared with Rust)" in tests/keystrokes.test.ts.
        let fixture: Value =
            serde_json::from_str(include_str!("../../tests/fixtures/keystroke-identity.json")).unwrap();
        for case in fixture["cases"].as_array().unwrap() {
            let events = json!({"style":{},"tracks":{"m":{"events":case["events"]}}});
            let mut p = project(json!({"cursor": events}));
            p.segments[0].source_out = 10.;
            p.keystrokes = Some(json!({"enabled":true,"mode":case["mode"]}));
            let got = keystroke_captions(&p);
            let want = case["expected"].as_array().unwrap();
            assert_eq!(got.len(), want.len(), "{}: {got:?}", case["name"]);
            for (g, w) in got.iter().zip(want) {
                assert!((g.start - w["start"].as_f64().unwrap()).abs() < 1e-9, "{}: {g:?}", case["name"]);
                assert!((g.end - w["end"].as_f64().unwrap()).abs() < 1e-9, "{}: {g:?}", case["name"]);
                assert_eq!(g.label, w["label"].as_str().unwrap(), "{}", case["name"]);
            }
        }
    }

    fn ff() -> Option<std::path::PathBuf> {
        let ff = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("binaries/ffmpeg-aarch64-apple-darwin");
        ff.exists().then_some(ff)
    }

    /// Render one frame at `at` seconds through real ffmpeg + libass, as RGB.
    fn render(ass: &str, at: f64) -> Vec<u8> {
        let path =
            std::env::temp_dir().join(format!("yusafcut-annot-{}.ass", uuid::Uuid::new_v4()));
        std::fs::write(&path, ass).unwrap();
        let out = Command::new(ff().unwrap())
            .args([
                "-v",
                "error",
                "-f",
                "lavfi",
                "-i",
                "color=black:s=640x360:r=10:d=4",
                "-vf",
                &format!(
                    "ass={},select=eq(n\\,{})",
                    path.display(),
                    (at * 10.).round() as u32
                ),
                "-frames:v",
                "1",
                "-pix_fmt",
                "rgb24",
                "-f",
                "rawvideo",
                "pipe:1",
            ])
            .output()
            .unwrap();
        std::fs::remove_file(path).unwrap();
        assert!(
            out.status.success(),
            "{}",
            String::from_utf8_lossy(&out.stderr)
        );
        assert_eq!(out.stdout.len(), 640 * 360 * 3);
        out.stdout
    }
    fn px(f: &[u8], x: usize, y: usize) -> [u8; 3] {
        let i = (y * 640 + x) * 3;
        [f[i], f[i + 1], f[i + 2]]
    }

    #[test]
    fn real_ffmpeg_draws_boxes_arrows_text_and_fades() {
        if ff().is_none() {
            return;
        }
        let p = project(json!({"annotations":[
            {"kind":"box","start":0,"end":2,"x":0.25,"y":0.25,"w":0.5,"h":0.5,"color":"#ff0000","stroke":12},
            {"kind":"box","start":2,"end":4,"x":0.1,"y":0.1,"w":0.2,"h":0.2,"color":"#00ff00","filled":true,"fadeInMs":1000},
            {"kind":"arrow","start":0,"end":2,"x":0.05,"y":0.9,"w":0.3,"h":0,"color":"#0000ff","stroke":18},
            {"kind":"text","start":0,"end":2,"x":0.7,"y":0.05,"text":"{H}\\N","color":"#ffffff","fontSize":100}
        ]}));
        let o = Overlays::collect(&p);
        let mut buf = Vec::new();
        write_ass(
            &mut buf,
            &o.fixed,
            &[],
            640,
            360,
            Rect::fit(640, 360, 640, 360),
            KEY_CAP_Y,
        )
        .unwrap();
        let ass = String::from_utf8(buf).unwrap();
        let f = render(&ass, 1.);
        // Outline box: stroke 12 px @1080 = 4 px here, centred on x = 160.
        assert!(
            px(&f, 160, 180)[0] > 200 && px(&f, 160, 180)[1] < 40,
            "box edge {:?}",
            px(&f, 160, 180)
        );
        assert!(
            px(&f, 157, 180)[0] < 60 && px(&f, 163, 180)[0] < 60,
            "stroke stays ~4 px wide"
        );
        assert_eq!(px(&f, 320, 180), [0, 0, 0], "outline box is hollow");
        // Arrow from x=32 to x=224 at y=324: shaft and a head wider than the shaft.
        assert!(px(&f, 100, 324)[2] > 200);
        assert!(px(&f, 100, 324 - 6)[2] < 60, "shaft is 6 px");
        assert!(px(&f, 205, 324 - 8)[2] > 200, "head is wider");
        assert_eq!(px(&f, 230, 324), [0, 0, 0], "tip ends at the head point");
        // Text: braces and backslashes are drawn, not parsed; cap height 0.716 em.
        let lit: Vec<(usize, usize)> = (0..360)
            .flat_map(|y| (440..640).map(move |x| (x, y)))
            .filter(|(x, y)| px(&f, *x, *y)[1] > 200)
            .collect();
        let (top, bottom) = (
            lit.iter().map(|p| p.1).min().unwrap(),
            lit.iter().map(|p| p.1).max().unwrap(),
        );
        let em = 100. / 3.;
        assert!(
            (top as f64 - (18. + 0.345 * em)).abs() <= 4.,
            "text top {top}"
        );
        assert!(
            bottom as f64 > 18. + em * 0.9,
            "braces drawn and descend: {bottom}"
        );
        // Fade-in: half way through, the filled green box is about half bright.
        let g = render(&ass, 2.5)[(64 * 640 + 96) * 3 + 1];
        assert!((90..170).contains(&g), "fade at half: {g}");
        assert!(render(&ass, 3.5)[(64 * 640 + 96) * 3 + 1] >= 250);
    }

    #[test]
    fn real_ffmpeg_draws_keystroke_caps_and_unicode_text() {
        if ff().is_none() {
            return;
        }
        let keys = vec![KeyCaption {
            start: 0.,
            end: 2.,
            label: "⇧ ⌘ key ×2".into(),
        }];
        let notes = sanitize(
            Some(
                &json!([{"kind":"text","start":0,"end":2,"x":0.05,"y":0.05,"text":"日本語 ✓","color":"#ffffff","fontSize":90}]),
            ),
            4.,
        );
        let mut buf = Vec::new();
        write_ass(
            &mut buf,
            &notes,
            &keys,
            640,
            360,
            Rect::fit(640, 360, 640, 360),
            KEY_CAP_Y,
        )
        .unwrap();
        let f = render(&String::from_utf8(buf).unwrap(), 1.);
        // The caption box sits bottom-centre, above 94 % of the height.
        let boxed = (250..390).filter(|x| px(&f, *x, 330)[0] > 20).count();
        assert!(boxed > 60, "key cap box drawn: {boxed}");
        assert_eq!(px(&f, 320, 350), [0, 0, 0], "nothing below the caption");
        // CJK glyphs render as real shapes (many lit pixels), not empty boxes only.
        let lit = (0..120)
            .flat_map(|y| (0..320).map(move |x| (x, y)))
            .filter(|(x, y)| px(&f, *x, *y)[0] > 200)
            .count();
        assert!(lit > 400, "unicode text drawn: {lit}");
    }
}
