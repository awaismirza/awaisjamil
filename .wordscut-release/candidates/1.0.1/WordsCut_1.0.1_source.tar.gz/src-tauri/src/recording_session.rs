//! The authoritative recording session.
//!
//! Rust owns the one recording session. Windows, the menu-bar item and global
//! shortcuts are *clients*: they read a [`RecordingSnapshot`] (initial fetch +
//! the `record:snapshot` event) and send actions that carry the session id they
//! believe they are controlling. This module is pure state — no Tauri, no
//! processes — so every ordering rule below is unit-tested.
//!
//! Rules enforced here:
//! * one session at a time; `begin` is rejected unless the phase is `Idle`;
//! * every action names a session id; an id from an older take is refused;
//! * an action is only valid in specific phases, so a duplicate Stop, a Pause
//!   while Finalizing, or a late helper failure after Stop cannot re-run work;
//! * `revision` increases on every change so a client that races its initial
//!   fetch against events keeps only the newest snapshot;
//! * elapsed media time never goes backwards within a take.

use serde::Serialize;
use std::future::Future;
use std::sync::{Arc, Mutex};
use tokio::sync::watch;
use uuid::Uuid;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
#[serde(rename_all = "lowercase")]
pub enum Phase {
    Idle,
    /// Capture is being started; cancellable.
    Starting,
    Recording,
    Paused,
    /// Stop accepted; files are being finalized. No further actions apply.
    Finalizing,
    /// The capture backend died mid-take. Recoverable media may exist: Stop saves
    /// it, Cancel discards it.
    Interrupted,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
#[serde(rename_all = "lowercase")]
pub enum Backend {
    Native,
    Ffmpeg,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Action {
    Pause,
    Resume,
    Stop,
    Cancel,
    Mark,
    Restart,
}

impl Action {
    fn allowed(self, phase: Phase) -> bool {
        use Phase::*;
        match self {
            Action::Pause | Action::Mark => phase == Recording,
            Action::Resume => phase == Paused,
            Action::Stop | Action::Restart => matches!(phase, Recording | Paused | Interrupted),
            Action::Cancel => matches!(phase, Starting | Recording | Paused | Interrupted),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct RecordingSnapshot {
    /// Increases on every change; clients ignore anything not newer than theirs.
    pub revision: u64,
    pub session_id: Option<String>,
    pub phase: Phase,
    pub backend: Option<Backend>,
    pub mode: Option<String>,
    /// Media time captured so far, never wall time.
    pub elapsed_sec: f64,
    /// Elapsed media time of each "mark a moment" press.
    pub markers: Vec<f64>,
    /// Latest problem for this take (or the last take, while idle).
    pub error: Option<String>,
    /// The user hid the desktop recording controller for this take.
    pub controller_hidden: bool,
    /// Key-name recording is on for this take: `"names"` or `"all"` (every character).
    /// Shown as an indicator in the controller and the menu bar while recording.
    pub key_names: Option<String>,
}

impl RecordingSnapshot {
    fn idle(revision: u64) -> Self {
        Self {
            revision,
            session_id: None,
            phase: Phase::Idle,
            backend: None,
            mode: None,
            elapsed_sec: 0.0,
            markers: vec![],
            error: None,
            controller_hidden: false,
            key_names: None,
        }
    }
}

/// Returned by [`SessionAuthority::begin`]; the starter races its work against
/// `cancel` so Cancel interrupts startup instead of waiting for it.
pub struct StartTicket {
    pub id: Uuid,
    pub cancel: AbortSignal,
}

/// Fires when the take is cancelled. Cloneable; cheap to check.
#[derive(Clone)]
pub struct AbortSignal(watch::Receiver<bool>);

impl AbortSignal {
    pub fn is_aborted(&self) -> bool {
        *self.0.borrow()
    }

    /// Resolves when aborted (never, if the sender is dropped unaborted).
    pub async fn aborted(&mut self) {
        loop {
            if *self.0.borrow() {
                return;
            }
            if self.0.changed().await.is_err() {
                std::future::pending::<()>().await;
            }
        }
    }

    /// A signal that never fires (for callers outside a session).
    pub fn never() -> Self {
        let (tx, rx) = watch::channel(false);
        std::mem::forget(tx);
        Self(rx)
    }
}

#[derive(Debug, PartialEq, Eq)]
pub struct Cancelled;

/// Run `work`, giving up at once if `signal` fires first.
pub async fn or_cancelled<T>(
    signal: &mut AbortSignal,
    work: impl Future<Output = T>,
) -> Result<T, Cancelled> {
    tokio::select! {
        biased;
        _ = signal.aborted() => Err(Cancelled),
        out = work => Ok(out),
    }
}

type Sink = Box<dyn Fn(&RecordingSnapshot) + Send + Sync>;

struct Inner {
    snap: RecordingSnapshot,
    abort: Option<watch::Sender<bool>>,
    sink: Option<Sink>,
}

impl Inner {
    fn publish(&mut self) {
        self.snap.revision += 1;
        if let Some(sink) = &self.sink {
            sink(&self.snap);
        }
    }
    fn current(&self, id: &str) -> Result<(), String> {
        match &self.snap.session_id {
            Some(current) if current == id => Ok(()),
            Some(_) => Err("that recording has already ended (stale session)".into()),
            None => Err("no recording is running".into()),
        }
    }
}

pub struct SessionAuthority {
    inner: Mutex<Inner>,
}

impl Default for SessionAuthority {
    fn default() -> Self {
        Self {
            inner: Mutex::new(Inner {
                snap: RecordingSnapshot::idle(0),
                abort: None,
                sink: None,
            }),
        }
    }
}

impl SessionAuthority {
    /// Called from `setup` to forward every change to the webviews. The sink runs
    /// under the state lock, so events leave in revision order; it must not call
    /// back into the authority.
    pub fn set_sink(&self, sink: impl Fn(&RecordingSnapshot) + Send + Sync + 'static) {
        self.inner.lock().unwrap().sink = Some(Box::new(sink));
    }

    pub fn snapshot(&self) -> RecordingSnapshot {
        self.inner.lock().unwrap().snap.clone()
    }

    /// Claim the one session slot (phase `Starting`).
    pub fn begin(&self, mode: &str, backend: Backend) -> Result<StartTicket, String> {
        let mut g = self.inner.lock().unwrap();
        if g.snap.phase != Phase::Idle {
            return Err(if g.snap.phase == Phase::Finalizing {
                "the previous recording is still being saved".into()
            } else {
                "a recording is already running".into()
            });
        }
        let id = Uuid::new_v4();
        let (tx, rx) = watch::channel(false);
        g.abort = Some(tx);
        g.snap = RecordingSnapshot {
            revision: g.snap.revision,
            session_id: Some(id.to_string()),
            phase: Phase::Starting,
            backend: Some(backend),
            mode: Some(mode.to_string()),
            ..RecordingSnapshot::idle(0)
        };
        g.publish();
        Ok(StartTicket {
            id,
            cancel: AbortSignal(rx),
        })
    }

    /// The abort signal of the live session (used by Resume, which also waits on
    /// capture startup).
    pub fn abort_signal(&self, id: &str) -> Option<AbortSignal> {
        let g = self.inner.lock().unwrap();
        g.current(id).ok()?;
        g.abort.as_ref().map(|tx| AbortSignal(tx.subscribe()))
    }

    pub fn set_backend(&self, id: &str, backend: Backend) {
        let mut g = self.inner.lock().unwrap();
        if g.current(id).is_ok() && g.snap.backend != Some(backend) {
            g.snap.backend = Some(backend);
            g.publish();
        }
    }

    /// Starting → Recording. False if the take was cancelled or replaced.
    pub fn activate(&self, id: &str) -> bool {
        let mut g = self.inner.lock().unwrap();
        if g.current(id).is_err() || g.snap.phase != Phase::Starting {
            return false;
        }
        if g.abort.as_ref().is_some_and(|tx| *tx.borrow()) {
            return false;
        }
        g.snap.phase = Phase::Recording;
        g.publish();
        true
    }

    /// Check an action against the session id and phase without changing state.
    /// Call before queuing for the action lock *and* again once it is held.
    pub fn authorize(&self, id: &str, action: Action) -> Result<(), String> {
        let g = self.inner.lock().unwrap();
        g.current(id)?;
        if action.allowed(g.snap.phase) {
            Ok(())
        } else {
            Err(format!(
                "cannot {} while the recording is {}",
                match action {
                    Action::Pause => "pause",
                    Action::Resume => "resume",
                    Action::Stop => "stop",
                    Action::Cancel => "cancel",
                    Action::Mark => "mark",
                    Action::Restart => "restart",
                },
                phase_word(g.snap.phase)
            ))
        }
    }

    /// Cancel accepted: fire the abort signal so in-flight startup (native first
    /// frame, FFmpeg first sample, resume) unwinds immediately.
    pub fn request_abort(&self, id: &str) -> Result<(), String> {
        let g = self.inner.lock().unwrap();
        g.current(id)?;
        if let Some(tx) = &g.abort {
            let _ = tx.send(true);
        }
        Ok(())
    }

    /// Apply a validated phase change. False (and no change) if stale/illegal.
    pub fn set_phase(&self, id: &str, phase: Phase) -> bool {
        let mut g = self.inner.lock().unwrap();
        if g.current(id).is_err() || g.snap.phase == phase {
            return false;
        }
        use Phase::*;
        let legal = match (g.snap.phase, phase) {
            (Recording, Paused) | (Paused, Recording) => true,
            (Recording | Paused | Interrupted, Finalizing) => true,
            (Recording | Paused, Interrupted) => true,
            _ => false,
        };
        if legal {
            g.snap.phase = phase;
            g.publish();
        }
        legal
    }

    /// Record elapsed media time. Stale ids, finished takes and backward jumps
    /// (a queued helper tick from before a pause, an FFmpeg segment boundary) are
    /// ignored.
    pub fn observe_elapsed(&self, id: &str, secs: f64) -> bool {
        let mut g = self.inner.lock().unwrap();
        if g.current(id).is_err()
            || !matches!(
                g.snap.phase,
                Phase::Recording | Phase::Paused | Phase::Interrupted
            )
            || !secs.is_finite()
            || secs <= g.snap.elapsed_sec
        {
            return false;
        }
        g.snap.elapsed_sec = secs;
        g.publish();
        true
    }

    /// Mark a moment at the current media time; returns that time.
    pub fn add_marker(&self, id: &str) -> Result<f64, String> {
        self.authorize(id, Action::Mark)?;
        let mut g = self.inner.lock().unwrap();
        let t = g.snap.elapsed_sec;
        g.snap.markers.push(t);
        g.publish();
        Ok(t)
    }

    /// Attach a message to the take without changing its phase.
    pub fn report_error(&self, id: &str, message: impl Into<String>) {
        let mut g = self.inner.lock().unwrap();
        if g.current(id).is_ok() {
            g.snap.error = Some(message.into());
            g.publish();
        }
    }

    /// The backend failed mid-take. Only meaningful while Recording/Paused: once
    /// Stop has been accepted (Finalizing) the failure belongs to that stop path
    /// and must not start a second finalization.
    pub fn interrupt(&self, id: &str, message: impl Into<String>) -> bool {
        self.interrupt_inner(id, message.into(), false)
    }

    /// Like `interrupt`, but a specific message the helper already reported
    /// (e.g. "USB Microphone was disconnected") wins over the generic one.
    pub fn interrupt_keeping_error(&self, id: &str, fallback: impl Into<String>) -> bool {
        self.interrupt_inner(id, fallback.into(), true)
    }

    fn interrupt_inner(&self, id: &str, message: String, keep_existing: bool) -> bool {
        let mut g = self.inner.lock().unwrap();
        if g.current(id).is_err() || !matches!(g.snap.phase, Phase::Recording | Phase::Paused) {
            return false;
        }
        g.snap.phase = Phase::Interrupted;
        if !(keep_existing && g.snap.error.is_some()) {
            g.snap.error = Some(message);
        }
        g.publish();
        true
    }

    /// End the take: back to Idle. `error` stays visible until the next start.
    /// Returns the markers captured, for the importer. False if stale.
    pub fn finish(&self, id: &str, error: Option<String>) -> Option<Vec<f64>> {
        let mut g = self.inner.lock().unwrap();
        g.current(id).ok()?;
        let markers = std::mem::take(&mut g.snap.markers);
        let revision = g.snap.revision;
        g.snap = RecordingSnapshot {
            error,
            ..RecordingSnapshot::idle(revision)
        };
        g.abort = None;
        g.publish();
        Some(markers)
    }

    /// Record which key-identity level this take uses (`None` = off). Native screen takes only.
    pub fn set_key_names(&self, id: &str, level: Option<&str>) {
        let mut g = self.inner.lock().unwrap();
        if g.current(id).is_err() {
            return;
        }
        g.snap.key_names = level.map(str::to_string);
        g.publish();
    }

    /// Show/hide the desktop controller for the live take. Allowed in any phase of
    /// a live session so the menu bar can restore it after it was hidden.
    pub fn set_controller_hidden(&self, hidden: bool) -> bool {
        let mut g = self.inner.lock().unwrap();
        if g.snap.session_id.is_none() || g.snap.controller_hidden == hidden {
            return false;
        }
        g.snap.controller_hidden = hidden;
        g.publish();
        true
    }

    pub fn markers(&self, id: &str) -> Vec<f64> {
        let g = self.inner.lock().unwrap();
        if g.current(id).is_ok() {
            g.snap.markers.clone()
        } else {
            vec![]
        }
    }
}

fn phase_word(phase: Phase) -> &'static str {
    match phase {
        Phase::Idle => "idle",
        Phase::Starting => "starting",
        Phase::Recording => "recording",
        Phase::Paused => "paused",
        Phase::Finalizing => "being saved",
        Phase::Interrupted => "interrupted",
    }
}

pub type SharedAuthority = Arc<SessionAuthority>;

#[cfg(test)]
mod tests {
    use super::*;
    use std::time::{Duration, Instant};

    fn live() -> (SessionAuthority, String) {
        let a = SessionAuthority::default();
        let t = a.begin("screen", Backend::Native).unwrap();
        let id = t.id.to_string();
        assert!(a.activate(&id));
        (a, id)
    }

    #[test]
    fn key_names_indicator_is_per_take_and_cleared_at_the_end() {
        let (a, id) = live();
        assert_eq!(a.snapshot().key_names, None);
        a.set_key_names(&id, Some("all"));
        assert_eq!(a.snapshot().key_names.as_deref(), Some("all"));
        a.set_key_names("stale", None);
        assert_eq!(a.snapshot().key_names.as_deref(), Some("all"), "stale ids are ignored");
        a.finish(&id, None);
        assert_eq!(a.snapshot().key_names, None);
    }

    #[test]
    fn only_one_session_and_duplicate_start_is_rejected() {
        let a = SessionAuthority::default();
        let first = a.begin("screen", Backend::Native).unwrap();
        assert_eq!(
            a.begin("camera", Backend::Ffmpeg).err().unwrap(),
            "a recording is already running"
        );
        assert_eq!(a.snapshot().session_id, Some(first.id.to_string()));
        assert_eq!(a.snapshot().phase, Phase::Starting);
    }

    #[test]
    fn stale_session_ids_are_refused_after_a_new_take_starts() {
        let (a, old) = live();
        assert!(a.finish(&old, None).is_some());
        let new = a.begin("screen", Backend::Native).unwrap().id.to_string();
        assert!(a.activate(&new));
        for action in [Action::Stop, Action::Pause, Action::Cancel, Action::Mark] {
            assert!(a.authorize(&old, action).unwrap_err().contains("stale"));
        }
        assert!(!a.set_phase(&old, Phase::Paused));
        assert!(!a.observe_elapsed(&old, 9.0));
        assert!(!a.interrupt(&old, "late failure"));
        assert_eq!(a.snapshot().phase, Phase::Recording);
        assert_eq!(a.snapshot().elapsed_sec, 0.0);
        assert!(a.authorize(&new, Action::Stop).is_ok());
    }

    #[test]
    fn actions_are_valid_only_in_their_phase() {
        let (a, id) = live();
        assert!(a.authorize(&id, Action::Resume).is_err());
        assert!(a.authorize(&id, Action::Pause).is_ok());
        assert!(a.set_phase(&id, Phase::Paused));
        assert!(a.authorize(&id, Action::Pause).is_err()); // duplicate pause
        assert!(a.authorize(&id, Action::Mark).is_err());
        assert!(a.authorize(&id, Action::Resume).is_ok());
    }

    #[test]
    fn duplicate_stop_cannot_finalize_twice() {
        let (a, id) = live();
        a.authorize(&id, Action::Stop).unwrap();
        assert!(a.set_phase(&id, Phase::Finalizing));
        // The second Stop (another window, the tray, a shortcut) re-checks after
        // it wins the action lock and is refused.
        assert!(a.authorize(&id, Action::Stop).unwrap_err().contains("saved"));
        assert!(a.authorize(&id, Action::Cancel).is_err());
        assert!(!a.set_phase(&id, Phase::Finalizing));
        a.finish(&id, None);
        assert!(a.authorize(&id, Action::Stop).unwrap_err().contains("no recording"));
    }

    #[test]
    fn helper_failure_after_stop_was_accepted_is_ignored() {
        let (a, id) = live();
        assert!(a.set_phase(&id, Phase::Finalizing));
        assert!(!a.interrupt(&id, "helper exited"));
        assert_eq!(a.snapshot().phase, Phase::Finalizing);
        assert_eq!(a.snapshot().error, None);
    }

    #[test]
    fn helper_failure_mid_take_is_truthful_and_stop_can_still_save() {
        let (a, id) = live();
        assert!(a.observe_elapsed(&id, 4.2));
        assert!(a.interrupt(&id, "display lost"));
        let s = a.snapshot();
        assert_eq!(s.phase, Phase::Interrupted);
        assert_eq!(s.error.as_deref(), Some("display lost"));
        assert_eq!(s.elapsed_sec, 4.2);
        assert!(a.authorize(&id, Action::Pause).is_err());
        assert!(a.authorize(&id, Action::Resume).is_err());
        assert!(a.authorize(&id, Action::Stop).is_ok());
        assert!(a.authorize(&id, Action::Cancel).is_ok());
        assert!(!a.interrupt(&id, "again")); // reported once
    }

    #[test]
    fn specific_helper_error_survives_the_generic_failed_state() {
        let (a, id) = live();
        a.report_error(&id, "USB Microphone was disconnected");
        assert!(a.interrupt_keeping_error(&id, "generic"));
        assert_eq!(a.snapshot().error.as_deref(), Some("USB Microphone was disconnected"));
        let (b, id2) = live();
        assert!(b.interrupt_keeping_error(&id2, "generic"));
        assert_eq!(b.snapshot().error.as_deref(), Some("generic"));
    }

    #[test]
    fn late_elapsed_ticks_never_move_the_clock_backwards() {
        let (a, id) = live();
        assert!(a.observe_elapsed(&id, 5.0));
        assert!(a.set_phase(&id, Phase::Paused));
        assert!(!a.observe_elapsed(&id, 3.0)); // queued tick from before the pause
        assert!(!a.observe_elapsed(&id, f64::NAN));
        assert!(a.set_phase(&id, Phase::Recording));
        assert!(!a.observe_elapsed(&id, 4.9));
        assert!(a.observe_elapsed(&id, 5.5));
        assert_eq!(a.snapshot().elapsed_sec, 5.5);
    }

    #[test]
    fn elapsed_is_ignored_while_starting_and_finalizing() {
        let a = SessionAuthority::default();
        let id = a.begin("screen", Backend::Native).unwrap().id.to_string();
        assert!(!a.observe_elapsed(&id, 1.0));
        a.activate(&id);
        a.set_phase(&id, Phase::Finalizing);
        assert!(!a.observe_elapsed(&id, 2.0));
    }

    #[test]
    fn markers_use_authoritative_media_time_and_are_returned_on_finish() {
        let (a, id) = live();
        a.observe_elapsed(&id, 2.5);
        assert_eq!(a.add_marker(&id).unwrap(), 2.5);
        a.observe_elapsed(&id, 7.0);
        a.add_marker(&id).unwrap();
        a.set_phase(&id, Phase::Paused);
        assert!(a.add_marker(&id).is_err());
        assert_eq!(a.snapshot().markers, vec![2.5, 7.0]);
        assert_eq!(a.finish(&id, None), Some(vec![2.5, 7.0]));
        assert!(a.snapshot().markers.is_empty());
    }

    #[test]
    fn revisions_are_strictly_increasing_across_takes() {
        let seen = Arc::new(Mutex::new(vec![]));
        let a = SessionAuthority::default();
        let s = seen.clone();
        a.set_sink(move |snap| s.lock().unwrap().push(snap.revision));
        let id = a.begin("screen", Backend::Native).unwrap().id.to_string();
        a.activate(&id);
        a.observe_elapsed(&id, 1.0);
        a.finish(&id, Some("x".into()));
        let id2 = a.begin("screen", Backend::Native).unwrap().id.to_string();
        a.finish(&id2, None);
        let revs = seen.lock().unwrap().clone();
        assert!(revs.windows(2).all(|w| w[1] > w[0]), "{revs:?}");
        assert_eq!(*revs.last().unwrap(), a.snapshot().revision);
    }

    #[test]
    fn finish_keeps_the_error_visible_while_idle() {
        let (a, id) = live();
        a.finish(&id, Some("camera disconnected".into()));
        let s = a.snapshot();
        assert_eq!(s.phase, Phase::Idle);
        assert_eq!(s.session_id, None);
        assert_eq!(s.error.as_deref(), Some("camera disconnected"));
        a.begin("screen", Backend::Native).unwrap();
        assert_eq!(a.snapshot().error, None);
    }

    #[test]
    fn cancel_during_startup_fires_the_signal_and_blocks_activation() {
        let a = SessionAuthority::default();
        let ticket = a.begin("screen", Backend::Native).unwrap();
        let id = ticket.id.to_string();
        assert!(a.authorize(&id, Action::Cancel).is_ok());
        assert!(a.authorize(&id, Action::Stop).is_err());
        assert!(a.authorize(&id, Action::Pause).is_err());
        assert!(!ticket.cancel.is_aborted());
        a.request_abort(&id).unwrap();
        assert!(ticket.cancel.is_aborted());
        // The starter must not be able to flip a cancelled take to Recording.
        assert!(!a.activate(&id));
    }

    #[tokio::test]
    async fn cancel_interrupts_a_thirty_second_startup_immediately() {
        let a = SessionAuthority::default();
        let mut ticket = a.begin("screen", Backend::Native).unwrap();
        let id = ticket.id.to_string();
        let started = Instant::now();
        let canceller = {
            let id = id.clone();
            let a = &a;
            async move {
                tokio::time::sleep(Duration::from_millis(30)).await;
                a.request_abort(&id).unwrap();
            }
        };
        let startup = or_cancelled(
            &mut ticket.cancel,
            tokio::time::sleep(Duration::from_secs(30)),
        );
        let (outcome, ()) = tokio::join!(startup, canceller);
        assert_eq!(outcome, Err(Cancelled));
        assert!(started.elapsed() < Duration::from_secs(2));
    }

    #[tokio::test]
    async fn completed_startup_wins_when_not_cancelled() {
        let a = SessionAuthority::default();
        let mut t = a.begin("screen", Backend::Native).unwrap();
        let out = or_cancelled(&mut t.cancel, async { 7 }).await;
        assert_eq!(out, Ok(7));
    }

    #[tokio::test]
    async fn resume_can_be_cancelled_through_the_session_signal() {
        let (a, id) = live();
        a.set_phase(&id, Phase::Paused);
        let mut sig = a.abort_signal(&id).unwrap();
        a.request_abort(&id).unwrap();
        let out = or_cancelled(&mut sig, tokio::time::sleep(Duration::from_secs(30))).await;
        assert_eq!(out, Err(Cancelled));
        assert!(a.abort_signal("not-this-session").is_none());
    }

    #[test]
    fn backend_fallback_updates_the_snapshot_once() {
        let a = SessionAuthority::default();
        let id = a.begin("screen", Backend::Native).unwrap().id.to_string();
        let rev = a.snapshot().revision;
        a.set_backend(&id, Backend::Native); // unchanged: no event
        assert_eq!(a.snapshot().revision, rev);
        a.set_backend(&id, Backend::Ffmpeg);
        assert_eq!(a.snapshot().backend, Some(Backend::Ffmpeg));
    }

    #[test]
    fn controller_visibility_belongs_to_the_take() {
        let (a, id) = live();
        assert!(a.set_controller_hidden(true));
        assert!(!a.set_controller_hidden(true)); // no event for a no-op
        assert!(a.snapshot().controller_hidden);
        a.finish(&id, None);
        assert!(!a.snapshot().controller_hidden);
        assert!(!a.set_controller_hidden(true)); // nothing to hide when idle
    }

    #[test]
    fn snapshot_serializes_for_the_frontend() {
        let (a, _) = live();
        let v = serde_json::to_value(a.snapshot()).unwrap();
        assert_eq!(v["phase"], "recording");
        assert_eq!(v["backend"], "native");
        assert!(v["sessionId"].is_string());
        assert!(v["elapsedSec"].is_number());
        assert!(v["markers"].is_array());
    }
}
