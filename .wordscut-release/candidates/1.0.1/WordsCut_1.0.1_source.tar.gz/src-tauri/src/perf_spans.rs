//! Opt-in native timing spans for performance baselines.
//!
//! Disabled by default. Enable with the `YUSAFCUT_PERF_SPANS=1` environment
//! variable or `set_enabled(true)`. Spans hold a static name, a duration, a
//! wall-clock start and an optional opaque id (job/session id). They never
//! carry file paths or media names. Storage is a bounded ring buffer
//! (`MAX_SPANS` entries); the oldest entries are dropped first.

use serde::Serialize;
use std::collections::VecDeque;
use std::sync::atomic::{AtomicU8, Ordering};
use std::sync::Mutex;
use std::time::{Instant, SystemTime, UNIX_EPOCH};

pub const MAX_SPANS: usize = 4096;
const ENV_VAR: &str = "YUSAFCUT_PERF_SPANS";
const MAX_ID_LEN: usize = 64;

#[derive(Debug, Clone, Serialize, PartialEq)]
#[serde(rename_all = "camelCase")]
pub struct SpanRecord {
    pub name: String,
    pub duration_ms: f64,
    pub start_unix_ms: u64,
    pub id: Option<String>,
}

/// Bounded FIFO of span records.
#[derive(Debug)]
pub struct SpanBuffer {
    cap: usize,
    items: VecDeque<SpanRecord>,
}

impl SpanBuffer {
    pub fn new(cap: usize) -> Self {
        let cap = cap.clamp(1, MAX_SPANS);
        Self { cap, items: VecDeque::with_capacity(cap.min(256)) }
    }

    pub fn push(&mut self, rec: SpanRecord) {
        if self.items.len() >= self.cap {
            self.items.pop_front();
        }
        self.items.push_back(rec);
    }

    pub fn snapshot(&self) -> Vec<SpanRecord> {
        self.items.iter().cloned().collect()
    }

    pub fn len(&self) -> usize {
        self.items.len()
    }

    pub fn is_empty(&self) -> bool {
        self.items.is_empty()
    }

    pub fn clear(&mut self) {
        self.items.clear();
    }
}

// 0 = not yet decided (read env), 1 = off, 2 = on.
static ENABLED: AtomicU8 = AtomicU8::new(0);
static BUFFER: Mutex<Option<SpanBuffer>> = Mutex::new(None);

fn env_enabled() -> bool {
    matches!(std::env::var(ENV_VAR).as_deref(), Ok("1") | Ok("true"))
}

pub fn is_enabled() -> bool {
    match ENABLED.load(Ordering::Relaxed) {
        1 => false,
        2 => true,
        _ => {
            let on = env_enabled();
            ENABLED.store(if on { 2 } else { 1 }, Ordering::Relaxed);
            on
        }
    }
}

pub fn set_enabled(on: bool) {
    ENABLED.store(if on { 2 } else { 1 }, Ordering::Relaxed);
}

fn with_buffer<R>(f: impl FnOnce(&mut SpanBuffer) -> R) -> R {
    let mut guard = BUFFER.lock().unwrap_or_else(|p| p.into_inner());
    f(guard.get_or_insert_with(|| SpanBuffer::new(MAX_SPANS)))
}

/// Record a finished span (no-op when disabled).
pub fn record(name: &str, duration_ms: f64, id: Option<&str>) {
    if !is_enabled() {
        return;
    }
    let start_unix_ms = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis() as u64)
        .unwrap_or(0)
        .saturating_sub(duration_ms as u64);
    let rec = SpanRecord {
        name: name.chars().take(64).collect(),
        duration_ms,
        start_unix_ms,
        id: id.map(|s| s.chars().take(MAX_ID_LEN).collect()),
    };
    with_buffer(|b| b.push(rec));
}

/// All retained spans, oldest first. Empty when disabled and nothing recorded.
pub fn snapshot() -> Vec<SpanRecord> {
    with_buffer(|b| b.snapshot())
}

pub fn clear() {
    with_buffer(|b| b.clear());
}

/// RAII timer: records on drop when spans are enabled.
pub struct Span {
    name: &'static str,
    id: Option<String>,
    started: Option<Instant>,
}

impl Span {
    pub fn start(name: &'static str) -> Self {
        Self { name, id: None, started: is_enabled().then(Instant::now) }
    }

    pub fn with_id(name: &'static str, id: &str) -> Self {
        let mut s = Self::start(name);
        if s.started.is_some() {
            s.id = Some(id.to_owned());
        }
        s
    }
}

impl Drop for Span {
    fn drop(&mut self) {
        if let Some(t) = self.started.take() {
            record(self.name, t.elapsed().as_secs_f64() * 1000.0, self.id.as_deref());
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn rec(i: usize) -> SpanRecord {
        SpanRecord { name: format!("s{i}"), duration_ms: i as f64, start_unix_ms: 0, id: None }
    }

    #[test]
    fn buffer_is_bounded_and_drops_oldest() {
        let mut b = SpanBuffer::new(4);
        for i in 0..10 {
            b.push(rec(i));
        }
        assert_eq!(b.len(), 4);
        let names: Vec<_> = b.snapshot().into_iter().map(|r| r.name).collect();
        assert_eq!(names, ["s6", "s7", "s8", "s9"]);
    }

    #[test]
    fn capacity_is_capped_at_max_spans() {
        let mut b = SpanBuffer::new(1_000_000);
        for i in 0..(MAX_SPANS + 100) {
            b.push(rec(i));
        }
        assert_eq!(b.len(), MAX_SPANS);
    }

    // Single test for the global state so parallel tests cannot race on it.
    #[test]
    fn global_is_opt_in_and_carries_no_paths() {
        set_enabled(false);
        clear();
        record("off", 1.0, Some("job-1"));
        drop(Span::start("off_span"));
        assert!(snapshot().is_empty());

        set_enabled(true);
        record("on", 2.0, Some("job-1"));
        drop(Span::with_id("guard", "job-2"));
        let snap = snapshot();
        assert_eq!(snap.len(), 2);
        assert_eq!(snap[0].name, "on");
        assert_eq!(snap[0].id.as_deref(), Some("job-1"));
        assert_eq!(snap[1].name, "guard");
        let json = serde_json::to_string(&snap).unwrap();
        assert!(!json.contains('/'));

        for i in 0..(MAX_SPANS + 50) {
            record("flood", i as f64, None);
        }
        assert_eq!(snapshot().len(), MAX_SPANS);
        set_enabled(false);
        clear();
    }
}
