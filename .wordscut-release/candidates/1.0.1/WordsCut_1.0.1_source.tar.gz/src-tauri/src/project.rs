//! Project file I/O.
//!
//! `.scribe` is a folder on disk (presented to the user as a bundle), structured:
//!   MyProject.scribe/
//!   ├── project.json
//!   ├── transcripts/           # raw whisper output per media (future)
//!   └── media-refs.json        # original paths + sha256
//!
//! We write atomically: serialise to `.tmp` then rename.

use crate::edl::Project;
use anyhow::{Context, Result};
use std::path::{Path, PathBuf};
use tokio::fs;

const PROJECT_FILE: &str = "project.json";
// Both editor save entry points and any other WebView share this process-level gate.
static SAVE_LOCK: tokio::sync::Mutex<()> = tokio::sync::Mutex::const_new(());

pub async fn save(project: &Project, path: &Path) -> Result<()> {
    let _guard = SAVE_LOCK.lock().await;
    fs::create_dir_all(path).await.with_context(|| format!("creating {}", path.display()))?;
    let main = path.join(PROJECT_FILE);
    let tmp = path.join(format!("{}.{}.tmp", PROJECT_FILE, uuid::Uuid::new_v4()));
    let json = serde_json::to_vec_pretty(project)?;
    if let Err(error) = fs::write(&tmp, json).await {
        let _ = fs::remove_file(&tmp).await;
        return Err(error).context("writing tmp");
    }
    if let Err(error) = fs::rename(&tmp, &main).await {
        let _ = fs::remove_file(&tmp).await;
        return Err(error).context("atomic rename");
    }
    Ok(())
}

pub async fn load(path: &Path) -> Result<Project> {
    let p: PathBuf = if path.is_dir() {
        path.join(PROJECT_FILE)
    } else {
        path.to_path_buf()
    };
    let raw = fs::read(&p).await.with_context(|| format!("reading {}", p.display()))?;
    let project: Project = serde_json::from_slice(&raw).context("parsing project.json")?;
    Ok(project)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::edl::{ExportPreset, ProjectSettings};
    use std::collections::HashMap;
    use tokio::runtime::Runtime;

    fn sample_project() -> Project {
        Project {
            version: 1,
            id: "abc".into(),
            name: "Sample".into(),
            created_at: "2025-01-01T00:00:00Z".into(),
            updated_at: "2025-01-01T00:00:00Z".into(),
            media: HashMap::new(),
            segments: vec![],
            settings: ProjectSettings {
                export_preset: ExportPreset::Youtube1080p,
                padding_ms: 80,
            },
            chapters: vec![],
            audio_tracks: vec![],
            scene: None,
            zoom_regions: None,
            cursor: None,
            captions: None,
            annotations: None,
            keystrokes: None, overlays: None, masks: None,
            original_transcripts: None,
        }
    }

    #[test]
    fn round_trip_via_tempdir() {
        let rt = Runtime::new().unwrap();
        rt.block_on(async {
            let dir = std::env::temp_dir().join(format!("yusafcut-test-{}", uuid::Uuid::new_v4()));
            let bundle = dir.join("Test.scribe");
            let p = sample_project();
            save(&p, &bundle).await.unwrap();
            let loaded = load(&bundle).await.unwrap();
            assert_eq!(p.id, loaded.id);
            assert_eq!(p.name, loaded.name);
            tokio::fs::remove_dir_all(&dir).await.ok();
        });
    }
    #[test]
    fn load_survives_hostile_timing_and_save_keeps_unknown_segment_keys() {
        Runtime::new().unwrap().block_on(async {
            let dir = std::env::temp_dir().join(format!("yusafcut-hostile-{}", uuid::Uuid::new_v4()));
            let mut value = serde_json::to_value(sample_project()).unwrap();
            value["segments"] = serde_json::json!([
                {"id":"a","mediaId":"m","words":[],"sourceIn":0.0,"sourceOut":2.0,"speed":"2"},
                {"id":"b","mediaId":"m","words":[],"sourceIn":2.0,"sourceOut":4.0,
                 "transitionIn":{"kind":"wipe","duration":0.5},"futureKey":{"x":1}},
                {"id":"c","mediaId":"m","words":[],"sourceIn":4.0,"sourceOut":6.0,"transitionIn":{"kind":"dip"}}
            ]);
            fs::create_dir_all(&dir).await.unwrap();
            fs::write(dir.join(PROJECT_FILE), serde_json::to_vec(&value).unwrap()).await.unwrap();
            let p = load(&dir).await.expect("one bad value never fails the load");
            assert_eq!(p.segments.len(), 3);
            assert_eq!(p.output_duration(), 6.0);
            assert!(!p.has_timing_effects());
            save(&p, &dir).await.unwrap();
            let saved: serde_json::Value =
                serde_json::from_slice(&fs::read(dir.join(PROJECT_FILE)).await.unwrap()).unwrap();
            assert_eq!(saved["segments"][1]["futureKey"], serde_json::json!({"x":1}));
            assert!(saved["segments"][1].get("transitionIn").is_none());
            fs::remove_dir_all(dir).await.unwrap();
        });
    }

    #[test]
    fn overlapping_saves_do_not_share_a_temporary_file_or_corrupt_the_bundle() {
        Runtime::new().unwrap().block_on(async {
            let dir = std::env::temp_dir().join(format!("yusafcut-concurrent-save-{}", uuid::Uuid::new_v4()));
            let mut tasks = vec![];
            for n in 0..20 {
                let path = dir.clone();
                tasks.push(tokio::spawn(async move {
                    let mut p = sample_project(); p.name = format!("revision-{n}");
                    save(&p, &path).await
                }));
            }
            for task in tasks { task.await.unwrap().unwrap(); }
            let p = load(&dir).await.unwrap();
            assert!(p.name.starts_with("revision-"));
            let mut files = fs::read_dir(&dir).await.unwrap();
            let mut count = 0;
            while files.next_entry().await.unwrap().is_some() { count += 1; }
            assert_eq!(count, 1, "no temporary files remain");
            fs::remove_dir_all(dir).await.unwrap();
        });
    }

}
