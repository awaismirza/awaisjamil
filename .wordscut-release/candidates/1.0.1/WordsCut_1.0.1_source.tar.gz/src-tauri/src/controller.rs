//! The desktop recording controller: a small always-on-top window, separate from
//! the editor, that mirrors the Rust recording session.
//!
//! Policy (pure, tested) lives in [`controller_view`] and [`clamp_to_monitors`];
//! the rest creates/shows/hides the window to match. The window loads
//! `controller.html`, which mounts only the controller UI — never the editor
//! `App`, autosave, import or transcription.
//!
//! Exclusion from the footage is done by the native capture helper (it filters
//! windows titled [`TITLE`] owned by this process out of display/area capture).
//! The FFmpeg fallback cannot exclude windows, so the controller stays hidden
//! during FFmpeg screen capture; the menu bar and shortcuts remain.

use crate::recording_session::{Backend, Phase, RecordingSnapshot};
use crate::AppState;
use serde::{Deserialize, Serialize};
use std::sync::atomic::{AtomicU64, Ordering};
use std::time::Duration;
use tauri::{
    AppHandle, Manager, PhysicalPosition, WebviewUrl, WebviewWindow, WebviewWindowBuilder,
    WindowEvent,
};

pub const LABEL: &str = "controller";
/// Must match `CONTROLLER_WINDOW_TITLE` in the Swift helper (`CaptureCore`).
pub const TITLE: &str = "WordsCut Recording Controls";
const WIDTH: f64 = 320.0;
const HEIGHT: f64 = 52.0;
const EXPANDED_HEIGHT: f64 = 210.0;
const MARGIN: i32 = 8;
const POSITION_FILE: &str = "recording-controller.json";

#[derive(Default)]
pub struct ControllerState {
    /// Serializes window changes so two quick snapshots cannot interleave.
    lock: tokio::sync::Mutex<()>,
    /// Debounce token for persisting the position while dragging.
    move_generation: AtomicU64,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ControllerView {
    /// No window: idle, or a mode without a screen capture.
    Closed,
    /// Window exists but is not on screen.
    Hidden,
    Shown,
}

fn is_screen_mode(mode: Option<&str>) -> bool {
    matches!(mode, Some("screen") | Some("screen-camera"))
}

/// What the controller window should look like for this session.
pub fn controller_view(snap: &RecordingSnapshot) -> ControllerView {
    if snap.phase == Phase::Idle || !is_screen_mode(snap.mode.as_deref()) {
        return ControllerView::Closed;
    }
    // FFmpeg's avfoundation capture cannot exclude windows: never put the
    // controller in the footage.
    if snap.backend == Some(Backend::Ffmpeg) || snap.controller_hidden {
        return ControllerView::Hidden;
    }
    ControllerView::Shown
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Rect {
    pub x: i32,
    pub y: i32,
    pub w: u32,
    pub h: u32,
}

impl Rect {
    fn contains(&self, x: i32, y: i32) -> bool {
        x >= self.x && y >= self.y && x < self.x + self.w as i32 && y < self.y + self.h as i32
    }
}

/// Keep a window of `size` fully inside the monitor that holds its centre (or the
/// first monitor when it is off every screen, e.g. after a display was unplugged).
pub fn clamp_to_monitors(pos: (i32, i32), size: (u32, u32), monitors: &[Rect]) -> (i32, i32) {
    let Some(first) = monitors.first() else {
        return pos;
    };
    let cx = pos.0 + size.0 as i32 / 2;
    let cy = pos.1 + size.1 as i32 / 2;
    let m = monitors.iter().find(|m| m.contains(cx, cy)).unwrap_or(first);
    let max_x = (m.x + m.w as i32 - size.0 as i32 - MARGIN).max(m.x + MARGIN);
    let max_y = (m.y + m.h as i32 - size.1 as i32 - MARGIN).max(m.y + MARGIN);
    (
        pos.0.clamp(m.x + MARGIN, max_x),
        pos.1.clamp(m.y + MARGIN, max_y),
    )
}

/// Top centre of a monitor, below the menu bar.
pub fn default_position(size: (u32, u32), monitor: &Rect) -> (i32, i32) {
    (
        monitor.x + (monitor.w as i32 - size.0 as i32) / 2,
        monitor.y + 48,
    )
}

#[derive(Serialize, Deserialize)]
struct SavedPosition {
    x: i32,
    y: i32,
}

fn monitors(app: &AppHandle) -> Vec<Rect> {
    app.available_monitors()
        .unwrap_or_default()
        .iter()
        .map(|m| Rect {
            x: m.position().x,
            y: m.position().y,
            w: m.size().width,
            h: m.size().height,
        })
        .collect()
}

fn position_path(app: &AppHandle) -> Option<std::path::PathBuf> {
    app.path().app_config_dir().ok().map(|d| d.join(POSITION_FILE))
}

fn load_position(app: &AppHandle) -> Option<(i32, i32)> {
    let raw = std::fs::read_to_string(position_path(app)?).ok()?;
    let p: SavedPosition = serde_json::from_str(&raw).ok()?;
    Some((p.x, p.y))
}

fn save_position(app: &AppHandle, pos: (i32, i32)) {
    let Some(path) = position_path(app) else {
        return;
    };
    if let Some(dir) = path.parent() {
        let _ = std::fs::create_dir_all(dir);
    }
    if let Ok(json) = serde_json::to_string(&SavedPosition { x: pos.0, y: pos.1 }) {
        let _ = std::fs::write(path, json);
    }
}

fn size_px(win: &WebviewWindow) -> (u32, u32) {
    win.outer_size()
        .map(|s| (s.width, s.height))
        .unwrap_or((WIDTH as u32, HEIGHT as u32))
}

/// Move the window back onto a connected display if it is not on one.
pub fn clamp_in_place(app: &AppHandle, win: &WebviewWindow) {
    let mons = monitors(app);
    let Ok(current) = win.outer_position() else {
        return;
    };
    let size = size_px(win);
    let target = clamp_to_monitors((current.x, current.y), size, &mons);
    if target != (current.x, current.y) {
        let _ = win.set_position(PhysicalPosition::new(target.0, target.1));
    }
}

fn create(app: &AppHandle) -> Result<WebviewWindow, String> {
    let win = WebviewWindowBuilder::new(app, LABEL, WebviewUrl::App("controller.html".into()))
        .title(TITLE)
        .inner_size(WIDTH, HEIGHT)
        .resizable(false)
        .maximizable(false)
        .minimizable(false)
        .decorations(false)
        .always_on_top(true)
        .visible_on_all_workspaces(true)
        .skip_taskbar(true)
        .focused(false)
        .visible(false)
        .shadow(true)
        .build()
        .map_err(|e| e.to_string())?;

    // Closing the controller must never discard or strand a take: hide it and let
    // the menu bar bring it back.
    let handle = app.clone();
    win.on_window_event(move |event| match event {
        WindowEvent::CloseRequested { api, .. } => {
            api.prevent_close();
            handle
                .state::<AppState>()
                .recording
                .authority
                .set_controller_hidden(true);
        }
        WindowEvent::Moved(p) => schedule_save(&handle, (p.x, p.y)),
        _ => {}
    });

    let mons = monitors(app);
    let size = size_px(&win);
    let wanted = load_position(app)
        .or_else(|| mons.first().map(|m| default_position(size, m)))
        .map(|p| clamp_to_monitors(p, size, &mons));
    if let Some(p) = wanted {
        let _ = win.set_position(PhysicalPosition::new(p.0, p.1));
    }
    Ok(win)
}

fn schedule_save(app: &AppHandle, pos: (i32, i32)) {
    let generation = {
        let st = app.state::<ControllerState>();
        st.move_generation.fetch_add(1, Ordering::SeqCst) + 1
    };
    let app = app.clone();
    tauri::async_runtime::spawn(async move {
        tokio::time::sleep(Duration::from_millis(400)).await;
        if app.state::<ControllerState>().move_generation.load(Ordering::SeqCst) == generation {
            save_position(&app, pos);
        }
    });
}

/// Bring the window in line with the session. Idempotent; reads the latest
/// snapshot itself so a burst of changes converges on the newest.
pub async fn sync(app: &AppHandle) {
    let st = app.state::<ControllerState>();
    let _guard = st.lock.lock().await;
    let snap = app.state::<AppState>().recording.authority.snapshot();
    let existing = app.get_webview_window(LABEL);
    match controller_view(&snap) {
        ControllerView::Closed => {
            if let Some(w) = existing {
                let _ = w.destroy();
            }
        }
        ControllerView::Hidden => {
            if let Some(w) = existing {
                let _ = w.hide();
            }
        }
        ControllerView::Shown => {
            let win = match existing {
                Some(w) => w,
                None => match create(app) {
                    Ok(w) => w,
                    Err(e) => {
                        log::warn!("recording controller unavailable: {e}");
                        return;
                    }
                },
            };
            // Display layout may have changed since the last snapshot.
            clamp_in_place(app, &win);
            if !win.is_visible().unwrap_or(false) {
                let _ = win.show();
            }
        }
    }
}

/// Called from the authority's sink (which must not block): run `sync` async.
pub fn request_sync(app: &AppHandle) {
    let app = app.clone();
    tauri::async_runtime::spawn(async move { sync(&app).await });
}

/// Explicitly restore and focus the MAIN editor window (never the caller's).
#[tauri::command]
pub fn show_main_window(app: AppHandle) -> Result<(), String> {
    let win = app
        .get_webview_window("main")
        .ok_or_else(|| "the editor window is not available".to_string())?;
    let _ = win.unminimize();
    win.show().map_err(|e| e.to_string())?;
    win.set_focus().map_err(|e| e.to_string())
}

/// Grow the window downward for the overflow menu and shrink it back after.
#[tauri::command]
pub fn set_controller_expanded(app: AppHandle, expanded: bool) -> Result<(), String> {
    let Some(win) = app.get_webview_window(LABEL) else {
        return Ok(());
    };
    let height = if expanded { EXPANDED_HEIGHT } else { HEIGHT };
    win.set_size(tauri::LogicalSize::new(WIDTH, height))
        .map_err(|e| e.to_string())?;
    clamp_in_place(&app, &win);
    Ok(())
}

/// Hide/show the controller for the live take (menu bar, controller overflow).
#[tauri::command]
pub fn set_controller_hidden(state: tauri::State<'_, AppState>, hidden: bool) {
    state.recording.authority.set_controller_hidden(hidden);
}

#[cfg(test)]
mod tests {
    use super::*;

    fn snap(phase: Phase, mode: &str, backend: Backend, hidden: bool) -> RecordingSnapshot {
        RecordingSnapshot {
            revision: 1,
            session_id: Some("s".into()),
            phase,
            backend: Some(backend),
            mode: Some(mode.into()),
            elapsed_sec: 0.0,
            markers: vec![],
            error: None,
            controller_hidden: hidden,
            key_names: None,
        }
    }

    #[test]
    fn controller_follows_the_session_for_native_screen_takes() {
        use ControllerView::*;
        for phase in [
            Phase::Starting,
            Phase::Recording,
            Phase::Paused,
            Phase::Interrupted,
            Phase::Finalizing,
        ] {
            assert_eq!(controller_view(&snap(phase, "screen", Backend::Native, false)), Shown);
        }
        assert_eq!(
            controller_view(&snap(Phase::Idle, "screen", Backend::Native, false)),
            Closed
        );
    }

    #[test]
    fn controller_is_never_shown_over_ffmpeg_screen_capture() {
        assert_eq!(
            controller_view(&snap(Phase::Recording, "screen", Backend::Ffmpeg, false)),
            ControllerView::Hidden
        );
        assert_eq!(
            controller_view(&snap(Phase::Starting, "screen-camera", Backend::Ffmpeg, false)),
            ControllerView::Hidden
        );
    }

    #[test]
    fn user_hide_and_non_screen_modes() {
        assert_eq!(
            controller_view(&snap(Phase::Paused, "screen", Backend::Native, true)),
            ControllerView::Hidden
        );
        for mode in ["camera", "voiceover"] {
            assert_eq!(
                controller_view(&snap(Phase::Recording, mode, Backend::Native, false)),
                ControllerView::Closed
            );
        }
    }

    const MAIN: Rect = Rect { x: 0, y: 0, w: 2880, h: 1800 };
    const SIDE: Rect = Rect { x: 2880, y: 0, w: 1920, h: 1080 };

    #[test]
    fn clamp_keeps_a_visible_position() {
        assert_eq!(clamp_to_monitors((500, 60), (640, 104), &[MAIN, SIDE]), (500, 60));
    }

    #[test]
    fn clamp_pulls_a_window_back_from_an_unplugged_display() {
        // Was on SIDE; SIDE is gone, so it lands on the remaining screen.
        let (x, y) = clamp_to_monitors((3500, 200), (640, 104), &[MAIN]);
        assert_eq!((x, y), (2880 - 640 - MARGIN, 200));
        // Far off in any direction.
        assert_eq!(clamp_to_monitors((-5000, -5000), (640, 104), &[MAIN]), (MARGIN, MARGIN));
        assert_eq!(
            clamp_to_monitors((9000, 9000), (640, 104), &[MAIN]),
            (2880 - 640 - MARGIN, 1800 - 104 - MARGIN)
        );
    }

    #[test]
    fn clamp_stays_on_the_monitor_holding_the_window_centre() {
        let (x, y) = clamp_to_monitors((2900, 2000), (640, 104), &[MAIN, SIDE]);
        // Centre (3220, 2052) is on neither: first monitor wins.
        assert!(x <= 2880 - 640 - MARGIN && y <= 1800 - 104 - MARGIN);
        let (x, _) = clamp_to_monitors((4400, 10), (640, 104), &[MAIN, SIDE]);
        assert_eq!(x, 2880 + 1920 - 640 - MARGIN);
    }

    #[test]
    fn clamp_without_monitors_is_a_no_op_and_default_is_top_centre() {
        assert_eq!(clamp_to_monitors((10, 10), (640, 104), &[]), (10, 10));
        assert_eq!(default_position((640, 104), &MAIN), (1120, 48));
    }
}
