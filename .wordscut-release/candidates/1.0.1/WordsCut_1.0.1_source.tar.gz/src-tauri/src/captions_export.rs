//! Burned-in captions as an ASS script drawn by the bundled libass (the same
//! route as `cursor_export.rs`). The frontend lays the words out (`captionLayout.ts`)
//! and sends cue and word times in OUTPUT time; this module only validates,
//! styles and escapes them, so nothing here invents timing.
use serde::Deserialize;
use std::io::{self, Write};

/// Same list as `CAPTION_FONTS` in `captionStyle.ts`.
const FONTS: [&str; 6] = ["Helvetica Neue", "Arial", "Verdana", "Trebuchet MS", "Georgia", "Menlo"];
const MAX_CUES: usize = 50_000;
const MAX_LINES: usize = 3;
const MAX_WORDS_PER_LINE: usize = 64;
const MAX_WORD_CHARS: usize = 120;

#[derive(Clone, Debug, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct CaptionStyle {
    pub font: String,
    pub size: f64,
    pub weight: String,
    pub color: String,
    pub highlight: bool,
    pub highlight_color: String,
    pub outline: f64,
    pub outline_color: String,
    pub shadow: f64,
    pub r#box: bool,
    pub box_color: String,
    pub box_opacity: f64,
    pub position: String,
}
impl Default for CaptionStyle {
    fn default() -> Self {
        Self {
            font: "Helvetica Neue".into(),
            size: 48.,
            weight: "bold".into(),
            color: "#ffffff".into(),
            highlight: false,
            highlight_color: "#ffd60a".into(),
            outline: 3.,
            outline_color: "#000000".into(),
            shadow: 0.,
            r#box: true,
            box_color: "#000000".into(),
            box_opacity: 0.7,
            position: "bottom".into(),
        }
    }
}
fn clamp(v: f64, d: f64, lo: f64, hi: f64) -> f64 {
    if v.is_finite() { v.clamp(lo, hi) } else { d }
}
impl CaptionStyle {
    /// Same bounds as `sanitizeCaptionStyle`; never trusts the caller.
    pub fn sanitized(&self) -> Self {
        let d = Self::default();
        let hex = |s: &str, fallback: &str| {
            if s.len() == 7 && s.starts_with('#') && s[1..].bytes().all(|b| b.is_ascii_hexdigit()) {
                s.to_lowercase()
            } else {
                fallback.to_string()
            }
        };
        Self {
            font: if FONTS.contains(&self.font.as_str()) { self.font.clone() } else { d.font },
            size: clamp(self.size, 48., 16., 140.),
            weight: if self.weight == "regular" { "regular".into() } else { "bold".into() },
            color: hex(&self.color, "#ffffff"),
            highlight: self.highlight,
            highlight_color: hex(&self.highlight_color, "#ffd60a"),
            outline: clamp(self.outline, 3., 0., 12.),
            outline_color: hex(&self.outline_color, "#000000"),
            shadow: clamp(self.shadow, 0., 0., 12.),
            r#box: self.r#box,
            box_color: hex(&self.box_color, "#000000"),
            box_opacity: clamp(self.box_opacity, 0.7, 0., 1.),
            position: match self.position.as_str() {
                "top" => "top".into(),
                "middle" => "middle".into(),
                _ => "bottom".into(),
            },
        }
    }
}

#[derive(Clone, Debug, Deserialize)]
pub struct CueWord {
    pub t: String,
    pub s: f64,
    pub e: f64,
}
#[derive(Clone, Debug, Deserialize)]
pub struct Cue {
    pub start: f64,
    pub end: f64,
    #[serde(default)]
    pub lines: Vec<Vec<CueWord>>,
}
/// What `ExportOpts.captions` carries: the style and the laid-out cues.
#[derive(Clone, Debug, Default, Deserialize)]
pub struct CaptionExport {
    #[serde(default)]
    pub style: CaptionStyle,
    #[serde(default)]
    pub cues: Vec<Cue>,
}

impl CaptionExport {
    /// Cues that can be drawn: finite, in range, sorted, with clean text.
    fn clean_cues(&self) -> Vec<Cue> {
        let mut cues: Vec<Cue> = self
            .cues
            .iter()
            .take(MAX_CUES)
            .filter(|c| c.start.is_finite() && c.end.is_finite() && c.start >= 0. && c.end > c.start)
            .filter_map(|c| {
                let lines: Vec<Vec<CueWord>> = c
                    .lines
                    .iter()
                    .take(MAX_LINES)
                    .map(|l| {
                        l.iter()
                            .take(MAX_WORDS_PER_LINE)
                            .filter_map(|w| {
                                let t: String = w
                                    .t
                                    .chars()
                                    .filter(|ch| !ch.is_control())
                                    .take(MAX_WORD_CHARS)
                                    .collect();
                                (!t.trim().is_empty() && w.s.is_finite() && w.e.is_finite()).then(|| CueWord {
                                    t: t.trim().to_string(),
                                    s: w.s.clamp(c.start, c.end),
                                    e: w.e.clamp(c.start, c.end),
                                })
                            })
                            .collect::<Vec<_>>()
                    })
                    .filter(|l| !l.is_empty())
                    .collect();
                (!lines.is_empty()).then(|| Cue { start: c.start, end: c.end, lines })
            })
            .collect();
        cues.sort_by(|a, b| a.start.total_cmp(&b.start));
        cues
    }
    pub fn active(&self) -> bool {
        !self.clean_cues().is_empty()
    }
}

/// Centisecond ASS time. Rounded (not floored) so that one cue's end and the
/// next cue's start, which are the same number, map to the same tick.
fn time(t: f64) -> String {
    let cs = (t * 100.).round().max(0.) as u64;
    format!("{}:{:02}:{:02}.{:02}", cs / 360000, (cs / 6000) % 60, (cs / 100) % 60, cs % 100)
}
/// "#rrggbb" to ASS "&HAABBGGRR" with `alpha` 0 (opaque) to 255.
fn colour(hex: &str, alpha: u8) -> String {
    format!("&H{alpha:02X}{}", bgr(hex))
}
/// "#rrggbb" to "BBGGRR" (the form inside override tags).
fn bgr(hex: &str) -> String {
    format!("{}{}{}", &hex[5..7], &hex[3..5], &hex[1..3]).to_uppercase()
}

/// Make arbitrary text safe inside an ASS dialogue line: `{` would open an
/// override block, `\N` `\n` `\h` are control codes, and nothing else in the
/// text may be read as markup. A backslash is followed by U+2060 (word joiner,
/// invisible) so it can never combine with the next character.
pub fn escape_ass(text: &str) -> String {
    let mut out = String::with_capacity(text.len());
    for ch in text.chars() {
        match ch {
            '\\' => out.push_str("\\\u{2060}"),
            '{' => out.push_str("\\{"),
            '}' => out.push_str("\\}"),
            c if c.is_control() => out.push(' '),
            c => out.push(c),
        }
    }
    out
}

/// libass has no automatic fallback to CJK fonts here (Helvetica and friends
/// draw empty boxes), so Han and kana runs switch to Hiragino Sans GB and Hangul
/// to Apple SD Gothic Neo, then back to the style font. Emoji cannot be drawn
/// by libass at all (Apple Color Emoji is a bitmap font); the frontend warns.
const CJK_FONT: &str = "Hiragino Sans GB";
const HANGUL_FONT: &str = "Apple SD Gothic Neo";
fn script_of(c: char) -> u8 {
    match c as u32 {
        0x3040..=0x30FF | 0x3400..=0x4DBF | 0x4E00..=0x9FFF | 0xF900..=0xFAFF | 0x3000..=0x303F
        | 0xFF00..=0xFFEF | 0x20000..=0x2FA1F => 1,
        0x1100..=0x11FF | 0x3130..=0x318F | 0xA960..=0xA97F | 0xAC00..=0xD7FF => 2,
        _ => 0,
    }
}
/// `escape_ass` plus the font switches above. `font` is the style font to return to.
pub fn ass_text(text: &str, font: &str) -> String {
    let mut out = String::with_capacity(text.len());
    let mut run = 0u8;
    let mut buf = [0u8; 4];
    for ch in text.chars() {
        let class = script_of(ch);
        if class != run {
            let f = match class {
                1 => CJK_FONT,
                2 => HANGUL_FONT,
                _ => font,
            };
            out.push_str(&format!("{{\\fn{f}}}"));
            run = class;
        }
        out.push_str(&escape_ass(ch.encode_utf8(&mut buf)));
    }
    if run != 0 {
        out.push_str(&format!("{{\\fn{font}}}"));
    }
    out
}

/// A file path as one `ass=filename=` value inside a filter graph. Two levels
/// of escaping (option value, then filtergraph): quotes, colons, commas,
/// brackets, semicolons, spaces and backslashes in the path are all safe.
pub fn filter_file_arg(path: &std::path::Path) -> String {
    let escape = |s: &str, special: &[char]| -> String {
        s.chars().flat_map(|c| if special.contains(&c) { vec!['\\', c] } else { vec![c] }).collect()
    };
    let level1 = escape(&path.to_string_lossy(), &['\\', '\'', ':']);
    escape(&level1, &['\\', '\'', '[', ']', ',', ';'])
}

/// The captions stage of the filter graph. `keep_alpha` is for a frame with an
/// alpha channel (`yuva444p`): libass leaves alpha untouched unless asked.
pub fn filter_stage(input: &str, ass: &std::path::Path, output: &str, keep_alpha: bool) -> String {
    format!(
        "[{input}]ass=filename={}{}[{output}]",
        filter_file_arg(ass),
        if keep_alpha { ":alpha=1" } else { "" }
    )
}

/// Write the whole script for a `width` x `height` frame (the final picture:
/// after zoom and scene). Returns the number of dialogue events written.
pub fn write_ass<W: Write>(
    out: &mut W,
    captions: &CaptionExport,
    width: u32,
    height: u32,
) -> Result<u64, String> {
    if width == 0 || height == 0 {
        return Err("invalid caption frame size".into());
    }
    let st = captions.style.sanitized();
    let scale = height as f64 / 1080.;
    let (alignment, margin_v) = match st.position.as_str() {
        "top" => (8, (height as f64 * 0.06).round()),
        "middle" => (5, 0.),
        _ => (2, (height as f64 * 0.06).round()),
    };
    let size = st.size * scale;
    // Box: libass draws it with the outline colour, `Outline` is its padding.
    let (outline_c, outline, shadow, border_style) = if st.r#box {
        let alpha = ((1. - st.box_opacity) * 255.).round() as u8;
        (colour(&st.box_color, alpha), size * 0.22, 0., 3)
    } else {
        (colour(&st.outline_color, 0), st.outline * scale, st.shadow * scale, 1)
    };
    let back = if st.r#box { colour("#000000", 255) } else { colour("#000000", 128) };
    let margin_h = (width as f64 * 0.05).round();
    (|| -> io::Result<()> {
        writeln!(
            out,
            "[Script Info]\nScriptType: v4.00+\nPlayResX: {width}\nPlayResY: {height}\nWrapStyle: 2\nScaledBorderAndShadow: yes\n\n[V4+ Styles]\nFormat: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\nStyle: Cap,{font},{size:.2},{primary},{primary},{outline_c},{back},{bold},0,0,0,100,100,0,0,{border_style},{outline:.2},{shadow:.2},{alignment},{margin_h},{margin_h},{margin_v},1\n\n[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text",
            font = st.font,
            primary = colour(&st.color, 0),
            bold = if st.weight == "bold" { -1 } else { 0 },
        )
    })()
    .map_err(|e| e.to_string())?;

    let hi = bgr(&st.highlight_color);
    let mut events = 0;
    for cue in captions.clean_cues() {
        // Without highlight: one event for the cue. With it: one event per
        // spoken word, the same text with that word recoloured.
        let words: Vec<&CueWord> = cue.lines.iter().flatten().collect();
        let windows: Vec<(f64, f64, Option<usize>)> = if st.highlight {
            words.iter().enumerate().map(|(i, w)| (w.s, w.e, Some(i))).collect()
        } else {
            vec![(cue.start, cue.end, None)]
        };
        for (start, end, active) in windows {
            if (end * 100.).round() <= (start * 100.).round() {
                continue;
            }
            let mut n = 0;
            let text = cue
                .lines
                .iter()
                .map(|line| {
                    line.iter()
                        .map(|w| {
                            let t = ass_text(&w.t, &st.font);
                            let on = active == Some(n);
                            n += 1;
                            if on { format!("{{\\1c&H{hi}&}}{t}{{\\r}}") } else { t }
                        })
                        .collect::<Vec<_>>()
                        .join(" ")
                })
                .collect::<Vec<_>>()
                .join("\\N");
            writeln!(out, "Dialogue: 0,{},{},Cap,,0,0,0,,{text}", time(start), time(end))
                .map_err(|e| e.to_string())?;
            events += 1;
        }
    }
    Ok(events)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn export(cues: &str, style: &str) -> CaptionExport {
        serde_json::from_str(&format!(r#"{{"style":{style},"cues":{cues}}}"#)).unwrap()
    }
    fn render(c: &CaptionExport, w: u32, h: u32) -> String {
        let mut buf = Vec::new();
        write_ass(&mut buf, c, w, h).unwrap();
        String::from_utf8(buf).unwrap()
    }

    #[test]
    fn escapes_override_braces_backslashes_and_control_codes() {
        assert_eq!(escape_ass("a{b}c"), "a\\{b\\}c");
        assert_eq!(escape_ass("x\\Ny"), "x\\\u{2060}Ny");
        assert_eq!(escape_ass("a\nb\u{0}c"), "a b c");
        assert_eq!(escape_ass("café 你好 😀"), "café 你好 😀");
    }

    #[test]
    fn cjk_and_hangul_runs_switch_font_and_switch_back() {
        assert_eq!(ass_text("abc", "Arial"), "abc");
        assert_eq!(ass_text("a你好b", "Arial"), "a{\\fnHiragino Sans GB}你好{\\fnArial}b");
        assert_eq!(ass_text("한국", "Arial"), "{\\fnApple SD Gothic Neo}한국{\\fnArial}");
        assert_eq!(ass_text("{你}", "Arial"), "\\{{\\fnHiragino Sans GB}你{\\fnArial}\\}");
    }

    #[test]
    fn filter_path_is_escaped_for_both_parsing_levels() {
        let a = filter_file_arg(std::path::Path::new("/t/a b:c'd,e[f];g.ass"));
        assert_eq!(a, "/t/a b\\\\:c\\\\\\'d\\,e\\[f\\]\\;g.ass");
        assert_eq!(filter_stage("x", std::path::Path::new("/a.ass"), "y", false), "[x]ass=filename=/a.ass[y]");
        assert!(filter_stage("x", std::path::Path::new("/a.ass"), "y", true).ends_with(":alpha=1[y]"));
    }

    #[test]
    fn style_is_sanitized_and_old_payloads_get_defaults() {
        let c = export("[]", r##"{"font":"Comic Sans","size":9999,"color":"red","position":"left","boxOpacity":-3}"##);
        let s = c.style.sanitized();
        assert_eq!((s.font.as_str(), s.size, s.color.as_str(), s.position.as_str()), ("Helvetica Neue", 140., "#ffffff", "bottom"));
        assert_eq!(s.box_opacity, 0.);
        assert!(!export("[]", "{}").active());
    }

    #[test]
    fn plain_cue_is_one_event_and_highlight_is_one_event_per_word() {
        let cues = r#"[{"start":1.0,"end":2.5,"lines":[[{"t":"Hello","s":1.0,"e":1.5},{"t":"there","s":1.5,"e":2.5}]]}]"#;
        let plain = render(&export(cues, "{}"), 1280, 720);
        assert_eq!(plain.matches("Dialogue:").count(), 1);
        assert!(plain.contains("Dialogue: 0,0:00:01.00,0:00:02.50,Cap,,0,0,0,,Hello there"));
        let hi = render(&export(cues, r#"{"highlight":true}"#), 1280, 720);
        assert_eq!(hi.matches("Dialogue:").count(), 2);
        assert!(hi.contains("0:00:01.00,0:00:01.50,Cap,,0,0,0,,{\\1c&H0AD6FF&}Hello{\\r} there"));
        assert!(hi.contains("0:00:01.50,0:00:02.50,Cap,,0,0,0,,Hello {\\1c&H0AD6FF&}there{\\r}"));
    }

    #[test]
    fn hostile_input_is_dropped_or_clamped() {
        let cues = r#"[{"start":-1,"end":2,"lines":[[{"t":"neg","s":0,"e":1}]]},
            {"start":3,"end":2,"lines":[[{"t":"back","s":0,"e":1}]]},
            {"start":5,"end":6,"lines":[[{"t":"  \u0007 ","s":5,"e":6}]]},
            {"start":7,"end":8,"lines":[[{"t":"ok{\\an8}","s":0,"e":99}]]}]"#;
        let ass = render(&export(cues, "{}"), 640, 360);
        assert_eq!(ass.matches("Dialogue:").count(), 1);
        assert!(ass.contains("ok\\{\\\u{2060}an8\\}"));
        assert!(write_ass(&mut Vec::new(), &export("[]", "{}"), 0, 10).is_err());
    }

    #[test]
    fn style_line_follows_position_box_and_frame_scale() {
        let bottom = render(&export("[]", "{}"), 1920, 1080);
        // box: BorderStyle 3, alpha 0x4D for opacity 0.7, bold, bottom (2), 6% margin
        assert!(bottom.contains("Style: Cap,Helvetica Neue,48.00,&H00FFFFFF,&H00FFFFFF,&H4D000000,&HFF000000,-1,0,0,0,100,100,0,0,3,10.56,0.00,2,96,96,65,1"), "{bottom}");
        let top = render(&export("[]", r#"{"position":"top","box":false,"shadow":2}"#), 960, 540);
        assert!(top.contains(",24.00,") && top.contains(",1,1.50,1.00,8,"), "{top}");
        assert!(render(&export("[]", r#"{"position":"middle"}"#), 960, 540).contains(",5,48,48,0,1"));
    }
}
