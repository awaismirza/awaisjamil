//! Media overlays (images / videos placed over the output) and privacy masks
//! (blur, pixelate, solid fill, dim-surround) for the full re-encode graph.
//!
//! Masks are SOURCE-ANCHORED (`src/lib/masks.ts`): `{mediaId, srcStart, srcEnd,
//! region}`. The export applies them per clip, on that source's own frames,
//! before trim / speed / freeze frames / transitions, so every occurrence of the
//! content is masked, at the right place for that source's size, and crossfade
//! or dip frames never show it unmasked. Output spans are only derived (key caps,
//! the cursor pass, the coverage check), never stored.
//!
//! The project keeps both as raw JSON (`Project::overlays`, `Project::masks`);
//! everything is re-validated here with the rules of `src/lib/layers.ts`
//! (shared fixture `tests/fixtures/layersSanitize.json`).
//!
//! Where they go in the graph (see the layer order policy in `commands/export.rs`):
//!   picture layer: masks -> cursor -> follow-zoom overlays -> follow-zoom annotations -> zoom -> scene
//!   frame layer:   fixed overlays -> fixed annotations -> captions -> key caps
//! Masks are normalised to the source picture and run first, so every later
//! stage (cursor, annotations, overlays, zoom, crop, captions, the GIF palette,
//! the encoder) only ever sees masked pixels.
use crate::annotations_export::Rect;
use crate::edl::Project;
use serde_json::{json, Value};
use std::fmt::Write as _;

pub const MAX_OVERLAYS: usize = 200;
pub const MAX_MASKS: usize = 200;
pub const MIN_OVERLAY_SEC: f64 = 0.25;
pub const MIN_MASK_SRC_SEC: f64 = 0.001;
/// A derived on-screen span is at least one frame at 30 fps (extended, never dropped).
pub const MIN_SPAN_SEC: f64 = 1. / 30.;
/// Export floors in output pixels (same as `MIN_BLUR_PX` / `MIN_BLOCK_PX` in masks.ts).
pub const MIN_BLUR_PX: f64 = 6.;
pub const MIN_BLOCK_PX: f64 = 8.;
/// Larger overlay images are refused (`MAX_IMAGE_PX` in layers.ts); decoders get `-max_pixels`.
pub const MAX_IMAGE_PX: f64 = 16384.;
/// Freeze frames show the frame at `sourceOut`: masked when the mask reaches this close.
const HOLD_TOLERANCE: f64 = 0.05;
const MAX_FADE_MS: f64 = 5000.;
const MAX_PATH_CHARS: usize = 4096;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum OverlayKind {
    /// PNG / JPEG: one still, looped.
    Image,
    /// GIF: animated, looped by the gif demuxer.
    Gif,
    Video,
}

#[derive(Clone, Debug, PartialEq)]
pub struct MediaOverlay {
    pub kind: OverlayKind,
    pub path: String,
    pub sha256: Option<String>,
    pub src_w: u32,
    pub src_h: u32,
    pub start: f64,
    pub end: f64,
    pub x: f64,
    pub y: f64,
    pub w: f64,
    pub h: f64,
    pub opacity: f64,
    pub rotation: f64,
    pub radius: f64,
    pub fade_in_ms: f64,
    pub fade_out_ms: f64,
    pub follow_zoom: bool,
    pub trim_in: f64,
    pub media_duration: f64,
    pub has_audio: bool,
    pub include_audio: bool,
    pub gain_db: f64,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum MaskEffect {
    Blur,
    Pixelate,
    Solid,
    Dim,
}

#[derive(Clone, Debug, PartialEq)]
pub struct Mask {
    pub id: String,
    pub media_id: String,
    /// Source-file seconds.
    pub src_start: f64,
    pub src_end: f64,
    /// Normalised to that source's own picture.
    pub x: f64,
    pub y: f64,
    pub w: f64,
    pub h: f64,
    pub ellipse: bool,
    pub effect: MaskEffect,
    pub strength: f64,
    /// `#rrggbb`.
    pub color: String,
}

fn num(v: &Value, fallback: f64) -> f64 {
    v.as_f64().filter(|n| n.is_finite()).unwrap_or(fallback)
}

fn span(r: &Value, total: f64, min: f64) -> Option<(f64, f64)> {
    let start = r["start"].as_f64().filter(|n| n.is_finite())?.clamp(0., total);
    let end = r["end"].as_f64().filter(|n| n.is_finite())?.clamp(0., total);
    (end - start >= min - 1e-9).then_some((start, end))
}

/// Same as `rect` in layers.ts (and annotation boxes).
fn rect(r: &Value, dx: f64, dy: f64, dw: f64, dh: f64) -> (f64, f64, f64, f64) {
    let x = num(&r["x"], dx).clamp(0., 1.);
    let y = num(&r["y"], dy).clamp(0., 1.);
    let w = num(&r["w"], dw).clamp(0.01, (1. - x).max(0.01));
    let h = num(&r["h"], dh).clamp(0.01, (1. - y).max(0.01));
    (x, y, w, h)
}

/// Lower-cased extension of the last path component, like `fileExtension` in layers.ts.
fn extension(path: &str) -> String {
    let base = path.rsplit('/').next().unwrap_or("");
    match base.rfind('.') {
        Some(dot) if dot > 0 => base[dot + 1..].to_lowercase(),
        _ => String::new(),
    }
}

fn clean_path(v: &Value) -> Option<String> {
    let s = v.as_str()?;
    if !s.starts_with('/') || s.chars().count() > MAX_PATH_CHARS || s.chars().any(char::is_control) {
        return None;
    }
    Some(s.to_string())
}

/// One stored value -> a valid overlay. Mirrors `sanitizeOverlay` in layers.ts.
pub fn sanitize_overlay(r: &Value, total: f64) -> Option<MediaOverlay> {
    if !r.is_object() {
        return None;
    }
    let path = clean_path(&r["path"])?;
    let kind = match extension(&path).as_str() {
        "png" | "jpg" | "jpeg" => OverlayKind::Image,
        "gif" => OverlayKind::Gif,
        "mp4" | "mov" | "m4v" => OverlayKind::Video,
        _ => return None,
    };
    let (start, end) = span(r, total, MIN_OVERLAY_SEC)?;
    if num(&r["srcW"], 0.) > MAX_IMAGE_PX || num(&r["srcH"], 0.) > MAX_IMAGE_PX {
        return None;
    }
    let (x, y, w, h) = rect(r, 0.6, 0.6, 0.3, 0.3);
    let mut fade_in = num(&r["fadeInMs"], 0.).clamp(0., MAX_FADE_MS);
    let mut fade_out = num(&r["fadeOutMs"], 0.).clamp(0., MAX_FADE_MS);
    let ms = (end - start) * 1000.;
    if fade_in + fade_out > ms {
        let f = ms / (fade_in + fade_out);
        fade_in = (fade_in * f).floor();
        fade_out = (fade_out * f).floor();
    }
    let video = kind == OverlayKind::Video;
    let has_audio = video && r["hasAudio"] == Value::Bool(true);
    let sha256 = r["sha256"]
        .as_str()
        .filter(|s| s.len() == 64 && s.bytes().all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b)))
        .map(String::from);
    Some(MediaOverlay {
        kind,
        path,
        sha256,
        src_w: num(&r["srcW"], 0.).max(0.).round() as u32,
        src_h: num(&r["srcH"], 0.).max(0.).round() as u32,
        start,
        end,
        x,
        y,
        w,
        h,
        opacity: num(&r["opacity"], 1.).clamp(0., 1.),
        rotation: num(&r["rotation"], 0.).clamp(-180., 180.),
        radius: num(&r["radius"], 0.).clamp(0., 540.),
        fade_in_ms: fade_in,
        fade_out_ms: fade_out,
        follow_zoom: r["followZoom"] == Value::Bool(true),
        trim_in: if video { num(&r["trimIn"], 0.).clamp(0., 1e6) } else { 0. },
        media_duration: if video { num(&r["mediaDuration"], 0.).clamp(0., 1e7) } else { 0. },
        has_audio,
        include_audio: has_audio && r["includeAudio"] == Value::Bool(true),
        gain_db: if has_audio { num(&r["gainDb"], 0.).clamp(-60., 12.) } else { 0. },
    })
}

impl MediaOverlay {
    /// The TypeScript shape (without `id`), for the parity fixture.
    pub fn to_json(&self) -> Value {
        let mut v = json!({
            "kind": if self.kind == OverlayKind::Video { "video" } else { "image" },
            "path": self.path, "srcW": self.src_w, "srcH": self.src_h,
            "start": self.start, "end": self.end,
            "x": self.x, "y": self.y, "w": self.w, "h": self.h, "opacity": self.opacity,
        });
        let o = v.as_object_mut().unwrap();
        let mut put = |k: &str, on: bool, val: Value| {
            if on {
                o.insert(k.into(), val);
            }
        };
        put("sha256", self.sha256.is_some(), json!(self.sha256));
        put("rotation", self.rotation != 0., json!(self.rotation));
        put("radius", self.radius > 0., json!(self.radius));
        put("fadeInMs", self.fade_in_ms > 0., json!(self.fade_in_ms));
        put("fadeOutMs", self.fade_out_ms > 0., json!(self.fade_out_ms));
        put("followZoom", self.follow_zoom, json!(true));
        put("trimIn", self.trim_in > 0., json!(self.trim_in));
        put("mediaDuration", self.media_duration > 0., json!(self.media_duration));
        put("hasAudio", self.has_audio, json!(true));
        put("includeAudio", self.include_audio, json!(true));
        put("gainDb", self.gain_db != 0., json!(self.gain_db));
        v
    }
}

fn fin(v: &Value) -> Option<f64> {
    v.as_f64().filter(|n| n.is_finite())
}

/// One stored value -> a valid mask. Mirrors `sanitizeMask` in masks.ts.
pub fn sanitize_mask(r: &Value) -> Option<Mask> {
    if !r.is_object() {
        return None;
    }
    let media_id = r["mediaId"].as_str().filter(|s| !s.is_empty() && s.chars().count() <= 200)?;
    let src_start = fin(&r["srcStart"])?.max(0.);
    let src_end = fin(&r["srcEnd"])?;
    if !(src_end - src_start >= MIN_MASK_SRC_SEC - 1e-9) {
        return None;
    }
    let x = num(&r["x"], 0.35).clamp(0., 1.);
    let y = num(&r["y"], 0.35).clamp(0., 1.);
    // A stored size under 1 % is refused, never silently grown into a 1 % box.
    let (w, h) = (num(&r["w"], 0.3), num(&r["h"], 0.2));
    if w < 0.01 || h < 0.01 {
        return None;
    }
    let (effect, lo, hi, dflt) = match r["effect"].as_str() {
        Some("blur") => (MaskEffect::Blur, 12., 100., 30.),
        Some("pixelate") => (MaskEffect::Pixelate, 16., 200., 32.),
        Some("dim") => (MaskEffect::Dim, 10., 95., 65.),
        _ => (MaskEffect::Solid, 0., 0., 0.),
    };
    let color = r["color"]
        .as_str()
        .filter(|s| s.len() == 7 && s.starts_with('#') && s[1..].bytes().all(|b| b.is_ascii_hexdigit()))
        .unwrap_or("#000000")
        .to_ascii_lowercase();
    Some(Mask {
        id: r["id"].as_str().filter(|s| !s.is_empty()).unwrap_or("").to_string(),
        media_id: media_id.to_string(),
        src_start,
        src_end,
        x,
        y,
        w: w.clamp(0.01, (1. - x).max(0.01)),
        h: h.clamp(0.01, (1. - y).max(0.01)),
        ellipse: r["shape"].as_str() == Some("ellipse"),
        effect,
        strength: num(&r["strength"], dflt).clamp(lo, hi),
        color,
    })
}

impl Mask {
    /// The TypeScript shape (without `id`), for the parity fixture.
    pub fn to_json(&self) -> Value {
        json!({
            "mediaId": self.media_id, "srcStart": self.src_start, "srcEnd": self.src_end,
            "x": self.x, "y": self.y, "w": self.w, "h": self.h,
            "shape": if self.ellipse { "ellipse" } else { "rect" },
            "effect": match self.effect {
                MaskEffect::Blur => "blur", MaskEffect::Pixelate => "pixelate",
                MaskEffect::Solid => "solid", MaskEffect::Dim => "dim",
            },
            "strength": self.strength, "color": self.color,
        })
    }
}

/// Valid masks in stored order (at most `MAX_MASKS`), sorted by source then start.
pub fn sanitize_masks(raw: Option<&Value>) -> Vec<Mask> {
    let mut out: Vec<Mask> = raw
        .and_then(Value::as_array)
        .map(|items| items.iter().filter_map(sanitize_mask).take(MAX_MASKS).collect())
        .unwrap_or_default();
    out.sort_by(|a, b| {
        a.media_id.cmp(&b.media_id).then(a.src_start.total_cmp(&b.src_start)).then(a.src_end.total_cmp(&b.src_end))
    });
    out
}

/// One timeline entry: (media, source in/out, output start, speed, hold).
struct Entry<'a> {
    media: &'a str,
    sin: f64,
    sout: f64,
    start: f64,
    speed: f64,
    hold: f64,
}
fn entries(project: &Project) -> Vec<Entry<'_>> {
    let mut start = 0.;
    project
        .segments
        .iter()
        .map(|s| {
            let e = Entry { media: &s.media_id, sin: s.source_in, sout: s.source_out, start, speed: s.speed(), hold: s.hold() };
            start += s.output_len();
            e
        })
        .collect()
}
impl Entry<'_> {
    fn play_end(&self) -> f64 {
        self.start + (self.sout - self.sin) / self.speed
    }
    fn out_at(&self, src: f64) -> f64 {
        self.start + (src - self.sin) / self.speed
    }
    fn src_at(&self, t: f64) -> f64 {
        (self.sin + (t - self.start).max(0.) * self.speed).min(self.sout)
    }
}

/// Masks of a project, converting masks saved in the old OUTPUT-time shape
/// (`start` / `end`, no `mediaId`) through the current timeline: one source mask
/// per clip the span touches. Mirrors `migrateMasks` in masks.ts.
pub fn source_masks(project: &Project) -> Vec<Mask> {
    let Some(items) = project.masks.as_ref().and_then(Value::as_array) else { return Vec::new() };
    let tl = entries(project);
    let mut out: Vec<Value> = Vec::new();
    for r in items {
        let legacy = r.is_object() && r.get("mediaId").is_none();
        let (Some(start), Some(end), true) = (fin(&r["start"]), fin(&r["end"]), legacy) else {
            out.push(r.clone());
            continue;
        };
        for e in &tl {
            let (lo, hi) = (start.max(e.start), end.min(e.play_end() + e.hold));
            if hi <= lo {
                continue;
            }
            let mut piece = r.clone();
            let o = piece.as_object_mut().unwrap();
            o.remove("start");
            o.remove("end");
            o.insert("mediaId".into(), json!(e.media));
            if lo < e.play_end() {
                let s = e.src_at(lo);
                let t = e.src_at(hi.min(e.play_end()));
                let mut p = o.clone();
                p.insert("srcStart".into(), json!(s));
                p.insert("srcEnd".into(), json!(t.max(s + MIN_MASK_SRC_SEC)));
                out.push(Value::Object(p));
            }
            if hi > e.play_end() {
                o.insert("srcStart".into(), json!((e.sout - HOLD_TOLERANCE).max(0.)));
                o.insert("srcEnd".into(), json!(e.sout));
                out.push(piece);
            }
        }
    }
    sanitize_masks(Some(&Value::Array(out)))
}

/// Every output span where `m`'s source content is on screen (each clip of
/// that source playing any of it, at its speed, plus a freeze of a masked last
/// frame), at least `MIN_SPAN_SEC` long, merged. Mirrors `maskOutputSpans`.
pub fn mask_output_spans(project: &Project, m: &Mask) -> Vec<(f64, f64)> {
    let mut spans = Vec::new();
    for e in entries(project) {
        if !same_content(project, &m.media_id, e.media) {
            continue;
        }
        let (s, t) = (m.src_start.max(e.sin), m.src_end.min(e.sout));
        if t > s {
            spans.push((e.out_at(s), e.out_at(t)));
        }
        if e.hold > 0. && m.src_start <= e.sout && m.src_end >= e.sout - HOLD_TOLERANCE {
            spans.push((e.play_end(), e.play_end() + e.hold));
        }
    }
    spans.sort_by(|a, b| a.0.total_cmp(&b.0));
    let mut merged: Vec<(f64, f64)> = Vec::new();
    for (a, b) in spans {
        let b = b.max(a + MIN_SPAN_SEC);
        match merged.last_mut() {
            Some(last) if a <= last.1 + 1e-9 => last.1 = last.1.max(b),
            _ => merged.push((a, b)),
        }
    }
    merged
}

/// Is source time `t` of `media` inside a mask (one frame of margin)? For key caps.
pub fn source_masked(masks: &[Mask], project: &Project, media: &str, t: f64) -> bool {
    masks.iter().any(|m| same_content(project, &m.media_id, media) && t >= m.src_start - MIN_SPAN_SEC && t <= m.src_end + MIN_SPAN_SEC)
}

/// Same content? Both checksums known and equal, OR equal paths: at export
/// time one path is one set of bytes, even with a stale stored checksum (a
/// recording overwritten in place and imported again). Erring towards "same"
/// only masks more. Mirrors `sameFile` in masks.ts (shared fixture `contentPairs`).
pub fn same_file(a_sha: &str, a_path: &str, b_sha: &str, b_path: &str) -> bool {
    (!a_sha.is_empty() && a_sha == b_sha) || (!a_path.is_empty() && a_path == b_path)
}

/// Does media `id` show the same file as media `mask_media`? The same file
/// imported twice has two ids; a mask covers both.
pub fn same_content(project: &Project, mask_media: &str, id: &str) -> bool {
    if mask_media == id {
        return true;
    }
    match (project.media.get(mask_media), project.media.get(id)) {
        (Some(a), Some(b)) => same_file(&a.sha256, &a.path, &b.sha256, &b.path),
        _ => false,
    }
}

/// The masks that apply to media `id` (its own and those of the same file).
pub fn masks_for_media<'a>(masks: &'a [Mask], project: &Project, id: &str) -> Vec<&'a Mask> {
    masks.iter().filter(|m| same_content(project, &m.media_id, id)).collect()
}

/// The masks whose source file is this overlay's file (checksum or path).
pub fn masks_for_overlay<'a>(masks: &'a [Mask], project: &Project, o: &MediaOverlay) -> Vec<&'a Mask> {
    masks
        .iter()
        .filter(|m| {
            project
                .media
                .get(&m.media_id)
                .is_some_and(|src| same_file(&src.sha256, &src.path, o.sha256.as_deref().unwrap_or(""), &o.path))
        })
        .collect()
}

/// Pixels-at-1080 scale for a source: its SHORT side / 1080, which is the
/// same whether or not stored sizes predate rotation-aware probing. Errors when
/// the size is unknown: a mask is never silently dropped.
pub fn mask_scale(project: &Project, media_id: &str) -> Result<f64, String> {
    let m = project.media.get(media_id).ok_or_else(|| format!("a privacy mask refers to unknown media {media_id}"))?;
    let short = m.width.min(m.height);
    if short == 0 {
        return Err(format!(
            "a privacy mask is on {} but its picture size is unknown: relink or re-import that file before exporting",
            m.path
        ));
    }
    Ok(short as f64 / 1080.)
}

fn sanitize_list<T>(raw: Option<&Value>, total: f64, max: usize, one: fn(&Value, f64) -> Option<T>, key: fn(&T) -> (f64, f64)) -> Vec<T> {
    let mut out: Vec<T> = raw
        .and_then(Value::as_array)
        .map(|items| items.iter().filter_map(|r| one(r, total)).take(max).collect())
        .unwrap_or_default();
    out.sort_by(|a, b| {
        let (a, b) = (key(a), key(b));
        a.0.total_cmp(&b.0).then(a.1.total_cmp(&b.1))
    });
    out
}

pub fn sanitize_overlays(raw: Option<&Value>, total: f64) -> Vec<MediaOverlay> {
    sanitize_list(raw, total, MAX_OVERLAYS, sanitize_overlay, |o| (o.start, o.end))
}

/// Everything this module draws for one export.
#[derive(Debug, Default)]
pub struct Layers {
    pub overlays: Vec<MediaOverlay>,
    pub masks: Vec<Mask>,
}
impl Layers {
    pub fn collect(project: &Project) -> Self {
        let total = project.output_duration();
        Self {
            overlays: sanitize_overlays(project.overlays.as_ref(), total),
            masks: source_masks(project),
        }
    }
    pub fn is_empty(&self) -> bool {
        self.overlays.is_empty() && self.masks.is_empty()
    }
}

/// Timeline expression for a span, quoted so the commas survive the graph parser.
fn enable(start: f64, end: f64) -> String {
    format!("enable='between(t,{start:.6},{end:.6})'")
}

fn even_floor(v: f64) -> i64 {
    (v / 2.).floor() as i64 * 2
}
fn even_ceil(v: f64) -> i64 {
    (v / 2.).ceil() as i64 * 2
}

/// The masked region in picture pixels, grown outward to even coordinates
/// (4:2:0 chroma) and kept inside the `pw` x `ph` picture: (x, y, w, h).
pub fn mask_region(m: &Mask, rect: Rect, pw: u32, ph: u32) -> (i64, i64, i64, i64) {
    let (maxw, maxh) = ((pw as i64 / 2 * 2).max(2), (ph as i64 / 2 * 2).max(2));
    let x0 = even_floor(rect.x + m.x * rect.w).clamp(0, maxw - 2);
    let y0 = even_floor(rect.y + m.y * rect.h).clamp(0, maxh - 2);
    let x1 = even_ceil(rect.x + (m.x + m.w) * rect.w).clamp(x0 + 2, maxw);
    let y1 = even_ceil(rect.y + (m.y + m.h) * rect.h).clamp(y0 + 2, maxh);
    (x0, y0, x1 - x0, y1 - y0)
}

/// Alpha for an ellipse inscribed in the region (binary edge: no partial cover).
const ELLIPSE: &str = "format=yuva420p,geq=lum='lum(X,Y)':cb='cb(X,Y)':cr='cr(X,Y)':a='255*lte(hypot((X+0.5)/W-0.5,(Y+0.5)/H-0.5),0.5)'";

/// Where a mask's normalised region lands in a stage.
#[derive(Clone, Copy)]
pub enum Geom {
    /// On the frame entering the stage, from its ACTUAL decoded size
    /// (`iw` / `ih` expressions): stored media sizes are never trusted.
    Frame,
    /// At a placed rect inside a `pw` x `ph` picture (the output picture).
    Rect(Rect, u32, u32),
}

/// One mask placed for a stage: where it lands, its pixels-at-1080 scale and
/// the spans (in this stage's time) it is active.
pub struct Placed<'a> {
    pub mask: &'a Mask,
    pub geom: Geom,
    pub k: f64,
    pub spans: Vec<(f64, f64)>,
}

/// Timeline expression for several spans, each padded by `pad` either side.
fn enable_spans(spans: &[(f64, f64)], pad: f64) -> String {
    let terms: Vec<String> = spans.iter().map(|(a, b)| format!("between(t,{:.6},{:.6})", (a - pad).max(0.), b + pad)).collect();
    format!("enable='{}'", terms.join("+"))
}

/// Even start and size of [a, a + len] of a dimension `d` (an ffmpeg variable), kept inside it.
fn axis_expr(d: &str, a: f64, len: f64) -> (String, String) {
    let start = format!("min(trunc({d}*{a:.6}/2)*2,trunc({d}/2)*2-2)");
    let size = format!("max(2,min(ceil({d}*{:.6}/2)*2,trunc({d}/2)*2)-{start})", a + len);
    (start, size)
}

/// (crop filter, overlay x, overlay y) for a placed mask.
fn region(p: &Placed) -> (String, String, String) {
    let m = p.mask;
    match p.geom {
        Geom::Frame => {
            let (x, w) = axis_expr("iw", m.x, m.w);
            let (y, h) = axis_expr("ih", m.y, m.h);
            let (ox, _) = axis_expr("W", m.x, m.w);
            let (oy, _) = axis_expr("H", m.y, m.h);
            (format!("crop=w='{w}':h='{h}':x='{x}':y='{y}'"), format!("'{ox}'"), format!("'{oy}'"))
        }
        Geom::Rect(rect, pw, ph) => {
            let (x, y, w, h) = mask_region(m, rect, pw, ph);
            (format!("crop={w}:{h}:{x}:{y}"), x.to_string(), y.to_string())
        }
    }
}

/// Masks on a picture, `[input]` -> `[output]`, labels prefixed with `prefix`.
/// Sizes are `strength * k` pixels, never below `MIN_BLUR_PX` / `MIN_BLOCK_PX`.
pub fn mask_chain(items: &[Placed], pad: f64, prefix: &str, input: &str, output: &str) -> String {
    let mut g = String::new();
    let mut cur = input.to_string();
    for (i, p) in items.iter().enumerate() {
        let m = p.mask;
        let out = if i + 1 == items.len() { output.to_string() } else { format!("{prefix}{i}") };
        let l = format!("{prefix}{i}_");
        let (crop, x, y) = region(p);
        let k = p.k;
        let en = enable_spans(&p.spans, pad);
        let alpha = if m.ellipse { format!(",{ELLIPSE}:{en}") } else { String::new() };
        if !g.is_empty() {
            g.push(';');
        }
        if m.effect == MaskEffect::Dim {
            // Darken the whole picture, then put the untouched region back.
            let f = 1. - m.strength / 100.;
            let _ = write!(
                g,
                "[{cur}]split=2[{l}a][{l}b];\
                 [{l}a]lutyuv=y='16+(val-16)*{f:.4}':u='128+(val-128)*{f:.4}':v='128+(val-128)*{f:.4}':{en}[{l}d];\
                 [{l}b]{crop}{alpha}[{l}r];\
                 [{l}d][{l}r]overlay=x={x}:y={y}:format=auto:{en}[{out}]"
            );
        } else {
            let effect = match m.effect {
                MaskEffect::Blur => format!("gblur=sigma={:.2}:steps=3:{en}", (m.strength * k).max(MIN_BLUR_PX)),
                MaskEffect::Pixelate => {
                    let b = ((m.strength * k).round()).max(MIN_BLOCK_PX) as i64;
                    format!("pixelize=w={b}:h={b}:{en}")
                }
                _ => format!("drawbox=x=0:y=0:w=iw:h=ih:color=0x{}@1:t=fill", &m.color[1..]),
            };
            let _ = write!(
                g,
                "[{cur}]split=2[{l}a][{l}b];\
                 [{l}b]{crop},{effect}{alpha}[{l}r];\
                 [{l}a][{l}r]overlay=x={x}:y={y}:format=auto:{en}[{out}]"
            );
        }
        cur = out;
    }
    g
}

/// The per-clip mask stage (ffmpeg input `input`, source range [sin, sout],
/// masks of that file `masks`, scale `k`): `[input:v]` trimmed with a one
/// second margin and masked on its own decoded frames in SOURCE time, padded
/// by `pad` (one source frame). No rate conversion happens before the mask, so
/// a variable-rate frame is masked before any later `fps` duplicates it. The
/// clip's own `trim` reads `[label]` instead of `[input:v]`, so speed, freeze
/// frames, crossfades and dips only ever see masked frames.
#[allow(clippy::too_many_arguments)]
pub fn clip_mask_stage(masks: &[&Mask], k: f64, input: usize, sin: f64, sout: f64, pad: f64, rate: f64, label: &str) -> Option<String> {
    let items: Vec<Placed> = masks
        .iter()
        .filter(|m| m.src_end >= sin - pad && m.src_start <= sout + pad)
        .map(|m| Placed { mask: m, geom: Geom::Frame, k, spans: vec![(m.src_start, m.src_end)] })
        .collect();
    if items.is_empty() {
        return None;
    }
    let src = format!("{label}s");
    Some(format!(
        "[{input}:v]trim=start={:.6}:end={:.6}[{src}];{}",
        (sin - 1.).max(0.),
        sout + 1.,
        two_pass(&items, pad, rate, &format!("{label}m"), &src, label)
    ))
}

/// Masks applied twice around a constant-rate conversion. Pass 1, on the
/// source frames: a frame whose own time is inside a span is masked before
/// anything repeats it (a variable-rate frame held past the span's end). Then
/// `fps={rate}`. Pass 2: the repeats of a frame from BEFORE a span that now sit
/// at times inside it (secret shown, then a static screen) are masked too.
/// Solid / blur / pixelate twice is harmless. Dim-surround runs in pass 2
/// only (twice would darken twice), so every frame on screen in the span,
/// including a held pre-span frame, is dimmed once.
pub fn two_pass(items: &[Placed], pad: f64, rate: f64, prefix: &str, input: &str, output: &str) -> String {
    let hide: Vec<Placed> = items
        .iter()
        .filter(|p| p.mask.effect != MaskEffect::Dim)
        .map(|p| Placed { mask: p.mask, geom: p.geom, k: p.k, spans: p.spans.clone() })
        .collect();
    let first = if hide.is_empty() {
        format!("[{input}]null[{prefix}p]")
    } else {
        mask_chain(&hide, pad, &format!("{prefix}a"), input, &format!("{prefix}p"))
    };
    let again: Vec<Placed> = items.iter().map(|p| Placed { mask: p.mask, geom: p.geom, k: p.k, spans: p.spans.clone() }).collect();
    let cfr = format!("[{prefix}p]fps={rate}[{prefix}c]");
    let second = mask_chain(&again, 1. / rate.max(1.), &format!("{prefix}b"), &format!("{prefix}c"), output);
    format!("{first};{cfr};{second}")
}

/// A video overlay whose file is masked footage: the masks run on the overlay
/// input's own frames, in its time (source time minus `trimIn`), before it is
/// scaled and composited. None when no mask touches what it shows.
pub fn overlay_mask_stage(masks: &[&Mask], o: &MediaOverlay, k: f64, input: usize, pad: f64, rate: f64, label: &str) -> Option<String> {
    let len = o.end - o.start;
    let items: Vec<Placed> = masks
        .iter()
        .map(|m| (m, (m.src_start - o.trim_in, m.src_end - o.trim_in)))
        .filter(|(_, (a, b))| *b >= -pad && *a <= len + pad)
        .map(|(m, span)| Placed { mask: m, geom: Geom::Frame, k, spans: vec![span] })
        .collect();
    if items.is_empty() {
        return None;
    }
    Some(two_pass(&items, pad, rate, &format!("{label}m"), &format!("{input}:v"), label))
}

/// ffmpeg input options for one overlay (placed before its `-i`). Every input
/// is bounded with `-t`, so a long file is never read past what is shown.
pub fn overlay_input_args(o: &MediaOverlay, fps: f64) -> Vec<String> {
    let dur = format!("{:.6}", o.end - o.start);
    // Local files only, read with the demuxer the extension promises: a file
    // that is really a playlist or another container cannot pull in anything else.
    let mut a: Vec<String> = vec!["-protocol_whitelist".into(), "file".into()];
    let max_pixels = format!("{}", (MAX_IMAGE_PX * MAX_IMAGE_PX) as u64);
    match o.kind {
        OverlayKind::Image => {
            a.extend(["-f", "image2", "-pattern_type", "none", "-max_pixels", &max_pixels, "-framerate"].map(String::from));
            a.push(format!("{fps}"));
            return a; // one frame; repeated by `loop` in `overlay_chain`
        }
        OverlayKind::Gif => a.extend(["-f", "gif", "-max_pixels", &max_pixels, "-ignore_loop", "0"].map(String::from)),
        OverlayKind::Video => {
            a.extend(["-f", "mov", "-max_pixels", &max_pixels].map(String::from));
            if o.trim_in > 0. {
                a.extend(["-ss".into(), format!("{:.6}", o.trim_in)]);
            }
        }
    }
    a.extend(["-t".into(), dur]);
    a
}

/// Overlays drawn into a frame whose normalised space is `rect` (the whole
/// frame, or the picture for follow-zoom ones), `[input]` -> `[output]`.
/// `inputs[i]` is the ffmpeg input index of `items[i]`. Alpha from PNG / GIF /
/// ProRes 4444 sources is kept (rgba) and composited; `format=auto` keeps a
/// transparent frame's alpha plane.
pub fn overlay_chain(items: &[(&MediaOverlay, String)], rect: Rect, prefix: &str, input: &str, output: &str) -> String {
    let k = rect.h / 1080.;
    let mut g = String::new();
    let mut cur = input.to_string();
    for (i, (o, idx)) in items.iter().enumerate() {
        let out = if i + 1 == items.len() { output.to_string() } else { format!("{prefix}{i}") };
        let w = (o.w * rect.w).round().max(2.);
        let h = (o.h * rect.h).round().max(2.);
        let (cx, cy) = (rect.x + (o.x + o.w / 2.) * rect.w, rect.y + (o.y + o.h / 2.) * rect.h);
        // A still is decoded once and repeated in the graph (`-loop 1` on the input
        // would retry a corrupt file forever instead of failing).
        let still = if o.kind == OverlayKind::Image {
            format!("loop=loop=-1:size=1:start=0,trim=duration={:.6},", o.end - o.start)
        } else {
            String::new()
        };
        let mut s = format!("[{idx}]{still}setpts=PTS-STARTPTS+{:.6}/TB,scale={w}:{h},format=rgba", o.start);
        let r = (o.radius * k).min(w / 2.).min(h / 2.);
        if r >= 0.5 {
            let _ = write!(
                s,
                ",geq=r='r(X,Y)':g='g(X,Y)':b='b(X,Y)':a='alpha(X,Y)*lte(hypot(max(0,abs(X+0.5-W/2)-(W/2-{r:.3})),max(0,abs(Y+0.5-H/2)-(H/2-{r:.3}))),{r:.3})'"
            );
        }
        if o.fade_in_ms > 0. {
            let _ = write!(s, ",fade=t=in:st={:.6}:d={:.6}:alpha=1", o.start, o.fade_in_ms / 1000.);
        }
        if o.fade_out_ms > 0. {
            let _ = write!(s, ",fade=t=out:st={:.6}:d={:.6}:alpha=1", o.end - o.fade_out_ms / 1000., o.fade_out_ms / 1000.);
        }
        if o.opacity < 1. {
            let _ = write!(s, ",colorchannelmixer=aa={:.4}", o.opacity);
        }
        if o.rotation != 0. {
            let a = o.rotation.to_radians();
            let _ = write!(s, ",rotate=a={a:.6}:c=none:ow=rotw({a:.6}):oh=roth({a:.6})");
        }
        if !g.is_empty() {
            g.push(';');
        }
        let _ = write!(
            g,
            "{s}[{prefix}{i}s];[{cur}][{prefix}{i}s]overlay=x='{cx:.3}-overlay_w/2':y='{cy:.3}-overlay_h/2':eof_action=pass:format=auto:{}[{out}]",
            enable(o.start, o.end)
        );
        cur = out;
    }
    g
}

/// The audio of video overlays with "include audio" on, each as its own
/// labelled stream (`[ovaN]`) as long as the timeline: gain, fades on its own
/// clock, delayed to its start. Like a music bed, but never ducked.
pub fn overlay_audio(items: &[(&MediaOverlay, usize)], total: f64, filter: &mut String) -> Vec<String> {
    let mut labels = Vec::new();
    for (i, (o, idx)) in items.iter().enumerate() {
        let len = o.end - o.start;
        let _ = write!(filter, ";[{idx}:a]aresample=48000,volume={}dB", o.gain_db);
        if o.fade_in_ms > 0. {
            let _ = write!(filter, ",afade=t=in:st=0:d={:.3}", o.fade_in_ms / 1000.);
        }
        if o.fade_out_ms > 0. {
            let _ = write!(filter, ",afade=t=out:st={:.3}:d={:.3}", len - o.fade_out_ms / 1000., o.fade_out_ms / 1000.);
        }
        let ms = (o.start * 1000.).round() as i64;
        let _ = write!(filter, ",atrim=0:{len:.6},adelay=delays={ms}:all=1,apad,atrim=0:{total:.6},asetpts=PTS-STARTPTS[ova{i}]");
        labels.push(format!("ova{i}"));
    }
    labels
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::path::{Path, PathBuf};
    use std::process::Command;

    /// Equal JSON, numbers compared as f64 (`1` == `1.0`; serde_json's default
    /// float parsing may be off by one ulp from JavaScript's).
    fn same(a: &Value, b: &Value) -> bool {
        match (a, b) {
            (Value::Number(x), Value::Number(y)) => (x.as_f64().unwrap() - y.as_f64().unwrap()).abs() < 1e-12,
            (Value::Array(x), Value::Array(y)) => x.len() == y.len() && x.iter().zip(y).all(|(a, b)| same(a, b)),
            (Value::Object(x), Value::Object(y)) => x.len() == y.len() && x.iter().all(|(k, v)| y.get(k).is_some_and(|w| same(v, w))),
            (a, b) => a == b,
        }
    }

    #[test]
    fn sanitizers_match_the_shared_typescript_fixture() {
        let fx: Value = serde_json::from_str(include_str!("../../tests/fixtures/layersSanitize.json")).unwrap();
        let total = fx["total"].as_f64().unwrap();
        let got: Vec<Value> = sanitize_overlays(Some(&fx["overlays"]["input"]), total).iter().map(MediaOverlay::to_json).collect();
        assert!(same(&Value::Array(got.clone()), &fx["overlays"]["expected"]), "{got:#?}");
        let got: Vec<Value> = sanitize_masks(Some(&fx["masks"]["input"])).iter().map(Mask::to_json).collect();
        assert!(same(&Value::Array(got.clone()), &fx["masks"]["expected"]), "{got:#?}");
        // Old output-time masks convert through the timeline exactly like `migrateMasks`.
        let legacy: Project = serde_json::from_value(fx["legacy"]["project"].clone()).unwrap();
        let got: Vec<Value> = source_masks(&legacy).iter().map(Mask::to_json).collect();
        assert!(same(&Value::Array(got.clone()), &fx["legacy"]["expected"]), "{got:#?}");
    }

    #[test]
    fn content_identity_and_derived_spans_match_typescript() {
        let fx: Value = serde_json::from_str(include_str!("../../tests/fixtures/layersSanitize.json")).unwrap();
        for pair in fx["contentPairs"].as_array().unwrap() {
            let (a, b) = (&pair["a"], &pair["b"]);
            let s = |v: &Value, k: &str| v[k].as_str().unwrap_or("").to_string();
            assert_eq!(
                same_file(&s(a, "sha256"), &s(a, "path"), &s(b, "sha256"), &s(b, "path")),
                pair["same"].as_bool().unwrap(),
                "{pair}"
            );
        }
        // 400 seeded random timelines from tests/fixtures/maskSpansParity.gen.ts.
        let cases: Value = serde_json::from_str(include_str!("../../tests/fixtures/maskSpansParity.json")).unwrap();
        let cases = cases.as_array().unwrap();
        assert_eq!(cases.len(), 400);
        for (i, c) in cases.iter().enumerate() {
            let p: Project = serde_json::from_value(c["project"].clone()).unwrap();
            let masks = sanitize_masks(p.masks.as_ref());
            let want = c["expected"].as_array().unwrap();
            assert_eq!(masks.len(), want.len(), "case {i}: masks kept");
            for (m, w) in masks.iter().zip(want) {
                let got = mask_output_spans(&p, m);
                let w: Vec<(f64, f64)> = w.as_array().unwrap().iter().map(|s| (s[0].as_f64().unwrap(), s[1].as_f64().unwrap())).collect();
                assert_eq!(got.len(), w.len(), "case {i} mask {}: {got:?} vs {w:?}", m.id);
                for (g, e) in got.iter().zip(&w) {
                    assert!((g.0 - e.0).abs() < 1e-9 && (g.1 - e.1).abs() < 1e-9, "case {i}: {got:?} vs {w:?}");
                }
            }
        }
    }

    #[test]
    fn hostile_values_never_panic_and_counts_are_capped() {
        for junk in [json!(null), json!("x"), json!(7), json!({}), json!([[], {}, null, "inf", {"path":"/a.png","start":"0","end":{}}])] {
            assert!(sanitize_overlays(Some(&junk), 10.).is_empty());
            assert!(sanitize_masks(Some(&junk)).is_empty());
        }
        let many: Vec<Value> = (0..300).map(|_| json!({"start":0,"end":1,"path":"/a.png","mediaId":"m","srcStart":0,"srcEnd":1})).collect();
        assert_eq!(sanitize_overlays(Some(&Value::Array(many.clone())), 4.).len(), MAX_OVERLAYS);
        assert_eq!(sanitize_masks(Some(&Value::Array(many))).len(), MAX_MASKS);
    }

    #[test]
    fn a_mask_region_is_even_and_inside_the_picture() {
        let m = mask(json!({"x":0.999,"y":0.001,"w":0.5,"h":0.5}));
        let (x, y, w, h) = mask_region(&m, Rect::fit(641, 361, 641, 361), 641, 361);
        assert!(x % 2 == 0 && y % 2 == 0 && w % 2 == 0 && h % 2 == 0);
        assert!(x + w <= 640 && y + h <= 360 && w >= 2 && h >= 2, "{x} {y} {w} {h}");
    }

    /// A mask on media "m" over source 1..2 s with these fields.
    fn mask(extra: Value) -> Mask {
        let mut v = json!({"mediaId":"m","srcStart":1,"srcEnd":2});
        for (k, x) in extra.as_object().unwrap() {
            v[k] = x.clone();
        }
        sanitize_mask(&v).unwrap()
    }
    fn chain(m: &Mask, rect: Rect) -> String {
        let k = rect.w.min(rect.h) / 1080.;
        mask_chain(&[Placed { mask: m, geom: Geom::Rect(rect, 640, 360), k, spans: vec![(m.src_start, m.src_end)] }], 0.1, "t", "0:v", "o")
    }
    fn frame_chain(m: &Mask) -> String {
        mask_chain(&[Placed { mask: m, geom: Geom::Frame, k: 360. / 1080., spans: vec![(m.src_start, m.src_end)] }], 0.1, "t", "0:v", "o")
    }

    #[test]
    fn frame_geometry_from_the_decoded_size_matches_placed_pixels() {
        if ff().is_none() {
            return;
        }
        // The same masks placed from `iw`/`ih` (no stored size) and from known pixels.
        for spec in [
            json!({"x":0.25,"y":0.25,"w":0.25,"h":0.25,"color":"#00ff00"}),
            json!({"x":0.999,"y":0.0,"w":0.5,"h":1.0,"color":"#00ff00"}),
            json!({"x":0.1,"y":0.6,"w":0.3,"h":0.4,"effect":"pixelate","strength":40,"shape":"ellipse"}),
        ] {
            let m = mask(spec);
            assert_eq!(render(&frame_chain(&m), 15, &[]), render(&chain(&m, Rect::fit(640, 360, 640, 360)), 15, &[]));
        }
    }

    #[test]
    fn strength_floors_hold_in_the_sanitizer_and_in_output_pixels() {
        assert_eq!(mask(json!({"effect":"blur","strength":1})).strength, 12.);
        assert_eq!(mask(json!({"effect":"pixelate","strength":1})).strength, 16.);
        assert_eq!(mask(json!({})).effect, MaskEffect::Solid, "default effect is solid");
        // 640x360: 12 @1080 would be sigma 4 and pixelate 16 @1080 a 5 px block: floored.
        let r = Rect::fit(640, 360, 640, 360);
        assert!(chain(&mask(json!({"effect":"blur","strength":12})), r).contains("gblur=sigma=6.00"));
        assert!(chain(&mask(json!({"effect":"pixelate","strength":16})), r).contains("pixelize=w=8:h=8"));
    }

    #[test]
    fn output_spans_cover_every_occurrence_speed_and_holds() {
        let p: Project = serde_json::from_value(json!({"version":1,"id":"p","name":"a","createdAt":"","updatedAt":"",
            "media":{"m":{"id":"m","path":"/x","duration":10,"fps":30,"width":640,"height":360,"audioSampleRate":48000,"sha256":""}},
            "segments":[
                {"id":"a","mediaId":"m","sourceIn":0,"sourceOut":4,"words":[],"speed":4,"holdSec":1},
                {"id":"b","mediaId":"m","sourceIn":0,"sourceOut":4,"words":[]}],
            "settings":{"exportPreset":"youtube-1080p","paddingMs":0}})).unwrap();
        // 0.07 s of source on a 4x clip is 0.0175 s on screen: extended to a frame, never dropped.
        let tiny = mask(json!({"srcStart":1.0,"srcEnd":1.07}));
        let s = mask_output_spans(&p, &tiny);
        assert_eq!(s.len(), 2, "both copies {s:?}");
        assert!((s[0].0 - 0.25).abs() < 1e-9 && (s[0].1 - (0.25 + MIN_SPAN_SEC)).abs() < 1e-9);
        assert!((s[1].0 - 3.0).abs() < 1e-9, "the duplicate at 2 s + 1 s: {s:?}");
        // Reaching the last frame also masks the freeze frame.
        let last = mask(json!({"srcStart":3.5,"srcEnd":4}));
        assert!(mask_output_spans(&p, &last).iter().any(|(a, b)| (*a - 0.875).abs() < 1e-9 && (*b - 2.0).abs() < 1e-9));
    }

    #[test]
    fn overlay_inputs_are_local_only_with_a_fixed_demuxer_and_a_pixel_cap() {
        let o = sanitize_overlay(&json!({"path":"/a/odd%d.png","start":0,"end":1}), 2.).unwrap();
        let a = overlay_input_args(&o, 30.).join(" ");
        assert!(a.starts_with("-protocol_whitelist file -f image2 -pattern_type none -max_pixels 268435456 "), "{a}");
        let v = sanitize_overlay(&json!({"path":"/a/b.mov","start":0,"end":1,"trimIn":2}), 2.).unwrap();
        assert!(overlay_input_args(&v, 30.).join(" ").contains("-f mov -max_pixels 268435456 -ss 2.000000 -t"));
        assert!(sanitize_overlay(&json!({"path":"/a.png","start":0,"end":1,"srcW":16385}), 2.).is_none());
        if ff().is_none() {
            return;
        }
        // A ".png" that is really an HLS playlist pointing at the network: refused, nothing fetched.
        let dir = std::env::temp_dir().join(format!("yc-poly-{}", uuid::Uuid::new_v4()));
        std::fs::create_dir_all(&dir).unwrap();
        let evil = dir.join("evil.png");
        std::fs::write(&evil, "#EXTM3U\n#EXT-X-TARGETDURATION:1\n#EXTINF:1,\nhttp://127.0.0.1:9/x.ts\n#EXT-X-ENDLIST\n").unwrap();
        let o = sanitize_overlay(&json!({"path": evil.to_string_lossy(), "start":0,"end":1}), 2.).unwrap();
        let mut args: Vec<String> = vec!["-v".into(), "debug".into()];
        args.extend(overlay_input_args(&o, 10.));
        args.extend(["-i".into(), o.path.clone(), "-frames:v".into(), "1".into(), "-f".into(), "null".into(), "-".into()]);
        let out = Command::new(ff().unwrap()).args(&args).output().unwrap();
        let err = String::from_utf8_lossy(&out.stderr);
        assert!(!out.status.success(), "a fake PNG must not decode");
        assert!(!err.contains("hls") && !err.contains("127.0.0.1"), "no playlist / network access: {err}");
        // A real PNG whose name contains a printf pattern still works (no image sequence).
        let odd = dir.join("odd%d.png");
        std::fs::rename(write_png(&dir, "plain.png", "color=red:s=16x16"), &odd).unwrap();
        let odd = odd.to_string_lossy().into_owned();
        let o = sanitize_overlay(&json!({"path": odd, "start":0,"end":1}), 2.).unwrap();
        let mut args: Vec<String> = vec!["-v".into(), "error".into()];
        args.extend(overlay_input_args(&o, 10.));
        args.extend(["-i".into(), o.path.clone(), "-frames:v".into(), "1".into(), "-f".into(), "null".into(), "-".into()]);
        assert!(Command::new(ff().unwrap()).args(&args).output().unwrap().status.success());
        std::fs::remove_dir_all(dir).unwrap();
    }

    fn ff() -> Option<PathBuf> {
        let p = Path::new(env!("CARGO_MANIFEST_DIR")).join("binaries/ffmpeg-aarch64-apple-darwin");
        p.exists().then_some(p)
    }

    /// Render `graph` (reading `[0:v]`, writing `[o]`) over a 640x360 test pattern; frame `n` as RGB.
    fn render(graph: &str, n: u32, extra_inputs: &[String]) -> Vec<u8> {
        let mut args: Vec<String> = ["-v", "error", "-f", "lavfi", "-i", "color=c=gray:s=640x360:r=10:d=4,geq=lum='if(mod(floor(X/4)+floor(Y/4),2),220,30)':cb='128+60*sin(X/40)':cr='128+60*cos(Y/30)',format=yuv420p"].map(String::from).to_vec();
        args.extend(extra_inputs.iter().cloned());
        args.extend([
            "-filter_complex".into(),
            format!("{graph};[o]select=eq(n\\,{n}),format=rgb24[s]"),
            "-map".into(), "[s]".into(), "-frames:v".into(), "1".into(),
            "-f".into(), "rawvideo".into(), "pipe:1".into(),
        ]);
        let out = Command::new(ff().unwrap()).args(&args).output().unwrap();
        assert!(out.status.success(), "{}", String::from_utf8_lossy(&out.stderr));
        assert_eq!(out.stdout.len(), 640 * 360 * 3);
        out.stdout
    }
    fn px(f: &[u8], x: usize, y: usize) -> [i32; 3] {
        let i = (y * 640 + x) * 3;
        [f[i] as i32, f[i + 1] as i32, f[i + 2] as i32]
    }
    /// Sum of absolute horizontal differences in a box: high for detail, ~0 when blurred / filled.
    fn detail(f: &[u8], x0: usize, y0: usize, x1: usize, y1: usize) -> i64 {
        let mut d = 0i64;
        for y in y0..y1 {
            for x in x0..x1 - 1 {
                let (a, b) = (px(f, x, y), px(f, x + 1, y));
                d += (0..3).map(|c| (a[c] - b[c]).abs() as i64).sum::<i64>();
            }
        }
        d
    }

    #[test]
    fn real_ffmpeg_blur_changes_only_the_region_and_only_in_range() {
        if ff().is_none() {
            return;
        }
        let m = mask(json!({"x":0.25,"y":0.25,"w":0.25,"h":0.25,"effect":"blur","strength":40}));
        let rect = Rect::fit(640, 360, 640, 360);
        let graph = chain(&m, rect);
        let plain = render("[0:v]null[o]", 15, &[]);
        let masked = render(&graph, 15, &[]);
        // Outside the region: bit-identical to the unmasked picture.
        let (x, y, w, h) = mask_region(&m, rect, 640, 360);
        let (x, y, w, h) = (x as usize, y as usize, w as usize, h as usize);
        for yy in 0..360 {
            for xx in 0..640 {
                if !(xx >= x && xx < x + w && yy >= y && yy < y + h) {
                    assert_eq!(px(&masked, xx, yy), px(&plain, xx, yy), "pixel {xx},{yy} changed outside the mask");
                }
            }
        }
        // Inside: the detail is gone.
        let (before, after) = (detail(&plain, x + 4, y + 4, x + w - 4, y + h - 4), detail(&masked, x + 4, y + 4, x + w - 4, y + h - 4));
        assert!(after * 5 < before, "blurred {after} vs source {before}");
        // Out of range (frame 30 = 3.0 s, past end + one frame pad): untouched.
        assert_eq!(render(&graph, 30, &[]), render("[0:v]null[o]", 30, &[]));
    }

    #[test]
    fn real_ffmpeg_pixelate_solid_dim_and_ellipse() {
        if ff().is_none() {
            return;
        }
        let rect = Rect::fit(640, 360, 640, 360);
        let at = |spec: Value| render(&chain(&mask(spec), rect), 15, &[]);
        let plain = render("[0:v]null[o]", 15, &[]);
        let solid = at(json!({"start":0,"end":4,"x":0.5,"y":0.5,"w":0.25,"h":0.25,"effect":"solid","color":"#00ff00"}));
        let c = px(&solid, 400, 220);
        assert!(c[1] > 200 && c[0] < 60 && c[2] < 60, "solid green {c:?}");
        let ell = at(json!({"start":0,"end":4,"x":0.5,"y":0.5,"w":0.25,"h":0.25,"effect":"solid","color":"#00ff00","shape":"ellipse"}));
        assert!(px(&ell, 400, 225)[1] > 200, "ellipse centre filled");
        assert_eq!(px(&ell, 322, 182), px(&plain, 322, 182), "ellipse corner untouched");
        let pix = at(json!({"start":0,"end":4,"x":0.25,"y":0.25,"w":0.25,"h":0.25,"effect":"pixelate","strength":40}));
        assert!(detail(&pix, 164, 94, 316, 176) * 3 < detail(&plain, 164, 94, 316, 176));
        let dim = at(json!({"start":0,"end":4,"x":0.25,"y":0.25,"w":0.25,"h":0.25,"effect":"dim","strength":80}));
        assert_eq!(px(&dim, 200, 120), px(&plain, 200, 120), "highlighted region unchanged");
        let (a, b) = (px(&dim, 600, 340), px(&plain, 600, 340));
        assert!(a.iter().sum::<i32>() < b.iter().sum::<i32>() / 2 + 30, "surround dimmed {a:?} vs {b:?}");
    }

    fn write_png(dir: &Path, name: &str, src: &str) -> String {
        let p = dir.join(name);
        let out = Command::new(ff().unwrap())
            .args(["-v", "error", "-y", "-f", "lavfi", "-i", src, "-frames:v", "1"])
            .arg(&p)
            .output()
            .unwrap();
        assert!(out.status.success(), "{}", String::from_utf8_lossy(&out.stderr));
        p.to_string_lossy().into_owned()
    }

    #[test]
    fn real_ffmpeg_overlay_is_drawn_only_in_range_at_its_place_and_opacity_with_alpha() {
        if ff().is_none() {
            return;
        }
        let dir = std::env::temp_dir().join(format!("yc-layers-{}", uuid::Uuid::new_v4()));
        std::fs::create_dir_all(&dir).unwrap();
        // Solid red, and a PNG that is opaque blue on the left half, fully transparent on the right.
        let red = write_png(&dir, "red.png", "color=red:s=64x64");
        let half = write_png(&dir, "half.png", "color=blue@1:s=64x64,format=rgba,geq=r='0':g='0':b='255':a='if(lt(X,32),255,0)'");
        let base = |p: &str, opacity: f64, x: f64| {
            sanitize_overlay(&json!({"path":p,"start":1,"end":2,"x":x,"y":0.5,"w":0.25,"h":0.25,"opacity":opacity}), 4.).unwrap()
        };
        let (a, b) = (base(&red, 0.5, 0.0), base(&half, 1.0, 0.5));
        let rect = Rect::fit(640, 360, 640, 360);
        let mut inputs: Vec<String> = overlay_input_args(&a, 10.);
        inputs.extend(["-i".into(), red.clone()]);
        inputs.extend(overlay_input_args(&b, 10.));
        inputs.extend(["-i".into(), half.clone()]);
        let graph = overlay_chain(&[(&a, "1:v".into()), (&b, "2:v".into())], rect, "ovl", "0:v", "o");
        let plain = render("[0:v]null[o]", 15, &[]);
        let f = render(&graph, 15, &inputs);
        // Half-opacity red over the test pattern at x 0..160, y 180..270.
        let (p, q) = (px(&f, 80, 225), px(&plain, 80, 225));
        assert!((p[0] - (q[0] + 255) / 2).abs() < 20 && (p[1] - q[1] / 2).abs() < 20, "50 % red {p:?} over {q:?}");
        let (o, p0) = (px(&f, 200, 100), px(&plain, 200, 100));
        assert!((0..3).all(|c| (o[c] - p0[c]).abs() <= 3), "outside the overlay {o:?} {p0:?}");
        // Alpha PNG: blue where opaque, the picture shows through where transparent.
        let blue = px(&f, 330, 225);
        assert!(blue[2] > 220 && blue[0] < 30, "opaque half {blue:?}");
        let through = (px(&f, 440, 225), px(&plain, 440, 225));
        assert!((0..3).all(|c| (through.0[c] - through.1[c]).abs() < 6), "transparent half {through:?}");
        // Before and after the span: no overlay at all.
        // (Overlay compositing may round the frame by a level; masks must not, see above.)
        let near = |a: &[u8], b: &[u8]| a.iter().zip(b).all(|(x, y)| (*x as i32 - *y as i32).abs() <= 3);
        assert!(near(&render(&graph, 5, &inputs), &render("[0:v]null[o]", 5, &[])), "before the span");
        assert!(near(&render(&graph, 25, &inputs), &render("[0:v]null[o]", 25, &[])), "after the span");
        std::fs::remove_dir_all(dir).unwrap();
    }
}
