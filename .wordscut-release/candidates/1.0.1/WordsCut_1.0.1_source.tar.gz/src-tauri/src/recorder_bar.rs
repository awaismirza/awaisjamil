//! The floating recorder setup bar: a focusable, always-on-top window (label
//! `recorder-bar`, entry `recorder-bar.html`) that exists only while the session
//! is idle. It is destroyed on close or when a take starts, which also releases
//! the camera preview. The main editor window is hidden while the bar is up.
//!
//! Pure policy ([`bar_frame`], [`observe_phase`]) is unit tested; the rest drives
//! the windows. The title starts with the controller title so the native capture
//! helper excludes the bar from the footage.

use crate::controller::{self, Rect};
use crate::recording_session::Phase;
use crate::AppState;
use serde::Serialize;
use std::sync::Mutex;
use tauri::{
    AppHandle, Emitter, Manager, PhysicalPosition, PhysicalSize, WebviewUrl, WebviewWindow,
    WebviewWindowBuilder, WindowEvent,
};

pub const LABEL: &str = "recorder-bar";
/// Prefixed by the controller title, so the Swift exclusion filter matches it.
pub const TITLE: &str = "WordsCut Recording Controls — Setup";
pub const BAR_W: f64 = 1180.0;
pub const BAR_H: f64 = 76.0;
pub const MAX_H: f64 = 520.0;
const SIDE_MARGIN: f64 = 24.0;
const TOP_OFFSET: f64 = 48.0;
pub const VISIBILITY_EVENT: &str = "recorder-bar:visibility";

/// Remembers the previous session phase so the sink can spot a return to idle.
#[derive(Default)]
pub struct RecorderBarState {
    prev: Mutex<Option<Phase>>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SinkAction {
    None,
    /// A take started: the bar must not stay up over the footage.
    DestroyBar,
    /// A take ended: make sure the editor is back (the caller checks visibility).
    RestoreMain,
}

/// Pure transition rule for the authority sink.
pub fn observe_phase(prev: Option<Phase>, now: Phase) -> SinkAction {
    if now == Phase::Recording {
        return SinkAction::DestroyBar;
    }
    match prev {
        Some(p) if p != Phase::Idle && now == Phase::Idle => SinkAction::RestoreMain,
        _ => SinkAction::None,
    }
}

impl RecorderBarState {
    /// Record `now` and return what the sink should do for the change.
    pub fn observe(&self, now: Phase) -> SinkAction {
        let mut g = self.prev.lock().unwrap();
        let action = observe_phase(*g, now);
        *g = Some(now);
        action
    }
}

/// Physical `(x, y, w, h)` of the bar on `monitor`: top centre, `48 * scale`
/// below the monitor top, width clamped to the monitor minus a 24 pt gutter.
pub fn bar_frame(monitor: &Rect, scale: f64) -> (i32, i32, u32, u32) {
    let max_w = (monitor.w as f64 - 2.0 * SIDE_MARGIN * scale).max(1.0);
    let w = (BAR_W * scale).min(max_w).round() as u32;
    let h = (BAR_H * scale).round() as u32;
    let (x, _) = controller::default_position((w, h), monitor);
    let y = monitor.y + (TOP_OFFSET * scale).round() as i32;
    let (x, y) = controller::clamp_to_monitors((x, y), (w, h), std::slice::from_ref(monitor));
    (x, y, w, h)
}

/// Clamp a requested logical height to `[BAR_H, MAX_H]`.
pub fn clamp_height(height: f64) -> f64 {
    if height.is_finite() {
        height.clamp(BAR_H, MAX_H)
    } else {
        BAR_H
    }
}

#[derive(Serialize, Clone)]
struct Visibility {
    visible: bool,
}

fn emit_visibility(app: &AppHandle, visible: bool) {
    let _ = app.emit(VISIBILITY_EVENT, Visibility { visible });
}

fn rect_of(m: &tauri::Monitor) -> Rect {
    Rect { x: m.position().x, y: m.position().y, w: m.size().width, h: m.size().height }
}

/// The monitor holding the cursor, else the main window's, else the first.
fn target_monitor(app: &AppHandle) -> Option<(Rect, f64)> {
    let mons = app.available_monitors().unwrap_or_default();
    if let Ok(c) = app.cursor_position() {
        let (cx, cy) = (c.x as i32, c.y as i32);
        for m in &mons {
            let r = rect_of(m);
            if cx >= r.x && cy >= r.y && cx < r.x + r.w as i32 && cy < r.y + r.h as i32 {
                return Some((r, m.scale_factor()));
            }
        }
    }
    if let Some(m) = app
        .get_webview_window("main")
        .and_then(|w| w.current_monitor().ok().flatten())
    {
        return Some((rect_of(&m), m.scale_factor()));
    }
    mons.first().map(|m| (rect_of(m), m.scale_factor()))
}

fn create(app: &AppHandle) -> Result<WebviewWindow, String> {
    let win = WebviewWindowBuilder::new(app, LABEL, WebviewUrl::App("recorder-bar.html".into()))
        .title(TITLE)
        .inner_size(BAR_W, BAR_H)
        .resizable(false)
        .maximizable(false)
        .minimizable(false)
        .decorations(false)
        .always_on_top(true)
        .visible_on_all_workspaces(true)
        .skip_taskbar(true)
        .focused(true)
        .visible(false)
        .shadow(true)
        .background_color(tauri::window::Color(28, 28, 30, 255))
        .build()
        .map_err(|e| e.to_string())?;
    let handle = app.clone();
    win.on_window_event(move |event| {
        if let WindowEvent::CloseRequested { api, .. } = event {
            api.prevent_close();
            let _ = close(&handle, true);
        }
    });
    Ok(win)
}

fn place(app: &AppHandle, win: &WebviewWindow) {
    if let Some((mon, scale)) = target_monitor(app) {
        let (x, y, w, h) = bar_frame(&mon, scale);
        let _ = win.set_size(PhysicalSize::new(w, h));
        let _ = win.set_position(PhysicalPosition::new(x, y));
    }
}

fn close(app: &AppHandle, restore_main: bool) -> Result<(), String> {
    if let Some(w) = app.get_webview_window(LABEL) {
        let _ = w.destroy();
    }
    if restore_main {
        controller::show_main_window(app.clone())?;
    }
    emit_visibility(app, false);
    Ok(())
}

/// Show the setup bar and hide the editor. Only while no take is in flight.
#[tauri::command]
pub fn open_recorder_bar(app: AppHandle) -> Result<(), String> {
    let phase = app.state::<AppState>().recording.authority.snapshot().phase;
    if phase != Phase::Idle {
        return Err("a recording is already in progress".into());
    }
    let win = match app.get_webview_window(LABEL) {
        Some(w) => w,
        None => create(&app)?,
    };
    place(&app, &win);
    win.show().map_err(|e| e.to_string())?;
    let _ = win.set_focus();
    // Hide the editor only once the bar is up, so the user is never left with nothing.
    if let Some(main) = app.get_webview_window("main") {
        let _ = main.hide();
    }
    emit_visibility(&app, true);
    Ok(())
}

/// Destroy the bar (releasing the camera), optionally bringing the editor back.
#[tauri::command]
pub fn close_recorder_bar(app: AppHandle, restore_main: bool) -> Result<(), String> {
    close(&app, restore_main)
}

/// Hide the bar without destroying it (just before a take starts).
#[tauri::command]
pub fn hide_recorder_bar(app: AppHandle) -> Result<(), String> {
    if let Some(w) = app.get_webview_window(LABEL) {
        w.hide().map_err(|e| e.to_string())?;
    }
    Ok(())
}

/// Resize the bar to make room for a popover panel below it.
#[tauri::command]
pub fn set_recorder_bar_height(app: AppHandle, height: f64) -> Result<(), String> {
    let Some(win) = app.get_webview_window(LABEL) else {
        return Ok(());
    };
    let w = win.inner_size().map_err(|e| e.to_string())?;
    let scale = win.scale_factor().unwrap_or(1.0);
    win.set_size(tauri::LogicalSize::new(w.width as f64 / scale, clamp_height(height)))
        .map_err(|e| e.to_string())?;
    controller::clamp_in_place(&app, &win);
    Ok(())
}

/// Reveal the recordings folder in Finder (created if missing).
#[tauri::command]
pub fn open_recordings_folder(app: AppHandle) -> Result<(), String> {
    let dir = app
        .path()
        .app_data_dir()
        .map_err(|e| e.to_string())?
        .join("recordings");
    std::fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
    std::process::Command::new("open")
        .arg(&dir)
        .spawn()
        .map(|_| ())
        .map_err(|e| e.to_string())
}

/// Called from the authority sink (must not block): keep the bar and editor honest.
pub fn on_phase(app: &AppHandle, phase: Phase) {
    let action = app.state::<RecorderBarState>().observe(phase);
    match action {
        SinkAction::None => {}
        SinkAction::DestroyBar => {
            if let Some(w) = app.get_webview_window(LABEL) {
                let _ = w.destroy();
                emit_visibility(app, false);
            }
        }
        SinkAction::RestoreMain => {
            let main_hidden = app
                .get_webview_window("main")
                .map(|w| !w.is_visible().unwrap_or(true))
                .unwrap_or(false);
            if main_hidden && app.get_webview_window(LABEL).is_none() {
                let _ = controller::show_main_window(app.clone());
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn frame_on_retina_display() {
        let m = Rect { x: 0, y: 0, w: 2880, h: 1800 };
        assert_eq!(bar_frame(&m, 2.0), (260, 96, 2360, 152));
    }

    #[test]
    fn frame_clamps_width_on_small_monitor() {
        let m = Rect { x: 100, y: 0, w: 1100, h: 800 };
        let (x, y, w, h) = bar_frame(&m, 1.0);
        assert_eq!(w, 1100 - 48);
        assert_eq!(h, 76);
        assert_eq!(y, 48);
        assert_eq!(x, 100 + 24);
    }

    #[test]
    fn height_is_clamped() {
        assert_eq!(clamp_height(10.0), BAR_H);
        assert_eq!(clamp_height(9999.0), MAX_H);
        assert_eq!(clamp_height(f64::NAN), BAR_H);
        assert_eq!(clamp_height(300.0), 300.0);
    }

    #[test]
    fn sink_transitions() {
        use Phase::*;
        assert_eq!(observe_phase(Some(Idle), Recording), SinkAction::DestroyBar);
        assert_eq!(observe_phase(Some(Starting), Recording), SinkAction::DestroyBar);
        assert_eq!(observe_phase(Some(Recording), Idle), SinkAction::RestoreMain);
        assert_eq!(observe_phase(Some(Finalizing), Idle), SinkAction::RestoreMain);
        assert_eq!(observe_phase(Some(Starting), Idle), SinkAction::RestoreMain);
        assert_eq!(observe_phase(Some(Idle), Idle), SinkAction::None);
        assert_eq!(observe_phase(None, Idle), SinkAction::None);
        assert_eq!(observe_phase(Some(Idle), Starting), SinkAction::None);
    }

    #[test]
    fn tracker_remembers_previous_phase() {
        let s = RecorderBarState::default();
        assert_eq!(s.observe(Phase::Idle), SinkAction::None);
        assert_eq!(s.observe(Phase::Starting), SinkAction::None);
        assert_eq!(s.observe(Phase::Recording), SinkAction::DestroyBar);
        assert_eq!(s.observe(Phase::Idle), SinkAction::RestoreMain);
        assert_eq!(s.observe(Phase::Idle), SinkAction::None);
    }
}
