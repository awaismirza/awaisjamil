//! Export filter graph for clips with speed, freeze-frame holds, mute and
//! transitions. Pure string building; `commands/export.rs` uses it only when
//! `Project::has_timing_effects()`, so plain EDLs keep their exact argv.
//!
//! Timing model (mirrors `src/lib/timeMap.ts`): clip `i` occupies
//! `play_len + hold` output seconds. Transitions are overlap-neutral: a
//! crossfade pads each side with `h` seconds of its frozen edge frame (and
//! silence), then `xfade`/`acrossfade` overlap the padded clips by `2h`, so
//! the joined length is exactly the sum of the clip lengths and no output time
//! moves. A dip fades the last `h` of one clip to black and the first `h` of
//! the next up from black, with matching audio fades.
//!
//! Frame accounting: a clip that must be resampled (speed, hold, crossfade)
//! gets a whole number of frames, taken from the rounded *timeline* boundaries
//! (`round(end*F) - round(start*F)`), so rounding never accumulates over many
//! clips. Its video is cut to exactly that many frames (`trim=end_frame`) and
//! its audio to exactly `frames / F` seconds, and `xfade` offsets are derived
//! from the same frame counts, so picture and sound end together.

use crate::edl::{transition_half, Segment, TransitionKind};
use std::fmt::Write as _;

/// A frame rate as a rational, e.g. 30000/1001, so frame maths is exact.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Rate {
    pub num: u64,
    pub den: u64,
}

impl Rate {
    pub fn fps(self) -> f64 {
        self.num as f64 / self.den as f64
    }
    /// Nearest whole frame to `secs`.
    pub fn frames(self, secs: f64) -> i64 {
        (secs * self.num as f64 / self.den as f64).round() as i64
    }
    pub fn secs(self, frames: i64) -> f64 {
        frames as f64 * self.den as f64 / self.num as f64
    }
    /// The output rate for retimed clips. NTSC-style rates snap to x/1001,
    /// near-integers to integers, anything else to 1/1000 fps. A missing or
    /// silly rate becomes 30. Capped at `cap` (60 for a source rate: VFR
    /// screen recordings often report a huge `r_frame_rate`; 120 for a rate
    /// the user asked for).
    pub fn from_fps(fps: f64, cap: f64) -> Rate {
        let f = if fps.is_finite() && fps >= 1.0 { fps.min(cap) } else { 30.0 };
        for n in [24000u64, 30000, 48000, 60000, 120000] {
            if (f - n as f64 / 1001.0).abs() < 0.005 {
                return Rate { num: n, den: 1001 };
            }
        }
        if (f - f.round()).abs() < 0.005 {
            return Rate { num: f.round() as u64, den: 1 };
        }
        Rate { num: (f * 1000.0).round() as u64, den: 1000 }
    }
}

impl std::fmt::Display for Rate {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        if self.den == 1 { write!(f, "{}", self.num) } else { write!(f, "{}/{}", self.num, self.den) }
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct ClipSpec {
    pub input: usize,
    pub sin: f64,
    pub sout: f64,
    pub speed: f64,
    pub mute: bool,
    /// Timeline (output) start and length of the clip: footage plus hold.
    pub start: f64,
    pub len: f64,
    pub hold: f64,
    /// Crossfade half-length into / out of this clip (0 = none).
    pub xin: f64,
    pub xout: f64,
    /// Dip half-length into / out of this clip (0 = none).
    pub dip_in: f64,
    pub dip_out: f64,
}

impl ClipSpec {
    /// Speed, a hold or crossfade padding change the frame count: such a clip
    /// is resampled to a constant rate. Mute or a dip alone keep source frames.
    fn needs_resample(&self) -> bool {
        (self.speed - 1.0).abs() > 1e-9 || self.hold > 0.0 || self.xin > 0.0 || self.xout > 0.0
    }
}

/// One spec per segment, in output order. `input_of` gives the ffmpeg input index.
pub fn clip_specs(segments: &[Segment], mut input_of: impl FnMut(&Segment) -> usize) -> Vec<ClipSpec> {
    let half = |i: usize, kind: TransitionKind| {
        let h = transition_half(segments, i);
        match segments.get(i).and_then(|s| s.timing.transition_in) {
            Some(t) if t.kind == kind && h > 1e-3 => h,
            _ => 0.0,
        }
    };
    let mut start = 0.0;
    segments
        .iter()
        .enumerate()
        .map(|(i, seg)| {
            let c = ClipSpec {
                input: input_of(seg),
                sin: seg.source_in.max(0.0),
                sout: seg.source_out,
                speed: seg.speed(),
                mute: seg.muted(),
                start,
                len: seg.output_len(),
                hold: seg.hold(),
                xin: half(i, TransitionKind::Crossfade),
                xout: half(i + 1, TransitionKind::Crossfade),
                dip_in: half(i, TransitionKind::Dip),
                dip_out: half(i + 1, TransitionKind::Dip),
            };
            start += c.len;
            c
        })
        .collect()
}

/// How each clip's stream is cut, after deciding which clips are resampled.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct ClipFrames {
    /// Resampled to the export rate and cut to `frames` exactly.
    pub resampled: bool,
    /// Crossfade padding at the head / tail, in frames.
    pub kin: i64,
    pub kout: i64,
    /// Total frames of the padded stream (resampled clips only).
    pub frames: i64,
    /// Length of the padded stream in seconds (audio is cut to this).
    pub secs: f64,
}

impl ClipFrames {
    /// A resampled clip that rounds to no frame: not in the graph at all.
    pub fn dropped(&self) -> bool {
        self.resampled && self.frames == 0
    }
}

/// Frame plan for every clip. With any crossfade every clip is resampled
/// (`xfade` needs one rate and timebase on both sides).
pub fn plan_frames(specs: &[ClipSpec], rate: Rate) -> Vec<ClipFrames> {
    let crossfades = specs.iter().any(|c| c.xin > 0.0);
    // Footage frames per clip from rounded timeline boundaries. A resampled
    // clip shorter than half a frame gets none and is left out of the graph
    // (`ClipFrames::dropped`), exactly as the rounded timeline has no frame for it.
    let base: Vec<i64> =
        specs.iter().map(|c| (rate.frames(c.start + c.len) - rate.frames(c.start)).max(0)).collect();
    // Crossfade padding K into clip i: never more than either neighbour's
    // frames; 0 (a plain cut) when either side has none.
    let k: Vec<i64> = specs
        .iter()
        .enumerate()
        .map(|(i, c)| if i > 0 && c.xin > 0.0 { rate.frames(c.xin).min(base[i - 1]).min(base[i]).max(0) } else { 0 })
        .collect();
    let mut out: Vec<ClipFrames> = specs
        .iter()
        .enumerate()
        .map(|(i, c)| {
            let resampled = crossfades || c.needs_resample();
            let (kin, kout) = (k[i], k.get(i + 1).copied().unwrap_or(0));
            if resampled {
                let frames = base[i] + kin + kout;
                ClipFrames { resampled, kin, kout, frames, secs: rate.secs(frames) }
            } else {
                ClipFrames { resampled, kin: 0, kout: 0, frames: 0, secs: c.len }
            }
        })
        .collect();
    // A whole timeline under half a frame still needs one clip in the graph.
    if !out.is_empty() && out.iter().all(ClipFrames::dropped) {
        out[0].frames = 1;
        out[0].secs = rate.secs(1);
    }
    out
}

/// `atempo` only accepts 0.5..=2 per instance on older ffmpeg; chain it.
fn atempo_chain(speed: f64) -> String {
    let mut s = speed;
    let mut out = String::new();
    while s > 2.0 + 1e-9 {
        out.push_str(",atempo=2");
        s /= 2.0;
    }
    while s < 0.5 - 1e-9 {
        out.push_str(",atempo=0.5");
        s /= 0.5;
    }
    if (s - 1.0).abs() > 1e-9 {
        let _ = write!(out, ",atempo={s:.6}");
    }
    out
}

/// Video filter for one clip, from its input to `[label]`. `tail` is the shared
/// scale/pad/fps suffix.
///
/// A resampled clip goes `trim, setpts(speed), fps=R, tpad, tail, trim=end_frame`:
/// `fps` right after `setpts` drops the extra frames of a sped-up clip, and is
/// required before `tpad` (ffmpeg 7.1's `tpad` pads nothing straight after
/// `trim,setpts`). `tpad` over-pads by two frames and `trim=end_frame` cuts to
/// the planned count, so the clip is exactly `frames` long whatever `fps`
/// rounded. `settb` evens the timebase for `xfade`.
/// `src`: a label to read instead of `[input:v]` (the clip's privacy-mask stage).
pub fn video_chain(c: &ClipSpec, f: &ClipFrames, tail: &str, rate: Rate, settb: bool, label: &str, src: Option<&str>) -> String {
    let input = src.map_or_else(|| format!("{}:v", c.input), String::from);
    let mut s = format!("[{input}]trim=start={}:end={}", c.sin, c.sout);
    if (c.speed - 1.0).abs() > 1e-9 {
        let _ = write!(s, ",setpts=(PTS-STARTPTS)/{:.6}", c.speed);
    } else {
        s.push_str(",setpts=PTS-STARTPTS");
    }
    if f.resampled {
        let stop = rate.frames(c.hold) + f.kout + 2;
        // eof_action=pass: a clip shorter than a frame would otherwise round to
        // no frame at all, leaving tpad nothing to clone.
        let _ = write!(s, ",fps={rate}:eof_action=pass,tpad=");
        if f.kin > 0 {
            let _ = write!(s, "start_mode=clone:start={}:", f.kin);
        }
        let _ = write!(s, "stop_mode=clone:stop={stop}");
    }
    s.push_str(tail);
    if f.resampled {
        let _ = write!(s, ",trim=end_frame={}", f.frames);
    }
    if settb {
        s.push_str(",settb=AVTB");
    }
    if c.dip_in > 0.0 {
        let _ = write!(s, ",fade=t=in:st=0:d={:.6}", c.dip_in);
    }
    if c.dip_out > 0.0 {
        let _ = write!(s, ",fade=t=out:st={:.6}:d={:.6}", f.secs - c.dip_out, c.dip_out);
    }
    let _ = write!(s, "[{label}]");
    s
}

/// Audio filter for one clip, cut to exactly the clip's planned length so it
/// matches the picture and `atempo` rounding never accumulates. `silent` mutes
/// it (a muted clip, or another source in a stem).
pub fn audio_chain(c: &ClipSpec, f: &ClipFrames, rate: Rate, silent: bool, label: &str) -> String {
    let mut s = format!("[{}:a]atrim=start={}:end={},asetpts=PTS-STARTPTS", c.input, c.sin, c.sout);
    s.push_str(&atempo_chain(c.speed));
    if silent || c.mute {
        s.push_str(",volume=0");
    }
    if f.kin > 0 {
        let _ = write!(s, ",adelay=delays={:.3}:all=1", rate.secs(f.kin) * 1000.0);
    }
    let len = f.secs;
    // Timestamps from the sample count: `atempo` fed digital silence (ffmpeg
    // 7.1) emits timestamps that make `concat` fail with "Invalid data".
    let _ = write!(s, ",apad=whole_dur={len:.6},atrim=end={len:.6},asetpts=N/SR/TB");
    if c.dip_in > 0.0 {
        let _ = write!(s, ",afade=t=in:st=0:d={:.6}", c.dip_in);
    }
    if c.dip_out > 0.0 {
        let _ = write!(s, ",afade=t=out:st={:.6}:d={:.6}", len - c.dip_out, c.dip_out);
    }
    let _ = write!(s, "[{label}]");
    s
}

/// One crossfade join: where it starts in the stream so far, how long it is,
/// and where that stream ends (all in frames). `offset + d <= end` always.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Join {
    pub offset: i64,
    pub d: i64,
    pub end: i64,
}

/// Runs of clip indices (a new run starts at every crossfade) and the join
/// before each run after the first, from the frame plan.
pub fn plan_joins(specs: &[ClipSpec], frames: &[ClipFrames]) -> (Vec<Vec<usize>>, Vec<Join>) {
    debug_assert_eq!(specs.len(), frames.len());
    let mut runs: Vec<Vec<usize>> = Vec::new();
    for (i, f) in frames.iter().enumerate() {
        if f.dropped() {
            continue;
        }
        if runs.is_empty() || f.kin > 0 {
            runs.push(Vec::new());
        }
        runs.last_mut().expect("run").push(i);
    }
    let mut joins = Vec::new();
    let mut cur = 0i64;
    for (j, run) in runs.iter().enumerate() {
        let run_frames: i64 = run.iter().map(|&i| frames[i].frames).sum();
        if j > 0 {
            let d = frames[run[0]].kin * 2;
            joins.push(Join { offset: cur - d, d, end: cur });
            cur -= d;
        }
        cur += run_frames;
    }
    (runs, joins)
}

/// Join per-clip streams `[{p}v{i}]` / `[{p}a{i}]` into `vout` / `aout`.
/// Clips between crossfades are concatenated as runs; runs are joined with
/// `xfade` / constant-power `acrossfade` at frame-exact offsets, so the total
/// length is the sum of the clip lengths.
pub fn join(
    filter: &mut String,
    specs: &[ClipSpec],
    frames: &[ClipFrames],
    rate: Rate,
    p: &str,
    vout: Option<&str>,
    aout: Option<&str>,
) {
    let (runs, joins) = plan_joins(specs, frames);
    let single = runs.len() == 1;
    for (j, run) in runs.iter().enumerate() {
        let (rv, ra) = if single {
            (vout.unwrap_or_default().to_string(), aout.unwrap_or_default().to_string())
        } else {
            (format!("{p}rv{j}"), format!("{p}ra{j}"))
        };
        let mut ins = String::new();
        for &i in run {
            if vout.is_some() {
                let _ = write!(ins, "[{p}v{i}]");
            }
            if aout.is_some() {
                let _ = write!(ins, "[{p}a{i}]");
            }
        }
        let _ = write!(
            filter,
            ";{ins}concat=n={n}:v={v}:a={a}{vo}{ao}",
            n = run.len(),
            v = vout.is_some() as u8,
            a = aout.is_some() as u8,
            vo = if vout.is_some() { format!("[{rv}]") } else { String::new() },
            ao = if aout.is_some() { format!("[{ra}]") } else { String::new() },
        );
        if j == 0 {
            continue;
        }
        let join = joins[j - 1];
        let d = rate.secs(join.d);
        let last = j == runs.len() - 1;
        let (prev_v, prev_a) = if j == 1 {
            (format!("{p}rv0"), format!("{p}ra0"))
        } else {
            (format!("{p}xv{}", j - 1), format!("{p}xa{}", j - 1))
        };
        if let Some(v) = vout {
            let out = if last { v.to_string() } else { format!("{p}xv{j}") };
            let _ = write!(
                filter,
                ";[{prev_v}][{rv}]xfade=transition=fade:duration={d:.6}:offset={o:.6}[{out}]",
                o = rate.secs(join.offset)
            );
        }
        if let Some(a) = aout {
            let out = if last { a.to_string() } else { format!("{p}xa{j}") };
            // Constant power: each side is padded with silence, so a linear
            // (tri) fade would sag to -6 dB at the cut; qsin dips at most -3 dB.
            let _ = write!(filter, ";[{prev_a}][{ra}]acrossfade=d={d:.6}:c1=qsin:c2=qsin[{out}]");
        }
    }
}

/// The whole clip section of the graph: per-clip chains then the join. Starts
/// without a leading `;`, matching the plain path, which also starts the graph.
#[allow(clippy::too_many_arguments)]
pub fn append_clips(
    filter: &mut String,
    specs: &[ClipSpec],
    video_tail: &str,
    rate: Rate,
    p: &str,
    vout: Option<&str>,
    aout: Option<&str>,
    only_input: Option<usize>,
    sources: &[Option<String>],
) {
    let crossfades = specs.iter().any(|c| c.xin > 0.0);
    let frames = plan_frames(specs, rate);
    let mut parts: Vec<String> = Vec::new();
    for (i, (c, f)) in specs.iter().zip(&frames).enumerate() {
        if f.dropped() {
            continue;
        }
        if vout.is_some() {
            let src = sources.get(i).cloned().flatten();
            parts.push(video_chain(c, f, video_tail, rate, crossfades, &format!("{p}v{i}"), src.as_deref()));
        }
        if aout.is_some() {
            let silent = only_input.is_some_and(|k| k != c.input);
            parts.push(audio_chain(c, f, rate, silent, &format!("{p}a{i}")));
        }
    }
    filter.push_str(&parts.join(";"));
    join(filter, specs, &frames, rate, p, vout, aout);
}


#[cfg(test)]
mod tests {
    use super::*;
    use crate::edl::{SegmentTiming, Transition};

    fn seg(sin: f64, sout: f64, timing: SegmentTiming) -> Segment {
        Segment { id: "s".into(), media_id: "m".into(), words: vec![], source_in: sin, source_out: sout, timing }
    }

    #[test]
    fn atempo_is_chained_inside_its_range() {
        assert_eq!(atempo_chain(1.0), "");
        assert_eq!(atempo_chain(4.0), ",atempo=2,atempo=2.000000");
        assert_eq!(atempo_chain(0.25), ",atempo=0.5,atempo=0.500000");
        assert_eq!(atempo_chain(1.5), ",atempo=1.500000");
    }

    #[test]
    fn crossfade_padding_keeps_the_joined_length_equal_to_the_timeline() {
        let x = Some(Transition { kind: TransitionKind::Crossfade, duration: 1.0 });
        let segs = vec![
            seg(0.0, 2.0, SegmentTiming { speed: Some(2.0), ..Default::default() }),
            seg(3.0, 5.0, SegmentTiming { transition_in: x, hold_sec: Some(1.0), ..Default::default() }),
            seg(6.0, 8.0, SegmentTiming { transition_in: x, ..Default::default() }),
        ];
        let specs = clip_specs(&segs, |_| 0);
        let rate = Rate { num: 30, den: 1 };
        // Each crossfade overlaps by 2h = 1.0 s (30 frames), padded 15 frames a side.
        assert_eq!((specs[0].xin, specs[0].xout, specs[1].xin, specs[1].xout), (0.0, 0.5, 0.5, 0.5));
        let frames = plan_frames(&specs, rate);
        assert_eq!(frames.iter().map(|f| f.frames).collect::<Vec<_>>(), vec![45, 120, 75]);
        let (_, joins) = plan_joins(&specs, &frames);
        assert_eq!(joins, vec![Join { offset: 15, d: 30, end: 45 }, Join { offset: 105, d: 30, end: 135 }]);
        let total: i64 = frames.iter().map(|f| f.frames).sum::<i64>() - joins.iter().map(|j| j.d).sum::<i64>();
        assert_eq!(total, rate.frames(segs.iter().map(Segment::output_len).sum()));
        let mut f = String::new();
        append_clips(&mut f, &specs, "", rate, "", Some("outv"), Some("mainvox"), None, &[]);
        assert!(f.contains("xfade=transition=fade:duration=1.000000:offset=0.500000[xv1]"), "{f}");
        assert!(f.contains("xfade=transition=fade:duration=1.000000:offset=3.500000[outv]"), "{f}");
        assert!(f.contains("acrossfade=d=1.000000:c1=qsin:c2=qsin[mainvox]"), "{f}");
        assert!(f.contains("setpts=(PTS-STARTPTS)/2.000000,fps=30:eof_action=pass,tpad=stop_mode=clone:stop=17"), "{f}");
        assert!(f.contains("fps=30:eof_action=pass,tpad=start_mode=clone:start=15:stop_mode=clone:stop=47,trim=end_frame=120"), "{f}");
    }

    // ---- real ffmpeg / ffprobe ------------------------------------------------

    use crate::commands::export::{build_reencode_argv, ExportFormat, ExportOpts};
    use crate::edl::{ExportPreset, Project, ProjectSettings, SourceMedia};
    use std::path::{Path, PathBuf};
    use std::process::Command;

    struct Tools {
        ffmpeg: PathBuf,
        ffprobe: PathBuf,
        dir: PathBuf,
    }
    impl Drop for Tools {
        fn drop(&mut self) {
            let _ = std::fs::remove_dir_all(&self.dir);
        }
    }
    fn tools() -> Option<Tools> {
        let bin = |n: &str| {
            let p = Path::new(env!("CARGO_MANIFEST_DIR")).join(format!("binaries/{n}-aarch64-apple-darwin"));
            let ok = std::fs::metadata(&p).is_ok_and(|m| m.len() > 1_000_000)
                && Command::new(&p).arg("-version").output().is_ok_and(|o| o.status.success());
            ok.then_some(p)
        };
        let dir = std::env::temp_dir().join(format!("yusafcut-retime-{}", uuid::Uuid::new_v4()));
        std::fs::create_dir_all(&dir).ok()?;
        Some(Tools { ffmpeg: bin("ffmpeg")?, ffprobe: bin("ffprobe")?, dir })
    }

    const FPS: f64 = 30.0;
    /// Source beeps (1 kHz, 60 ms) at these source times; silence elsewhere.
    const BEEPS: [f64; 4] = [1.0, 4.0, 5.5, 7.0];

    /// 8 s of moving testsrc2 at 30 fps with stereo 48 kHz beeps at `BEEPS`.
    fn make_source(t: &Tools) -> PathBuf {
        let path = t.dir.join("beeps.mp4");
        let cond = BEEPS.iter().map(|b| format!("between(t,{b},{})", b + 0.06)).collect::<Vec<_>>().join("+");
        let audio = format!("aevalsrc='({cond})*0.5*sin(2*PI*1000*t)|({cond})*0.5*sin(2*PI*1000*t)':s=48000:d=8");
        let out = Command::new(&t.ffmpeg)
            .args(["-v", "error", "-y", "-f", "lavfi", "-i", "testsrc2=s=640x360:r=30:d=8"])
            .args(["-f", "lavfi", "-i", &audio])
            .args(["-c:v", "libx264", "-pix_fmt", "yuv420p", "-g", "30", "-c:a", "aac", "-b:a", "192k", "-shortest"])
            .arg(&path)
            .output()
            .unwrap();
        assert!(out.status.success(), "{}", String::from_utf8_lossy(&out.stderr));
        path
    }

    fn project(source: &Path, segs: Vec<Segment>) -> Project {
        let mut media = std::collections::HashMap::new();
        media.insert("m".to_string(), SourceMedia {
            id: "m".into(), path: source.to_string_lossy().into_owned(), duration: 8.0, fps: FPS,
            width: 640, height: 360, audio_sample_rate: 48000, sha256: "x".into(), pending_camera: None,
        });
        Project {
            version: 1, id: "p".into(), name: "p".into(), created_at: "x".into(), updated_at: "x".into(),
            media, segments: segs,
            settings: ProjectSettings { export_preset: ExportPreset::Youtube1080p, padding_ms: 80 },
            original_transcripts: None, chapters: vec![], audio_tracks: vec![], scene: None,
            zoom_regions: None, cursor: None, captions: None, annotations: None, keystrokes: None, overlays: None, masks: None,
        }
    }

    fn export(t: &Tools, p: Project, name: &str) -> PathBuf {
        let out = t.dir.join(name);
        let total = p.output_duration();
        let opts = ExportOpts {
            project: p, output_path: out.to_string_lossy().into_owned(), preset: ExportPreset::Youtube1080p,
            video_bitrate_kbps: Some(2000), audio_bitrate_kbps: None, width: None, height: None, fps: None,
            codec: None, force_reencode: false, scene: None, zoom_regions: vec![], draw_cursor: false,
            format: ExportFormat::Mp4, range: None, stems: false, loudness_lufs: None, captions: None, contact_sheet: None,
        };
        let argv: Vec<String> = build_reencode_argv(&opts, total, None, None).unwrap()
            .into_iter().filter(|a| a != "-hwaccel" && a != "videotoolbox").collect();
        let res = Command::new(&t.ffmpeg).args(&argv).output().unwrap();
        assert!(res.status.success(), "ffmpeg {argv:?}: {}", String::from_utf8_lossy(&res.stderr));
        out
    }

    fn probe(t: &Tools, file: &Path, stream: &str, entries: &str) -> String {
        let out = Command::new(&t.ffprobe)
            .args(["-v", "error", "-count_frames", "-select_streams", stream, "-show_entries", entries])
            .args(["-of", "default=nw=1:nk=1"])
            .arg(file)
            .output()
            .unwrap();
        String::from_utf8_lossy(&out.stdout).trim().to_string()
    }

    /// Centre of every beep in the file: midway between the end of the silence
    /// before it and the start of the silence after it. The centre, not the
    /// onset, because pitch-preserving `atempo` smears a tone's edges by a few
    /// tens of ms at low speeds while leaving its position in time intact.
    fn beep_centres(t: &Tools, file: &Path) -> Vec<f64> {
        let out = Command::new(&t.ffmpeg)
            .args(["-hide_banner", "-i"])
            .arg(file)
            .args(["-af", "silencedetect=n=-30dB:d=0.03", "-f", "null", "-"])
            .output()
            .unwrap();
        let log = String::from_utf8_lossy(&out.stderr);
        let num = |l: &str, key: &str| -> Option<f64> {
            l.split(key).nth(1)?.split_whitespace().next()?.parse().ok()
        };
        let ends: Vec<f64> = log.lines().filter_map(|l| num(l, "silence_end: ")).collect();
        let starts: Vec<f64> = log.lines().filter_map(|l| num(l, "silence_start: ")).collect();
        // Silence k ends where beep k begins; silence k+1 starts where it ends.
        ends.iter().zip(starts.iter().skip(1)).map(|(a, b)| (a + b) / 2.0).collect()
    }

    /// Where each source beep should land: the shared output-time mapping.
    fn mapped_beeps(segs: &[Segment]) -> Vec<f64> {
        let mut out = Vec::new();
        let mut start = 0.0;
        for s in segs {
            for b in BEEPS {
                // A beep needs its whole 60 ms inside the clip to be heard as one.
                if b >= s.source_in && b + 0.06 <= s.source_out && !s.muted() {
                    out.push(start + (b + 0.03 - s.source_in) / s.speed());
                }
            }
            start += s.output_len();
        }
        out
    }

    fn frame(t: &Tools, file: &Path, at: f64) -> Vec<u8> {
        let out = Command::new(&t.ffmpeg)
            .args(["-v", "error", "-ss", &format!("{at:.4}"), "-i"])
            .arg(file)
            .args(["-frames:v", "1", "-vf", "scale=64:36", "-f", "rawvideo", "-pix_fmt", "gray", "-"])
            .output()
            .unwrap();
        assert!(!out.stdout.is_empty(), "no frame at {at}");
        out.stdout
    }

    fn diff(a: &[u8], b: &[u8]) -> f64 {
        a.iter().zip(b).map(|(x, y)| (*x as f64 - *y as f64).abs()).sum::<f64>() / a.len() as f64
    }

    fn assert_duration_and_sync(t: &Tools, segs: &[Segment], file: &Path) {
        let expected = segs.iter().map(Segment::output_len).sum::<f64>();
        let frames: f64 = probe(t, file, "v:0", "stream=nb_read_frames").parse().unwrap();
        assert!((frames / FPS - expected).abs() <= 1.0 / FPS + 1e-9, "video {frames} frames vs {expected} s");
        let audio: f64 = probe(t, file, "a:0", "stream=duration").parse().unwrap();
        assert!((audio - expected).abs() <= 1.0 / FPS, "audio {audio} s vs {expected} s");
        let got = beep_centres(t, file);
        let want = mapped_beeps(segs);
        eprintln!("beep centres {got:?} vs mapped {want:?}");
        assert_eq!(got.len(), want.len(), "beeps {got:?} vs mapped {want:?}");
        for (g, w) in got.iter().zip(&want) {
            assert!((g - w).abs() <= 1.0 / FPS, "beep at {g} s, mapping says {w} s ({got:?} vs {want:?})");
        }
    }

    #[test]
    fn speed_hold_and_crossfade_export_matches_the_mapping() {
        let Some(t) = tools() else { return };
        let src = make_source(&t);
        let x = Some(Transition { kind: TransitionKind::Crossfade, duration: 0.4 });
        let segs = vec![
            seg(0.0, 2.0, SegmentTiming { speed: Some(2.0), ..Default::default() }),
            seg(3.0, 5.0, SegmentTiming { speed: Some(0.5), hold_sec: Some(1.0), ..Default::default() }),
            seg(5.0, 8.0, SegmentTiming { transition_in: x, ..Default::default() }),
        ];
        let out = export(&t, project(&src, segs.clone()), "timed.mp4");
        assert_duration_and_sync(&t, &segs, &out);
        // The hold (output 5.0..6.0, crossfade from 5.8) is one frozen frame: the
        // last frame of the slowed clip. Footage just before it still moves.
        let (held_a, held_b) = (frame(&t, &out, 5.3), frame(&t, &out, 5.7));
        assert!(diff(&held_a, &held_b) < 1.0, "hold moved: {}", diff(&held_a, &held_b));
        assert!(diff(&frame(&t, &out, 4.97), &held_a) < 2.0, "hold is not the last frame");
        assert!(diff(&frame(&t, &out, 4.0), &held_a) > 2.0, "footage before the hold should differ");
    }

    #[test]
    fn dip_and_mute_export_matches_the_mapping() {
        let Some(t) = tools() else { return };
        let src = make_source(&t);
        let d = Some(Transition { kind: TransitionKind::Dip, duration: 1.0 });
        let segs = vec![
            seg(0.0, 3.0, SegmentTiming { muted: Some(true), ..Default::default() }),
            seg(3.0, 6.0, SegmentTiming { transition_in: d, speed: Some(4.0), ..Default::default() }),
            seg(6.0, 8.0, SegmentTiming::default()),
        ];
        let out = export(&t, project(&src, segs.clone()), "dip.mp4");
        assert_duration_and_sync(&t, &segs, &out);
        // At the cut (3.0 s) the picture has dipped to black.
        let black = frame(&t, &out, 3.0);
        let mean = black.iter().map(|v| *v as f64).sum::<f64>() / black.len() as f64;
        assert!(mean < 30.0, "dip should be dark at the cut, mean luma {mean}");
        assert!(frame(&t, &out, 1.0).iter().map(|v| *v as f64).sum::<f64>() / 2304.0 > 60.0);
    }

    /// Mono 48 kHz float samples of a file's audio.
    fn pcm(t: &Tools, file: &Path) -> Vec<f32> {
        let out = Command::new(&t.ffmpeg)
            .args(["-v", "error", "-i"])
            .arg(file)
            .args(["-vn", "-ac", "1", "-ar", "48000", "-f", "f32le", "-"])
            .output()
            .unwrap();
        out.stdout.chunks_exact(4).map(|b| f32::from_le_bytes([b[0], b[1], b[2], b[3]])).collect()
    }

    fn video_frames(t: &Tools, file: &Path) -> i64 {
        probe(t, file, "v:0", "stream=nb_read_frames").parse().unwrap()
    }

    #[test]
    fn two_hundred_odd_speed_clips_keep_picture_and_sound_the_same_length() {
        let Some(t) = tools() else { return };
        let src = make_source(&t);
        let x = Some(Transition { kind: TransitionKind::Crossfade, duration: 0.3 });
        let speeds = [0.37, 1.0, 2.9, 0.61, 3.7, 1.3];
        let segs: Vec<Segment> = (0..200)
            .map(|i| {
                // Ascending source, short clips with a little overlap, like a heavily cut take.
                let sin = i as f64 * 0.035;
                seg(sin, sin + 0.05 + (i % 7) as f64 * 0.031, SegmentTiming {
                    speed: Some(speeds[i % speeds.len()]),
                    hold_sec: (i % 11 == 0).then_some(0.07),
                    transition_in: if i % 9 == 0 && i > 0 { x } else { None },
                    ..Default::default()
                })
            })
            .collect();
        let out = export(&t, project(&src, segs.clone()), "many.mp4");
        let rate = Rate { num: 30, den: 1 };
        let frames = video_frames(&t, &out);
        let samples = pcm(&t, &out).len() as f64;
        let mapped = segs.iter().map(Segment::output_len).sum::<f64>();
        let specs = clip_specs(&segs, |_| 0);
        let plan = plan_frames(&specs, rate);
        let (_, joins) = plan_joins(&specs, &plan);
        let planned = plan.iter().map(|f| f.frames).sum::<i64>() - joins.iter().map(|j| j.d).sum::<i64>();
        let audio_dur: f64 = probe(&t, &out, "a:0", "stream=duration").parse().unwrap();
        eprintln!("200 clips: {frames} frames (planned {planned}), {samples} samples, audio {audio_dur} s, mapped {mapped:.4} s");
        assert!((frames as f64 / FPS - samples / 48000.0).abs() <= 1.0 / FPS, "picture and sound differ");
        assert!((frames - planned).abs() <= 1, "{frames} frames vs planned {planned}");
        assert!((frames - rate.frames(mapped)).abs() <= 1, "{frames} frames vs mapped {mapped} s");
    }

    #[test]
    fn crossfade_audio_dips_no_more_than_three_db() {
        let Some(t) = tools() else { return };
        let path = t.dir.join("tone.mp4");
        let ok = Command::new(&t.ffmpeg)
            .args(["-v", "error", "-y", "-f", "lavfi", "-i", "testsrc2=s=160x90:r=30:d=6"])
            .args(["-f", "lavfi", "-i", "sine=frequency=440:sample_rate=48000:duration=6"])
            .args(["-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest"])
            .arg(&path)
            .status()
            .unwrap();
        assert!(ok.success());
        let x = Some(Transition { kind: TransitionKind::Crossfade, duration: 0.6 });
        let segs = vec![
            seg(0.0, 2.0, SegmentTiming::default()),
            seg(3.0, 5.0, SegmentTiming { transition_in: x, ..Default::default() }),
        ];
        let out = export(&t, project(&path, segs), "xfade.mp4");
        let s = pcm(&t, &out);
        let rms = |from: f64| {
            let a = (from * 48000.0) as usize;
            let w = &s[a..a + 480];
            (w.iter().map(|v| (*v as f64).powi(2)).sum::<f64>() / w.len() as f64).sqrt()
        };
        let steady = rms(0.5);
        let worst = (0..50).map(|k| rms(1.75 + k as f64 * 0.01)).fold(f64::INFINITY, f64::min);
        let dip = 20.0 * (worst / steady).log10();
        eprintln!("crossfade loudness dip {dip:.2} dB");
        assert!(dip > -3.5, "crossfade dips {dip:.2} dB");
    }

    #[test]
    fn a_vfr_source_exports_with_retimed_and_mute_only_clips() {
        let Some(t) = tools() else { return };
        let src = Path::new("/private/tmp/yc-qa/fixtures/vfr.mp4");
        if !src.exists() {
            eprintln!("skipping: vfr fixture not present");
            return;
        }
        let len: f64 = probe(&t, src, "v:0", "format=duration").parse().unwrap_or(4.0);
        let mut p = project(src, vec![
            seg(0.0, len / 2.0, SegmentTiming { muted: Some(true), ..Default::default() }),
            seg(len / 2.0, len, SegmentTiming { speed: Some(1.5), hold_sec: Some(0.5), ..Default::default() }),
        ]);
        // The project records r_frame_rate (30/1 here) although frames arrive ~18/s.
        p.media.get_mut("m").unwrap().duration = len;
        let segs = p.segments.clone();
        let out = export(&t, p, "vfr.mp4");
        let mapped = segs.iter().map(Segment::output_len).sum::<f64>();
        let video: f64 = probe(&t, &out, "v:0", "stream=duration").parse().unwrap();
        let audio = pcm(&t, &out).len() as f64 / 48000.0;
        eprintln!("vfr: video {video} s, audio {audio} s, mapped {mapped} s");
        assert!((video - mapped).abs() <= 0.1, "video {video} vs {mapped}");
        assert!((audio - mapped).abs() <= 1.0 / FPS, "audio {audio} vs {mapped}");
    }

    #[test]
    fn dips_fade_without_padding_and_muted_clips_are_silent() {
        let d = Some(Transition { kind: TransitionKind::Dip, duration: 0.6 });
        let segs = vec![
            seg(0.0, 2.0, SegmentTiming { muted: Some(true), ..Default::default() }),
            seg(3.0, 5.0, SegmentTiming { transition_in: d, ..Default::default() }),
        ];
        let specs = clip_specs(&segs, |_| 0);
        let mut f = String::new();
        append_clips(&mut f, &specs, "", Rate { num: 30, den: 1 }, "", Some("outv"), Some("mainvox"), None, &[]);
        assert!(f.contains("fade=t=out:st=1.700000:d=0.300000[v0]"), "{f}");
        assert!(f.contains("fade=t=in:st=0:d=0.300000[v1]"), "{f}");
        assert!(f.contains("volume=0"), "{f}");
        assert!(f.contains("concat=n=2:v=1:a=1[outv][mainvox]"), "{f}");
        assert!(!f.contains("xfade") && !f.contains("settb"), "{f}");
        // Mute and dips need no constant rate: the source frames are kept (VFR stays VFR).
        assert!(!f.contains("fps=") && !f.contains("tpad"), "{f}");
    }

    #[test]
    fn rates_are_rational_and_capped() {
        assert_eq!(Rate::from_fps(29.97002997, 60.0).to_string(), "30000/1001");
        assert_eq!(Rate::from_fps(30.0, 60.0).to_string(), "30");
        assert_eq!(Rate::from_fps(18.171428, 60.0).to_string(), "18171/1000");
        assert_eq!(Rate::from_fps(90000.0, 60.0).to_string(), "60");
        assert_eq!(Rate::from_fps(240.0, 120.0).to_string(), "120");
        assert_eq!(Rate::from_fps(f64::NAN, 60.0).to_string(), "30");
        let ntsc = Rate::from_fps(29.97, 60.0);
        assert_eq!(ntsc.frames(ntsc.secs(1234)), 1234);
    }

    #[test]
    fn many_short_clips_never_drift_and_joins_stay_inside_their_runs() {
        let x = |d: f64| Some(Transition { kind: TransitionKind::Crossfade, duration: d });
        let speeds = [0.37, 1.0, 2.9, 0.61, 3.7, 1.3];
        let segs: Vec<Segment> = (0..200)
            .map(|i| {
                let sin = (i as f64 * 0.047) % 9.0;
                seg(sin, sin + 0.05 + (i % 7) as f64 * 0.031, SegmentTiming {
                    speed: Some(speeds[i % speeds.len()]),
                    hold_sec: (i % 11 == 0).then_some(0.07),
                    transition_in: (i % 5 == 0 && i > 0).then(|| x(0.1 + (i % 3) as f64 * 0.2)).flatten(),
                    ..Default::default()
                })
            })
            .collect();
        let specs = clip_specs(&segs, |_| 0);
        for rate in [Rate { num: 30, den: 1 }, Rate { num: 30000, den: 1001 }, Rate { num: 25, den: 1 }] {
            let frames = plan_frames(&specs, rate);
            let (_, joins) = plan_joins(&specs, &frames);
            for j in &joins {
                assert!(j.d > 0 && j.offset >= 0 && j.offset + j.d <= j.end, "{j:?}");
            }
            let total = frames.iter().map(|f| f.frames).sum::<i64>() - joins.iter().map(|j| j.d).sum::<i64>();
            let mapped = rate.frames(segs.iter().map(Segment::output_len).sum());
            assert!((total - mapped).abs() <= 1, "{total} frames vs mapped {mapped} at {rate}");
        }
    }
}
