//! `WordsCut mcp`: newline-delimited JSON-RPC on stdin/stdout, logs on stderr.
//! `initialize`, `ping` and notifications are answered locally; `tools/*` is
//! forwarded to the running app's `POST /mcp`.

use super::CliError;
use serde_json::{json, Value};
use std::io::{BufRead, Write};

const SUPPORTED: [&str; 3] = ["2025-06-18", "2025-03-26", "2024-11-05"];
pub const ERR_UNREACHABLE: i64 = -32001;
pub const ERR_ACCESS: i64 = -32002;

/// Forwards one request to the app; `Ok(None)` means "no reply".
pub type Forward<'a> = dyn FnMut(&Value) -> Result<Option<Value>, CliError> + 'a;

pub fn run_bridge(input: impl BufRead, mut out: impl Write, forward: &mut Forward) -> std::io::Result<()> {
    for line in input.lines() {
        let line = line?;
        if line.trim().is_empty() {
            continue;
        }
        if let Some(reply) = handle_line(&line, forward) {
            writeln!(out, "{}", serde_json::to_string(&reply).unwrap_or_default())?;
            out.flush()?;
        }
    }
    Ok(())
}

pub fn handle_line(line: &str, forward: &mut Forward) -> Option<Value> {
    let msg: Value = match serde_json::from_str(line) {
        Ok(v) => v,
        Err(e) => return Some(rpc_error(&Value::Null, -32700, format!("Parse error: {e}"))),
    };
    if !msg.is_object() {
        return Some(rpc_error(&Value::Null, -32600, "Invalid Request (batches are not supported)".into()));
    }
    let id = msg.get("id").cloned();
    let method = msg.get("method").and_then(Value::as_str).unwrap_or("");
    // Notifications and stray responses from the client never get a reply.
    let id = id?;
    if method.is_empty() {
        return None;
    }
    match method {
        "initialize" => {
            let asked = msg["params"]["protocolVersion"].as_str().unwrap_or("");
            let version = if SUPPORTED.contains(&asked) { asked } else { SUPPORTED[0] };
            Some(json!({"jsonrpc":"2.0","id":id,"result":{
                "protocolVersion": version,
                "capabilities": {"tools": {"listChanged": false}},
                "serverInfo": {"name": "yusafcut", "version": env!("CARGO_PKG_VERSION")},
                "instructions": "Drives the open WordsCut project. Call tools with confirm:false to plan, then confirm:true with baseRevision to apply. Times are output-timeline seconds. Undo with the history tool."
            }}))
        }
        "ping" => Some(json!({"jsonrpc":"2.0","id":id,"result":{}})),
        "tools/list" | "tools/call" => match forward(&msg) {
            Ok(Some(reply)) => Some(reply),
            Ok(None) => Some(rpc_error(&id, -32603, "Empty reply from WordsCut".into())),
            Err(e) => {
                eprintln!("yusafcut mcp: {}", e.message);
                let code = if e.code == 4 { ERR_ACCESS } else { ERR_UNREACHABLE };
                Some(rpc_error(&id, code, e.message))
            }
        },
        other => Some(rpc_error(&id, -32601, format!("Method not found: {other}"))),
    }
}

fn rpc_error(id: &Value, code: i64, message: String) -> Value {
    json!({"jsonrpc":"2.0","id":id,"error":{"code":code,"message":message}})
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Cursor;

    fn run(input: &str, fwd: &mut Forward) -> Vec<Value> {
        let mut out = Vec::new();
        run_bridge(Cursor::new(input.as_bytes().to_vec()), &mut out, fwd).unwrap();
        String::from_utf8(out).unwrap().lines().map(|l| serde_json::from_str(l).unwrap()).collect()
    }

    #[test]
    fn local_methods_and_one_line_per_request() {
        let mut calls = 0;
        let mut fwd = |_: &Value| -> Result<Option<Value>, CliError> {
            calls += 1;
            Ok(None)
        };
        let input = concat!(
            "{\"jsonrpc\":\"2.0\",\"id\":1,\"method\":\"initialize\",\"params\":{\"protocolVersion\":\"2024-11-05\"}}\n",
            "{\"jsonrpc\":\"2.0\",\"method\":\"notifications/initialized\"}\n",
            "{\"jsonrpc\":\"2.0\",\"id\":2,\"method\":\"ping\"}\n",
            "{\"jsonrpc\":\"2.0\",\"id\":3,\"method\":\"initialize\",\"params\":{\"protocolVersion\":\"1999\"}}\n",
            "{\"jsonrpc\":\"2.0\",\"id\":4,\"method\":\"nope\"}\n",
            "not json\n",
        );
        let out = run(input, &mut fwd);
        assert_eq!(out.len(), 5);
        assert_eq!(out[0]["result"]["protocolVersion"], "2024-11-05");
        assert_eq!(out[1]["result"], json!({}));
        assert_eq!(out[2]["result"]["protocolVersion"], "2025-06-18");
        assert_eq!(out[3]["error"]["code"], -32601);
        assert_eq!(out[4]["error"]["code"], -32700);
        assert_eq!(calls, 0);
    }

    #[test]
    fn forwards_tools_and_maps_failures() {
        let mut fwd = |m: &Value| -> Result<Option<Value>, CliError> {
            if m["params"]["name"] == "down" {
                return Err(CliError::unreachable("app down"));
            }
            Ok(Some(json!({"jsonrpc":"2.0","id":m["id"],"result":{"echo":m["method"]}})))
        };
        let input = concat!(
            "{\"jsonrpc\":\"2.0\",\"id\":7,\"method\":\"tools/list\"}\n",
            "{\"jsonrpc\":\"2.0\",\"id\":8,\"method\":\"tools/call\",\"params\":{\"name\":\"down\"}}\n",
        );
        let out = run(input, &mut fwd);
        assert_eq!(out[0]["id"], 7);
        assert_eq!(out[0]["result"]["echo"], "tools/list");
        assert_eq!(out[1]["id"], 8);
        assert_eq!(out[1]["error"]["code"], ERR_UNREACHABLE);
    }
}
