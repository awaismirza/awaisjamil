//! Blocking facade over the app's loopback HTTP surface (design §2.5).
//! reqwest is async, so each client owns a tiny current-thread tokio runtime.

use super::CliError;
use serde_json::{json, Value};
use std::time::Duration;
use yusafcut_lib::agent::connection::ConnectionInfo;
use yusafcut_lib::agent::protocol::Health;

pub struct Client {
    rt: tokio::runtime::Runtime,
    http: reqwest::Client,
    base: String,
    token: String,
}

impl Client {
    pub fn new(info: &ConnectionInfo, timeout: Duration) -> Result<Client, CliError> {
        Self::with_base(format!("http://127.0.0.1:{}", info.port), info.token.clone(), timeout)
    }

    pub fn with_base(base: String, token: String, timeout: Duration) -> Result<Client, CliError> {
        let rt = tokio::runtime::Builder::new_current_thread()
            .enable_all()
            .build()
            .map_err(|e| CliError::internal(format!("cannot start async runtime: {e}")))?;
        let http = reqwest::Client::builder()
            .no_proxy()
            .timeout(timeout)
            .build()
            .map_err(|e| CliError::internal(format!("cannot build HTTP client: {e}")))?;
        Ok(Client { rt, http, base, token })
    }

    /// Returns `(status, body)`. 401/403 become the access error (exit 4).
    fn send(&self, method: reqwest::Method, path: &str, body: Option<&Value>) -> Result<(u16, String), CliError> {
        let mut req = self
            .http
            .request(method, format!("{}{}", self.base, path))
            .bearer_auth(&self.token);
        if let Some(b) = body {
            req = req.json(b);
        }
        self.rt.block_on(async {
            let resp = req.send().await.map_err(map_reqwest)?;
            let status = resp.status().as_u16();
            let text = resp.text().await.map_err(map_reqwest)?;
            if status == 401 || status == 403 {
                return Err(CliError::access(
                    "WordsCut rejected the connection token. Re-open the app's Agent (CLI/MCP) dialog and check access is enabled.",
                ));
            }
            Ok((status, text))
        })
    }

    pub fn health(&self) -> Result<Health, CliError> {
        let (status, text) = self.send(reqwest::Method::GET, "/v1/health", None)?;
        if status != 200 {
            return Err(CliError::unreachable(format!("health check returned HTTP {status}")));
        }
        serde_json::from_str(&text).map_err(|e| CliError::unreachable(format!("bad health reply: {e}")))
    }

    pub fn list_tools(&self) -> Result<Vec<Value>, CliError> {
        let (status, text) = self.send(reqwest::Method::GET, "/v1/tools", None)?;
        match serde_json::from_str::<Value>(&text) {
            Ok(Value::Array(a)) if status == 200 => Ok(a),
            Ok(v) if v.get("ok") == Some(&Value::Bool(false)) => Err(CliError::from_outcome(&v)),
            _ => Err(CliError::tool("BAD_REPLY", format!("unexpected reply (HTTP {status})"))),
        }
    }

    /// Returns the raw `ToolOutcome` (ok or not); transport failures are `Err`.
    pub fn call_tool(&self, name: &str, input: &Value) -> Result<Value, CliError> {
        let (status, text) = self.send(
            reqwest::Method::POST,
            "/v1/tools/call",
            Some(&json!({ "name": name, "input": input })),
        )?;
        match serde_json::from_str::<Value>(&text) {
            Ok(v) if v.get("ok").is_some() => Ok(v),
            _ if status == 503 => Ok(json!({
                "ok": false, "tool": name,
                "error": {"code": "EDITOR_NOT_READY", "message": "The WordsCut editor window is not ready yet.", "hint": "Wait a few seconds and retry."}
            })),
            _ => Err(CliError::tool("BAD_REPLY", format!("unexpected reply (HTTP {status})"))),
        }
    }

    /// POST a JSON-RPC message to `/mcp`. `Ok(None)` for 202/empty bodies.
    pub fn post_mcp(&self, msg: &Value) -> Result<Option<Value>, CliError> {
        let (status, text) = self.send(reqwest::Method::POST, "/mcp", Some(msg))?;
        if status == 202 || text.trim().is_empty() {
            return Ok(None);
        }
        serde_json::from_str(&text)
            .map(Some)
            .map_err(|_| CliError::tool("BAD_REPLY", format!("unexpected MCP reply (HTTP {status})")))
    }
}

fn map_reqwest(e: reqwest::Error) -> CliError {
    if e.is_timeout() {
        CliError::tool("TIMEOUT", "Timed out waiting for WordsCut (raise --timeout).")
    } else {
        CliError::unreachable(format!("cannot reach WordsCut: {e}"))
    }
}
