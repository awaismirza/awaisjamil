//! Rendering of outcomes for humans and for `--json`.

use super::CliError;
use serde_json::{json, Value};

pub fn ok_outcome(tool: &str, data: Value) -> Value {
    json!({ "ok": true, "tool": tool, "data": data })
}

pub fn err_outcome(tool: &str, e: &CliError) -> Value {
    let mut error = json!({ "code": e.kind, "message": e.message });
    if let Some(h) = &e.hint {
        error["hint"] = json!(h);
    }
    json!({ "ok": false, "tool": tool, "error": error })
}

/// Exactly one line.
pub fn json_line(outcome: &Value) -> String {
    serde_json::to_string(outcome).unwrap_or_else(|_| "{\"ok\":false}".into())
}

/// Human rendering: `(stdout, stderr)`.
pub fn human(outcome: &Value) -> (String, String) {
    if outcome.get("ok") == Some(&Value::Bool(true)) {
        let data = outcome.get("data").cloned().unwrap_or(Value::Null);
        let mut out = String::new();
        if let Some(s) = data.get("summary").and_then(Value::as_str) {
            out.push_str(s);
            out.push('\n');
            if let Some(a) = data.get("applied").and_then(Value::as_bool) {
                out.push_str(if a { "(applied)\n" } else { "(plan only, nothing changed)\n" });
            }
            out.push('\n');
        }
        out.push_str(&serde_json::to_string_pretty(&data).unwrap_or_default());
        (out, String::new())
    } else {
        let e = outcome.get("error").cloned().unwrap_or(Value::Null);
        let code = e.get("code").and_then(Value::as_str).unwrap_or("ERROR");
        let msg = e.get("message").and_then(Value::as_str).unwrap_or("unknown error");
        let mut text = format!("error [{code}]: {msg}");
        if let Some(h) = e.get("hint").and_then(Value::as_str) {
            text.push_str(&format!("\nhint: {h}"));
        }
        (String::new(), text)
    }
}

/// Table for `tool list`.
pub fn tool_table(tools: &[Value]) -> String {
    let width = tools.iter().filter_map(|t| t["name"].as_str()).map(str::len).max().unwrap_or(4);
    let mut s = String::new();
    for t in tools {
        let name = t["name"].as_str().unwrap_or("?");
        let kind = if t["mutates"].as_bool().unwrap_or(false) { "edit" } else { "read" };
        let first = t["description"].as_str().unwrap_or("").lines().next().unwrap_or("");
        s.push_str(&format!("{name:<width$}  {kind}  {first}\n"));
    }
    s
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn json_is_one_line() {
        let o = ok_outcome("t", json!({"a": [1, 2], "s": "x\ny"}));
        assert!(!json_line(&o).contains('\n'));
    }

    #[test]
    fn human_ok_and_error() {
        let (out, err) = human(&ok_outcome("t", json!({"summary": "Cut 3 words", "applied": false})));
        assert!(out.starts_with("Cut 3 words\n(plan only"));
        assert!(err.is_empty());
        let e = CliError::tool("STALE_REVISION", "changed").with_hint("re-read");
        let (out, err) = human(&err_outcome("t", &e));
        assert!(out.is_empty());
        assert_eq!(err, "error [STALE_REVISION]: changed\nhint: re-read");
    }

    #[test]
    fn table_lists_tools() {
        let t = tool_table(&[json!({"name":"a","mutates":true,"description":"Do it.\nMore"})]);
        assert_eq!(t, "a  edit  Do it.\n");
    }
}
