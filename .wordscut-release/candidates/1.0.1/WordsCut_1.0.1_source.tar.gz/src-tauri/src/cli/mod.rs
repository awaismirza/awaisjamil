//! Headless entry points: `WordsCut agent …` and `WordsCut mcp`.
//! Design: docs/agent-cli-design.md §8. Never starts the Tauri runtime.

mod args;
mod client;
mod inspect;
mod launch;
mod output;
mod stdio;

use args::{Command, Global, InputSource, Parsed};
use serde_json::{json, Value};
use std::io::Read;
use std::path::Path;
use std::time::Duration;
use yusafcut_lib::agent::connection;

pub const README: &str = include_str!("../../resources/agent/README.md");
pub const SKILL: &str = include_str!("../../resources/agent/SKILL.md");
const SKILLS: [(&str, &str); 1] = [("yusafcut", SKILL)];

#[derive(Debug, Clone)]
pub struct CliError {
    pub code: i32,
    pub kind: String,
    pub message: String,
    pub hint: Option<String>,
}

impl CliError {
    fn new(code: i32, kind: &str, message: impl Into<String>) -> Self {
        CliError { code, kind: kind.into(), message: message.into(), hint: None }
    }
    pub fn usage(m: impl Into<String>) -> Self {
        Self::new(2, "USAGE", m)
    }
    pub fn unreachable(m: impl Into<String>) -> Self {
        Self::new(3, "APP_UNREACHABLE", m)
    }
    pub fn access(m: impl Into<String>) -> Self {
        Self::new(4, "ACCESS_DENIED", m)
    }
    pub fn tool(kind: &str, m: impl Into<String>) -> Self {
        let code = if kind == "STALE_REVISION" { 6 } else { 5 };
        Self::new(code, kind, m)
    }
    pub fn internal(m: impl Into<String>) -> Self {
        Self::new(5, "INTERNAL", m)
    }
    pub fn with_hint(mut self, h: impl Into<String>) -> Self {
        self.hint = Some(h.into());
        self
    }
    pub fn from_outcome(o: &Value) -> Self {
        let e = &o["error"];
        let mut err = Self::tool(
            e["code"].as_str().unwrap_or("ERROR"),
            e["message"].as_str().unwrap_or("tool failed"),
        );
        err.hint = e["hint"].as_str().map(str::to_string);
        err
    }
}

pub struct Run {
    pub code: i32,
    pub stdout: String,
    pub stderr: String,
}

/// Process entry: `args` start with `agent` or `mcp`. Returns the exit code.
pub fn run(args: &[String]) -> i32 {
    let parsed = match args::parse(args) {
        Ok(p) => p,
        Err(m) => {
            eprintln!("error: {m}\n\n{}", args::USAGE);
            return 2;
        }
    };
    if parsed.command == Command::Mcp {
        return run_mcp(&parsed.global);
    }
    let mut stdin = std::io::stdin();
    let r = execute(&parsed, &mut stdin);
    if !r.stdout.is_empty() {
        println!("{}", r.stdout.trim_end_matches('\n'));
    }
    if !r.stderr.is_empty() {
        eprintln!("{}", r.stderr.trim_end_matches('\n'));
    }
    r.code
}

fn run_mcp(global: &Global) -> i32 {
    let timeout = Duration::from_secs(global.timeout_secs);
    let no_launch = global.no_launch;
    let mut forward = |msg: &Value| -> Result<Option<Value>, CliError> {
        if let Ok(info) = connection::read() {
            match client::Client::new(&info, timeout)?.post_mcp(msg) {
                Err(e) if e.code == 3 => {}
                other => return other,
            }
        }
        launch::connect(no_launch, timeout)?.client.post_mcp(msg)
    };
    let stdin = std::io::stdin();
    match stdio::run_bridge(stdin.lock(), std::io::stdout(), &mut forward) {
        Ok(()) => 0,
        Err(e) => {
            eprintln!("yusafcut mcp: {e}");
            1
        }
    }
}

/// Execute a parsed non-`mcp` command, returning captured output (testable).
pub fn execute(parsed: &Parsed, stdin: &mut dyn Read) -> Run {
    let g = &parsed.global;
    let (tool, result) = dispatch(parsed, stdin);
    emit(g, tool, result)
}

struct Done {
    outcome: Value,
    /// Replaces the human rendering of an ok outcome (not `--json`).
    text: Option<String>,
}

fn done(tool: &str, data: Value) -> Done {
    Done { outcome: output::ok_outcome(tool, data), text: None }
}

fn emit(g: &Global, tool: String, result: Result<Done, CliError>) -> Run {
    let (outcome, text) = match result {
        Ok(d) => (d.outcome, d.text),
        Err(e) => (output::err_outcome(&tool, &e), None),
    };
    let ok = outcome.get("ok") == Some(&Value::Bool(true));
    let code = if ok {
        0
    } else {
        match outcome["error"]["code"].as_str().unwrap_or("") {
            "STALE_REVISION" => 6,
            "APP_UNREACHABLE" => 3,
            "ACCESS_DENIED" => 4,
            "USAGE" => 2,
            _ => 5,
        }
    };
    if g.json {
        return Run { code, stdout: output::json_line(&outcome), stderr: String::new() };
    }
    if ok {
        if let Some(t) = text {
            return Run { code, stdout: t, stderr: String::new() };
        }
    }
    let (stdout, stderr) = output::human(&outcome);
    Run { code, stdout, stderr }
}

fn abs(p: &str) -> String {
    let path = Path::new(p);
    if path.is_absolute() {
        return p.to_string();
    }
    std::env::current_dir()
        .map(|d| d.join(path).to_string_lossy().into_owned())
        .unwrap_or_else(|_| p.to_string())
}

fn read_input(src: &InputSource, stdin: &mut dyn Read) -> Result<Value, CliError> {
    let text = match src {
        InputSource::None => String::new(),
        InputSource::Json(j) => j.clone(),
        InputSource::File(f) if f == "-" => {
            let mut s = String::new();
            stdin.read_to_string(&mut s).map_err(|e| CliError::usage(format!("cannot read stdin: {e}")))?;
            s
        }
        InputSource::File(f) => {
            std::fs::read_to_string(f).map_err(|e| CliError::usage(format!("cannot read {f}: {e}")))?
        }
    };
    args::parse_input(&text).map_err(CliError::usage)
}

fn dispatch(parsed: &Parsed, stdin: &mut dyn Read) -> (String, Result<Done, CliError>) {
    let g = &parsed.global;
    let timeout = Duration::from_secs(g.timeout_secs);
    let call = |name: &str, input: Value| -> Result<Done, CliError> {
        let c = launch::connect(g.no_launch, timeout)?;
        let outcome = c.client.call_tool(name, &input)?;
        Ok(Done { outcome, text: None })
    };
    match &parsed.command {
        Command::Help | Command::Mcp => ("help".into(), Ok(Done { outcome: output::ok_outcome("help", json!(args::USAGE)), text: Some(args::USAGE.into()) })),
        Command::Readme => ("readme".into(), Ok(Done { outcome: output::ok_outcome("readme", json!(README)), text: Some(README.into()) })),
        Command::Status => ("status".into(), (|| {
            let c = launch::try_connect(timeout)?;
            let h = c.client.health()?;
            Ok(Done {
                outcome: output::ok_outcome("status", json!({
                    "running": true, "port": c.info.port, "pid": h.pid, "version": h.version,
                    "editorReady": h.editor_ready, "binaryPath": c.info.binary_path,
                    "connectionFile": connection::connection_file().to_string_lossy(),
                })),
                text: Some(format!(
                    "WordsCut {} running on 127.0.0.1:{} (pid {}), editor {}",
                    h.version, c.info.port, h.pid, if h.editor_ready { "ready" } else { "not ready" }
                )),
            })
        })()),
        Command::ProjectInspect { path } => ("project_inspect".into(),
            inspect::inspect(Path::new(&abs(path))).map(|d| done("project_inspect", d))),
        Command::ProjectOpen { path, discard_unsaved } => ("project_open".into(),
            call("project_open", json!({"path": abs(path), "discardUnsaved": discard_unsaved}))),
        Command::ProjectInfo => ("project_info".into(), call("project_info", json!({}))),
        Command::ProjectSave { path } => ("project_save".into(), call("project_save",
            path.as_ref().map(|p| json!({"path": abs(p)})).unwrap_or(json!({})))),
        Command::ToolList => ("tool_list".into(), (|| {
            let c = launch::connect(g.no_launch, timeout)?;
            let tools = c.client.list_tools()?;
            let text = output::tool_table(&tools);
            Ok(Done { outcome: output::ok_outcome("tool_list", Value::Array(tools)), text: Some(text) })
        })()),
        Command::ToolDescribe { name } => ("tool_describe".into(), (|| {
            let c = launch::connect(g.no_launch, timeout)?;
            let tool = c.client.list_tools()?.into_iter().find(|t| t["name"] == name.as_str())
                .ok_or_else(|| CliError::tool("NOT_FOUND", format!("no tool named '{name}'")).with_hint("Run `agent tool list`."))?;
            let text = serde_json::to_string_pretty(&tool).unwrap_or_default();
            Ok(Done { outcome: output::ok_outcome("tool_describe", tool), text: Some(text) })
        })()),
        Command::ToolCall { name, input } => (name.clone(), read_input(input, stdin).and_then(|v| call(name, v))),
        Command::Skills { print, write } => ("skills".into(), skills(print.as_deref(), write.as_deref())),
        Command::Export { output, resolution, codec, confirm, overwrite } => ("export_start".into(), call("export_start", json!({
            "outputPath": abs(output), "resolution": resolution, "codec": codec,
            "confirm": confirm, "overwrite": overwrite,
        }))),
    }
}

fn skills(print: Option<&str>, write: Option<&str>) -> Result<Done, CliError> {
    let find = |n: &str| SKILLS.iter().find(|(name, _)| *name == n);
    let mut text = String::new();
    let mut data = json!({ "skills": SKILLS.iter().map(|(n, _)| n).collect::<Vec<_>>() });
    if let Some(n) = print {
        let (_, body) = find(n).ok_or_else(|| CliError::usage(format!("unknown skill '{n}'")))?;
        text.push_str(body);
    }
    if let Some(dir) = write {
        let mut written = vec![];
        for (name, body) in SKILLS {
            let d = Path::new(&abs(dir)).join(name);
            std::fs::create_dir_all(&d).map_err(|e| CliError::internal(format!("{}: {e}", d.display())))?;
            let f = d.join("SKILL.md");
            std::fs::write(&f, body).map_err(|e| CliError::internal(format!("{}: {e}", f.display())))?;
            text.push_str(&format!("wrote {}\n", f.display()));
            written.push(f.to_string_lossy().into_owned());
        }
        data["written"] = json!(written);
    }
    if print.is_none() && write.is_none() {
        for (name, body) in SKILLS {
            let desc = body.lines().find_map(|l| l.strip_prefix("description:")).unwrap_or("").trim();
            text.push_str(&format!("{name}  {desc}\n"));
        }
    }
    Ok(Done { outcome: output::ok_outcome("skills", data), text: Some(text) })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write as _;
    use std::net::TcpListener;
    use std::sync::{Arc, Mutex};

    /// Env var `YUSAFCUT_AGENT_DIR` is process-global; tests that set it serialise here.
    static ENV: Mutex<()> = Mutex::new(());

    type Log = Arc<Mutex<Vec<(String, String, String, String)>>>;

    /// Minimal in-process HTTP server. `handler(method, path, body) -> (status, body)`.
    fn fake(handler: impl Fn(&str, &str, &str) -> (u16, String) + Send + 'static) -> (u16, Log) {
        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        let port = listener.local_addr().unwrap().port();
        let log: Log = Arc::default();
        let log2 = log.clone();
        std::thread::spawn(move || {
            for stream in listener.incoming() {
                let Ok(mut s) = stream else { continue };
                let mut buf = Vec::new();
                let mut chunk = [0u8; 4096];
                let (head_end, content_len) = loop {
                    let n = s.read(&mut chunk).unwrap_or(0);
                    if n == 0 {
                        break (0, 0);
                    }
                    buf.extend_from_slice(&chunk[..n]);
                    if let Some(i) = buf.windows(4).position(|w| w == b"\r\n\r\n") {
                        let head = String::from_utf8_lossy(&buf[..i]).to_lowercase();
                        let cl = head
                            .lines()
                            .find_map(|l| l.strip_prefix("content-length:"))
                            .and_then(|v| v.trim().parse::<usize>().ok())
                            .unwrap_or(0);
                        break (i + 4, cl);
                    }
                };
                if head_end == 0 {
                    continue;
                }
                while buf.len() < head_end + content_len {
                    let n = s.read(&mut chunk).unwrap_or(0);
                    if n == 0 {
                        break;
                    }
                    buf.extend_from_slice(&chunk[..n]);
                }
                let head = String::from_utf8_lossy(&buf[..head_end]).into_owned();
                let body = String::from_utf8_lossy(&buf[head_end..]).into_owned();
                let mut first = head.lines().next().unwrap_or("").split(' ');
                let method = first.next().unwrap_or("").to_string();
                let path = first.next().unwrap_or("").to_string();
                let auth = head
                    .lines()
                    .find(|l| l.to_lowercase().starts_with("authorization:"))
                    .unwrap_or("")
                    .to_string();
                log2.lock().unwrap().push((method.clone(), path.clone(), body.clone(), auth));
                let (status, resp) = handler(&method, &path, &body);
                let _ = write!(
                    s,
                    "HTTP/1.1 {status} X\r\nContent-Type: application/json\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{resp}",
                    resp.len()
                );
            }
        });
        (port, log)
    }

    fn point_at(port: u16) -> std::path::PathBuf {
        let dir = std::env::temp_dir().join(format!("yc-cli-{}", uuid::Uuid::new_v4()));
        std::env::set_var("YUSAFCUT_AGENT_DIR", &dir);
        connection::write(&connection::ConnectionInfo {
            version: 1, port, token: "tok".into(), pid: 1, started_at: "n".into(),
            app_version: "0".into(), binary_path: "/b".into(),
            mcp_url: format!("http://127.0.0.1:{port}/mcp"),
        })
        .unwrap();
        dir
    }

    fn exec(line: &str) -> Run {
        let v: Vec<String> = line.split_whitespace().map(String::from).collect();
        let parsed = args::parse(&v).unwrap();
        execute(&parsed, &mut std::io::empty())
    }

    const HEALTH: &str = r#"{"ok":true,"app":"WordsCut","version":"9.9.9","editorReady":true,"pid":42}"#;

    #[test]
    fn happy_path_stale_and_auth() {
        let _g = ENV.lock().unwrap_or_else(|e| e.into_inner());
        let (port, log) = fake(|m, p, body| match (m, p) {
            ("GET", "/v1/health") => (200, HEALTH.into()),
            ("GET", "/v1/tools") => (200, r#"[{"name":"project_info","description":"Info.","mutates":false,"inputSchema":{}}]"#.into()),
            ("POST", "/v1/tools/call") => {
                let v: Value = serde_json::from_str(body).unwrap();
                if v["name"] == "stale" {
                    (200, r#"{"ok":false,"tool":"stale","error":{"code":"STALE_REVISION","message":"moved","hint":"re-read"}}"#.into())
                } else {
                    (200, json!({"ok":true,"tool":v["name"],"data":{"echo":v["input"]}}).to_string())
                }
            }
            _ => (404, "{}".into()),
        });
        let dir = point_at(port);

        let r = exec("agent status --json");
        assert_eq!(r.code, 0);
        assert_eq!(serde_json::from_str::<Value>(&r.stdout).unwrap()["data"]["version"], "9.9.9");
        assert!(!r.stdout.contains('\n'));

        let r = exec("agent tool call --name edit_cut_words --input-json {\"confirm\":false} --json");
        assert_eq!(r.code, 0);
        let v: Value = serde_json::from_str(&r.stdout).unwrap();
        assert_eq!(v["data"]["echo"]["confirm"], false);
        assert!(log.lock().unwrap().iter().all(|(_, _, _, a)| a.is_empty() || a.ends_with("Bearer tok")));

        let r = exec("agent tool call --name stale --json");
        assert_eq!(r.code, 6);
        let r = exec("agent tool call --name stale");
        assert_eq!(r.code, 6);
        assert!(r.stderr.contains("STALE_REVISION") && r.stderr.contains("hint: re-read"));

        let r = exec("agent tool list");
        assert_eq!(r.code, 0);
        assert!(r.stdout.starts_with("project_info  read  Info."));
        assert_eq!(exec("agent tool describe --name nope").code, 5);
        assert_eq!(exec("agent tool describe --name project_info --json").code, 0);

        let r = exec("agent project open --path /tmp/x.scribe --discard-unsaved --json");
        let v: Value = serde_json::from_str(&r.stdout).unwrap();
        assert_eq!(v["data"]["echo"], json!({"path":"/tmp/x.scribe","discardUnsaved":true}));

        let r = exec("agent export --output /tmp/o.mp4 --confirm --json");
        let v: Value = serde_json::from_str(&r.stdout).unwrap();
        assert_eq!(v["tool"], "export_start");
        assert_eq!(v["data"]["echo"]["resolution"], "1080p");
        assert_eq!(v["data"]["echo"]["confirm"], true);
        let _ = std::fs::remove_dir_all(dir);
    }

    #[test]
    fn unauthorized_is_exit_4_and_missing_connection_is_3() {
        let _g = ENV.lock().unwrap_or_else(|e| e.into_inner());
        let (port, _) = fake(|_, _, _| (401, r#"{"error":"no"}"#.into()));
        let dir = point_at(port);
        assert_eq!(exec("agent tool call --name project_info --no-launch").code, 4);
        assert_eq!(exec("agent status --json").code, 4);
        let _ = std::fs::remove_dir_all(&dir);

        std::env::set_var("YUSAFCUT_AGENT_DIR", &dir); // now empty
        let r = exec("agent status --json");
        assert_eq!(r.code, 3);
        assert_eq!(serde_json::from_str::<Value>(&r.stdout).unwrap()["ok"], false);
        // --no-launch must never launch; 3 normally, 4 if a real app is running here.
        assert!(matches!(exec("agent project info --no-launch").code, 3 | 4));
        assert_eq!(launch::try_connect(Duration::from_secs(1)).err().unwrap().code, 3);
    }

    #[test]
    fn editor_not_ready_503_maps_to_tool_error() {
        let _g = ENV.lock().unwrap_or_else(|e| e.into_inner());
        let (port, _) = fake(|_, p, _| if p == "/v1/health" { (200, HEALTH.into()) } else { (503, "not ready".into()) });
        let dir = point_at(port);
        let r = exec("agent tool call --name project_info --json");
        assert_eq!(r.code, 5);
        assert!(r.stdout.contains("EDITOR_NOT_READY"));
        let _ = std::fs::remove_dir_all(dir);
    }

    #[test]
    fn stdin_input_file() {
        let v: Vec<String> = "agent tool call --name t --input-file -".split_whitespace().map(String::from).collect();
        let parsed = args::parse(&v).unwrap();
        let Command::ToolCall { input, .. } = parsed.command else { panic!() };
        let got = read_input(&input, &mut "{\"a\":1}".as_bytes()).unwrap();
        assert_eq!(got, json!({"a":1}));
        assert!(read_input(&input, &mut "{".as_bytes()).is_err());
    }

    #[test]
    fn readme_and_skills_are_embedded() {
        let r = exec("agent readme");
        assert_eq!(r.code, 0);
        assert!(r.stdout.contains("confirm"));
        let r = exec("agent skills --print yusafcut");
        assert!(r.stdout.starts_with("---\nname: yusafcut"));
        assert_eq!(exec("agent skills --print nope").code, 2);
        let dir = std::env::temp_dir().join(format!("yc-skill-{}", uuid::Uuid::new_v4()));
        let r = execute(
            &args::parse(&["agent".into(), "skills".into(), "--write".into(), dir.to_string_lossy().into()]).unwrap(),
            &mut std::io::empty(),
        );
        assert_eq!(r.code, 0);
        assert!(dir.join("yusafcut/SKILL.md").exists());
        let _ = std::fs::remove_dir_all(dir);
    }

    #[test]
    fn mcp_forwarder_posts_to_app() {
        let _g = ENV.lock().unwrap_or_else(|e| e.into_inner());
        let (port, _) = fake(|m, p, body| {
            assert_eq!((m, p), ("POST", "/mcp"));
            let v: Value = serde_json::from_str(body).unwrap();
            (200, json!({"jsonrpc":"2.0","id":v["id"],"result":{"tools":[]}}).to_string())
        });
        let dir = point_at(port);
        let info = connection::read().unwrap();
        let c = client::Client::new(&info, Duration::from_secs(5)).unwrap();
        let mut fwd = |m: &Value| c.post_mcp(m);
        let line = r#"{"jsonrpc":"2.0","id":5,"method":"tools/list"}"#;
        let reply = stdio::handle_line(line, &mut fwd).unwrap();
        assert_eq!(reply["id"], 5);
        assert_eq!(reply["result"]["tools"], json!([]));
        let _ = std::fs::remove_dir_all(dir);
    }
}
