//! `project inspect`: headless, read-only look at a `.scribe` on disk.

use super::CliError;
use serde_json::{json, Value};
use std::path::Path;

pub fn inspect(path: &Path) -> Result<Value, CliError> {
    let rt = tokio::runtime::Builder::new_current_thread()
        .enable_all()
        .build()
        .map_err(|e| CliError::internal(format!("runtime: {e}")))?;
    let project = rt
        .block_on(yusafcut_lib::project::load(path))
        .map_err(|e| CliError::tool("PROJECT_LOAD_FAILED", format!("{e:#}")))?;

    let mut media: Vec<_> = project.media.values().collect();
    media.sort_by(|a, b| a.id.cmp(&b.id));
    let media_json: Vec<Value> = media
        .iter()
        .map(|m| {
            json!({
                "id": m.id, "path": m.path, "durationSec": m.duration,
                "width": m.width, "height": m.height, "fps": m.fps,
                "exists": Path::new(&m.path).exists(),
            })
        })
        .collect();

    let words: Vec<&yusafcut_lib::edl::Word> =
        project.segments.iter().flat_map(|s| s.words.iter()).collect();
    let duration: f64 = project.output_duration();
    let preview: Vec<&str> = words.iter().take(60).map(|w| w.text.trim()).collect();
    let zoom_count = project
        .zoom_regions
        .as_ref()
        .and_then(Value::as_array)
        .map(Vec::len)
        .unwrap_or(0);

    Ok(json!({
        "name": project.name,
        "id": project.id,
        "version": project.version,
        "updatedAt": project.updated_at,
        "media": media_json,
        "segmentCount": project.segments.len(),
        "wordCount": words.len(),
        "durationSec": duration,
        "chapters": project.chapters.iter().map(|c| json!({"id": c.id, "time": c.output_time, "title": c.title})).collect::<Vec<_>>(),
        "zoomRegionCount": zoom_count,
        "paddingMs": project.settings.padding_ms,
        "transcriptPreview": preview.join(" "),
        "note": "Read from disk; the running editor may hold unsaved changes. Use project_info for live state.",
    }))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn inspects_a_temp_scribe() {
        let dir = std::env::temp_dir().join(format!("yc-inspect-{}.scribe", uuid::Uuid::new_v4()));
        std::fs::create_dir_all(&dir).unwrap();
        let project = json!({
            "version":1,"id":"p1","name":"Demo","createdAt":"x","updatedAt":"y",
            "media":{"m1":{"id":"m1","path":"/nope.mp4","duration":10.0,"fps":30.0,"width":1920,"height":1080,"audioSampleRate":48000,"sha256":"s"}},
            "segments":[{"id":"s1","mediaId":"m1","sourceIn":0.0,"sourceOut":2.0,"words":[
                {"id":"w1","text":"hello","start":0.0,"end":0.5,"confidence":1.0},
                {"id":"w2","text":"world","start":0.5,"end":1.0,"confidence":1.0}]}],
            "settings":{"exportPreset":"youtube-1080p","paddingMs":80},
            "chapters":[{"id":"c1","outputTime":0.0,"title":"Intro"}]
        });
        std::fs::write(dir.join("project.json"), project.to_string()).unwrap();
        let before = std::fs::read(dir.join("project.json")).unwrap();
        let v = inspect(&dir).unwrap();
        assert_eq!(v["name"], "Demo");
        assert_eq!(v["wordCount"], 2);
        assert_eq!(v["durationSec"], 2.0);
        assert_eq!(v["transcriptPreview"], "hello world");
        assert_eq!(v["media"][0]["exists"], false);
        assert_eq!(std::fs::read(dir.join("project.json")).unwrap(), before);
        assert!(inspect(&dir.join("missing")).is_err());
        let _ = std::fs::remove_dir_all(&dir);
    }
}
