//! Hand-rolled argument parser for `WordsCut agent …` / `WordsCut mcp`.

use serde_json::Value;

#[derive(Debug, Clone, PartialEq)]
pub enum InputSource {
    None,
    Json(String),
    /// A path, or `-` for stdin.
    File(String),
}

#[derive(Debug, Clone, PartialEq)]
pub enum Command {
    Help,
    Readme,
    Status,
    ProjectOpen { path: String, discard_unsaved: bool },
    ProjectInfo,
    ProjectSave { path: Option<String> },
    ProjectInspect { path: String },
    ToolList,
    ToolDescribe { name: String },
    ToolCall { name: String, input: InputSource },
    Skills { print: Option<String>, write: Option<String> },
    Export { output: String, resolution: String, codec: String, confirm: bool, overwrite: bool },
    Mcp,
}

#[derive(Debug, Clone, PartialEq)]
pub struct Global {
    pub json: bool,
    pub no_launch: bool,
    pub timeout_secs: u64,
}

impl Default for Global {
    fn default() -> Self {
        Global { json: false, no_launch: false, timeout_secs: 60 }
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct Parsed {
    pub global: Global,
    pub command: Command,
}

pub const USAGE: &str = "\
Usage:
  WordsCut agent readme
  WordsCut agent status [--json]
  WordsCut agent project open --path <dir.scribe> [--discard-unsaved] [--json]
  WordsCut agent project info [--json]
  WordsCut agent project save [--path <p>] [--json]
  WordsCut agent project inspect --path <p> [--json]
  WordsCut agent tool list [--json]
  WordsCut agent tool describe --name <tool> [--json]
  WordsCut agent tool call --name <tool> (--input-json '<json>' | --input-file <file|->) [--json]
  WordsCut agent skills [--print <name>] [--write <dir>]
  WordsCut agent export --output <p> [--resolution 1080p] [--codec auto] [--confirm] [--overwrite] [--json]
  WordsCut mcp

Global flags: --no-launch  --timeout <sec>  --json
Exit codes: 0 ok, 2 usage, 3 app not running, 4 unauthorized / access disabled, 5 tool error, 6 STALE_REVISION";

/// Parse the arguments *including* the leading `agent` / `mcp` word.
pub fn parse(args: &[String]) -> Result<Parsed, String> {
    let mut global = Global::default();
    let mut positionals: Vec<String> = Vec::new();
    let mut flags: Vec<(String, Option<String>)> = Vec::new();

    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        i += 1;
        if a == "-" || !a.starts_with("--") {
            positionals.push(a.clone());
            continue;
        }
        let (name, inline) = match a.split_once('=') {
            Some((n, v)) => (n.to_string(), Some(v.to_string())),
            None => (a.clone(), None),
        };
        match name.as_str() {
            "--json" => global.json = true,
            "--no-launch" => global.no_launch = true,
            "--timeout" => {
                let v = take_value(&name, inline, args, &mut i)?;
                global.timeout_secs = v
                    .parse::<u64>()
                    .ok()
                    .filter(|n| *n > 0)
                    .ok_or_else(|| format!("--timeout needs a positive number of seconds, got '{v}'"))?;
            }
            "--help" | "-h" => return Ok(Parsed { global, command: Command::Help }),
            "--path" | "--name" | "--input-json" | "--input-file" | "--print" | "--write"
            | "--output" | "--resolution" | "--codec" => {
                let v = take_value(&name, inline, args, &mut i)?;
                flags.push((name, Some(v)));
            }
            "--discard-unsaved" | "--confirm" | "--overwrite" => flags.push((name, None)),
            other => return Err(format!("unknown flag '{other}'")),
        }
    }

    let mut pos = positionals.iter().map(String::as_str);
    let root = pos.next().ok_or("missing command")?;
    let rest: Vec<&str> = pos.collect();

    let command = match (root, rest.as_slice()) {
        ("mcp", []) => Command::Mcp,
        ("agent", []) => Command::Help,
        ("agent", ["help"]) => Command::Help,
        ("agent", ["readme"]) => Command::Readme,
        ("agent", ["status"]) => Command::Status,
        ("agent", ["project", "open"]) => Command::ProjectOpen {
            path: require(&flags, "--path")?,
            discard_unsaved: has(&flags, "--discard-unsaved"),
        },
        ("agent", ["project", "info"]) => Command::ProjectInfo,
        ("agent", ["project", "save"]) => Command::ProjectSave { path: get(&flags, "--path") },
        ("agent", ["project", "inspect"]) => {
            Command::ProjectInspect { path: require(&flags, "--path")? }
        }
        ("agent", ["tool", "list"]) => Command::ToolList,
        ("agent", ["tool", "describe"]) => {
            Command::ToolDescribe { name: require(&flags, "--name")? }
        }
        ("agent", ["tool", "call"]) => {
            let json = get(&flags, "--input-json");
            let file = get(&flags, "--input-file");
            let input = match (json, file) {
                (Some(_), Some(_)) => {
                    return Err("use only one of --input-json and --input-file".into())
                }
                (Some(j), None) => InputSource::Json(j),
                (None, Some(f)) => InputSource::File(f),
                (None, None) => InputSource::None,
            };
            Command::ToolCall { name: require(&flags, "--name")?, input }
        }
        ("agent", ["skills"]) => {
            Command::Skills { print: get(&flags, "--print"), write: get(&flags, "--write") }
        }
        ("agent", ["export"]) => Command::Export {
            output: require(&flags, "--output")?,
            resolution: get(&flags, "--resolution").unwrap_or_else(|| "1080p".into()),
            codec: get(&flags, "--codec").unwrap_or_else(|| "auto".into()),
            confirm: has(&flags, "--confirm"),
            overwrite: has(&flags, "--overwrite"),
        },
        (_, rest) => {
            let shown: Vec<&str> = std::iter::once(root).chain(rest.iter().copied()).collect();
            return Err(format!("unknown command '{}'", shown.join(" ")));
        }
    };

    // Reject flags that the chosen command ignores, so typos do not pass silently.
    let allowed: &[&str] = match &command {
        Command::ProjectOpen { .. } => &["--path", "--discard-unsaved"],
        Command::ProjectSave { .. } | Command::ProjectInspect { .. } => &["--path"],
        Command::ToolDescribe { .. } => &["--name"],
        Command::ToolCall { .. } => &["--name", "--input-json", "--input-file"],
        Command::Skills { .. } => &["--print", "--write"],
        Command::Export { .. } => {
            &["--output", "--resolution", "--codec", "--confirm", "--overwrite"]
        }
        _ => &[],
    };
    if let Some((bad, _)) = flags.iter().find(|(n, _)| !allowed.contains(&n.as_str())) {
        return Err(format!("flag '{bad}' is not valid for this command"));
    }

    Ok(Parsed { global, command })
}

fn take_value(
    name: &str,
    inline: Option<String>,
    args: &[String],
    i: &mut usize,
) -> Result<String, String> {
    if let Some(v) = inline {
        return Ok(v);
    }
    match args.get(*i) {
        Some(v) if !(v.starts_with("--") && v.len() > 2) => {
            *i += 1;
            Ok(v.clone())
        }
        _ => Err(format!("{name} needs a value")),
    }
}

fn get(flags: &[(String, Option<String>)], name: &str) -> Option<String> {
    flags.iter().rev().find(|(n, _)| n == name).and_then(|(_, v)| v.clone())
}

fn has(flags: &[(String, Option<String>)], name: &str) -> bool {
    flags.iter().any(|(n, _)| n == name)
}

fn require(flags: &[(String, Option<String>)], name: &str) -> Result<String, String> {
    get(flags, name).ok_or_else(|| format!("missing required flag {name}"))
}

/// Parse a `--input-json` / file payload into a JSON object (default `{}`).
pub fn parse_input(text: &str) -> Result<Value, String> {
    if text.trim().is_empty() {
        return Ok(Value::Object(Default::default()));
    }
    serde_json::from_str(text).map_err(|e| format!("input is not valid JSON: {e}"))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn p(s: &str) -> Result<Parsed, String> {
        let v: Vec<String> = shell_split(s);
        parse(&v)
    }

    fn shell_split(s: &str) -> Vec<String> {
        // Tiny splitter honouring single quotes, enough for the tests.
        let mut out = vec![];
        let mut cur = String::new();
        let mut q = false;
        let mut any = false;
        for c in s.chars() {
            match c {
                '\'' => {
                    q = !q;
                    any = true;
                }
                ' ' if !q => {
                    if any || !cur.is_empty() {
                        out.push(std::mem::take(&mut cur));
                        any = false;
                    }
                }
                _ => cur.push(c),
            }
        }
        if any || !cur.is_empty() {
            out.push(cur);
        }
        out
    }

    #[test]
    fn parses_every_documented_form() {
        assert_eq!(p("agent readme").unwrap().command, Command::Readme);
        assert!(p("agent status --json").unwrap().global.json);
        assert_eq!(
            p("agent project open --path /a/b.scribe --discard-unsaved").unwrap().command,
            Command::ProjectOpen { path: "/a/b.scribe".into(), discard_unsaved: true }
        );
        assert_eq!(p("agent project info").unwrap().command, Command::ProjectInfo);
        assert_eq!(
            p("agent project save").unwrap().command,
            Command::ProjectSave { path: None }
        );
        assert_eq!(
            p("agent project save --path=/x.scribe").unwrap().command,
            Command::ProjectSave { path: Some("/x.scribe".into()) }
        );
        assert_eq!(
            p("agent project inspect --path /x.scribe").unwrap().command,
            Command::ProjectInspect { path: "/x.scribe".into() }
        );
        assert_eq!(p("agent tool list").unwrap().command, Command::ToolList);
        assert_eq!(
            p("agent tool describe --name edit_cut_words").unwrap().command,
            Command::ToolDescribe { name: "edit_cut_words".into() }
        );
        assert_eq!(
            p("agent tool call --name t --input-json '{\"a\": 1}' --json --timeout 5")
                .unwrap(),
            Parsed {
                global: Global { json: true, no_launch: false, timeout_secs: 5 },
                command: Command::ToolCall {
                    name: "t".into(),
                    input: InputSource::Json("{\"a\": 1}".into())
                }
            }
        );
        assert_eq!(
            p("agent tool call --name t --input-file -").unwrap().command,
            Command::ToolCall { name: "t".into(), input: InputSource::File("-".into()) }
        );
        assert_eq!(
            p("agent skills --print yusafcut --write /d").unwrap().command,
            Command::Skills { print: Some("yusafcut".into()), write: Some("/d".into()) }
        );
        assert_eq!(
            p("--no-launch agent export --output /o.mp4 --resolution 720p --confirm").unwrap(),
            Parsed {
                global: Global { json: false, no_launch: true, timeout_secs: 60 },
                command: Command::Export {
                    output: "/o.mp4".into(),
                    resolution: "720p".into(),
                    codec: "auto".into(),
                    confirm: true,
                    overwrite: false
                }
            }
        );
        assert_eq!(p("mcp").unwrap().command, Command::Mcp);
    }

    #[test]
    fn rejects_bad_usage() {
        assert!(p("agent bogus").is_err());
        assert!(p("agent status --wat").is_err());
        assert!(p("agent project open").is_err());
        assert!(p("agent tool call --name t --input-json {} --input-file x").is_err());
        assert!(p("agent tool call --name").is_err());
        assert!(p("agent status --path /x").is_err());
        assert!(p("agent status --timeout 0").is_err());
        assert!(p("mcp extra").is_err());
    }

    #[test]
    fn input_parsing() {
        assert_eq!(parse_input("").unwrap(), serde_json::json!({}));
        assert!(parse_input("{").is_err());
    }
}
