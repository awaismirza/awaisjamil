//! Finding (and, if allowed, launching) the running app.

use super::client::Client;
use super::CliError;
use std::path::{Path, PathBuf};
use std::time::{Duration, Instant};
use yusafcut_lib::agent::connection::{self, ConnectionInfo};

const ENABLE_HINT: &str = "Enable it in WordsCut -> Agent (CLI/MCP).";
pub const LAUNCH_WAIT: Duration = Duration::from_secs(30);

pub struct Connected {
    pub info: ConnectionInfo,
    pub client: Client,
}

/// Connect to a running app without ever launching it.
pub fn try_connect(call_timeout: Duration) -> Result<Connected, CliError> {
    let info = connection::read().map_err(|_| CliError::unreachable("WordsCut is not running (no connection file)."))?;
    let client = Client::new(&info, call_timeout)?;
    client.health()?;
    Ok(Connected { info, client })
}

/// Connect, launching the app first when allowed and needed.
pub fn connect(no_launch: bool, call_timeout: Duration) -> Result<Connected, CliError> {
    connect_with(no_launch, call_timeout, LAUNCH_WAIT)
}

pub fn connect_with(no_launch: bool, call_timeout: Duration, wait: Duration) -> Result<Connected, CliError> {
    match try_connect(call_timeout) {
        Ok(c) => return Ok(c),
        Err(e) if e.code == 4 => return Err(e),
        Err(_) => {}
    }
    let already_running = app_process_running();
    if no_launch {
        return Err(not_running(already_running));
    }
    let poll_for = if already_running {
        Duration::from_secs(3).min(wait)
    } else {
        match launch_app() {
            Ok(()) => wait,
            Err(e) => return Err(e),
        }
    };
    let deadline = Instant::now() + poll_for;
    let mut last: Option<Connected> = None;
    while Instant::now() < deadline {
        match try_connect(call_timeout) {
            Ok(c) => {
                let ready = c.client.health().map(|h| h.editor_ready).unwrap_or(false);
                if ready {
                    return Ok(c);
                }
                last = Some(c);
            }
            Err(e) if e.code == 4 => return Err(e),
            Err(_) => {}
        }
        std::thread::sleep(Duration::from_millis(250));
    }
    if let Some(c) = last {
        return Ok(c); // reachable but editor still booting; the call reports EDITOR_NOT_READY
    }
    Err(not_running(app_process_running()))
}

fn not_running(process_alive: bool) -> CliError {
    if process_alive {
        CliError::access(format!("WordsCut is running but agent access is off. {ENABLE_HINT}"))
    } else {
        CliError::unreachable("WordsCut is not running. Start it, or drop --no-launch to let the CLI launch it.")
    }
}

/// `<x>.app` that contains the current executable, if any.
pub fn bundle_path(exe: &Path) -> Option<PathBuf> {
    exe.ancestors()
        .find(|p| p.extension().map(|e| e == "app").unwrap_or(false))
        .map(Path::to_path_buf)
}

fn launch_app() -> Result<(), CliError> {
    let exe = std::env::current_exe().map_err(|e| CliError::internal(format!("cannot locate executable: {e}")))?;
    let Some(bundle) = bundle_path(&exe) else {
        return Err(CliError::unreachable(
            "WordsCut is not running and this binary is not inside an .app bundle (dev build). Start it with `npm run tauri:dev`, then retry.",
        ));
    };
    let status = std::process::Command::new("open")
        .arg("-a")
        .arg(&bundle)
        .status()
        .map_err(|e| CliError::unreachable(format!("cannot run `open`: {e}")))?;
    if status.success() {
        Ok(())
    } else {
        Err(CliError::unreachable(format!("`open -a {}` failed", bundle.display())))
    }
}

/// True if a GUI instance of the app is alive (CLI/bridge invocations excluded).
fn app_process_running() -> bool {
    let out = match std::process::Command::new("ps").args(["-axo", "pid=,command="]).output() {
        Ok(o) => String::from_utf8_lossy(&o.stdout).into_owned(),
        Err(_) => return false,
    };
    out.lines().any(|l| is_gui_instance(l, std::process::id()))
}

pub fn is_gui_instance(ps_line: &str, my_pid: u32) -> bool {
    let line = ps_line.trim();
    let Some((pid, cmd)) = line.split_once(char::is_whitespace) else { return false };
    if pid.parse::<u32>().ok() == Some(my_pid) {
        return false;
    }
    let cmd = cmd.trim();
    // The executable path may contain spaces ("Application Support"), so match on the
    // `/Contents/MacOS/` marker or a trailing binary name instead of splitting.
    let (exe, args) = match cmd.find("/Contents/MacOS/") {
        Some(i) => {
            let rest = &cmd[i + "/Contents/MacOS/".len()..];
            let (name, args) = rest.split_once(' ').unwrap_or((rest, ""));
            (name, args)
        }
        None => return false,
    };
    (exe.eq_ignore_ascii_case("WordsCut") || exe.eq_ignore_ascii_case("yusafcut")) && !matches!(args.split_whitespace().next(), Some("agent") | Some("mcp"))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn bundle_detection() {
        assert_eq!(
            bundle_path(Path::new("/Applications/WordsCut.app/Contents/MacOS/WordsCut")),
            Some(PathBuf::from("/Applications/WordsCut.app"))
        );
        assert_eq!(bundle_path(Path::new("/repo/src-tauri/target/debug/yusafcut")), None);
    }

    #[test]
    fn gui_instance_filter() {
        let gui = "123 /Applications/WordsCut.app/Contents/MacOS/WordsCut";
        let cli = "124 /Applications/WordsCut.app/Contents/MacOS/WordsCut agent status";
        let mcp = "125 /Applications/WordsCut.app/Contents/MacOS/WordsCut mcp";
        let other = "126 /usr/bin/vim";
        assert!(is_gui_instance(gui, 1));
        assert!(is_gui_instance("127 /Applications/YusafCut.app/Contents/MacOS/YusafCut", 1));
        assert!(!is_gui_instance("128 /Applications/YusafCut.app/Contents/MacOS/YusafCut mcp", 1));
        assert!(!is_gui_instance(gui, 123));
        assert!(!is_gui_instance(cli, 1));
        assert!(!is_gui_instance(mcp, 1));
        assert!(!is_gui_instance(other, 1));
    }
}
