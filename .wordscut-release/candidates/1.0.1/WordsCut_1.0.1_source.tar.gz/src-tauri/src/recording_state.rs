//! Recorder process progress and shared session ownership.

use crate::native_capture::{HelperClient, NativeDevices};
use crate::recorder::RecordOptions;
use crate::recording_session::SessionAuthority;
use std::path::PathBuf;
use std::sync::Arc;
use tauri_plugin_shell::process::CommandChild;
use tokio::sync::{watch, Mutex};

#[derive(Default)]
pub struct RecordingState {
    /// Serializes transitions through finalization, even after the session is taken.
    pub actions: Mutex<()>,
    pub session: Arc<Mutex<Option<ActiveSession>>>,
    /// The native capture helper's session. At most one of the two is active.
    pub native: Arc<Mutex<Option<NativeSession>>>,
    /// Last device listing from the native helper — `start_recording` resolves
    /// the indices the frontend echoes back against it.
    pub native_devices: Mutex<Option<NativeDevices>>,
    /// The public, authoritative session (phase, elapsed, markers, id). Clients
    /// read snapshots of this; the two slots above only hold process handles.
    pub authority: Arc<SessionAuthority>,
    /// Finished takes the editor has not imported yet (see `ack_recording_result`).
    pub finished: std::sync::Mutex<Vec<crate::commands::record::RecordingResult>>,
}

/// One take recorded by the native helper: a single set of aligned track files
/// (pause/resume happen inside the helper, so there are no segments to join).
pub struct NativeSession {
    pub id: uuid::Uuid,
    pub client: Arc<HelperClient>,
    pub opts: RecordOptions,
    /// Session directory under `<app-data>/recordings/`.
    pub dir: PathBuf,
    /// Where the helper writes screen / camera / audio tracks and events.jsonl.
    pub tracks_dir: PathBuf,
    pub accumulated_secs: f64,
    pub paused: bool,
    /// The helper died mid-take; the files on disk are what is left.
    pub crashed: bool,
    pub stopping: bool,
}

impl NativeSession {
    pub fn elapsed_secs(&self) -> f64 {
        self.accumulated_secs
    }
    pub fn is_paused(&self) -> bool {
        self.paused
    }
    pub fn freeze(&mut self) {
        self.paused = true;
    }
    pub fn observe_elapsed(&mut self, value: &serde_json::Value) {
        if let Some(elapsed) = value["elapsed"]
            .as_f64()
            .filter(|n| n.is_finite() && *n >= 0.)
        {
            self.accumulated_secs = self.accumulated_secs.max(elapsed);
        }
    }
}

#[derive(Clone, Debug, Default)]
pub struct CaptureStatus {
    pub encoded_secs: f64,
    pub ended: Option<Result<(), String>>,
}

impl CaptureStatus {
    /// FFmpeg's machine-readable progress is media time, not process uptime.
    pub fn observe_progress(&mut self, line: &str) {
        if let Some(us) = line.trim().strip_prefix("out_time_us=") {
            if let Ok(us) = us.parse::<u64>() {
                self.encoded_secs = self.encoded_secs.max(us as f64 / 1_000_000.0);
            }
        }
    }
}

pub struct CaptureProcess {
    pub child: Option<CommandChild>,
    pub status: watch::Receiver<CaptureStatus>,
}

impl CaptureProcess {
    pub fn encoded_secs(&self) -> f64 {
        self.status.borrow().encoded_secs
    }

    pub async fn wait_ready(&mut self) -> Result<(), String> {
        loop {
            let status = self.status.borrow().clone();
            if let Some(result) = status.ended {
                return result.and(Err("capture ended before recording was ready".into()));
            }
            if status.encoded_secs > 0.0 {
                return Ok(());
            }
            self.status
                .changed()
                .await
                .map_err(|_| "capture progress disconnected")?;
        }
    }

    pub async fn wait_ended(&mut self) -> Result<(), String> {
        loop {
            if let Some(result) = self.status.borrow().ended.clone() {
                return result;
            }
            self.status
                .changed()
                .await
                .map_err(|_| "capture completion disconnected")?;
        }
    }
}

pub struct ActiveSession {
    /// Prevent an older session's ticker from publishing into a later take.
    pub id: uuid::Uuid,
    pub opts: RecordOptions,
    pub dir: PathBuf,
    pub segments: Vec<PathBuf>,
    pub child: Option<CaptureProcess>,
    /// Probed durations of finalized segments, never process wall time.
    pub accumulated_secs: f64,
}

impl ActiveSession {
    pub fn elapsed_secs(&self) -> f64 {
        self.accumulated_secs
            + self
                .child
                .as_ref()
                .map_or(0.0, CaptureProcess::encoded_secs)
    }

    pub fn is_paused(&self) -> bool {
        self.child.is_none()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn media_clock_ignores_startup_invalid_and_backward_progress() {
        let mut status = CaptureStatus::default();
        for line in [
            "out_time_us=N/A",
            "out_time_us=-20000",
            "out_time_us=NaN",
            "frame=30",
        ] {
            status.observe_progress(line);
        }
        assert_eq!(status.encoded_secs, 0.0);
        status.observe_progress("out_time_us=1250000");
        status.observe_progress("out_time_us=1000000");
        assert_eq!(status.encoded_secs, 1.25);
    }

    #[tokio::test]
    async fn ready_waits_for_media_and_completion_waits_for_actual_exit() {
        let (tx, rx) = watch::channel(CaptureStatus::default());
        let mut process = CaptureProcess {
            child: None,
            status: rx,
        };
        let task = tokio::spawn(async move {
            process.wait_ready().await.unwrap();
            process.wait_ended().await
        });
        tokio::task::yield_now().await;
        assert!(!task.is_finished());
        tx.send_modify(|s| s.encoded_secs = 0.5);
        tokio::task::yield_now().await;
        // Output and a stable-size file are not evidence of process termination.
        assert!(!task.is_finished());
        tx.send_modify(|s| s.ended = Some(Ok(())));
        assert!(task.await.unwrap().is_ok());
    }

    #[tokio::test]
    async fn failed_startup_is_reported_without_starting_the_clock() {
        let (tx, rx) = watch::channel(CaptureStatus::default());
        let mut process = CaptureProcess {
            child: None,
            status: rx,
        };
        tx.send_modify(|s| s.ended = Some(Err("microphone disconnected".into())));
        assert_eq!(
            process.wait_ready().await.unwrap_err(),
            "microphone disconnected"
        );
    }
}
