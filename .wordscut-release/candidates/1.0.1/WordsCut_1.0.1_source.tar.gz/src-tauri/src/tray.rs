//! Menu-bar (tray) item: shows the recording state and offers the recorder
//! controls while WordsCut's own window is minimised out of the capture.
//!
//! The frontend owns the logic. `trayModel` (TypeScript) decides the title,
//! tooltip and which rows are enabled; `update_tray` just applies it. A click
//! on a row is sent back as the `tray:action` event, carrying the row id.

use serde::Deserialize;
use std::collections::HashMap;
use std::sync::Mutex;
use tauri::menu::{Menu, MenuItem, PredefinedMenuItem};
use tauri::tray::TrayIconBuilder;
use tauri::{AppHandle, Emitter, Manager, Wry};

const TRAY_ID: &str = "yusafcut-tray";

/// Ids of the rows the frontend controls, in menu order.
const CONTROL_ROWS: [(&str, &str); 6] = [
    ("record", "Start Recording"),
    ("pause", "Pause Recording"),
    ("rerecord", "Restart Take"),
    ("mark", "Mark a Moment"),
    ("cancel", "Discard Recording"),
    ("controller", "Hide Recording Controls"),
];

/// Handles to the menu rows, so `update_tray` can relabel and enable them.
#[derive(Default)]
pub struct TrayRows(Mutex<HashMap<String, MenuItem<Wry>>>);

#[derive(Debug, Deserialize)]
pub struct TrayItemState {
    pub id: String,
    pub label: String,
    pub enabled: bool,
}

#[derive(Debug, Deserialize)]
pub struct TrayModel {
    pub title: Option<String>,
    pub tooltip: String,
    pub items: Vec<TrayItemState>,
}

/// Build the menu-bar item. Called once from `setup`.
pub fn build(app: &AppHandle) -> tauri::Result<()> {
    let mut rows = HashMap::new();
    let mut items: Vec<MenuItem<Wry>> = Vec::new();
    for (id, label) in CONTROL_ROWS {
        // Only "record" is usable before a session starts.
        let item = MenuItem::with_id(app, id, label, id == "record", None::<&str>)?;
        rows.insert(id.to_string(), item.clone());
        items.push(item);
    }
    let show = MenuItem::with_id(app, "show", "Show WordsCut", true, None::<&str>)?;
    let quit = PredefinedMenuItem::quit(app, Some("Quit WordsCut"))?;
    let sep_a = PredefinedMenuItem::separator(app)?;
    let sep_b = PredefinedMenuItem::separator(app)?;

    let menu = Menu::with_items(
        app,
        &[
            &items[0],
            &sep_a,
            &items[1],
            &items[2],
            &items[3],
            &items[4],
            &sep_b,
            &items[5],
            &show,
            &quit,
        ],
    )?;

    let mut builder = TrayIconBuilder::with_id(TRAY_ID)
        .menu(&menu)
        .show_menu_on_left_click(true)
        .tooltip("WordsCut")
        .on_menu_event(|app, event| {
            let _ = app.emit("tray:action", event.id().as_ref());
        });
    if let Some(icon) = app.default_window_icon() {
        builder = builder.icon(icon.clone());
    }
    builder.build(app)?;

    *app.state::<TrayRows>().0.lock().unwrap() = rows;
    Ok(())
}

/// Apply a model computed by the frontend to the live menu-bar item.
#[tauri::command]
pub fn update_tray(app: AppHandle, model: TrayModel) -> Result<(), String> {
    let tray = app
        .tray_by_id(TRAY_ID)
        .ok_or_else(|| "menu-bar item is not available".to_string())?;
    tray.set_title(model.title.as_deref()).map_err(|e| e.to_string())?;
    tray.set_tooltip(Some(model.tooltip.as_str())).map_err(|e| e.to_string())?;

    let rows = app.state::<TrayRows>();
    let rows = rows.0.lock().map_err(|e| e.to_string())?;
    for item in &model.items {
        if let Some(row) = rows.get(&item.id) {
            row.set_text(&item.label).map_err(|e| e.to_string())?;
            row.set_enabled(item.enabled).map_err(|e| e.to_string())?;
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn model_deserialises_from_the_frontend_shape() {
        let json = r#"{
            "title": "● 01:23",
            "tooltip": "Recording 01:23",
            "items": [{"id": "record", "label": "Stop", "enabled": true}]
        }"#;
        let m: TrayModel = serde_json::from_str(json).unwrap();
        assert_eq!(m.title.as_deref(), Some("● 01:23"));
        assert_eq!(m.items[0].id, "record");
        assert!(m.items[0].enabled);
    }

    #[test]
    fn a_null_title_means_icon_only() {
        let json = r#"{"title": null, "tooltip": "WordsCut", "items": []}"#;
        let m: TrayModel = serde_json::from_str(json).unwrap();
        assert!(m.title.is_none());
    }

    #[test]
    fn control_rows_match_the_frontend_ids() {
        let ids: Vec<&str> = CONTROL_ROWS.iter().map(|(id, _)| *id).collect();
        assert_eq!(ids, ["record", "pause", "rerecord", "mark", "cancel", "controller"]);
    }
}
