//! WordsCut backend — Tauri-side glue and command handlers.
//!
//! Everything that talks to whisper.cpp, ffmpeg, or the filesystem lives in
//! this crate. The frontend communicates via Tauri commands in `commands::*`.
//!
//! AI / MLX features (detect_chapters, suggest_broll) were removed in v3.4.0
//! to eliminate the Python/MLX sidecar dependency. Restore from commit
//! 074d1d3 if needed.

pub mod agent;
pub mod commands;
pub mod controller;
pub mod captions_export;
pub mod annotations_export;
pub mod cursor_export;
pub mod edl;
pub mod engine_bridge;
pub mod export_state;
pub mod jobs;
pub mod layers_export;
pub mod media;
pub mod project;
pub mod waveform;
pub mod perf_spans;
pub mod preview_cache;
pub mod native_capture;
pub mod recorder;
pub mod recorder_bar;
pub mod recording_session;
pub mod recording_state;
pub mod retime;
pub mod scene;
pub mod smart_cut;
pub mod snapshots;
pub mod transcribe;
pub mod zoom;
pub mod tray;

/// Shared application state passed into every Tauri command.
#[derive(Default)]
pub struct AppState {
    pub export: export_state::ExportState,
    pub recording: recording_state::RecordingState,
    pub jobs: jobs::JobQueue,
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    env_logger::Builder::from_env(env_logger::Env::default().default_filter_or("info")).init();

    tauri::Builder::default()
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_fs::init())
        .plugin(tauri_plugin_shell::init())
        .plugin(tauri_plugin_global_shortcut::Builder::new().build())
        .manage(AppState::default())
        .manage(tray::TrayRows::default())
        .manage(controller::ControllerState::default())
        .manage(recorder_bar::RecorderBarState::default())
        .manage(agent::AgentState::default())
        .invoke_handler(tauri::generate_handler![
            commands::media::import_media,
            commands::media::probe_media,
            commands::media::probe_media_size,
            commands::media::hash_media,
            commands::misc::perf_spans_snapshot,
            commands::engine::native_engine_capabilities,
            commands::preview::generate_waveform,
            commands::preview::generate_preview_proxy,
            commands::record::list_recording_devices,
            commands::record::read_recording_cursor_log,
            commands::record::discard_recording_take,
            commands::record::request_recording_permissions,
            commands::record::open_privacy_settings,
            commands::record::recording_thumbnail,
            commands::record::get_recording_snapshot,
            commands::record::pending_recording_results,
            commands::record::ack_recording_result,
            commands::record::mark_recording,
            commands::record::start_recording,
            commands::record::pause_recording,
            commands::record::resume_recording,
            commands::record::stop_recording,
            commands::record::cancel_recording,
            commands::record::restart_recording,
            commands::record::composite_recording_camera,
            commands::record::discard_recording_composite,
            commands::transcribe::transcribe,
            commands::transcribe::list_models,
            commands::transcribe::download_model,
            commands::transcribe::delete_model,
            commands::project::save_project,
            commands::project::load_project,
            commands::project::relink_media,
            commands::project::find_missing_media,
            commands::export::export_video,
            commands::export::cancel_export,
            commands::export::mask_coverage_sheet,
            commands::jobs::list_jobs,
            commands::jobs::cancel_job,
            commands::snapshots::create_snapshot,
            commands::snapshots::list_snapshots,
            commands::snapshots::restore_snapshot,
            commands::snapshots::delete_snapshot,
            commands::snapshots::strip_snapshot_key_names,
            commands::misc::app_data_dir,
            commands::misc::reveal_in_finder,
            commands::pauses::detect_pauses,
            tray::update_tray,
            controller::show_main_window,
            controller::set_controller_hidden,
            controller::set_controller_expanded,
            recorder_bar::open_recorder_bar,
            recorder_bar::close_recorder_bar,
            recorder_bar::hide_recorder_bar,
            recorder_bar::set_recorder_bar_height,
            recorder_bar::open_recordings_folder,
            agent::commands::agent_ready,
            agent::commands::agent_respond,
            agent::commands::agent_path_info,
            agent::commands::agent_write_text_file,
            agent::commands::agent_server_info,
            agent::commands::agent_set_enabled,
            agent::commands::agent_regenerate_token,
        ])
        .setup(|app| {
            // Best-effort persistence of the jobs queue across restarts.
            use tauri::{Emitter, Manager};
            // Every authoritative session change reaches every window, in order.
            let emitter = app.handle().clone();
            app.state::<AppState>()
                .recording
                .authority
                .set_sink(move |snapshot| {
                    let _ = emitter.emit("record:snapshot", snapshot);
                    controller::request_sync(&emitter);
                    recorder_bar::on_phase(&emitter, snapshot.phase);
                });
            // A missing menu-bar item must never stop the app from starting.
            if let Err(e) = tray::build(app.handle()) {
                log::warn!("menu-bar item unavailable: {e}");
            }
            agent::init(app.handle());
            let handle = app.handle().clone();
            tauri::async_runtime::spawn(async move {
                let state = handle.state::<AppState>();
                let path = handle
                    .path()
                    .app_data_dir()
                    .ok()
                    .map(|d| d.join("jobs.json"));
                if let Some(p) = &path {
                    state.jobs.load_from(p).await;
                    state.jobs.cleanse_dead_jobs().await;
                }
            });
            Ok(())
        })
        .build(tauri::generate_context!())
        .expect("error while building WordsCut")
        .run(|handle, event| {
            if let tauri::RunEvent::Exit = event {
                agent::shutdown(handle);
            }
        });
}
