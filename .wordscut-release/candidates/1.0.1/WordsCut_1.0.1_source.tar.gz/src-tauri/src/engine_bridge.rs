//! Bridge to the native Apple media engine helper (`native/yusafcut-engine`).
//!
//! First slice: only `capabilities`. The helper is NOT bundled yet (it is not in
//! `tauri.conf.json` `externalBin`), so a shipped app reports
//! `{available: false, reason: "helper-missing"}` and every caller stays on the
//! FFmpeg / HTML5 path. Contract and reason codes: `docs/native-engine.md`.

use serde_json::{json, Value};
use std::path::{Path, PathBuf};
use std::time::Duration;

/// Binary name inside a bundle (next to the app executable).
pub const ENGINE_NAME: &str = "yusafcut-engine";
/// `capabilities` does no media work; anything slower than this is a hung helper.
pub const CAPABILITIES_TIMEOUT: Duration = Duration::from_secs(5);
/// Upper bound on helper stdout we parse (bounded memory).
const MAX_OUTPUT_BYTES: usize = 64 * 1024;

/// Where the engine helper lives, if anywhere. Same shape as
/// `native_capture::helper_path`: `YUSAFCUT_ENGINE_BIN`, then (debug builds) a
/// copy in `src-tauri/binaries/` or the Swift package's own `.build` output,
/// then next to the app executable.
pub fn helper_path() -> Option<PathBuf> {
    if let Ok(p) = std::env::var("YUSAFCUT_ENGINE_BIN") {
        let p = PathBuf::from(p);
        return p.is_file().then_some(p);
    }
    let mut candidates: Vec<PathBuf> = Vec::new();
    if cfg!(debug_assertions) {
        let manifest = Path::new(env!("CARGO_MANIFEST_DIR"));
        candidates.push(manifest.join("binaries").join(format!("{ENGINE_NAME}-aarch64-apple-darwin")));
        let pkg = manifest.join("..").join("native").join(ENGINE_NAME).join(".build");
        candidates.push(pkg.join("release").join(ENGINE_NAME));
        candidates.push(pkg.join("debug").join(ENGINE_NAME));
    }
    if let Ok(exe) = std::env::current_exe() {
        if let Some(dir) = exe.parent() {
            candidates.push(dir.join(ENGINE_NAME));
        }
    }
    candidates.into_iter().find(|p| p.is_file())
}

/// The stub every failure path returns. `reason` is a stable code.
pub fn unavailable(reason: &str) -> Value {
    json!({ "available": false, "reason": reason, "levels": [] })
}

/// Parse `yusafcut-engine capabilities` stdout. Anything that is not a JSON
/// object with a boolean `available` is `helper-bad-output`.
pub fn parse_capabilities(stdout: &[u8]) -> Value {
    if stdout.len() > MAX_OUTPUT_BYTES {
        return unavailable("helper-bad-output");
    }
    match serde_json::from_slice::<Value>(stdout) {
        Ok(v) if v.get("available").and_then(Value::as_bool).is_some() => v,
        _ => unavailable("helper-bad-output"),
    }
}

/// Run `<path> capabilities` with a timeout. `None` means no helper was found.
pub async fn capabilities_from(path: Option<&Path>, timeout: Duration) -> Value {
    let Some(path) = path else {
        return unavailable("helper-missing");
    };
    let mut cmd = tokio::process::Command::new(path);
    cmd.arg("capabilities")
        .stdin(std::process::Stdio::null())
        .stdout(std::process::Stdio::piped())
        .stderr(std::process::Stdio::null())
        .kill_on_drop(true);
    match tokio::time::timeout(timeout, cmd.output()).await {
        Err(_) => unavailable("helper-timeout"),
        Ok(Err(e)) => {
            log::warn!("native engine helper failed to start: {e}");
            unavailable("helper-failed")
        }
        Ok(Ok(out)) if !out.status.success() => unavailable("helper-failed"),
        Ok(Ok(out)) => parse_capabilities(&out.stdout),
    }
}

/// What the app should report. `YUSAFCUT_NATIVE_ENGINE=0` turns the probe off.
pub async fn capabilities() -> Value {
    if std::env::var("YUSAFCUT_NATIVE_ENGINE").map(|v| v == "0").unwrap_or(false) {
        return unavailable("disabled-by-env");
    }
    capabilities_from(helper_path().as_deref(), CAPABILITIES_TIMEOUT).await
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::os::unix::fs::PermissionsExt;

    fn script(body: &str) -> PathBuf {
        let dir = std::env::temp_dir().join(format!("yusafcut-engine-{}", uuid::Uuid::new_v4()));
        std::fs::create_dir_all(&dir).unwrap();
        let p = dir.join("engine.sh");
        std::fs::write(&p, format!("#!/bin/sh\n{body}\n")).unwrap();
        std::fs::set_permissions(&p, std::fs::Permissions::from_mode(0o755)).unwrap();
        p
    }

    #[tokio::test]
    async fn missing_helper_is_reported_not_an_error() {
        let v = capabilities_from(None, CAPABILITIES_TIMEOUT).await;
        assert_eq!(v["available"], false);
        assert_eq!(v["reason"], "helper-missing");
    }

    #[tokio::test]
    async fn helper_json_is_passed_through() {
        let p = script(r#"[ "$1" = capabilities ] || exit 9; echo '{"available":true,"reason":null,"planVersion":1,"levels":["probe"]}'"#);
        let v = capabilities_from(Some(&p), CAPABILITIES_TIMEOUT).await;
        assert_eq!(v["available"], true);
        assert_eq!(v["levels"][0], "probe");
    }

    #[tokio::test]
    async fn failing_slow_or_garbled_helpers_fall_back_with_a_code() {
        let p = script("exit 3");
        assert_eq!(capabilities_from(Some(&p), CAPABILITIES_TIMEOUT).await["reason"], "helper-failed");
        let p = script("sleep 5");
        assert_eq!(capabilities_from(Some(&p), Duration::from_millis(200)).await["reason"], "helper-timeout");
        let p = script("echo not json");
        assert_eq!(capabilities_from(Some(&p), CAPABILITIES_TIMEOUT).await["reason"], "helper-bad-output");
        let p = Path::new("/nonexistent/yusafcut-engine");
        assert_eq!(capabilities_from(Some(p), CAPABILITIES_TIMEOUT).await["reason"], "helper-failed");
    }

    #[test]
    fn parse_requires_an_available_flag() {
        assert_eq!(parse_capabilities(br#"{"available":false,"reason":"not-apple-silicon"}"#)["reason"], "not-apple-silicon");
        assert_eq!(parse_capabilities(br#"{"reason":"x"}"#)["reason"], "helper-bad-output");
        assert_eq!(parse_capabilities(b"[]")["reason"], "helper-bad-output");
        assert_eq!(parse_capabilities(&vec![b' '; MAX_OUTPUT_BYTES + 1])["reason"], "helper-bad-output");
    }

    /// Runs the real Swift helper when it has been built (`swift build` in
    /// native/yusafcut-engine); skipped otherwise.
    #[tokio::test]
    async fn real_helper_when_built() {
        let pkg = Path::new(env!("CARGO_MANIFEST_DIR")).join("../native/yusafcut-engine/.build");
        let Some(bin) = ["release", "debug"].iter().map(|c| pkg.join(c).join(ENGINE_NAME)).find(|p| p.is_file()) else {
            eprintln!("skipped: yusafcut-engine not built");
            return;
        };
        let v = capabilities_from(Some(&bin), CAPABILITIES_TIMEOUT).await;
        assert!(v["available"].is_boolean(), "{v}");
        assert_eq!(v["planVersion"], 1);
        assert!(v["macosVersion"].is_string());
    }
}
