//! Tauri commands for the agent bridge (design §2.4).

use super::protocol::{PathInfo, RelayResponse, ServerInfo, ToolCatalogEntry};
use super::security::{self, PathKind};
use super::AgentState;
use std::path::Path;
use tauri::State;

#[tauri::command]
pub fn agent_ready(state: State<'_, AgentState>, catalog: Vec<ToolCatalogEntry>) {
    state.relay.set_catalog(catalog);
}

#[tauri::command]
pub fn agent_respond(state: State<'_, AgentState>, response: RelayResponse) {
    state.relay.respond(response);
}

pub fn path_info_for(path: &str, forbidden: &[std::path::PathBuf]) -> PathInfo {
    let p = Path::new(path);
    let absolute = p.is_absolute() && !path.contains('\0');
    if !absolute {
        return PathInfo {
            path: path.to_string(),
            absolute: false,
            exists: false,
            is_dir: false,
            is_file: false,
            parent_exists: false,
            canonical: None,
        };
    }
    // Protected locations report no canonical path, so callers cannot use them.
    let canonical = security::canonicalize_lenient(p)
        .ok()
        .filter(|c| !security::is_forbidden(c, forbidden))
        .map(|c| c.to_string_lossy().into_owned());
    PathInfo {
        path: path.to_string(),
        absolute,
        exists: p.exists(),
        is_dir: p.is_dir(),
        is_file: p.is_file(),
        parent_exists: p.parent().is_some_and(|d| d.is_dir()),
        canonical,
    }
}

#[tauri::command]
pub fn agent_path_info(path: String) -> PathInfo {
    path_info_for(&path, &security::default_forbidden_roots())
}

pub fn write_text_file(
    path: &str,
    contents: &str,
    overwrite: bool,
    forbidden: &[std::path::PathBuf],
) -> Result<(), String> {
    if contents.len() > security::MAX_TEXT_WRITE {
        return Err("contents exceed 10 MiB".into());
    }
    let target = security::validate_path_with(PathKind::Captions, path, forbidden)?;
    if target.is_dir() {
        return Err("path is a directory".into());
    }
    if target.exists() && !overwrite {
        return Err("file exists; pass overwrite:true to replace it".into());
    }
    std::fs::write(&target, contents).map_err(|e| e.to_string())
}

#[tauri::command]
pub fn agent_write_text_file(path: String, contents: String, overwrite: bool) -> Result<(), String> {
    write_text_file(&path, &contents, overwrite, &security::default_forbidden_roots())
}

#[tauri::command]
pub fn agent_server_info(state: State<'_, AgentState>) -> ServerInfo {
    state.info()
}

#[tauri::command]
pub async fn agent_set_enabled(
    state: State<'_, AgentState>,
    enabled: bool,
) -> Result<ServerInfo, String> {
    state.set_enabled(enabled).await
}

#[tauri::command]
pub async fn agent_regenerate_token(state: State<'_, AgentState>) -> Result<ServerInfo, String> {
    state.regenerate_token().await
}

#[cfg(test)]
mod tests {
    use super::*;

    fn tmp() -> std::path::PathBuf {
        let d = std::env::temp_dir().join(format!("yc-cmd-{}", uuid::Uuid::new_v4()));
        std::fs::create_dir_all(&d).unwrap();
        d.canonicalize().unwrap()
    }

    #[test]
    fn write_respects_overwrite_and_extension() {
        let d = tmp();
        let f = d.join("a.srt");
        let p = f.to_str().unwrap();
        write_text_file(p, "one", false, &[]).unwrap();
        assert!(write_text_file(p, "two", false, &[]).is_err());
        write_text_file(p, "two", true, &[]).unwrap();
        assert_eq!(std::fs::read_to_string(&f).unwrap(), "two");
        assert!(write_text_file(d.join("a.txt").to_str().unwrap(), "x", true, &[]).is_err());
        assert!(write_text_file(p, "x", true, &[d.clone()]).is_err());
        let _ = std::fs::remove_dir_all(&d);
    }

    #[test]
    fn path_info_reports_facts() {
        let d = tmp();
        let i = path_info_for(d.join("new.srt").to_str().unwrap(), &[]);
        assert!(i.absolute && !i.exists && i.parent_exists && i.canonical.is_some());
        let i = path_info_for(d.to_str().unwrap(), &[]);
        assert!(i.is_dir && !i.is_file);
        let i = path_info_for("relative/x", &[]);
        assert!(!i.absolute && i.canonical.is_none());
        let i = path_info_for(d.join("x.srt").to_str().unwrap(), &[d.clone()]);
        assert!(i.canonical.is_none());
        let _ = std::fs::remove_dir_all(&d);
    }
}
