//! Loopback HTTP server (hyper 1.x): MCP Streamable HTTP plus a small REST surface.

use super::mcp::{self, ToolBackend};
use super::protocol::{CallRequest, Health};
use super::security;
use bytes::Bytes;
use http_body_util::{BodyExt, Full, Limited};
use hyper::body::Incoming;
use hyper::header::{AUTHORIZATION, CONTENT_TYPE, HOST, ORIGIN};
use hyper::server::conn::http1;
use hyper::service::service_fn;
use hyper::{Method, Request, Response, StatusCode};
use hyper_util::rt::{TokioIo, TokioTimer};
use serde_json::{json, Value};
use std::convert::Infallible;
use std::io;
use std::net::SocketAddr;
use std::sync::Arc;
use std::time::Duration;
use tokio::net::TcpListener;
use tokio::sync::watch;

pub struct ServerHandle {
    pub port: u16,
    pub token: String,
    shutdown: watch::Sender<bool>,
}

impl ServerHandle {
    /// Stops accepting and closes open connections. Does not wait.
    pub fn stop(&self) {
        let _ = self.shutdown.send(true);
    }
}

struct Ctx<B> {
    backend: Arc<B>,
    token: String,
    port: u16,
}

type Resp = Response<Full<Bytes>>;

fn respond(status: StatusCode, body: &Value) -> Resp {
    let mut r = Response::new(Full::new(Bytes::from(body.to_string())));
    *r.status_mut() = status;
    r.headers_mut()
        .insert(CONTENT_TYPE, "application/json".parse().unwrap());
    r
}

fn empty(status: StatusCode) -> Resp {
    let mut r = Response::new(Full::new(Bytes::new()));
    *r.status_mut() = status;
    r
}

fn error(status: StatusCode, code: &str, message: &str) -> Resp {
    respond(
        status,
        &json!({"ok": false, "error": {"code": code, "message": message}}),
    )
}

/// Binds `127.0.0.1:0` and serves until `stop()`.
pub async fn start<B: ToolBackend + 'static>(
    backend: Arc<B>,
    token: String,
) -> io::Result<ServerHandle> {
    let listener = TcpListener::bind(SocketAddr::from(([127, 0, 0, 1], 0))).await?;
    let port = listener.local_addr()?.port();
    let (tx, rx) = watch::channel(false);
    let ctx = Arc::new(Ctx { backend, token: token.clone(), port });

    tokio::spawn(async move {
        let mut stop = rx.clone();
        loop {
            tokio::select! {
                _ = stop.changed() => break,
                accepted = listener.accept() => {
                    let Ok((stream, _)) = accepted else { continue };
                    let ctx = ctx.clone();
                    let mut conn_stop = rx.clone();
                    tokio::spawn(async move {
                        let svc = service_fn(move |req| {
                            let ctx = ctx.clone();
                            async move { Ok::<_, Infallible>(handle(&ctx, req).await) }
                        });
                        let conn = http1::Builder::new()
                            .timer(TokioTimer::new())
                            .header_read_timeout(Duration::from_secs(10))
                            .serve_connection(TokioIo::new(stream), svc);
                        tokio::pin!(conn);
                        tokio::select! {
                            _ = conn.as_mut() => {}
                            _ = conn_stop.changed() => { conn.as_mut().graceful_shutdown(); }
                        }
                    });
                }
            }
        }
    });

    Ok(ServerHandle { port, token, shutdown: tx })
}

async fn handle<B: ToolBackend>(ctx: &Ctx<B>, req: Request<Incoming>) -> Resp {
    let (parts, body) = req.into_parts();
    let hdr = |name| parts.headers.get(name).and_then(|v| v.to_str().ok());

    if security::has_origin(parts.headers.get(ORIGIN).map(|_| "present")) {
        return error(StatusCode::FORBIDDEN, "FORBIDDEN", "Cross-origin requests are not allowed.");
    }
    if !security::check_host(hdr(HOST), ctx.port) {
        return error(StatusCode::FORBIDDEN, "FORBIDDEN", "Unexpected Host header.");
    }
    match security::bearer(hdr(AUTHORIZATION)) {
        Some(t) if security::token_eq(t, &ctx.token) => {}
        _ => return error(StatusCode::UNAUTHORIZED, "UNAUTHORIZED", "Missing or invalid bearer token."),
    }

    let path = parts.uri.path();
    let known = matches!(path, "/mcp" | "/v1/health" | "/v1/tools" | "/v1/tools/call");
    if !known {
        return error(StatusCode::NOT_FOUND, "NOT_FOUND", "No such route.");
    }
    let wants_post = matches!(path, "/mcp" | "/v1/tools/call");
    let method_ok = if wants_post { parts.method == Method::POST } else { parts.method == Method::GET };
    if !method_ok {
        let mut r = error(StatusCode::METHOD_NOT_ALLOWED, "METHOD_NOT_ALLOWED", "Method not allowed.");
        r.headers_mut().insert(
            hyper::header::ALLOW,
            if wants_post { "POST" } else { "GET" }.parse().unwrap(),
        );
        return r;
    }

    let body = if wants_post {
        match Limited::new(body, security::MAX_BODY).collect().await {
            Ok(b) => b.to_bytes(),
            Err(_) => return error(StatusCode::PAYLOAD_TOO_LARGE, "PAYLOAD_TOO_LARGE", "Body exceeds 1 MiB."),
        }
    } else {
        Bytes::new()
    };

    match path {
        "/v1/health" => respond(
            StatusCode::OK,
            &serde_json::to_value(Health {
                ok: true,
                app: "yusafcut".into(),
                version: env!("CARGO_PKG_VERSION").into(),
                editor_ready: ctx.backend.ready(),
                pid: std::process::id(),
            })
            .unwrap(),
        ),
        "/v1/tools" => {
            if !ctx.backend.ready() {
                return not_ready();
            }
            respond(StatusCode::OK, &serde_json::to_value(ctx.backend.catalog()).unwrap())
        }
        "/v1/tools/call" => {
            let Ok(call) = serde_json::from_slice::<CallRequest>(&body) else {
                return error(StatusCode::BAD_REQUEST, "INVALID_INPUT", "Body must be {name, input}.");
            };
            if !ctx.backend.ready() {
                return not_ready();
            }
            let input = if call.input.is_null() { json!({}) } else { call.input };
            respond(StatusCode::OK, &ctx.backend.call(&call.name, input).await)
        }
        _ => match mcp::handle_jsonrpc_bytes(&body, ctx.backend.as_ref()).await {
            None => empty(StatusCode::ACCEPTED),
            Some(v) => {
                let status = if mcp::is_not_ready(&v) { StatusCode::SERVICE_UNAVAILABLE } else { StatusCode::OK };
                respond(status, &v)
            }
        },
    }
}

fn not_ready() -> Resp {
    error(
        StatusCode::SERVICE_UNAVAILABLE,
        "EDITOR_NOT_READY",
        "The editor has not finished loading.",
    )
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::agent::protocol::{RelayResponse, ToolCatalogEntry};
    use crate::agent::relay::{Relay, RelayBackend};
    use std::sync::atomic::{AtomicUsize, Ordering};

    fn entry(name: &str) -> ToolCatalogEntry {
        ToolCatalogEntry {
            name: name.into(),
            title: name.into(),
            description: "d".into(),
            mutates: false,
            long_running: None,
            input_schema: json!({"type": "object", "additionalProperties": false}),
        }
    }

    /// Fake "webview": answers every request after 30 ms, tracking concurrency.
    fn fake_webview(relay: &Arc<Relay>, max: Arc<AtomicUsize>) {
        let in_flight = Arc::new(AtomicUsize::new(0));
        let r2 = relay.clone();
        relay.set_emitter(move |req| {
            let (r3, f, m) = (r2.clone(), in_flight.clone(), max.clone());
            tokio::spawn(async move {
                m.fetch_max(f.fetch_add(1, Ordering::SeqCst) + 1, Ordering::SeqCst);
                tokio::time::sleep(Duration::from_millis(30)).await;
                f.fetch_sub(1, Ordering::SeqCst);
                r3.respond(RelayResponse {
                    id: req.id,
                    outcome: json!({"ok": true, "tool": req.name, "data": {"echo": req.input}}),
                });
            });
            Ok(())
        });
    }

    struct Harness {
        relay: Arc<Relay>,
        handle: ServerHandle,
        http: reqwest::Client,
    }

    impl Harness {
        async fn new() -> Self {
            let relay = Arc::new(Relay::default());
            let handle = start(Arc::new(RelayBackend(relay.clone())), "secret-token".into())
                .await
                .unwrap();
            let http = reqwest::Client::builder().no_proxy().build().unwrap();
            Self { relay, handle, http }
        }
        fn url(&self, p: &str) -> String {
            format!("http://127.0.0.1:{}{}", self.handle.port, p)
        }
        fn req(&self, m: reqwest::Method, p: &str) -> reqwest::RequestBuilder {
            self.http
                .request(m, self.url(p))
                .header("Authorization", "Bearer secret-token")
        }
    }

    #[tokio::test]
    async fn auth_host_origin_and_limits() {
        let h = Harness::new().await;
        // 401 without / with wrong token
        let r = h.http.get(h.url("/v1/health")).send().await.unwrap();
        assert_eq!(r.status(), 401);
        let r = h.http.get(h.url("/v1/health")).header("Authorization", "Bearer nope").send().await.unwrap();
        assert_eq!(r.status(), 401);
        // 200 health, editor not ready yet
        let r = h.req(reqwest::Method::GET, "/v1/health").send().await.unwrap();
        assert_eq!(r.status(), 200);
        let v: Value = r.json().await.unwrap();
        assert_eq!(v["ok"], true);
        assert_eq!(v["editorReady"], false);
        // 403 Origin and Host
        let r = h.req(reqwest::Method::GET, "/v1/health").header("Origin", "http://evil.com").send().await.unwrap();
        assert_eq!(r.status(), 403);
        let r = h.req(reqwest::Method::GET, "/v1/health").header("Host", "evil.com").send().await.unwrap();
        assert_eq!(r.status(), 403);
        let ok_host = format!("localhost:{}", h.handle.port);
        let r = h.req(reqwest::Method::GET, "/v1/health").header("Host", ok_host).send().await.unwrap();
        assert_eq!(r.status(), 200);
        // 404 / 405
        assert_eq!(h.req(reqwest::Method::GET, "/nope").send().await.unwrap().status(), 404);
        assert_eq!(h.req(reqwest::Method::GET, "/mcp").send().await.unwrap().status(), 405);
        assert_eq!(h.req(reqwest::Method::POST, "/v1/health").send().await.unwrap().status(), 405);
        // 413
        let big = vec![b'a'; security::MAX_BODY + 1];
        let r = h.req(reqwest::Method::POST, "/mcp").body(big).send().await.unwrap();
        assert_eq!(r.status(), 413);
        // 503 before agent_ready
        assert_eq!(h.req(reqwest::Method::GET, "/v1/tools").send().await.unwrap().status(), 503);
        let body = json!({"jsonrpc":"2.0","id":1,"method":"tools/list"});
        let r = h.req(reqwest::Method::POST, "/mcp").json(&body).send().await.unwrap();
        assert_eq!(r.status(), 503);
        h.handle.stop();
    }

    #[tokio::test]
    async fn round_trip_over_rest_and_mcp() {
        let h = Harness::new().await;
        h.relay.set_catalog(vec![entry("project_info")]);
        fake_webview(&h.relay, Arc::new(AtomicUsize::new(0)));

        let tools: Value = h.req(reqwest::Method::GET, "/v1/tools").send().await.unwrap().json().await.unwrap();
        assert_eq!(tools[0]["name"], "project_info");

        let r = h
            .req(reqwest::Method::POST, "/v1/tools/call")
            .json(&json!({"name": "project_info", "input": {"a": 1}}))
            .send()
            .await
            .unwrap();
        assert_eq!(r.status(), 200);
        let v: Value = r.json().await.unwrap();
        assert_eq!(v["ok"], true);
        assert_eq!(v["data"]["echo"]["a"], 1);

        let bad = h.req(reqwest::Method::POST, "/v1/tools/call").body("{}").send().await.unwrap();
        assert_eq!(bad.status(), 400);

        let init = json!({"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-03-26"}});
        let v: Value = h.req(reqwest::Method::POST, "/mcp").json(&init).send().await.unwrap().json().await.unwrap();
        assert_eq!(v["result"]["protocolVersion"], "2025-03-26");
        let note = json!({"jsonrpc":"2.0","method":"notifications/initialized"});
        assert_eq!(h.req(reqwest::Method::POST, "/mcp").json(&note).send().await.unwrap().status(), 202);
        let call = json!({"jsonrpc":"2.0","id":2,"method":"tools/call","params":{"name":"project_info","arguments":{"x":true}}});
        let v: Value = h.req(reqwest::Method::POST, "/mcp").json(&call).send().await.unwrap().json().await.unwrap();
        assert_eq!(v["result"]["isError"], false);
        assert_eq!(v["result"]["structuredContent"]["echo"]["x"], true);
        let junk = h.req(reqwest::Method::POST, "/mcp").body("{oops").send().await.unwrap();
        let v: Value = junk.json().await.unwrap();
        assert_eq!(v["error"]["code"], -32700);
        h.handle.stop();
    }

    #[tokio::test]
    async fn concurrent_calls_are_serialised() {
        let h = Harness::new().await;
        h.relay.set_catalog(vec![entry("project_info")]);
        let max = Arc::new(AtomicUsize::new(0));
        fake_webview(&h.relay, max.clone());
        let mut tasks = Vec::new();
        for i in 0..6 {
            let rb = h
                .req(reqwest::Method::POST, "/v1/tools/call")
                .json(&json!({"name": "project_info", "input": {"i": i}}));
            tasks.push(tokio::spawn(async move {
                rb.send().await.unwrap().json::<Value>().await.unwrap()
            }));
        }
        for (i, t) in tasks.into_iter().enumerate() {
            let v = t.await.unwrap();
            assert_eq!(v["data"]["echo"]["i"], i);
        }
        assert_eq!(max.load(Ordering::SeqCst), 1);
        h.handle.stop();
    }

    #[tokio::test]
    async fn stop_refuses_new_connections() {
        let h = Harness::new().await;
        h.handle.stop();
        tokio::time::sleep(Duration::from_millis(100)).await;
        let r = h.req(reqwest::Method::GET, "/v1/health").send().await;
        assert!(r.is_err());
    }
}
