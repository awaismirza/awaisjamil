//! Agent CLI / MCP: loopback server that lets external AI CLIs drive the editor.
//! Design: docs/agent-cli-design.md.

pub mod commands;
pub mod connection;
pub mod mcp;
pub mod protocol;
pub mod relay;
pub mod security;
pub mod server;
pub mod settings;

use protocol::{RelayRequest, ServerInfo};
use relay::{Relay, RelayBackend};
use server::ServerHandle;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex};
use tauri::{AppHandle, Emitter, Manager};

pub const UNAVAILABLE_MAS: &str = "Not available in the Mac App Store build";

/// `Some(reason)` when running inside the App Store sandbox.
pub fn unavailable_reason_from(sandbox_container_id: Option<&str>) -> Option<String> {
    sandbox_container_id
        .filter(|v| !v.is_empty())
        .map(|_| UNAVAILABLE_MAS.to_string())
}

pub fn unavailable_reason() -> Option<String> {
    unavailable_reason_from(std::env::var("APP_SANDBOX_CONTAINER_ID").ok().as_deref())
}

pub fn binary_path() -> String {
    std::env::current_exe()
        .map(|p| p.to_string_lossy().into_owned())
        .unwrap_or_default()
}

pub fn build_connection_info(port: u16, token: &str) -> connection::ConnectionInfo {
    connection::ConnectionInfo {
        version: 1,
        port,
        token: token.to_string(),
        pid: std::process::id(),
        started_at: chrono::Utc::now().to_rfc3339(),
        app_version: env!("CARGO_PKG_VERSION").to_string(),
        binary_path: binary_path(),
        mcp_url: format!("http://127.0.0.1:{port}/mcp"),
    }
}

/// 256 bits from two UUIDv4 values.
pub fn new_token() -> String {
    format!("{}{}", uuid::Uuid::new_v4().simple(), uuid::Uuid::new_v4().simple())
}

/// Removes `connection.json` only if this process wrote it.
fn remove_own_connection_file() {
    if let Ok(info) = connection::read() {
        if info.pid == std::process::id() {
            connection::remove();
        }
    }
}

#[derive(Default)]
pub struct AgentState {
    pub relay: Arc<Relay>,
    server: Mutex<Option<ServerHandle>>,
    enabled: AtomicBool,
    lifecycle: tokio::sync::Mutex<()>,
}

impl AgentState {
    pub fn info(&self) -> ServerInfo {
        let reason = unavailable_reason();
        let server = self.server.lock().unwrap();
        let (port, token) = match server.as_ref() {
            Some(s) => (Some(s.port), Some(s.token.clone())),
            None => (None, None),
        };
        ServerInfo {
            available: reason.is_none(),
            unavailable_reason: reason,
            enabled: self.enabled.load(Ordering::SeqCst),
            running: server.is_some(),
            port,
            mcp_url: port.map(|p| format!("http://127.0.0.1:{p}/mcp")),
            token,
            binary_path: binary_path(),
            connection_file: connection::connection_file().to_string_lossy().into_owned(),
            app_version: env!("CARGO_PKG_VERSION").to_string(),
        }
    }

    fn stop_locked(&self) {
        if let Some(s) = self.server.lock().unwrap().take() {
            s.stop();
        }
        remove_own_connection_file();
    }

    async fn start_locked(&self) -> Result<(), String> {
        if self.server.lock().unwrap().is_some() {
            return Ok(());
        }
        let token = new_token();
        let handle = server::start(Arc::new(RelayBackend(self.relay.clone())), token.clone())
            .await
            .map_err(|e| format!("could not start agent server: {e}"))?;
        if let Err(e) = connection::write(&build_connection_info(handle.port, &token)) {
            handle.stop();
            return Err(format!("could not write connection file: {e}"));
        }
        *self.server.lock().unwrap() = Some(handle);
        Ok(())
    }

    pub async fn set_enabled(&self, enabled: bool) -> Result<ServerInfo, String> {
        let _turn = self.lifecycle.lock().await;
        if enabled && unavailable_reason().is_some() {
            return Err(UNAVAILABLE_MAS.into());
        }
        self.enabled.store(enabled, Ordering::SeqCst);
        if let Err(e) = settings::save(&settings::Settings { enabled }) {
            log::warn!("agent settings not saved: {e}");
        }
        if enabled {
            self.start_locked().await?;
        } else {
            self.stop_locked();
        }
        Ok(self.info())
    }

    /// New token (and port) for a running server; no-op while it is off.
    pub async fn regenerate_token(&self) -> Result<ServerInfo, String> {
        let _turn = self.lifecycle.lock().await;
        if self.server.lock().unwrap().is_some() {
            self.stop_locked();
            self.start_locked().await?;
        }
        Ok(self.info())
    }

    pub fn shutdown(&self) {
        self.stop_locked();
    }
}

/// Called from `setup`: wires the relay to the main window and starts the
/// server if the user enabled it.
pub fn init(app: &AppHandle) {
    let state = app.state::<AgentState>();
    let emitter = app.clone();
    state.relay.set_emitter(move |req: RelayRequest| {
        emitter
            .emit_to("main", protocol::EVENT_REQUEST, req)
            .map_err(|e| e.to_string())
    });
    if unavailable_reason().is_some() {
        return;
    }
    if settings::load().enabled {
        state.enabled.store(true, Ordering::SeqCst);
        let handle = app.clone();
        tauri::async_runtime::spawn(async move {
            let state = handle.state::<AgentState>();
            let _turn = state.lifecycle.lock().await;
            if let Err(e) = state.start_locked().await {
                log::warn!("agent server not started: {e}");
            }
        });
    }
}

/// Called on `RunEvent::Exit`.
pub fn shutdown(app: &AppHandle) {
    app.state::<AgentState>().shutdown();
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn sandbox_disables_agent() {
        assert!(unavailable_reason_from(None).is_none());
        assert!(unavailable_reason_from(Some("")).is_none());
        assert_eq!(
            unavailable_reason_from(Some("abc")).as_deref(),
            Some("Not available in the Mac App Store build")
        );
    }

    #[test]
    fn token_is_256_bits_and_unique() {
        let (a, b) = (new_token(), new_token());
        assert_eq!(a.len(), 64);
        assert!(a.chars().all(|c| c.is_ascii_hexdigit()));
        assert_ne!(a, b);
    }

    #[test]
    fn connection_info_shape() {
        let i = build_connection_info(4242, "tok");
        assert_eq!(i.version, 1);
        assert_eq!(i.mcp_url, "http://127.0.0.1:4242/mcp");
        assert_eq!(i.pid, std::process::id());
    }

    #[tokio::test]
    async fn disabled_by_default_and_info_shape() {
        let s = AgentState::default();
        let i = s.info();
        assert!(!i.enabled && !i.running && i.token.is_none() && i.port.is_none());
    }
}
