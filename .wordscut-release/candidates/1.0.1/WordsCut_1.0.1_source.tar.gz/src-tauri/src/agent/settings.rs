//! `<agent_dir>/settings.json`: the persisted on/off switch. Off by default.

use serde::{Deserialize, Serialize};
use std::io;
use std::path::{Path, PathBuf};

#[derive(Debug, Clone, Default, Serialize, Deserialize, PartialEq, Eq)]
pub struct Settings {
    #[serde(default)]
    pub enabled: bool,
}

pub fn settings_file_in(dir: &Path) -> PathBuf {
    dir.join("settings.json")
}

/// Missing or corrupt files read as the default (disabled).
pub fn load_from(dir: &Path) -> Settings {
    std::fs::read(settings_file_in(dir))
        .ok()
        .and_then(|b| serde_json::from_slice(&b).ok())
        .unwrap_or_default()
}

pub fn save_to(dir: &Path, settings: &Settings) -> io::Result<()> {
    std::fs::create_dir_all(dir)?;
    let tmp = dir.join("settings.json.tmp");
    std::fs::write(&tmp, serde_json::to_vec_pretty(settings).map_err(io::Error::other)?)?;
    std::fs::rename(&tmp, settings_file_in(dir))
}

pub fn load() -> Settings {
    load_from(&super::connection::agent_dir())
}

pub fn save(settings: &Settings) -> io::Result<()> {
    save_to(&super::connection::agent_dir(), settings)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn default_off_and_round_trip() {
        let dir = std::env::temp_dir().join(format!("yc-settings-{}", uuid::Uuid::new_v4()));
        assert!(!load_from(&dir).enabled);
        save_to(&dir, &Settings { enabled: true }).unwrap();
        assert!(load_from(&dir).enabled);
        std::fs::write(settings_file_in(&dir), b"{not json").unwrap();
        assert!(!load_from(&dir).enabled);
        let _ = std::fs::remove_dir_all(&dir);
    }
}
