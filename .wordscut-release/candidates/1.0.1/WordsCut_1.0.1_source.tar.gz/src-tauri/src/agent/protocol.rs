//! Serde mirrors of `src/lib/agent/protocol.ts` (camelCase on the wire).

use serde::{Deserialize, Serialize};
use serde_json::Value;

pub const EVENT_REQUEST: &str = "agent:request";

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ToolCatalogEntry {
    pub name: String,
    pub title: String,
    pub description: String,
    pub mutates: bool,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub long_running: Option<bool>,
    pub input_schema: Value,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AgentError {
    pub code: String,
    pub message: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub hint: Option<String>,
}

/// `{ok:true, tool, data}` or `{ok:false, tool, error}`; kept as raw JSON so the
/// relay never has to understand individual tools.
pub type ToolOutcome = Value;

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct RelayRequest {
    pub id: String,
    pub name: String,
    pub input: Value,
    pub deadline_ms: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct RelayResponse {
    pub id: String,
    pub outcome: ToolOutcome,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PathInfo {
    pub path: String,
    pub absolute: bool,
    pub exists: bool,
    pub is_dir: bool,
    pub is_file: bool,
    pub parent_exists: bool,
    pub canonical: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ServerInfo {
    pub available: bool,
    pub unavailable_reason: Option<String>,
    pub enabled: bool,
    pub running: bool,
    pub port: Option<u16>,
    pub mcp_url: Option<String>,
    pub token: Option<String>,
    pub binary_path: String,
    pub connection_file: String,
    pub app_version: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Health {
    pub ok: bool,
    pub app: String,
    pub version: String,
    pub editor_ready: bool,
    pub pid: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CallRequest {
    pub name: String,
    #[serde(default)]
    pub input: Value,
}
