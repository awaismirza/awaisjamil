//! Pure MCP (JSON-RPC 2.0) handling. No I/O: the transport and the tool
//! backend are supplied by the caller.

use super::protocol::ToolCatalogEntry;
use serde_json::{json, Value};
use std::future::Future;

pub const SUPPORTED_VERSIONS: [&str; 3] = ["2025-06-18", "2025-03-26", "2024-11-05"];
pub const NOT_READY_CODE: &str = "EDITOR_NOT_READY";

const ERR_PARSE: i64 = -32700;
const ERR_INVALID_REQUEST: i64 = -32600;
const ERR_METHOD: i64 = -32601;
const ERR_PARAMS: i64 = -32602;
const ERR_NOT_READY: i64 = -32002;

pub trait ToolBackend: Send + Sync {
    fn ready(&self) -> bool;
    fn catalog(&self) -> Vec<ToolCatalogEntry>;
    /// Returns a `ToolOutcome`: `{ok:true,tool,data}` or `{ok:false,tool,error}`.
    fn call(&self, name: &str, input: Value) -> impl Future<Output = Value> + Send;
}

pub fn negotiate(requested: Option<&str>) -> &'static str {
    requested
        .and_then(|r| SUPPORTED_VERSIONS.iter().find(|v| **v == r))
        .copied()
        .unwrap_or(SUPPORTED_VERSIONS[0])
}

fn ok(id: Value, result: Value) -> Value {
    json!({"jsonrpc": "2.0", "id": id, "result": result})
}

fn err(id: Value, code: i64, message: &str, data: Option<Value>) -> Value {
    let mut e = json!({"code": code, "message": message});
    if let Some(d) = data {
        e["data"] = d;
    }
    json!({"jsonrpc": "2.0", "id": id, "error": e})
}

/// True when a JSON-RPC response reports that the editor is not ready (HTTP 503).
pub fn is_not_ready(resp: &Value) -> bool {
    resp.pointer("/error/data/code").and_then(Value::as_str) == Some(NOT_READY_CODE)
}

fn not_ready(id: Value) -> Value {
    err(
        id,
        ERR_NOT_READY,
        "The editor is not ready yet. Open WordsCut's main window and retry.",
        Some(json!({"code": NOT_READY_CODE})),
    )
}

/// Parses a request body and handles it. `None` means "no response body" (202).
pub async fn handle_jsonrpc_bytes<B: ToolBackend>(body: &[u8], backend: &B) -> Option<Value> {
    match serde_json::from_slice::<Value>(body) {
        Ok(msg) => handle_jsonrpc(&msg, backend).await,
        Err(_) => Some(err(Value::Null, ERR_PARSE, "Parse error", None)),
    }
}

pub async fn handle_jsonrpc<B: ToolBackend>(msg: &Value, backend: &B) -> Option<Value> {
    let Some(obj) = msg.as_object() else {
        return Some(err(Value::Null, ERR_INVALID_REQUEST, "Invalid Request", None));
    };
    let id = obj.get("id").cloned();
    let Some(method) = obj.get("method").and_then(Value::as_str) else {
        // A client response to a server request: nothing to do.
        if obj.contains_key("result") || obj.contains_key("error") {
            return None;
        }
        return Some(err(
            id.unwrap_or(Value::Null),
            ERR_INVALID_REQUEST,
            "Invalid Request",
            None,
        ));
    };
    // No id: a notification, never answered.
    let id = id?;
    let params = obj.get("params").cloned().unwrap_or(Value::Null);

    Some(match method {
        "initialize" => {
            let version = negotiate(params.get("protocolVersion").and_then(Value::as_str));
            ok(
                id,
                json!({
                    "protocolVersion": version,
                    "capabilities": {"tools": {"listChanged": false}},
                    "serverInfo": {"name": "yusafcut", "version": env!("CARGO_PKG_VERSION")},
                    "instructions": "Drives the open WordsCut editor. Call mutating tools with confirm:false first to get a plan, then confirm:true with baseRevision to apply."
                }),
            )
        }
        "ping" => ok(id, json!({})),
        "tools/list" => {
            if !backend.ready() {
                return Some(not_ready(id));
            }
            let tools: Vec<Value> = backend
                .catalog()
                .into_iter()
                .map(|t| {
                    json!({
                        "name": t.name,
                        "title": t.title,
                        "description": t.description,
                        "inputSchema": t.input_schema,
                        "annotations": {"readOnlyHint": !t.mutates},
                    })
                })
                .collect();
            ok(id, json!({"tools": tools}))
        }
        "tools/call" => {
            if !backend.ready() {
                return Some(not_ready(id));
            }
            let Some(name) = params.get("name").and_then(Value::as_str) else {
                return Some(err(id, ERR_PARAMS, "Missing tool name", None));
            };
            if !backend.catalog().iter().any(|t| t.name == name) {
                return Some(err(id, ERR_PARAMS, &format!("Unknown tool: {name}"), None));
            }
            let args = match params.get("arguments") {
                None | Some(Value::Null) => json!({}),
                Some(a) if a.is_object() => a.clone(),
                Some(_) => return Some(err(id, ERR_PARAMS, "arguments must be an object", None)),
            };
            let outcome = backend.call(name, args).await;
            ok(id, outcome_to_result(&outcome))
        }
        _ => err(id, ERR_METHOD, &format!("Method not found: {method}"), None),
    })
}

/// `{content:[{type:"text",text}], structuredContent, isError}` from a `ToolOutcome`.
pub fn outcome_to_result(outcome: &Value) -> Value {
    let is_ok = outcome.get("ok").and_then(Value::as_bool).unwrap_or(false);
    let payload = if is_ok {
        outcome.get("data").cloned().unwrap_or(Value::Null)
    } else {
        outcome.get("error").cloned().unwrap_or_else(|| outcome.clone())
    };
    let text = serde_json::to_string_pretty(&payload).unwrap_or_else(|_| "null".into());
    let mut result = json!({
        "content": [{"type": "text", "text": text}],
        "isError": !is_ok,
    });
    if payload.is_object() {
        result["structuredContent"] = payload;
    }
    result
}

#[cfg(test)]
mod tests {
    use super::*;

    struct Fake {
        ready: bool,
        outcome: Value,
    }

    impl ToolBackend for Fake {
        fn ready(&self) -> bool {
            self.ready
        }
        fn catalog(&self) -> Vec<ToolCatalogEntry> {
            vec![ToolCatalogEntry {
                name: "project_info".into(),
                title: "Project info".into(),
                description: "d".into(),
                mutates: false,
                long_running: None,
                input_schema: json!({"type": "object", "additionalProperties": false}),
            }]
        }
        async fn call(&self, _name: &str, _input: Value) -> Value {
            self.outcome.clone()
        }
    }

    fn fake(ready: bool, outcome: Value) -> Fake {
        Fake { ready, outcome }
    }

    #[tokio::test]
    async fn initialize_negotiates_versions() {
        let b = fake(true, Value::Null);
        for (req, want) in [
            ("2024-11-05", "2024-11-05"),
            ("2025-03-26", "2025-03-26"),
            ("2025-06-18", "2025-06-18"),
            ("1999-01-01", "2025-06-18"),
        ] {
            let m = json!({"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":req}});
            let r = handle_jsonrpc(&m, &b).await.unwrap();
            assert_eq!(r["result"]["protocolVersion"], want);
            assert_eq!(r["id"], 1);
            assert_eq!(r["result"]["serverInfo"]["name"], "yusafcut");
        }
        let m = json!({"jsonrpc":"2.0","id":1,"method":"initialize"});
        let r = handle_jsonrpc(&m, &b).await.unwrap();
        assert_eq!(r["result"]["protocolVersion"], "2025-06-18");
    }

    #[tokio::test]
    async fn notifications_get_no_response() {
        let b = fake(true, Value::Null);
        let m = json!({"jsonrpc":"2.0","method":"notifications/initialized"});
        assert!(handle_jsonrpc(&m, &b).await.is_none());
        let m = json!({"jsonrpc":"2.0","method":"tools/list"});
        assert!(handle_jsonrpc(&m, &b).await.is_none());
        let m = json!({"jsonrpc":"2.0","id":3,"result":{}});
        assert!(handle_jsonrpc(&m, &b).await.is_none());
    }

    #[tokio::test]
    async fn ping_and_unknown_method() {
        let b = fake(true, Value::Null);
        let r = handle_jsonrpc(&json!({"jsonrpc":"2.0","id":"a","method":"ping"}), &b).await.unwrap();
        assert_eq!(r["result"], json!({}));
        let r = handle_jsonrpc(&json!({"jsonrpc":"2.0","id":2,"method":"nope"}), &b).await.unwrap();
        assert_eq!(r["error"]["code"], -32601);
    }

    #[tokio::test]
    async fn parse_and_invalid_request() {
        let b = fake(true, Value::Null);
        let r = handle_jsonrpc_bytes(b"{oops", &b).await.unwrap();
        assert_eq!(r["error"]["code"], -32700);
        assert_eq!(r["id"], Value::Null);
        let r = handle_jsonrpc_bytes(b"[1]", &b).await.unwrap();
        assert_eq!(r["error"]["code"], -32600);
    }

    #[tokio::test]
    async fn tools_list_before_ready_errors() {
        let b = fake(false, Value::Null);
        let r = handle_jsonrpc(&json!({"jsonrpc":"2.0","id":1,"method":"tools/list"}), &b).await.unwrap();
        assert!(is_not_ready(&r));
        let r = handle_jsonrpc(
            &json!({"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"project_info"}}),
            &b,
        )
        .await
        .unwrap();
        assert!(is_not_ready(&r));
    }

    #[tokio::test]
    async fn tools_list_when_ready() {
        let b = fake(true, Value::Null);
        let r = handle_jsonrpc(&json!({"jsonrpc":"2.0","id":1,"method":"tools/list"}), &b).await.unwrap();
        assert_eq!(r["result"]["tools"][0]["name"], "project_info");
        assert_eq!(r["result"]["tools"][0]["annotations"]["readOnlyHint"], true);
        assert_eq!(r["result"]["tools"][0]["inputSchema"]["type"], "object");
    }

    #[tokio::test]
    async fn tools_call_maps_outcomes() {
        let good = fake(true, json!({"ok":true,"tool":"project_info","data":{"name":"x"}}));
        let m = json!({"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"project_info","arguments":{}}});
        let r = handle_jsonrpc(&m, &good).await.unwrap();
        assert_eq!(r["result"]["isError"], false);
        assert_eq!(r["result"]["structuredContent"]["name"], "x");
        let text = r["result"]["content"][0]["text"].as_str().unwrap();
        assert_eq!(serde_json::from_str::<Value>(text).unwrap()["name"], "x");

        let bad = fake(
            true,
            json!({"ok":false,"tool":"project_info","error":{"code":"BUSY","message":"m"}}),
        );
        let r = handle_jsonrpc(&m, &bad).await.unwrap();
        assert_eq!(r["result"]["isError"], true);
        assert_eq!(r["result"]["structuredContent"]["code"], "BUSY");

        let unknown = json!({"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"zzz"}});
        let r = handle_jsonrpc(&unknown, &good).await.unwrap();
        assert_eq!(r["error"]["code"], -32602);
        let noname = json!({"jsonrpc":"2.0","id":1,"method":"tools/call","params":{}});
        assert_eq!(handle_jsonrpc(&noname, &good).await.unwrap()["error"]["code"], -32602);
        let badargs = json!({"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"project_info","arguments":[1]}});
        assert_eq!(handle_jsonrpc(&badargs, &good).await.unwrap()["error"]["code"], -32602);
    }
}
