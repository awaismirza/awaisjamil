//! `connection.json`: how the CLI and the stdio bridge find the running app.
//! Directory mode 0700, file mode 0600, written atomically.

use serde::{Deserialize, Serialize};
use std::io;
use std::path::PathBuf;

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "camelCase")]
pub struct ConnectionInfo {
    /// Format version, currently 1.
    pub version: u32,
    pub port: u16,
    pub token: String,
    pub pid: u32,
    pub started_at: String,
    pub app_version: String,
    pub binary_path: String,
    pub mcp_url: String,
}

/// `$YUSAFCUT_AGENT_DIR`, else `<config dir>/dev.yusafcut.app/agent`.
pub fn agent_dir() -> PathBuf {
    if let Some(dir) = std::env::var_os("YUSAFCUT_AGENT_DIR") {
        return PathBuf::from(dir);
    }
    dirs::config_dir()
        .unwrap_or_else(std::env::temp_dir)
        .join("dev.yusafcut.app")
        .join("agent")
}

pub fn connection_file() -> PathBuf {
    agent_dir().join("connection.json")
}

#[cfg(unix)]
fn set_mode(path: &std::path::Path, mode: u32) -> io::Result<()> {
    use std::os::unix::fs::PermissionsExt;
    std::fs::set_permissions(path, std::fs::Permissions::from_mode(mode))
}

#[cfg(not(unix))]
fn set_mode(_: &std::path::Path, _: u32) -> io::Result<()> {
    Ok(())
}

pub fn write(info: &ConnectionInfo) -> io::Result<()> {
    let dir = agent_dir();
    std::fs::create_dir_all(&dir)?;
    set_mode(&dir, 0o700)?;
    let tmp = dir.join("connection.json.tmp");
    std::fs::write(&tmp, serde_json::to_vec_pretty(info).map_err(io::Error::other)?)?;
    set_mode(&tmp, 0o600)?;
    std::fs::rename(&tmp, connection_file())
}

pub fn read() -> io::Result<ConnectionInfo> {
    let bytes = std::fs::read(connection_file())?;
    serde_json::from_slice(&bytes).map_err(io::Error::other)
}

/// Best effort.
pub fn remove() {
    let _ = std::fs::remove_file(connection_file());
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn round_trip_with_private_modes() {
        let dir = std::env::temp_dir().join(format!("yc-agent-{}", uuid::Uuid::new_v4()));
        std::env::set_var("YUSAFCUT_AGENT_DIR", &dir);
        let info = ConnectionInfo {
            version: 1,
            port: 4242,
            token: "t".into(),
            pid: 1,
            started_at: "now".into(),
            app_version: "0".into(),
            binary_path: "/bin/x".into(),
            mcp_url: "http://127.0.0.1:4242/mcp".into(),
        };
        write(&info).unwrap();
        assert_eq!(read().unwrap(), info);
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            let f = std::fs::metadata(connection_file()).unwrap().permissions().mode() & 0o777;
            let d = std::fs::metadata(&dir).unwrap().permissions().mode() & 0o777;
            assert_eq!((f, d), (0o600, 0o700));
        }
        remove();
        assert!(read().is_err());
        let _ = std::fs::remove_dir_all(&dir);
    }
}
