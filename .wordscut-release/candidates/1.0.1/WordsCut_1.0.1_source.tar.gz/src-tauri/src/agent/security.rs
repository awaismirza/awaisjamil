//! Pure request and path validation for the agent server (design §6).

use std::path::{Path, PathBuf};

/// Request body limit (1 MiB).
pub const MAX_BODY: usize = 1024 * 1024;
/// Text files written through `agent_write_text_file` (10 MiB).
pub const MAX_TEXT_WRITE: usize = 10 * 1024 * 1024;

/// `Host` must be `127.0.0.1:<port>` or `localhost:<port>` (blocks DNS rebinding).
pub fn check_host(host: Option<&str>, port: u16) -> bool {
    let Some(host) = host else { return false };
    let host = host.trim().to_ascii_lowercase();
    host == format!("127.0.0.1:{port}") || host == format!("localhost:{port}")
}

/// Browsers always send `Origin` on cross-site requests; the CLI never does.
pub fn has_origin(origin: Option<&str>) -> bool {
    origin.is_some()
}

/// Constant-time comparison (length is not secret: tokens are fixed width).
pub fn token_eq(a: &str, b: &str) -> bool {
    let (a, b) = (a.as_bytes(), b.as_bytes());
    if a.len() != b.len() {
        return false;
    }
    a.iter().zip(b).fold(0u8, |acc, (x, y)| acc | (x ^ y)) == 0
}

/// Extracts the token from `Authorization: Bearer <token>`.
pub fn bearer(header: Option<&str>) -> Option<&str> {
    let h = header?.trim();
    let (scheme, rest) = h.split_once(' ')?;
    scheme.eq_ignore_ascii_case("bearer").then(|| rest.trim())
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PathKind {
    /// `.scribe` directory containing `project.json`, or a `project.json` file.
    OpenProject,
    /// `.scribe` destination.
    SaveProject,
    /// `.mp4` / `.mov`.
    ExportVideo,
    /// `.m4a`.
    ExportAudio,
    /// `.srt` / `.vtt`.
    Captions,
}

fn ext_of(p: &Path) -> String {
    p.extension()
        .and_then(|e| e.to_str())
        .map(|e| e.to_ascii_lowercase())
        .unwrap_or_default()
}

/// Canonicalise a path whose final component may not exist yet. The parent must exist.
pub fn canonicalize_lenient(path: &Path) -> Result<PathBuf, String> {
    if path.exists() {
        return path.canonicalize().map_err(|e| e.to_string());
    }
    let parent = path.parent().ok_or("path has no parent directory")?;
    let name = path.file_name().ok_or("path has no file name")?;
    let parent = parent
        .canonicalize()
        .map_err(|_| "parent directory does not exist".to_string())?;
    Ok(parent.join(name))
}

/// Directories the agent must never read or write: the running `.app` bundle and the agent dir.
pub fn default_forbidden_roots() -> Vec<PathBuf> {
    let mut roots = vec![super::connection::agent_dir()];
    if let Ok(exe) = std::env::current_exe() {
        if let Some(app) = exe.ancestors().find(|a| ext_of(a) == "app") {
            roots.push(app.to_path_buf());
        }
    }
    roots
}

pub fn is_forbidden(canonical: &Path, forbidden: &[PathBuf]) -> bool {
    forbidden.iter().any(|root| {
        let root = root.canonicalize().unwrap_or_else(|_| root.clone());
        canonical.starts_with(&root)
    })
}

pub fn validate_path(kind: PathKind, path: &str) -> Result<PathBuf, String> {
    validate_path_with(kind, path, &default_forbidden_roots())
}

/// Returns the canonical path. Does not check overwrite (the caller does).
pub fn validate_path_with(
    kind: PathKind,
    path: &str,
    forbidden: &[PathBuf],
) -> Result<PathBuf, String> {
    if path.is_empty() || path.len() > 4096 {
        return Err("path must be 1-4096 characters".into());
    }
    if path.contains('\0') {
        return Err("path contains a NUL byte".into());
    }
    let p = Path::new(path);
    if !p.is_absolute() {
        return Err("path must be absolute".into());
    }
    let canonical = canonicalize_lenient(p)?;
    if is_forbidden(&canonical, forbidden) {
        return Err("path is inside a protected location".into());
    }
    let ext = ext_of(&canonical);
    match kind {
        PathKind::OpenProject => {
            let is_file = canonical.file_name().and_then(|n| n.to_str()) == Some("project.json");
            if is_file {
                if !canonical.is_file() {
                    return Err("project.json does not exist".into());
                }
            } else if ext == "scribe" {
                if !canonical.join("project.json").is_file() {
                    return Err("not a project: missing project.json".into());
                }
            } else {
                return Err("expected a .scribe project or project.json".into());
            }
        }
        PathKind::SaveProject => {
            if ext != "scribe" {
                return Err("project path must end in .scribe".into());
            }
        }
        PathKind::ExportVideo => {
            if ext != "mp4" && ext != "mov" {
                return Err("export path must end in .mp4 or .mov".into());
            }
        }
        PathKind::ExportAudio => {
            if ext != "m4a" {
                return Err("audio export path must end in .m4a".into());
            }
        }
        PathKind::Captions => {
            if ext != "srt" && ext != "vtt" {
                return Err("captions path must end in .srt or .vtt".into());
            }
        }
    }
    Ok(canonical)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn tmp() -> PathBuf {
        let d = std::env::temp_dir().join(format!("yc-sec-{}", uuid::Uuid::new_v4()));
        std::fs::create_dir_all(&d).unwrap();
        d.canonicalize().unwrap()
    }

    #[test]
    fn host_checks() {
        assert!(check_host(Some("127.0.0.1:5000"), 5000));
        assert!(check_host(Some("LocalHost:5000"), 5000));
        assert!(!check_host(Some("127.0.0.1:5001"), 5000));
        assert!(!check_host(Some("evil.com"), 5000));
        assert!(!check_host(Some("127.0.0.1"), 5000));
        assert!(!check_host(None, 5000));
    }

    #[test]
    fn origin_and_token() {
        assert!(has_origin(Some("http://evil")));
        assert!(!has_origin(None));
        assert!(token_eq("abc", "abc"));
        assert!(!token_eq("abc", "abd"));
        assert!(!token_eq("abc", "abcd"));
        assert_eq!(bearer(Some("Bearer xyz")), Some("xyz"));
        assert_eq!(bearer(Some("bearer xyz")), Some("xyz"));
        assert_eq!(bearer(Some("Basic xyz")), None);
        assert_eq!(bearer(None), None);
    }

    #[test]
    fn path_rules() {
        let d = tmp();
        let s = |p: &Path| p.to_str().unwrap().to_string();
        // relative, NUL, empty
        assert!(validate_path_with(PathKind::Captions, "a.srt", &[]).is_err());
        assert!(validate_path_with(PathKind::Captions, "/tmp/a\0.srt", &[]).is_err());
        assert!(validate_path_with(PathKind::Captions, "", &[]).is_err());
        // extension allowlists
        assert!(validate_path_with(PathKind::Captions, &s(&d.join("a.srt")), &[]).is_ok());
        assert!(validate_path_with(PathKind::Captions, &s(&d.join("a.VTT")), &[]).is_ok());
        assert!(validate_path_with(PathKind::Captions, &s(&d.join("a.txt")), &[]).is_err());
        assert!(validate_path_with(PathKind::ExportVideo, &s(&d.join("a.mov")), &[]).is_ok());
        assert!(validate_path_with(PathKind::ExportVideo, &s(&d.join("a.m4a")), &[]).is_err());
        assert!(validate_path_with(PathKind::ExportAudio, &s(&d.join("a.m4a")), &[]).is_ok());
        assert!(validate_path_with(PathKind::SaveProject, &s(&d.join("p.scribe")), &[]).is_ok());
        assert!(validate_path_with(PathKind::SaveProject, &s(&d.join("p")), &[]).is_err());
        // parent must exist
        assert!(validate_path_with(PathKind::Captions, &s(&d.join("no/a.srt")), &[]).is_err());
        // open project
        let proj = d.join("p.scribe");
        assert!(validate_path_with(PathKind::OpenProject, &s(&proj), &[]).is_err());
        std::fs::create_dir_all(&proj).unwrap();
        assert!(validate_path_with(PathKind::OpenProject, &s(&proj), &[]).is_err());
        std::fs::write(proj.join("project.json"), "{}").unwrap();
        assert!(validate_path_with(PathKind::OpenProject, &s(&proj), &[]).is_ok());
        assert!(validate_path_with(PathKind::OpenProject, &s(&proj.join("project.json")), &[]).is_ok());
        // forbidden roots (also through `..`)
        let forbidden = vec![proj.clone()];
        assert!(validate_path_with(PathKind::OpenProject, &s(&proj), &forbidden).is_err());
        let sneaky = format!("{}/x/../p.scribe", d.display());
        std::fs::create_dir_all(d.join("x")).unwrap();
        assert!(validate_path_with(PathKind::OpenProject, &sneaky, &forbidden).is_err());
        let _ = std::fs::remove_dir_all(&d);
    }

    #[cfg(unix)]
    #[test]
    fn symlink_into_forbidden_is_refused() {
        let d = tmp();
        let secret = d.join("secret");
        std::fs::create_dir_all(&secret).unwrap();
        let link = d.join("link");
        std::os::unix::fs::symlink(&secret, &link).unwrap();
        let p = link.join("a.srt");
        assert!(validate_path_with(PathKind::Captions, p.to_str().unwrap(), &[secret]).is_err());
        let _ = std::fs::remove_dir_all(&d);
    }
}
