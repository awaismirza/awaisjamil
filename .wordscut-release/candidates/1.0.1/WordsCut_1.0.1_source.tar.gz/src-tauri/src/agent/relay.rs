//! Relays tool calls to the webview and waits for `agent_respond`.
//! One call at a time; the deadline includes queue time.

use super::mcp::ToolBackend;
use super::protocol::{RelayRequest, RelayResponse, ToolCatalogEntry};
use serde_json::{json, Value};
use std::collections::HashMap;
use std::sync::{Arc, Mutex, RwLock};
use std::time::{Duration, Instant};
use tokio::sync::oneshot;

pub const DEFAULT_DEADLINE: Duration = Duration::from_secs(60);

type Emitter = Arc<dyn Fn(RelayRequest) -> Result<(), String> + Send + Sync>;

pub fn failure(tool: &str, code: &str, message: &str) -> Value {
    json!({"ok": false, "tool": tool, "error": {"code": code, "message": message}})
}

pub struct Relay {
    pending: Mutex<HashMap<String, oneshot::Sender<Value>>>,
    catalog: RwLock<Option<Vec<ToolCatalogEntry>>>,
    exec: tokio::sync::Mutex<()>,
    emitter: RwLock<Option<Emitter>>,
    deadline: Duration,
}

impl Default for Relay {
    fn default() -> Self {
        Self::with_deadline(DEFAULT_DEADLINE)
    }
}

struct PendingGuard<'a> {
    relay: &'a Relay,
    id: String,
}

impl Drop for PendingGuard<'_> {
    fn drop(&mut self) {
        self.relay.pending.lock().unwrap().remove(&self.id);
    }
}

impl Relay {
    pub fn with_deadline(deadline: Duration) -> Self {
        Self {
            pending: Mutex::new(HashMap::new()),
            catalog: RwLock::new(None),
            exec: tokio::sync::Mutex::new(()),
            emitter: RwLock::new(None),
            deadline,
        }
    }

    pub fn set_emitter(&self, f: impl Fn(RelayRequest) -> Result<(), String> + Send + Sync + 'static) {
        *self.emitter.write().unwrap() = Some(Arc::new(f));
    }

    pub fn set_catalog(&self, catalog: Vec<ToolCatalogEntry>) {
        *self.catalog.write().unwrap() = Some(catalog);
    }

    pub fn catalog(&self) -> Vec<ToolCatalogEntry> {
        self.catalog.read().unwrap().clone().unwrap_or_default()
    }

    pub fn is_ready(&self) -> bool {
        self.catalog.read().unwrap().is_some()
    }

    pub fn pending_len(&self) -> usize {
        self.pending.lock().unwrap().len()
    }

    /// Unknown ids (late answers after a timeout) are ignored.
    pub fn respond(&self, response: RelayResponse) {
        if let Some(tx) = self.pending.lock().unwrap().remove(&response.id) {
            let _ = tx.send(response.outcome);
        }
    }

    /// Always returns a `ToolOutcome`.
    pub async fn call(&self, name: &str, input: Value) -> Value {
        if !self.is_ready() {
            return failure(name, "EDITOR_NOT_READY", "The editor has not finished loading.");
        }
        let started = Instant::now();
        let run = async {
            let _turn = self.exec.lock().await;
            let remaining = self.deadline.saturating_sub(started.elapsed());
            let id = uuid::Uuid::new_v4().to_string();
            let (tx, rx) = oneshot::channel();
            self.pending.lock().unwrap().insert(id.clone(), tx);
            let _guard = PendingGuard { relay: self, id: id.clone() };
            let emitter = self.emitter.read().unwrap().clone();
            let Some(emit) = emitter else {
                return failure(name, "INTERNAL", "Relay is not connected to a window.");
            };
            let req = RelayRequest {
                id,
                name: name.to_string(),
                input,
                deadline_ms: remaining.as_millis() as u64,
            };
            if let Err(e) = emit(req) {
                return failure(name, "INTERNAL", &format!("Could not reach the editor: {e}"));
            }
            match rx.await {
                Ok(outcome) => outcome,
                Err(_) => failure(name, "INTERNAL", "The editor dropped the request."),
            }
        };
        let outcome = match tokio::time::timeout(self.deadline, run).await {
            Ok(v) => v,
            Err(_) => failure(name, "TIMEOUT", "The editor did not answer in time."),
        };
        log::info!(
            "agent tool={} ms={} code={}",
            name,
            started.elapsed().as_millis(),
            outcome_code(&outcome)
        );
        outcome
    }
}

fn outcome_code(outcome: &Value) -> String {
    if outcome.get("ok").and_then(Value::as_bool) == Some(true) {
        "ok".into()
    } else {
        outcome
            .pointer("/error/code")
            .and_then(Value::as_str)
            .unwrap_or("error")
            .to_string()
    }
}

/// Adapts a shared `Relay` to the MCP/HTTP layer.
#[derive(Clone)]
pub struct RelayBackend(pub Arc<Relay>);

impl ToolBackend for RelayBackend {
    fn ready(&self) -> bool {
        self.0.is_ready()
    }
    fn catalog(&self) -> Vec<ToolCatalogEntry> {
        self.0.catalog()
    }
    async fn call(&self, name: &str, input: Value) -> Value {
        self.0.call(name, input).await
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::atomic::{AtomicUsize, Ordering};

    pub fn entry(name: &str) -> ToolCatalogEntry {
        ToolCatalogEntry {
            name: name.into(),
            title: name.into(),
            description: "d".into(),
            mutates: false,
            long_running: None,
            input_schema: json!({"type": "object", "additionalProperties": false}),
        }
    }

    #[tokio::test]
    async fn not_ready_until_catalog() {
        let r = Relay::default();
        let o = r.call("x", json!({})).await;
        assert_eq!(o["error"]["code"], "EDITOR_NOT_READY");
    }

    #[tokio::test]
    async fn timeout_clears_pending_and_late_answer_is_ignored() {
        let r = Arc::new(Relay::with_deadline(Duration::from_millis(100)));
        r.set_catalog(vec![entry("x")]);
        let seen = Arc::new(Mutex::new(None::<String>));
        let s2 = seen.clone();
        r.set_emitter(move |req| {
            *s2.lock().unwrap() = Some(req.id);
            Ok(())
        });
        let o = r.call("x", json!({})).await;
        assert_eq!(o["error"]["code"], "TIMEOUT");
        assert_eq!(o["ok"], false);
        assert_eq!(r.pending_len(), 0);
        let id = seen.lock().unwrap().clone().unwrap();
        r.respond(RelayResponse { id, outcome: json!({"ok": true}) }); // ignored
        r.respond(RelayResponse { id: "nope".into(), outcome: json!({}) });
        assert_eq!(r.pending_len(), 0);
    }

    #[tokio::test]
    async fn round_trip_and_serialised_calls() {
        let r = Arc::new(Relay::default());
        r.set_catalog(vec![entry("x")]);
        let in_flight = Arc::new(AtomicUsize::new(0));
        let max = Arc::new(AtomicUsize::new(0));
        let (r2, f, m) = (r.clone(), in_flight.clone(), max.clone());
        r.set_emitter(move |req| {
            let (r3, f, m) = (r2.clone(), f.clone(), m.clone());
            tokio::spawn(async move {
                let now = f.fetch_add(1, Ordering::SeqCst) + 1;
                m.fetch_max(now, Ordering::SeqCst);
                tokio::time::sleep(Duration::from_millis(30)).await;
                f.fetch_sub(1, Ordering::SeqCst);
                r3.respond(RelayResponse {
                    id: req.id,
                    outcome: json!({"ok": true, "tool": req.name, "data": req.input}),
                });
            });
            Ok(())
        });
        let calls = (0..5).map(|i| {
            let r = r.clone();
            tokio::spawn(async move { r.call("x", json!({"i": i})).await })
        });
        for (i, h) in calls.collect::<Vec<_>>().into_iter().enumerate() {
            let o = h.await.unwrap();
            assert_eq!(o["ok"], true);
            assert_eq!(o["data"]["i"], i);
        }
        assert_eq!(max.load(Ordering::SeqCst), 1);
        assert_eq!(r.pending_len(), 0);
    }

    #[tokio::test]
    async fn emit_failure_is_internal() {
        let r = Relay::default();
        r.set_catalog(vec![entry("x")]);
        r.set_emitter(|_| Err("no window".into()));
        let o = r.call("x", json!({})).await;
        assert_eq!(o["error"]["code"], "INTERNAL");
        assert_eq!(r.pending_len(), 0);
    }
}
