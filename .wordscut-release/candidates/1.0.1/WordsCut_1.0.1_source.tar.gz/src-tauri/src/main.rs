// Prevents additional console window on Windows in release. Kept for parity even
// though WordsCut is a macOS-only target — costs nothing.
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

mod cli;

fn main() {
    // `WordsCut agent …` and `WordsCut mcp` are the headless agent entry points:
    // they must never start the Tauri runtime (no window, no event loop).
    let args: Vec<String> = std::env::args().skip(1).collect();
    if matches!(args.first().map(String::as_str), Some("agent") | Some("mcp")) {
        std::process::exit(cli::run(&args));
    }
    yusafcut_lib::run()
}
