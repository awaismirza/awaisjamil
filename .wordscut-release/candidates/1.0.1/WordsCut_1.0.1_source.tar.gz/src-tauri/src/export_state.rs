//! Export process ownership. Cancellation of queued or unrelated jobs cannot kill
//! the current export, and cancellation racing with spawn kills the new child.
use tauri_plugin_shell::process::CommandChild;
use tokio::sync::Mutex;
#[derive(Default)]
pub struct ExportState {
    active: Mutex<Option<ActiveExport>>,
}
struct ActiveExport {
    id: String,
    cancelled: bool,
    child: Option<CommandChild>,
}
impl ExportState {
    pub async fn begin(&self, id: &str) {
        *self.active.lock().await = Some(ActiveExport {
            id: id.into(),
            cancelled: false,
            child: None,
        });
    }
    pub async fn register_child(&self, child: CommandChild) -> Result<(), String> {
        let mut slot = self.active.lock().await;
        if let Some(active) = slot.as_mut() {
            if !active.cancelled {
                active.child = Some(child);
                return Ok(());
            }
        }
        let _ = child.kill();
        Err("export cancelled".into())
    }
    pub async fn clear_child(&self) {
        if let Some(active) = self.active.lock().await.as_mut() {
            active.child = None;
        }
    }
    pub async fn finish(&self) {
        *self.active.lock().await = None;
    }
    pub async fn cancel(&self, id: Option<&str>) {
        let mut slot = self.active.lock().await;
        if let Some(active) = slot.as_mut() {
            if id.is_some_and(|id| id != active.id) {
                return;
            }
            active.cancelled = true;
            if let Some(child) = active.child.take() {
                let _ = child.kill();
            }
        }
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[tokio::test]
    async fn unrelated_and_queued_cancellation_leave_active_export_alone() {
        let state = ExportState::default();
        state.begin("first").await;
        state.cancel(Some("queued")).await;
        assert!(!state.active.lock().await.as_ref().unwrap().cancelled);
        state.cancel(Some("first")).await;
        assert!(state.active.lock().await.as_ref().unwrap().cancelled);
        state.finish().await;
        state.begin("next").await;
        assert!(!state.active.lock().await.as_ref().unwrap().cancelled);
    }
}
