//! Scene rendering for export: the background, rounded corners and shadow
//! around the video, built as an ffmpeg filter graph.
//!
//! The frontend resolves every number (`sceneLayout` in `src/lib/scene.ts`), so
//! this module does no layout: it only turns pixels into filters. That keeps
//! the preview and the export identical by construction. Everything here is a
//! pure string builder, so it is tested without spawning ffmpeg; one test also
//! runs the real binary and checks pixels.

use serde::Deserialize;
use std::fmt::Write as _;

#[derive(Debug, Clone, Deserialize, PartialEq)]
#[serde(tag = "kind", rename_all = "lowercase")]
pub enum ResolvedBackground {
    Solid {
        color: String,
    },
    Gradient {
        from: String,
        to: String,
        x0: f64,
        y0: f64,
        x1: f64,
        y1: f64,
    },
    Image {
        path: String,
    },
    /// No background: the canvas outside the picture keeps alpha 0 (see `build_scene_filter`).
    Transparent,
}

/// Source-pixel rectangle kept from the picture before it is laid out.
#[derive(Debug, Clone, Copy, Deserialize, PartialEq)]
pub struct CropPx {
    pub x: u32,
    pub y: u32,
    pub w: u32,
    pub h: u32,
}

/// Pixel rectangle on the canvas (whole numbers from the frontend; rounded here).
#[derive(Debug, Clone, Copy, Deserialize, PartialEq)]
pub struct PxRect {
    pub x: f64,
    pub y: f64,
    pub w: f64,
    pub h: f64,
}

/// One filled rounded rectangle of a device frame (`FrameShape` in deviceFrame.ts).
/// Radii are top-left, top-right, bottom-right, bottom-left.
#[derive(Debug, Clone, Deserialize, PartialEq)]
pub struct FrameShape {
    #[serde(flatten)]
    pub rect: PxRect,
    pub radii: [f64; 4],
    pub color: String,
    #[serde(default = "one")]
    pub alpha: f64,
    /// Part of the outline the shadow is cast from.
    #[serde(default)]
    pub silhouette: bool,
}

fn one() -> f64 {
    1.0
}

/// Text centred on a point (the browser address pill); drawn through ASS.
#[derive(Debug, Clone, Deserialize, PartialEq)]
#[serde(rename_all = "camelCase")]
pub struct FrameText {
    pub text: String,
    pub cx: f64,
    pub cy: f64,
    pub font_px: f64,
    pub color: String,
}

/// A procedural device around the picture, in canvas pixels. The picture
/// (`content_*`) sits inside `screen`, centred, on black; the screen's corners
/// are cut to `screen_radii`.
#[derive(Debug, Clone, Deserialize, PartialEq)]
#[serde(rename_all = "camelCase")]
pub struct FrameRender {
    pub screen: PxRect,
    pub screen_radii: [f64; 4],
    #[serde(default)]
    pub below: Vec<FrameShape>,
    #[serde(default)]
    pub above: Vec<FrameShape>,
    #[serde(default)]
    pub texts: Vec<FrameText>,
}

const MAX_FRAME_SHAPES: usize = 12;
const MAX_FRAME_TEXTS: usize = 4;
const MAX_FRAME_TEXT_CHARS: usize = 200;

/// A scene with every dimension in output pixels.
#[derive(Debug, Clone, Deserialize, PartialEq)]
#[serde(rename_all = "camelCase")]
pub struct SceneRender {
    pub canvas_w: u32,
    pub canvas_h: u32,
    pub content_x: u32,
    pub content_y: u32,
    pub content_w: u32,
    pub content_h: u32,
    pub radius_px: f64,
    pub shadow_sigma_px: f64,
    pub shadow_opacity: f64,
    pub shadow_offset_y: f64,
    pub background: ResolvedBackground,
    /// Crop of the source picture, applied before it is scaled onto the canvas.
    #[serde(default)]
    pub crop: Option<CropPx>,
    /// Device around the picture. `None` = the plain rounded box.
    #[serde(default)]
    pub frame: Option<FrameRender>,
}

/// A validated shape: whole pixels inside the canvas, radii that fit, colour checked.
struct CheckedShape {
    x: i64,
    y: i64,
    w: i64,
    h: i64,
    radii: [f64; 4],
    color: String,
    alpha: f64,
    silhouette: bool,
}

struct CheckedFrame {
    sx: i64,
    sy: i64,
    sw: i64,
    sh: i64,
    radii: [f64; 4],
    below: Vec<CheckedShape>,
    above: Vec<CheckedShape>,
}

fn whole(v: f64, what: &str) -> Result<i64, String> {
    if v.is_finite() && v.abs() < 100_000.0 {
        Ok(v.round() as i64)
    } else {
        Err(format!("device frame {what} is not a usable number"))
    }
}

/// A rectangle fully inside the canvas, in whole pixels.
fn check_rect(r: &PxRect, cw: u32, ch: u32, what: &str) -> Result<(i64, i64, i64, i64), String> {
    let (x, y, w, h) = (whole(r.x, what)?, whole(r.y, what)?, whole(r.w, what)?, whole(r.h, what)?);
    if w < 1 || h < 1 || x < 0 || y < 0 || x + w > cw as i64 || y + h > ch as i64 {
        return Err(format!("device frame {what} does not fit on the canvas"));
    }
    Ok((x, y, w, h))
}

/// Radii that are finite, non-negative and no bigger than half the shorter side.
fn check_radii(r: &[f64; 4], w: i64, h: i64) -> [f64; 4] {
    let m = (w.min(h) / 2) as f64;
    r.map(|v| if v.is_finite() { v.clamp(0.0, m) } else { 0.0 })
}

fn check_shapes(list: &[FrameShape], cw: u32, ch: u32) -> Result<Vec<CheckedShape>, String> {
    list.iter()
        .map(|s| {
            let (x, y, w, h) = check_rect(&s.rect, cw, ch, "shape")?;
            ffmpeg_color(&s.color)?;
            Ok(CheckedShape {
                x,
                y,
                w,
                h,
                radii: check_radii(&s.radii, w, h),
                color: ffmpeg_color(&s.color)?,
                alpha: if s.alpha.is_finite() { s.alpha.clamp(0.0, 1.0) } else { 1.0 },
                silhouette: s.silhouette,
            })
        })
        .collect()
}

fn check_frame(f: &FrameRender, cw: u32, ch: u32, content: (u32, u32, u32, u32)) -> Result<CheckedFrame, String> {
    if f.below.len() > MAX_FRAME_SHAPES || f.above.len() > MAX_FRAME_SHAPES || f.texts.len() > MAX_FRAME_TEXTS {
        return Err("device frame has too many shapes".into());
    }
    let (sx, sy, sw, sh) = check_rect(&f.screen, cw, ch, "screen")?;
    let (cx, cy, cwid, chei) = content;
    if (cx as i64) < sx || (cy as i64) < sy || (cx + cwid) as i64 > sx + sw || (cy + chei) as i64 > sy + sh {
        return Err("the picture does not fit inside the device screen".into());
    }
    Ok(CheckedFrame {
        sx,
        sy,
        sw,
        sh,
        radii: check_radii(&f.screen_radii, sw, sh),
        below: check_shapes(&f.below, cw, ch)?,
        above: check_shapes(&f.above, cw, ch)?,
    })
}

impl SceneRender {
    /// Device text as an ASS script for a canvas-sized frame, or `None` when there is none.
    /// Drawn by an `ass` stage right after the scene (see `export.rs`).
    pub fn frame_text_ass(&self, duration_sec: f64) -> Option<String> {
        let f = self.frame.as_ref()?;
        // Shown for the whole export: its length plus a second of margin (ASS `h:mm:ss.cc`).
        let secs = if duration_sec.is_finite() { duration_sec.clamp(0.0, 86_400.0) } else { 0.0 };
        let cs = ((secs + 1.0) * 100.0).ceil() as u64;
        let end = format!("{}:{:02}:{:02}.{:02}", cs / 360_000, cs / 6000 % 60, cs / 100 % 60, cs % 100);
        let lines: Vec<String> = f
            .texts
            .iter()
            .take(MAX_FRAME_TEXTS)
            .filter_map(|t| {
                let text: String = t
                    .text
                    .chars()
                    .filter(|c| !c.is_control() && !crate::annotations_export::is_emoji(*c))
                    .take(MAX_FRAME_TEXT_CHARS)
                    .collect();
                let hex = t.color.strip_prefix('#').unwrap_or(&t.color);
                let ok = hex.len() == 6 && hex.chars().all(|c| c.is_ascii_hexdigit());
                if text.trim().is_empty() || !ok || !t.font_px.is_finite() || t.font_px < 1.0 || t.font_px > 2000.0 {
                    return None;
                }
                if !t.cx.is_finite() || !t.cy.is_finite() {
                    return None;
                }
                let bgr = format!("{}{}{}", &hex[4..6], &hex[2..4], &hex[0..2]).to_uppercase();
                Some(format!(
                    "Dialogue: 0,0:00:00.00,{end},Frame,,0,0,0,,{{\\an5\\pos({:.2},{:.2})\\fs{:.2}\\bord0\\shad0\\1c&H{bgr}&}}{}",
                    t.cx,
                    t.cy,
                    t.font_px / crate::annotations_export::EM_PER_FS,
                    crate::annotations_export::escape_text(&text),
                ))
            })
            .collect();
        if lines.is_empty() {
            return None;
        }
        Some(format!(
            "[Script Info]\nScriptType: v4.00+\nPlayResX: {}\nPlayResY: {}\nScaledBorderAndShadow: yes\nWrapStyle: 2\n[V4+ Styles]\n\
             Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\n\
             Style: Frame,{},20,&H00FFFFFF,&H00FFFFFF,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,0,0,5,0,0,0,1\n\
             [Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n{}\n",
            self.canvas_w,
            self.canvas_h,
            crate::annotations_export::FONT,
            lines.join("\n"),
        ))
    }
}

impl SceneRender {
    /// Path of the background image, when the background is one.
    pub fn image_path(&self) -> Option<&str> {
        match &self.background {
            ResolvedBackground::Image { path } => Some(path),
            _ => None,
        }
    }

    fn has_shadow(&self) -> bool {
        self.shadow_opacity > 0.001 && self.shadow_sigma_px > 0.05
    }
}

/// `#rrggbb` -> `0xrrggbb`, rejecting anything else so no stray text reaches a filter.
fn ffmpeg_color(hex: &str) -> Result<String, String> {
    let h = hex.strip_prefix('#').unwrap_or(hex);
    if h.len() == 6 && h.chars().all(|c| c.is_ascii_hexdigit()) {
        Ok(format!("0x{h}"))
    } else {
        Err(format!("invalid colour: {hex:?}"))
    }
}

/// `geq` expression: 255 inside a rounded rectangle, 0 outside, with a one
/// pixel soft edge on the corners. The rectangle's top-left is (`ox`, `oy`).
fn rounded_rect_mask(ox: f64, oy: f64, w: f64, h: f64, r: f64) -> String {
    // Pixel centres, relative to the rectangle.
    let x = format!("(X+0.5-{ox:.3})");
    let y = format!("(Y+0.5-{oy:.3})");
    let inside = format!("gte({x},0)*lt({x},{w:.3})*gte({y},0)*lt({y},{h:.3})");
    if r < 0.5 {
        return format!("255*{inside}");
    }
    let corner = |cx: String, cy: String| format!("clip({:.3}+0.5-hypot({x}-{cx},{y}-{cy}),0,1)", r);
    let (rx, by) = (w - r, h - r);
    let tl = corner(format!("{r:.3}"), format!("{r:.3}"));
    let tr = corner(format!("{rx:.3}"), format!("{r:.3}"));
    let bl = corner(format!("{r:.3}"), format!("{by:.3}"));
    let br = corner(format!("{rx:.3}"), format!("{by:.3}"));
    format!(
        "255*{inside}*if(lt({x},{r:.3})*lt({y},{r:.3}),{tl},\
         if(gt({x},{rx:.3})*lt({y},{r:.3}),{tr},\
         if(lt({x},{r:.3})*gt({y},{by:.3}),{bl},\
         if(gt({x},{rx:.3})*gt({y},{by:.3}),{br},1))))"
    )
}

/// Like `rounded_rect_mask`, with a separate radius per corner (top-left,
/// top-right, bottom-right, bottom-left). Corners under half a pixel stay square.
fn rounded_rect_mask_radii(ox: f64, oy: f64, w: f64, h: f64, radii: [f64; 4]) -> String {
    let x = format!("(X+0.5-{ox:.3})");
    let y = format!("(Y+0.5-{oy:.3})");
    let inside = format!("gte({x},0)*lt({x},{w:.3})*gte({y},0)*lt({y},{h:.3})");
    let [tl, tr, br, bl] = radii;
    // (radius, x-range test, y-range test, arc centre)
    let corner = |r: f64, cx: f64, cy: f64| format!("clip({r:.3}+0.5-hypot({x}-{cx:.3},{y}-{cy:.3}),0,1)");
    let mut parts: Vec<(String, String)> = Vec::new();
    if tl >= 0.5 {
        parts.push((format!("lt({x},{tl:.3})*lt({y},{tl:.3})"), corner(tl, tl, tl)));
    }
    if tr >= 0.5 {
        parts.push((format!("gt({x},{:.3})*lt({y},{tr:.3})", w - tr), corner(tr, w - tr, tr)));
    }
    if br >= 0.5 {
        parts.push((format!("gt({x},{:.3})*gt({y},{:.3})", w - br, h - br), corner(br, w - br, h - br)));
    }
    if bl >= 0.5 {
        parts.push((format!("lt({x},{bl:.3})*gt({y},{:.3})", h - bl), corner(bl, bl, h - bl)));
    }
    let mut tail = "1".to_string();
    for (test, value) in parts.into_iter().rev() {
        tail = format!("if({test},{value},{tail})");
    }
    format!("255*{inside}*{tail}")
}

/// Stage lines that draw each shape on `base`: a flat colour cut by a rounded
/// mask (made once at 1 fps like the picture's mask), overlaid at its position.
/// Returns the label of the last result. `tag` keeps labels unique.
fn draw_shapes(g: &mut String, shapes: &[CheckedShape], tag: &str, pf: &str, mut base: String) -> String {
    for (i, s) in shapes.iter().enumerate() {
        let mask = rounded_rect_mask_radii(0.0, 0.0, s.w as f64, s.h as f64, s.radii);
        let out = format!("sc{tag}b{i}");
        let _ = write!(
            g,
            // One frame each (`d=1`); overlay repeats the last frame, so `geq` runs once.
            "color=c={}:s={}x{}:r=1:d=1,format={pf}[sc{tag}s{i}];\
             color=c=black:s={}x{}:r=1:d=1,format=gray,geq=lum='({mask})*{:.3}'[sc{tag}m{i}];\
             [sc{tag}s{i}][sc{tag}m{i}]alphamerge[sc{tag}p{i}];\
             [{base}][sc{tag}p{i}]overlay=x={}:y={}:format=auto[{out}];",
            s.color, s.w, s.h, s.w, s.h, s.alpha, s.x, s.y
        );
        base = out;
    }
    base
}

/// Filter graph that places `[input]` on the scene canvas and outputs `[output]`.
///
/// `fps` is the output frame rate (the background must match it, because the
/// first overlay input sets the pace). `image_input` is the ffmpeg input index
/// of the background image when the background is an image; the caller adds
/// that input with `-loop 1`.
///
/// `source` is the pixel size of the picture entering the scene; a crop is clamped to it
/// so a stale or oversized rectangle never reaches ffmpeg.
///
/// `keep_alpha` is true only when the output format can hold transparency. A
/// transparent background then stays alpha 0 and the output is `yuva444p`;
/// otherwise it is flattened onto black so the file never looks opaque by accident.
pub fn build_scene_filter(
    s: &SceneRender,
    fps: f64,
    image_input: Option<usize>,
    input: &str,
    output: &str,
    source: (u32, u32),
    keep_alpha: bool,
) -> Result<String, String> {
    if s.canvas_w < 2 || s.canvas_h < 2 || s.content_w < 2 || s.content_h < 2 {
        return Err("scene has an empty canvas or content area".into());
    }
    if s.content_x + s.content_w > s.canvas_w || s.content_y + s.content_h > s.canvas_h {
        return Err("scene content does not fit on the canvas".into());
    }
    let fps = if fps.is_finite() && fps > 0.0 { fps } else { 30.0 };
    let (cw, ch) = (s.canvas_w, s.canvas_h);
    let (vw, vh) = (s.content_w, s.content_h);
    let frame = match &s.frame {
        Some(f) => Some(check_frame(f, cw, ch, (s.content_x, s.content_y, vw, vh))?),
        None => None,
    };

    // A transparent background only stays transparent when the format can hold it.
    let alpha = keep_alpha && s.background == ResolvedBackground::Transparent;
    // Alpha formats (ProRes 4444) stay 4:4:4 throughout, transparent or not, so
    // rounded corners have no chroma fringe and nothing is subsampled on the way.
    let pf = if keep_alpha { "yuva444p" } else { "yuva420p" };
    let mut g = String::new();

    // Background -> [scbg]
    match &s.background {
        ResolvedBackground::Transparent if alpha => {
            let _ = write!(g, "color=c=black@0.0:s={cw}x{ch}:r={fps},format={pf}[scbg];");
        }
        ResolvedBackground::Transparent => {
            let _ = write!(g, "color=c=black:s={cw}x{ch}:r={fps}[scbg];");
        }
        ResolvedBackground::Solid { color } => {
            let c = ffmpeg_color(color)?;
            let _ = write!(g, "color=c={c}:s={cw}x{ch}:r={fps}[scbg];");
        }
        ResolvedBackground::Gradient { from, to, x0, y0, x1, y1 } => {
            let (c0, c1) = (ffmpeg_color(from)?, ffmpeg_color(to)?);
            let _ = write!(
                g,
                "gradients=s={cw}x{ch}:r={fps}:c0={c0}:c1={c1}:x0={}:y0={}:x1={}:y1={}:speed=0:seed=0[scbg];",
                x0.round() as i64,
                y0.round() as i64,
                x1.round() as i64,
                y1.round() as i64,
            );
        }
        ResolvedBackground::Image { .. } => {
            let idx = image_input.ok_or("image background needs an input index")?;
            let _ = write!(
                g,
                "[{idx}:v]fps={fps},scale={cw}:{ch}:force_original_aspect_ratio=increase,\
                 crop={cw}:{ch},setsar=1[scbg];"
            );
        }
    }

    // Video, rounded by a mask -> [scclip]
    // The crop (if any) is cut from the picture first, so padding and aspect see the cropped size.
    let crop = match s.crop {
        Some(c) => {
            let (sw, sh) = (source.0 & !1, source.1 & !1);
            if sw < 2 || sh < 2 {
                return Err("crop needs a source with a size".into());
            }
            let (w, h) = ((c.w & !1).clamp(2, sw), (c.h & !1).clamp(2, sh));
            let (x, y) = ((c.x & !1).min(sw - w), (c.y & !1).min(sh - h));
            format!("crop={w}:{h}:{x}:{y},")
        }
        None => String::new(),
    };
    // With a device the picture is padded with black to the screen's size (it is
    // letterboxed when the screen has another aspect) and cut by the screen's corners.
    let pad = match &frame {
        Some(f) if (f.sw, f.sh) != (vw as i64, vh as i64) => {
            format!("pad={}:{}:{}:{}:color=black,", f.sw, f.sh, s.content_x as i64 - f.sx, s.content_y as i64 - f.sy)
        }
        _ => String::new(),
    };
    let _ = write!(g, "[{input}]{crop}scale={vw}:{vh}:flags=lanczos,{pad}setsar=1,format={pf}[scvid];");
    if let Some(f) = &frame {
        if f.radii.iter().any(|r| *r >= 0.5) {
            let mask = rounded_rect_mask_radii(0.0, 0.0, f.sw as f64, f.sh as f64, f.radii);
            let _ = write!(
                g,
                // One frame, cached and looped: `geq` runs once, not once per second.
                "color=c=black:s={}x{}:r=1:d=1,format=gray,geq=lum='{mask}',loop=loop=-1:size=1[scmask];\
                 [scvid][scmask]alphamerge=shortest=1[scclip];",
                f.sw, f.sh
            );
        } else {
            let _ = write!(g, "[scvid]null[scclip];");
        }
    } else if s.radius_px >= 0.5 {
        let mask = rounded_rect_mask(0.0, 0.0, vw as f64, vh as f64, s.radius_px);
        let _ = write!(
            g,
            "color=c=black:s={vw}x{vh}:r=1,format=gray,geq=lum='{mask}'[scmask];\
             [scvid][scmask]alphamerge=shortest=1[scclip];"
        );
    } else {
        let _ = write!(g, "[scvid]null[scclip];");
    }

    // Shadow: the same rounded rectangle, blurred and tinted black -> [scshadow]
    // With a device the shadow is cast by its outline (the silhouette shapes).
    let silhouette: Vec<&CheckedShape> =
        frame.iter().flat_map(|f| f.below.iter()).filter(|b| b.silhouette).collect();
    let has_shadow = s.has_shadow() && (frame.is_none() || !silhouette.is_empty());
    // The device path renders each mask ONCE (one frame, held by overlay's repeat) instead of
    // re-running `geq` every second. ponytail: the pre-existing plain-box path keeps its
    // `r=1` sources so the default argv stays byte-identical; they cost one geq per output second.
    let (once, shortest) = if frame.is_some() { (":d=1", "") } else { ("", "shortest=1:") };
    let base = if has_shadow {
        let mask = if frame.is_some() {
            let masks: Vec<String> = silhouette
                .iter()
                .map(|b| rounded_rect_mask_radii(b.x as f64, b.y as f64 + s.shadow_offset_y, b.w as f64, b.h as f64, b.radii))
                .collect();
            masks.into_iter().reduce(|a, b| format!("max({a},{b})")).unwrap_or_default()
        } else {
            rounded_rect_mask(
                s.content_x as f64,
                s.content_y as f64 + s.shadow_offset_y,
                vw as f64,
                vh as f64,
                s.radius_px,
            )
        };
        let _ = write!(
            g,
            "color=c=black:s={cw}x{ch}:r=1{once},format=gray,geq=lum='{mask}',\
             gblur=sigma={:.3},lut=y='val*{:.3}'[scsmask];\
             color=c=black:s={cw}x{ch}:r=1{once},format={pf}[scsblack];\
             [scsblack][scsmask]alphamerge[scshadow];\
             [scbg][scshadow]overlay={shortest}format=auto[scbase];",
            s.shadow_sigma_px,
            s.shadow_opacity.clamp(0.0, 1.0),
        );
        "scbase"
    } else {
        "scbg"
    };

    let out_fmt = if keep_alpha { "yuva444p" } else { "yuv420p" };
    if let Some(f) = &frame {
        // Device: outline shapes, the screen with the picture, then what sits over it.
        let base = draw_shapes(&mut g, &f.below, "d", pf, base.to_string());
        let _ = write!(
            g,
            "[{base}][scclip]overlay=x={}:y={}:shortest=1:format=auto[scpic];",
            f.sx, f.sy
        );
        let last = draw_shapes(&mut g, &f.above, "o", pf, "scpic".to_string());
        let _ = write!(g, "[{last}]format={out_fmt}[{output}]");
        return Ok(g);
    }
    let _ = write!(
        g,
        "[{base}][scclip]overlay=x={}:y={}:shortest=1:format=auto,format={out_fmt}[{output}]",
        s.content_x, s.content_y
    );
    Ok(g)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn scene(background: ResolvedBackground) -> SceneRender {
        SceneRender {
            canvas_w: 800,
            canvas_h: 600,
            content_x: 80,
            content_y: 120,
            content_w: 640,
            content_h: 360,
            radius_px: 40.0,
            shadow_sigma_px: 0.0,
            shadow_opacity: 0.0,
            shadow_offset_y: 0.0,
            background,
            crop: None,
            frame: None,
        }
    }

    fn solid(c: &str) -> ResolvedBackground {
        ResolvedBackground::Solid { color: c.into() }
    }

    #[test]
    fn deserialises_the_frontend_payload() {
        let json = r##"{
            "canvasW": 1920, "canvasH": 1080,
            "contentX": 100, "contentY": 50, "contentW": 1720, "contentH": 980,
            "radiusPx": 30, "shadowSigmaPx": 20, "shadowOpacity": 0.4, "shadowOffsetY": 16,
            "background": {"kind": "gradient", "from": "#000000", "to": "#ffffff",
                           "x0": 0, "y0": 0, "x1": 1920, "y1": 1080}
        }"##;
        let s: SceneRender = serde_json::from_str(json).unwrap();
        assert_eq!(s.canvas_w, 1920);
        assert!(matches!(s.background, ResolvedBackground::Gradient { .. }));
        let img = r##"{"kind":"image","path":"/tmp/a.png"}"##;
        assert!(matches!(
            serde_json::from_str::<ResolvedBackground>(img).unwrap(),
            ResolvedBackground::Image { .. }
        ));
    }

    #[test]
    fn solid_background_uses_the_canvas_size_and_rate() {
        let f = build_scene_filter(&scene(solid("#1a2b3c")), 60.0, None, "catv", "outv", (640, 360), false).unwrap();
        assert!(f.contains("color=c=0x1a2b3c:s=800x600:r=60[scbg]"));
        assert!(f.ends_with("[outv]"));
        assert!(f.contains("[catv]scale=640:360"));
        assert!(f.contains("overlay=x=80:y=120"));
    }

    #[test]
    fn gradient_background_uses_rounded_endpoints() {
        let bg = ResolvedBackground::Gradient {
            from: "#000000".into(),
            to: "#ffffff".into(),
            x0: 0.4,
            y0: 0.6,
            x1: 799.5,
            y1: 599.4,
        };
        let f = build_scene_filter(&scene(bg), 30.0, None, "a", "b", (640, 360), false).unwrap();
        assert!(f.contains("gradients=s=800x600:r=30:c0=0x000000:c1=0xffffff:x0=0:y0=1:x1=800:y1=599:speed=0"));
    }

    #[test]
    fn gradient_initialisation_has_a_fixed_seed_for_repeatable_exports() {
        let s = scene(ResolvedBackground::Gradient { from: "#000000".into(), to: "#ffffff".into(), x0: 0.0, y0: 0.0, x1: 800.0, y1: 0.0 });
        assert!(build_scene_filter(&s, 30.0, None, "a", "b", (640, 360), false).unwrap().contains(":speed=0:seed=0[scbg]"));
    }

    #[test]
    fn image_background_reads_the_given_input() {
        let bg = ResolvedBackground::Image { path: "/x.png".into() };
        let f = build_scene_filter(&scene(bg), 30.0, Some(2), "a", "b", (640, 360), false).unwrap();
        assert!(f.contains("[2:v]fps=30,scale=800:600:force_original_aspect_ratio=increase,crop=800:600"));
    }

    #[test]
    fn image_background_without_an_input_is_an_error() {
        let bg = ResolvedBackground::Image { path: "/x.png".into() };
        assert!(build_scene_filter(&scene(bg), 30.0, None, "a", "b", (640, 360), false).is_err());
    }

    #[test]
    fn rejects_colours_that_could_inject_filter_text() {
        for bad in ["red", "#12345", "#12345g", "#123456;movie=/etc/passwd", ""] {
            let r = build_scene_filter(&scene(solid(bad)), 30.0, None, "a", "b", (640, 360), false);
            assert!(r.is_err(), "{bad:?} should be rejected");
        }
    }

    #[test]
    fn rejects_content_that_does_not_fit() {
        let mut s = scene(solid("#000000"));
        s.content_x = 400;
        assert!(build_scene_filter(&s, 30.0, None, "a", "b", (640, 360), false).is_err());
        let mut s = scene(solid("#000000"));
        s.content_w = 0;
        assert!(build_scene_filter(&s, 30.0, None, "a", "b", (640, 360), false).is_err());
    }

    #[test]
    fn shadow_is_only_built_when_visible() {
        let none = build_scene_filter(&scene(solid("#000000")), 30.0, None, "a", "b", (640, 360), false).unwrap();
        assert!(!none.contains("gblur"));
        let mut s = scene(solid("#000000"));
        s.shadow_sigma_px = 20.0;
        s.shadow_opacity = 0.5;
        s.shadow_offset_y = 16.0;
        let some = build_scene_filter(&s, 30.0, None, "a", "b", (640, 360), false).unwrap();
        assert!(some.contains("gblur=sigma=20.000"));
        assert!(some.contains("lut=y='val*0.500'"));
    }

    #[test]
    fn the_rounded_clip_ends_with_the_video_not_the_endless_mask() {
        let f = build_scene_filter(&scene(solid("#000000")), 30.0, None, "a", "b", (640, 360), false).unwrap();
        assert!(f.contains("alphamerge=shortest=1[scclip]"));
        assert!(f.contains("overlay=x=80:y=120:shortest=1"));
    }

    #[test]
    fn square_corners_skip_the_mask() {
        let mut s = scene(solid("#000000"));
        s.radius_px = 0.0;
        let f = build_scene_filter(&s, 30.0, None, "a", "b", (640, 360), false).unwrap();
        assert!(!f.contains("alphamerge=shortest=1[scclip]"));
        assert!(f.contains("[scvid]null[scclip]"));
    }

    #[test]
    fn falls_back_to_30_fps_for_a_bad_rate() {
        let f = build_scene_filter(&scene(solid("#000000")), f64::NAN, None, "a", "b", (640, 360), false).unwrap();
        assert!(f.contains(":r=30[scbg]"));
    }

    // -----------------------------------------------------------------------
    // Real ffmpeg: render one frame and look at pixels.
    // -----------------------------------------------------------------------

    fn ffmpeg_binary() -> Option<std::path::PathBuf> {
        let p = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("binaries/ffmpeg-aarch64-apple-darwin");
        // The fetched binary is a large executable; a stub or missing file means skip.
        let ok = std::fs::metadata(&p).map(|m| m.len() > 1_000_000).unwrap_or(false);
        let runs = ok
            && std::process::Command::new(&p)
                .arg("-version")
                .output()
                .map(|o| o.status.success())
                .unwrap_or(false);
        runs.then_some(p)
    }

    /// Render the scene over a solid red 640x360 video and return RGB24 pixels.
    fn render_frame(s: &SceneRender, ffmpeg: &std::path::Path) -> Vec<u8> {
        let graph = build_scene_filter(s, 30.0, None, "catv", "outv", (640, 360), false).unwrap();
        let out = std::process::Command::new(ffmpeg)
            .args(["-v", "error", "-f", "lavfi", "-i", "color=c=red:s=640x360:r=30:d=1"])
            .args(["-filter_complex", &format!("[0:v]format=yuv420p[catv];{graph}")])
            .args(["-map", "[outv]", "-frames:v", "1", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"])
            .output()
            .expect("run ffmpeg");
        assert!(
            out.status.success(),
            "ffmpeg failed: {}\ngraph: {graph}",
            String::from_utf8_lossy(&out.stderr)
        );
        assert_eq!(out.stdout.len(), (s.canvas_w * s.canvas_h * 3) as usize, "frame size");
        out.stdout
    }

    fn px(frame: &[u8], w: u32, x: u32, y: u32) -> [i32; 3] {
        let i = ((y * w + x) * 3) as usize;
        [frame[i] as i32, frame[i + 1] as i32, frame[i + 2] as i32]
    }

    fn near(a: [i32; 3], b: [i32; 3], tol: i32) -> bool {
        a.iter().zip(b).all(|(x, y)| (x - y).abs() <= tol)
    }

    #[test]
    fn real_ffmpeg_draws_background_video_and_rounded_corners() {
        let Some(ffmpeg) = ffmpeg_binary() else {
            eprintln!("skipping: bundled ffmpeg not present");
            return;
        };
        let s = scene(solid("#0000ff"));
        let f = render_frame(&s, &ffmpeg);
        let w = s.canvas_w;
        // Canvas edge is the blue background.
        assert!(near(px(&f, w, 2, 2), [0, 0, 255], 8), "background {:?}", px(&f, w, 2, 2));
        // Centre of the video is red.
        assert!(near(px(&f, w, 400, 300), [255, 0, 0], 12), "video {:?}", px(&f, w, 400, 300));
        // Just inside the video's square corner, outside the 40 px arc: background shows through.
        assert!(near(px(&f, w, 82, 122), [0, 0, 255], 12), "corner {:?}", px(&f, w, 82, 122));
        // Along the straight top edge, well inside the corner arcs: video.
        assert!(near(px(&f, w, 400, 122), [255, 0, 0], 12), "top edge {:?}", px(&f, w, 400, 122));
        // The padding strip between canvas and video is background.
        assert!(near(px(&f, w, 40, 300), [0, 0, 255], 8));
    }

    #[test]
    fn real_ffmpeg_square_corners_keep_the_video_corner() {
        let Some(ffmpeg) = ffmpeg_binary() else {
            return;
        };
        let mut s = scene(solid("#0000ff"));
        s.radius_px = 0.0;
        let f = render_frame(&s, &ffmpeg);
        assert!(near(px(&f, s.canvas_w, 82, 122), [255, 0, 0], 12));
    }

    #[test]
    fn real_ffmpeg_shadow_darkens_beside_the_video_only() {
        let Some(ffmpeg) = ffmpeg_binary() else {
            return;
        };
        let mut s = scene(solid("#ffffff"));
        s.shadow_sigma_px = 14.0;
        s.shadow_opacity = 0.6;
        s.shadow_offset_y = 10.0;
        let f = render_frame(&s, &ffmpeg);
        let w = s.canvas_w;
        // Just below the video (y = 480..) the shadow darkens the white background...
        let near_shadow = px(&f, w, 400, 490);
        assert!(near_shadow[0] < 235, "expected a shadow, got {near_shadow:?}");
        // ...and fades to plain background far away.
        assert!(near(px(&f, w, 400, 596), [255, 255, 255], 6));
        assert!(near(px(&f, w, 2, 2), [255, 255, 255], 4));
    }

    #[test]
    fn real_ffmpeg_gradient_changes_across_the_canvas() {
        let Some(ffmpeg) = ffmpeg_binary() else {
            return;
        };
        let s = scene(ResolvedBackground::Gradient {
            from: "#000000".into(),
            to: "#ffffff".into(),
            x0: 0.0,
            y0: 0.0,
            x1: 800.0,
            y1: 0.0,
        });
        let f = render_frame(&s, &ffmpeg);
        let left = px(&f, s.canvas_w, 5, 5);
        let right = px(&f, s.canvas_w, 794, 5);
        assert!(left[0] < 40, "left {left:?}");
        assert!(right[0] > 215, "right {right:?}");
    }

    #[test]
    fn real_ffmpeg_accepts_a_portrait_canvas() {
        let Some(ffmpeg) = ffmpeg_binary() else {
            return;
        };
        let s = SceneRender {
            canvas_w: 540,
            canvas_h: 960,
            content_x: 20,
            content_y: 360,
            content_w: 500,
            content_h: 240,
            radius_px: 20.0,
            shadow_sigma_px: 8.0,
            shadow_opacity: 0.4,
            shadow_offset_y: 6.0,
            background: solid("#101010"),
            crop: None,
            frame: None,
        };
        let f = render_frame(&s, &ffmpeg);
        assert!(near(px(&f, 540, 270, 480), [255, 0, 0], 12));
        assert!(near(px(&f, 540, 270, 20), [16, 16, 16], 6));
    }

    // -----------------------------------------------------------------------
    // Crop and transparency, checked on real pixels.
    // -----------------------------------------------------------------------

    /// Render a 640x360 source that is red on the left half and green on the
    /// right half, and return RGBA pixels.
    fn render_rgba(s: &SceneRender, ffmpeg: &std::path::Path, keep_alpha: bool) -> Vec<u8> {
        let graph = build_scene_filter(s, 30.0, None, "catv", "outv", (640, 360), keep_alpha).unwrap();
        let src = "color=c=red:s=320x360:r=30:d=1[l];color=c=0x00ff00:s=320x360:r=30:d=1[r];\
                   [l][r]hstack,format=yuv420p[catv]";
        let out = std::process::Command::new(ffmpeg)
            .args(["-v", "error", "-filter_complex", &format!("{src};{graph}")])
            .args(["-map", "[outv]", "-frames:v", "1", "-f", "rawvideo", "-pix_fmt", "rgba", "-"])
            .output()
            .expect("run ffmpeg");
        assert!(out.status.success(), "ffmpeg failed: {}\ngraph: {graph}", String::from_utf8_lossy(&out.stderr));
        assert_eq!(out.stdout.len(), (s.canvas_w * s.canvas_h * 4) as usize);
        out.stdout
    }

    fn rgba(frame: &[u8], w: u32, x: u32, y: u32) -> [i32; 4] {
        let i = ((y * w + x) * 4) as usize;
        [frame[i] as i32, frame[i + 1] as i32, frame[i + 2] as i32, frame[i + 3] as i32]
    }

    #[test]
    fn crop_runs_before_the_scale_and_is_in_the_graph() {
        let mut s = scene(solid("#000000"));
        s.crop = Some(CropPx { x: 320, y: 0, w: 320, h: 360 });
        let f = build_scene_filter(&s, 30.0, None, "catv", "outv", (640, 360), false).unwrap();
        assert!(f.contains("[catv]crop=320:360:320:0,scale=640:360"), "{f}");
        let plain = build_scene_filter(&scene(solid("#000000")), 30.0, None, "catv", "outv", (640, 360), false).unwrap();
        assert!(!plain.contains("crop="));
    }

    #[test]
    fn real_ffmpeg_crop_keeps_only_the_chosen_part_of_the_picture() {
        let Some(ffmpeg) = ffmpeg_binary() else { return };
        // Keep the right (green) half; content is the usual 640x360 box.
        let mut s = scene(solid("#0000ff"));
        s.radius_px = 0.0;
        s.crop = Some(CropPx { x: 320, y: 0, w: 320, h: 360 });
        let f = render_rgba(&s, &ffmpeg, false);
        let w = s.canvas_w;
        for (x, y) in [(90, 130), (400, 300), (710, 470)] {
            let p = rgba(&f, w, x, y);
            assert!(p[0] < 30 && p[1] > 225 && p[2] < 30, "({x},{y}) should be green only: {p:?}");
        }
        assert!(near(px_rgb(&f, w, 40, 300), [0, 0, 255], 8));
    }

    fn px_rgb(frame: &[u8], w: u32, x: u32, y: u32) -> [i32; 3] {
        let p = rgba(frame, w, x, y);
        [p[0], p[1], p[2]]
    }

    #[test]
    fn real_ffmpeg_transparent_background_has_alpha_zero_outside_and_255_inside() {
        let Some(ffmpeg) = ffmpeg_binary() else { return };
        let mut s = scene(ResolvedBackground::Transparent);
        s.radius_px = 0.0;
        let f = render_rgba(&s, &ffmpeg, true);
        let w = s.canvas_w;
        assert_eq!(rgba(&f, w, 20, 20)[3], 0, "padding must be transparent");
        assert_eq!(rgba(&f, w, 790, 590)[3], 0);
        let inside = rgba(&f, w, 200, 300);
        assert_eq!(inside[3], 255, "content must be opaque");
        assert!(inside[0] > 225 && inside[1] < 30, "left half is red: {inside:?}");
    }

    #[test]
    fn crop_is_clamped_to_the_real_source_size() {
        let mut s = scene(solid("#000000"));
        s.crop = Some(CropPx { x: 1500, y: 9, w: 4000, h: 0 });
        let f = build_scene_filter(&s, 30.0, None, "a", "b", (1280, 720), false).unwrap();
        assert!(f.contains("[a]crop=1280:2:0:8,"), "{f}");
        s.crop = Some(CropPx { x: 1000, y: 0, w: 640, h: 360 });
        let f = build_scene_filter(&s, 30.0, None, "a", "b", (1280, 720), false).unwrap();
        assert!(f.contains("crop=640:360:640:0,"), "{f}");
        assert!(build_scene_filter(&s, 30.0, None, "a", "b", (0, 0), false).is_err());
    }

    #[test]
    fn alpha_formats_stay_444_even_without_a_transparent_background() {
        let f = build_scene_filter(&scene(solid("#000000")), 30.0, None, "a", "b", (640, 360), true).unwrap();
        assert!(f.contains("format=yuva444p[scvid]") && f.ends_with("format=yuva444p[b]"), "{f}");
        let g = build_scene_filter(&scene(solid("#000000")), 30.0, None, "a", "b", (640, 360), false).unwrap();
        assert!(g.ends_with("format=yuv420p[b]"));
    }

    #[test]
    fn real_ffmpeg_rounded_corner_edges_keep_the_video_colour_with_partial_alpha() {
        let Some(ffmpeg) = ffmpeg_binary() else { return };
        let s = scene(ResolvedBackground::Transparent); // radius 40 at (80,120)
        let f = render_rgba(&s, &ffmpeg, true);
        let w = s.canvas_w;
        let mut partial = 0;
        for y in 120..170 {
            for x in 80..130 {
                let p = rgba(&f, w, x, y);
                if p[3] > 20 && p[3] < 235 {
                    partial += 1;
                    assert!(p[0] > 215 && p[1] < 40, "edge pixel ({x},{y}) darkened: {p:?}");
                }
            }
        }
        assert!(partial > 5, "expected anti-aliased edge pixels, saw {partial}");
    }

    #[test]
    fn real_ffmpeg_transparent_background_flattens_to_black_without_alpha_support() {
        let Some(ffmpeg) = ffmpeg_binary() else { return };
        let s = scene(ResolvedBackground::Transparent);
        let f = render_rgba(&s, &ffmpeg, false);
        let p = rgba(&f, s.canvas_w, 20, 20);
        assert_eq!(p, [0, 0, 0, 255], "flattened to opaque black");
    }

    #[test]
    fn real_ffmpeg_shadow_keeps_partial_alpha_on_a_transparent_canvas() {
        let Some(ffmpeg) = ffmpeg_binary() else { return };
        let mut s = scene(ResolvedBackground::Transparent);
        s.radius_px = 0.0;
        s.shadow_sigma_px = 10.0;
        s.shadow_opacity = 0.8;
        s.shadow_offset_y = 8.0;
        let f = render_rgba(&s, &ffmpeg, true);
        let a = rgba(&f, s.canvas_w, 400, 490)[3];
        assert!(a > 20 && a < 255, "shadow alpha {a}");
        assert_eq!(rgba(&f, s.canvas_w, 5, 5)[3], 0);
    }

    // -----------------------------------------------------------------------
    // Device frames. The payloads are what the frontend sends
    // (tests/fixtures/deviceFrameRender.json, checked against the TypeScript in
    // tests/deviceFrame.test.ts), so these render the very same geometry.
    // -----------------------------------------------------------------------

    fn fixture(name: &str) -> SceneRender {
        let all: std::collections::HashMap<String, SceneRender> =
            serde_json::from_str(include_str!("../../tests/fixtures/deviceFrameRender.json")).unwrap();
        all[name].clone()
    }

    /// `render_rgba`, plus the device text stage the exporter adds after the scene.
    fn render_framed(s: &SceneRender, ffmpeg: &std::path::Path, keep_alpha: bool) -> Vec<u8> {
        let graph = build_scene_filter(s, 30.0, None, "catv", "outv", (640, 360), keep_alpha).unwrap();
        let src = "color=c=red:s=320x360:r=30:d=1[l];color=c=0x00ff00:s=320x360:r=30:d=1[r];\
                   [l][r]hstack,format=yuv420p[catv]";
        let mut chain = format!("{src};{graph}");
        let mut label = "outv";
        let ass = s.frame_text_ass(5.0).map(|script| {
            let p = std::env::temp_dir().join(format!("yusafcut-frametest-{}.ass", uuid::Uuid::new_v4()));
            std::fs::write(&p, script).unwrap();
            p
        });
        if let Some(p) = &ass {
            chain.push_str(&format!(";{}", crate::captions_export::filter_stage("outv", p, "txtv", keep_alpha)));
            label = "txtv";
        }
        let out = std::process::Command::new(ffmpeg)
            .args(["-v", "error", "-filter_complex", &chain, "-map", &format!("[{label}]")])
            .args(["-frames:v", "1", "-f", "rawvideo", "-pix_fmt", "rgba", "-"])
            .output()
            .expect("run ffmpeg");
        if let Some(p) = ass {
            let _ = std::fs::remove_file(p);
        }
        assert!(out.status.success(), "ffmpeg failed: {}\ngraph: {chain}", String::from_utf8_lossy(&out.stderr));
        assert_eq!(out.stdout.len(), (s.canvas_w * s.canvas_h * 4) as usize);
        out.stdout
    }

    fn px4(f: &[u8], s: &SceneRender, x: f64, y: f64) -> [i32; 4] {
        rgba(f, s.canvas_w, x.round() as u32, y.round() as u32)
    }

    fn colour(hex: &str) -> [i32; 3] {
        let h = hex.trim_start_matches('#');
        [0, 2, 4].map(|i| i32::from_str_radix(&h[i..i + 2], 16).unwrap())
    }

    fn is(p: [i32; 4], want: [i32; 3], tol: i32) -> bool {
        p[3] == 255 && near([p[0], p[1], p[2]], want, tol)
    }

    /// The picture inside the screen is the source: red left half, green right half.
    fn assert_picture(f: &[u8], s: &SceneRender) {
        let (x, y, w, h) = (s.content_x as f64, s.content_y as f64, s.content_w as f64, s.content_h as f64);
        for fy in [0.2, 0.5, 0.8] {
            for fx in [0.15, 0.4, 0.6, 0.85] {
                let p = px4(f, s, x + w * fx, y + h * fy);
                let want = if fx < 0.5 { [255, 0, 0] } else { [0, 255, 0] };
                assert!(is(p, want, 14), "picture at ({fx},{fy}) of the content: {p:?}");
            }
        }
    }

    #[test]
    fn frame_payload_deserialises_and_old_payloads_have_no_frame() {
        let s = fixture("phone");
        let f = s.frame.as_ref().unwrap();
        assert_eq!(f.below.len(), 1);
        assert!(f.below[0].silhouette && f.above.len() == 1 && f.texts.is_empty());
        let plain: SceneRender = serde_json::from_str(
            r##"{"canvasW":800,"canvasH":600,"contentX":80,"contentY":120,"contentW":640,"contentH":360,
                "radiusPx":10,"shadowSigmaPx":0,"shadowOpacity":0,"shadowOffsetY":0,
                "background":{"kind":"solid","color":"#000000"}}"##,
        )
        .unwrap();
        assert!(plain.frame.is_none());
    }

    #[test]
    fn a_scene_without_a_frame_builds_the_same_graph_as_before() {
        let f = build_scene_filter(&scene(solid("#1a2b3c")), 60.0, None, "catv", "outv", (640, 360), false).unwrap();
        assert_eq!(
            f,
            "color=c=0x1a2b3c:s=800x600:r=60[scbg];\
             [catv]scale=640:360:flags=lanczos,setsar=1,format=yuva420p[scvid];\
             color=c=black:s=640x360:r=1,format=gray,geq=lum='255*gte((X+0.5-0.000),0)*lt((X+0.5-0.000),640.000)*gte((Y+0.5-0.000),0)*lt((Y+0.5-0.000),360.000)*if(lt((X+0.5-0.000),40.000)*lt((Y+0.5-0.000),40.000),clip(40.000+0.5-hypot((X+0.5-0.000)-40.000,(Y+0.5-0.000)-40.000),0,1),if(gt((X+0.5-0.000),600.000)*lt((Y+0.5-0.000),40.000),clip(40.000+0.5-hypot((X+0.5-0.000)-600.000,(Y+0.5-0.000)-40.000),0,1),if(lt((X+0.5-0.000),40.000)*gt((Y+0.5-0.000),320.000),clip(40.000+0.5-hypot((X+0.5-0.000)-40.000,(Y+0.5-0.000)-320.000),0,1),if(gt((X+0.5-0.000),600.000)*gt((Y+0.5-0.000),320.000),clip(40.000+0.5-hypot((X+0.5-0.000)-600.000,(Y+0.5-0.000)-320.000),0,1),1))))'[scmask];\
             [scvid][scmask]alphamerge=shortest=1[scclip];\
             [scbg][scclip]overlay=x=80:y=120:shortest=1:format=auto,format=yuv420p[outv]"
        );
    }

    #[test]
    fn per_corner_masks_leave_square_corners_out() {
        let m = rounded_rect_mask_radii(0.0, 0.0, 100.0, 50.0, [0.0, 0.0, 10.0, 10.0]);
        assert!(!m.contains("lt((X+0.5-0.000),0.000)"), "{m}");
        assert_eq!(m.matches("hypot").count(), 2, "{m}");
        let none = rounded_rect_mask_radii(0.0, 0.0, 100.0, 50.0, [0.0; 4]);
        assert!(!none.contains("hypot") && none.ends_with("*1"), "{none}");
    }

    #[test]
    fn a_frame_graph_draws_outline_screen_then_overlay_shapes_in_order() {
        let s = fixture("browser");
        let g = build_scene_filter(&s, 30.0, None, "catv", "outv", (640, 360), true).unwrap();
        let (i_body, i_clip, i_light) = (g.find("[scdb0]").unwrap(), g.find("[scclip]overlay").unwrap(), g.find("[scob0]").unwrap());
        assert!(i_body < i_clip && i_clip < i_light, "{g}");
        assert!(g.ends_with("format=yuva444p[outv]"), "{g}");
        // The browser's screen is as big as its picture: no padding needed.
        assert!(!g.contains("pad="), "{g}");
        let phone = build_scene_filter(&fixture("phone"), 30.0, None, "catv", "outv", (640, 360), false).unwrap();
        assert!(phone.contains("pad=396:856:0:318:color=black,setsar=1"), "{phone}");
        assert!(phone.ends_with("format=yuv420p[outv]"), "{phone}");
    }

    #[test]
    fn frame_text_becomes_an_escaped_ass_script() {
        let mut s = fixture("browser");
        s.frame.as_mut().unwrap().texts[0].text = "a {\\an7\\p1} b\\N\u{1F600} \u{4e2d}\u{6587}\nline".into();
        let ass = s.frame_text_ass(5.0).unwrap();
        assert!(ass.contains("PlayResX: 960\nPlayResY: 540"));
        let line = ass.lines().find(|l| l.starts_with("Dialogue")).unwrap();
        // Braces are escaped, backslashes are neutralised, emoji and control characters dropped.
        assert!(line.contains("\\{\\\u{2060}an7\\\u{2060}p1\\}"), "{line}");
        assert!(!line.contains('\u{1F600}') && !line.contains("}\\N") && line.contains("\u{4e2d}\u{6587}"), "{line}");
        assert!(line.contains("\\1c&HD9D4D4&") || line.contains("&HD9D4D4&"), "{line}");
        assert!(fixture("phone").frame_text_ass(5.0).is_none());
        let mut blank = fixture("browser");
        blank.frame.as_mut().unwrap().texts[0].text = "  ".into();
        assert!(blank.frame_text_ass(5.0).is_none());
        let mut bad = fixture("browser");
        bad.frame.as_mut().unwrap().texts[0].color = "red;x".into();
        assert!(bad.frame_text_ass(5.0).is_none());
    }

    #[test]
    fn hostile_frames_are_rejected_not_passed_to_ffmpeg() {
        let ok = fixture("phone");
        let run = |s: &SceneRender| build_scene_filter(s, 30.0, None, "a", "b", (640, 360), false);
        assert!(run(&ok).is_ok());
        let mut s = ok.clone();
        s.frame.as_mut().unwrap().below[0].color = "#12345;movie=/etc/passwd".into();
        assert!(run(&s).is_err());
        let mut s = ok.clone();
        s.frame.as_mut().unwrap().below[0].rect.w = 99999.0;
        assert!(run(&s).is_err());
        let mut s = ok.clone();
        s.frame.as_mut().unwrap().below[0].rect.x = -5.0;
        assert!(run(&s).is_err());
        let mut s = ok.clone();
        s.frame.as_mut().unwrap().below[0].rect.h = f64::NAN;
        assert!(run(&s).is_err());
        let mut s = ok.clone();
        let extra = s.frame.as_ref().unwrap().below[0].clone();
        s.frame.as_mut().unwrap().below = vec![extra; 17];
        assert!(run(&s).is_err());
        let mut s = ok.clone();
        s.frame.as_mut().unwrap().screen.x = 500.0;
        assert!(run(&s).is_err());
        // The picture must lie inside the screen.
        let mut s = ok.clone();
        s.content_y = s.frame.as_ref().unwrap().screen.y as u32;
        s.content_h = s.canvas_h - s.content_y;
        assert!(run(&s).is_err());
        // Oversized radii and a bad alpha are clamped, not fatal.
        let mut s = ok.clone();
        s.frame.as_mut().unwrap().below[0].radii = [1e9, -3.0, f64::INFINITY, 2.0];
        s.frame.as_mut().unwrap().below[0].alpha = 7.0;
        let g = run(&s).unwrap();
        assert!(!g.contains("e9") && !g.contains("inf") && !g.contains("NaN"), "{g}");
    }

    #[test]
    fn real_ffmpeg_phone_has_bezel_island_letterbox_and_a_clean_alpha_silhouette() {
        let Some(ffmpeg) = ffmpeg_binary() else { return };
        let s = fixture("phone");
        let f = render_framed(&s, &ffmpeg, true);
        let fr = s.frame.as_ref().unwrap();
        let body = &fr.below[0];
        let (bx, by, bw, bh) = (body.rect.x, body.rect.y, body.rect.w, body.rect.h);
        // Outside the silhouette (canvas corner and just outside the rounded corner): alpha 0.
        assert_eq!(px4(&f, &s, 3.0, 3.0)[3], 0);
        assert_eq!(px4(&f, &s, bx + 2.0, by + 2.0)[3], 0, "rounded body corner must be transparent");
        assert_eq!(px4(&f, &s, bx + bw - 3.0, by + bh - 3.0)[3], 0);
        // Bezel colour at the side of the body, fully opaque.
        assert!(is(px4(&f, &s, bx + 8.0, by + bh / 2.0), colour(&body.color), 6), "{:?}", px4(&f, &s, bx + 8.0, by + bh / 2.0));
        // The screen's rounded corner shows the bezel, not the picture or the background.
        let sc = &fr.screen;
        assert!(is(px4(&f, &s, sc.x + 2.0, sc.y + 2.0), colour(&body.color), 6));
        // Island, over the black letterbox bar.
        let isl = &fr.above[0];
        assert!(is(px4(&f, &s, isl.rect.x + isl.rect.w / 2.0, isl.rect.y + isl.rect.h / 2.0), [5, 5, 6], 5));
        // Letterbox bar: the 16:9 picture does not fill the portrait screen.
        assert!(is(px4(&f, &s, sc.x + 30.0, sc.y + 120.0), [0, 0, 0], 4));
        assert!(is(px4(&f, &s, sc.x + 30.0, sc.y + sc.h - 60.0), [0, 0, 0], 4));
        assert_picture(&f, &s);
        // No half-transparent fringe inside the device: every pixel in the body's interior is opaque.
        for (x, y) in [(bx + 30.0, by + 30.0), (bx + bw / 2.0, by + 12.0), (bx + 10.0, by + bh - 40.0)] {
            assert_eq!(px4(&f, &s, x, y)[3], 255, "interior alpha at ({x},{y})");
        }
    }

    #[test]
    fn real_ffmpeg_browser_has_title_bar_lights_pill_and_text() {
        let Some(ffmpeg) = ffmpeg_binary() else { return };
        let s = fixture("browser");
        let f = render_framed(&s, &ffmpeg, true);
        let fr = s.frame.as_ref().unwrap();
        let bar = &fr.below[0];
        let bar_h = fr.screen.y - bar.rect.y;
        assert!(bar_h >= 20.0);
        // Title bar colour between the lights and the pill.
        assert!(is(px4(&f, &s, bar.rect.x + 190.0, bar.rect.y + bar_h / 2.0), colour(&bar.color), 6));
        // Traffic lights (red, yellow, green) at the centre of each circle.
        for (i, want) in [[108, 108, 114]; 3].into_iter().enumerate() {
            let c = &fr.above[i].rect;
            assert!(is(px4(&f, &s, c.x + c.w / 2.0, c.y + c.h / 2.0), want, 10), "light {i}");
        }
        // Rounded window corners are transparent, top and bottom.
        assert_eq!(px4(&f, &s, bar.rect.x + 1.0, bar.rect.y + 1.0)[3], 0);
        assert_eq!(px4(&f, &s, bar.rect.x + 1.0, bar.rect.y + bar.rect.h - 2.0)[3], 0);
        assert_eq!(px4(&f, &s, bar.rect.x + bar.rect.w - 2.0, bar.rect.y + bar.rect.h - 2.0)[3], 0);
        // The picture fills the whole screen, square at the top, and starts right below the bar.
        assert_picture(&f, &s);
        assert!(is(px4(&f, &s, fr.screen.x + 2.0, fr.screen.y + 2.0), [255, 0, 0], 14));
        // The address pill is its own colour, and text is drawn in it, centred.
        let pill = &fr.above[3];
        let pill_c = colour(&pill.color);
        assert!(is(px4(&f, &s, pill.rect.x + 8.0, pill.rect.y + pill.rect.h / 2.0), pill_c, 6));
        let (mut n, mut sum_x) = (0.0, 0.0);
        for y in (pill.rect.y as u32)..(pill.rect.y + pill.rect.h) as u32 {
            for x in (pill.rect.x as u32)..(pill.rect.x + pill.rect.w) as u32 {
                let p = rgba(&f, s.canvas_w, x, y);
                if (p[0] - pill_c[0]).abs() > 40 {
                    n += 1.0;
                    sum_x += x as f64;
                }
            }
        }
        assert!(n > 40.0, "expected title text inside the pill, saw {n} text pixels");
        let cx = fr.texts[0].cx;
        assert!((sum_x / n - cx).abs() < 14.0, "text should be centred on {cx}, centre of mass {}", sum_x / n);
    }

    #[test]
    fn real_ffmpeg_laptop_has_bezel_base_lip_and_a_shadow_that_keeps_partial_alpha() {
        let Some(ffmpeg) = ffmpeg_binary() else { return };
        let s = fixture("laptop");
        let f = render_framed(&s, &ffmpeg, true);
        let fr = s.frame.as_ref().unwrap();
        let (lid, base) = (&fr.below[0], &fr.below[1]);
        assert_eq!(px4(&f, &s, 4.0, 4.0)[3], 0);
        assert!(is(px4(&f, &s, lid.rect.x + 6.0, lid.rect.y + lid.rect.h / 2.0), colour(&lid.color), 6));
        assert!(is(px4(&f, &s, base.rect.x + 40.0, base.rect.y + 4.0), colour(&base.color), 6));
        assert_eq!(fr.above.len(), 1, "only the camera dot: no thumb notch on the base");
        // The base is wider than the lid.
        assert!(base.rect.w > lid.rect.w + 20.0);
        assert_eq!(px4(&f, &s, (base.rect.x - 12.0).max(0.0), lid.rect.y + 100.0)[3], 0, "beside the lid, above the base");
        // Shadow under the base: partly transparent black.
        let below = px4(&f, &s, base.rect.x + base.rect.w / 2.0, base.rect.y + base.rect.h + 4.0);
        assert!(below[3] > 10 && below[3] < 255 && below[0] < 30, "shadow {below:?}");
        assert_picture(&f, &s);
    }

    #[test]
    fn real_ffmpeg_tablet_on_a_solid_background_is_flat_and_letterboxes_the_picture() {
        let Some(ffmpeg) = ffmpeg_binary() else { return };
        let s = fixture("tablet");
        let f = render_framed(&s, &ffmpeg, false);
        let fr = s.frame.as_ref().unwrap();
        let body = &fr.below[0];
        assert!(is(px4(&f, &s, body.rect.x + 2.0, body.rect.y + 2.0), [0, 0, 255], 6), "outside the rounded corner: background");
        assert!(is(px4(&f, &s, body.rect.x + 8.0, body.rect.y + body.rect.h / 2.0), colour(&body.color), 6));
        let cam = &fr.above[0];
        assert!(is(px4(&f, &s, cam.rect.x + cam.rect.w / 2.0, cam.rect.y + cam.rect.h / 2.0), colour(&cam.color), 8));
        // 16:9 picture in a 4:3 screen: black bars above and below.
        assert!(is(px4(&f, &s, fr.screen.x + 30.0, fr.screen.y + 8.0), [0, 0, 0], 4));
        assert_picture(&f, &s);
    }

    #[test]
    fn device_masks_are_rendered_once_not_every_second() {
        for name in ["browser", "phone", "laptop", "laptop4k", "tablet", "browserOdd"] {
            let s = fixture(name);
            let g = build_scene_filter(&s, 30.0, None, "catv", "outv", (640, 360), true).unwrap();
            for stage in g.split(';').filter(|st| st.contains("geq")) {
                assert!(stage.contains(":d=1"), "{name}: a mask source runs forever: {stage}");
            }
            // The mask held for the whole video loops one cached frame; shape overlays repeat theirs.
            assert!(g.contains("loop=loop=-1:size=1[scmask]"), "{name}: {g}");
            for stage in g.split(';').filter(|st| st.contains("overlay=") && !st.contains("[scclip]")) {
                assert!(!stage.contains("shortest"), "{name}: {stage}");
            }
        }
    }

    #[test]
    fn frame_text_runs_for_the_export_length_not_ten_hours() {
        let s = fixture("browser");
        let line = |d: f64| {
            let ass = s.frame_text_ass(d).unwrap();
            ass.lines().find(|l| l.starts_with("Dialogue")).unwrap().to_string()
        };
        assert!(line(5.0).starts_with("Dialogue: 0,0:00:00.00,0:00:06.00,"), "{}", line(5.0));
        assert!(line(3725.5).starts_with("Dialogue: 0,0:00:00.00,1:02:06.50,"), "{}", line(3725.5));
        assert!(line(f64::NAN).contains(",0:00:01.00,"));
    }

    #[test]
    fn real_ffmpeg_420_output_has_no_seam_under_the_screen() {
        let Some(ffmpeg) = ffmpeg_binary() else { return };
        // Layout of a canvas that used to produce odd offsets; yuv420p output (MP4 / MOV / GIF path).
        let s = fixture("browserOdd");
        let fr = s.frame.as_ref().unwrap();
        for v in [fr.screen.x, fr.screen.y, fr.screen.w, fr.screen.h, fr.below[0].rect.x, fr.below[0].rect.y] {
            assert_eq!(v as i64 % 2, 0, "offsets and sizes are even");
        }
        let f = render_framed(&s, &ffmpeg, false);
        let (x, y, w, h) = (s.content_x as f64, s.content_y as f64, s.content_w as f64, s.content_h as f64);
        // Every edge pixel of the picture is picture colour (red left, green right): nothing of the
        // title bar or the background slips in as a 1 px line on any side.
        for (px_x, px_y, want) in [
            (x, y + h / 2.0, [255, 0, 0]),
            (x + w - 1.0, y + h / 2.0, [0, 255, 0]),
            (x + w / 4.0, y + h - 1.0, [255, 0, 0]),
            (x + 3.0 * w / 4.0, y + h - 1.0, [0, 255, 0]),
            (x + w / 4.0, y, [255, 0, 0]),
        ] {
            let p = px4(&f, &s, px_x, px_y);
            assert!(is(p, want, 30), "edge pixel ({px_x},{px_y}) {p:?}");
        }
        // And just outside them is the bar / background, not picture.
        assert!(!is(px4(&f, &s, x - 1.0, y + h / 2.0), [255, 0, 0], 60));
        assert!(!is(px4(&f, &s, x + w, y + h / 2.0), [0, 255, 0], 60));
        assert!(!is(px4(&f, &s, x + w / 4.0, y + h), [255, 0, 0], 60));
        // The title bar sits flush on the picture: its last row is bar colour, the next is picture.
        let bar = &fr.below[0];
        assert!(is(px4(&f, &s, bar.rect.x + 150.0, y - 1.0), colour(&bar.color), 12));
    }

    #[test]
    fn a_4k_laptop_frame_over_ten_seconds_does_not_re_run_its_masks_every_second() {
        let Some(ffmpeg) = ffmpeg_binary() else { return };
        let s = fixture("laptop4k");
        let graph = build_scene_filter(&s, 30.0, None, "catv", "outv", (1280, 720), false).unwrap();
        let chain = format!("color=c=red:s=1280x720:r=30:d=10,format=yuv420p[catv];{graph}");
        let t0 = std::time::Instant::now();
        let out = std::process::Command::new(&ffmpeg)
            .args(["-v", "error", "-filter_complex", &chain, "-map", "[outv]", "-f", "null", "-"])
            .output()
            .expect("run ffmpeg");
        let secs = t0.elapsed().as_secs_f64();
        assert!(out.status.success(), "{}", String::from_utf8_lossy(&out.stderr));
        eprintln!("4K laptop frame, 10 s of video: {secs:.1} s wall");
        // Generous: the work is 300 4K overlays; ten more mask evaluations would add ~7 s on top.
        assert!(secs < 90.0, "took {secs:.1} s");
    }

    #[test]
    fn real_ffmpeg_frame_without_alpha_flattens_the_transparent_padding_to_black() {
        let Some(ffmpeg) = ffmpeg_binary() else { return };
        let s = fixture("phone");
        let f = render_framed(&s, &ffmpeg, false);
        assert_eq!(px4(&f, &s, 3.0, 3.0), [0, 0, 0, 255]);
    }
}
