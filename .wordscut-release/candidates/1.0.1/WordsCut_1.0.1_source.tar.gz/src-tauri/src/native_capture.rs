//! Native capture helper — protocol client and pure mapping logic.
//!
//! `yusafcut-capture` (Swift, ScreenCaptureKit + AVFoundation) is spawned as a
//! child process and driven with JSON lines over stdin/stdout:
//!
//! ```text
//! → {"id":1,"cmd":"list-devices"}
//! ← {"id":1,"ok":true,"result":{...}}
//! ← {"event":"state","state":"recording","elapsed":3.2}      (unsolicited)
//! ```
//!
//! Nothing here depends on Tauri, so the whole protocol is tested against a fake
//! helper process (see the tests at the bottom). `commands::record` owns the
//! session lifecycle and falls back to ffmpeg when [`HelperError::is_fallback`].

use crate::recorder::{
    pip_filter, AreaRect, AudioDevice, DisplayInfo, RecordMode, RecordOptions, RecordingDevices, VideoDevice, WindowDevice,
};
use serde::Deserialize;
use serde_json::{json, Map, Value};
use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::process::Stdio;
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::{Arc, Mutex as StdMutex};
use std::time::Duration;
use tokio::io::{AsyncBufReadExt, AsyncRead, AsyncWrite, AsyncWriteExt, BufReader};
use tokio::process::{Child, Command};
use tokio::sync::{mpsc, oneshot, Mutex};

/// Device indices at or above this belong to the native helper's listing. The
/// frontend only ever echoes indices back, so this is how `start_recording`
/// knows which recorder a selection came from.
pub const NATIVE_INDEX_BASE: u32 = 1000;

pub fn is_native_index(i: u32) -> bool {
    i >= NATIVE_INDEX_BASE
}

pub const SIDECAR_NAME: &str = "yusafcut-capture";
const READY_TIMEOUT: Duration = Duration::from_secs(5);
pub const DEFAULT_TIMEOUT: Duration = Duration::from_secs(15);
/// `start` may sit behind a macOS permission prompt.
/// A permission request waits on the user clicking a system prompt.
pub const PERMISSION_TIMEOUT: Duration = Duration::from_secs(120);
pub const START_TIMEOUT: Duration = Duration::from_secs(120);
pub const STOP_TIMEOUT: Duration = Duration::from_secs(60);

// ---------------------------------------------------------------------------
// Errors
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, PartialEq)]
pub enum HelperError {
    /// Missing, not executable, crashed before `ready`, or disabled by env.
    Unavailable(String),
    /// The helper went away (EOF) while a request was in flight.
    Closed,
    Timeout(String),
    /// The helper answered `ok:false`.
    Rejected { code: String, message: String },
    Protocol(String),
    /// The user cancelled the take while the helper was still starting.
    Cancelled,
}

impl HelperError {
    /// Should the caller silently use the ffmpeg recorder instead? Permission
    /// and bad-request errors are real answers (ffmpeg would hit the same wall),
    /// everything else means the helper itself is not working.
    pub fn is_fallback(&self) -> bool {
        match self {
            HelperError::Rejected { code, .. } => {
                !matches!(code.as_str(), "permission-denied" | "bad-request" | "not-found")
            }
            HelperError::Cancelled => false,
            _ => true,
        }
    }

    /// Message to show the user.
    pub fn user_message(&self) -> String {
        match self {
            HelperError::Unavailable(m) => format!("native recorder unavailable: {m}"),
            HelperError::Closed => "the native recorder stopped unexpectedly".into(),
            HelperError::Timeout(c) => format!("the native recorder did not answer `{c}` in time"),
            HelperError::Rejected { message, .. } => message.clone(),
            HelperError::Protocol(m) => format!("native recorder protocol error: {m}"),
            HelperError::Cancelled => "Recording cancelled".into(),
        }
    }
}

impl std::fmt::Display for HelperError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.user_message())
    }
}

// ---------------------------------------------------------------------------
// Locating the helper
// ---------------------------------------------------------------------------

/// Where the helper binary lives, if anywhere.
///
/// Order: `YUSAFCUT_CAPTURE_BIN`, then (debug builds) the freshly built copy in
/// `src-tauri/binaries/`, then next to the app executable (where Tauri puts
/// sidecars in a bundle and in `tauri dev`). `YUSAFCUT_FORCE_FFMPEG=1` disables
/// the native path entirely.
pub fn helper_path() -> Option<PathBuf> {
    if std::env::var("YUSAFCUT_FORCE_FFMPEG").map(|v| v == "1").unwrap_or(false) {
        return None;
    }
    if let Ok(p) = std::env::var("YUSAFCUT_CAPTURE_BIN") {
        let p = PathBuf::from(p);
        return p.is_file().then_some(p);
    }
    let mut candidates: Vec<PathBuf> = Vec::new();
    if cfg!(debug_assertions) {
        candidates.push(
            Path::new(env!("CARGO_MANIFEST_DIR"))
                .join("binaries")
                .join(format!("{SIDECAR_NAME}-aarch64-apple-darwin")),
        );
    }
    if let Ok(exe) = std::env::current_exe() {
        if let Some(dir) = exe.parent() {
            candidates.push(dir.join(SIDECAR_NAME));
        }
    }
    candidates.into_iter().find(|p| p.is_file())
}

// ---------------------------------------------------------------------------
// Protocol client
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, PartialEq)]
pub struct HelperEvent {
    pub name: String,
    pub data: Value,
}

type Pending = Arc<StdMutex<HashMap<u64, oneshot::Sender<Result<Value, HelperError>>>>>;

pub struct HelperClient {
    writer: Mutex<Box<dyn AsyncWrite + Send + Unpin>>,
    pending: Pending,
    next_id: AtomicU64,
    alive: Arc<AtomicBool>,
    events: StdMutex<Option<mpsc::UnboundedReceiver<HelperEvent>>>,
    child: Mutex<Option<Child>>,
    stderr_tail: Arc<StdMutex<String>>,
}

impl HelperClient {
    /// Spawn the helper and wait for its `ready` event.
    pub async fn spawn(path: &Path) -> Result<HelperClient, HelperError> {
        let mut child = Command::new(path)
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::piped())
            .kill_on_drop(true)
            .spawn()
            .map_err(|e| HelperError::Unavailable(format!("{}: {e}", path.display())))?;
        let stdin = child.stdin.take().ok_or_else(|| HelperError::Unavailable("no stdin".into()))?;
        let stdout = child.stdout.take().ok_or_else(|| HelperError::Unavailable("no stdout".into()))?;
        let stderr_tail = Arc::new(StdMutex::new(String::new()));
        if let Some(stderr) = child.stderr.take() {
            let tail = stderr_tail.clone();
            tokio::spawn(async move {
                let mut lines = BufReader::new(stderr).lines();
                while let Ok(Some(line)) = lines.next_line().await {
                    let mut t = tail.lock().unwrap();
                    t.push_str(&line);
                    t.push('\n');
                    if t.len() > 2000 {
                        let cut = t.len() - 2000;
                        t.drain(..cut);
                    }
                }
            });
        }
        let mut client = Self::from_io(stdout, stdin, Some(child), stderr_tail);
        client.await_ready().await?;
        Ok(client)
    }

    /// Wire a client to any pair of streams (used by tests).
    pub fn from_io<R, W>(
        reader: R,
        writer: W,
        child: Option<Child>,
        stderr_tail: Arc<StdMutex<String>>,
    ) -> HelperClient
    where
        R: AsyncRead + Send + Unpin + 'static,
        W: AsyncWrite + Send + Unpin + 'static,
    {
        let pending: Pending = Arc::new(StdMutex::new(HashMap::new()));
        let alive = Arc::new(AtomicBool::new(true));
        let (tx, rx) = mpsc::unbounded_channel();

        let pending_r = pending.clone();
        let alive_r = alive.clone();
        tokio::spawn(async move {
            let mut lines = BufReader::new(reader).lines();
            while let Ok(Some(line)) = lines.next_line().await {
                let Ok(Value::Object(obj)) = serde_json::from_str::<Value>(&line) else {
                    log::debug!("native helper (ignored non-JSON line): {line}");
                    continue;
                };
                if let Some(id) = obj.get("id").and_then(Value::as_u64) {
                    let waiter = pending_r.lock().unwrap().remove(&id);
                    if let Some(waiter) = waiter {
                        let _ = waiter.send(parse_response(&obj));
                    }
                } else if let Some(name) = obj.get("event").and_then(Value::as_str) {
                    let _ = tx.send(HelperEvent { name: name.to_string(), data: Value::Object(obj.clone()) });
                }
            }
            // EOF: the helper exited or crashed.
            alive_r.store(false, Ordering::SeqCst);
            let waiters: Vec<_> = pending_r.lock().unwrap().drain().collect();
            for (_, w) in waiters {
                let _ = w.send(Err(HelperError::Closed));
            }
            let _ = tx.send(HelperEvent { name: "exited".into(), data: Value::Null });
        });

        HelperClient {
            writer: Mutex::new(Box::new(writer)),
            pending,
            next_id: AtomicU64::new(1),
            alive,
            events: StdMutex::new(Some(rx)),
            child: Mutex::new(child),
            stderr_tail,
        }
    }

    async fn await_ready(&mut self) -> Result<(), HelperError> {
        let rx = self.events.get_mut().unwrap().as_mut().expect("events present at startup");
        let outcome = tokio::time::timeout(READY_TIMEOUT, async {
            while let Some(ev) = rx.recv().await {
                match ev.name.as_str() {
                    "ready" => return Ok(()),
                    "exited" => return Err(()),
                    _ => {}
                }
            }
            Err(())
        })
        .await;
        match outcome {
            Ok(Ok(())) => Ok(()),
            Ok(Err(())) => Err(HelperError::Unavailable(format!(
                "exited before it was ready. {}",
                self.stderr_tail.lock().unwrap().trim()
            ))),
            Err(_) => Err(HelperError::Unavailable("did not report ready in time".into())),
        }
    }

    pub fn is_alive(&self) -> bool {
        self.alive.load(Ordering::SeqCst)
    }

    /// Take the stream of unsolicited events (`state`, `error`, `exited`, …).
    pub fn take_events(&self) -> Option<mpsc::UnboundedReceiver<HelperEvent>> {
        self.events.lock().unwrap().take()
    }

    pub fn stderr_tail(&self) -> String {
        self.stderr_tail.lock().unwrap().trim().to_string()
    }

    /// Send one command and wait for its response.
    pub async fn request(&self, cmd: &str, params: Value, timeout: Duration) -> Result<Value, HelperError> {
        if !self.is_alive() {
            return Err(HelperError::Closed);
        }
        let id = self.next_id.fetch_add(1, Ordering::SeqCst);
        let mut obj: Map<String, Value> = match params {
            Value::Object(m) => m,
            Value::Null => Map::new(),
            _ => return Err(HelperError::Protocol("params must be an object".into())),
        };
        obj.insert("id".into(), json!(id));
        obj.insert("cmd".into(), json!(cmd));
        let mut line = Value::Object(obj).to_string();
        line.push('\n');

        let (tx, rx) = oneshot::channel();
        self.pending.lock().unwrap().insert(id, tx);
        // EOF may have drained `pending` between the liveness check above and the
        // insert; without this the request would wait out its whole timeout.
        if !self.is_alive() {
            self.pending.lock().unwrap().remove(&id);
            return Err(HelperError::Closed);
        }
        {
            let mut w = self.writer.lock().await;
            if w.write_all(line.as_bytes()).await.is_err() || w.flush().await.is_err() {
                self.pending.lock().unwrap().remove(&id);
                return Err(HelperError::Closed);
            }
        }
        match tokio::time::timeout(timeout, rx).await {
            Ok(Ok(result)) => result,
            Ok(Err(_)) => Err(HelperError::Closed),
            Err(_) => {
                self.pending.lock().unwrap().remove(&id);
                Err(HelperError::Timeout(cmd.to_string()))
            }
        }
    }

    /// Ask the helper to quit (finalizing any take), then make sure it is gone.
    pub async fn shutdown(&self) {
        if self.is_alive() {
            let _ = self.request("quit", Value::Null, Duration::from_secs(10)).await;
        }
        self.kill().await;
    }

    /// Kill immediately, without asking the helper to finalize anything.
    pub async fn kill_now(&self) {
        if let Some(mut child) = self.child.lock().await.take() {
            let _ = child.kill().await;
        }
    }

    pub async fn kill(&self) {
        if let Some(mut child) = self.child.lock().await.take() {
            match tokio::time::timeout(Duration::from_secs(2), child.wait()).await {
                Ok(_) => {}
                Err(_) => {
                    let _ = child.kill().await;
                }
            }
        }
    }
}

fn parse_response(obj: &Map<String, Value>) -> Result<Value, HelperError> {
    if obj.get("ok").and_then(Value::as_bool) == Some(true) {
        return Ok(obj.get("result").cloned().unwrap_or(Value::Null));
    }
    let err = obj.get("error");
    Err(HelperError::Rejected {
        code: err
            .and_then(|e| e.get("code"))
            .and_then(Value::as_str)
            .unwrap_or("unknown")
            .to_string(),
        message: err
            .and_then(|e| e.get("message"))
            .and_then(Value::as_str)
            .unwrap_or("the native recorder reported an error")
            .to_string(),
    })
}

// ---------------------------------------------------------------------------
// Device listing → the frontend's index-based shape
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, Default, PartialEq, Deserialize)]
pub struct NativeDisplay {
    pub id: u32,
    #[serde(default)]
    pub name: String,
    /// Size in points (0 when the helper did not report it).
    #[serde(default)]
    pub width: f64,
    #[serde(default)]
    pub height: f64,
}

#[derive(Debug, Clone, Default, PartialEq, Deserialize)]
pub struct NativeWindow {
    pub id: u32,
    #[serde(default)]
    pub title: String,
    #[serde(default)]
    pub app: String,
}

#[derive(Debug, Clone, Default, PartialEq, Deserialize)]
pub struct NativeCamera {
    pub id: String,
    #[serde(default)]
    pub name: String,
}

#[derive(Debug, Clone, Default, PartialEq, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct NativeMic {
    pub id: String,
    #[serde(default)]
    pub name: String,
    #[serde(default)]
    pub is_default: bool,
}

#[derive(Debug, Clone, Default, PartialEq, Deserialize)]
pub struct NativeDevices {
    #[serde(default)]
    pub displays: Vec<NativeDisplay>,
    #[serde(default)]
    pub windows: Vec<NativeWindow>,
    #[serde(default)]
    pub cameras: Vec<NativeCamera>,
    #[serde(default)]
    pub microphones: Vec<NativeMic>,
    #[serde(default)]
    pub permissions: Option<Value>,
}

/// What a video index points at.
#[derive(Debug, Clone, PartialEq)]
pub enum VideoRef<'a> {
    Display(&'a NativeDisplay),
    Camera(&'a NativeCamera),
}

impl NativeDevices {
    pub fn parse(result: &Value) -> Result<NativeDevices, HelperError> {
        serde_json::from_value(result.clone())
            .map_err(|e| HelperError::Protocol(format!("unexpected list-devices result: {e}")))
    }

    /// Video list order is displays then cameras; indices count from
    /// [`NATIVE_INDEX_BASE`] over the combined list. Microphones likewise.
    pub fn to_recording_devices(&self) -> RecordingDevices {
        let mut video = Vec::new();
        for (i, d) in self.displays.iter().enumerate() {
            video.push(VideoDevice {
                index: NATIVE_INDEX_BASE + i as u32,
                name: if d.name.is_empty() { format!("Display {}", i + 1) } else { d.name.clone() },
                is_screen: true,
            });
        }
        for (j, c) in self.cameras.iter().enumerate() {
            video.push(VideoDevice {
                index: NATIVE_INDEX_BASE + (self.displays.len() + j) as u32,
                name: c.name.clone(),
                is_screen: false,
            });
        }
        // Default microphone first, so the UI's "first mic" pick is the system default.
        let mut mics: Vec<&NativeMic> = self.microphones.iter().collect();
        mics.sort_by_key(|m| !m.is_default);
        let audio = mics
            .iter()
            .enumerate()
            .map(|(i, m)| AudioDevice { index: NATIVE_INDEX_BASE + i as u32, name: m.name.clone() })
            .collect();
        RecordingDevices {
            video,
            audio,
            backend: "native".into(),
            windows: self
                .windows
                .iter()
                .map(|w| WindowDevice { id: w.id, title: w.title.clone(), app: w.app.clone() })
                .collect(),
            permissions: self.permissions.clone(),
            displays: self
                .displays
                .iter()
                .enumerate()
                .filter(|(_, d)| d.width > 0.0 && d.height > 0.0)
                .map(|(i, d)| DisplayInfo {
                    index: NATIVE_INDEX_BASE + i as u32,
                    width: d.width,
                    height: d.height,
                })
                .collect(),
        }
    }

    pub fn video_ref(&self, index: u32) -> Option<VideoRef<'_>> {
        let i = index.checked_sub(NATIVE_INDEX_BASE)? as usize;
        if i < self.displays.len() {
            return Some(VideoRef::Display(&self.displays[i]));
        }
        self.cameras.get(i - self.displays.len()).map(VideoRef::Camera)
    }

    pub fn mic_ref(&self, index: u32) -> Option<&NativeMic> {
        let i = index.checked_sub(NATIVE_INDEX_BASE)? as usize;
        let mut mics: Vec<&NativeMic> = self.microphones.iter().collect();
        mics.sort_by_key(|m| !m.is_default);
        mics.get(i).copied()
    }
}

// ---------------------------------------------------------------------------
// Start parameters
// ---------------------------------------------------------------------------

/// Permission kinds the helper understands (`request-permissions`).
pub const PERMISSION_KINDS: [&str; 4] = ["screenRecording", "camera", "microphone", "inputMonitoring"];

/// Keep only known permission kinds, in order and without repeats.
pub fn sanitize_permission_kinds(kinds: &[String]) -> Result<Vec<&'static str>, String> {
    let mut out: Vec<&'static str> = Vec::new();
    for k in kinds {
        let known = PERMISSION_KINDS
            .iter()
            .find(|c| **c == k.as_str())
            .ok_or_else(|| format!("unknown permission \"{k}\""))?;
        if !out.contains(known) {
            out.push(known);
        }
    }
    Ok(out)
}

/// The System Settings pane that holds a permission.
pub fn privacy_settings_url(kind: &str) -> Option<&'static str> {
    Some(match kind {
        "screenRecording" => "x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture",
        "camera" => "x-apple.systempreferences:com.apple.preference.security?Privacy_Camera",
        "microphone" => "x-apple.systempreferences:com.apple.preference.security?Privacy_Microphone",
        "inputMonitoring" => "x-apple.systempreferences:com.apple.preference.security?Privacy_ListenEvent",
        _ => return None,
    })
}

/// `thumbnail` parameters for a window, or for the display behind a screen index.
pub fn thumbnail_params(
    devices: &NativeDevices,
    screen_index: Option<u32>,
    window_id: Option<u32>,
    max_width: u32,
) -> Result<Value, String> {
    let max_width = max_width.clamp(64, 1280);
    if let Some(w) = window_id {
        if !devices.windows.iter().any(|x| x.id == w) {
            return Err("the selected window is no longer available".into());
        }
        return Ok(json!({"window": w, "maxWidth": max_width}));
    }
    let idx = screen_index.ok_or("no screen selected")?;
    match devices.video_ref(idx) {
        Some(VideoRef::Display(d)) => Ok(json!({"display": d.id, "maxWidth": max_width})),
        _ => Err("the selected screen is no longer available".into()),
    }
}

/// Smallest capture area the recorder accepts, in points.
pub const MIN_AREA_POINTS: f64 = 32.0;

/// An area must be finite, big enough, and (when the display size is known)
/// inside the display it was drawn on.
fn validate_area(a: &AreaRect, d: &NativeDisplay) -> Result<(), String> {
    let finite = [a.x, a.y, a.width, a.height].iter().all(|v| v.is_finite());
    if !finite || a.x < 0.0 || a.y < 0.0 {
        return Err("the selected capture area is invalid".into());
    }
    if a.width < MIN_AREA_POINTS || a.height < MIN_AREA_POINTS {
        return Err("the selected capture area is too small".into());
    }
    if d.width > 0.0 && d.height > 0.0 && (a.x + a.width > d.width + 0.5 || a.y + a.height > d.height + 0.5) {
        return Err("the selected capture area is outside its display — pick it again".into());
    }
    Ok(())
}

/// Build the helper's `start` parameters from the recorder options.
pub fn build_start_params(
    opts: &RecordOptions,
    devices: &NativeDevices,
    out_dir: &Path,
) -> Result<Value, String> {
    let mut p = Map::new();
    p.insert("outDir".into(), json!(out_dir.to_string_lossy()));
    p.insert("fps".into(), json!(opts.fps.unwrap_or(30).clamp(10, 60)));
    // The real cursor is never baked in: it is redrawn from the cursor events.
    p.insert("showsCursor".into(), json!(false));

    let wants_screen = matches!(opts.mode, RecordMode::Screen | RecordMode::ScreenCamera);
    let wants_camera = matches!(opts.mode, RecordMode::ScreenCamera | RecordMode::Camera);

    if wants_screen {
        if let Some(w) = opts.window_id {
            if !devices.windows.iter().any(|x| x.id == w) {
                return Err("the selected window is no longer available".into());
            }
            p.insert("window".into(), json!(w));
        } else {
            let idx = opts.screen_index.ok_or("screen recording requires a screen device")?;
            match devices.video_ref(idx) {
                Some(VideoRef::Display(d)) => match opts.area {
                    Some(a) => {
                        validate_area(&a, d)?;
                        p.insert(
                            "area".into(),
                            json!({"display": d.id, "x": a.x, "y": a.y,
                                   "width": a.width, "height": a.height}),
                        );
                    }
                    None => {
                        p.insert("display".into(), json!(d.id));
                    }
                },
                _ => return Err("the selected screen is no longer available".into()),
            }
        }
        if opts.system_audio.unwrap_or(false) {
            p.insert("systemAudio".into(), json!(true));
        }
        // Key identity is opt-in; the helper ignores the second flag without the first.
        if opts.record_key_identity.unwrap_or(false) {
            p.insert("recordKeyIdentity".into(), json!(true));
            if opts.record_all_characters.unwrap_or(false) {
                p.insert("recordAllCharacters".into(), json!(true));
            }
        }
    }
    if wants_camera {
        let idx = opts.camera_index.ok_or("this recording mode requires a camera device")?;
        match devices.video_ref(idx) {
            Some(VideoRef::Camera(c)) => {
                p.insert("camera".into(), json!(c.id));
            }
            _ => return Err("the selected camera is no longer available".into()),
        }
    }
    match opts.audio_index {
        Some(i) => match devices.mic_ref(i) {
            Some(m) => {
                p.insert("microphone".into(), json!(m.id));
            }
            None => return Err("the selected microphone is no longer available".into()),
        },
        None if opts.mode == RecordMode::Voiceover => {
            return Err("voice-over recording requires a microphone".into())
        }
        None => {}
    }
    Ok(Value::Object(p))
}

/// Translate native selections into avfoundation indices, so a failed helper
/// can hand the same take to the ffmpeg recorder. Matches by name; screens by
/// position ("Capture screen N" is the Nth display).
pub fn to_avfoundation_options(
    opts: &RecordOptions,
    native: &NativeDevices,
    avf: &RecordingDevices,
) -> Result<RecordOptions, String> {
    if opts.area.is_some() && opts.window_id.is_none() {
        return Err("area capture needs the native recorder".into());
    }
    let mut out = opts.clone();
    out.window_id = None;
    out.system_audio = None;

    if let Some(i) = opts.screen_index.filter(|i| is_native_index(*i)) {
        let Some(VideoRef::Display(d)) = native.video_ref(i) else {
            return Err("selected screen is unknown".into());
        };
        let pos = native.displays.iter().position(|x| x.id == d.id).unwrap_or(0);
        let screens: Vec<&VideoDevice> = avf.video.iter().filter(|v| v.is_screen).collect();
        out.screen_index = Some(screens.get(pos).or(screens.first()).ok_or("ffmpeg lists no screens")?.index);
    }
    if let Some(i) = opts.camera_index.filter(|i| is_native_index(*i)) {
        let Some(VideoRef::Camera(c)) = native.video_ref(i) else {
            return Err("selected camera is unknown".into());
        };
        let found = avf.video.iter().find(|v| !v.is_screen && v.name == c.name);
        out.camera_index = Some(found.ok_or("ffmpeg cannot see the selected camera")?.index);
    }
    if let Some(i) = opts.audio_index.filter(|i| is_native_index(*i)) {
        let m = native.mic_ref(i).ok_or("selected microphone is unknown")?;
        let found = avf.audio.iter().find(|a| a.name == m.name).or(avf.audio.first());
        out.audio_index = Some(found.ok_or("ffmpeg lists no microphones")?.index);
    }
    Ok(out)
}

// ---------------------------------------------------------------------------
// Tracks → one playable file
// ---------------------------------------------------------------------------

/// The separate track files a native take leaves in its `tracks/` directory.
#[derive(Debug, Clone, Default, PartialEq)]
pub struct NativeTracks {
    pub screen: Option<PathBuf>,
    pub camera: Option<PathBuf>,
    pub microphone: Option<PathBuf>,
    pub system_audio: Option<PathBuf>,
}

impl NativeTracks {
    /// Read the `files` object of a `stop` result (absent keys are fine).
    pub fn from_files(files: &Value) -> NativeTracks {
        let get = |k: &str| files.get(k).and_then(Value::as_str).map(PathBuf::from);
        NativeTracks {
            screen: get("screen"),
            camera: get("camera"),
            microphone: get("microphone"),
            system_audio: get("systemAudio"),
        }
    }

    /// Crash recovery: the helper is gone, so look at what it left on disk.
    pub fn scan(dir: &Path) -> NativeTracks {
        let pick = |name: &str| {
            let p = dir.join(name);
            std::fs::metadata(&p).map(|m| m.len() > 0).unwrap_or(false).then_some(p)
        };
        NativeTracks {
            screen: pick("screen.mp4"),
            camera: pick("camera.mp4"),
            microphone: pick("mic.m4a"),
            system_audio: pick("system.m4a"),
        }
    }

    pub fn has_video(&self) -> bool {
        self.screen.is_some() || self.camera.is_some()
    }

    pub fn is_empty(&self) -> bool {
        !self.has_video() && self.microphone.is_none() && self.system_audio.is_none()
    }

    /// Drop entries whose file is missing or empty.
    pub fn existing(self) -> NativeTracks {
        let keep = |p: Option<PathBuf>| {
            p.filter(|p| std::fs::metadata(p).map(|m| m.len() > 0).unwrap_or(false))
        };
        NativeTracks {
            screen: keep(self.screen),
            camera: keep(self.camera),
            microphone: keep(self.microphone),
            system_audio: keep(self.system_audio),
        }
    }
}

/// ffmpeg arguments that fold a take's tracks into one MP4:
///
/// * screen (+ camera picture-in-picture) as the picture; camera alone for
///   camera mode,
/// * microphone and system audio mixed into one AAC track,
/// * video is stream-copied unless the camera has to be composited.
///
/// Returns `None` when there is nothing to mux (voice-over copies its m4a).
pub fn finalize_args(opts: &RecordOptions, tracks: &NativeTracks, output: &Path) -> Option<Vec<String>> {
    // Picture sources in input order.
    let (main, pip) = match opts.mode {
        RecordMode::Voiceover => return None,
        RecordMode::Camera => (tracks.camera.as_ref().or(tracks.screen.as_ref())?, None),
        RecordMode::Screen => (tracks.screen.as_ref().or(tracks.camera.as_ref())?, None),
        RecordMode::ScreenCamera => match (&tracks.screen, &tracks.camera) {
            (Some(s), Some(c)) => (s, Some(c)),
            (Some(s), None) => (s, None),
            (None, Some(c)) => (c, None),
            (None, None) => return None,
        },
    };

    let mut args: Vec<String> = vec!["-y".into(), "-hide_banner".into()];
    let mut inputs = 0usize;
    let mut add_input = |args: &mut Vec<String>, p: &Path| {
        args.push("-i".into());
        args.push(p.to_string_lossy().into_owned());
        inputs += 1;
        inputs - 1
    };
    add_input(&mut args, main);
    let cam_idx = pip.map(|p| add_input(&mut args, p));
    let mut audio_idx: Vec<usize> = Vec::new();
    // Camera mode keeps the microphone only; the other modes mix whatever exists.
    for track in [tracks.microphone.as_ref(), tracks.system_audio.as_ref()].into_iter().flatten() {
        audio_idx.push(add_input(&mut args, track));
    }

    let mut filter_parts: Vec<String> = Vec::new();
    let video_map: String;
    if cam_idx.is_some() {
        filter_parts.push(format!("{}[outv]", pip_filter(opts)));
        video_map = "[outv]".into();
    } else {
        video_map = "0:v".into();
    }
    let audio_map: Option<String> = match audio_idx.len() {
        0 => None,
        1 => Some(format!("{}:a", audio_idx[0])),
        _ => {
            let ins: String = audio_idx.iter().map(|i| format!("[{i}:a]")).collect();
            // amix divides each input by the input count; volume=2 restores level.
            filter_parts.push(format!(
                "{ins}amix=inputs={}:duration=longest:dropout_transition=0,volume={}[outa]",
                audio_idx.len(),
                audio_idx.len()
            ));
            Some("[outa]".into())
        }
    };

    if !filter_parts.is_empty() {
        args.push("-filter_complex".into());
        args.push(filter_parts.join(";"));
    }
    args.extend(["-map".into(), video_map]);
    if let Some(a) = &audio_map {
        args.extend(["-map".into(), a.clone()]);
    }

    if cam_idx.is_some() {
        args.extend([
            "-c:v".into(),
            "h264_videotoolbox".into(),
            "-b:v".into(),
            "8000k".into(),
            "-pix_fmt".into(),
            "yuv420p".into(),
        ]);
    } else {
        args.extend(["-c:v".into(), "copy".into()]);
    }
    if audio_map.is_some() {
        args.extend(["-c:a".into(), "aac".into(), "-b:a".into(), "192k".into()]);
    }
    args.extend(["-movflags".into(), "+faststart".into(), output.to_string_lossy().into_owned()]);
    Some(args)
}

// ---------------------------------------------------------------------------
// Stop hand-off: playable screen first, camera composite deferred
// ---------------------------------------------------------------------------

/// How Stop turns a take's tracks into something the editor can play.
#[derive(Debug, Clone, PartialEq)]
pub struct StopHandoff {
    /// Tracks folded into the file Stop hands back. For a screen + camera take
    /// the camera is left out, so the picture is a stream copy (no re-encode).
    pub playable: NativeTracks,
    /// The camera track kept as its own finalized file in `tracks_dir`, for the
    /// background composite. `None` for every other mode, and when either the
    /// screen or the camera track is missing (then there is nothing to overlay).
    pub deferred_camera: Option<PathBuf>,
}

/// Decide the Stop hand-off for `opts.mode` and the tracks that hold data.
/// Only a screen + camera take with both tracks defers anything; camera-only,
/// screen-only and voice-over are exactly what `finalize_args` did before.
pub fn plan_stop_handoff(opts: &RecordOptions, tracks: &NativeTracks) -> StopHandoff {
    match (opts.mode, &tracks.screen, &tracks.camera) {
        (RecordMode::ScreenCamera, Some(_), Some(camera)) => StopHandoff {
            playable: NativeTracks { camera: None, ..tracks.clone() },
            deferred_camera: Some(camera.clone()),
        },
        _ => StopHandoff { playable: tracks.clone(), deferred_camera: None },
    }
}

/// The background camera composite: the argv `finalize_args` produced at Stop
/// before 4.49 (screen + camera picture-in-picture, mic and system audio mixed,
/// `h264_videotoolbox`) with ONE difference: the overlay uses
/// `eof_action=pass` instead of `shortest=1`, so a camera that ended early
/// (unplugged mid-take) only removes the bubble from then on instead of
/// cutting the picture short. The video then always spans the screen track, so
/// the composite can replace the stream-copied hand-off file without moving an
/// edit. `None` unless both the screen and the camera track exist.
pub fn camera_composite_args(
    tracks: &NativeTracks,
    pip_corner: Option<crate::recorder::PipCorner>,
    pip_size: Option<crate::recorder::PipSize>,
    output: &Path,
) -> Option<Vec<String>> {
    if tracks.screen.is_none() || tracks.camera.is_none() {
        return None;
    }
    let opts = RecordOptions {
        mode: RecordMode::ScreenCamera,
        pip_corner,
        pip_size,
        ..Default::default()
    };
    let mut args = finalize_args(&opts, tracks, output)?;
    let graph = args.iter_mut().find(|a| a.contains("[outv]"))?;
    if !graph.contains(":shortest=1[outv]") {
        return None; // the PiP filter changed shape: refuse rather than guess
    }
    *graph = graph.replace(":shortest=1[outv]", ":eof_action=pass[outv]");
    Some(args)
}

/// What a swap must preserve, read from `ffprobe -show_streams -show_format` JSON.
#[derive(Debug, Clone, PartialEq)]
pub struct StreamFacts {
    /// Duration of the first video stream (NOT the container, which is the
    /// longest stream: the audio mix runs `duration=longest`).
    pub video_sec: Option<f64>,
    /// Container (format) duration: the longest stream.
    pub container_sec: Option<f64>,
    pub width: u32,
    pub height: u32,
    /// Sample rate of the first audio stream, 0 when there is none.
    pub audio_sample_rate: u32,
}

impl StreamFacts {
    pub fn parse(json: &str) -> Option<StreamFacts> {
        let v: Value = serde_json::from_str(json).ok()?;
        let streams = v["streams"].as_array()?;
        let num = |s: &Value, k: &str| -> Option<f64> {
            s[k].as_f64().or_else(|| s[k].as_str().and_then(|t| t.parse().ok()))
        };
        let video = streams.iter().find(|s| s["codec_type"] == "video");
        let audio = streams.iter().find(|s| s["codec_type"] == "audio");
        Some(StreamFacts {
            video_sec: video.and_then(|s| num(s, "duration")).filter(|d| d.is_finite()),
            container_sec: num(&v["format"], "duration").filter(|d| d.is_finite()),
            width: video.and_then(|s| num(s, "width")).unwrap_or(0.0) as u32,
            height: video.and_then(|s| num(s, "height")).unwrap_or(0.0) as u32,
            audio_sample_rate: audio.and_then(|s| num(s, "sample_rate")).unwrap_or(0.0) as u32,
        })
    }
}

/// Seconds the composite's video may differ from the hand-off file's (about 2 frames at 30 fps).
pub const COMPOSITE_VIDEO_TOLERANCE: f64 = 0.07;

/// May `composite` replace the playable `handoff` file of the same take? Same
/// picture size, same audio presence and rate, and the composite's picture
/// never ends before the hand-off's (the container length hides a short video
/// behind the audio, which is how a lost camera used to truncate it).
///
/// Equal video lengths (within tolerance) are accepted. A sparse / VFR screen
/// track (no new frames while the screen was static at the end) can have a
/// hand-off video shorter than its container; a composite whose video is at
/// least as long and whose container matches is accepted too, because both
/// files show the last screen frame until the same end.
pub fn composite_lines_up(handoff: &StreamFacts, composite: &StreamFacts) -> Result<(), String> {
    if (handoff.width, handoff.height) != (composite.width, composite.height) {
        return Err(format!(
            "picture size {}x{} differs from {}x{}",
            composite.width, composite.height, handoff.width, handoff.height
        ));
    }
    if handoff.audio_sample_rate != composite.audio_sample_rate {
        return Err(if handoff.audio_sample_rate == 0 || composite.audio_sample_rate == 0 {
            "one version has sound and the other has none".into()
        } else {
            "the sound differs".into()
        });
    }
    let tol = COMPOSITE_VIDEO_TOLERANCE;
    match (handoff.video_sec, composite.video_sec) {
        (Some(a), Some(b)) if (a - b).abs() <= tol => Ok(()),
        (Some(a), Some(b)) => {
            let sparse_handoff = handoff.container_sec.is_some_and(|c| a < c - tol);
            let same_container = match (handoff.container_sec, composite.container_sec) {
                (Some(hc), Some(cc)) => (hc - cc).abs() <= tol,
                _ => false,
            };
            let not_shorter = b >= a - tol && composite.container_sec.is_some_and(|cc| b <= cc + tol);
            if sparse_handoff && same_container && not_shorter {
                Ok(())
            } else {
                Err(format!("picture length {b:.2} s differs from {a:.2} s"))
            }
        }
        _ => Err("the picture length could not be read".into()),
    }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;
    use crate::recorder::{PipCorner, PipSize};
    use tokio::io::duplex;

    fn devices() -> NativeDevices {
        NativeDevices::parse(&json!({
            "displays": [{"id": 69, "name": "Built-in Retina Display"}, {"id": 70, "name": "LG"}],
            "windows": [{"id": 42, "title": "Doc", "app": "Pages"}],
            "cameras": [{"id": "cam-a", "name": "FaceTime HD Camera"}],
            "microphones": [
                {"id": "mic-b", "name": "USB Mic", "isDefault": false},
                {"id": "mic-a", "name": "MacBook Pro Microphone", "isDefault": true}
            ],
            "permissions": {"screenRecording": "granted"}
        }))
        .unwrap()
    }

    // ----- pure mapping ----------------------------------------------------

    #[test]
    fn listing_reports_display_sizes_for_area_selection() {
        let n = NativeDevices::parse(&json!({
            "displays": [{"id": 69, "name": "A", "width": 1512.0, "height": 982.0}, {"id": 70, "name": "B"}]
        }))
        .unwrap();
        let d = n.to_recording_devices();
        // A display without a reported size is not offered for area capture.
        assert_eq!(d.displays, vec![DisplayInfo { index: 1000, width: 1512.0, height: 982.0 }]);
    }

    fn sized() -> NativeDevices {
        NativeDevices::parse(&json!({
            "displays": [{"id": 69, "name": "A", "width": 1000.0, "height": 600.0}]
        }))
        .unwrap()
    }

    #[test]
    fn area_start_params_name_the_display_and_rect() {
        let mut o = base_opts(RecordMode::Screen);
        o.screen_index = Some(1000);
        o.area = Some(AreaRect { x: 10.0, y: 20.0, width: 300.0, height: 200.0 });
        let p = build_start_params(&o, &sized(), Path::new("/x")).unwrap();
        assert_eq!(p["area"], json!({"display": 69, "x": 10.0, "y": 20.0, "width": 300.0, "height": 200.0}));
        assert!(p.get("display").is_none(), "area replaces display");
    }

    #[test]
    fn invalid_areas_are_rejected_before_the_helper_runs() {
        let mut o = base_opts(RecordMode::Screen);
        o.screen_index = Some(1000);
        for (x, y, w, h) in [(0.0, 0.0, 8.0, 200.0), (900.0, 0.0, 300.0, 200.0), (-1.0, 0.0, 100.0, 100.0), (0.0, 0.0, f64::NAN, 100.0)] {
            o.area = Some(AreaRect { x, y, width: w, height: h });
            assert!(build_start_params(&o, &sized(), Path::new("/x")).is_err(), "{x},{y},{w},{h}");
        }
    }

    #[test]
    fn ffmpeg_fallback_refuses_area_capture() {
        let mut o = base_opts(RecordMode::Screen);
        o.screen_index = Some(1000);
        o.area = Some(AreaRect { x: 0.0, y: 0.0, width: 100.0, height: 100.0 });
        let avf = RecordingDevices::default();
        assert!(to_avfoundation_options(&o, &sized(), &avf).is_err());
    }

    #[test]
    fn permission_kinds_are_whitelisted() {
        let k = |v: &[&str]| v.iter().map(|s| s.to_string()).collect::<Vec<_>>();
        assert_eq!(
            sanitize_permission_kinds(&k(&["camera", "camera", "microphone"])).unwrap(),
            vec!["camera", "microphone"]
        );
        assert!(sanitize_permission_kinds(&k(&["camera", "rm -rf"])).is_err());
        assert!(privacy_settings_url("screenRecording").unwrap().contains("Privacy_ScreenCapture"));
        assert!(privacy_settings_url("other").is_none());
    }

    #[test]
    fn thumbnail_params_resolve_windows_and_displays() {
        let d = devices();
        assert_eq!(thumbnail_params(&d, Some(1001), None, 480).unwrap(), json!({"display": 70, "maxWidth": 480}));
        assert_eq!(thumbnail_params(&d, Some(1001), Some(42), 9000).unwrap(), json!({"window": 42, "maxWidth": 1280}));
        assert!(thumbnail_params(&d, Some(1002), None, 480).is_err(), "a camera is not a screen");
        assert!(thumbnail_params(&d, None, Some(7), 480).is_err(), "unknown window");
        assert!(thumbnail_params(&d, None, None, 480).is_err());
    }

    #[test]
    fn listing_maps_to_native_index_range() {
        let d = devices().to_recording_devices();
        assert_eq!(d.backend, "native");
        let v: Vec<(u32, &str, bool)> = d.video.iter().map(|v| (v.index, v.name.as_str(), v.is_screen)).collect();
        assert_eq!(
            v,
            vec![
                (1000, "Built-in Retina Display", true),
                (1001, "LG", true),
                (1002, "FaceTime HD Camera", false)
            ]
        );
        // default mic first
        assert_eq!(d.audio[0].name, "MacBook Pro Microphone");
        assert_eq!(d.audio[0].index, 1000);
        assert_eq!(d.audio[1].index, 1001);
        assert_eq!(d.windows.len(), 1);
        assert!(d.permissions.is_some());
    }

    #[test]
    fn index_resolution_round_trips() {
        let d = devices();
        assert_eq!(d.video_ref(1001), Some(VideoRef::Display(&d.displays[1])));
        assert_eq!(d.video_ref(1002), Some(VideoRef::Camera(&d.cameras[0])));
        assert_eq!(d.video_ref(1003), None);
        assert_eq!(d.video_ref(2), None, "ffmpeg indices are not native");
        assert_eq!(d.mic_ref(1000).unwrap().id, "mic-a");
        assert_eq!(d.mic_ref(1001).unwrap().id, "mic-b");
        assert!(is_native_index(1000) && !is_native_index(999));
    }

    fn base_opts(mode: RecordMode) -> RecordOptions {
        RecordOptions { mode, ..Default::default() }
    }

    #[test]
    fn start_params_for_screen_with_mic_and_system_audio() {
        let o = RecordOptions {
            screen_index: Some(1001),
            audio_index: Some(1000),
            fps: Some(120),
            system_audio: Some(true),
            ..base_opts(RecordMode::Screen)
        };
        let p = build_start_params(&o, &devices(), Path::new("/tmp/t")).unwrap();
        assert_eq!(p["display"], 70);
        assert_eq!(p["microphone"], "mic-a");
        assert_eq!(p["systemAudio"], true);
        assert_eq!(p["fps"], 60, "fps is clamped");
        assert_eq!(p["showsCursor"], false, "the real cursor is never captured");
        assert_eq!(p["outDir"], "/tmp/t");
        assert!(p.get("camera").is_none());
    }

    #[test]
    fn start_params_window_overrides_display() {
        let o = RecordOptions { screen_index: Some(1000), window_id: Some(42), ..base_opts(RecordMode::Screen) };
        let p = build_start_params(&o, &devices(), Path::new("/x")).unwrap();
        assert_eq!(p["window"], 42);
        assert!(p.get("display").is_none());
        let bad = RecordOptions { window_id: Some(7), ..o };
        assert!(build_start_params(&bad, &devices(), Path::new("/x")).is_err());
    }

    #[test]
    fn start_params_screen_camera_needs_both() {
        let o = RecordOptions {
            screen_index: Some(1000),
            camera_index: Some(1002),
            ..base_opts(RecordMode::ScreenCamera)
        };
        let p = build_start_params(&o, &devices(), Path::new("/x")).unwrap();
        assert_eq!(p["display"], 69);
        assert_eq!(p["camera"], "cam-a");
        let no_cam = RecordOptions { camera_index: None, ..o.clone() };
        assert!(build_start_params(&no_cam, &devices(), Path::new("/x")).is_err());
        // A screen index in the camera slot is rejected rather than misused.
        let wrong = RecordOptions { camera_index: Some(1000), ..o };
        assert!(build_start_params(&wrong, &devices(), Path::new("/x")).is_err());
    }

    #[test]
    fn start_params_voiceover_and_camera_modes() {
        let vo = RecordOptions { audio_index: Some(1001), ..base_opts(RecordMode::Voiceover) };
        let p = build_start_params(&vo, &devices(), Path::new("/x")).unwrap();
        assert_eq!(p["microphone"], "mic-b");
        assert!(p.get("display").is_none() && p.get("camera").is_none());
        assert!(build_start_params(&base_opts(RecordMode::Voiceover), &devices(), Path::new("/x")).is_err());
        let cam = RecordOptions { camera_index: Some(1002), ..base_opts(RecordMode::Camera) };
        let p = build_start_params(&cam, &devices(), Path::new("/x")).unwrap();
        assert_eq!(p["camera"], "cam-a");
        assert!(p.get("microphone").is_none(), "no mic selected, none requested");
    }

    #[test]
    fn avfoundation_fallback_translation() {
        let avf = RecordingDevices {
            video: vec![
                VideoDevice { index: 0, name: "FaceTime HD Camera".into(), is_screen: false },
                VideoDevice { index: 1, name: "Capture screen 0".into(), is_screen: true },
                VideoDevice { index: 2, name: "Capture screen 1".into(), is_screen: true },
            ],
            audio: vec![
                AudioDevice { index: 0, name: "USB Mic".into() },
                AudioDevice { index: 1, name: "MacBook Pro Microphone".into() },
            ],
            ..Default::default()
        };
        let o = RecordOptions {
            screen_index: Some(1001),
            camera_index: Some(1002),
            audio_index: Some(1000),
            window_id: Some(9),
            system_audio: Some(true),
            ..base_opts(RecordMode::ScreenCamera)
        };
        let m = to_avfoundation_options(&o, &devices(), &avf).unwrap();
        assert_eq!(m.screen_index, Some(2), "second display → second 'Capture screen'");
        assert_eq!(m.camera_index, Some(0));
        assert_eq!(m.audio_index, Some(1), "mic matched by name");
        assert_eq!((m.window_id, m.system_audio), (None, None));

        // Options that already use avfoundation indices pass through untouched.
        let legacy = RecordOptions { screen_index: Some(1), ..base_opts(RecordMode::Screen) };
        assert_eq!(to_avfoundation_options(&legacy, &devices(), &avf).unwrap().screen_index, Some(1));
    }

    #[test]
    fn fallback_policy() {
        assert!(HelperError::Unavailable("x".into()).is_fallback());
        assert!(HelperError::Closed.is_fallback());
        assert!(HelperError::Timeout("start".into()).is_fallback());
        assert!(HelperError::Rejected { code: "capture-failed".into(), message: "m".into() }.is_fallback());
        assert!(!HelperError::Rejected { code: "permission-denied".into(), message: "m".into() }.is_fallback());
        assert!(!HelperError::Rejected { code: "bad-request".into(), message: "m".into() }.is_fallback());
    }

    // ----- finalize args ---------------------------------------------------

    fn tracks_all() -> NativeTracks {
        NativeTracks {
            screen: Some("/t/screen.mp4".into()),
            camera: Some("/t/camera.mp4".into()),
            microphone: Some("/t/mic.m4a".into()),
            system_audio: Some("/t/system.m4a".into()),
        }
    }

    #[test]
    fn finalize_screen_copies_video_and_mixes_audio() {
        let args = finalize_args(&base_opts(RecordMode::Screen), &tracks_all(), Path::new("/o.mp4")).unwrap();
        let j = args.join(" ");
        assert!(j.contains("-i /t/screen.mp4 -i /t/mic.m4a -i /t/system.m4a"));
        assert!(!j.contains("camera.mp4"), "camera is not part of screen mode");
        assert!(j.contains("amix=inputs=2"));
        assert!(j.contains("-map 0:v") && j.contains("-map [outa]"));
        assert!(j.contains("-c:v copy"));
        assert!(j.ends_with("/o.mp4"));
    }

    #[test]
    fn finalize_screen_with_single_audio_needs_no_mix() {
        let t = NativeTracks { system_audio: None, ..tracks_all() };
        let j = finalize_args(&base_opts(RecordMode::Screen), &t, Path::new("/o.mp4")).unwrap().join(" ");
        assert!(!j.contains("amix") && !j.contains("filter_complex"));
        assert!(j.contains("-map 1:a"));
    }

    #[test]
    fn finalize_screen_only_has_no_audio_flags() {
        let t = NativeTracks { screen: tracks_all().screen, ..Default::default() };
        let j = finalize_args(&base_opts(RecordMode::Screen), &t, Path::new("/o.mp4")).unwrap().join(" ");
        assert!(!j.contains("-c:a") && !j.contains("-map 1"));
    }

    #[test]
    fn finalize_pip_composites_camera_over_screen() {
        let o = RecordOptions {
            pip_corner: Some(PipCorner::TopLeft),
            pip_size: Some(PipSize::Small),
            ..base_opts(RecordMode::ScreenCamera)
        };
        let j = finalize_args(&o, &tracks_all(), Path::new("/o.mp4")).unwrap().join(" ");
        assert!(j.contains("-i /t/screen.mp4 -i /t/camera.mp4 -i /t/mic.m4a -i /t/system.m4a"));
        assert!(j.contains("ref_w") && j.contains("overlay=28:28") && j.contains("[outv]"));
        assert!(j.contains("[2:a][3:a]amix=inputs=2"), "audio inputs follow the two picture inputs");
        assert!(j.contains("h264_videotoolbox"));
    }

    #[test]
    fn finalize_pip_without_camera_track_keeps_the_screen() {
        let t = NativeTracks { camera: None, ..tracks_all() };
        let j = finalize_args(&base_opts(RecordMode::ScreenCamera), &t, Path::new("/o.mp4")).unwrap().join(" ");
        assert!(!j.contains("overlay") && j.contains("-c:v copy"));
    }

    #[test]
    fn finalize_camera_mode_uses_camera_and_mic() {
        let t = NativeTracks { screen: None, system_audio: None, ..tracks_all() };
        let j = finalize_args(&base_opts(RecordMode::Camera), &t, Path::new("/o.mp4")).unwrap().join(" ");
        assert!(j.contains("-i /t/camera.mp4 -i /t/mic.m4a"));
    }

    #[test]
    fn finalize_voiceover_and_empty_have_nothing_to_mux() {
        assert!(finalize_args(&base_opts(RecordMode::Voiceover), &tracks_all(), Path::new("/o.m4a")).is_none());
        assert!(finalize_args(&base_opts(RecordMode::Screen), &NativeTracks::default(), Path::new("/o.mp4")).is_none());
    }

    // ----- stop hand-off ----------------------------------------------------

    #[test]
    fn screen_camera_stop_hands_back_a_stream_copy_and_defers_the_camera() {
        let o = RecordOptions {
            pip_corner: Some(PipCorner::TopLeft),
            pip_size: Some(PipSize::Small),
            ..base_opts(RecordMode::ScreenCamera)
        };
        let plan = plan_stop_handoff(&o, &tracks_all());
        assert_eq!(plan.deferred_camera, Some(PathBuf::from("/t/camera.mp4")));
        assert_eq!(plan.playable.camera, None);
        assert_eq!(plan.playable.screen, tracks_all().screen);
        assert_eq!(plan.playable.microphone, tracks_all().microphone);
        assert_eq!(plan.playable.system_audio, tracks_all().system_audio);
        let j = finalize_args(&o, &plan.playable, Path::new("/o.mp4")).unwrap().join(" ");
        assert!(j.contains("-i /t/screen.mp4 -i /t/mic.m4a -i /t/system.m4a"));
        assert!(!j.contains("camera.mp4") && !j.contains("overlay") && !j.contains("videotoolbox"));
        assert!(j.contains("-c:v copy") && j.contains("[1:a][2:a]amix=inputs=2"));
    }

    #[test]
    fn other_modes_and_missing_tracks_defer_nothing() {
        for mode in [RecordMode::Screen, RecordMode::Camera, RecordMode::Voiceover] {
            let plan = plan_stop_handoff(&base_opts(mode), &tracks_all());
            assert_eq!(plan, StopHandoff { playable: tracks_all(), deferred_camera: None }, "{mode:?}");
        }
        // Screen + camera mode with one picture track: nothing to overlay.
        for t in [
            NativeTracks { camera: None, ..tracks_all() },
            NativeTracks { screen: None, ..tracks_all() },
        ] {
            let plan = plan_stop_handoff(&base_opts(RecordMode::ScreenCamera), &t);
            assert_eq!(plan, StopHandoff { playable: t.clone(), deferred_camera: None });
        }
    }

    #[test]
    fn background_composite_is_the_old_stop_composite_except_the_bubble_end() {
        for (corner, size) in [
            (None, None),
            (Some(PipCorner::TopLeft), Some(PipSize::Small)),
            (Some(PipCorner::BottomRight), Some(PipSize::Large)),
        ] {
            let o = RecordOptions { pip_corner: corner, pip_size: size, ..base_opts(RecordMode::ScreenCamera) };
            let legacy = finalize_args(&o, &tracks_all(), Path::new("/o.mp4")).unwrap();
            let deferred = camera_composite_args(&tracks_all(), corner, size, Path::new("/o.mp4")).unwrap();
            let expected: Vec<String> = legacy
                .iter()
                .map(|a| a.replace(":shortest=1[outv]", ":eof_action=pass[outv]"))
                .collect();
            assert_ne!(deferred, legacy);
            assert_eq!(deferred, expected);
            let j = deferred.join(" ");
            assert!(j.contains("h264_videotoolbox") && !j.contains("shortest=1"));
        }
        let no_cam = NativeTracks { camera: None, ..tracks_all() };
        assert!(camera_composite_args(&no_cam, None, None, Path::new("/o.mp4")).is_none());
        let no_screen = NativeTracks { screen: None, ..tracks_all() };
        assert!(camera_composite_args(&no_screen, None, None, Path::new("/o.mp4")).is_none());
    }

    #[test]
    fn swap_check_compares_video_length_size_and_sound() {
        let json = r#"{"streams":[{"codec_type":"video","width":640,"height":360,"duration":"4.000000"},
            {"codec_type":"audio","sample_rate":"48000","duration":"4.017"}],"format":{"duration":"4.017"}}"#;
        let h = StreamFacts::parse(json).unwrap();
        assert_eq!(
            h,
            StreamFacts { video_sec: Some(4.0), container_sec: Some(4.017), width: 640, height: 360, audio_sample_rate: 48000 }
        );
        assert!(composite_lines_up(&h, &h).is_ok());
        let short = StreamFacts { video_sec: Some(1.5), ..h.clone() };
        assert!(composite_lines_up(&h, &short).unwrap_err().contains("picture length"));
        let silent = StreamFacts { audio_sample_rate: 0, ..h.clone() };
        assert!(composite_lines_up(&silent, &h).unwrap_err().contains("sound"));
        let other_rate = StreamFacts { audio_sample_rate: 44100, ..h.clone() };
        assert!(composite_lines_up(&h, &other_rate).is_err());
        let wide = StreamFacts { width: 1280, ..h.clone() };
        assert!(composite_lines_up(&h, &wide).unwrap_err().contains("size"));
        let unknown = StreamFacts { video_sec: None, ..h.clone() };
        assert!(composite_lines_up(&h, &unknown).is_err());
        assert!(StreamFacts::parse("not json").is_none());
    }

    #[test]
    fn sparse_vfr_handoff_accepts_a_longer_composite_but_never_a_shorter_one() {
        // Static screen at the end: the hand-off's video stops at 2 s inside a 4 s file.
        let h = StreamFacts { video_sec: Some(2.0), container_sec: Some(4.0), width: 640, height: 360, audio_sample_rate: 48000 };
        let filled = StreamFacts { video_sec: Some(4.0), ..h.clone() };
        assert!(composite_lines_up(&h, &filled).is_ok());
        assert!(composite_lines_up(&h, &h).is_ok());
        // Shorter than the hand-off's picture: refused, even inside the same container.
        let cut = StreamFacts { video_sec: Some(1.5), ..h.clone() };
        assert!(composite_lines_up(&h, &cut).is_err());
        // Different container length: refused.
        let longer = StreamFacts { video_sec: Some(5.0), container_sec: Some(5.0), ..h.clone() };
        assert!(composite_lines_up(&h, &longer).is_err());
        // A dense hand-off never accepts a different length.
        let dense = StreamFacts { video_sec: Some(4.0), container_sec: Some(4.0), ..h.clone() };
        let over = StreamFacts { video_sec: Some(3.5), ..dense.clone() };
        assert!(composite_lines_up(&dense, &over).is_err());
    }

    fn bundled(name: &str) -> Option<PathBuf> {
        let p = Path::new(env!("CARGO_MANIFEST_DIR")).join(format!("binaries/{name}-aarch64-apple-darwin"));
        p.exists().then_some(p)
    }

    fn run(bin: &Path, args: &[String]) -> std::process::Output {
        let out = std::process::Command::new(bin).args(args).output().unwrap();
        assert!(out.status.success(), "{}", String::from_utf8_lossy(&out.stderr));
        out
    }

    fn facts(ffprobe: &Path, file: &Path) -> StreamFacts {
        let args = ["-v", "error", "-print_format", "json", "-show_format", "-show_streams"]
            .map(String::from)
            .into_iter()
            .chain([file.to_string_lossy().into_owned()])
            .collect::<Vec<_>>();
        StreamFacts::parse(&String::from_utf8_lossy(&run(ffprobe, &args).stdout)).unwrap()
    }

    /// Review regression: camera lost after 1.5 s of a 4 s take. The old
    /// `shortest=1` composite has a 1.5 s picture inside a 4 s container and
    /// must be refused; the deferred composite keeps the whole picture.
    #[test]
    fn camera_lost_mid_take_never_shortens_the_swapped_picture() {
        let (Some(ff), Some(fp)) = (bundled("ffmpeg"), bundled("ffprobe")) else {
            eprintln!("bundled ffmpeg/ffprobe missing; skipped");
            return;
        };
        let dir = std::env::temp_dir().join(format!("yc-cam-lost-{}", uuid::Uuid::new_v4()));
        std::fs::create_dir_all(&dir).unwrap();
        let gen = |args: &str, out: &str| {
            let mut a: Vec<String> = ["-v", "error", "-y", "-f", "lavfi", "-i"].map(String::from).to_vec();
            a.extend(args.split(' ').map(String::from));
            a.push(dir.join(out).to_string_lossy().into_owned());
            run(&ff, &a);
        };
        gen("testsrc2=size=640x360:rate=30:duration=4 -c:v libx264 -pix_fmt yuv420p", "screen.mp4");
        gen("testsrc2=size=320x180:rate=30:duration=1.5 -c:v libx264 -pix_fmt yuv420p", "camera.mp4");
        gen("sine=frequency=440:sample_rate=48000:duration=4 -c:a aac", "mic.m4a");
        let tracks = NativeTracks::scan(&dir);
        assert!(tracks.screen.is_some() && tracks.camera.is_some() && tracks.microphone.is_some());
        let opts = base_opts(RecordMode::ScreenCamera);

        let handoff = dir.join("handoff.mp4");
        let plan = plan_stop_handoff(&opts, &tracks);
        run(&ff, &finalize_args(&opts, &plan.playable, &handoff).unwrap());
        let h = facts(&fp, &handoff);
        assert!((h.video_sec.unwrap() - 4.0).abs() < 0.05, "{h:?}");

        let legacy = dir.join("legacy.mp4");
        run(&ff, &finalize_args(&opts, &tracks, &legacy).unwrap());
        let l = facts(&fp, &legacy);
        assert!(l.video_sec.unwrap() < 1.6, "the old composite cuts the picture: {l:?}");
        assert!(composite_lines_up(&h, &l).is_err(), "a short picture must never be swapped in");

        let deferred = dir.join("deferred.mp4");
        run(&ff, &camera_composite_args(&tracks, None, None, &deferred).unwrap());
        let d = facts(&fp, &deferred);
        assert!(composite_lines_up(&h, &d).is_ok(), "{h:?} vs {d:?}");

        // A hand-off that lost its sound (raw screen copy fallback) is never swapped to a sounded composite.
        let silent = StreamFacts { audio_sample_rate: 0, ..h };
        assert!(composite_lines_up(&silent, &d).is_err());
        std::fs::remove_dir_all(&dir).ok();
    }

    /// Review regression: a VFR screen track with a 2 s static gap (no frames
    /// written while nothing changed) must still be accepted, at the end of the
    /// take and in the middle of it.
    #[test]
    fn sparse_vfr_screen_with_a_static_gap_still_swaps() {
        let (Some(ff), Some(fp)) = (bundled("ffmpeg"), bundled("ffprobe")) else {
            eprintln!("bundled ffmpeg/ffprobe missing; skipped");
            return;
        };
        for (label, select) in [("end", "lt(t\\,2)"), ("middle", "lt(t\\,1)+gte(t\\,3)")] {
            let dir = std::env::temp_dir().join(format!("yc-vfr-{label}-{}", uuid::Uuid::new_v4()));
            std::fs::create_dir_all(&dir).unwrap();
            let p = |n: &str| dir.join(n).to_string_lossy().into_owned();
            let a = |v: &[&str]| v.iter().map(|s| s.to_string()).collect::<Vec<_>>();
            run(&ff, &a(&["-v", "error", "-y", "-f", "lavfi", "-i", "testsrc2=size=640x360:rate=30:duration=4",
                "-vf", &format!("select='{select}'"), "-fps_mode", "passthrough",
                "-c:v", "libx264", "-pix_fmt", "yuv420p", &p("screen.mp4")]));
            run(&ff, &a(&["-v", "error", "-y", "-f", "lavfi", "-i", "testsrc2=size=320x180:rate=30:duration=4",
                "-c:v", "libx264", "-pix_fmt", "yuv420p", &p("camera.mp4")]));
            run(&ff, &a(&["-v", "error", "-y", "-f", "lavfi", "-i", "sine=frequency=440:sample_rate=48000:duration=4",
                "-c:a", "aac", &p("mic.m4a")]));
            let tracks = NativeTracks::scan(&dir);
            let opts = base_opts(RecordMode::ScreenCamera);
            let handoff = dir.join("handoff.mp4");
            run(&ff, &finalize_args(&opts, &plan_stop_handoff(&opts, &tracks).playable, &handoff).unwrap());
            let composite = dir.join("composite.mp4");
            run(&ff, &camera_composite_args(&tracks, None, None, &composite).unwrap());
            let (h, c) = (facts(&fp, &handoff), facts(&fp, &composite));
            if label == "end" {
                assert!(h.video_sec.unwrap() < h.container_sec.unwrap() - 1.0, "really sparse: {h:?}");
            }
            assert!(composite_lines_up(&h, &c).is_ok(), "{label}: {h:?} vs {c:?}");
            std::fs::remove_dir_all(&dir).ok();
        }
    }

    #[test]
    fn tracks_scan_ignores_missing_and_empty_files() {
        let dir = std::env::temp_dir().join(format!("yc-scan-{}", uuid::Uuid::new_v4()));
        std::fs::create_dir_all(&dir).unwrap();
        std::fs::write(dir.join("screen.mp4"), b"data").unwrap();
        std::fs::write(dir.join("camera.mp4"), b"").unwrap();
        let t = NativeTracks::scan(&dir);
        assert_eq!(t.screen, Some(dir.join("screen.mp4")));
        assert_eq!(t.camera, None);
        assert!(t.microphone.is_none() && !t.is_empty() && t.has_video());
        let from = NativeTracks::from_files(&json!({"screen": dir.join("screen.mp4").to_string_lossy(), "camera": dir.join("camera.mp4").to_string_lossy()}));
        assert!(from.existing().camera.is_none());
        std::fs::remove_dir_all(&dir).ok();
    }

    // ----- protocol over in-memory streams ----------------------------------

    fn tail() -> Arc<StdMutex<String>> {
        Arc::new(StdMutex::new(String::new()))
    }

    #[tokio::test]
    async fn responses_are_matched_by_id_even_out_of_order() {
        let (client_side, helper_side) = duplex(8192);
        let (cr, cw) = tokio::io::split(client_side);
        let (hr, mut hw) = tokio::io::split(helper_side);
        let client = Arc::new(HelperClient::from_io(cr, cw, None, tail()));

        // Fake helper: read two requests, answer them in reverse order, with
        // noise (garbage + an unsolicited event) in between.
        tokio::spawn(async move {
            let mut lines = BufReader::new(hr).lines();
            let a = lines.next_line().await.unwrap().unwrap();
            let b = lines.next_line().await.unwrap().unwrap();
            let id = |l: &str| serde_json::from_str::<Value>(l).unwrap()["id"].as_u64().unwrap();
            let (ia, ib) = (id(&a), id(&b));
            hw.write_all(b"this is not json\n").await.unwrap();
            hw.write_all(format!("{{\"event\":\"state\",\"state\":\"recording\"}}\n").as_bytes()).await.unwrap();
            hw.write_all(format!("{{\"id\":{ib},\"ok\":true,\"result\":{{\"which\":\"b\"}}}}\n").as_bytes()).await.unwrap();
            hw.write_all(format!("{{\"id\":{ia},\"ok\":true,\"result\":{{\"which\":\"a\"}}}}\n").as_bytes()).await.unwrap();
        });

        let mut events = client.take_events().unwrap();
        let (c1, c2) = (client.clone(), client.clone());
        let (ra, rb) = tokio::join!(
            async move { c1.request("status", Value::Null, Duration::from_secs(5)).await },
            async move { c2.request("status", json!({}), Duration::from_secs(5)).await },
        );
        assert_eq!(ra.unwrap()["which"], "a");
        assert_eq!(rb.unwrap()["which"], "b");
        let ev = events.recv().await.unwrap();
        assert_eq!((ev.name.as_str(), ev.data["state"].as_str()), ("state", Some("recording")));
    }

    #[tokio::test]
    async fn eof_fails_pending_requests_and_emits_exited() {
        let (client_side, helper_side) = duplex(8192);
        let (cr, cw) = tokio::io::split(client_side);
        let client = HelperClient::from_io(cr, cw, None, tail());
        let mut events = client.take_events().unwrap();
        let req = client.request("stop", Value::Null, Duration::from_secs(5));
        let kill = async {
            tokio::time::sleep(Duration::from_millis(50)).await;
            drop(helper_side);
        };
        let (res, _) = tokio::join!(req, kill);
        assert_eq!(res, Err(HelperError::Closed));
        assert_eq!(events.recv().await.unwrap().name, "exited");
        assert!(!client.is_alive());
        assert_eq!(client.request("status", Value::Null, Duration::from_secs(1)).await, Err(HelperError::Closed));
    }

    #[tokio::test]
    async fn cancelling_a_pending_start_returns_at_once_instead_of_waiting_for_the_helper() {
        use crate::recording_session::{or_cancelled, Backend, SessionAuthority};
        let (client_side, _silent_helper) = duplex(8192);
        let (cr, cw) = tokio::io::split(client_side);
        let client = HelperClient::from_io(cr, cw, None, tail());
        let authority = SessionAuthority::default();
        let mut ticket = authority.begin("screen", Backend::Native).unwrap();
        let sid = ticket.id.to_string();
        let began = std::time::Instant::now();
        let cancel = async {
            tokio::time::sleep(Duration::from_millis(40)).await;
            authority.request_abort(&sid).unwrap();
        };
        let start = or_cancelled(
            &mut ticket.cancel,
            client.request("start", json!({}), START_TIMEOUT),
        );
        let (outcome, ()) = tokio::join!(start, cancel);
        assert!(outcome.is_err(), "the 120 s start request must be abandoned");
        assert!(began.elapsed() < Duration::from_secs(2));
    }

    #[tokio::test]
    async fn unanswered_request_times_out() {
        let (client_side, _helper_side) = duplex(8192);
        let (cr, cw) = tokio::io::split(client_side);
        let client = HelperClient::from_io(cr, cw, None, tail());
        let r = client.request("status", Value::Null, Duration::from_millis(80)).await;
        assert_eq!(r, Err(HelperError::Timeout("status".into())));
        assert!(client.pending.lock().unwrap().is_empty(), "timed-out waiters are cleaned up");
    }

    #[tokio::test]
    async fn requests_are_written_as_single_json_lines() {
        let (client_side, helper_side) = duplex(8192);
        let (cr, cw) = tokio::io::split(client_side);
        let client = HelperClient::from_io(cr, cw, None, tail());
        let params = json!({"display": 69, "outDir": "/tmp/x y", "systemAudio": true});
        let _ = client.request("start", params, Duration::from_millis(30)).await;
        let mut lines = BufReader::new(helper_side).lines();
        let sent: Value = serde_json::from_str(&lines.next_line().await.unwrap().unwrap()).unwrap();
        assert_eq!(sent["cmd"], "start");
        assert_eq!(sent["display"], 69);
        assert_eq!(sent["outDir"], "/tmp/x y");
        assert!(sent["id"].is_u64());
    }

    // ----- protocol against a real (fake) helper process --------------------

    /// A shell stand-in for `yusafcut-capture`: same line protocol, canned answers.
    const FAKE_HELPER: &str = r#"#!/bin/sh
echo '{"event":"ready","version":"test","pid":1}'
while IFS= read -r line; do
  id=$(printf '%s' "$line" | sed -n 's/.*"id":\([0-9][0-9]*\).*/\1/p')
  case "$line" in
    *'"cmd":"list-devices"'*)
      echo '{"id":'$id',"ok":true,"result":{"displays":[{"id":69,"name":"Main"}],"windows":[],"cameras":[{"id":"cam","name":"Cam"}],"microphones":[{"id":"mic","name":"Mic","isDefault":true}],"permissions":{"screenRecording":"granted"}}}' ;;
    *'"cmd":"start"'*)
      dir=$(printf '%s' "$line" | sed -n 's/.*"outDir":"\([^"]*\)".*/\1/p')
      mkdir -p "$dir"; printf 'x' > "$dir/screen.mp4"; printf '{}' > "$dir/events.jsonl"
      printf '%s' "$line" > "$dir/start-request.json"
      echo '{"id":'$id',"ok":true,"result":{"files":{"screen":"'$dir'/screen.mp4","events":"'$dir'/events.jsonl"}}}'
      echo '{"event":"state","state":"recording","elapsed":0}' ;;
    *'"cmd":"pause"'*|*'"cmd":"resume"'*|*'"cmd":"status"'*)
      echo '{"id":'$id',"ok":true,"result":{"elapsed":1.5,"state":"recording"}}' ;;
    *'"cmd":"stop"'*)
      echo '{"id":'$id',"ok":true,"result":{"durationSec":1.5,"files":{"screen":"'$FAKE_DIR'/screen.mp4"}}}' ;;
    *'"cmd":"deny"'*)
      echo '{"id":'$id',"ok":false,"error":{"code":"permission-denied","message":"Screen Recording is off"}}' ;;
    *'"cmd":"hang"'*) : ;;
    *'"cmd":"boom"'*) exit 3 ;;
    *'"cmd":"quit"'*) echo '{"id":'$id',"ok":true,"result":{}}'; exit 0 ;;
    *) echo '{"id":'$id',"ok":false,"error":{"code":"bad-request","message":"unknown"}}' ;;
  esac
done
"#;

    fn write_script(name: &str, body: &str) -> PathBuf {
        use std::os::unix::fs::PermissionsExt;
        let dir = std::env::temp_dir().join(format!("yc-fake-{}-{}", name, uuid::Uuid::new_v4()));
        std::fs::create_dir_all(&dir).unwrap();
        let path = dir.join("helper.sh");
        std::fs::write(&path, body).unwrap();
        std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o755)).unwrap();
        path
    }

    #[tokio::test]
    async fn full_session_against_fake_helper_process() {
        let script = write_script("session", FAKE_HELPER);
        let client = HelperClient::spawn(&script).await.expect("spawn");
        let mut events = client.take_events().unwrap();

        let listing = client.request("list-devices", Value::Null, DEFAULT_TIMEOUT).await.unwrap();
        let native = NativeDevices::parse(&listing).unwrap();
        assert_eq!(native.displays[0].id, 69);

        let out = std::env::temp_dir().join(format!("yc-take-{}", uuid::Uuid::new_v4()));
        let opts = RecordOptions { screen_index: Some(1000), audio_index: Some(1000), ..base_opts(RecordMode::Screen) };
        let params = build_start_params(&opts, &native, &out).unwrap();
        let started = client.request("start", params, START_TIMEOUT).await.unwrap();
        assert!(started["files"]["screen"].as_str().unwrap().ends_with("screen.mp4"));
        let ev = events.recv().await.unwrap();
        assert_eq!((ev.name.as_str(), ev.data["state"].as_str()), ("state", Some("recording")));

        assert_eq!(client.request("pause", Value::Null, DEFAULT_TIMEOUT).await.unwrap()["elapsed"], 1.5);
        client.request("resume", Value::Null, DEFAULT_TIMEOUT).await.unwrap();
        let st = client.request("status", Value::Null, DEFAULT_TIMEOUT).await.unwrap();
        assert_eq!(st["state"], "recording");

        let denied = client.request("deny", Value::Null, DEFAULT_TIMEOUT).await.unwrap_err();
        assert_eq!(denied, HelperError::Rejected { code: "permission-denied".into(), message: "Screen Recording is off".into() });
        assert!(!denied.is_fallback());

        client.shutdown().await;
        for _ in 0..50 {
            if !client.is_alive() {
                break;
            }
            tokio::time::sleep(Duration::from_millis(20)).await;
        }
        assert!(!client.is_alive());
        std::fs::remove_dir_all(&out).ok();
    }

    #[tokio::test]
    async fn key_identity_flags_reach_the_helper_only_when_opted_in() {
        let script = write_script("keyid", FAKE_HELPER);
        let client = HelperClient::spawn(&script).await.expect("spawn");
        let listing = client.request("list-devices", Value::Null, DEFAULT_TIMEOUT).await.unwrap();
        let native = NativeDevices::parse(&listing).unwrap();
        let cases = [
            (None, None, false, false),
            (Some(false), Some(true), false, false), // second flag alone is never sent
            (Some(true), None, true, false),
            (Some(true), Some(true), true, true),
        ];
        for (identity, all, want_identity, want_all) in cases {
            let out = std::env::temp_dir().join(format!("yc-keyid-{}", uuid::Uuid::new_v4()));
            let opts = RecordOptions {
                screen_index: Some(1000),
                record_key_identity: identity,
                record_all_characters: all,
                ..base_opts(RecordMode::Screen)
            };
            let params = build_start_params(&opts, &native, &out).unwrap();
            client.request("start", params, START_TIMEOUT).await.unwrap();
            let line = std::fs::read_to_string(out.join("start-request.json")).unwrap();
            let sent: Value = serde_json::from_str(&line).unwrap();
            assert_eq!(sent["recordKeyIdentity"] == true, want_identity, "{identity:?}/{all:?}");
            assert_eq!(sent["recordAllCharacters"] == true, want_all, "{identity:?}/{all:?}");
            std::fs::remove_dir_all(&out).ok();
        }
        client.shutdown().await;
    }

    #[tokio::test]
    async fn helper_dying_mid_take_surfaces_closed_and_exited() {
        let script = write_script("boom", FAKE_HELPER);
        let client = HelperClient::spawn(&script).await.unwrap();
        let mut events = client.take_events().unwrap();
        let r = client.request("boom", Value::Null, DEFAULT_TIMEOUT).await;
        assert_eq!(r, Err(HelperError::Closed));
        assert_eq!(events.recv().await.unwrap().name, "exited");
        client.kill().await;
    }

    #[tokio::test]
    async fn hung_request_times_out_against_real_process() {
        let script = write_script("hang", FAKE_HELPER);
        let client = HelperClient::spawn(&script).await.unwrap();
        let r = client.request("hang", Value::Null, Duration::from_millis(200)).await;
        assert_eq!(r, Err(HelperError::Timeout("hang".into())));
        client.shutdown().await;
    }

    #[tokio::test]
    async fn missing_binary_is_unavailable() {
        let err = HelperClient::spawn(Path::new("/definitely/not/here/yusafcut-capture")).await.err().unwrap();
        assert!(matches!(err, HelperError::Unavailable(_)));
        assert!(err.is_fallback());
    }

    #[tokio::test]
    async fn stub_that_exits_immediately_is_unavailable_with_its_message() {
        let script = write_script("stub", "#!/bin/sh\necho 'native helper not built' >&2\nexit 78\n");
        let err = HelperClient::spawn(&script).await.err().unwrap();
        match err {
            HelperError::Unavailable(m) => assert!(m.contains("exited before it was ready"), "{m}"),
            other => panic!("unexpected {other:?}"),
        }
    }

    #[tokio::test]
    async fn silent_helper_that_never_says_ready_is_unavailable() {
        let script = write_script("silent", "#!/bin/sh\nsleep 30\n");
        let t = tokio::time::Instant::now();
        let err = HelperClient::spawn(&script).await.err().unwrap();
        assert!(matches!(err, HelperError::Unavailable(_)));
        assert!(t.elapsed() < Duration::from_secs(8));
    }

    /// End-to-end against the real Swift helper and bundled ffmpeg. Needs macOS
    /// Screen Recording permission, so it only runs on request:
    /// `YUSAFCUT_E2E=1 cargo test native_capture::tests::e2e -- --nocapture`
    #[tokio::test]
    async fn e2e_screen_take_through_real_helper() {
        if std::env::var("YUSAFCUT_E2E").map(|v| v != "1").unwrap_or(true) {
            eprintln!("skipped (set YUSAFCUT_E2E=1)");
            return;
        }
        let bins = Path::new(env!("CARGO_MANIFEST_DIR")).join("binaries");
        let helper = bins.join("yusafcut-capture-aarch64-apple-darwin");
        let ffmpeg = bins.join("ffmpeg-aarch64-apple-darwin");
        let client = HelperClient::spawn(&helper).await.expect("helper starts");
        let listing = client.request("list-devices", Value::Null, DEFAULT_TIMEOUT).await.unwrap();
        let native = NativeDevices::parse(&listing).unwrap();
        let recording_devices = native.to_recording_devices();
        let screen = recording_devices.video.iter().find(|v| v.is_screen).expect("a display").index;

        let out = std::env::temp_dir().join(format!("yc-e2e-{}", uuid::Uuid::new_v4()));
        let opts = RecordOptions { screen_index: Some(screen), ..base_opts(RecordMode::Screen) };
        let params = build_start_params(&opts, &native, &out.join("tracks")).unwrap();
        client.request("start", params, START_TIMEOUT).await.expect("start");
        tokio::time::sleep(Duration::from_millis(1500)).await;
        client.request("pause", Value::Null, DEFAULT_TIMEOUT).await.unwrap();
        tokio::time::sleep(Duration::from_millis(500)).await;
        client.request("resume", Value::Null, DEFAULT_TIMEOUT).await.unwrap();
        tokio::time::sleep(Duration::from_millis(1500)).await;
        let stopped = client.request("stop", Value::Null, STOP_TIMEOUT).await.expect("stop");
        client.shutdown().await;

        let dur = stopped["durationSec"].as_f64().unwrap();
        assert!((2.5..4.0).contains(&dur), "pause is excluded from the timeline: {dur}");
        let tracks = NativeTracks::from_files(&stopped["files"]).existing();
        assert!(tracks.screen.is_some(), "screen track has data");
        let final_path = out.join("final.mp4");
        let args = finalize_args(&opts, &tracks, &final_path).unwrap();
        let status = std::process::Command::new(&ffmpeg).args(&args).output().unwrap();
        assert!(status.status.success(), "{}", String::from_utf8_lossy(&status.stderr));
        assert!(std::fs::metadata(&final_path).unwrap().len() > 10_000);
        let events = std::fs::read_to_string(out.join("tracks/events.jsonl")).unwrap();
        assert!(events.lines().next().unwrap().contains("\"type\":\"header\""));
        assert!(events.contains("\"type\":\"pause\"") && events.contains("\"type\":\"end\""));
        eprintln!("e2e ok: {} ({dur:.2}s)", final_path.display());
        std::fs::remove_dir_all(&out).ok();
    }
}
