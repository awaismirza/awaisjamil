//! Pure, streaming vector cursor export. ASS drawings use bundled libass; no fonts
//! or raster sprites are needed. Source-time sampling matches cursor.ts/style.ts.
use crate::edl::Project;
use serde::Deserialize;
use std::collections::HashMap;
use std::io::{self, Write};

#[derive(Clone, Debug, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct CursorStyle {
    pub show: bool,
    pub shape: String,
    pub size: f64,
    pub color: String,
    pub smoothing: f64,
    pub click_effect: String,
    pub hide_when_idle: bool,
    pub motion_blur: bool,
}
impl Default for CursorStyle {
    fn default() -> Self {
        Self {
            show: true,
            shape: "macos".into(),
            size: 32.,
            color: "#ffffff".into(),
            smoothing: 0.1,
            click_effect: "ripple".into(),
            hide_when_idle: false,
            motion_blur: false,
        }
    }
}
#[derive(Clone, Debug, Default, Deserialize)]
pub struct CursorConfig {
    #[serde(default)]
    pub style: CursorStyle,
    #[serde(default)]
    pub tracks: HashMap<String, RawTrack>,
}
#[derive(Clone, Debug, Default, Deserialize)]
pub struct RawTrack {
    #[serde(default)]
    pub events: Vec<Event>,
}
#[derive(Clone, Debug, Deserialize)]
pub struct Event {
    #[serde(rename = "type")]
    pub kind: String,
    pub t: f64,
    pub x: Option<f64>,
    pub y: Option<f64>,
    #[serde(default)]
    pub outside: bool,
}
#[derive(Clone, Copy, Debug)]
struct Point {
    t: f64,
    x: f64,
    y: f64,
    outside: bool,
}
struct Track {
    events: Vec<Event>,
    points: Vec<Point>,
}
impl Track {
    fn new(raw: &RawTrack, smoothing: f64) -> Self {
        let mut events: Vec<_> = raw
            .events
            .iter()
            .filter(|e| {
                e.t.is_finite()
                    && e.t >= 0.
                    && matches!(
                        e.kind.as_str(),
                        "move" | "down" | "up" | "key" | "scroll" | "cursorshape"
                    )
            })
            .cloned()
            .collect();
        events.sort_by(|a, b| a.t.total_cmp(&b.t));
        let mut points: Vec<Point> = Vec::new();
        for e in &events {
            if !matches!(e.kind.as_str(), "move" | "down" | "up") {
                continue;
            }
            if let (Some(x), Some(y)) = (e.x, e.y) {
                if !x.is_finite() || !y.is_finite() {
                    continue;
                }
                let p = Point {
                    t: e.t,
                    x: x.clamp(0., 1.),
                    y: y.clamp(0., 1.),
                    outside: e.outside,
                };
                if points.last().is_some_and(|last| last.t == p.t) {
                    points.pop();
                }
                points.push(p);
            }
        }
        if smoothing.is_finite() && smoothing > 0. && points.len() >= 3 {
            let radius = smoothing.min(0.5);
            let source = points.clone();
            let (mut left, mut right, mut sx, mut sy) = (0, 0, 0., 0.);
            for (i, p) in source.iter().enumerate() {
                let start = i == 0 || source[i - 1].outside != p.outside;
                if start {
                    left = i;
                    right = i;
                    sx = 0.;
                    sy = 0.;
                }
                while right < source.len()
                    && source[right].outside == p.outside
                    && source[right].t <= p.t + radius
                {
                    sx += source[right].x;
                    sy += source[right].y;
                    right += 1;
                }
                while left < right && source[left].t < p.t - radius {
                    sx -= source[left].x;
                    sy -= source[left].y;
                    left += 1;
                }
                if !(start || i + 1 == source.len() || source[i + 1].outside != p.outside) {
                    points[i].x = (sx / (right - left) as f64).clamp(0., 1.);
                    points[i].y = (sy / (right - left) as f64).clamp(0., 1.);
                }
            }
        }
        Self { events, points }
    }
    fn at(&self, t: f64) -> Option<Point> {
        let i = self.points.partition_point(|p| p.t <= t).checked_sub(1)?;
        let a = self.points[i];
        let Some(b) = self.points.get(i + 1) else {
            return Some(Point { t, ..a });
        };
        if a.outside != b.outside {
            return Some(Point { t, ..a });
        }
        let f = (t - a.t) / (b.t - a.t);
        Some(Point {
            t,
            x: a.x + (b.x - a.x) * f,
            y: a.y + (b.y - a.y) * f,
            outside: a.outside,
        })
    }
}
struct Appearance<'a> {
    point: Point,
    visible: bool,
    clicks: Vec<&'a Event>,
    bounce: f64,
}
impl Track {
    fn appearance(&self, t: f64, style: &CursorStyle, clip_start: f64) -> Option<Appearance<'_>> {
        let point = self.at(t)?;
        let end = self.events.partition_point(|e| e.t <= t);
        let last = self
            .events
            .get(end.checked_sub(1)?)
            .map_or(f64::NEG_INFINITY, |e| e.t);
        let visible = style.show && !point.outside && (!style.hide_when_idle || t - last <= 1.5);
        let clicks: Vec<_> = if style.click_effect == "none" {
            Vec::new()
        } else {
            self.events[..end]
                .iter()
                .rev()
                .take_while(|e| e.t >= clip_start.max(t - 0.45))
                .filter(|e| e.kind == "down" && !e.outside && e.x.is_some() && e.y.is_some())
                .collect()
        };
        let bounce = if style.click_effect == "bounce" {
            clicks.first().map_or(1., |e| {
                1. - 0.22 * (std::f64::consts::PI * (t - e.t) / 0.45).sin()
            })
        } else {
            1.
        };
        Some(Appearance {
            point,
            visible,
            clicks,
            bounce,
        })
    }
}
impl CursorConfig {
    pub fn active(&self, project: &Project) -> bool {
        self.style.show
            && project.segments.iter().any(|s| {
                self.tracks.get(&s.media_id).is_some_and(|track| {
                    track.events.iter().any(|e| {
                        matches!(e.kind.as_str(), "move" | "down" | "up")
                            && e.x.is_some()
                            && e.y.is_some()
                    })
                })
            })
    }
}
fn time(t: f64) -> String {
    let cs = (t * 100. + 1e-7).floor().max(0.) as u64;
    format!(
        "{}:{:02}:{:02}.{:02}",
        cs / 360000,
        (cs / 6000) % 60,
        (cs / 100) % 60,
        cs % 100
    )
}
fn color(s: &str) -> String {
    if s.len() == 7 && s.starts_with('#') && s[1..].bytes().all(|b| b.is_ascii_hexdigit()) {
        format!("{}{}{}", &s[5..7], &s[3..5], &s[1..3])
    } else {
        "FFFFFF".into()
    }
}
/// Translate/scaled path coordinates directly: ASS's origin remains the video's
/// top-left, including glyphs with negative coordinates and clipped edge cursors.
fn path(raw: &str, x: f64, y: f64, scale: f64) -> String {
    let mut axis = 0;
    raw.split_whitespace()
        .map(|token| {
            if let Ok(n) = token.parse::<f64>() {
                let v = if axis % 2 == 0 {
                    x + n * scale
                } else {
                    y + n * scale
                };
                axis += 1;
                format!("{v:.3}")
            } else {
                axis = 0;
                token.to_string()
            }
        })
        .collect::<Vec<_>>()
        .join(" ")
}
fn circle(r: f64) -> String {
    let k = r * 0.55228475;
    let nr = -r;
    let nk = -k;
    format!("m {r} 0 b {r} {k} {k} {r} 0 {r} b {nk} {r} {nr} {k} {nr} 0 b {nr} {nk} {nk} {nr} 0 {nr} b {k} {nr} {r} {nk} {r} 0")
}
fn glyph(shape: &str) -> String {
    match shape {
        "dot"=>circle(5.), "ring"=>circle(10.),
        "crosshair"=>"m -13 0 l 13 0 m 0 -13 l 0 13".into(),
        "pointer"=>"m 0 0 b 0 -3 5 -3 5 0 l 5 11 7 9 b 9 8 11 9 11 11 b 14 8 17 10 17 13 b 20 11 23 13 23 16 l 23 23 b 23 30 8 32 5 25 l -3 15 b -5 11 -1 9 2 12 l 5 15 5 0".into(),
        "macos"=>"m 0 0 l 0 30 8 22 14 34 20 31 14 19 25 19 0 0".into(),
        _=>"m 0 0 l 0 29 8 21 14 33 20 30 14 18 25 18 0 0".into(),
    }
}
struct Drawing<'a, W: Write> {
    out: &'a mut W,
    start: f64,
    end: f64,
    color: String,
    scale: f64,
}
impl<W: Write> Drawing<'_, W> {
    fn event(
        &mut self,
        p: &str,
        x: f64,
        y: f64,
        scale: f64,
        fill: &str,
        stroke: &str,
        border: f64,
        opacity: f64,
        blur: f64,
    ) -> io::Result<()> {
        let alpha = ((1. - opacity.clamp(0., 1.)) * 255.).round() as u8;
        let painted_fill = if fill == "transparent" {
            "FFFFFF"
        } else {
            fill
        };
        writeln!(self.out,"Dialogue: 0,{},{},Cursor,,0,0,0,,{{\\an7\\pos(0,0)\\p1\\shad0\\bord{border:.3}\\blur{blur:.3}\\1c&H{painted_fill}&\\3c&H{stroke}&\\alpha&H{alpha:02X}&{}}}{}",
            time(self.start),time(self.end),if fill=="transparent" {"\\1a&HFF&"} else {""},path(p,x,y,scale))
    }
    fn cursor(
        &mut self,
        style: &CursorStyle,
        p: Point,
        w: f64,
        h: f64,
        ox: f64,
        oy: f64,
        bounce: f64,
        opacity: f64,
        blur: f64,
    ) -> io::Result<()> {
        let (fill, stroke, border) = match style.shape.as_str() {
            "macos" => ("101010", self.color.as_str(), 0.9),
            "ring" => ("transparent", self.color.as_str(), 1.25),
            "crosshair" => ("transparent", self.color.as_str(), 1.),
            _ => (self.color.as_str(), "171717", 0.75),
        };
        let fill = fill.to_string();
        let stroke = stroke.to_string();
        self.event(
            &glyph(&style.shape),
            ox + p.x * w,
            oy + p.y * h,
            self.scale * bounce,
            &fill,
            &stroke,
            border * self.scale * bounce,
            opacity,
            blur,
        )
    }
}
/// Stream one event group per output frame; memory is bounded by source logs.
/// Cancellation is checked at every frame, before any further expensive drawing.
pub fn write_ass<W: Write>(
    out: &mut W,
    config: &CursorConfig,
    project: &Project,
    width: u32,
    height: u32,
    fps: f64,
    mut cancelled: impl FnMut() -> bool,
) -> Result<u64, String> {
    if width == 0 || height == 0 || !fps.is_finite() || !(1. ..=60.).contains(&fps) {
        return Err("invalid cursor export dimensions/fps".into());
    }
    let tracks: HashMap<_, _> = config
        .tracks
        .iter()
        .map(|(id, raw)| (id, Track::new(raw, config.style.smoothing)))
        .collect();
    writeln!(out,"[Script Info]\nScriptType: v4.00+\nPlayResX: {width}\nPlayResY: {height}\nScaledBorderAndShadow: yes\n[V4+ Styles]\nFormat: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\nStyle: Cursor,Arial,20,&H00FFFFFF,&H00FFFFFF,&H00171717,&H00000000,0,0,0,0,100,100,0,0,1,0,0,7,0,0,0,1\n[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text").map_err(|e|e.to_string())?;
    let total: f64 = project
        .segments
        .iter()
        .map(|s| s.output_len())
        .sum();
    if !total.is_finite() || total > 43200. {
        return Err("cursor export exceeds 12-hour duration limit".into());
    }
    let (mut entry, mut offset) = (0, 0.);
    let mut frames = 0;
    for frame in 0..(total * fps).ceil() as u64 {
        if cancelled() {
            return Err("cancelled".into());
        }
        let t = frame as f64 / fps;
        while let Some(s) = project.segments.get(entry) {
            let length = s.output_len();
            if t < offset + length {
                break;
            }
            offset += length;
            entry += 1;
        }
        let Some(seg) = project.segments.get(entry) else {
            break;
        };
        let Some(track) = tracks.get(&seg.media_id) else {
            continue;
        };
        if !config.style.show {
            continue;
        }
        let source = seg.source_at(t - offset);
        let Some(sample) = track.appearance(source, &config.style, seg.source_in) else {
            continue;
        };
        if !sample.visible {
            continue;
        }
        let point = sample.point;
        let clicks = sample.clicks;
        let media = project
            .media
            .get(&seg.media_id)
            .ok_or("cursor source is missing")?;
        let fit = (width as f64 / media.width.max(1) as f64)
            .min(height as f64 / media.height.max(1) as f64);
        let (w, h) = (media.width as f64 * fit, media.height as f64 * fit);
        let (ox, oy) = ((width as f64 - w) / 2., (height as f64 - h) / 2.);
        let size = if config.style.size.is_finite() {
            config.style.size.clamp(12., 96.)
        } else {
            32.
        } * h
            / 1080.;
        let mut d = Drawing {
            out,
            start: t,
            end: ((frame + 1) as f64 / fps).min(total),
            color: color(&config.style.color),
            scale: size / 32.,
        };
        if config.style.motion_blur {
            for (i, age) in [1. / 30., 1. / 60.].iter().enumerate() {
                if source - age < seg.source_in {
                    continue;
                }
                if let Some(p) = track.at(source - age) {
                    if !p.outside && (p.x - point.x).hypot(p.y - point.y) > 0.001 {
                        d.cursor(
                            &config.style,
                            p,
                            w,
                            h,
                            ox,
                            oy,
                            1.,
                            (i + 1) as f64 * 0.1,
                            h / 1080.,
                        )
                        .map_err(|e| e.to_string())?;
                    }
                }
            }
        }
        if matches!(config.style.click_effect.as_str(), "ripple" | "ring") {
            for click in &clicks {
                let progress = (source - click.t) / 0.45;
                let radius = size
                    * if config.style.click_effect == "ripple" {
                        0.4 + progress * 1.6
                    } else {
                        0.65
                    };
                let c = d.color.clone();
                d.event(
                    &circle(radius),
                    ox + click.x.unwrap().clamp(0., 1.) * w,
                    oy + click.y.unwrap().clamp(0., 1.) * h,
                    1.,
                    "transparent",
                    &c,
                    h / 1080.,
                    1. - progress,
                    0.,
                )
                .map_err(|e| e.to_string())?;
            }
        }
        let bounce = sample.bounce;
        d.cursor(&config.style, point, w, h, ox, oy, bounce, 1., 0.)
            .map_err(|e| e.to_string())?;
        frames += 1;
    }
    Ok(frames)
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;
    use std::process::Command;
    fn project() -> Project {
        serde_json::from_value(json!({"version":1,"id":"p","name":"cursor","createdAt":"","updatedAt":"",
            "media":{"m":{"id":"m","path":"unused","duration":5,"fps":30,"width":640,"height":360,"audioSampleRate":48000,"sha256":""}},
            "segments":[{"id":"s","mediaId":"m","sourceIn":1,"sourceOut":2,"words":[]}],
            "settings":{"exportPreset":"youtube-1080p","paddingMs":0}})).unwrap()
    }
    fn config(shape: &str) -> CursorConfig {
        serde_json::from_value(
            json!({"style":{"shape":shape,"size":96,"smoothing":0,"clickEffect":"none"},
            "tracks":{"m":{"events":[{"type":"move","t":0,"x":0.5,"y":0.5}]}}}),
        )
        .unwrap()
    }
    #[test]
    #[ignore = "explicit synthetic filter benchmark; not release certification"]
    fn benchmark_vector_cursor_rendering() {
        let ff = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("binaries/ffmpeg-aarch64-apple-darwin");
        assert!(ff.exists());
        let dir =
            std::env::temp_dir().join(format!("yusafcut-cursor-bench-{}", uuid::Uuid::new_v4()));
        std::fs::create_dir_all(&dir).unwrap();
        let mut p = project();
        p.segments[0].source_out = 31.;
        let media = p.media.get_mut("m").unwrap();
        media.duration = 32.;
        media.width = 1920;
        media.height = 1080;
        let mut c = config("macos");
        c.style.smoothing = 0.1;
        c.style.motion_blur = true;
        c.style.click_effect = "ripple".into();
        let events = &mut c.tracks.get_mut("m").unwrap().events;
        events.clear();
        for i in 0..=1860 {
            let t = i as f64 / 60.;
            events.push(Event {
                kind: if i % 60 == 0 { "down" } else { "move" }.into(),
                t,
                x: Some(0.5 + 0.35 * (t * 2.).sin()),
                y: Some(0.5 + 0.3 * (t * 3.).cos()),
                outside: false,
            });
        }
        let ass = dir.join("activity.ass");
        let generation = std::time::Instant::now();
        let mut writer = std::io::BufWriter::new(std::fs::File::create(&ass).unwrap());
        let frames = write_ass(&mut writer, &c, &p, 1920, 1080, 30., || false).unwrap();
        writer.flush().unwrap();
        drop(writer);
        let generation_ms = generation.elapsed().as_secs_f64() * 1000.;
        let mut samples = Vec::new();
        for with_cursor in [false, true, false, true] {
            let now = std::time::Instant::now();
            let mut command = Command::new(&ff);
            command.args([
                "-v",
                "error",
                "-filter_threads",
                "1",
                "-f",
                "lavfi",
                "-i",
                "color=black:s=1920x1080:r=30:d=30",
            ]);
            if with_cursor {
                command.args(["-vf", &format!("ass={}", ass.display())]);
            }
            let result = command.args(["-f", "null", "-"]).output().unwrap();
            assert!(
                result.status.success(),
                "{}",
                String::from_utf8_lossy(&result.stderr)
            );
            samples.push(serde_json::json!({"cursor":with_cursor,"wallMs":now.elapsed().as_secs_f64()*1000.}));
        }
        let report = serde_json::json!({"scope":"synthetic 30-second 1080p/30 filter-only workload; debug Rust generator; no encode, UI, real footage or release certification", "frames":frames,"assBytes":std::fs::metadata(&ass).unwrap().len(),"generationMs":generation_ms,"style":"macos + smoothing + ripple + blurred trails","runs":samples});
        std::fs::write(
            "/private/tmp/yusafcut-cursor-vector-benchmark.json",
            serde_json::to_vec_pretty(&report).unwrap(),
        )
        .unwrap();
        eprintln!("{report}");
        std::fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn agrees_with_shared_typescript_preview_samples() {
        let fixture: serde_json::Value = serde_json::from_str(include_str!(
            "../../tests/fixtures/cursor-export-parity.json"
        ))
        .unwrap();
        let style: CursorStyle = serde_json::from_value(fixture["style"].clone()).unwrap();
        let raw: RawTrack =
            serde_json::from_value(serde_json::json!({"events":fixture["events"]})).unwrap();
        let track = Track::new(&raw, style.smoothing);
        for expected in fixture["samples"].as_array().unwrap() {
            let t = expected["t"].as_f64().unwrap();
            let sample = track.appearance(t, &style, 0.).unwrap();
            assert!(
                (sample.point.x - expected["point"]["x"].as_f64().unwrap()).abs() < 1e-10,
                "x at {t}"
            );
            assert!(
                (sample.point.y - expected["point"]["y"].as_f64().unwrap()).abs() < 1e-10,
                "y at {t}"
            );
            assert_eq!(
                sample.visible,
                expected["visible"].as_bool().unwrap(),
                "visibility at {t}"
            );
            assert!(
                (sample.bounce - expected["bounce"].as_f64().unwrap()).abs() < 1e-10,
                "bounce at {t}"
            );
            assert_eq!(
                sample.clicks.len(),
                expected["clicks"].as_array().unwrap().len()
            );
        }
    }

    #[test]
    fn smoothing_matches_convex_window_and_keeps_outside_boundaries() {
        let raw: RawTrack = serde_json::from_value(json!({"events":[
            {"type":"move","t":0,"x":0,"y":0},
            {"type":"move","t":0.1,"x":1,"y":1},
            {"type":"move","t":0.2,"x":0,"y":0},
            {"type":"move","t":0.3,"x":1,"y":1,"outside":true}]}))
        .unwrap();
        let track = Track::new(&raw, 0.15);
        assert_eq!(track.at(0.).unwrap().x, 0.);
        assert!((track.at(0.1).unwrap().x - 1. / 3.).abs() < 1e-9);
        assert_eq!(track.at(0.2).unwrap().x, 0.);
        assert!(!track.at(0.25).unwrap().outside);
        assert!(track.at(0.3).unwrap().outside);
    }
    #[test]
    fn cuts_repeats_and_preclip_clicks_follow_source_time() {
        let mut p = project();
        let mut repeated = p.segments[0].clone();
        repeated.id = "repeat".into();
        p.segments.push(repeated);
        let mut c = config("dot");
        c.style.click_effect = "ripple".into();
        c.tracks
            .get_mut("m")
            .unwrap()
            .events
            .push(serde_json::from_value(json!({"type":"down","t":0.9,"x":0.1,"y":0.1})).unwrap());
        let mut buf = Vec::new();
        assert_eq!(
            write_ass(&mut buf, &c, &p, 640, 360, 30., || false).unwrap(),
            60
        );
        let text = String::from_utf8(buf).unwrap();
        let events: Vec<_> = text.lines().filter(|l| l.starts_with("Dialogue")).collect();
        assert_eq!(events.len(), 60); // No ripple leaking from before sourceIn.
        assert_eq!(events[0].split(",,").last(), events[30].split(",,").last());
        assert!(events[30].starts_with("Dialogue: 0,0:00:01.00"));
    }
    #[test]
    fn hidden_idle_missing_tracks_and_cancellation_do_not_draw() {
        let p = project();
        let mut c = config("dot");
        c.style.hide_when_idle = true;
        let mut p = p.clone();
        p.segments[0].source_in = 2.;
        p.segments[0].source_out = 3.;
        assert_eq!(
            write_ass(&mut Vec::new(), &c, &p, 640, 360, 30., || false).unwrap(),
            0
        );
        assert!(write_ass(&mut Vec::new(), &c, &p, 640, 360, 30., || true)
            .unwrap_err()
            .contains("cancelled"));
        c.style.show = false;
        assert!(!c.active(&p));
    }
    #[test]
    fn static_screen_input_still_presents_moving_cursor_frames() {
        let ff = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("binaries/ffmpeg-aarch64-apple-darwin");
        if !ff.exists() {
            return;
        }
        let ass = std::env::temp_dir().join(format!(
            "yusafcut-cursor-static-{}.ass",
            uuid::Uuid::new_v4()
        ));
        let mut c = config("dot");
        c.tracks.get_mut("m").unwrap().events = serde_json::from_value(json!([
            {"type":"move","t":1,"x":0.2,"y":0.5},{"type":"move","t":2,"x":0.8,"y":0.5}]))
        .unwrap();
        write_ass(
            &mut std::fs::File::create(&ass).unwrap(),
            &c,
            &project(),
            640,
            360,
            30.,
            || false,
        )
        .unwrap();
        let out = Command::new(&ff)
            .args([
                "-v",
                "error",
                "-f",
                "lavfi",
                "-i",
                "color=black:s=640x360:r=1/3:d=3",
                "-vf",
                &format!("fps=30,ass={},select=eq(n\\,0)+eq(n\\,29)", ass.display()),
                "-fps_mode",
                "passthrough",
                "-frames:v",
                "2",
                "-pix_fmt",
                "rgb24",
                "-f",
                "rawvideo",
                "pipe:1",
            ])
            .output()
            .unwrap();
        assert!(
            out.status.success(),
            "{}",
            String::from_utf8_lossy(&out.stderr)
        );
        let bytes = 640 * 360 * 3;
        assert_eq!(out.stdout.len(), bytes * 2);
        let pixel = |frame: usize, x: usize| out.stdout[frame * bytes + (180 * 640 + x) * 3];
        assert!(pixel(0, 128) > 150);
        assert_eq!(pixel(0, 499), 0);
        assert!(pixel(1, 499) > 150);
        assert_eq!(pixel(1, 128), 0);
        std::fs::remove_file(ass).unwrap();
    }

    #[test]
    fn real_ffmpeg_click_rings_and_bounce_match_preview_geometry() {
        let ff = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("binaries/ffmpeg-aarch64-apple-darwin");
        if !ff.exists() {
            return;
        }
        let dir = std::env::temp_dir().join(format!("yusafcut-cursor-fx-{}", uuid::Uuid::new_v4()));
        std::fs::create_dir_all(&dir).unwrap();
        let mut c = config("dot");
        c.tracks.get_mut("m").unwrap().events = serde_json::from_value(json!([
            {"type":"move","t":0,"x":0.25,"y":0.5},
            {"type":"down","t":1.1,"x":0.25,"y":0.5,"button":"left"},
            {"type":"move","t":1.11,"x":0.75,"y":0.5}]))
        .unwrap();
        let mut cursor_areas = Vec::new();
        for effect in ["none", "ripple", "ring", "bounce"] {
            c.style.click_effect = effect.into();
            let ass = dir.join(format!("{effect}.ass"));
            write_ass(
                &mut std::fs::File::create(&ass).unwrap(),
                &c,
                &project(),
                640,
                360,
                30.,
                || false,
            )
            .unwrap();
            let out = Command::new(&ff)
                .args([
                    "-v",
                    "error",
                    "-f",
                    "lavfi",
                    "-i",
                    "color=black:s=640x360:r=30:d=1",
                    "-vf",
                    &format!("ass={},select=eq(n\\,8)", ass.display()),
                    "-frames:v",
                    "1",
                    "-pix_fmt",
                    "rgb24",
                    "-f",
                    "rawvideo",
                    "pipe:1",
                ])
                .output()
                .unwrap();
            assert!(
                out.status.success(),
                "{}",
                String::from_utf8_lossy(&out.stderr)
            );
            assert_eq!(out.stdout.len(), 640 * 360 * 3);
            let brightness = |x: usize, y: usize| {
                *out.stdout[(y * 640 + x) * 3..(y * 640 + x) * 3 + 3]
                    .iter()
                    .max()
                    .unwrap()
            };
            let radius: f64 = if effect == "ripple" {
                32. * (0.4 + ((1. + 8. / 30. - 1.1) / 0.45) * 1.6)
            } else {
                32. * 0.65
            };
            let expected_x = (160. + radius).round() as usize;
            let peak = (expected_x - 2..=expected_x + 2)
                .flat_map(|x| (178..=182).map(move |y| (x, y)))
                .map(|(x, y)| brightness(x, y))
                .max()
                .unwrap();
            if matches!(effect, "ring" | "ripple") {
                assert!(peak > 35, "missing {effect} at radius {radius}: {peak}");
                assert_eq!(brightness(160, 180), 0, "ring is hollow");
            } else {
                assert_eq!(peak, 0, "no click ring for {effect}");
            }
            let area = (470..491)
                .flat_map(|x| (170..191).map(move |y| (x, y)))
                .filter(|(x, y)| brightness(*x, *y) > 100)
                .count();
            cursor_areas.push((effect, area));
        }
        assert!(
            cursor_areas[3].1 < cursor_areas[0].1,
            "bounce shrinks the cursor: {cursor_areas:?}"
        );
        std::fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn real_ffmpeg_renders_each_local_vector_shape_at_the_cursor_hotspot() {
        let ff = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("binaries/ffmpeg-aarch64-apple-darwin");
        if !ff.exists() {
            return;
        }
        let dir = std::env::temp_dir().join(format!("yusafcut-cursor-{}", uuid::Uuid::new_v4()));
        std::fs::create_dir_all(&dir).unwrap();
        for shape in ["arrow", "macos", "pointer", "dot", "ring", "crosshair"] {
            let ass = dir.join(format!("{shape}.ass"));
            let mut file = std::fs::File::create(&ass).unwrap();
            write_ass(&mut file, &config(shape), &project(), 640, 360, 30., || {
                false
            })
            .unwrap();
            let now = std::time::Instant::now();
            let out = Command::new(&ff)
                .args([
                    "-v",
                    "error",
                    "-f",
                    "lavfi",
                    "-i",
                    "color=black:s=640x360:r=30:d=1",
                    "-vf",
                    &format!("ass={}", ass.display()),
                    "-frames:v",
                    "1",
                    "-pix_fmt",
                    "rgb24",
                    "-f",
                    "rawvideo",
                    "pipe:1",
                ])
                .output()
                .unwrap();
            assert!(
                out.status.success(),
                "{}",
                String::from_utf8_lossy(&out.stderr)
            );
            assert_eq!(out.stdout.len(), 640 * 360 * 3);
            let lit: Vec<_> = out
                .stdout
                .chunks_exact(3)
                .enumerate()
                .filter(|(_, p)| p.iter().any(|v| *v > 100))
                .map(|(i, _)| (i % 640, i / 640))
                .collect();
            assert!(!lit.is_empty(), "shape {shape} is missing");
            assert!(
                lit.iter()
                    .all(|(x, y)| *x >= 300 && *x <= 350 && *y >= 160 && *y <= 220),
                "shape {shape} hotspot differs"
            );
            eprintln!(
                "cursor {shape}: {} bytes ASS; one-frame render {:?}",
                std::fs::metadata(&ass).unwrap().len(),
                now.elapsed()
            );
        }
        std::fs::remove_dir_all(dir).unwrap();
    }
}
