//! Disposable source-time waveform peaks, decoded once and reduced without PCM buffering.

use serde::{Deserialize, Serialize};

pub const PEAKS_VERSION: u32 = 1;
const BASE_PEAKS_PER_SECOND: u32 = 100;
const MAX_SECONDS: u64 = 12 * 60 * 60;
const REDUCTION: usize = 4;
const COARSE_BUCKET_LIMIT: usize = 512;

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PeakLevel {
    pub samples_per_peak: u64,
    pub peaks: Vec<f32>,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PeakPyramid {
    pub version: u32,
    pub sample_rate: u32,
    pub samples_per_peak: u64,
    pub levels: Vec<PeakLevel>,
}

fn base_bucket_size(sample_rate: u32) -> Result<u64, String> {
    if sample_rate == 0 {
        return Err("waveform sample rate must be positive".into());
    }
    Ok(u64::from((sample_rate / BASE_PEAKS_PER_SECOND).max(1)))
}

/// Streaming signed 16-bit little-endian mono PCM. One byte and one partial
/// peak bucket are retained between chunks; complete PCM samples are discarded.
pub struct PcmPeakBuilder {
    sample_rate: u32,
    samples_per_peak: u64,
    total_samples: u64,
    pending_byte: Option<u8>,
    bucket_samples: u64,
    bucket_peak: f32,
    peaks: Vec<f32>,
}

impl PcmPeakBuilder {
    pub fn new(sample_rate: u32) -> Result<Self, String> {
        Ok(Self {
            sample_rate,
            samples_per_peak: base_bucket_size(sample_rate)?,
            total_samples: 0,
            pending_byte: None,
            bucket_samples: 0,
            bucket_peak: 0.0,
            peaks: Vec::new(),
        })
    }

    /// Reject an oversized chunk before changing the builder. The caller can
    /// stop its decoder immediately; no 12-hour PCM buffer is ever allocated.
    pub fn push(&mut self, bytes: &[u8]) -> Result<(), String> {
        let limit = u64::from(self.sample_rate) * MAX_SECONDS;
        let remaining_bytes =
            (limit - self.total_samples) * 2 - u64::from(self.pending_byte.is_some());
        if bytes.len() as u64 > remaining_bytes {
            return Err("waveform input exceeds 12 hours".into());
        }
        let mut offset = 0;
        if let (Some(low), Some(&high)) = (self.pending_byte, bytes.first()) {
            self.pending_byte = None;
            self.sample(i16::from_le_bytes([low, high]));
            offset = 1;
        }
        let mut chunks = bytes[offset..].chunks_exact(2);
        for pair in &mut chunks {
            self.sample(i16::from_le_bytes([pair[0], pair[1]]));
        }
        if let Some(&byte) = chunks.remainder().first() {
            self.pending_byte = Some(byte);
        }
        Ok(())
    }

    fn sample(&mut self, sample: i16) {
        let amplitude = (f32::from(sample) / 32768.0).abs();
        self.bucket_peak = self.bucket_peak.max(amplitude);
        self.bucket_samples += 1;
        self.total_samples += 1;
        if self.bucket_samples == self.samples_per_peak {
            self.peaks.push(self.bucket_peak);
            self.bucket_samples = 0;
            self.bucket_peak = 0.0;
        }
    }

    pub fn finish(mut self) -> Result<PeakPyramid, String> {
        if self.pending_byte.is_some() {
            return Err("waveform PCM ends with an incomplete sample".into());
        }
        if self.bucket_samples > 0 {
            self.peaks.push(self.bucket_peak);
        }
        let mut levels = vec![PeakLevel {
            samples_per_peak: self.samples_per_peak,
            peaks: self.peaks,
        }];
        while levels.last().unwrap().peaks.len() > COARSE_BUCKET_LIMIT {
            let previous = levels.last().unwrap();
            levels.push(PeakLevel {
                samples_per_peak: previous.samples_per_peak * REDUCTION as u64,
                peaks: reduce(&previous.peaks),
            });
        }
        Ok(PeakPyramid {
            version: PEAKS_VERSION,
            sample_rate: self.sample_rate,
            samples_per_peak: self.samples_per_peak,
            levels,
        })
    }
}

fn reduce(peaks: &[f32]) -> Vec<f32> {
    peaks
        .chunks(REDUCTION)
        .map(|chunk| chunk.iter().copied().fold(0.0, f32::max))
        .collect()
}

impl PeakPyramid {
    /// Validate untrusted cache contents before using them. Source fingerprint /
    /// cache-key matching remains the command layer's responsibility.
    pub fn validate(&self, expected_sample_rate: u32) -> Result<(), String> {
        let base = base_bucket_size(expected_sample_rate)?;
        if self.version != PEAKS_VERSION
            || self.sample_rate != expected_sample_rate
            || self.samples_per_peak != base
            || self.levels.is_empty()
        {
            return Err("incompatible waveform cache".into());
        }
        let max_peaks = (u64::from(self.sample_rate) * MAX_SECONDS).div_ceil(base);
        if self.levels[0].peaks.len() as u64 > max_peaks {
            return Err("waveform cache exceeds 12 hours".into());
        }
        let mut bucket_size = base;
        for (i, level) in self.levels.iter().enumerate() {
            if level.samples_per_peak != bucket_size
                || level
                    .peaks
                    .iter()
                    .any(|p| !p.is_finite() || !(0.0..=1.0).contains(p))
            {
                return Err("invalid waveform cache level".into());
            }
            if i > 0 {
                let previous = &self.levels[i - 1];
                if previous.peaks.len() <= COARSE_BUCKET_LIMIT
                    || level.peaks != reduce(&previous.peaks)
                {
                    return Err("invalid waveform cache reduction".into());
                }
            }
            bucket_size = bucket_size
                .checked_mul(REDUCTION as u64)
                .ok_or("waveform cache bucket size overflow")?;
        }
        if self.levels.last().unwrap().peaks.len() > COARSE_BUCKET_LIMIT {
            return Err("waveform cache lacks coarse levels".into());
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn pcm(samples: &[i16]) -> Vec<u8> {
        samples.iter().flat_map(|s| s.to_le_bytes()).collect()
    }

    #[test]
    fn silence_and_empty_are_valid() {
        let mut builder = PcmPeakBuilder::new(8000).unwrap();
        builder.push(&vec![0; 320]).unwrap();
        let peaks = builder.finish().unwrap();
        assert_eq!(peaks.samples_per_peak, 80);
        assert_eq!(peaks.levels[0].peaks, vec![0.0, 0.0]);
        peaks.validate(8000).unwrap();
        PcmPeakBuilder::new(8000)
            .unwrap()
            .finish()
            .unwrap()
            .validate(8000)
            .unwrap();
        assert!(PcmPeakBuilder::new(0).is_err());
    }

    #[test]
    fn chunk_boundaries_and_odd_bytes_do_not_change_peaks() {
        let mut samples = vec![0; 161];
        samples[0] = i16::MIN;
        samples[90] = i16::MAX;
        samples[160] = -16384;
        let bytes = pcm(&samples);
        let mut complete = PcmPeakBuilder::new(8000).unwrap();
        complete.push(&bytes).unwrap();
        let expected = complete.finish().unwrap();
        assert_eq!(expected.levels[0].peaks, vec![1.0, 32767.0 / 32768.0, 0.5]);
        for size in [1, 3, 7, 80, 159, 1024] {
            let mut chunked = PcmPeakBuilder::new(8000).unwrap();
            for chunk in bytes.chunks(size) {
                chunked.push(chunk).unwrap();
                chunked.push(&[]).unwrap();
            }
            assert_eq!(chunked.finish().unwrap(), expected);
        }
    }

    #[test]
    fn rejects_incomplete_final_sample() {
        let mut builder = PcmPeakBuilder::new(8000).unwrap();
        builder.push(&[0]).unwrap();
        assert!(builder.finish().is_err());
    }

    #[test]
    fn reduces_four_buckets_preserving_last_partial_and_transients() {
        let mut samples = vec![0; 8000 * 30 + 1];
        *samples.last_mut().unwrap() = i16::MIN;
        let mut builder = PcmPeakBuilder::new(8000).unwrap();
        builder.push(&pcm(&samples)).unwrap();
        let pyramid = builder.finish().unwrap();
        assert_eq!(
            pyramid
                .levels
                .iter()
                .map(|l| l.peaks.len())
                .collect::<Vec<_>>(),
            vec![3001, 751, 188]
        );
        assert_eq!(
            pyramid
                .levels
                .iter()
                .map(|l| l.samples_per_peak)
                .collect::<Vec<_>>(),
            vec![80, 320, 1280]
        );
        assert!(pyramid.levels.iter().all(|l| l.peaks.last() == Some(&1.0)));
        pyramid.validate(8000).unwrap();
    }

    #[test]
    fn twelve_hour_limit_is_checked_before_consuming_chunk() {
        // Small source rate exercises the real limit without allocating hours of PCM.
        let mut builder = PcmPeakBuilder::new(1).unwrap();
        builder
            .push(&vec![0; MAX_SECONDS as usize * 2 - 1])
            .unwrap();
        assert!(builder.push(&[0, 0, 0]).is_err());
        builder.push(&[0]).unwrap();
        assert!(builder.push(&[0, 0]).is_err());
        builder.finish().unwrap().validate(1).unwrap();
    }

    #[test]
    fn cache_roundtrip_and_invalid_metadata_are_checked() {
        let mut builder = PcmPeakBuilder::new(8000).unwrap();
        builder.push(&pcm(&[i16::MAX, i16::MIN])).unwrap();
        let valid = builder.finish().unwrap();
        let json = serde_json::to_string(&valid).unwrap();
        assert!(json.contains("sampleRate"));
        assert!(json.contains("samplesPerPeak"));
        let reopened: PeakPyramid = serde_json::from_str(&json).unwrap();
        reopened.validate(8000).unwrap();
        assert!(reopened.validate(16000).is_err());
        let mut invalid = valid.clone();
        invalid.version += 1;
        assert!(invalid.validate(8000).is_err());
        invalid = valid.clone();
        invalid.levels[0].peaks[0] = f32::NAN;
        assert!(invalid.validate(8000).is_err());
        invalid = valid.clone();
        invalid.levels[0].peaks[0] = 1.1;
        assert!(invalid.validate(8000).is_err());
        invalid = valid;
        invalid.levels.clear();
        assert!(invalid.validate(8000).is_err());
    }

    #[test]
    fn cache_rejects_corrupt_or_missing_reductions() {
        let mut builder = PcmPeakBuilder::new(100).unwrap();
        builder.push(&vec![0; 1200]).unwrap();
        let valid = builder.finish().unwrap();
        valid.validate(100).unwrap();
        let mut invalid = valid.clone();
        invalid.levels[1].peaks[0] = 0.5;
        assert!(invalid.validate(100).is_err());
        invalid = valid.clone();
        invalid.levels.pop();
        assert!(invalid.validate(100).is_err());
        invalid = valid;
        invalid.levels.push(invalid.levels[1].clone());
        assert!(invalid.validate(100).is_err());
    }
}
