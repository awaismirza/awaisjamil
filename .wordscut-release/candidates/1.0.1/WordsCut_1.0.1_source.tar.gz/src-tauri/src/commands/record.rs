//! Recorder commands — device listing and the session lifecycle
//! (start / pause / resume / stop / cancel / restart / mark).
//!
//! Pure logic (arg builders, parsers) lives in `crate::recorder`; the session
//! rules (ids, phases, stale-action rejection, cancel signal) live in
//! `crate::recording_session`. This module owns the capture processes and
//! reports every change to the authority, which publishes `record:snapshot`.
//!
//! Every state-changing command takes the session id the caller believes it is
//! controlling. It is authorized against the authority both before queuing for
//! the action lock and again once the lock is held, so duplicate or stale
//! requests from several windows / the tray / shortcuts are rejected instead of
//! repeating work.

use crate::native_capture::{
    self, build_start_params, camera_composite_args, finalize_args, helper_path, is_native_index,
    plan_stop_handoff, to_avfoundation_options, HelperClient, HelperError, NativeDevices,
    NativeTracks,
};
use crate::recorder::{
    build_concat_manifest, build_ffmpeg_args, camera_path_for, composite_args, composited_path_for,
    concat_args, parse_avfoundation_devices, remux_args, PipCorner, PipSize, RecordMode,
    RecordOptions, RecordingDevices,
};
use crate::recording_session::{
    or_cancelled, AbortSignal, Action, Backend, Phase, RecordingSnapshot, SharedAuthority,
};
use crate::recording_state::{ActiveSession, CaptureProcess, CaptureStatus, NativeSession};
use crate::AppState;
use serde::Serialize;
use std::path::{Path, PathBuf};
use std::sync::Arc;
use std::time::Duration;
use tauri::{AppHandle, Emitter, Manager, State};
use tauri_plugin_shell::process::CommandEvent;
use tauri_plugin_shell::ShellExt;
use tokio::fs;
use tokio::sync::watch;
use tokio::time::{sleep, timeout};
use uuid::Uuid;

const CANCELLED: &str = "Recording cancelled";

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct RecordingResult {
    /// The session this take belonged to; the importer dedupes on it.
    pub session_id: String,
    pub path: String,
    pub duration_sec: f64,
    pub mode: String,
    /// Native recorder only: directory holding the separate, aligned tracks
    /// (screen.mp4, camera.mp4, mic.m4a, system.m4a) and events.jsonl.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub tracks_dir: Option<String>,
    /// Native recorder only: `events.jsonl` (cursor / click / key log, format in
    /// `docs/cursor-events.md`), when the take produced one.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub events_path: Option<String>,
    /// Elapsed media time of every "mark a moment" press.
    pub markers: Vec<f64>,
    /// Something degraded but the take was kept (e.g. camera could not be added).
    #[serde(skip_serializing_if = "Option::is_none")]
    pub warning: Option<String>,
    /// `RecordOptions::purpose` of the take, so any window (or a reloaded one)
    /// routes it the same way.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub purpose: Option<String>,
    /// Native screen + camera takes only: the camera was NOT composited at Stop.
    /// `path` is the screen picture (stream copy) with the audio mix, playable
    /// at once; the camera stays a separate finalized file and the editor runs
    /// `composite_recording_camera` in the background (docs/architecture.md,
    /// "Recording hand-off").
    #[serde(skip_serializing_if = "Option::is_none")]
    pub camera: Option<RecordingCamera>,
}

/// The separate camera track of a screen + camera take, and how the old Stop
/// composite placed it. Additive: older editors ignore it.
#[derive(Debug, Clone, Serialize, PartialEq)]
#[serde(rename_all = "camelCase")]
pub struct RecordingCamera {
    /// `tracks/camera.mp4`, finalized by the helper.
    pub path: String,
    /// Seconds to add to the camera file's timestamps to place it on the
    /// screen clip. Always 0 for native takes: every track is retimed to the
    /// take's shared origin and its writer session starts at media time 0.
    pub offset_sec: f64,
    pub pip_corner: PipCorner,
    pub pip_size: PipSize,
}

impl RecordingCamera {
    /// Shape the hand-off camera for `opts`; the defaults are the ones the
    /// picture-in-picture filter falls back to.
    pub fn for_take(opts: &RecordOptions, camera: &Path) -> RecordingCamera {
        RecordingCamera {
            path: camera.to_string_lossy().into_owned(),
            offset_sec: 0.0,
            pip_corner: opts.pip_corner.unwrap_or(PipCorner::BottomRight),
            pip_size: opts.pip_size.unwrap_or(PipSize::Medium),
        }
    }
}

/// "names" / "all" when this take records key identity (native screen takes only).
fn key_names_level(opts: &RecordOptions) -> Option<&'static str> {
    let screen = matches!(opts.mode, RecordMode::Screen | RecordMode::ScreenCamera);
    if !screen || backend_for(opts) != Backend::Native || !opts.record_key_identity.unwrap_or(false) {
        return None;
    }
    Some(if opts.record_all_characters.unwrap_or(false) { "all" } else { "names" })
}

fn backend_for(opts: &RecordOptions) -> Backend {
    if wants_native(opts) {
        Backend::Native
    } else {
        Backend::Ffmpeg
    }
}

// ---------------------------------------------------------------------------
// Public session API (snapshot, results, marks)
// ---------------------------------------------------------------------------

/// The current authoritative state. A window fetches this once after it has
/// subscribed to `record:snapshot` and keeps whichever has the higher revision.
#[tauri::command]
pub fn get_recording_snapshot(state: State<'_, AppState>) -> RecordingSnapshot {
    state.recording.authority.snapshot()
}

/// Takes that finished but whose import the editor has not acknowledged (covers
/// a missed `record:finished` event, e.g. a reloaded editor window).
#[tauri::command]
pub fn pending_recording_results(state: State<'_, AppState>) -> Vec<RecordingResult> {
    state.recording.finished.lock().unwrap().clone()
}

#[tauri::command]
pub fn ack_recording_result(state: State<'_, AppState>, session_id: String) {
    state
        .recording
        .finished
        .lock()
        .unwrap()
        .retain(|r| r.session_id != session_id);
}

/// Mark a moment at the take's own media time (not a window's clock).
#[tauri::command]
pub fn mark_recording(state: State<'_, AppState>, session_id: String) -> Result<f64, String> {
    state.recording.authority.add_marker(&session_id)
}

// ---------------------------------------------------------------------------
// Device enumeration
// ---------------------------------------------------------------------------

/// Ask the native helper what it can capture. A short-lived helper process.
async fn list_native_devices(path: &Path) -> Result<NativeDevices, HelperError> {
    let client = HelperClient::spawn(path).await?;
    let result = client
        .request(
            "list-devices",
            serde_json::Value::Null,
            native_capture::DEFAULT_TIMEOUT,
        )
        .await;
    client.shutdown().await;
    NativeDevices::parse(&result?)
}

async fn list_ffmpeg_devices(app: &AppHandle) -> Result<RecordingDevices, String> {
    let shell = app.shell();
    let cmd = shell
        .sidecar("ffmpeg")
        .map_err(|e| format!("ffmpeg sidecar not available: {e}"))?
        .args([
            "-hide_banner",
            "-f",
            "avfoundation",
            "-list_devices",
            "true",
            "-i",
            "",
        ]);

    // ffmpeg exits non-zero after listing devices; the listing itself is on
    // stderr, so we collect it and ignore the exit code.
    let output = cmd
        .output()
        .await
        .map_err(|e| format!("run ffmpeg device listing: {e}"))?;
    let stderr = String::from_utf8_lossy(&output.stderr);
    let mut devices = parse_avfoundation_devices(&stderr);
    if devices.video.is_empty() && devices.audio.is_empty() {
        return Err(format!(
            "no capture devices found — ffmpeg said: {}",
            stderr.trim().chars().take(400).collect::<String>()
        ));
    }
    devices.backend = "ffmpeg".into();
    Ok(devices)
}

/// Devices for the recorder dialog. The native helper answers when it can (its
/// indices start at `NATIVE_INDEX_BASE`); otherwise this is the ffmpeg listing.
#[tauri::command]
pub async fn list_recording_devices(
    app: AppHandle,
    state: State<'_, AppState>,
) -> Result<RecordingDevices, String> {
    if let Some(path) = helper_path() {
        match list_native_devices(&path).await {
            Ok(native) => {
                let devices = native.to_recording_devices();
                *state.recording.native_devices.lock().await = Some(native);
                return Ok(devices);
            }
            Err(e) => log::warn!("native device listing failed, using ffmpeg: {e}"),
        }
    }
    *state.recording.native_devices.lock().await = None;
    list_ffmpeg_devices(&app).await
}

/// A short-lived helper must not start a second capture session alongside a take.
fn require_idle(state: &State<'_, AppState>) -> Result<(), String> {
    if state.recording.authority.snapshot().phase != Phase::Idle {
        return Err("finish or cancel the current recording first".into());
    }
    Ok(())
}

/// Show the system prompt for each requested permission (where macOS allows one)
/// and return the new states. Native recorder only.
#[tauri::command]
pub async fn request_recording_permissions(
    state: State<'_, AppState>,
    kinds: Vec<String>,
) -> Result<serde_json::Value, String> {
    require_idle(&state)?;
    let kinds = native_capture::sanitize_permission_kinds(&kinds)?;
    let path = helper_path().ok_or("the native capture helper is not installed")?;
    let client = HelperClient::spawn(&path).await.map_err(|e| e.user_message())?;
    // The user may sit on a system prompt for a while.
    let result = client
        .request(
            "request-permissions",
            serde_json::json!({ "kinds": kinds }),
            native_capture::PERMISSION_TIMEOUT,
        )
        .await;
    client.shutdown().await;
    result.map_err(|e| e.user_message())
}

/// Open the System Settings pane where a denied permission is changed.
#[tauri::command]
pub fn open_privacy_settings(kind: String) -> Result<(), String> {
    let url = native_capture::privacy_settings_url(&kind).ok_or("unknown permission")?;
    std::process::Command::new("open")
        .arg(url)
        .spawn()
        .map(|_| ())
        .map_err(|e| format!("could not open System Settings: {e}"))
}

/// A `data:` URL preview of a display or window for the source picker, or an
/// error the panel shows as "preview unavailable". Native recorder only.
#[tauri::command]
pub async fn recording_thumbnail(
    state: State<'_, AppState>,
    screen_index: Option<u32>,
    window_id: Option<u32>,
    max_width: Option<u32>,
) -> Result<String, String> {
    require_idle(&state)?;
    let devices = state
        .recording
        .native_devices
        .lock()
        .await
        .clone()
        .ok_or("thumbnails need the native recorder")?;
    let params = native_capture::thumbnail_params(&devices, screen_index, window_id, max_width.unwrap_or(480))?;
    let path = helper_path().ok_or("the native capture helper is not installed")?;
    let client = HelperClient::spawn(&path).await.map_err(|e| e.user_message())?;
    let result = client.request("thumbnail", params, native_capture::DEFAULT_TIMEOUT).await;
    client.shutdown().await;
    let result = result.map_err(|e| e.user_message())?;
    let data = result.get("data").and_then(|v| v.as_str()).ok_or("the helper returned no image")?;
    let mime = result.get("mime").and_then(|v| v.as_str()).unwrap_or("image/jpeg");
    Ok(format!("data:{mime};base64,{data}"))
}

/// Read only capture-owned cursor data; raw event logs never need a broad editor
/// filesystem grant or survive as external paths in a saved project.
#[tauri::command]
pub async fn read_recording_cursor_log(app: AppHandle, path: String) -> Result<String, String> {
    let root = app
        .path()
        .app_data_dir()
        .map_err(|e| e.to_string())?
        .join("recordings");
    read_cursor_log_under(&root, Path::new(&path)).await
}
/// Delete a take the user discarded (a voice-over draft that was never kept):
/// the whole `rec-*` session folder holding it. Refuses anything that is not
/// directly inside the app's own recordings folder. The editor only calls this
/// for media no project state (including undo / redo history) references.
#[tauri::command]
pub async fn discard_recording_take(app: AppHandle, path: String) -> Result<(), String> {
    let root = app
        .path()
        .app_data_dir()
        .map_err(|e| e.to_string())?
        .join("recordings");
    let dir = owned_take_dir(&root, Path::new(&path)).await?;
    fs::remove_dir_all(dir).await.map_err(|e| e.to_string())
}
async fn owned_take_dir(root: &Path, path: &Path) -> Result<PathBuf, String> {
    let root = fs::canonicalize(root).await.map_err(|e| e.to_string())?;
    let path = fs::canonicalize(path).await.map_err(|e| e.to_string())?;
    let dir = path.parent().ok_or("not a recording")?;
    let named = dir.file_name().and_then(|n| n.to_str()).is_some_and(|n| n.starts_with("rec-"));
    if !named || dir.parent() != Some(root.as_path()) {
        return Err("only a take inside the app's recordings folder can be discarded".into());
    }
    Ok(dir.to_path_buf())
}
async fn read_cursor_log_under(root: &Path, path: &Path) -> Result<String, String> {
    let root = fs::canonicalize(root).await.map_err(|e| e.to_string())?;
    let path = fs::canonicalize(path).await.map_err(|e| e.to_string())?;
    if !path.starts_with(&root) || path.file_name().and_then(|n| n.to_str()) != Some("events.jsonl")
    {
        return Err("cursor log must belong to an app recording".into());
    }
    if fs::metadata(&path).await.map_err(|e| e.to_string())?.len() > 128 * 1024 * 1024 {
        return Err("cursor log exceeds the 128 MB limit".into());
    }
    fs::read_to_string(path).await.map_err(|e| e.to_string())
}


// ---------------------------------------------------------------------------
// Session lifecycle
// ---------------------------------------------------------------------------

/// Start one FFmpeg segment and wait for its first encoded media. `failure` lets
/// an unexpected exit mark the take interrupted; `cancel` aborts the wait at once.
async fn spawn_segment(
    app: &AppHandle,
    opts: &RecordOptions,
    path: &Path,
    failure: Option<(SharedAuthority, String)>,
    cancel: &mut AbortSignal,
) -> Result<CaptureProcess, String> {
    let args = build_ffmpeg_args(opts, path)?;
    let cmd = app
        .shell()
        .sidecar("ffmpeg")
        .map_err(|e| format!("ffmpeg sidecar not available: {e}"))?
        .args(args);
    let (mut rx, child) = cmd.spawn().map_err(|e| format!("spawn ffmpeg: {e}"))?;
    let (status_tx, status) = watch::channel(CaptureStatus::default());
    let mut process = CaptureProcess {
        child: Some(child),
        status,
    };
    let path_for_task = path.to_path_buf();
    tauri::async_runtime::spawn(async move {
        let mut stderr_tail = std::collections::VecDeque::new();
        while let Some(event) = rx.recv().await {
            match event {
                CommandEvent::Stdout(line) => {
                    let line = String::from_utf8_lossy(&line);
                    status_tx.send_modify(|s| s.observe_progress(&line));
                }
                CommandEvent::Stderr(line) => {
                    stderr_tail.push_back(String::from_utf8_lossy(&line).into_owned());
                    if stderr_tail.len() > 30 {
                        stderr_tail.pop_front();
                    }
                }
                CommandEvent::Terminated(t) => {
                    let stderr = stderr_tail.into_iter().collect::<Vec<_>>().join("\n");
                    let result = if matches!(t.code, Some(0) | Some(255)) {
                        Ok(())
                    } else {
                        Err(format!(
                            "Recording process ended unexpectedly. {}",
                            friendly_ffmpeg_error(&stderr)
                        ))
                    };
                    log::info!(
                        "capture exited {:?} for {} after {:.3}s encoded",
                        t.code,
                        path_for_task.display(),
                        status_tx.borrow().encoded_secs
                    );
                    let failure_message = result.as_ref().err().cloned();
                    status_tx.send_modify(|s| s.ended = Some(result));
                    if let (Some(error), Some((authority, id))) = (failure_message, &failure) {
                        // Ignored unless the take is Recording/Paused, so a stop,
                        // cancel or failed startup never reports twice.
                        authority.interrupt(id, error);
                    }
                    return;
                }
                CommandEvent::Error(error) => {
                    stderr_tail.push_back(error);
                }
                _ => {}
            }
        }
        status_tx
            .send_modify(|s| s.ended = Some(Err("capture event stream closed before exit".into())));
    });
    let outcome = or_cancelled(
        cancel,
        timeout(Duration::from_secs(30), process.wait_ready()),
    )
    .await;
    match outcome {
        Ok(Ok(Ok(()))) => Ok(process),
        other => {
            if let Some(child) = process.child.take() {
                let _ = child.kill();
            }
            let _ = timeout(Duration::from_secs(5), process.wait_ended()).await;
            Err(match other {
                Err(_) => CANCELLED.to_string(),
                Ok(Ok(Err(error))) => error,
                _ => "Capture did not produce media within 30 seconds. Check the selected device and permissions.".into(),
            })
        }
    }
}

/// A flushed header can stay unchanged while a process is still capturing.
/// Only the terminal event means it is safe to probe, rename or concatenate.
async fn finish_capture(process: &mut CaptureProcess) -> Result<(), String> {
    if process.status.borrow().ended.is_none() {
        process
            .child
            .as_mut()
            .ok_or("capture process is unavailable")?
            .write(b"q")
            .map_err(|e| format!("stop capture: {e}"))?;
    }
    let result = match timeout(Duration::from_secs(30), process.wait_ended()).await {
        Ok(result) => result,
        Err(_) => {
            if let Some(child) = process.child.take() {
                child
                    .kill()
                    .map_err(|e| format!("Could not stop capture: {e}. Files preserved."))?;
            }
            let _ = timeout(Duration::from_secs(5), process.wait_ended()).await;
            return Err("Capture did not finish flushing and was stopped. Recorded files were preserved for recovery.".into());
        }
    };
    // A nonzero exit may still leave playable footage. Probe it after exit rather
    // than throwing the take away or leaving an ended process impossible to stop.
    if let Err(error) = result {
        log::warn!("{error}; checking the saved media");
    }
    Ok(())
}

async fn captured_duration(app: &AppHandle, path: &Path) -> Result<f64, String> {
    let output = app
        .shell()
        .sidecar("ffprobe")
        .map_err(|e| e.to_string())?
        .args([
            "-v",
            "error",
            "-show_entries",
            "format=duration",
            "-of",
            "default=noprint_wrappers=1:nokey=1",
            &path.to_string_lossy(),
        ])
        .output()
        .await
        .map_err(|e| format!("probe recorded segment: {e}"))?;
    let duration = String::from_utf8_lossy(&output.stdout)
        .trim()
        .parse::<f64>()
        .map_err(|_| {
            "Recorded segment has no readable duration; the take has been preserved.".to_string()
        })?;
    if !output.status.success() || !duration.is_finite() || duration <= 0.0 {
        return Err("Recording produced no playable media; the take has been preserved.".into());
    }
    Ok(duration)
}

/// Distil ffmpeg's stderr into an actionable one-liner.
fn friendly_ffmpeg_error(stderr: &str) -> String {
    let lower = stderr.to_lowercase();
    if lower.contains("operation not permitted") || lower.contains("not authorized") {
        return "Check Screen Recording / Camera / Microphone permission for WordsCut in \
                System Settings → Privacy & Security."
            .into();
    }
    stderr
        .lines()
        .rev()
        .find(|l| !l.trim().is_empty())
        .unwrap_or("")
        .trim()
        .to_string()
}

/// Run the bundled ffmpeg to completion and return Ok on exit code 0.
async fn run_ffmpeg(app: &AppHandle, args: Vec<String>) -> Result<(), String> {
    let output = app
        .shell()
        .sidecar("ffmpeg")
        .map_err(|e| format!("ffmpeg sidecar not available: {e}"))?
        .args(args)
        .output()
        .await
        .map_err(|e| format!("ffmpeg: {e}"))?;
    if output.status.success() {
        Ok(())
    } else {
        Err(friendly_ffmpeg_error(&String::from_utf8_lossy(
            &output.stderr,
        )))
    }
}

async fn file_len(path: &Path) -> u64 {
    fs::metadata(path).await.map(|m| m.len()).unwrap_or(0)
}


/// Turn one recorded segment into a single playable file, or None if it holds
/// nothing. For screen + camera it composites the two tracks; if the camera
/// track is empty or the composite fails, the screen track alone is kept, so a
/// camera problem never costs the screen footage.
async fn finalize_segment(
    app: &AppHandle,
    opts: &RecordOptions,
    seg: &Path,
    warnings: &mut Vec<String>,
) -> Option<PathBuf> {
    if file_len(seg).await == 0 {
        return None;
    }
    if opts.mode != RecordMode::ScreenCamera {
        return Some(seg.to_path_buf());
    }
    let camera = camera_path_for(seg);
    if file_len(&camera).await == 0 {
        log::warn!(
            "camera track {} is empty; keeping the screen only",
            camera.display()
        );
        let _ = fs::remove_file(&camera).await;
        return Some(seg.to_path_buf());
    }
    let pip = composited_path_for(seg);
    match run_ffmpeg(app, composite_args(seg, &camera, &pip, opts)).await {
        Ok(()) if file_len(&pip).await > 0 => {
            let _ = fs::remove_file(seg).await;
            let _ = fs::remove_file(&camera).await;
            Some(pip)
        }
        other => {
            log::warn!("compositing the camera failed ({other:?}); keeping the screen only");
            let _ = fs::remove_file(&pip).await;
            let _ = fs::remove_file(&camera).await;
            warnings.push(
                "The camera could not be added to the recording, so only the screen was kept."
                    .into(),
            );
            Some(seg.to_path_buf())
        }
    }
}

/// Reject a request whose session no longer matches the live process handles.
fn same_session(id: Uuid, sid: &str) -> Result<(), String> {
    if id.to_string() == sid {
        Ok(())
    } else {
        Err("that recording has already ended (stale session)".into())
    }
}

#[tauri::command]
pub async fn start_recording(
    app: AppHandle,
    state: State<'_, AppState>,
    opts: RecordOptions,
) -> Result<RecordingSnapshot, String> {
    // Claim the session slot first: a duplicate Start is refused immediately, and
    // a Cancel can interrupt the startup below without queuing behind it.
    let ticket = state
        .recording
        .authority
        .begin(opts.mode.as_str(), backend_for(&opts))?;
    state.recording.authority.set_key_names(&ticket.id.to_string(), key_names_level(&opts));
    let _action = state.recording.actions.lock().await;
    start_locked(&app, &state, opts, ticket).await
}

/// Start capture for an already-claimed session. Caller holds the action lock.
async fn start_locked(
    app: &AppHandle,
    state: &State<'_, AppState>,
    opts: RecordOptions,
    mut ticket: crate::recording_session::StartTicket,
) -> Result<RecordingSnapshot, String> {
    let authority = state.recording.authority.clone();
    let id = ticket.id;
    let sid = id.to_string();
    match start_backend(app, state, opts, id, &mut ticket.cancel).await {
        Ok(()) => {
            if authority.activate(&sid) {
                spawn_ffmpeg_ticker(state, id);
                Ok(authority.snapshot())
            } else {
                // Cancel landed as capture came up: tear it down, do not report
                // a recording.
                discard_live(state).await;
                authority.finish(&sid, None);
                Err(CANCELLED.into())
            }
        }
        Err(error) => {
            let cancelled = ticket.cancel.is_aborted();
            authority.finish(&sid, (!cancelled).then(|| error.clone()));
            Err(if cancelled { CANCELLED.into() } else { error })
        }
    }
}

async fn start_backend(
    app: &AppHandle,
    state: &State<'_, AppState>,
    opts: RecordOptions,
    id: Uuid,
    cancel: &mut AbortSignal,
) -> Result<(), String> {
    let authority = state.recording.authority.clone();
    let sid = id.to_string();
    let mut opts = opts;
    if wants_native(&opts) {
        // The controller must exist and be on screen before the helper reads the
        // window list, so the capture filter can exclude it from the first frame.
        crate::controller::sync(app).await;
        match start_native(app, state, &opts, id, cancel).await {
            Ok(()) => return Ok(()),
            Err(HelperError::Cancelled) => return Err(CANCELLED.into()),
            // A cancelled take must never be "rescued" by the FFmpeg fallback.
            Err(e) if e.is_fallback() && !cancel.is_aborted() => {
                // Helper missing / broken: record the same take through ffmpeg.
                log::warn!("native recorder failed ({e}); falling back to ffmpeg");
                let native = state.recording.native_devices.lock().await.clone();
                let avf = list_ffmpeg_devices(app)
                    .await
                    .map_err(|_| e.user_message())?;
                opts = match native {
                    Some(n) => to_avfoundation_options(&opts, &n, &avf)
                        .map_err(|why| format!("{} ({why})", e.user_message()))?,
                    None => return Err(e.user_message()),
                };
                authority.set_backend(&sid, Backend::Ffmpeg);
                // FFmpeg cannot exclude windows: hide the controller first.
                crate::controller::sync(app).await;
                if cancel.is_aborted() {
                    return Err(CANCELLED.into());
                }
            }
            Err(e) => return Err(e.user_message()),
        }
    }

    let mut guard = state.recording.session.lock().await;
    if guard.is_some() {
        return Err("a recording is already running".into());
    }

    let mut dir = app.path().app_data_dir().map_err(|e| e.to_string())?;
    dir.push("recordings");
    dir.push(format!("rec-{}", Uuid::new_v4()));
    fs::create_dir_all(&dir).await.map_err(|e| e.to_string())?;

    let seg_path = dir.join(format!("seg-000.{}", opts.mode.extension()));
    let child = match spawn_segment(
        app,
        &opts,
        &seg_path,
        Some((authority.clone(), sid)),
        cancel,
    )
    .await
    {
        Ok(child) => child,
        Err(e) => {
            let _ = fs::remove_dir_all(&dir).await;
            return Err(e);
        }
    };

    *guard = Some(ActiveSession {
        id,
        opts,
        dir,
        segments: vec![seg_path],
        child: Some(child),
        accumulated_secs: 0.0,
    });
    Ok(())
}

/// 1 Hz elapsed-time feed for an FFmpeg take; exits when the take ends.
fn spawn_ffmpeg_ticker(state: &State<'_, AppState>, id: Uuid) {
    let session = state.recording.session.clone();
    let authority = state.recording.authority.clone();
    tauri::async_runtime::spawn(async move {
        let sid = id.to_string();
        loop {
            sleep(Duration::from_secs(1)).await;
            let guard = session.lock().await;
            match guard.as_ref() {
                Some(s) if s.id == id => {
                    authority.observe_elapsed(&sid, s.elapsed_secs());
                }
                _ => break,
            }
        }
    });
}

#[tauri::command]
pub async fn pause_recording(
    app: AppHandle,
    state: State<'_, AppState>,
    session_id: String,
) -> Result<(), String> {
    let authority = state.recording.authority.clone();
    authority.authorize(&session_id, Action::Pause)?;
    let _action = state.recording.actions.lock().await;
    authority.authorize(&session_id, Action::Pause)?;
    if let Some(native) = state.recording.native.lock().await.as_mut() {
        same_session(native.id, &session_id)?;
        return pause_native(&authority, &session_id, native).await;
    }
    let mut guard = state.recording.session.lock().await;
    let session = guard.as_mut().ok_or("no recording is running")?;
    same_session(session.id, &session_id)?;
    let process = session
        .child
        .as_mut()
        .ok_or("recording is already paused")?;
    finish_capture(process).await?;
    let path = session.segments.last().ok_or("no recording segment")?;
    session.accumulated_secs += captured_duration(&app, path).await?;
    session.child = None;
    authority.observe_elapsed(&session_id, session.elapsed_secs());
    authority.set_phase(&session_id, Phase::Paused);
    Ok(())
}

#[tauri::command]
pub async fn resume_recording(
    app: AppHandle,
    state: State<'_, AppState>,
    session_id: String,
) -> Result<(), String> {
    let authority = state.recording.authority.clone();
    authority.authorize(&session_id, Action::Resume)?;
    let _action = state.recording.actions.lock().await;
    authority.authorize(&session_id, Action::Resume)?;
    if let Some(native) = state.recording.native.lock().await.as_mut() {
        same_session(native.id, &session_id)?;
        return resume_native(&authority, &session_id, native).await;
    }
    let mut guard = state.recording.session.lock().await;
    let session = guard.as_mut().ok_or("no recording is running")?;
    same_session(session.id, &session_id)?;
    if session.child.is_some() {
        return Err("recording is not paused".into());
    }
    let seg_path = session.dir.join(format!(
        "seg-{:03}.{}",
        session.segments.len(),
        session.opts.mode.extension()
    ));
    let mut cancel = authority
        .abort_signal(&session_id)
        .ok_or("that recording has already ended (stale session)")?;
    let child = spawn_segment(
        &app,
        &session.opts,
        &seg_path,
        Some((authority.clone(), session_id.clone())),
        &mut cancel,
    )
    .await?;
    session.segments.push(seg_path);
    session.child = Some(child);
    authority.set_phase(&session_id, Phase::Recording);
    Ok(())
}

#[tauri::command]
pub async fn stop_recording(
    app: AppHandle,
    state: State<'_, AppState>,
    session_id: String,
) -> Result<RecordingResult, String> {
    let authority = state.recording.authority.clone();
    authority.authorize(&session_id, Action::Stop)?;
    let _stop_cmd = crate::perf_spans::Span::start("record.stop.command");
    let _action = state.recording.actions.lock().await;
    authority.authorize(&session_id, Action::Stop)?;
    // From here the take is Finalizing: a helper failure, a second Stop or a
    // Cancel can no longer re-enter finalization.
    if !authority.set_phase(&session_id, Phase::Finalizing) {
        return Err("the recording is already being saved".into());
    }
    let mut warnings = Vec::new();
    let native = state.recording.native.lock().await.take();
    let outcome = if let Some(native) = native {
        stop_native(&app, native, &mut warnings).await
    } else {
        let session = state.recording.session.lock().await.take();
        match session {
            Some(session) => stop_ffmpeg(&app, session, &mut warnings).await,
            None => Err("no recording is running".to_string()),
        }
    };
    match outcome {
        Ok(mut result) => {
            result.session_id = session_id.clone();
            result.markers = authority.markers(&session_id);
            result.warning = (!warnings.is_empty()).then(|| warnings.join(" "));
            state.recording.finished.lock().unwrap().push(result.clone());
            // Before the idle snapshot, so the importer knows a take is on its way.
            let _ = app.emit("record:finished", &result);
            authority.finish(&session_id, result.warning.clone());
            Ok(result)
        }
        Err(error) => {
            authority.finish(&session_id, Some(error.clone()));
            Err(error)
        }
    }
}

async fn stop_ffmpeg(
    app: &AppHandle,
    mut session: ActiveSession,
    warnings: &mut Vec<String>,
) -> Result<RecordingResult, String> {
    if let Some(process) = session.child.as_mut() {
        finish_capture(process).await?;
        // Stop has no further capture work; the final file is probed below.
        session.child = None;
    }

    // Composite each segment, dropping any that never got a frame.
    let mut usable: Vec<PathBuf> = Vec::new();
    for seg in &session.segments {
        if let Some(done) = finalize_segment(app, &session.opts, seg, warnings).await {
            usable.push(done);
        }
    }
    if usable.is_empty() {
        let _ = fs::remove_dir_all(&session.dir).await;
        return Err("recording produced no data — check capture permissions".into());
    }

    let ext = session.opts.mode.extension();
    let final_path = session.dir.join(format!(
        "{}-{}.{ext}",
        session.opts.mode.as_str(),
        Uuid::new_v4()
    ));

    if usable.len() == 1 {
        // Segments are fragmented MP4 (crash-safe); rewrite as a normal MP4 for
        // editing. Voice-over is already a plain m4a. If the remux fails, the
        // fragmented file is still playable, so keep it rather than lose the take.
        if session.opts.mode == RecordMode::Voiceover {
            fs::rename(&usable[0], &final_path)
                .await
                .map_err(|e| format!("finalize recording: {e}"))?;
        } else {
            match run_ffmpeg(app, remux_args(&usable[0], &final_path)).await {
                Ok(()) if file_len(&final_path).await > 0 => {
                    let _ = fs::remove_file(&usable[0]).await;
                }
                other => {
                    log::warn!("remux failed ({other:?}); keeping the fragmented file");
                    let _ = fs::remove_file(&final_path).await;
                    fs::rename(&usable[0], &final_path)
                        .await
                        .map_err(|e| format!("finalize recording: {e}"))?;
                }
            }
        }
    } else {
        let manifest_path = session.dir.join("concat.txt");
        fs::write(&manifest_path, build_concat_manifest(&usable))
            .await
            .map_err(|e| e.to_string())?;
        let shell = app.shell();
        let cmd = shell
            .sidecar("ffmpeg")
            .map_err(|e| format!("ffmpeg sidecar not available: {e}"))?
            .args(concat_args(&manifest_path, &final_path));
        let output = cmd
            .output()
            .await
            .map_err(|e| format!("concat segments: {e}"))?;
        if !output.status.success() {
            return Err(format!(
                "failed to join recording segments: {}",
                String::from_utf8_lossy(&output.stderr)
                    .lines()
                    .rev()
                    .find(|l| !l.trim().is_empty())
                    .unwrap_or("")
            ));
        }
        for seg in &usable {
            let _ = fs::remove_file(seg).await;
        }
        let _ = fs::remove_file(&manifest_path).await;
    }

    let duration_sec = captured_duration(app, &final_path).await?;
    Ok(RecordingResult {
        session_id: String::new(),
        path: final_path.to_string_lossy().into_owned(),
        duration_sec,
        mode: session.opts.mode.as_str().to_string(),
        tracks_dir: None,
        events_path: None,
        markers: vec![],
        warning: None,
        purpose: session.opts.purpose.clone(),
        // The FFmpeg fallback still composites per segment at Stop.
        camera: None,
    })
}

#[tauri::command]
pub async fn cancel_recording(
    state: State<'_, AppState>,
    session_id: String,
) -> Result<(), String> {
    let authority = state.recording.authority.clone();
    authority.authorize(&session_id, Action::Cancel)?;
    // Interrupt in-flight startup (native first frame, FFmpeg first sample, a
    // resume) *before* queuing for the action lock that startup is holding.
    authority.request_abort(&session_id)?;
    let _action = state.recording.actions.lock().await;
    if authority.authorize(&session_id, Action::Cancel).is_err() {
        // The aborted start (or a racing action) already ended this take.
        return Ok(());
    }
    if !authority.set_phase(&session_id, Phase::Finalizing) {
        return Ok(());
    }
    discard_live(&state).await;
    authority.finish(&session_id, None);
    Ok(())
}

/// Atomically discard the current take and begin a new one with the same
/// options. One serialized action, so a double-pressed Restart cannot start two.
#[tauri::command]
pub async fn restart_recording(
    app: AppHandle,
    state: State<'_, AppState>,
    session_id: String,
) -> Result<RecordingSnapshot, String> {
    let authority = state.recording.authority.clone();
    authority.authorize(&session_id, Action::Restart)?;
    let _action = state.recording.actions.lock().await;
    authority.authorize(&session_id, Action::Restart)?;
    let opts = {
        let native = state.recording.native.lock().await;
        match native.as_ref() {
            Some(n) => n.opts.clone(),
            None => state
                .recording
                .session
                .lock()
                .await
                .as_ref()
                .map(|s| s.opts.clone())
                .ok_or("no recording is running")?,
        }
    };
    if !authority.set_phase(&session_id, Phase::Finalizing) {
        return Err("the recording is already being saved".into());
    }
    discard_live(&state).await;
    authority.finish(&session_id, None);
    let ticket = authority.begin(opts.mode.as_str(), backend_for(&opts))?;
    authority.set_key_names(&ticket.id.to_string(), key_names_level(&opts));
    start_locked(&app, &state, opts, ticket).await
}

/// Kill whatever capture is live and delete its files.
async fn discard_live(state: &State<'_, AppState>) {
    let native = state.recording.native.lock().await.take();
    if let Some(native) = native {
        native.client.kill_now().await;
        sleep(Duration::from_millis(100)).await;
        let _ = fs::remove_dir_all(&native.dir).await;
        return;
    }
    let session = state.recording.session.lock().await.take();
    if let Some(session) = session {
        if let Some(mut process) = session.child {
            if let Some(child) = process.child.take() {
                let _ = child.kill();
            }
            if timeout(Duration::from_secs(5), process.wait_ended())
                .await
                .is_err()
            {
                log::warn!("capture has not exited after kill; deleting its files anyway");
            }
        }
        let _ = fs::remove_dir_all(&session.dir).await;
    }
}

// ---------------------------------------------------------------------------
// Native capture helper
// ---------------------------------------------------------------------------

/// Did the frontend pick devices from the native listing (or a window)?
fn wants_native(opts: &RecordOptions) -> bool {
    opts.window_id.is_some()
        || [opts.screen_index, opts.camera_index, opts.audio_index]
            .into_iter()
            .flatten()
            .any(is_native_index)
}

async fn start_native(
    app: &AppHandle,
    state: &State<'_, AppState>,
    opts: &RecordOptions,
    id: Uuid,
    cancel: &mut AbortSignal,
) -> Result<(), HelperError> {
    let mut guard = state.recording.native.lock().await;
    if guard.is_some() {
        return Err(HelperError::Rejected {
            code: "invalid-state".into(),
            message: "a recording is already running".into(),
        });
    }
    let path = helper_path()
        .ok_or_else(|| HelperError::Unavailable("capture helper not installed".into()))?;
    let client = Arc::new(
        or_cancelled(cancel, HelperClient::spawn(&path))
            .await
            .map_err(|_| HelperError::Cancelled)??,
    );

    let mut dir = match app.path().app_data_dir() {
        Ok(d) => d,
        Err(e) => {
            client.shutdown().await;
            return Err(HelperError::Unavailable(e.to_string()));
        }
    };
    dir.push("recordings");
    dir.push(format!("rec-{}", Uuid::new_v4()));
    let tracks_dir = dir.join("tracks");

    let started = or_cancelled(cancel, async {
        let devices = match state.recording.native_devices.lock().await.clone() {
            Some(d) => d,
            None => {
                let listing = client
                    .request(
                        "list-devices",
                        serde_json::Value::Null,
                        native_capture::DEFAULT_TIMEOUT,
                    )
                    .await?;
                NativeDevices::parse(&listing)?
            }
        };
        fs::create_dir_all(&tracks_dir).await.map_err(|e| {
            HelperError::Unavailable(format!("create {}: {e}", tracks_dir.display()))
        })?;
        let params = build_start_params(opts, &devices, &tracks_dir).map_err(|message| {
            HelperError::Rejected {
                code: "bad-request".into(),
                message,
            }
        })?;
        client
            .request("start", params, native_capture::START_TIMEOUT)
            .await
            .map(|_| ())
    })
    .await;

    match started {
        Err(_) => {
            // Cancelled while the helper was waiting for its first frame: kill it
            // now instead of waiting out its own startup deadline.
            client.kill_now().await;
            let _ = fs::remove_dir_all(&dir).await;
            return Err(HelperError::Cancelled);
        }
        Ok(Err(e)) => {
            client.shutdown().await;
            let _ = fs::remove_dir_all(&dir).await;
            return Err(e);
        }
        Ok(Ok(())) => {}
    }

    let events = client.take_events();
    *guard = Some(NativeSession {
        id,
        client,
        opts: opts.clone(),
        dir,
        tracks_dir,
        accumulated_secs: 0.0,
        paused: false,
        crashed: false,
        stopping: false,
    });
    drop(guard);

    if let Some(rx) = events {
        tauri::async_runtime::spawn(forward_native_events(
            state.recording.native.clone(),
            state.recording.authority.clone(),
            id,
            rx,
        ));
    }

    // The helper emits state/media-clock snapshots itself. Do not invent a
    // second wall clock here; device startup/pause must not inflate the timer.
    Ok(())
}

/// Relay the helper's unsolicited events into the authority; notice if it dies
/// mid-take. Events are scoped to this take (the slot's id), and the authority
/// ignores anything that arrives after Stop/Cancel was accepted.
async fn forward_native_events(
    slot: Arc<tokio::sync::Mutex<Option<NativeSession>>>,
    authority: SharedAuthority,
    id: Uuid,
    mut rx: tokio::sync::mpsc::UnboundedReceiver<native_capture::HelperEvent>,
) {
    let sid = id.to_string();
    while let Some(ev) = rx.recv().await {
        let mut guard = slot.lock().await;
        let Some(s) = guard.as_mut().filter(|s| s.id == id) else {
            break;
        };
        match ev.name.as_str() {
            "state" => {
                // Command acknowledgements own phase; a queued tick from before
                // a Pause/Resume only ever advances the media clock.
                s.observe_elapsed(&ev.data);
                authority.observe_elapsed(&sid, s.elapsed_secs());
                if ev.data["state"].as_str() == Some("failed") {
                    authority.interrupt_keeping_error(
                        &sid,
                        "The capture source stopped (a display, camera or microphone was lost). \
                         Stop to save what was recorded.",
                    );
                }
            }
            "error" => {
                let message = ev.data["message"]
                    .as_str()
                    .unwrap_or("the native recorder reported an error");
                authority.report_error(&sid, message);
            }
            "exited" => {
                if !s.stopping && !s.crashed {
                    s.crashed = true;
                    s.freeze();
                    log::warn!("capture helper exited mid-take: {}", s.client.stderr_tail());
                    authority.interrupt(
                        &sid,
                        "The capture helper stopped unexpectedly. Stop to save the recorded tracks.",
                    );
                }
                break;
            }
            _ => {}
        }
    }
}

async fn pause_native(
    authority: &SharedAuthority,
    sid: &str,
    s: &mut NativeSession,
) -> Result<(), String> {
    if s.crashed {
        return Err("the capture helper stopped; press Stop to save what was recorded".into());
    }
    if s.is_paused() {
        return Err("recording is already paused".into());
    }
    let result = s
        .client
        .request(
            "pause",
            serde_json::Value::Null,
            native_capture::DEFAULT_TIMEOUT,
        )
        .await
        .map_err(|e| format!("failed to pause recording: {}", e.user_message()))?;
    s.observe_elapsed(&result);
    s.freeze();
    authority.observe_elapsed(sid, s.elapsed_secs());
    authority.set_phase(sid, Phase::Paused);
    Ok(())
}

async fn resume_native(
    authority: &SharedAuthority,
    sid: &str,
    s: &mut NativeSession,
) -> Result<(), String> {
    if s.crashed {
        return Err("the capture helper stopped; press Stop to save what was recorded".into());
    }
    if !s.is_paused() {
        return Err("recording is not paused".into());
    }
    let result = s
        .client
        .request(
            "resume",
            serde_json::Value::Null,
            native_capture::DEFAULT_TIMEOUT,
        )
        .await
        .map_err(|e| format!("failed to resume recording: {}", e.user_message()))?;
    s.observe_elapsed(&result);
    s.paused = false;
    authority.observe_elapsed(sid, s.elapsed_secs());
    authority.set_phase(sid, Phase::Recording);
    Ok(())
}

async fn stop_native(
    app: &AppHandle,
    mut s: NativeSession,
    warnings: &mut Vec<String>,
) -> Result<RecordingResult, String> {
    s.stopping = true;
    s.freeze();
    let mode = s.opts.mode;
    let _stop_total = crate::perf_spans::Span::start("record.stop_native.total");

    // Ask the helper to finalize its files; if it is gone (or wedged), use
    // whatever fragmented tracks it left on disk.
    let mut duration = s.accumulated_secs;
    let mut tracks = NativeTracks::default();
    if !s.crashed && s.client.is_alive() {
        let _helper_span = crate::perf_spans::Span::start("record.stop_native.helper_stop");
        match s
            .client
            .request(
                "stop",
                serde_json::Value::Null,
                native_capture::STOP_TIMEOUT,
            )
            .await
        {
            Ok(result) => {
                if let Some(d) = result["durationSec"].as_f64() {
                    duration = d;
                }
                tracks = NativeTracks::from_files(&result["files"]).existing();
            }
            Err(e) => log::warn!("native stop failed ({e}); recovering tracks from disk"),
        }
    }
    s.client.shutdown().await;
    if tracks.is_empty() {
        tracks = NativeTracks::scan(&s.tracks_dir);
    }
    if tracks.is_empty() {
        let _ = fs::remove_dir_all(&s.dir).await;
        return Err("recording produced no data — check capture permissions".into());
    }

    let ext = mode.extension();
    let final_path = s
        .dir
        .join(format!("{}-{}.{ext}", mode.as_str(), Uuid::new_v4()));
    let tracks_dir = s.tracks_dir.to_string_lossy().into_owned();
    let mut camera: Option<RecordingCamera> = None;

    if mode == RecordMode::Voiceover {
        let src = tracks.microphone.clone().or(tracks.system_audio.clone());
        let Some(src) = src else {
            return Err("voice-over recording produced no audio".into());
        };
        fs::copy(&src, &final_path)
            .await
            .map_err(|e| format!("finalize recording: {e}"))?;
    } else {
        let mut ok = false;
        // A screen + camera take is handed back as the stream-copied screen with
        // the audio mix; the camera composite (a whole-take re-encode) runs later
        // as a background job, so Stop never waits for it.
        let handoff = plan_stop_handoff(&s.opts, &tracks);
        camera = handoff
            .deferred_camera
            .as_deref()
            .map(|c| RecordingCamera::for_take(&s.opts, c));
        if let Some(args) = finalize_args(&s.opts, &handoff.playable, &final_path) {
            let _finalize_span = crate::perf_spans::Span::start("record.stop_native.finalize_copy_mix");
            match run_ffmpeg(app, args).await {
                Ok(()) if file_len(&final_path).await > 0 => ok = true,
                other => {
                    log::warn!("combining native tracks failed ({other:?})");
                    let _ = fs::remove_file(&final_path).await;
                }
            }
        }
        if !ok {
            // Never lose the take: hand back the best single track.
            let best = tracks.screen.clone().or(tracks.camera.clone());
            let Some(best) = best else {
                return Err("could not combine the recorded tracks".into());
            };
            fs::copy(&best, &final_path)
                .await
                .map_err(|e| format!("finalize recording: {e}"))?;
            warnings.push(
                "The tracks could not be mixed, so the picture was kept without separate audio."
                    .into(),
            );
        }
    }

    let actual_duration = {
        let _probe_span = crate::perf_spans::Span::start("record.stop_native.probe");
        captured_duration(app, &final_path).await?
    };
    if (actual_duration - duration).abs() > 0.25 {
        log::warn!(
            "native media duration {actual_duration:.3}s differs from helper clock {duration:.3}s"
        );
    }
    Ok(RecordingResult {
        session_id: String::new(),
        path: final_path.to_string_lossy().into_owned(),
        duration_sec: actual_duration,
        mode: mode.as_str().to_string(),
        events_path: (tracks.screen.is_some()
            && matches!(mode, RecordMode::Screen | RecordMode::ScreenCamera)
            && s.tracks_dir.join("events.jsonl").exists())
        .then(|| format!("{tracks_dir}/events.jsonl")),
        tracks_dir: Some(tracks_dir),
        markers: vec![],
        warning: None,
        purpose: s.opts.purpose.clone(),
        camera,
    })
}

// ---------------------------------------------------------------------------
// Background camera composite (screen + camera takes)
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, serde::Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CameraCompositeRequest {
    /// `RecordingResult::tracks_dir` of the take.
    pub tracks_dir: String,
    /// The playable hand-off file the composite would replace (the media
    /// entry's path). Must be a file directly inside the same take folder; the
    /// composite is only returned when its video length, picture size and
    /// sound match this file's.
    pub screen_path: String,
    pub pip_corner: Option<PipCorner>,
    pub pip_size: Option<PipSize>,
    /// Every file path the open project references (media and overlays, in
    /// the present and in undo / redo). Leftover `camera-composite-*.mp4`
    /// files of this take that are NOT in it are deleted before the job runs
    /// (a webview reload abandons a running composite's result).
    #[serde(default)]
    pub keep: Vec<String>,
}

/// Prefix of an error that is a definite refusal (the take can never be
/// composited / swapped as it is). Every other error is transient (cancelled,
/// ffmpeg killed, ffprobe or I/O failure): the editor keeps its pending marker.
pub const COMPOSITE_REFUSED: &str = "camera composite refused: ";

fn refused(why: impl std::fmt::Display) -> String {
    format!("{COMPOSITE_REFUSED}{why}")
}

/// Running composite job per take folder, so a new request for the same take
/// (e.g. after a webview reload) cancels the one nobody is waiting for.
fn running_composites() -> &'static std::sync::Mutex<std::collections::HashMap<PathBuf, String>> {
    static RUNNING: std::sync::OnceLock<std::sync::Mutex<std::collections::HashMap<PathBuf, String>>> =
        std::sync::OnceLock::new();
    RUNNING.get_or_init(Default::default)
}

/// `camera-composite-*.mp4` files directly in `take` that are not in `keep`.
/// Never the hand-off file or a track (name pattern), never a referenced file.
async fn unreferenced_composites(take: &Path, keep: &[String]) -> Vec<PathBuf> {
    let mut kept = std::collections::HashSet::new();
    for k in keep {
        if let Ok(c) = fs::canonicalize(k).await {
            kept.insert(c);
        }
    }
    let mut out = Vec::new();
    let Ok(mut rd) = fs::read_dir(take).await else { return out };
    while let Ok(Some(e)) = rd.next_entry().await {
        let name = e.file_name().to_string_lossy().into_owned();
        if !name.starts_with(COMPOSITE_PREFIX) || !name.ends_with(".mp4") {
            continue;
        }
        let Ok(c) = fs::canonicalize(e.path()).await else { continue };
        if c.is_file() && !kept.contains(&c) {
            out.push(c);
        }
    }
    out
}

/// File-name prefix of background composites. Only files with this prefix can
/// be removed by `discard_recording_composite`; the hand-off file is named
/// `screen-camera-<uuid>.mp4` and can never match.
const COMPOSITE_PREFIX: &str = "camera-composite-";

/// `path` canonicalized, if it is a file directly inside the take folder `take`.
async fn file_in_take(take: &Path, path: &Path) -> Result<PathBuf, String> {
    let file = fs::canonicalize(path).await.map_err(|e| e.to_string())?;
    if file.parent() != Some(take) || !file.is_file() {
        return Err("only a file of this take can be used".into());
    }
    Ok(file)
}

/// A background composite inside a take folder (`rec-*/camera-composite-*.mp4`).
async fn owned_composite(root: &Path, path: &Path) -> Result<PathBuf, String> {
    let take = owned_take_dir(root, path).await?;
    let file = fs::canonicalize(path).await.map_err(|e| e.to_string())?;
    let name = file.file_name().and_then(|n| n.to_str()).unwrap_or("");
    if file.parent() != Some(take.as_path())
        || !name.starts_with(COMPOSITE_PREFIX)
        || !name.ends_with(".mp4")
    {
        return Err("only a camera composite of a take can be discarded".into());
    }
    Ok(file)
}

async fn stream_facts(app: &AppHandle, path: &Path) -> Result<native_capture::StreamFacts, String> {
    let out = app
        .shell()
        .sidecar("ffprobe")
        .map_err(|e| e.to_string())?
        .args([
            "-v",
            "error",
            "-print_format",
            "json",
            "-show_format",
            "-show_streams",
            &path.to_string_lossy(),
        ])
        .output()
        .await
        .map_err(|e| e.to_string())?;
    if !out.status.success() {
        return Err("ffprobe failed".into());
    }
    native_capture::StreamFacts::parse(&String::from_utf8_lossy(&out.stdout))
        .ok_or_else(|| "unreadable ffprobe output".into())
}

/// Remove a composite the editor did not use (it was not swapped in anywhere).
#[tauri::command]
pub async fn discard_recording_composite(app: AppHandle, path: String) -> Result<(), String> {
    let root = app.path().app_data_dir().map_err(|e| e.to_string())?.join("recordings");
    let file = owned_composite(&root, Path::new(&path)).await?;
    fs::remove_file(&file).await.map_err(|e| e.to_string())
}

/// Sent on the command's channel before the encode starts, so the editor can
/// cancel the job (project switch) while the command is still running.
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase", tag = "event")]
pub enum CameraCompositeEvent {
    #[serde(rename_all = "camelCase")]
    Started { job_id: String },
}

/// The `tracks/` folder of a take inside the app's recordings folder, or an
/// error. Paths come from the webview, so nothing outside a `rec-*/tracks`
/// folder is ever read or written next to.
async fn owned_tracks_dir(root: &Path, tracks: &Path) -> Result<PathBuf, String> {
    let root = fs::canonicalize(root).await.map_err(|e| e.to_string())?;
    let tracks = fs::canonicalize(tracks).await.map_err(|e| e.to_string())?;
    let take = tracks.parent().ok_or("not a recording")?;
    let ok = tracks.file_name().is_some_and(|n| n == "tracks")
        && take.file_name().and_then(|n| n.to_str()).is_some_and(|n| n.starts_with("rec-"))
        && take.parent() == Some(root.as_path());
    if !ok {
        return Err("only a take inside the app's recordings folder can be composited".into());
    }
    Ok(tracks)
}

/// Lower a background encode's CPU priority (best effort; VideoToolbox work is
/// scheduled by the system, this only keeps ffmpeg's own threads polite).
fn lower_priority(pid: u32) {
    // SAFETY: setpriority only reads its integer arguments.
    let rc = unsafe { libc::setpriority(libc::PRIO_PROCESS, pid as libc::id_t, 10) };
    if rc != 0 {
        log::debug!("could not lower the camera composite priority");
    }
}

/// Run ffmpeg for `job`, killing it as soon as the job is cancelled.
async fn run_ffmpeg_job(app: &AppHandle, args: Vec<String>, job: &crate::jobs::JobHandle) -> Result<(), String> {
    if job.is_cancelled() {
        return Err("cancelled".into());
    }
    let (mut rx, child) = app
        .shell()
        .sidecar("ffmpeg")
        .map_err(|e| format!("ffmpeg sidecar not available: {e}"))?
        .args(args)
        .spawn()
        .map_err(|e| format!("ffmpeg: {e}"))?;
    lower_priority(child.pid());
    let mut child = Some(child);
    let mut stderr = String::new();
    let result = loop {
        let notify = job.cancel_notify();
        let cancelled = notify.notified();
        tokio::pin!(cancelled);
        cancelled.as_mut().enable();
        if job.is_cancelled() {
            break Err("cancelled".to_string());
        }
        let event = tokio::select! {
            _ = &mut cancelled => break Err("cancelled".to_string()),
            event = rx.recv() => event,
        };
        match event {
            Some(CommandEvent::Stderr(line)) => {
                stderr.push_str(&String::from_utf8_lossy(&line));
                stderr.push('\n');
                if stderr.len() > 8192 {
                    stderr.drain(..stderr.len() - 8192);
                }
            }
            Some(CommandEvent::Terminated(status)) => {
                child.take();
                break if status.code == Some(0) { Ok(()) } else { Err(friendly_ffmpeg_error(&stderr)) };
            }
            None => break Err("ffmpeg closed without an exit status".into()),
            _ => {}
        }
    };
    if let Some(child) = child {
        let _ = child.kill();
    }
    result
}

/// Produce the picture-in-picture file the old Stop produced, as a low-priority,
/// cancellable background job, and return its path. Nothing in the project is
/// changed here: the editor decides (project / media identity, duration and
/// size checks) whether the clip's source is switched to it.
#[tauri::command]
pub async fn composite_recording_camera(
    app: AppHandle,
    state: State<'_, AppState>,
    request: CameraCompositeRequest,
    on_event: tauri::ipc::Channel<CameraCompositeEvent>,
) -> Result<String, String> {
    let root = app.path().app_data_dir().map_err(|e| e.to_string())?.join("recordings");
    if !Path::new(&request.tracks_dir).is_dir() {
        return Err(refused("the take's tracks folder is gone"));
    }
    let tracks_dir = owned_tracks_dir(&root, Path::new(&request.tracks_dir)).await.map_err(refused)?;
    let take_dir = tracks_dir.parent().ok_or("not a recording")?.to_path_buf();
    if !Path::new(&request.screen_path).exists() {
        // Possibly moved / not yet relinked: try again later.
        return Err("the clip's file is missing".into());
    }
    let screen = file_in_take(&take_dir, Path::new(&request.screen_path)).await.map_err(refused)?;
    let tracks = NativeTracks::scan(&tracks_dir);
    let name = Uuid::new_v4();
    let output = take_dir.join(format!("{COMPOSITE_PREFIX}{name}.mp4"));
    let partial = take_dir.join(format!(".{COMPOSITE_PREFIX}{name}.partial.mp4"));
    let args = camera_composite_args(&tracks, request.pip_corner, request.pip_size, &partial)
        .ok_or_else(|| refused("this take has no separate screen and camera tracks"))?;

    let job = state.jobs.create(&app, crate::jobs::JobKind::Composite, "Adding camera to recording").await;
    // A composite of the same take that nobody waits for any more (webview
    // reload) is cancelled; its result and other leftovers are swept.
    let stale = running_composites().lock().unwrap().insert(take_dir.clone(), job.id().to_string());
    if let Some(stale) = stale {
        let _ = state.jobs.cancel(&stale).await;
    }
    for orphan in unreferenced_composites(&take_dir, &request.keep).await {
        log::info!("removing an unused camera composite");
        let _ = fs::remove_file(orphan).await;
    }
    let _ = on_event.send(CameraCompositeEvent::Started { job_id: job.id().to_string() });
    // One composite at a time; a queued one can still be cancelled.
    let _queue = state.jobs.serialise(crate::jobs::JobKind::Composite).await;
    let result = async {
        if job.is_cancelled() {
            return Err("cancelled".to_string());
        }
        job.mark_running().await;
        {
            let _span = crate::perf_spans::Span::with_id("record.camera_composite", job.id());
            run_ffmpeg_job(&app, args, &job).await?;
        }
        if job.is_cancelled() {
            return Err("cancelled".into());
        }
        if file_len(&partial).await == 0 {
            return Err("the camera composite produced no data".into());
        }
        // The container length is the longest stream (the audio mix); compare
        // the pictures themselves, and refuse a change of sound.
        let (handoff, composite) = (stream_facts(&app, &screen).await?, stream_facts(&app, &partial).await?);
        native_capture::composite_lines_up(&handoff, &composite)
            .map_err(|why| refused(format!("the camera version does not line up ({why})")))?;
        if job.is_cancelled() {
            return Err("cancelled".into());
        }
        fs::rename(&partial, &output).await.map_err(|e| e.to_string())?;
        // Cancelled while renaming: nobody will use this file.
        if job.is_cancelled() {
            return Err("cancelled".into());
        }
        Ok(output.to_string_lossy().into_owned())
    }
    .await;
    if result.is_err() {
        let _ = fs::remove_file(&partial).await;
        let _ = fs::remove_file(&output).await;
    }
    {
        let mut running = running_composites().lock().unwrap();
        if running.get(&take_dir).map(String::as_str) == Some(job.id()) {
            running.remove(&take_dir);
        }
    }
    crate::commands::preview::finish_job(&job, &result).await;
    result
}

#[cfg(test)]
mod cursor_log_tests {
    use super::*;
    #[tokio::test]
    async fn cursor_reader_is_limited_to_recording_owned_event_files() {
        let dir = std::env::temp_dir().join(format!("yusafcut-cursor-read-{}", Uuid::new_v4()));
        let root = dir.join("recordings");
        let take = root.join("take");
        fs::create_dir_all(&take).await.unwrap();
        let good = take.join("events.jsonl");
        fs::write(&good, "{\"type\":\"move\"}\n").await.unwrap();
        assert!(read_cursor_log_under(&root, &good)
            .await
            .unwrap()
            .contains("move"));
        let outside = dir.join("events.jsonl");
        fs::write(&outside, "private").await.unwrap();
        assert!(read_cursor_log_under(&root, &outside).await.is_err());
        let wrong = take.join("other.txt");
        fs::write(&wrong, "private").await.unwrap();
        assert!(read_cursor_log_under(&root, &wrong).await.is_err());
        let sparse = std::fs::OpenOptions::new().write(true).open(&good).unwrap();
        sparse.set_len(128 * 1024 * 1024 + 1).unwrap();
        assert!(read_cursor_log_under(&root, &good)
            .await
            .unwrap_err()
            .contains("128 MB"));
        fs::remove_dir_all(&dir).await.unwrap();
    }

    #[test]
    fn stop_result_carries_the_deferred_camera_additively() {
        let opts = RecordOptions {
            mode: RecordMode::ScreenCamera,
            pip_corner: Some(PipCorner::TopLeft),
            pip_size: Some(PipSize::Large),
            ..Default::default()
        };
        let cam = RecordingCamera::for_take(&opts, Path::new("/r/rec-1/tracks/camera.mp4"));
        assert_eq!(cam.offset_sec, 0.0);
        let mut result = RecordingResult {
            session_id: "s".into(),
            path: "/r/rec-1/screen-camera-x.mp4".into(),
            duration_sec: 3.0,
            mode: "screen-camera".into(),
            tracks_dir: Some("/r/rec-1/tracks".into()),
            events_path: None,
            markers: vec![],
            warning: None,
            purpose: None,
            camera: Some(cam),
        };
        let v = serde_json::to_value(&result).unwrap();
        assert_eq!(
            v["camera"],
            serde_json::json!({
                "path": "/r/rec-1/tracks/camera.mp4",
                "offsetSec": 0.0,
                "pipCorner": "top-left",
                "pipSize": "large"
            })
        );
        // Defaults are the picture-in-picture filter's own defaults.
        let d = RecordingCamera::for_take(&RecordOptions { mode: RecordMode::ScreenCamera, ..Default::default() }, Path::new("/c.mp4"));
        assert_eq!((d.pip_corner, d.pip_size), (PipCorner::BottomRight, PipSize::Medium));
        // Every other take serializes exactly as before (no `camera` key).
        result.camera = None;
        assert!(serde_json::to_value(&result).unwrap().get("camera").is_none());
    }

    #[test]
    fn composite_events_and_requests_use_the_frontend_shape() {
        let started = CameraCompositeEvent::Started { job_id: "j".into() };
        assert_eq!(serde_json::to_value(&started).unwrap(), serde_json::json!({"event": "started", "jobId": "j"}));
        let req: CameraCompositeRequest = serde_json::from_value(serde_json::json!({
            "tracksDir": "/r/rec-1/tracks", "screenPath": "/r/rec-1/s.mp4", "pipCorner": "bottom-left", "pipSize": "small"
        }))
        .unwrap();
        assert_eq!((req.pip_corner, req.pip_size), (Some(PipCorner::BottomLeft), Some(PipSize::Small)));
        let bare: CameraCompositeRequest = serde_json::from_value(serde_json::json!({"tracksDir": "/t", "screenPath": "/s"})).unwrap();
        assert!(bare.pip_corner.is_none() && bare.pip_size.is_none());
    }

    #[tokio::test]
    async fn composite_reads_only_a_take_tracks_folder_inside_recordings() {
        let dir = std::env::temp_dir().join(format!("yusafcut-composite-{}", Uuid::new_v4()));
        let root = dir.join("recordings");
        let tracks = root.join("rec-1").join("tracks");
        fs::create_dir_all(&tracks).await.unwrap();
        let got = owned_tracks_dir(&root, &tracks).await.unwrap();
        assert_eq!(got, fs::canonicalize(&tracks).await.unwrap());
        // The take folder itself, another name, nested deeper, outside: refused.
        assert!(owned_tracks_dir(&root, &root.join("rec-1")).await.is_err());
        let other = root.join("rec-2").join("frames");
        fs::create_dir_all(&other).await.unwrap();
        assert!(owned_tracks_dir(&root, &other).await.is_err());
        let loose = root.join("misc").join("tracks");
        fs::create_dir_all(&loose).await.unwrap();
        assert!(owned_tracks_dir(&root, &loose).await.is_err());
        let deeper = tracks.join("tracks");
        fs::create_dir_all(&deeper).await.unwrap();
        assert!(owned_tracks_dir(&root, &deeper).await.is_err());
        let outside = dir.join("rec-3").join("tracks");
        fs::create_dir_all(&outside).await.unwrap();
        assert!(owned_tracks_dir(&root, &outside).await.is_err());
        assert!(owned_tracks_dir(&root, &root.join("rec-9").join("tracks")).await.is_err());
        // A `..` path that resolves into a take's tracks folder is fine; one that escapes is not.
        assert!(owned_tracks_dir(&root, &root.join("rec-2").join("..").join("rec-1").join("tracks")).await.is_ok());
        assert!(owned_tracks_dir(&root, &tracks.join("..").join("..").join("..").join("rec-3").join("tracks")).await.is_err());
        fs::remove_dir_all(&dir).await.unwrap();
    }

    #[tokio::test]
    async fn sweep_removes_only_unreferenced_composites_of_the_take() {
        let dir = std::env::temp_dir().join(format!("yusafcut-sweep-{}", Uuid::new_v4()));
        let take = dir.join("rec-1");
        fs::create_dir_all(take.join("tracks")).await.unwrap();
        let used = take.join("camera-composite-used.mp4");
        let orphan = take.join("camera-composite-orphan.mp4");
        let handoff = take.join("screen-camera-1.mp4");
        let partial = take.join(".camera-composite-x.partial.mp4");
        let track = take.join("tracks").join("camera-composite-in-tracks.mp4");
        for f in [&used, &orphan, &handoff, &partial, &track] {
            fs::write(f, "x").await.unwrap();
        }
        let take_c = fs::canonicalize(&take).await.unwrap();
        // `keep` may spell the path differently (`..`); it is compared canonically.
        let keep = vec![take.join("tracks").join("..").join("camera-composite-used.mp4").to_string_lossy().into_owned()];
        let got = unreferenced_composites(&take_c, &keep).await;
        assert_eq!(got, vec![fs::canonicalize(&orphan).await.unwrap()]);
        fs::remove_dir_all(&dir).await.unwrap();
    }

    #[test]
    fn refusals_are_marked_and_transient_errors_are_not() {
        assert!(refused("x").starts_with(COMPOSITE_REFUSED));
        assert_eq!(COMPOSITE_REFUSED, "camera composite refused: ");
    }

    #[tokio::test]
    async fn only_composites_and_take_files_are_accepted() {
        let dir = std::env::temp_dir().join(format!("yusafcut-composite-files-{}", Uuid::new_v4()));
        let root = dir.join("recordings");
        let take = root.join("rec-1");
        fs::create_dir_all(take.join("tracks")).await.unwrap();
        let composite = take.join("camera-composite-1.mp4");
        let handoff = take.join("screen-camera-1.mp4");
        let camera = take.join("tracks").join("camera.mp4");
        for f in [&composite, &handoff, &camera] {
            fs::write(f, "x").await.unwrap();
        }
        assert!(owned_composite(&root, &composite).await.is_ok());
        // The hand-off file, a track and anything outside are never discardable.
        assert!(owned_composite(&root, &handoff).await.is_err());
        assert!(owned_composite(&root, &camera).await.is_err());
        let outside = dir.join("rec-2");
        fs::create_dir_all(&outside).await.unwrap();
        fs::write(outside.join("camera-composite-1.mp4"), "x").await.unwrap();
        assert!(owned_composite(&root, &outside.join("camera-composite-1.mp4")).await.is_err());
        let take_c = fs::canonicalize(&take).await.unwrap();
        assert!(file_in_take(&take_c, &handoff).await.is_ok());
        assert!(file_in_take(&take_c, &camera).await.is_err());
        assert!(file_in_take(&take_c, &take).await.is_err());
        fs::remove_dir_all(&dir).await.unwrap();
    }

    #[tokio::test]
    async fn discard_is_limited_to_a_take_folder_inside_recordings() {
        let dir = std::env::temp_dir().join(format!("yusafcut-discard-{}", Uuid::new_v4()));
        let root = dir.join("recordings");
        let take = root.join("rec-1");
        fs::create_dir_all(take.join("tracks")).await.unwrap();
        let file = take.join("voiceover-1.m4a");
        fs::write(&file, "x").await.unwrap();
        let got = owned_take_dir(&root, &file).await.unwrap();
        assert_eq!(got, fs::canonicalize(&take).await.unwrap());
        // Not inside a rec-* folder, nested deeper, or outside recordings: refused.
        let loose = root.join("loose.m4a");
        fs::write(&loose, "x").await.unwrap();
        assert!(owned_take_dir(&root, &loose).await.is_err());
        let nested = take.join("tracks").join("mic.m4a");
        fs::write(&nested, "x").await.unwrap();
        assert!(owned_take_dir(&root, &nested).await.is_err());
        let outside = dir.join("rec-2");
        fs::create_dir_all(&outside).await.unwrap();
        fs::write(outside.join("a.m4a"), "x").await.unwrap();
        assert!(owned_take_dir(&root, &outside.join("a.m4a")).await.is_err());
        assert!(owned_take_dir(&root, &take.join("missing.m4a")).await.is_err());
        fs::remove_dir_all(&dir).await.unwrap();
    }
}
