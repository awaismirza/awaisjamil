//! Native media engine commands. Logic lives in `crate::engine_bridge`.

/// Whether the native engine helper is present and what this Mac supports.
/// Never fails: a missing or broken helper is `{available: false, reason}`.
#[tauri::command]
pub async fn native_engine_capabilities() -> serde_json::Value {
    crate::engine_bridge::capabilities().await
}
