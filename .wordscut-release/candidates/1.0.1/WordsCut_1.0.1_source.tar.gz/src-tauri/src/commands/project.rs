//! Project save / load / relink commands.

use crate::edl::{Project, SourceMedia};
use crate::media::parse_ffprobe_json;
use crate::media::sha256_file;
use std::path::Path;
use tauri_plugin_shell::process::CommandEvent;
use tauri_plugin_shell::ShellExt;

#[tauri::command]
pub async fn save_project(project: Project, path: String) -> Result<(), String> {
    let p = Path::new(&path);
    crate::project::save(&project, p).await.map_err(|e| e.to_string())
}

#[tauri::command]
pub async fn load_project(path: String) -> Result<Project, String> {
    let p = Path::new(&path);
    crate::project::load(p).await.map_err(|e| e.to_string())
}

/// Duration may differ by this much (seconds) between the project's record and
/// a candidate file: container rounding, not a different recording.
pub const RELINK_DURATION_TOLERANCE_SEC: f64 = 0.1;
/// Frame rates may differ by this much (fps), for 29.97 vs 30000/1001 style noise.
pub const RELINK_FPS_TOLERANCE: f64 = 0.01;

/// Does `actual` (a probed candidate) describe the same footage as `expected`
/// (what the project recorded)? Compares duration within tolerance, frame rate
/// within tolerance, and the video and audio streams: size and sample rate must
/// be equal, so a file that lost its audio or video track is refused. The
/// message names what differs, in words a user can act on.
pub fn verify_relink(expected: &SourceMedia, actual: &SourceMedia) -> Result<(), String> {
    let mut problems: Vec<String> = Vec::new();
    if (expected.duration - actual.duration).abs() > RELINK_DURATION_TOLERANCE_SEC {
        problems.push(format!(
            "length is {:.2} s but the project expects {:.2} s",
            actual.duration, expected.duration
        ));
    }
    if (expected.width, expected.height) != (actual.width, actual.height) {
        problems.push(match (expected.width > 0, actual.width > 0) {
            (true, false) => "it has no video stream".to_string(),
            (false, true) => "it has a video stream but the project media is audio only".to_string(),
            _ => format!(
                "picture is {}x{} but the project expects {}x{}",
                actual.width, actual.height, expected.width, expected.height
            ),
        });
    } else if expected.width > 0 && (expected.fps - actual.fps).abs() > RELINK_FPS_TOLERANCE {
        problems.push(format!(
            "frame rate is {:.2} fps but the project expects {:.2} fps",
            actual.fps, expected.fps
        ));
    }
    if expected.audio_sample_rate != actual.audio_sample_rate {
        problems.push(if actual.audio_sample_rate == 0 {
            "it has no audio stream".to_string()
        } else if expected.audio_sample_rate == 0 {
            "it has audio but the project media has none".to_string()
        } else {
            format!(
                "audio is {} Hz but the project expects {} Hz",
                actual.audio_sample_rate, expected.audio_sample_rate
            )
        });
    }
    if problems.is_empty() {
        Ok(())
    } else {
        Err(format!("This is not the original file: {}.", problems.join("; ")))
    }
}

/// Which of `paths` no longer exist as files. Used on project open to find media
/// the user moved, renamed or left on an unplugged drive.
#[tauri::command]
pub async fn find_missing_media(paths: Vec<String>) -> Vec<String> {
    paths.into_iter().filter(|p| !Path::new(p).is_file()).collect()
}

/// Relink: user has moved a media file. Probe the candidate, require the same
/// duration and streams as the project recorded (see `verify_relink`), then
/// confirm the SHA-256 matches so edits keep pointing at the same audio. The
/// returned media keeps the project's id, so segments stay attached.
#[tauri::command]
pub async fn relink_media(
    app: tauri::AppHandle,
    path: String,
    expected: SourceMedia,
) -> Result<SourceMedia, String> {
    let p = Path::new(&path);
    if !p.is_file() {
        return Err(format!("file not found: {}", path));
    }
    // Re-probe via ffprobe
    let shell = app.shell();
    let cmd = shell
        .sidecar("ffprobe")
        .map_err(|e| format!("ffprobe: {e}"))?
        .args([
            "-v", "error",
            "-print_format", "json",
            "-show_format",
            "-show_streams",
            &path,
        ]);
    let (mut rx, _child) = cmd.spawn().map_err(|e| format!("spawn ffprobe: {e}"))?;
    let mut stdout = String::new();
    let mut ok = false;
    while let Some(ev) = rx.recv().await {
        match ev {
            CommandEvent::Stdout(line) => {
                stdout.push_str(&String::from_utf8_lossy(&line));
                stdout.push('\n');
            }
            CommandEvent::Terminated(t) => {
                ok = t.code == Some(0);
                break;
            }
            _ => {}
        }
    }
    if !ok {
        return Err("That file could not be read as media (ffprobe failed).".into());
    }
    let probed = parse_ffprobe_json(&path, String::new(), &stdout).map_err(|e| e.to_string())?;
    let actual = sha256_file(p).await.map_err(|e| e.to_string())?;
    judge_relink(&expected, &probed, &actual)?;
    Ok(SourceMedia { id: expected.id, sha256: actual, ..probed })
}

/// The accept/refuse decision for a relink candidate. An identical checksum is
/// proof of the same bytes, so it is accepted whatever the probe says (ffprobe
/// can report slightly different numbers across versions). Otherwise the
/// metadata only decides how the refusal is worded. Hashes are never shown.
pub fn judge_relink(expected: &SourceMedia, probed: &SourceMedia, actual_sha: &str) -> Result<(), String> {
    if actual_sha == expected.sha256 {
        return Ok(());
    }
    verify_relink(expected, probed)?;
    if expected.sha256.is_empty() {
        // Old project without a recorded checksum: the structure check is all there is.
        return Ok(());
    }
    Err("This file has the same length and format but different content, so the edits would not line up. Choose the original recording.".into())
}

#[cfg(test)]
mod tests {
    use super::*;

    fn media() -> SourceMedia {
        SourceMedia {
            id: "m".into(),
            path: "/a.mp4".into(),
            duration: 60.0,
            fps: 30000.0 / 1001.0,
            width: 1920,
            height: 1080,
            audio_sample_rate: 48000,
            sha256: "abc".into(), pending_camera: None,
        }
    }

    #[test]
    fn accepts_the_same_footage_within_tolerance() {
        let mut other = media();
        other.path = "/elsewhere/b.mp4".into();
        other.duration += 0.05;
        other.fps = 29.97;
        assert!(verify_relink(&media(), &other).is_ok());
    }

    #[test]
    fn refuses_a_different_length_and_says_so() {
        let mut other = media();
        other.duration = 75.5;
        let err = verify_relink(&media(), &other).unwrap_err();
        assert!(err.contains("75.50 s") && err.contains("60.00 s"), "{err}");
    }

    #[test]
    fn refuses_a_file_missing_a_stream() {
        let mut no_audio = media();
        no_audio.audio_sample_rate = 0;
        assert!(verify_relink(&media(), &no_audio).unwrap_err().contains("no audio stream"));
        let mut no_video = media();
        no_video.width = 0;
        no_video.height = 0;
        no_video.fps = 0.0;
        assert!(verify_relink(&media(), &no_video).unwrap_err().contains("no video stream"));
    }

    #[test]
    fn refuses_other_picture_size_frame_rate_and_sample_rate() {
        let mut size = media();
        size.width = 1280;
        size.height = 720;
        assert!(verify_relink(&media(), &size).unwrap_err().contains("1280x720"));
        let mut fps = media();
        fps.fps = 25.0;
        assert!(verify_relink(&media(), &fps).unwrap_err().contains("frame rate"));
        let mut hz = media();
        hz.audio_sample_rate = 44100;
        assert!(verify_relink(&media(), &hz).unwrap_err().contains("44100 Hz"));
    }

    #[test]
    fn a_matching_checksum_is_accepted_despite_metadata_drift() {
        let mut drifted = media();
        drifted.duration = 61.0;
        drifted.fps = 24.0;
        drifted.audio_sample_rate = 44100;
        assert!(judge_relink(&media(), &drifted, "abc").is_ok());
    }

    #[test]
    fn a_different_checksum_is_refused_without_printing_hashes() {
        let same_shape = judge_relink(&media(), &media(), "deadbeefcafe").unwrap_err();
        assert!(same_shape.contains("different content"));
        assert!(!same_shape.contains("deadbeefcafe") && !same_shape.contains("abc"));
        let mut other = media();
        other.duration = 5.0;
        let err = judge_relink(&media(), &other, "deadbeefcafe").unwrap_err();
        assert!(err.contains("not the original file") && !err.contains("deadbeefcafe"));
    }

    #[test]
    fn a_project_without_a_recorded_checksum_relies_on_the_structure_check() {
        let mut legacy = media();
        legacy.sha256 = String::new();
        assert!(judge_relink(&legacy, &media(), "anything").is_ok());
        let mut other = media();
        other.duration = 5.0;
        assert!(judge_relink(&legacy, &other, "anything").is_err());
    }

    #[test]
    fn audio_only_media_is_compared_on_audio() {
        let mut a = media();
        a.width = 0;
        a.height = 0;
        a.fps = 0.0;
        let same = a.clone();
        assert!(verify_relink(&a, &same).is_ok());
    }

    #[test]
    fn lists_only_the_missing_paths() {
        let dir = std::env::temp_dir().join(format!("yusafcut-missing-{}", uuid::Uuid::new_v4()));
        std::fs::create_dir_all(&dir).unwrap();
        let here = dir.join("here.mp4");
        std::fs::write(&here, b"x").unwrap();
        let gone = dir.join("gone.mp4");
        let folder = dir.to_string_lossy().to_string();
        let got = tauri::async_runtime::block_on(find_missing_media(vec![
            here.to_string_lossy().into(),
            gone.to_string_lossy().into(),
            folder.clone(), // a folder is not media
        ]));
        std::fs::remove_dir_all(&dir).ok();
        assert_eq!(got, vec![gone.to_string_lossy().to_string(), folder]);
    }
}
