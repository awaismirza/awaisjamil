//! Disposable, source-fingerprinted waveform/proxy caches. One shared analysis
//! slot bounds decode work; each job owns and cancels only its own child.
use crate::{
    edl::SourceMedia,
    jobs::{JobHandle, JobKind},
    preview_cache::{cache_key, proxy_args, waveform_args, PreviewQuality},
    waveform::{PcmPeakBuilder, PeakPyramid},
    AppState,
};
use std::path::{Path, PathBuf};
use tauri::{Manager, State};
use tauri_plugin_shell::{process::CommandEvent, ShellExt};
pub static ANALYSIS_SLOT: tokio::sync::Semaphore = tokio::sync::Semaphore::const_new(1);

async fn fingerprint(media: &SourceMedia, variant: &str) -> Result<String, String> {
    let meta = tokio::fs::metadata(&media.path)
        .await
        .map_err(|e| e.to_string())?;
    if !meta.is_file() {
        return Err("Source is not a file".into());
    }
    let modified = meta
        .modified()
        .map_err(|e| e.to_string())?
        .duration_since(std::time::UNIX_EPOCH)
        .map_err(|e| e.to_string())?
        .as_nanos();
    Ok(cache_key(
        &media.path,
        &media.sha256,
        meta.len(),
        modified,
        variant,
    ))
}
async fn cache_path(app: &tauri::AppHandle, key: &str, ext: &str) -> Result<PathBuf, String> {
    let dir = app
        .path()
        .app_cache_dir()
        .map_err(|e| e.to_string())?
        .join("preview-v1");
    tokio::fs::create_dir_all(&dir)
        .await
        .map_err(|e| e.to_string())?;
    Ok(dir.join(format!("{key}.{ext}")))
}
pub async fn analysis_permit(
    job: &JobHandle,
) -> Result<tokio::sync::SemaphorePermit<'static>, String> {
    let notify = job.cancel_notify();
    let cancelled = notify.notified();
    tokio::pin!(cancelled);
    cancelled.as_mut().enable();
    if job.is_cancelled() {
        return Err("cancelled".into());
    }
    tokio::select! {
        _ = &mut cancelled => Err("cancelled".into()),
        permit = ANALYSIS_SLOT.acquire() => permit.map_err(|e| e.to_string()),
    }
}
pub(crate) async fn run_ffmpeg<F: FnMut(&[u8]) -> Result<(), String>>(
    app: &tauri::AppHandle,
    args: Vec<String>,
    job: &JobHandle,
    mut stdout: F,
) -> Result<(), String> {
    if job.is_cancelled() {
        return Err("cancelled".into());
    }
    let (mut rx, child) = app
        .shell()
        .sidecar("ffmpeg")
        .map_err(|e| e.to_string())?
        .args(args)
        .set_raw_out(true)
        .spawn()
        .map_err(|e| e.to_string())?;
    let mut child = Some(child);
    let mut stderr = Vec::new();
    let result = loop {
        let notify = job.cancel_notify();
        let cancelled = notify.notified();
        tokio::pin!(cancelled);
        cancelled.as_mut().enable();
        if job.is_cancelled() {
            break Err("cancelled".into());
        }
        let event = tokio::select! { _ = &mut cancelled => break Err("cancelled".into()), event = rx.recv() => event };
        match event {
            Some(CommandEvent::Stdout(bytes)) => {
                if let Err(e) = stdout(&bytes) {
                    break Err(e);
                }
            }
            Some(CommandEvent::Stderr(bytes)) => {
                stderr.extend(bytes);
                if stderr.len() > 8192 {
                    stderr.drain(..stderr.len() - 8192);
                }
            }
            Some(CommandEvent::Terminated(status)) => {
                child.take();
                break if status.code == Some(0) {
                    Ok(())
                } else {
                    Err(format!("ffmpeg: {}", String::from_utf8_lossy(&stderr)))
                };
            }
            None => break Err("ffmpeg closed without an exit status".into()),
            _ => {}
        }
    };
    if let Some(child) = child {
        let _ = child.kill();
    }
    result
}
pub(crate) async fn finish_job<T>(job: &JobHandle, result: &Result<T, String>) {
    if job.is_cancelled() {
        job.mark_cancelled().await;
    } else if let Err(e) = result {
        job.mark_failed(e.clone()).await;
    } else {
        job.mark_completed().await;
    }
}
async fn read_peaks(path: &Path) -> Option<PeakPyramid> {
    if tokio::fs::metadata(path).await.ok()?.len() > 96 * 1024 * 1024 {
        return None;
    }
    let raw = tokio::fs::read(path).await.ok()?;
    let peaks: PeakPyramid = serde_json::from_slice(&raw).ok()?;
    peaks.validate(8000).ok()?;
    Some(peaks)
}
#[tauri::command]
pub async fn generate_waveform(
    app: tauri::AppHandle,
    state: State<'_, AppState>,
    media: SourceMedia,
) -> Result<PeakPyramid, String> {
    let key = fingerprint(&media, "waveform-8000-100hz-pts-v2").await?;
    let path = cache_path(&app, &key, "json").await?;
    if let Some(peaks) = read_peaks(&path).await {
        return Ok(peaks);
    }
    let job = state
        .jobs
        .create(&app, JobKind::Waveform, "Building audio waveform")
        .await;
    let result = async {
        let _permit = analysis_permit(&job).await?;
        if job.is_cancelled() {
            return Err("cancelled".into());
        }
        let key = fingerprint(&media, "waveform-8000-100hz-pts-v2").await?;
        let path = cache_path(&app, &key, "json").await?;
        if let Some(peaks) = read_peaks(&path).await {
            return Ok(peaks);
        }
        job.mark_running().await;
        let mut builder = PcmPeakBuilder::new(8000)?;
        let args = waveform_args(&media.path);
        {
            let _span = crate::perf_spans::Span::with_id("preview.waveform.decode", job.id());
            run_ffmpeg(&app, args, &job, |bytes| builder.push(bytes)).await?;
        }
        let peaks = builder.finish()?;
        if job.is_cancelled() {
            return Err("cancelled".into());
        }
        if fingerprint(&media, "waveform-8000-100hz-pts-v2").await? != key {
            return Err("Source changed while building waveform".into());
        }
        let temp = path.with_extension(format!("{}.tmp", uuid::Uuid::new_v4()));
        let publish = async {
            tokio::fs::write(
                &temp,
                serde_json::to_vec(&peaks).map_err(|e| e.to_string())?,
            )
            .await
            .map_err(|e| e.to_string())?;
            tokio::fs::rename(&temp, &path)
                .await
                .map_err(|e| e.to_string())
        }
        .await;
        if publish.is_err() {
            let _ = tokio::fs::remove_file(&temp).await;
        }
        publish?;
        Ok(peaks)
    }
    .await;
    finish_job(&job, &result).await;
    result
}
#[tauri::command]
pub async fn generate_preview_proxy(
    app: tauri::AppHandle,
    state: State<'_, AppState>,
    media: SourceMedia,
    quality: PreviewQuality,
) -> Result<String, String> {
    let variant = format!("proxy-{quality:?}-v1");
    let job = state
        .jobs
        .create(&app, JobKind::Proxy, "Preparing preview proxy")
        .await;
    let result = async {
        let _permit = analysis_permit(&job).await?;
        if job.is_cancelled() {
            return Err("cancelled".into());
        }
        let key = fingerprint(&media, &variant).await?;
        let path = cache_path(&app, &key, "mp4").await?;
        // Published files are only successful complete encodes. A zero-size/corrupt
        // cache is reconstructed; browser decode errors can also fall back to original.
        if valid_proxy(&app, &path).await {
            return Ok(path.to_string_lossy().into_owned());
        }
        job.mark_running().await;
        let temp = path.with_file_name(format!("{}.{}.mp4", key, uuid::Uuid::new_v4()));
        let publish = async {
            let args = proxy_args(&media.path, &temp.to_string_lossy(), quality);
            {
                let _span = crate::perf_spans::Span::with_id("preview.proxy.encode", job.id());
                run_ffmpeg(&app, args, &job, |_| Ok(())).await?;
            }
            if job.is_cancelled() {
                return Err("cancelled".into());
            }
            if fingerprint(&media, &variant).await? != key {
                return Err("Source changed while preparing proxy".into());
            }
            let _validate_span = crate::perf_spans::Span::with_id("preview.proxy.validate_publish", job.id());
            if !valid_proxy(&app, &temp).await {
                return Err("Proxy validation failed".into());
            }
            tokio::fs::rename(&temp, &path)
                .await
                .map_err(|e| e.to_string())?;
            Ok(path.to_string_lossy().into_owned())
        }
        .await;
        if publish.is_err() {
            let _ = tokio::fs::remove_file(&temp).await;
        }
        publish
    }
    .await;
    finish_job(&job, &result).await;
    result
}
async fn valid_proxy(app: &tauri::AppHandle, path: &Path) -> bool {
    if !tokio::fs::metadata(path)
        .await
        .is_ok_and(|m| m.is_file() && m.len() > 0)
    {
        return false;
    }
    let Ok(cmd) = app.shell().sidecar("ffprobe") else {
        return false;
    };
    let Ok(out) = cmd
        .args([
            "-v",
            "error",
            "-select_streams",
            "v:0",
            "-show_entries",
            "stream=codec_name",
            "-of",
            "csv=p=0",
            &path.to_string_lossy(),
        ])
        .output()
        .await
    else {
        return false;
    };
    out.status.success() && String::from_utf8_lossy(&out.stdout).trim() == "h264"
}
