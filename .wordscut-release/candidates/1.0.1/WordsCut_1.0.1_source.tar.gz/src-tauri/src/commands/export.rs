//! Export command — render the EDL to a final `.mp4`.
//!
//! Two paths:
//!
//!   1. **Smart-cut** (`crate::smart_cut`) — stream-copy long interiors,
//!      re-encode only the few hundred frames either side of each cut. Used
//!      whenever the EDL is "simple" (single source, no codec / resolution /
//!      fps override, no music beds). 10-50× faster on long-form content.
//!
//!   2. **Full re-encode** — runs every frame through `h264_videotoolbox`
//!      via a filter_complex graph. Used as a fallback and whenever
//!      eligibility checks fail.
//!
//! Both paths share:
//!   * Job-queue registration so the UI shows a cancellable job entry.
//!   * `export:progress` events for the toolbar progress bar.
//!   * Chapter ffmetadata copy via `-map_metadata`.
//!   * Audio-track mixing under the main voice (full re-encode path only).

use crate::edl::{resolve_fades, AudioTrack, Chapter, ExportPreset, Project};
use crate::annotations_export::{write_ass as write_overlay_ass, Overlays, Rect};
use crate::captions_export::{filter_stage, CaptionExport};
use crate::cursor_export::{CursorConfig, write_ass};
use crate::jobs::{JobHandle, JobKind};
use crate::layers_export::{self as layers, Layers};
use crate::scene::{build_scene_filter, ResolvedBackground, SceneRender};
use crate::zoom::{build_zoom_filter, sanitize as sanitize_zoom, ZoomRegion};
use crate::smart_cut::{self, Chunk, ChunkKind};
use crate::AppState;
use serde::Deserialize;
use std::fmt::Write as _;
use std::path::PathBuf;
use tauri::{AppHandle, Emitter, State};
use tauri_plugin_shell::ShellExt;
use tauri_plugin_shell::process::CommandEvent;
use tokio::fs;

#[derive(Debug, Deserialize, Clone)]
pub struct ExportOpts {
    pub project: Project,
    #[serde(rename = "outputPath")]
    pub output_path: String,
    pub preset: ExportPreset,
    #[serde(rename = "videoBitrateKbps", default)]
    pub video_bitrate_kbps: Option<u32>,
    #[serde(rename = "audioBitrateKbps", default)]
    pub audio_bitrate_kbps: Option<u32>,
    #[serde(default)]
    pub width: Option<u32>,
    #[serde(default)]
    pub height: Option<u32>,
    #[serde(default)]
    pub fps: Option<f64>,
    #[serde(default)]
    pub codec: Option<String>,
    /// If true, skip smart-cut and force the full re-encode path. Used by
    /// the UI's "Force re-encode" advanced toggle.
    #[serde(rename = "forceReencode", default)]
    pub force_reencode: bool,
    /// The frame around the video, already resolved to pixels by the frontend.
    /// Present only when the scene is enabled; it forces the full re-encode path.
    #[serde(default)]
    pub scene: Option<SceneRender>,
    /// Zoom regions on the output timeline. Any region forces the full re-encode path.
    #[serde(rename = "zoomRegions", default)]
    pub zoom_regions: Vec<ZoomRegion>,
    /// Cursor tracks already travel once in Project.cursor; avoid duplicating logs.
    #[serde(rename = "drawCursor", default)]
    pub draw_cursor: bool,
    /// Output container + codec. Defaults to MP4 (H.264/HEVC), the original behaviour.
    #[serde(default)]
    pub format: ExportFormat,
    /// Export only this span of the output timeline (seconds). Forces the full re-encode path.
    #[serde(default)]
    pub range: Option<ExportRange>,
    /// Audio formats only: also write one file per audio source (each recorded
    /// source and each music track) beside the mix, named `<name>-voice-N` / `<name>-music-N`.
    #[serde(default)]
    pub stems: bool,
    /// Normalise the final mix to this integrated loudness (LUFS), e.g. -16 for
    /// podcasts, -14 for streaming. `None` leaves levels untouched. Forces the
    /// full re-encode path; stems are not normalised.
    #[serde(rename = "loudnessLufs", default)]
    pub loudness_lufs: Option<f64>,
    /// Burn these laid-out captions into the picture, above zoom and scene.
    #[serde(default)]
    pub captions: Option<CaptionExport>,
    /// Internal (never from the frontend): write a PNG contact sheet of the
    /// frames at these times (seconds from the range start) instead of a movie
    /// (`mask_coverage_sheet`).
    #[serde(skip)]
    pub contact_sheet: Option<Vec<f64>>,
}

/// What the export tells the caller beyond success: levels of the written file.
#[derive(Debug, serde::Serialize, Clone, PartialEq, Default)]
pub struct ExportReport {
    /// Absent for silent outputs (GIF) or when the measurement itself failed.
    pub audio: Option<AudioReport>,
}

/// Loudness and peaks of the exported mix (ffmpeg `ebur128` + `astats`).
#[derive(Debug, serde::Serialize, Clone, PartialEq)]
pub struct AudioReport {
    /// Each value is absent (null) when ffmpeg reports it as infinite, as it
    /// does for digital silence; JSON has no infinity.
    #[serde(rename = "integratedLufs")]
    pub integrated_lufs: Option<f64>,
    #[serde(rename = "loudnessRangeLu")]
    pub loudness_range_lu: Option<f64>,
    #[serde(rename = "truePeakDbtp")]
    pub true_peak_dbtp: Option<f64>,
    #[serde(rename = "samplePeakDb")]
    pub sample_peak_db: Option<f64>,
    /// Sample peak at or above full scale (-0.1 dB): the mix is clipping or about to.
    pub clipped: bool,
}

/// Loudness targets outside this are almost certainly typos.
const LOUDNESS_RANGE: std::ops::RangeInclusive<f64> = -30.0..=-5.0;

/// Output formats. `ProRes4444` is the only one that keeps a transparent scene
/// background. HEVC-with-alpha is deliberately absent: the bundled ffmpeg 7.1.1
/// `hevc_videotoolbox` accepts `-alpha_quality` but writes no alpha layer (verified).
#[derive(Debug, Deserialize, Clone, Copy, PartialEq, Eq, Default)]
pub enum ExportFormat {
    #[default]
    #[serde(rename = "mp4")]
    Mp4,
    /// H.264 / HEVC in a QuickTime container.
    #[serde(rename = "mov")]
    Mov,
    #[serde(rename = "prores-422")]
    ProRes422,
    #[serde(rename = "prores-422-hq")]
    ProRes422Hq,
    /// ProRes 4444 with an alpha channel (`yuva444p10le`).
    #[serde(rename = "prores-4444")]
    ProRes4444,
    #[serde(rename = "gif")]
    Gif,
    /// AAC in an MPEG-4 audio file.
    #[serde(rename = "m4a")]
    M4a,
    /// 16-bit PCM.
    #[serde(rename = "wav")]
    Wav,
}

impl ExportFormat {
    fn extension(self) -> &'static str {
        match self {
            Self::Mp4 => "mp4",
            Self::Mov | Self::ProRes422 | Self::ProRes422Hq | Self::ProRes4444 => "mov",
            Self::Gif => "gif",
            Self::M4a => "m4a",
            Self::Wav => "wav",
        }
    }
    fn is_audio(self) -> bool {
        matches!(self, Self::M4a | Self::Wav)
    }
    /// Can the container + codec carry transparency? Others flatten it to black.
    fn has_alpha(self) -> bool {
        matches!(self, Self::ProRes4444)
    }
    /// Smart-cut stream-copies H.264/HEVC + AAC; only MP4 and MOV can hold that as-is.
    fn allows_stream_copy(self) -> bool {
        matches!(self, Self::Mp4 | Self::Mov)
    }
}

#[derive(Debug, Deserialize, Clone, Copy, PartialEq)]
pub struct ExportRange {
    pub start: f64,
    pub end: f64,
}

/// The format actually written. The legacy podcast preset with the default
/// format means "audio only", which is M4A (its codec settings are identical).
fn format_of(opts: &ExportOpts) -> ExportFormat {
    if matches!(opts.preset, ExportPreset::PodcastAudio) && opts.format == ExportFormat::Mp4 {
        ExportFormat::M4a
    } else {
        opts.format
    }
}

fn audio_only(opts: &ExportOpts) -> bool {
    format_of(opts).is_audio()
}

/// Reject requests the encoder would get wrong rather than silently writing
/// the wrong container: extension/format mismatch, stems on video, bad ranges.
fn validate(opts: &ExportOpts, total_duration: f64) -> Result<(), String> {
    let format = format_of(opts);
    let ext = std::path::Path::new(&opts.output_path)
        .extension()
        .and_then(|e| e.to_str())
        .unwrap_or("")
        .to_ascii_lowercase();
    if ext != format.extension() {
        return Err(format!("output must end in .{} for this format", format.extension()));
    }
    if let Some(l) = opts.loudness_lufs {
        if !LOUDNESS_RANGE.contains(&l) {
            return Err(format!("loudness target must be between -30 and -5 LUFS (got {l})"));
        }
    }
    if opts.stems && !format.is_audio() {
        return Err("stems need an audio format (m4a or wav)".into());
    }
    if let Some(r) = opts.range {
        if !(r.start.is_finite() && r.end.is_finite() && r.start >= 0.0 && r.end > r.start) {
            return Err("export range must have 0 <= start < end".into());
        }
        if r.start >= total_duration {
            return Err("export range starts after the end of the timeline".into());
        }
    }
    let length = range_span(opts, total_duration).map_or(total_duration, |(_, d)| d);
    if format == ExportFormat::Gif && length > GIF_MAX_SECONDS + 1e-6 {
        return Err(format!(
            "GIF export is limited to {GIF_MAX_SECONDS:.0} s; set a range ({length:.1} s requested)"
        ));
    }
    Ok(())
}

/// Every stem file this export would write (empty unless stems are on).
fn stem_outputs(opts: &ExportOpts) -> Vec<String> {
    if !opts.stems || !audio_only(opts) {
        return Vec::new();
    }
    // One voice stem per distinct source file, matching build_reencode_argv's inputs.
    let mut sources: Vec<&str> = Vec::new();
    for seg in &opts.project.segments {
        if let Some(m) = opts.project.media.get(&seg.media_id) {
            if !sources.contains(&m.path.as_str()) {
                sources.push(&m.path);
            }
        }
    }
    stem_paths(&opts.output_path, sources.len(), &narration_flags(&opts.project))
}

/// Checks that need the file system, run before anything is written. Stems
/// are never overwritten: the save dialog only asked about the main file.
fn preflight(opts: &ExportOpts) -> Result<(), String> {
    if opts.project.segments.is_empty() {
        return Err("nothing to export — EDL is empty".into());
    }
    let total: f64 = opts.project.output_duration();
    validate(opts, total.max(0.001))?;
    overlay_files_exist(opts)?;
    for stem in stem_outputs(opts) {
        let p = std::path::Path::new(&stem);
        if stem == opts.output_path || opts.project.media.values().any(|m| std::path::Path::new(&m.path) == p) {
            return Err(format!("stem {stem} would overwrite an input or the main export"));
        }
        if p.exists() {
            return Err(format!("stem {stem} already exists; move it or pick another name"));
        }
    }
    Ok(())
}

/// Overlays are read from where they are on disk; a moved file is relinked in the Overlays panel.
fn overlay_files_exist(opts: &ExportOpts) -> Result<(), String> {
    for o in &layers_for(opts).overlays {
        if !std::path::Path::new(&o.path).is_file() {
            let name = std::path::Path::new(&o.path).file_name().map_or(o.path.clone(), |n| n.to_string_lossy().into_owned());
            return Err(format!("overlay file is missing: {name}. Relink it in the Overlays panel or remove the overlay."));
        }
    }
    Ok(())
}

/// Remove what a failed or cancelled export wrote: the main file and stems,
/// but only files modified since the export started (never an untouched file).
fn remove_partial_outputs(opts: &ExportOpts, started: std::time::SystemTime) {
    for path in std::iter::once(opts.output_path.clone()).chain(stem_outputs(opts)) {
        let fresh = std::fs::metadata(&path).and_then(|m| m.modified()).is_ok_and(|t| t >= started);
        if fresh {
            let _ = std::fs::remove_file(&path);
        }
    }
}

/// Chapters for a range: shifted to start at 0, the one in progress at the
/// range start moved to 0, and those after the range dropped.
fn chapters_in_range(chapters: &[Chapter], start: f64, end: f64) -> Vec<Chapter> {
    let mut sorted: Vec<&Chapter> = chapters.iter().collect();
    sorted.sort_by(|a, b| a.output_time.partial_cmp(&b.output_time).unwrap_or(std::cmp::Ordering::Equal));
    let first_inside = sorted.iter().position(|c| c.output_time > start).unwrap_or(sorted.len());
    sorted[first_inside.saturating_sub(1)..]
        .iter()
        .filter(|c| c.output_time < end)
        .map(|c| Chapter { output_time: (c.output_time - start).max(0.0), ..(*c).clone() })
        .collect()
}

/// The range clamped to the timeline, as (start, duration).
fn range_span(opts: &ExportOpts, total_duration: f64) -> Option<(f64, f64)> {
    opts.range.map(|r| (r.start, r.end.min(total_duration) - r.start))
}

/// GIF output caps: frame rate and width. Big GIFs are unusable, so default
/// small and never exceed the cap even when the user asks for more.
const GIF_DEFAULT_FPS: f64 = 15.0;
const GIF_MAX_FPS: f64 = 30.0;
const GIF_DEFAULT_WIDTH: u32 = 640;
const GIF_MAX_WIDTH: u32 = 960;
/// Longest GIF we will write; longer edits need a range.
const GIF_MAX_SECONDS: f64 = 60.0;

fn gif_fps(opts: &ExportOpts) -> f64 {
    opts.fps.filter(|f| f.is_finite() && *f > 0.0).unwrap_or(GIF_DEFAULT_FPS).min(GIF_MAX_FPS)
}

fn gif_width(opts: &ExportOpts) -> u32 {
    let picture = scene_for(opts)
        .map(|s| s.canvas_w)
        .or(opts.width)
        .or_else(|| opts.project.segments.first().and_then(|s| opts.project.media.get(&s.media_id)).map(|m| m.width))
        .unwrap_or(GIF_DEFAULT_WIDTH);
    let cap = if opts.width.is_some() { GIF_MAX_WIDTH } else { GIF_DEFAULT_WIDTH };
    (picture.min(cap) / 2 * 2).max(2)
}

/// Stem files beside `output`: `<name>-voice-N.<ext>` for each source, then one
/// per heard track in mix order: `<name>-music-N` for beds, `<name>-narration-N`
/// for voice-over takes (`narration[i]` says which).
fn stem_paths(output: &str, voices: usize, narration: &[bool]) -> Vec<String> {
    let p = std::path::Path::new(output);
    let stem = p.file_stem().and_then(|s| s.to_str()).unwrap_or("export");
    let ext = p.extension().and_then(|s| s.to_str()).unwrap_or("wav");
    let dir = p.parent().unwrap_or(std::path::Path::new(""));
    let named = |kind: &str, n: usize| dir.join(format!("{stem}-{kind}-{n}.{ext}")).to_string_lossy().into_owned();
    let (mut music, mut takes) = (0, 0);
    let tracks = narration.iter().map(|&vo| {
        if vo {
            takes += 1;
            named("narration", takes)
        } else {
            music += 1;
            named("music", music)
        }
    });
    (1..=voices).map(|n| named("voice", n)).chain(tracks).collect()
}

/// Which heard tracks are voice-over takes, in mix order (for stem names).
fn narration_flags(project: &Project) -> Vec<bool> {
    project.audible_tracks().iter().map(|t| t.is_voice_over()).collect()
}

#[tauri::command]
pub async fn export_video(
    app: AppHandle,
    state: State<'_, AppState>,
    opts: ExportOpts,
) -> Result<ExportReport, String> {
    // Create the job *before* acquiring the serialisation lock so a queued
    // second export shows up in the Jobs flyout immediately as "Queued"
    // rather than vanishing into a blocked await.
    let title = export_job_title(&opts);
    let job = state.jobs.create(&app, JobKind::Export, title).await;

    // Serialize: only one export at a time. The lock is per-kind so the
    // second export waits here until the first finishes.
    let _serial = state.jobs.serialise(JobKind::Export).await;
    state.export.begin(job.id()).await;
    if job.is_cancelled() { state.export.finish().await; job.mark_cancelled().await; return Err("cancelled".into()); }
    job.mark_running().await;

    let started = std::time::SystemTime::now();
    let result = match preflight(&opts) {
        Err(e) => Err(e),
        Ok(()) => {
            let r = run_export(&app, &state, &opts, &job).await;
            if r.is_err() {
                remove_partial_outputs(&opts, started);
            }
            r
        }
    };

    state.export.finish().await;
    match &result {
        Ok(()) => job.mark_completed().await,
        Err(e) => {
            // If the user pressed cancel, we get an ffmpeg non-zero exit. Tag
            // that as cancelled rather than failed so the Jobs flyout reads
            // cleanly.
            if job.is_cancelled() {
                job.mark_cancelled().await;
            } else {
                job.mark_failed(e.clone()).await;
            }
        }
    }

    // The export is finished: the job is completed and the serial lock freed
    // before the (best-effort) measurement, so it never delays a queued export
    // or turns a good export into an error.
    drop(_serial);
    result?;
    let mut report = ExportReport::default();
    if audio_in_output(&opts) {
        let _ = app.emit("export:measuring", ());
        report.audio = tokio::time::timeout(MEASURE_TIMEOUT, measure_audio(&app, &opts.output_path))
            .await
            .ok()
            .flatten();
    }
    Ok(report)
}

/// Longest the post-export measurement may take before it is dropped.
const MEASURE_TIMEOUT: std::time::Duration = std::time::Duration::from_secs(60);

/// GIF has no audio; every other format carries the mix.
fn audio_in_output(opts: &ExportOpts) -> bool {
    format_of(opts) != ExportFormat::Gif
}

/// ffmpeg arguments that print the loudness summary and sample peak of `path`.
fn measure_args(path: &str) -> Vec<String> {
    let filter = "astats=measure_perchannel=none:measure_overall=Peak_level,ebur128=peak=true:framelog=quiet";
    ["-hide_banner", "-nostats", "-i", path, "-vn", "-af", filter, "-f", "null", "-"]
        .map(String::from)
        .to_vec()
}

/// Read the numbers out of `measure_args` output (ffmpeg's stderr).
fn parse_audio_report(stderr: &str) -> Option<AudioReport> {
    // Text after the LAST occurrence of `key`: the input banner above the
    // results can contain anything (a file name with "Summary:" in it).
    let after = |text: &str, key: &str| -> Option<String> { text.rsplit(key).next().filter(|_| text.contains(key)).map(String::from) };
    // `Ok(None)` for a value ffmpeg printed as -inf / nan; `Err` when it is missing.
    let num = |text: &str, key: &str| -> Result<Option<f64>, ()> {
        let word = after(text, key).ok_or(())?;
        let v: f64 = word.split_whitespace().next().ok_or(())?.parse().map_err(|_| ())?;
        Ok(v.is_finite().then_some(v))
    };
    let summary = after(stderr, "Summary:")?;
    let integrated = num(&summary, "I:").ok()?;
    let lra = num(&summary, "LRA:").ok()?;
    let tp = num(&after(&summary, "True peak:")?, "Peak:").ok()?;
    let sample_peak = num(stderr, "Peak level dB:").ok()?;
    Some(AudioReport {
        integrated_lufs: integrated,
        loudness_range_lu: lra,
        true_peak_dbtp: tp,
        sample_peak_db: sample_peak,
        clipped: sample_peak.is_some_and(|p| p >= -0.1),
    })
}

/// Measure the written file. A failed measurement is not an export failure.
async fn measure_audio(app: &AppHandle, path: &str) -> Option<AudioReport> {
    let out = app.shell().sidecar("ffmpeg").ok()?.args(measure_args(path)).output().await.ok()?;
    parse_audio_report(&String::from_utf8_lossy(&out.stderr))
}

fn export_job_title(opts: &ExportOpts) -> String {
    let name = std::path::Path::new(&opts.output_path)
        .file_name()
        .and_then(|s| s.to_str())
        .unwrap_or("export.mp4");
    format!("Exporting → {name}")
}

/// Source-time bounds ffmpeg should cut for a segment.
///
/// Exactly the EDL bounds: cut-point padding (`paddingMs`) is already baked
/// into `source_in`/`source_out` when the edit is made (`deleteWords` in
/// `src/lib/edl.ts`). Padding again here would make every exported clip longer
/// than the timeline, so captions, chapters and music would drift later with
/// each segment.
fn segment_clip_bounds(seg: &crate::edl::Segment) -> (f64, f64) {
    (seg.source_in.max(0.0), seg.source_out)
}

/// The zoom regions to render, validated. Audio-only exports have no picture to zoom.
fn zoom_for(opts: &ExportOpts) -> Vec<ZoomRegion> {
    if audio_only(opts) {
        return Vec::new();
    }
    sanitize_zoom(&opts.zoom_regions)
}

/// The scene to draw, if any. Audio-only exports have no picture to frame.
fn scene_for(opts: &ExportOpts) -> Option<&SceneRender> {
    if audio_only(opts) {
        return None;
    }
    opts.scene.as_ref()
}

fn cursor_for(opts: &ExportOpts) -> Option<&serde_json::Value> {
    if audio_only(opts) || !opts.draw_cursor { return None; }
    opts.project.cursor.as_ref().filter(|cursor| {
        cursor["style"]["show"].as_bool() != Some(false) && opts.project.segments.iter().any(|seg| {
            cursor["tracks"][&seg.media_id]["events"].as_array().is_some_and(|events|events.iter().any(|e|
                matches!(e["type"].as_str(),Some("move"|"down"|"up")) && e["x"].is_number() && e["y"].is_number()))
        })
    })
}

/// Captions to burn in, when there is anything to draw. Audio has no picture.
fn captions_for(opts: &ExportOpts) -> Option<&CaptionExport> {
    if audio_only(opts) { return None; }
    opts.captions.as_ref().filter(|c| c.active())
}

/// Size of the finished frame (after zoom and scene): what captions are drawn on.
fn final_size(opts: &ExportOpts) -> Result<(u32, u32), String> {
    match scene_for(opts) {
        Some(s) => Ok((s.canvas_w, s.canvas_h)),
        None => picture_size(opts),
    }
}

/// The constant rate between the two mask passes: the source's own rate,
/// rounded and kept in 24..60 (VFR screen recordings report odd rates).
fn mask_rate(source_fps: f64) -> f64 {
    source_fps.round().clamp(24., 60.)
}

/// Static screen tracks can have a very low average frame rate. Cursor/zoom
/// animation still needs presented frames; retain explicit export rates and
/// higher source rates while supplying at least 30 Hz for original VFR media.
fn animation_fps(opts: &ExportOpts) -> f64 {
    opts.fps.filter(|fps|fps.is_finite() && *fps>=1.).unwrap_or_else(|| {
        opts.project.segments.first().and_then(|s|opts.project.media.get(&s.media_id))
            .map(|m|m.fps).filter(|fps|fps.is_finite()).unwrap_or(30.).max(30.)
    }).clamp(1.,240.)
}

fn picture_size(opts: &ExportOpts) -> Result<(u32,u32), String> {
    match (opts.width,opts.height,scene_for(opts)) {
        (Some(w),Some(h),None) => Ok((w,h)),
        _ => opts.project.segments.first().and_then(|s| opts.project.media.get(&s.media_id))
            .map(|m|(m.width,m.height)).ok_or_else(|| "picture needs a source size".into()),
    }
}

/// Private, disposable activity data. Drop also covers generation, spawn and
/// decoder errors/cancellation; never leave cursor logs beside the exported movie.
struct CursorArtifact(PathBuf);
impl Drop for CursorArtifact {
    fn drop(&mut self) { let _=std::fs::remove_file(&self.0); }
}
async fn prepare_cursor(opts: &ExportOpts, job: &JobHandle) -> Result<Option<CursorArtifact>, String> {
    if cursor_for(opts).is_none() {return Ok(None)}
    let (w,h)=picture_size(opts)?;
    let fps=animation_fps(opts).min(60.);
    let mut project=opts.project.clone();let job=job.clone();
    tokio::task::spawn_blocking(move || {
        use std::io::Write;
        use std::os::unix::fs::OpenOptionsExt;
        let cursor: CursorConfig = serde_json::from_value(project.cursor.take().ok_or("cursor settings missing")?).map_err(|e|format!("invalid cursor settings: {e}"))?;
        let file=CursorArtifact(std::env::temp_dir().join(format!("yusafcut-cursor-{}.ass",uuid::Uuid::new_v4())));
        let handle=std::fs::OpenOptions::new().write(true).create_new(true).mode(0o600).open(&file.0).map_err(|e|e.to_string())?;
        let mut writer=std::io::BufWriter::new(handle);
        write_ass(&mut writer,&cursor,&project,w,h,fps,||job.is_cancelled())?;
        writer.flush().map_err(|e|e.to_string())?;
        Ok(Some(file))
    }).await.map_err(|e|e.to_string())?
}

/// Private temp ASS for the captions; removed on drop like the cursor one.
async fn prepare_captions(opts: &ExportOpts) -> Result<Option<CursorArtifact>, String> {
    let Some(captions) = captions_for(opts) else { return Ok(None) };
    let (w, h) = final_size(opts)?;
    let captions = captions.clone();
    tokio::task::spawn_blocking(move || {
        use std::io::Write;
        use std::os::unix::fs::OpenOptionsExt;
        let file = CursorArtifact(std::env::temp_dir().join(format!("yusafcut-captions-{}.ass", uuid::Uuid::new_v4())));
        let handle = std::fs::OpenOptions::new().write(true).create_new(true).mode(0o600).open(&file.0).map_err(|e| e.to_string())?;
        let mut writer = std::io::BufWriter::new(handle);
        crate::captions_export::write_ass(&mut writer, &captions, w, h)?;
        writer.flush().map_err(|e| e.to_string())?;
        Ok(Some(file))
    }).await.map_err(|e| e.to_string())?
}

/// Annotations and keystroke captions to draw. Audio-only exports have no picture.
fn overlays_for(opts: &ExportOpts) -> Overlays {
    if audio_only(opts) { Overlays::default() } else { Overlays::collect(&opts.project) }
}

/// Media overlays and privacy masks. Audio-only exports keep only the video
/// overlays whose own audio is mixed in; they have no picture to mask.
fn layers_for(opts: &ExportOpts) -> Layers {
    let mut l = Layers::collect(&opts.project);
    if audio_only(opts) {
        l.masks.clear();
        l.overlays.retain(|o| o.include_audio);
    }
    l
}

// LAYER ORDER POLICY (keep every stage consistent with it; see docs/architecture.md):
//   picture layer: privacy masks -> cursor -> follow-zoom media overlays ->
//                  follow-zoom annotations -> zoom -> scene (incl. crop and the
//                  device frame shapes) -> device frame text (`scenetv`)
//   frame layer:   fixed media overlays -> fixed annotations -> captions -> keystroke caps
//   then:          range trim -> GIF palette / contact sheet -> encoder
// Masks are first so nothing after them (and no side output) sees unmasked
// pixels; a mask forces the constant-rate `animatedv` stage so a variable-rate
// frame can never carry unmasked content into the masked span.
// Key caps move up (`key_cap_y(true)`) when captions sit at the bottom. Every
// frame-layer `ass` stage gets `alpha=1` exactly when the scene keeps alpha
// (ProRes 4444 + transparent). Any overlay or caption disables smart-cut.

/// The ASS scripts for overlays: `follow` is drawn on the picture before zoom
/// (it zooms with it); `fixed` and `keys` on the finished frame after the scene.
#[derive(Default)]
struct OverlayFiles { follow: Option<CursorArtifact>, fixed: Option<CursorArtifact>, keys: Option<CursorArtifact>, frame_text: Option<CursorArtifact> }
impl OverlayFiles {
    /// These files as graph inputs; `cursor` and `captions` are prepared separately.
    fn paths(&self) -> OverlayPaths<'_> {
        OverlayPaths {
            follow: self.follow.as_ref().map(|f| f.0.as_path()),
            fixed: self.fixed.as_ref().map(|f| f.0.as_path()),
            keys: self.keys.as_ref().map(|f| f.0.as_path()),
            frame_text: self.frame_text.as_ref().map(|f| f.0.as_path()),
            ..OverlayPaths::default()
        }
    }
}

/// Every prepared ASS file the full re-encode graph draws (see the layer order
/// policy above). The one options struct of `build_reencode_argv_opts`; all
/// `None` is the plain export. Frame-layer stages get `alpha=1` exactly when the
/// scene keeps alpha (ProRes 4444 + transparent), derived in the builder.
#[derive(Default, Clone, Copy)]
struct OverlayPaths<'a> {
    /// Picture layer, first: the cursor (`prepare_cursor`).
    cursor: Option<&'a std::path::Path>,
    /// Picture layer: annotations that zoom with the picture.
    follow: Option<&'a std::path::Path>,
    /// Frame layer, first: annotations fixed on the frame.
    fixed: Option<&'a std::path::Path>,
    /// Frame layer: burned-in captions (`prepare_captions`).
    captions: Option<&'a std::path::Path>,
    /// Frame layer, last: keystroke caps.
    keys: Option<&'a std::path::Path>,
    /// Picture layer, right after the scene: the device frame's text (browser address).
    frame_text: Option<&'a std::path::Path>,
}

/// Small (one line per item), so written synchronously; removed on drop like the cursor file.
fn prepare_overlays(opts: &ExportOpts) -> Result<OverlayFiles, String> {
    let frame_text = prepare_frame_text(opts)?;
    let o = overlays_for(opts);
    if o.is_empty() { return Ok(OverlayFiles { frame_text, ..OverlayFiles::default() }); }
    let media = opts.project.segments.first().and_then(|s| opts.project.media.get(&s.media_id))
        .ok_or("annotations need a source with a size")?;
    // Key caps move above captions that sit at the bottom of the frame.
    let captions_at_bottom = captions_for(opts).is_some_and(|c| c.style.sanitized().position == "bottom");
    let key_y = crate::annotations_export::key_cap_y(captions_at_bottom);
    let write = |items: &[crate::annotations_export::Annotation], keys: &[crate::annotations_export::KeyCaption], w: u32, h: u32, rect: Rect| -> Result<Option<CursorArtifact>, String> {
        if items.is_empty() && keys.is_empty() { return Ok(None); }
        use std::os::unix::fs::OpenOptionsExt;
        let file = CursorArtifact(std::env::temp_dir().join(format!("yusafcut-overlay-{}.ass", uuid::Uuid::new_v4())));
        let mut handle = std::fs::OpenOptions::new().write(true).create_new(true).mode(0o600).open(&file.0).map_err(|e| e.to_string())?;
        write_overlay_ass(&mut handle, items, keys, w, h, rect, key_y).map_err(|e| e.to_string())?;
        Ok(Some(file))
    };
    let (pw, ph) = picture_size(opts)?;
    let picture = Rect::fit(pw, ph, media.width, media.height);
    // With a scene the frame is the canvas; without one it is the (letterboxed) picture.
    let (fw, fh, frame) = match scene_for(opts) {
        Some(s) => (s.canvas_w, s.canvas_h, Rect { x: 0., y: 0., w: s.canvas_w as f64, h: s.canvas_h as f64 }),
        None => (pw, ph, picture),
    };
    Ok(OverlayFiles {
        follow: write(&o.follow, &[], pw, ph, picture)?,
        fixed: write(&o.fixed, &[], fw, fh, frame)?,
        keys: write(&[], &o.keys, fw, fh, frame)?,
        frame_text,
    })
}

/// The device frame's text (a few characters) as a private ASS file, removed on drop
/// like the other overlay files. `None` when there is no scene, no frame or no text.
fn prepare_frame_text(opts: &ExportOpts) -> Result<Option<CursorArtifact>, String> {
    let Some(script) = scene_for(opts).and_then(|s| s.frame_text_ass(opts.project.output_duration())) else { return Ok(None) };
    use std::io::Write as _;
    use std::os::unix::fs::OpenOptionsExt;
    let file = CursorArtifact(std::env::temp_dir().join(format!("yusafcut-frame-{}.ass", uuid::Uuid::new_v4())));
    let mut handle = std::fs::OpenOptions::new().write(true).create_new(true).mode(0o600).open(&file.0).map_err(|e| e.to_string())?;
    handle.write_all(script.as_bytes()).map_err(|e| e.to_string())?;
    Ok(Some(file))
}

async fn run_export(
    app: &AppHandle,
    state: &State<'_, AppState>,
    opts: &ExportOpts,
    job: &JobHandle,
) -> Result<(), String> {
    // Compute total duration up-front — used for chapter metadata + progress.
    let total_duration = opts.project.output_duration().max(0.001);

    if opts.project.segments.is_empty() {
        return Err("nothing to export — EDL is empty".into());
    }
    // Decide which path to take. Smart-cut needs a "clean" single-source EDL
    // with no codec/res/fps overrides and no music beds. Anything else falls
    // back to the full re-encode.
    let audio_only = audio_only(opts);
    // A scene redraws every frame, so stream-copy is never possible with one.
    // ProRes / GIF / audio containers can't hold the copied H.264+AAC, and a
    // range is cut frame-accurately on the output, so those re-encode too.
    let eligible = !opts.force_reencode
        && format_of(opts).allows_stream_copy()
        && opts.range.is_none()
        && !opts.stems
        && opts.loudness_lufs.is_none()
        && scene_for(opts).is_none()
        && zoom_for(opts).is_empty()
        && cursor_for(opts).is_none()
        && captions_for(opts).is_none()
        && overlays_for(opts).is_empty()
        // Stream copy would copy unmasked frames: masks and overlays always re-encode.
        && layers_for(opts).is_empty()
        && smart_cut::is_eligible(
            &opts.project,
            opts.codec.as_deref(),
            opts.width,
            opts.height,
            opts.fps,
            audio_only,
        );

    let chapter_meta = match range_span(opts, total_duration) {
        Some((start, dur)) => {
            let chapters = chapters_in_range(&opts.project.chapters, start, start + dur);
            build_chapter_metadata_file(&chapters, dur).await
        }
        None => build_chapter_metadata_file(&opts.project.chapters, total_duration).await,
    };

    if eligible {
        match try_smart_cut(app, state, opts, job, total_duration, chapter_meta.as_ref().map(|f| &f.0)).await {
            Ok(()) => return Ok(()),
            Err(SmartCutError::Skip(reason)) => {
                log::warn!("smart-cut not viable ({reason}); falling back to full re-encode");
            }
            Err(SmartCutError::Hard(msg)) => return Err(msg),
        }
    }

    full_reencode(app, state, opts, job, total_duration, chapter_meta).await
}

// ---------------------------------------------------------------------------
// Chapter metadata helper
// ---------------------------------------------------------------------------

/// The temp file is removed when the guard drops, so every cancel, error or
/// spawn failure between here and ffmpeg exiting cleans it up.
async fn build_chapter_metadata_file(
    chapters: &[Chapter],
    total_duration: f64,
) -> Option<CursorArtifact> {
    if chapters.is_empty() {
        return None;
    }
    let file = CursorArtifact(tempfile_with_ext("ffmeta.txt"));
    let body = build_chapter_ffmetadata(chapters, total_duration);
    if let Err(err) = fs::write(&file.0, body).await {
        log::warn!("failed to write chapter ffmetadata: {err}");
        return None;
    }
    Some(file)
}

// ---------------------------------------------------------------------------
// Smart-cut path
// ---------------------------------------------------------------------------

enum SmartCutError {
    /// Eligibility passed but something prevented smart-cut at runtime (no
    /// keyframes, ffprobe failed, etc). Caller falls back to full re-encode.
    Skip(String),
    /// Unrecoverable — error out instead of falling back.
    Hard(String),
}

impl From<String> for SmartCutError {
    fn from(s: String) -> Self {
        SmartCutError::Hard(s)
    }
}

async fn try_smart_cut(
    app: &AppHandle,
    state: &State<'_, AppState>,
    opts: &ExportOpts,
    job: &JobHandle,
    total_duration: f64,
    chapter_meta: Option<&PathBuf>,
) -> Result<(), SmartCutError> {
    // We've already proven all segments share a single source.
    let source_path = {
        let first = &opts.project.segments[0];
        opts.project
            .media
            .get(&first.media_id)
            .ok_or_else(|| SmartCutError::Skip(format!("unknown media: {}", first.media_id)))?
            .path
            .clone()
    };

    // Probe keyframes once for the source. If the file has no usable
    // keyframes (some screen recordings, exotic codecs) drop back to full.
    let kfs = smart_cut::probe_keyframes(app, &source_path)
        .await
        .map_err(|e| SmartCutError::Skip(format!("keyframe probe: {e}")))?;
    if kfs.len() < 3 {
        return Err(SmartCutError::Skip("source has too few keyframes".into()));
    }

    // Plan chunks for every segment.
    let mut plans: Vec<Vec<Chunk>> = Vec::with_capacity(opts.project.segments.len());
    let mut total_chunks = 0usize;
    let mut copyable = 0.0f64;
    let mut reencode_secs = 0.0f64;
    for seg in &opts.project.segments {
        let (clip_in, clip_out) = segment_clip_bounds(seg);
        let chunks = smart_cut::plan_segment(clip_in, clip_out, &kfs);
        for c in &chunks {
            match c.kind {
                ChunkKind::Copy => copyable += c.duration(),
                ChunkKind::Reencode => reencode_secs += c.duration(),
            }
        }
        total_chunks += chunks.len();
        plans.push(chunks);
    }

    // If nothing is copyable, smart-cut buys us nothing — bail.
    if copyable < smart_cut::MIN_COPY_DURATION {
        return Err(SmartCutError::Skip(
            "no segment had a long enough keyframe interior to copy".into(),
        ));
    }

    log::info!(
        "smart-cut plan: {} chunks across {} segments — {:.1}s copy, {:.1}s re-encode",
        total_chunks,
        plans.len(),
        copyable,
        reencode_secs
    );

    // Workdir for all the intermediates.
    let workdir = tempfile_with_ext("smartcut-work");
    fs::create_dir_all(&workdir)
        .await
        .map_err(|e| SmartCutError::Hard(format!("workdir: {e}")))?;

    // Make every chunk. We weight progress by *seconds processed*: copy
    // chunks count cheaply (10× faster), re-encode chunks count by wall-time.
    // For simplicity, attribute progress proportionally to chunk *duration*.
    let mut chunk_files: Vec<PathBuf> = Vec::with_capacity(total_chunks);
    let mut processed_secs = 0.0f64;
    let video_codec = pick_video_codec(opts);
    let vbitrate = opts.video_bitrate_kbps.unwrap_or(8000);
    let abitrate = opts.audio_bitrate_kbps.unwrap_or(192);

    for chunks in &plans {
        for chunk in chunks {
            // Honour cancel between chunks. The kill is performed by the
            // cancel_job command — here we just bail.
            if job.is_cancelled() {
                let _ = fs::remove_dir_all(&workdir).await;
                if let Some(p) = chapter_meta {
                    let _ = fs::remove_file(p).await;
                }
                return Err(SmartCutError::Hard("cancelled".into()));
            }

            let out = workdir.join(format!("chunk-{:04}.mp4", chunk_files.len()));
            match chunk.kind {
                ChunkKind::Copy => {
                    smart_cut_copy_chunk(app, state, &source_path, chunk, &out)
                        .await
                        .map_err(SmartCutError::Hard)?;
                }
                ChunkKind::Reencode => {
                    smart_cut_reencode_chunk(
                        app, state, &source_path, chunk, video_codec, vbitrate, abitrate, &out,
                    )
                    .await
                    .map_err(SmartCutError::Hard)?;
                }
            }
            chunk_files.push(out);

            processed_secs += chunk.duration();
            let p = (processed_secs / total_duration).clamp(0.0, 0.98);
            // Use 0..0.98 for chunk render so the final concat pass can claim
            // the last 2%.
            let secs_remaining = (total_duration - processed_secs).max(0.0) as i64;
            job.set_progress(p, Some(secs_remaining)).await;
            app.emit(
                "export:progress",
                serde_json::json!({
                    "progress": p,
                    "outputTimeSec": processed_secs,
                    "etaSec": secs_remaining,
                }),
            )
            .ok();
        }
    }

    // Concat list
    let list_path = workdir.join("concat.txt");
    let mut list = String::new();
    for f in &chunk_files {
        // ffmpeg concat demuxer requires single-quoted, backslash-escaped paths.
        let escaped = f.to_string_lossy().replace('\'', "'\\''");
        let _ = writeln!(list, "file '{escaped}'");
    }
    fs::write(&list_path, list)
        .await
        .map_err(|e| SmartCutError::Hard(format!("writing concat list: {e}")))?;

    concat_chunks(app, state, &list_path, chapter_meta, &opts.output_path)
        .await
        .map_err(SmartCutError::Hard)?;

    let _ = fs::remove_dir_all(&workdir).await;

    job.set_progress(1.0, Some(0)).await;
    app.emit(
        "export:progress",
        serde_json::json!({
            "progress": 1.0,
            "outputTimeSec": total_duration,
            "etaSec": 0i64,
        }),
    )
    .ok();
    Ok(())
}

fn pick_video_codec(opts: &ExportOpts) -> &'static str {
    match opts.codec.as_deref() {
        Some("hevc") => "hevc_videotoolbox",
        _ => "h264_videotoolbox",
    }
}

/// Stream-copy a single sub-range of the source into an MP4.
async fn smart_cut_copy_chunk(
    app: &AppHandle,
    state: &State<'_, AppState>,
    source: &str,
    chunk: &Chunk,
    out: &PathBuf,
) -> Result<(), String> {
    let argv: Vec<String> = vec![
        "-y".into(),
        "-hide_banner".into(),
        // -ss before -i means a keyframe seek, which is what we want for copy.
        "-ss".into(), format!("{:.6}", chunk.chunk_in),
        "-to".into(), format!("{:.6}", chunk.chunk_out),
        "-i".into(), source.into(),
        "-c".into(), "copy".into(),
        // Reset timestamps so the concat demuxer doesn't trip on monotonic-PTS.
        "-avoid_negative_ts".into(), "make_zero".into(),
        out.to_string_lossy().to_string(),
    ];
    run_ffmpeg(app, state, &argv).await
}

/// Re-encode a small sub-range, sharing codec parameters with the copy chunks
/// so the concat demuxer can splice them with `-c copy`.
#[allow(clippy::too_many_arguments)]
async fn smart_cut_reencode_chunk(
    app: &AppHandle,
    state: &State<'_, AppState>,
    source: &str,
    chunk: &Chunk,
    video_codec: &str,
    video_bitrate_kbps: u32,
    audio_bitrate_kbps: u32,
    out: &PathBuf,
) -> Result<(), String> {
    let argv: Vec<String> = vec![
        "-y".into(),
        "-hide_banner".into(),
        // For re-encode we want frame-accurate trim — put -ss after -i.
        "-i".into(), source.into(),
        "-ss".into(), format!("{:.6}", chunk.chunk_in),
        "-to".into(), format!("{:.6}", chunk.chunk_out),
        "-c:v".into(), video_codec.into(),
        "-b:v".into(), format!("{video_bitrate_kbps}k"),
        "-c:a".into(), "aac".into(),
        "-b:a".into(), format!("{audio_bitrate_kbps}k"),
        // Force a keyframe at the start so the next chunk concats cleanly.
        "-force_key_frames".into(), "expr:eq(n,0)".into(),
        "-avoid_negative_ts".into(), "make_zero".into(),
        out.to_string_lossy().to_string(),
    ];
    run_ffmpeg(app, state, &argv).await
}

/// Run the final concat-demuxer pass to glue the chunks together. Adds chapter
/// metadata if present.
async fn concat_chunks(
    app: &AppHandle,
    state: &State<'_, AppState>,
    list_path: &PathBuf,
    chapter_meta: Option<&PathBuf>,
    output_path: &str,
) -> Result<(), String> {
    let mut argv: Vec<String> = vec![
        "-y".into(),
        "-hide_banner".into(),
        "-f".into(), "concat".into(),
        "-safe".into(), "0".into(),
        "-i".into(), list_path.to_string_lossy().to_string(),
    ];
    if let Some(p) = chapter_meta {
        argv.push("-i".into());
        argv.push(p.to_string_lossy().to_string());
        argv.push("-map_metadata".into());
        argv.push("1".into());
    }
    argv.extend([
        "-c".into(), "copy".into(),
        "-movflags".into(), "+faststart".into(),
        output_path.into(),
    ]);
    run_ffmpeg(app, state, &argv).await
}

/// Run a single ffmpeg invocation and surface its child handle through
/// AppState so cancel_job can kill it.
async fn run_ffmpeg(
    app: &AppHandle,
    state: &State<'_, AppState>,
    argv: &[String],
) -> Result<(), String> {
    let shell = app.shell();
    let cmd = shell
        .sidecar("ffmpeg")
        .map_err(|e| format!("ffmpeg sidecar: {e}"))?
        .args(argv);
    let (mut rx, child) = cmd.spawn().map_err(|e| format!("spawn ffmpeg: {e}"))?;
    state.export.register_child(child).await?;
    while let Some(ev) = rx.recv().await {
        if let CommandEvent::Terminated(t) = ev {
            state.export.clear_child().await;
            if t.code != Some(0) {
                return Err(format!("ffmpeg exited with code {:?}", t.code));
            }
            return Ok(());
        }
    }
    Ok(())
}

// ---------------------------------------------------------------------------
// Full re-encode path (the v2.1 behaviour, now with music-bed mixing).
// ---------------------------------------------------------------------------

/// The complete ffmpeg argument list for the full re-encode path. Pure: it only
/// builds strings, so the real export can be exercised in tests without the app.
/// The app calls `build_reencode_argv_opts`; this overlay-free form serves tests.
#[cfg_attr(not(test), allow(dead_code))]
pub(crate) fn build_reencode_argv(
    opts: &ExportOpts,
    total_duration: f64,
    chapter_meta: Option<&PathBuf>,
    cursor_file: Option<&std::path::Path>,
) -> Result<Vec<String>, String> {
    build_reencode_argv_opts(opts, total_duration, chapter_meta, OverlayPaths { cursor: cursor_file, ..OverlayPaths::default() })
}

/// `build_reencode_argv` plus the prepared captions ASS file (thin wrapper for tests).
#[cfg(test)]
fn build_reencode_argv_with(
    opts: &ExportOpts,
    total_duration: f64,
    chapter_meta: Option<&PathBuf>,
    cursor_file: Option<&std::path::Path>,
    captions_file: Option<&std::path::Path>,
) -> Result<Vec<String>, String> {
    build_reencode_argv_opts(
        opts,
        total_duration,
        chapter_meta,
        OverlayPaths { cursor: cursor_file, captions: captions_file, ..OverlayPaths::default() },
    )
}

/// The one full re-encode argv builder: every prepared overlay file in `files`.
fn build_reencode_argv_opts(
    opts: &ExportOpts,
    total_duration: f64,
    chapter_meta: Option<&PathBuf>,
    files: OverlayPaths<'_>,
) -> Result<Vec<String>, String> {
    let cursor_file = files.cursor;
    let captions_file = files.captions;
    if captions_for(opts).is_some() && captions_file.is_none() {
        return Err("caption file was not prepared".into());
    }
    if cursor_for(opts).is_some() && cursor_file.is_none() {
        return Err("cursor export activity file was not prepared".into());
    }
    let follow_file = files.follow;
    let overlays = overlays_for(opts);
    if (!overlays.follow.is_empty() && follow_file.is_none())
        || (!overlays.fixed.is_empty() && files.fixed.is_none())
        || (!overlays.keys.is_empty() && files.keys.is_none())
    {
        return Err("annotation overlay file was not prepared".into());
    }
    if scene_for(opts).is_some_and(|s| s.frame_text_ass(1.0).is_some()) && files.frame_text.is_none() {
        return Err("device frame text file was not prepared".into());
    }
    // Build a list of (input_path, in, out) by walking the EDL in output order.
    let mut inputs: Vec<&String> = Vec::new();
    let mut clip_specs: Vec<(usize, f64, f64)> = Vec::new();
    for seg in &opts.project.segments {
        let media = opts
            .project
            .media
            .get(&seg.media_id)
            .ok_or_else(|| format!("unknown media: {}", seg.media_id))?;
        let idx = match inputs.iter().position(|p| **p == media.path) {
            Some(i) => i,
            None => {
                inputs.push(&media.path);
                inputs.len() - 1
            }
        };
        let (clip_in, clip_out) = segment_clip_bounds(seg);
        clip_specs.push((idx, clip_in, clip_out));
    }
    let media_inputs = inputs.len();

    // Audio formats carry no picture and GIF no sound. ffmpeg rejects a graph
    // with an unconnected output, so build only the streams that get written.
    let format = format_of(opts);
    let want_video = !format.is_audio();
    let want_audio = format != ExportFormat::Gif && opts.contact_sheet.is_none();
    // Media overlays are extra inputs after the sources, each bounded with `-t`
    // (and `-ss` for a trimmed video), so a long file is never read in full.
    let layer_set = layers_for(opts);
    let mut input_args: Vec<(usize, Vec<String>)> = Vec::new();
    // Drawn overlays with the label their picture is read from (`k:v`, or a mask stage).
    let mut follow_ov: Vec<(&layers::MediaOverlay, String)> = Vec::new();
    let mut fixed_ov: Vec<(&layers::MediaOverlay, String)> = Vec::new();
    let mut mask_graph = String::new();
    let mut audio_ov: Vec<(&layers::MediaOverlay, usize)> = Vec::new();
    for o in &layer_set.overlays {
        let drawn = want_video;
        let heard = want_audio && o.include_audio;
        if !drawn && !heard {
            continue;
        }
        let idx = inputs.len();
        inputs.push(&o.path);
        input_args.push((idx, layers::overlay_input_args(o, animation_fps(opts))));
        if drawn {
            // An overlay of masked footage (e.g. a magnified inset of the same
            // recording) gets the masks on its own frames first.
            let mut src = format!("{idx}:v");
            let ms = layers::masks_for_overlay(&layer_set.masks, &opts.project, o);
            if let Some(first) = ms.first() {
                let k = layers::mask_scale(&opts.project, &first.media_id)?;
                let fps = opts.project.media.get(&first.media_id).map(|m| m.fps).filter(|f| f.is_finite() && *f >= 1.).unwrap_or(30.);
                let label = format!("om{idx}");
                if let Some(g) = layers::overlay_mask_stage(&ms, o, k, idx, 1. / fps, mask_rate(fps), &label) {
                    let _ = write!(mask_graph, "{g};");
                    src = label;
                }
            }
            if o.follow_zoom { follow_ov.push((o, src)) } else { fixed_ov.push((o, src)) }
        }
        if heard {
            audio_ov.push((o, idx));
        }
    }
    let has_masks = want_video && !layer_set.masks.is_empty();
    // Build the segment filter graph (trim each segment, concat into [outv][outa]).
    let mut concat_inputs = String::new();
    let mut video_tail = String::new();
    let mut filter = String::new();
    // Privacy masks, per clip on the source frames (`layers::clip_mask_stage`):
    // before trim, speed, freeze frames and transitions, at that source's size.
    let mut clip_masks: Vec<Option<String>> = vec![None; opts.project.segments.len()];
    if has_masks {
        for (i, (seg, (input_idx, sin, sout))) in opts.project.segments.iter().zip(&clip_specs).enumerate() {
            let ms = layers::masks_for_media(&layer_set.masks, &opts.project, &seg.media_id);
            if ms.is_empty() {
                continue;
            }
            // A mask on a source with no known size refuses the export (never dropped).
            let k = layers::mask_scale(&opts.project, &seg.media_id)?;
            let fps = opts.project.media.get(&seg.media_id).map(|m| m.fps).filter(|f| f.is_finite() && *f >= 1.).unwrap_or(30.);
            let label = format!("cm{i}");
            if let Some(g) = layers::clip_mask_stage(&ms, k, *input_idx, *sin, *sout, 1. / fps, mask_rate(fps), &label) {
                let _ = write!(mask_graph, "{g};");
                clip_masks[i] = Some(label);
            }
        }
    }

    filter.push_str(&mask_graph);
    let scene = scene_for(opts);
    // With a scene, the scene filter sizes the picture, so skip the plain scale+pad.
    if let (Some(w), Some(h), None) = (opts.width, opts.height, scene) {
        let _ = write!(
            video_tail,
            ",scale={w}:{h}:force_original_aspect_ratio=decrease,pad={w}:{h}:(ow-iw)/2:(oh-ih)/2"
        );
    }
    if let Some(fps) = opts.fps {
        if fps > 0.0 {
            let _ = write!(video_tail, ",fps={fps}");
        }
    }
    // Speed / hold / mute / transitions: a separate clip graph (crate::retime).
    // Without them the plain trim+concat below is untouched, byte for byte.
    let zoom_regions = zoom_for(opts);
    let frame_layer = files.fixed.is_some() || captions_file.is_some() || files.keys.is_some() || !fixed_ov.is_empty();
    let post_processed = scene.is_some() || !zoom_regions.is_empty() || cursor_file.is_some() || follow_file.is_some() || frame_layer
        || !follow_ov.is_empty() || opts.contact_sheet.is_some();
    let concat_video_label = if post_processed { "catv" } else { "outv" };
    let timed = opts.project.has_timing_effects().then(|| {
        let mut inputs_in_order = clip_specs.iter().map(|c| c.0);
        crate::retime::clip_specs(&opts.project.segments, |_| inputs_in_order.next().unwrap_or(0))
    });
    // Rate for clips that must be resampled (speed / hold / crossfade): the
    // requested export rate, else the first source's (as a rational, capped:
    // see `Rate::from_fps`). Mute- or dip-only clips keep their own frames.
    let retime_rate = match opts.fps.filter(|f| *f > 0.0) {
        Some(f) => crate::retime::Rate::from_fps(f, 120.0),
        None => crate::retime::Rate::from_fps(
            opts.project.segments.first().and_then(|s| opts.project.media.get(&s.media_id)).map_or(30.0, |m| m.fps),
            60.0,
        ),
    };
    if let Some(specs) = &timed {
        crate::retime::append_clips(
            &mut filter, specs, &video_tail, retime_rate, "",
            want_video.then_some(concat_video_label), want_audio.then_some("mainvox"), None, &clip_masks,
        );
    } else {
        for (i, (input_idx, sin, sout)) in clip_specs.iter().enumerate() {
            if want_video {
                let src = clip_masks[i].clone().unwrap_or_else(|| format!("{input_idx}:v"));
                let _ = write!(filter, "[{src}]trim=start={sin}:end={sout},setpts=PTS-STARTPTS{video_tail}[v{i}];");
                let _ = write!(concat_inputs, "[v{i}]");
            }
            if want_audio {
                let _ = write!(filter, "[{input_idx}:a]atrim=start={sin}:end={sout},asetpts=PTS-STARTPTS[a{i}];");
                let _ = write!(concat_inputs, "[a{i}]");
            }
            filter.push('\n');
        }
        let _ = write!(
            filter,
            "{concat_inputs}concat=n={n}:v={v}:a={a}{vout}{aout}",
            n = clip_specs.len(),
            v = want_video as u8,
            a = want_audio as u8,
            vout = if want_video { format!("[{concat_video_label}]") } else { String::new() },
            aout = if want_audio { "[mainvox]" } else { "" },
        );
    }
    // Zoom, then the scene, both run on the concatenated picture. Each stage reads
    // the previous stage's label; the last one writes `outv`.

    // Zoom regions: magnify the picture over spans of the timeline.
    let mut picture_label = concat_video_label.to_string();
    if cursor_file.is_some() || follow_file.is_some() || !zoom_regions.is_empty() {
        let fps=animation_fps(opts);
        let _=write!(filter,";[{picture_label}]fps={fps}[animatedv]");
        picture_label="animatedv".into();
    }
    // Picture layer (masks already ran per clip): cursor, the masks once more
    // over the cursor, overlays then annotations that follow the zoom (then
    // zoom, then scene). Each stage reads the previous one's label.
    enum Pic<'p> { CursorMasks, Ass(&'p std::path::Path), Overlays }
    let mut stages: Vec<Pic> = Vec::new();
    if let Some(c) = cursor_file {
        stages.push(Pic::Ass(c));
        if has_masks { stages.push(Pic::CursorMasks); }
    }
    if !follow_ov.is_empty() { stages.push(Pic::Overlays); }
    if let Some(f) = follow_file { stages.push(Pic::Ass(f)); }
    if !stages.is_empty() {
        let out_label=if scene.is_some() || !zoom_regions.is_empty() {"cursorv"} else {"outv"};
        // Where normalised picture coordinates live (the letterboxed source picture).
        let picture_rect = || -> Result<(Rect, u32, u32), String> {
            let (pw, ph) = picture_size(opts)?;
            let m = opts.project.segments.first().and_then(|s| opts.project.media.get(&s.media_id)).ok_or("picture needs a source")?;
            Ok((Rect::fit(pw, ph, m.width, m.height), pw, ph))
        };
        let n = stages.len();
        for (i, stage) in stages.iter().enumerate() {
            // Intermediate labels: `picv`, then `picv1`, `picv2`, ...
            let label = if i + 1 == n { out_label.to_string() } else if i == 0 { "picv".into() } else { format!("picv{i}") };
            let stage = match stage {
                Pic::CursorMasks => {
                    // The cursor is drawn on the output picture: hide it inside masks by
                    // masking again (output time, each source placed as `video_tail` fits it,
                    // spans widened by the longest transition half). Dim hides nothing: skipped.
                    // Unscaled clips (no export size, or a scene): the picture IS each
                    // source's decoded frame, so masks are placed from `iw`/`ih` and stored
                    // sizes never matter. Scaled to an export size: placed by the source's
                    // size, which `full_reencode` re-probes first (`with_probed_mask_sizes`).
                    let scaled = matches!((opts.width, opts.height, scene), (Some(_), Some(_), None));
                    let (pw, ph) = if scaled { picture_size(opts)? } else { (0, 0) };
                    let widen = opts.project.segments.iter().filter_map(|s| s.timing.transition_in.map(|t| t.duration / 2.)).fold(0., f64::max);
                    let mut placed: Vec<layers::Placed> = Vec::new();
                    for m in layer_set.masks.iter().filter(|m| m.effect != layers::MaskEffect::Dim) {
                        let Some(media) = opts.project.media.get(&m.media_id) else { continue };
                        let spans: Vec<(f64, f64)> = layers::mask_output_spans(&opts.project, m).into_iter().map(|(a, b)| (a - widen, b + widen)).collect();
                        if spans.is_empty() {
                            continue;
                        }
                        let (geom, k) = if scaled {
                            let rect = Rect::fit(pw, ph, media.width, media.height);
                            (layers::Geom::Rect(rect, pw, ph), rect.w.min(rect.h) / 1080.)
                        } else {
                            (layers::Geom::Frame, layers::mask_scale(&opts.project, &m.media_id)?)
                        };
                        placed.push(layers::Placed { mask: m, geom, k, spans });
                    }
                    if placed.is_empty() {
                        format!("[{picture_label}]null[{label}]")
                    } else {
                        layers::mask_chain(&placed, 1. / animation_fps(opts), "cmk", &picture_label, &label)
                    }
                }
                Pic::Ass(path) => filter_stage(&picture_label, path, &label, false),
                Pic::Overlays => layers::overlay_chain(&follow_ov, picture_rect()?.0, "ovp", &picture_label, &label),
            };
            let _=write!(filter,";{stage}");
            picture_label = label;
        }
    }
    if !zoom_regions.is_empty() {
        // Size of the picture entering the zoom: the export size when it is set and
        // there is no scene to size it, otherwise the first source's own size.
        let (base_w, base_h) = match (opts.width, opts.height, scene) {
            (Some(w), Some(h), None) => (w, h),
            _ => opts
                .project
                .segments
                .first()
                .and_then(|seg| opts.project.media.get(&seg.media_id))
                .map(|m| (m.width, m.height))
                .ok_or("zoom needs a source with a size")?,
        };
        let out_label = if scene.is_some() { "zoomv" } else { "outv" };
        if let Some(zoom_graph) = build_zoom_filter(&zoom_regions, base_w, base_h, &picture_label, out_label)? {
            let _ = write!(filter, ";{zoom_graph}");
            picture_label = out_label.to_string();
        }
    }

    // The scene: background, rounded corners and shadow around the picture.
    let mut bg_image_input: Option<usize> = None;
    // Label of the finished scene picture: `outv`, or `scenetv` once device text is drawn on it.
    let mut scene_label = "outv";
    if let Some(scene) = scene {
        let image_input = if let ResolvedBackground::Image { path } = &scene.background {
            // The image is one more ffmpeg input; `path` lives as long as `opts`.
            let idx = inputs.len();
            inputs.push(path);
            bg_image_input = Some(idx);
            Some(idx)
        } else {
            None
        };
        let fps = opts
            .fps
            .filter(|f| *f > 0.0)
            .or_else(|| {
                opts.project
                    .segments
                    .first()
                    .and_then(|seg| opts.project.media.get(&seg.media_id))
                    .map(|m| m.fps)
            })
            .unwrap_or(30.0);
        // The picture entering the scene is the first segment's media, whatever was imported first.
        let source = picture_size(opts)?;
        let scene_graph = build_scene_filter(scene, fps, image_input, &picture_label, "outv", source, format.has_alpha())?;
        let _ = write!(filter, ";{scene_graph}");
        // Device frame text (browser address): drawn on the finished scene, so it never zooms.
        if let Some(path) = files.frame_text {
            let _ = write!(filter, ";{}", filter_stage("outv", path, "scenetv", format.has_alpha()));
            scene_label = "scenetv";
        }
    }

    // A range is cut inside the graph, after music, zoom, cursor and scene are
    // laid out on the whole timeline (so the slice matches the preview) but
    // before GIF palettes or encoders see a frame: nothing outside the range is
    // buffered or encoded, and progress counts only the range.
    let range = range_span(opts, total_duration);
    // The finished picture: the scene's last label, else the picture layer's last
    // (never a bare `outv` that only the scene, zoom or picture stages write).
    let mut video_label = if scene.is_some() { scene_label.to_string() } else { picture_label.clone() };
    // LAYER ORDER (see the policy above `OverlayFiles` and docs/architecture.md):
    // the frame layer goes on the finished frame (after zoom and scene) so it is
    // never zoomed or framed: fixed annotations, then captions, then key caps.
    // The scene carries an alpha plane exactly when the format can hold it
    // (`build_scene_filter` keep_alpha); libass must then write alpha too, or
    // overlays over transparent padding would stay invisible.
    if want_video && frame_layer {
        let keep_alpha = scene.is_some() && format.has_alpha();
        let mut last = video_label.clone();
        if files.fixed.is_some() || files.keys.is_some() || !fixed_ov.is_empty() {
            // Static screen footage can be very low frame rate; give fades frames.
            let _ = write!(filter, ";[{last}]fps={}[framev]", animation_fps(opts));
            last = "framev".into();
        }
        if !fixed_ov.is_empty() {
            // Below the fixed annotations; the frame is the canvas with a scene, else the picture.
            let (pw, ph) = picture_size(opts)?;
            let frame = match scene {
                Some(s) => Rect { x: 0., y: 0., w: s.canvas_w as f64, h: s.canvas_h as f64 },
                None => {
                    let m = opts.project.segments.first().and_then(|s| opts.project.media.get(&s.media_id)).ok_or("overlays need a source")?;
                    Rect::fit(pw, ph, m.width, m.height)
                }
            };
            let _ = write!(filter, ";{}", layers::overlay_chain(&fixed_ov, frame, "ovf", &last, "ovlv"));
            last = "ovlv".into();
        }
        for (path, label) in [(files.fixed, "fixv"), (captions_file, "capv"), (files.keys, "keyv")] {
            if let Some(path) = path {
                let _ = write!(filter, ";{}", filter_stage(&last, path, label, keep_alpha));
                last = label.into();
            }
        }
        video_label = last;
    }
    if let (Some((start, dur)), true) = (range, want_video) {
        let _ = write!(filter, ";[{video_label}]trim=start={start:.6}:duration={dur:.6},setpts=PTS-STARTPTS[rangev]");
        video_label = "rangev".into();
    }
    let range_audio = |filter: &mut String, label: &str| -> String {
        match range {
            Some((start, dur)) => {
                let _ = write!(filter, ";[{label}]atrim=start={start:.6}:duration={dur:.6},asetpts=PTS-STARTPTS[{label}_r]");
                format!("{label}_r")
            }
            None => label.to_string(),
        }
    };

    // GIF: cap rate and width, then a palette per frame. A whole-clip palette
    // (stats_mode=diff) only appears at end of stream, so paletteuse would hold
    // every frame in memory first.
    let video_out = if let Some(times) = &opts.contact_sheet {
        // The frames nearest each sample time, tiled five to a row for checking by eye.
        let half = 0.5 / animation_fps(opts);
        let pick: Vec<String> = times.iter().map(|t| format!("lt(abs(t-{t:.6}),{half:.6})")).collect();
        let n = times.len().max(1);
        let _ = write!(
            filter,
            ";[{video_label}]select='{}',scale=480:-2,tile={}x{}:padding=4:color=white[sheet]",
            pick.join("+"),
            n.min(COVERAGE_COLUMNS),
            n.div_ceil(COVERAGE_COLUMNS)
        );
        "[sheet]".to_string()
    } else if format == ExportFormat::Gif {
        let _ = write!(
            filter,
            ";[{video_label}]fps={fps},scale={w}:-1:flags=lanczos,split[gifa][gifb];\
             [gifa]palettegen=stats_mode=single[gifp];\
             [gifb][gifp]paletteuse=new=1:dither=bayer:bayer_scale=5:diff_mode=rectangle[gifv]",
            fps = gif_fps(opts),
            w = gif_width(opts),
        );
        "[gifv]".to_string()
    } else {
        format!("[{video_label}]")
    };

    // Stems: one track per recorded source, silent while another source plays,
    // so the voice stems line up with the mix sample-for-sample.
    let mut stem_labels: Vec<String> = Vec::new();
    if opts.stems && want_audio {
        // Recorded sources only (overlay inputs come after them).
        let sources: Vec<usize> = (0..media_inputs).collect();
        for k in sources {
            if let Some(specs) = &timed {
                // Same retimed clips as the mix, other sources silenced.
                let label = format!("stemv{k}");
                filter.push(';');
                crate::retime::append_clips(&mut filter, specs, "", retime_rate, &format!("st{k}_"), None, Some(&label), Some(k), &[]);
                stem_labels.push(label);
                continue;
            }
            let mut cat = String::new();
            for (i, (input_idx, sin, sout)) in clip_specs.iter().enumerate() {
                let mute = if *input_idx == k { "" } else { ",volume=0" };
                let _ = write!(filter, ";[{input_idx}:a]atrim=start={sin}:end={sout},asetpts=PTS-STARTPTS{mute}[st{k}_{i}]");
                let _ = write!(cat, "[st{k}_{i}]");
            }
            let _ = write!(filter, ";{cat}concat=n={n}:v=0:a=1[stemv{k}]", n = clip_specs.len());
            stem_labels.push(format!("stemv{k}"));
        }
    }
    let voice_stems = stem_labels.len();

    // Voice-over override: the original clip audio (and its stems) is silent
    // inside each replacement interval, with short ramps outside it. Absent
    // without override takes, so every other graph is unchanged.
    let mut voice_label = "mainvox";
    let replaced: Vec<(f64, f64)> = opts
        .project
        .replacement_intervals(total_duration)
        .into_iter()
        .map(|(_, a, b)| (a, b))
        .collect();
    if let (Some(expr), true) = (crate::edl::envelope_expr(&replaced), want_audio) {
        let env = format!("asetnsamples=n=256:p=0,volume=volume='{expr}':eval=frame");
        let _ = write!(filter, ";[mainvox]{env}[mainvox_vo]");
        voice_label = "mainvox_vo";
        for label in stem_labels.iter_mut() {
            let _ = write!(filter, ";[{label}]{env}[{label}_vo]");
            *label = format!("{label}_vo");
        }
    }

    // Music-bed mixing. We track the music input indices as we add them, then
    // append filter rules to mix them under [mainvox] → [outa].
    let final_audio_label = if !want_audio {
        String::new()
    } else if opts.project.audible_tracks().is_empty() {
        // No music — just route mainvox straight through.
        let _ = write!(filter, ";[{voice_label}]anull[outa]");
        "outa".to_string()
    } else {
        append_music_bed_filters(
            &mut filter,
            &mut inputs,
            voice_label,
            &opts.project,
            total_duration,
            if opts.stems { Some(&mut stem_labels) } else { None },
        )?;
        "outa".to_string()
    };
    // Video overlays with "include audio": mixed over everything else, never ducked.
    let final_audio_label = if want_audio && !audio_ov.is_empty() {
        let labels = layers::overlay_audio(&audio_ov, total_duration, &mut filter);
        let ins: String = labels.iter().map(|l| format!("[{l}]")).collect();
        let _ = write!(
            filter,
            ";[{final_audio_label}]{ins}amix=inputs={}:duration=first:dropout_transition=0:normalize=0[outa_ov]",
            labels.len() + 1
        );
        "outa_ov".to_string()
    } else {
        final_audio_label
    };
    let final_audio_label = if want_audio { range_audio(&mut filter, &final_audio_label) } else { final_audio_label };
    // Loudness is measured on what gets written (after the range cut). loudnorm
    // works at 192 kHz internally, so bring it back to the mix's 48 kHz.
    let final_audio_label = match (opts.loudness_lufs, want_audio) {
        (Some(target), true) => {
            let _ = write!(
                filter,
                ";[{final_audio_label}]loudnorm=I={target}:TP=-1.5:LRA=11,aresample=48000[outa_ln]"
            );
            "outa_ln".to_string()
        }
        _ => final_audio_label,
    };
    let stem_labels: Vec<String> = stem_labels.iter().map(|l| range_audio(&mut filter, l)).collect();

    // Build the argv now that we know the input list (incl. music files).
    let mut argv: Vec<String> = vec![
        "-y".into(),
        "-hide_banner".into(),
        "-hwaccel".into(),
        "videotoolbox".into(),
    ];
    for (i, path) in inputs.iter().enumerate() {
        if let Some((_, args)) = input_args.iter().find(|(k, _)| *k == i) {
            argv.extend(args.iter().cloned());
        }
        if Some(i) == bg_image_input {
            // A still image must loop to last as long as the video.
            argv.push("-loop".into());
            argv.push("1".into());
        }
        argv.push("-i".into());
        argv.push(path.to_string());
    }
    // Chapter metadata as one extra non-media input.
    let chapter_input_index: Option<usize> = chapter_meta.map(|p| {
        let idx = inputs.len();
        argv.push("-i".into());
        argv.push(p.to_string_lossy().to_string());
        idx
    });
    argv.push("-filter_complex".into());
    argv.push(filter);

    // Mapping
    if want_video {
        argv.push("-map".into());
        argv.push(video_out);
    }
    if want_audio {
        argv.push("-map".into());
        argv.push(format!("[{final_audio_label}]"));
    }

    if let Some(idx) = chapter_input_index {
        argv.push("-map_metadata".into());
        argv.push(idx.to_string());
    }

    // Per-output encoder settings; stems reuse them so every file matches the mix.
    let mut codec: Vec<String> = Vec::new();
    let video_codec = pick_video_codec(opts);
    let vb = opts.video_bitrate_kbps.unwrap_or(8000);
    match format {
        _ if opts.contact_sheet.is_some() => {
            codec.extend(["-frames:v".into(), "1".into(), "-update".into(), "1".into()]);
        }
        ExportFormat::Mp4 | ExportFormat::Mov => {
            let ab = opts.audio_bitrate_kbps.unwrap_or(192);
            codec.extend(["-c:v".into(), video_codec.into(), "-b:v".into(), format!("{vb}k")]);
            if format == ExportFormat::Mov && video_codec == "hevc_videotoolbox" {
                // QuickTime only plays HEVC tagged hvc1 (ffmpeg defaults to hev1).
                codec.extend(["-tag:v".into(), "hvc1".into()]);
            }
            codec.extend([
                "-c:a".into(), "aac".into(),
                "-b:a".into(), format!("{ab}k"),
                "-movflags".into(), "+faststart".into(),
            ]);
        }
        ExportFormat::ProRes422 | ExportFormat::ProRes422Hq => {
            let profile = if format == ExportFormat::ProRes422Hq { "3" } else { "2" };
            codec.extend([
                "-c:v".into(), "prores_ks".into(),
                "-profile:v".into(), profile.into(),
                "-vendor".into(), "apl0".into(),
                "-pix_fmt".into(), "yuv422p10le".into(),
                "-c:a".into(), "pcm_s16le".into(),
            ]);
        }
        ExportFormat::ProRes4444 => {
            codec.extend([
                "-c:v".into(), "prores_ks".into(),
                "-profile:v".into(), "4".into(),
                "-vendor".into(), "apl0".into(),
                "-pix_fmt".into(), "yuva444p10le".into(),
                "-c:a".into(), "pcm_s16le".into(),
            ]);
        }
        ExportFormat::Gif => {
            codec.extend(["-c:v".into(), "gif".into(), "-loop".into(), "0".into()]);
        }
        ExportFormat::M4a => {
            let ab = opts.audio_bitrate_kbps.unwrap_or(128);
            codec.extend(["-vn".into(), "-c:a".into(), "aac".into(), "-b:a".into(), format!("{ab}k")]);
        }
        ExportFormat::Wav => {
            codec.extend(["-vn".into(), "-c:a".into(), "pcm_s16le".into()]);
        }
    }
    argv.extend(codec.iter().cloned());
    argv.extend(["-progress".into(), "pipe:1".into()]);
    argv.push(opts.output_path.clone());

    let paths = stem_paths(&opts.output_path, voice_stems, &narration_flags(&opts.project));
    for (label, path) in stem_labels.iter().zip(paths) {
        argv.extend(["-map".into(), format!("[{label}]")]);
        argv.extend(codec.iter().cloned());
        argv.push(path);
    }
    Ok(argv)
}

async fn full_reencode(
    app: &AppHandle,
    state: &State<'_, AppState>,
    opts: &ExportOpts,
    job: &JobHandle,
    total_duration: f64,
    chapter_meta: Option<CursorArtifact>,
) -> Result<(), String> {
    let probed = with_probed_mask_sizes(app, opts).await;
    let opts = &probed;
    let cursor_artifact=prepare_cursor(opts,job).await?;
    if job.is_cancelled() { return Err("cancelled".into()); }
    let captions_artifact = prepare_captions(opts).await?;
    let overlay = prepare_overlays(opts)?;
    let files = OverlayPaths {
        cursor: cursor_artifact.as_ref().map(|file| file.0.as_path()),
        captions: captions_artifact.as_ref().map(|file| file.0.as_path()),
        ..overlay.paths()
    };
    let argv = build_reencode_argv_opts(opts, total_duration, chapter_meta.as_ref().map(|f| &f.0), files)?;

    log::info!("ffmpeg {}", argv.join(" "));
    // Progress is measured on what gets written: the range when there is one.
    let total_duration = range_span(opts, total_duration).map_or(total_duration, |(_, d)| d);

    let shell = app.shell();
    let cmd = shell
        .sidecar("ffmpeg")
        .map_err(|e| format!("ffmpeg sidecar: {e}"))?
        .args(argv);
    let (mut rx, child) = cmd.spawn().map_err(|e| format!("spawn ffmpeg: {e}"))?;
    state.export.register_child(child).await?;

    while let Some(ev) = rx.recv().await {
        match ev {
            CommandEvent::Stdout(buf) => {
                let s = String::from_utf8_lossy(&buf);
                for line in s.lines() {
                    if let Some(rest) = line.strip_prefix("out_time_ms=") {
                        if let Ok(us) = rest.trim().parse::<u64>() {
                            let secs = us as f64 / 1_000_000.0;
                            let progress = (secs / total_duration).clamp(0.0, 1.0);
                            let eta = if progress > 0.001 {
                                Some(((total_duration - secs).max(0.0)) as i64)
                            } else {
                                None
                            };
                            job.set_progress(progress, eta).await;
                            app.emit(
                                "export:progress",
                                serde_json::json!({
                                    "progress": progress,
                                    "outputTimeSec": secs,
                                    "etaSec": eta,
                                }),
                            )
                            .ok();
                        }
                    }
                }
            }
            CommandEvent::Stderr(_) => {}
            CommandEvent::Terminated(t) => {
                state.export.clear_child().await;
                if t.code != Some(0) {
                    return Err(format!("ffmpeg exited with code {:?}", t.code));
                }
                app.emit(
                    "export:progress",
                    serde_json::json!({"progress": 1.0, "outputTimeSec": total_duration, "etaSec": 0i64}),
                )
                .ok();
                return Ok(());
            }
            _ => {}
        }
    }
    Ok(())
}

// ---------------------------------------------------------------------------
// Music-bed filter graph helpers
// ---------------------------------------------------------------------------

/// Append filter graph nodes that mix every audio track in the project under
/// the `[mainvox]` label and emit `[outa]`.
///
/// For each track:
///   * Add the underlying media file as a new -i input.
///   * Apply `volume=<gainDb>dB`, an `adelay` if `offsetSec > 0`, and
///     trim/`apad` so the track is exactly the output duration.
///   * If `ducks`, sidechain-compress it against [mainvox] so the music
///     drops by ~12 dB whenever the speaker is talking.
///   * `amix` all tracks together, then mix with [mainvox] (with normalize=0
///     so we don't lose voice headroom).
pub fn append_music_bed_filters<'a>(
    filter: &mut String,
    inputs: &mut Vec<&'a String>,
    voice_label: &str,
    project: &'a Project,
    total_duration: f64,
    stems: Option<&mut Vec<String>>,
) -> Result<(), String> {
    // Muted tracks, and everything but the soloed ones, are not in the graph at all.
    let tracks = project.audible_tracks();
    if tracks.is_empty() {
        return Ok(());
    }
    // Branch the voice so we can both use it as sidechain *and* mix it
    // directly. `asplit` is the audio version of split. One sidechain branch
    // per ducking track: ffmpeg refuses a graph with an unused or reused label,
    // so no ducking means no split at all.
    // A voice-over take never ducks itself; it is part of what the music ducks under.
    let ducks = |t: &AudioTrack| t.ducks && !t.is_voice_over();
    let ducking = tracks.iter().filter(|t| ducks(t)).count();
    let side_label = |k: usize| if k == 0 { "vox_side".to_string() } else { format!("vox_side_{k}") };
    // With takes, the sidechain key is the voice mixed with every heard take
    // (built after the loop, `vox_key`), so music ducks under narration too.
    let take_keys = ducking > 0 && tracks.iter().any(|t| t.is_voice_over());
    let mut keys: Vec<String> = Vec::new();
    if ducking == 0 {
        let _ = write!(filter, ";[{voice_label}]anull[vox_main]");
    } else if take_keys {
        let _ = write!(filter, ";[{voice_label}]asplit=2[vox_main][vox_key]");
    } else {
        let sides: String = (0..ducking).map(|k| format!("[{}]", side_label(k))).collect();
        let _ = write!(filter, ";[{voice_label}]asplit={}[vox_main]{sides}", ducking + 1);
    }
    let mut stems = stems;
    let mut next_side = 0;

    // Process each track.
    let mut track_labels: Vec<String> = Vec::with_capacity(tracks.len());
    for (i, track) in tracks.iter().copied().enumerate() {
        let media = project.media.get(&track.media_id).ok_or_else(|| {
            format!("audio track references unknown media: {}", track.media_id)
        })?;
        let input_idx = inputs.len();
        inputs.push(&media.path);

        // Trim, gain, optional ducking.
        let raw_label = format!("trk_raw_{i}");
        let delay_ms = (track.offset_sec.max(0.0) * 1000.0).round() as i64;
        // A voice-over take plays only its trim; a music bed its whole file.
        let (media_in, media_len) = track.media_range(media.duration);
        let trim = if track.is_voice_over() {
            format!("atrim=start={media_in:.6}:end={:.6}", media_in + media_len)
        } else {
            format!("atrim=0:{total_duration:.3}")
        };
        let _ = write!(
            filter,
            ";[{input_idx}:a]{trim},asetpts=PTS-STARTPTS,volume={gain}dB",
            gain = track.gain_db
        );
        // Fades run on the track's own clock (before the delay): the in-fade
        // starts with the track, the out-fade ends where the track ends on the
        // output timeline (media end, or the end of the edit if that is sooner).
        let start = delay_ms as f64 / 1000.0;
        let clip_len = media_len.min((total_duration - start).max(0.0));
        let (fade_in, fade_out) = resolve_fades(track.fade_in_sec, track.fade_out_sec, clip_len);
        if fade_in > 0.0 {
            let _ = write!(filter, ",afade=t=in:st=0:d={fade_in:.3}");
        }
        if fade_out > 0.0 {
            let _ = write!(filter, ",afade=t=out:st={:.3}:d={fade_out:.3}", clip_len - fade_out);
        }
        if delay_ms > 0 {
            // `adelay=N|N` applies to first 2 channels; works on mono+stereo files.
            let _ = write!(filter, ",adelay={delay_ms}|{delay_ms}");
        }
        // An older take is silent where a newer override take replaces it.
        if let Some(expr) = crate::edl::envelope_expr(&project.suppressors_of(&track.id, total_duration)) {
            let _ = write!(filter, ",asetnsamples=n=256:p=0,volume=volume='{expr}':eval=frame");
        }
        // Pad/cut the track to match the output duration so amix doesn't
        // truncate the voice.
        let _ = write!(
            filter,
            ",apad,atrim=0:{total_duration:.3},asetpts=PTS-STARTPTS[{raw_label}]"
        );

        // Stems tap the track after gain and offset but before ducking, so it
        // can be re-ducked or re-levelled in an editor.
        let raw_label = match stems.as_deref_mut() {
            Some(stems) => {
                let _ = write!(filter, ";[{raw_label}]asplit=2[{raw_label}_mix][{raw_label}_stem]");
                stems.push(format!("{raw_label}_stem"));
                format!("{raw_label}_mix")
            }
            None => raw_label,
        };
        let raw_label = if take_keys && track.is_voice_over() {
            let key = format!("trk_key_{i}");
            let _ = write!(filter, ";[{raw_label}]asplit=2[{raw_label}_m][{key}]");
            keys.push(key);
            format!("{raw_label}_m")
        } else {
            raw_label
        };

        if ducks(track) {
            let ducked = format!("trk_duck_{i}");
            let vox_side = side_label(next_side);
            next_side += 1;
            // `sidechaincompress` defaults: threshold=0.125, ratio=2 → not
            // aggressive enough. Tighten threshold + ratio for a real ducking
            // effect.
            let _ = write!(
                filter,
                ";[{raw_label}][{vox_side}]sidechaincompress=threshold=0.05:ratio=8:attack=20:release=300:makeup=1[{ducked}]"
            );
            track_labels.push(ducked);
        } else {
            track_labels.push(raw_label);
        }
    }
    if take_keys {
        // Voice + takes → one sidechain branch per ducking track. (The ducking
        // chains above reference `vox_side*` before this defines them; the
        // filtergraph parser links labels in either order.)
        let inputs: String = std::iter::once("[vox_key]".to_string())
            .chain(keys.iter().map(|k| format!("[{k}]")))
            .collect();
        let sides: String = (0..ducking).map(|k| format!("[{}]", side_label(k))).collect();
        let _ = write!(
            filter,
            ";{inputs}amix=inputs={}:duration=first:dropout_transition=0:normalize=0,asplit={ducking}{sides}",
            keys.len() + 1
        );
    }

    // Merge all music tracks. If only one, route it directly. Otherwise amix.
    let music_label = if track_labels.len() == 1 {
        track_labels.into_iter().next().unwrap()
    } else {
        let mixed = "music_mix".to_string();
        let mut amix_inputs = String::new();
        for l in &track_labels {
            let _ = write!(amix_inputs, "[{l}]");
        }
        let n = track_labels.len();
        let _ = write!(
            filter,
            ";{amix_inputs}amix=inputs={n}:duration=longest:dropout_transition=0:normalize=0[{mixed}]"
        );
        mixed
    };

    // Final mix: voice + music. normalize=0 keeps voice gain intact.
    let _ = write!(
        filter,
        ";[vox_main][{music_label}]amix=inputs=2:duration=first:dropout_transition=0:normalize=0[outa]"
    );

    Ok(())
}

// ---------------------------------------------------------------------------
// Chapter ffmetadata builder + temp paths
// ---------------------------------------------------------------------------

/// Build an FFmetadata file containing one [CHAPTER] block per chapter.
/// ffmpeg expects per-chapter START/END in TIMEBASE units; we use 1/1000 so
/// times are simply integer milliseconds. The exporter clamps end-of-file
/// using the total output duration so the last chapter gets a sensible END.
fn build_chapter_ffmetadata(chapters: &[Chapter], total_duration_sec: f64) -> String {
    let mut sorted: Vec<&Chapter> = chapters.iter().collect();
    sorted.sort_by(|a, b| {
        a.output_time
            .partial_cmp(&b.output_time)
            .unwrap_or(std::cmp::Ordering::Equal)
    });

    let mut out = String::from(";FFMETADATA1\n");
    for (i, c) in sorted.iter().enumerate() {
        let start_ms = (c.output_time.max(0.0) * 1000.0).round() as u64;
        let end_ms = if i + 1 < sorted.len() {
            (sorted[i + 1].output_time.max(0.0) * 1000.0).round() as u64
        } else {
            (total_duration_sec.max(c.output_time) * 1000.0).round() as u64
        };
        let safe_title = c
            .title
            .replace('\\', "\\\\")
            .replace('=', "\\=")
            .replace(';', "\\;")
            .replace('#', "\\#")
            .replace('\n', " ");
        let _ = writeln!(out, "[CHAPTER]");
        let _ = writeln!(out, "TIMEBASE=1/1000");
        let _ = writeln!(out, "START={start_ms}");
        let _ = writeln!(out, "END={end_ms}");
        let _ = writeln!(out, "title={safe_title}");
    }
    out
}

fn tempfile_with_ext(ext: &str) -> std::path::PathBuf {
    let mut p = std::env::temp_dir();
    p.push(format!("yusafcut-{}.{}", uuid::Uuid::new_v4(), ext));
    p
}

/// The masks are drawn again after the cursor on the output picture; when the
/// clips are scaled to an export size their placement needs each masked
/// source's real size. Stored sizes can be stale (rotated clips imported
/// before rotation-aware probing), so those are re-probed here. Only then.
async fn with_probed_mask_sizes(app: &AppHandle, opts: &ExportOpts) -> ExportOpts {
    let mut o = opts.clone();
    let scaled = matches!((o.width, o.height, scene_for(&o)), (Some(_), Some(_), None));
    if !(scaled && cursor_for(&o).is_some()) {
        return o;
    }
    for m in layers::source_masks(&o.project) {
        let Some(path) = o.project.media.get(&m.media_id).map(|x| x.path.clone()) else { continue };
        if let Ok((w, h)) = crate::commands::media::probe_size(app, &path).await {
            if let Some(media) = o.project.media.get_mut(&m.media_id) {
                (media.width, media.height) = (w, h);
            }
        }
    }
    o
}

/// Frames per row in a "Check coverage" contact sheet, and at most this many places checked.
const COVERAGE_COLUMNS: usize = 5;
const COVERAGE_PLACES: usize = 6;
/// Up to this many places on screen, every one is sampled.
const COVERAGE_ALL_PLACES: usize = 12;

/// How many of `n` places a coverage sheet samples (`coveragePlaces` in masks.ts).
pub(crate) fn coverage_places(n: usize) -> usize {
    if n <= COVERAGE_ALL_PLACES { n } else { COVERAGE_PLACES }
}

/// Sample times (output seconds) for checking `spans`: for every place the
/// mask is on screen, the frame just before it (by the longest transition
/// half plus a frame, so crossfade / dip frames are included), its first,
/// middle and last frames, and the frame just after it. One frame apart at
/// least, inside the timeline.
pub(crate) fn coverage_times(spans: &[(f64, f64)], fps: f64, widen: f64, total: f64) -> Vec<f64> {
    let frame = 1. / fps;
    let h = frame + widen;
    let last = (total - frame).max(0.);
    let mut t: Vec<f64> = spans
        .iter()
        .take(coverage_places(spans.len()))
        .flat_map(|(a, b)| [a - h, *a, (a + b) / 2., b - frame, b + h - frame])
        .map(|x| x.clamp(0., last))
        .collect();
    t.sort_by(f64::total_cmp);
    t.dedup_by(|b, a| *b - *a < frame * 0.9);
    t
}

/// "Check coverage" for a privacy mask: frames around and inside EVERY place
/// its source content is on screen (`coverage_times`), rendered through the
/// real export graph (per-clip masks, transitions, cursor, zoom, scene, crop,
/// overlays, captions) into one PNG in the temp folder.
pub(crate) fn coverage_opts(opts: ExportOpts, mask_id: &str, sheet: &std::path::Path) -> Result<ExportOpts, String> {
    let total = opts.project.output_duration();
    if opts.project.segments.is_empty() {
        return Err("nothing to check: the timeline is empty".into());
    }
    let mask = layers::source_masks(&opts.project).into_iter().find(|m| m.id == mask_id).ok_or("that mask no longer exists")?;
    let spans = layers::mask_output_spans(&opts.project, &mask);
    if spans.is_empty() {
        return Err("this mask's footage is not on the timeline".into());
    }
    let widen = opts.project.segments.iter().filter_map(|s| s.timing.transition_in.map(|t| t.duration / 2.)).fold(0., f64::max);
    let times = coverage_times(&spans, animation_fps(&opts), widen, total);
    let (start, end) = (times[0], times[times.len() - 1] + 2. / animation_fps(&opts));
    let o = ExportOpts {
        output_path: sheet.to_string_lossy().into_owned(),
        format: ExportFormat::Mp4,
        stems: false,
        loudness_lufs: None,
        range: Some(ExportRange { start, end: end.min(total) }),
        contact_sheet: Some(times.iter().map(|t| t - start).collect()),
        ..opts
    };
    overlay_files_exist(&o)?;
    Ok(o)
}

/// A temp folder only this user can read, removed with everything in it on drop.
pub(crate) struct PrivateDir(PathBuf);
impl PrivateDir {
    pub(crate) fn new() -> Result<Self, String> {
        use std::os::unix::fs::DirBuilderExt;
        let p = std::env::temp_dir().join(format!("yusafcut-coverage-{}", uuid::Uuid::new_v4()));
        std::fs::DirBuilder::new().mode(0o700).create(&p).map_err(|e| e.to_string())?;
        Ok(Self(p))
    }
}
impl Drop for PrivateDir {
    fn drop(&mut self) {
        let _ = std::fs::remove_dir_all(&self.0);
    }
}

/// A private per-job folder (0700) holding an empty 0600 `coverage.png`:
/// frames of masked footage are never readable by other users, and both go
/// when the returned guards drop (the file first).
fn private_sheet() -> Result<(PrivateDir, CursorArtifact), String> {
    use std::os::unix::fs::OpenOptionsExt;
    let dir = PrivateDir::new()?;
    let sheet = dir.0.join("coverage.png");
    std::fs::OpenOptions::new().write(true).create_new(true).mode(0o600).open(&sheet).map_err(|e| e.to_string())?;
    Ok((dir, CursorArtifact(sheet)))
}

/// Runs as a cancellable job in the Jobs list.
#[tauri::command]
pub async fn mask_coverage_sheet(app: AppHandle, state: State<'_, AppState>, opts: ExportOpts, mask_id: String) -> Result<tauri::ipc::Response, String> {
    let job = state.jobs.create(&app, JobKind::Export, "Checking mask coverage").await;
    job.mark_running().await;
    // Every fallible step is inside `result`, so the job is always finished
    // (never left "running" when the temp folder or file cannot be made).
    let result = async {
        let (_dir, sheet) = private_sheet()?;
        let o = coverage_opts(with_probed_mask_sizes(&app, &opts).await, &mask_id, &sheet.0)?;
        let cursor = prepare_cursor(&o, &job).await?;
        let captions = prepare_captions(&o).await?;
        let overlay = prepare_overlays(&o)?;
        let files = OverlayPaths {
            cursor: cursor.as_ref().map(|f| f.0.as_path()),
            captions: captions.as_ref().map(|f| f.0.as_path()),
            ..overlay.paths()
        };
        let argv = build_reencode_argv_opts(&o, o.project.output_duration(), None, files)?;
        crate::commands::preview::run_ffmpeg(&app, argv, &job, |_| Ok(())).await?;
        tokio::fs::read(&sheet.0).await.map_err(|e| e.to_string())
    }
    .await;
    crate::commands::preview::finish_job(&job, &result).await;
    result.map(tauri::ipc::Response::new)
}

#[tauri::command]
pub async fn cancel_export(state: State<'_, AppState>) -> Result<(), String> {
    state.export.cancel(None).await;
    Ok(())
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use crate::edl::{
        AudioTrack, ExportPreset, Project, ProjectSettings, Segment, SourceMedia, Word,
    };
    use std::collections::HashMap;

    fn build_filter_for_test(project: &Project) -> String {
        let mut filter = String::new();
        use std::fmt::Write as _;
        let mut inputs: Vec<&String> = Vec::new();
        let mut specs: Vec<(usize, f64, f64)> = Vec::new();
        for seg in &project.segments {
            let media = project.media.get(&seg.media_id).unwrap();
            let idx = match inputs.iter().position(|p| **p == media.path) {
                Some(i) => i,
                None => {
                    inputs.push(&media.path);
                    inputs.len() - 1
                }
            };
            specs.push((idx, seg.source_in, seg.source_out));
        }
        let mut concat_inputs = String::new();
        for (i, (idx, sin, sout)) in specs.iter().enumerate() {
            let _ = writeln!(
                filter,
                "[{idx}:v]trim=start={sin}:end={sout},setpts=PTS-STARTPTS[v{i}];[{idx}:a]atrim=start={sin}:end={sout},asetpts=PTS-STARTPTS[a{i}];"
            );
            let _ = write!(concat_inputs, "[v{i}][a{i}]");
        }
        let _ = write!(
            filter,
            "{concat_inputs}concat=n={n}:v=1:a=1[outv][mainvox]",
            n = specs.len()
        );
        filter
    }

    fn fixture() -> Project {
        let mut media = HashMap::new();
        media.insert(
            "m".into(),
            SourceMedia {
                id: "m".into(),
                path: "/tmp/x.mp4".into(),
                duration: 10.0,
                fps: 30.0,
                width: 1920,
                height: 1080,
                audio_sample_rate: 48000,
                sha256: "deadbeef".into(), pending_camera: None,
            },
        );
        Project {
            version: 1,
            id: "p".into(),
            name: "p".into(),
            created_at: "x".into(),
            updated_at: "x".into(),
            media,
            segments: vec![
                Segment {
                    id: "s1".into(),
                    media_id: "m".into(),
                    words: vec![Word {
                        id: "w".into(),
                        text: "x".into(),
                        start: 0.0,
                        end: 1.0,
                        confidence: 1.0,
                        speaker: None,
                    }],
                    source_in: 0.0,
                    source_out: 2.0,
                    timing: Default::default(),
                },
                Segment {
                    id: "s2".into(),
                    media_id: "m".into(),
                    words: vec![],
                    source_in: 5.0,
                    source_out: 7.0,
                    timing: Default::default(),
                },
            ],
            settings: ProjectSettings {
                export_preset: ExportPreset::Youtube1080p,
                padding_ms: 80,
            },
            chapters: vec![],
            audio_tracks: vec![],
            scene: None,
            zoom_regions: None,
            cursor: None,
            captions: None,
            annotations: None,
            keystrokes: None, overlays: None, masks: None,
            original_transcripts: None,
        }
    }

    #[test]
    fn exported_clip_lengths_sum_to_the_edl_duration_even_with_padding() {
        // padding_ms is 80 in the fixture; the exported clips must still total
        // exactly the timeline length, or captions/chapters drift per segment.
        let p = fixture();
        let edl_total: f64 = p.segments.iter().map(|s| s.source_out - s.source_in).sum();
        let clips_total: f64 = p
            .segments
            .iter()
            .map(|s| {
                let (a, b) = super::segment_clip_bounds(s);
                b - a
            })
            .sum();
        assert!((clips_total - edl_total).abs() < 1e-9, "{clips_total} vs {edl_total}");
    }

    #[test]
    fn builds_two_segment_concat() {
        let filter = build_filter_for_test(&fixture());
        assert!(filter.contains("[0:v]trim=start=0:end=2"));
        assert!(filter.contains("[0:v]trim=start=5:end=7"));
        assert!(filter.contains("concat=n=2:v=1:a=1[outv][mainvox]"));
    }

    #[test]
    fn ffmetadata_emits_one_block_per_chapter_with_ms_timebase() {
        use crate::edl::Chapter;
        let chapters = vec![
            Chapter { id: "1".into(), output_time: 0.0, title: "Intro".into() },
            Chapter { id: "2".into(), output_time: 12.5, title: "Demo".into() },
        ];
        let text = super::build_chapter_ffmetadata(&chapters, 30.0);
        assert!(text.starts_with(";FFMETADATA1\n"));
        assert_eq!(text.matches("[CHAPTER]").count(), 2);
        assert!(text.contains("TIMEBASE=1/1000"));
        assert!(text.contains("START=0\nEND=12500"));
        assert!(text.contains("START=12500\nEND=30000"));
        assert!(text.contains("title=Intro"));
        assert!(text.contains("title=Demo"));
    }

    #[test]
    fn chapter_metadata_file_is_removed_on_any_early_return() {
        let chapters = vec![crate::edl::Chapter { id: "c".into(), title: "One".into(), output_time: 0.0 }];
        let rt = tokio::runtime::Runtime::new().unwrap();
        // Same shape as full_reencode: own the guard, then bail with `?` before ffmpeg runs.
        let fail = |meta: Option<super::CursorArtifact>| -> Result<(), String> {
            let _meta = meta;
            Err::<(), String>("cancelled".into())?;
            Ok(())
        };
        let meta = rt.block_on(super::build_chapter_metadata_file(&chapters, 10.0)).unwrap();
        let path = meta.0.clone();
        assert!(path.exists());
        assert!(fail(Some(meta)).is_err());
        assert!(!path.exists(), "an error before ffmpeg exits must not leak ffmeta.txt");
        assert!(rt.block_on(super::build_chapter_metadata_file(&[], 10.0)).is_none());
    }

    #[test]
    fn ffmetadata_escapes_special_characters_in_titles() {
        use crate::edl::Chapter;
        let chapters = vec![Chapter {
            id: "1".into(),
            output_time: 0.0,
            title: "a=b;c#d\\e".into(),
        }];
        let text = super::build_chapter_ffmetadata(&chapters, 10.0);
        assert!(text.contains("title=a\\=b\\;c\\#d\\\\e"));
    }

    #[test]
    fn append_music_bed_emits_volume_and_amix_for_two_tracks() {
        let mut p = fixture();
        p.media.insert(
            "music".into(),
            SourceMedia {
                id: "music".into(),
                path: "/tmp/song.mp3".into(),
                duration: 200.0,
                fps: 0.0,
                width: 0,
                height: 0,
                audio_sample_rate: 44100,
                sha256: "music".into(), pending_camera: None,
            },
        );
        p.audio_tracks.push(AudioTrack {
            id: "t1".into(),
            media_id: "music".into(),
            gain_db: -12.0,
            offset_sec: 0.0,
            ducks: true,
            ..Default::default()
        });
        p.audio_tracks.push(AudioTrack {
            id: "t2".into(),
            media_id: "music".into(),
            gain_db: -20.0,
            offset_sec: 5.0,
            ducks: false,
            ..Default::default()
        });

        let mut filter = build_filter_for_test(&p);
        let mut inputs: Vec<&String> = p
            .segments
            .iter()
            .map(|s| &p.media.get(&s.media_id).unwrap().path)
            .collect();
        super::append_music_bed_filters(&mut filter, &mut inputs, "mainvox", &p, 30.0, None).unwrap();
        assert!(filter.contains("asplit=2[vox_main][vox_side]"));
        assert!(filter.contains("volume=-12dB"));
        assert!(filter.contains("volume=-20dB"));
        assert!(filter.contains("adelay=5000|5000"));
        assert!(filter.contains("sidechaincompress="));
        assert!(filter.contains("amix=inputs=2:duration=longest"));
        assert!(filter.contains("[outa]"));
    }

    #[test]
    fn append_music_bed_with_single_track_skips_inner_amix() {
        let mut p = fixture();
        p.media.insert(
            "music".into(),
            SourceMedia {
                id: "music".into(),
                path: "/tmp/song.mp3".into(),
                duration: 200.0,
                fps: 0.0,
                width: 0,
                height: 0,
                audio_sample_rate: 44100,
                sha256: "music".into(), pending_camera: None,
            },
        );
        p.audio_tracks.push(AudioTrack {
            id: "t1".into(),
            media_id: "music".into(),
            gain_db: -6.0,
            offset_sec: 0.0,
            ducks: false,
            ..Default::default()
        });
        let mut filter = build_filter_for_test(&p);
        let mut inputs: Vec<&String> = p
            .segments
            .iter()
            .map(|s| &p.media.get(&s.media_id).unwrap().path)
            .collect();
        super::append_music_bed_filters(&mut filter, &mut inputs, "mainvox", &p, 30.0, None).unwrap();
        // Only one inner track — no music_mix label needed.
        assert!(!filter.contains("music_mix"));
        // Final mix is voice + the single trk_raw_0 (no ducking).
        assert!(filter.contains("[vox_main][trk_raw_0]amix=inputs=2"));
    }

    // -----------------------------------------------------------------------
    // End to end with the real ffmpeg: generate a clip, export it, inspect it.
    // -----------------------------------------------------------------------

    use super::{build_reencode_argv, scene_for, zoom_for, ExportOpts};
    use crate::scene::{ResolvedBackground, SceneRender};
    use std::path::{Path, PathBuf};
    use std::process::Command;

    fn binary(name: &str) -> Option<PathBuf> {
        let p = Path::new(env!("CARGO_MANIFEST_DIR")).join(format!("binaries/{name}-aarch64-apple-darwin"));
        let big = std::fs::metadata(&p).map(|m| m.len() > 1_000_000).unwrap_or(false);
        let runs = big
            && Command::new(&p)
                .arg("-version")
                .output()
                .map(|o| o.status.success())
                .unwrap_or(false);
        runs.then_some(p)
    }

    struct Tools {
        ffmpeg: PathBuf,
        ffprobe: PathBuf,
        dir: PathBuf,
    }

    impl Drop for Tools {
        fn drop(&mut self) {
            let _ = std::fs::remove_dir_all(&self.dir);
        }
    }

    fn tools() -> Option<Tools> {
        let (ffmpeg, ffprobe) = (binary("ffmpeg")?, binary("ffprobe")?);
        let dir = std::env::temp_dir().join(format!("yusafcut-export-{}", uuid::Uuid::new_v4()));
        std::fs::create_dir_all(&dir).ok()?;
        Some(Tools { ffmpeg, ffprobe, dir })
    }

    /// A 5 s, 1280x720 clip: solid red picture with a tone.
    fn make_source(t: &Tools) -> PathBuf {
        let path = t.dir.join("source.mp4");
        let out = Command::new(&t.ffmpeg)
            .args(["-v", "error", "-y"])
            .args(["-f", "lavfi", "-i", "color=c=red:s=1280x720:r=30:d=5"])
            .args(["-f", "lavfi", "-i", "sine=frequency=440:duration=5"])
            .args(["-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest"])
            .arg(&path)
            .output()
            .unwrap();
        assert!(out.status.success(), "{}", String::from_utf8_lossy(&out.stderr));
        path
    }

    fn project_for(source: &Path) -> Project {
        let mut p = fixture();
        let m = p.media.get_mut("m").unwrap();
        m.path = source.to_string_lossy().into_owned();
        m.duration = 5.0;
        m.width = 1280;
        m.height = 720;
        // Two kept pieces: 0-1.5 s and 3-5 s, 3.5 s in total.
        p.segments[0].source_in = 0.0;
        p.segments[0].source_out = 1.5;
        p.segments[1].source_in = 3.0;
        p.segments[1].source_out = 5.0;
        p
    }

    fn opts_for(project: Project, out: &Path, scene: Option<SceneRender>) -> ExportOpts {
        ExportOpts {
            project,
            output_path: out.to_string_lossy().into_owned(),
            preset: ExportPreset::Youtube1080p,
            video_bitrate_kbps: Some(4000),
            audio_bitrate_kbps: None,
            width: None,
            height: None,
            fps: None,
            codec: None,
            force_reencode: false,
            scene,
            zoom_regions: Vec::new(),
            draw_cursor: false,
            format: super::ExportFormat::Mp4,
            range: None,
            stems: false,
            loudness_lufs: None,
            captions: None,
            contact_sheet: None,
        }
    }

    fn run_export_argv(t: &Tools, opts: &ExportOpts) {
        let total: f64 = opts.project.output_duration();
        let argv = build_reencode_argv(opts, total, None, None).expect("argv");
        // Software decode: the test machine may not expose VideoToolbox to a child process.
        let argv: Vec<String> = argv.into_iter().filter(|a| a != "-hwaccel" && a != "videotoolbox").collect();
        let out = Command::new(&t.ffmpeg).args(argv).output().unwrap();
        assert!(out.status.success(), "ffmpeg: {}", String::from_utf8_lossy(&out.stderr));
    }

    fn probe(t: &Tools, file: &Path, entries: &str) -> String {
        let out = Command::new(&t.ffprobe)
            .args(["-v", "error", "-select_streams", "v:0", "-show_entries", entries])
            .args(["-of", "default=nw=1:nk=1"])
            .arg(file)
            .output()
            .unwrap();
        String::from_utf8_lossy(&out.stdout).trim().replace('\n', " ")
    }

    fn frame_rgb(t: &Tools, file: &Path, at: f64, w: u32, h: u32) -> Vec<u8> {
        let out = Command::new(&t.ffmpeg)
            .args(["-v", "error", "-ss", &at.to_string(), "-i"])
            .arg(file)
            .args(["-frames:v", "1", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"])
            .output()
            .unwrap();
        assert!(out.status.success());
        assert_eq!(out.stdout.len(), (w * h * 3) as usize);
        out.stdout
    }

    fn rgb_at(frame: &[u8], w: u32, x: u32, y: u32) -> [i32; 3] {
        let i = ((y * w + x) * 3) as usize;
        [frame[i] as i32, frame[i + 1] as i32, frame[i + 2] as i32]
    }

    fn close(a: [i32; 3], b: [i32; 3], tol: i32) -> bool {
        a.iter().zip(b).all(|(x, y)| (x - y).abs() <= tol)
    }

    fn blue_scene() -> SceneRender {
        SceneRender {
            canvas_w: 1280,
            canvas_h: 720,
            content_x: 128,
            content_y: 72,
            content_w: 1024,
            content_h: 576,
            radius_px: 28.0,
            shadow_sigma_px: 0.0,
            shadow_opacity: 0.0,
            shadow_offset_y: 0.0,
            background: ResolvedBackground::Solid { color: "#0000ff".into() },
            crop: None,
            frame: None,
        }
    }

    #[test]
    fn export_with_a_scene_keeps_the_edl_duration_and_frames_the_picture() {
        let Some(t) = tools() else {
            eprintln!("skipping: bundled ffmpeg/ffprobe not present");
            return;
        };
        let source = make_source(&t);
        let out = t.dir.join("scene.mp4");
        run_export_argv(&t, &opts_for(project_for(&source), &out, Some(blue_scene())));

        assert_eq!(probe(&t, &out, "stream=width,height"), "1280 720");
        let duration: f64 = probe(&t, &out, "format=duration").parse().unwrap_or(0.0);
        // probe() asks for the video stream; fall back to the container duration below.
        let d = if duration > 0.0 {
            duration
        } else {
            let o = Command::new(&t.ffprobe)
                .args(["-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1"])
                .arg(&out)
                .output()
                .unwrap();
            String::from_utf8_lossy(&o.stdout).trim().parse().unwrap()
        };
        assert!((d - 3.5).abs() < 0.2, "duration {d} should be about 3.5 s");

        let f = frame_rgb(&t, &out, 1.0, 1280, 720);
        assert!(close(rgb_at(&f, 1280, 10, 10), [0, 0, 255], 14), "background {:?}", rgb_at(&f, 1280, 10, 10));
        assert!(close(rgb_at(&f, 1280, 640, 360), [255, 0, 0], 16), "video {:?}", rgb_at(&f, 1280, 640, 360));
        assert!(close(rgb_at(&f, 1280, 130, 74), [0, 0, 255], 16), "rounded corner {:?}", rgb_at(&f, 1280, 130, 74));
    }

    #[test]
    fn export_without_a_scene_is_unchanged() {
        let Some(t) = tools() else {
            return;
        };
        let source = make_source(&t);
        let out = t.dir.join("plain.mp4");
        let opts = opts_for(project_for(&source), &out, None);
        run_export_argv(&t, &opts);
        assert_eq!(probe(&t, &out, "stream=width,height"), "1280 720");
        let f = frame_rgb(&t, &out, 1.0, 1280, 720);
        // No frame: the corner is the video itself.
        assert!(close(rgb_at(&f, 1280, 2, 2), [255, 0, 0], 16));
        let argv = build_reencode_argv(&opts, 3.5, None, None).unwrap();
        assert!(!argv.join(" ").contains("catv"));
    }

    #[test]
    fn export_into_a_portrait_canvas_letterboxes_the_picture() {
        let Some(t) = tools() else {
            return;
        };
        let source = make_source(&t);
        let out = t.dir.join("portrait.mp4");
        let scene = SceneRender {
            canvas_w: 720,
            canvas_h: 1280,
            content_x: 36,
            content_y: 438,
            content_w: 648,
            content_h: 404,
            radius_px: 20.0,
            shadow_sigma_px: 10.0,
            shadow_opacity: 0.5,
            shadow_offset_y: 8.0,
            background: ResolvedBackground::Gradient {
                from: "#000000".into(),
                to: "#00ff00".into(),
                x0: 0.0,
                y0: 0.0,
                x1: 0.0,
                y1: 1280.0,
            },
            crop: None,
            frame: None,
        };
        run_export_argv(&t, &opts_for(project_for(&source), &out, Some(scene)));
        assert_eq!(probe(&t, &out, "stream=width,height"), "720 1280");
        let f = frame_rgb(&t, &out, 1.0, 720, 1280);
        assert!(close(rgb_at(&f, 720, 360, 640), [255, 0, 0], 16));
        // Top of the canvas is the dark end of the gradient, bottom the green end.
        assert!(rgb_at(&f, 720, 360, 6)[1] < 40);
        assert!(rgb_at(&f, 720, 360, 1273)[1] > 215);
    }

    #[test]
    fn a_scene_with_an_image_background_loops_the_still_for_the_whole_video() {
        let Some(t) = tools() else {
            return;
        };
        let source = make_source(&t);
        // A 64x64 solid green PNG as the background.
        let bg = t.dir.join("bg.png");
        let made = Command::new(&t.ffmpeg)
            .args(["-v", "error", "-y", "-f", "lavfi", "-i", "color=c=0x00ff00:s=64x64", "-frames:v", "1"])
            .arg(&bg)
            .output()
            .unwrap();
        assert!(made.status.success());
        let mut scene = blue_scene();
        scene.background = ResolvedBackground::Image { path: bg.to_string_lossy().into_owned() };
        let out = t.dir.join("image.mp4");
        let opts = opts_for(project_for(&source), &out, Some(scene));
        let argv = build_reencode_argv(&opts, 3.5, None, None).unwrap();
        let joined = argv.join(" ");
        assert!(joined.contains("-loop 1 -i"), "image input must loop: {joined}");
        run_export_argv(&t, &opts);
        let f = frame_rgb(&t, &out, 3.0, 1280, 720);
        assert!(close(rgb_at(&f, 1280, 10, 10), [0, 255, 0], 16), "bg {:?}", rgb_at(&f, 1280, 10, 10));
    }

    #[test]
    fn a_scene_is_ignored_for_audio_only_exports() {
        let mut opts = opts_for(fixture(), Path::new("/tmp/o.m4a"), Some(blue_scene()));
        opts.preset = ExportPreset::PodcastAudio;
        assert!(scene_for(&opts).is_none());
        opts.preset = ExportPreset::Youtube1080p;
        assert!(scene_for(&opts).is_some());
    }

    #[test]
    fn a_scene_never_uses_the_smart_cut_path() {
        // scene_for gates eligibility in run_export; without one the clean fixture qualifies.
        let with = opts_for(fixture(), Path::new("/tmp/o.mp4"), Some(blue_scene()));
        assert!(scene_for(&with).is_some());
    }

    // -----------------------------------------------------------------------
    // Zoom regions, end to end with the real ffmpeg.
    // -----------------------------------------------------------------------

    use crate::zoom::ZoomRegion;

    /// A 5 s, 1280x720 clip: left half red, right half blue, with a tone.
    fn make_split_source(t: &Tools) -> PathBuf {
        let path = t.dir.join("split.mp4");
        let out = Command::new(&t.ffmpeg)
            .args(["-v", "error", "-y"])
            .args(["-f", "lavfi", "-i", "color=c=red:s=1280x720:r=30:d=5,drawbox=x=640:y=0:w=640:h=720:color=blue:t=fill"])
            .args(["-f", "lavfi", "-i", "sine=frequency=440:duration=5"])
            .args(["-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest"])
            .arg(&path)
            .output()
            .unwrap();
        assert!(out.status.success(), "{}", String::from_utf8_lossy(&out.stderr));
        path
    }

    fn one_segment(source: &Path) -> Project {
        let mut p = project_for(source);
        // Keep 0-5 s as a single piece so output time equals source time.
        p.segments.truncate(1);
        p.segments[0].source_in = 0.0;
        p.segments[0].source_out = 5.0;
        p
    }

    fn zoom_region(start: f64, end: f64, scale: f64, fx: f64, fy: f64, ease_ms: f64) -> ZoomRegion {
        ZoomRegion {
            id: "z".into(),
            start,
            end,
            scale,
            focus_x: fx,
            focus_y: fy,
            ease_ms,
            follow: false,
            focus_keys: vec![],
        }
    }

    fn red(p: [i32; 3]) -> bool {
        p[0] > 200 && p[2] < 70
    }
    fn blue(p: [i32; 3]) -> bool {
        p[2] > 200 && p[0] < 70
    }

    #[test]
    fn cursor_is_drawn_before_zoom_then_scene_and_temp_files_are_removed() {
        let Some(t)=tools() else {return};
        let source=make_source(&t);
        let mut p=one_segment(&source);p.segments[0].source_out=2.;
        let mut opts=opts_for(p,&t.dir.join("cursor.mp4"),Some(blue_scene()));
        opts.zoom_regions=vec![zoom_region(0.,2.,2.,0.5,0.5,0.)];
        opts.draw_cursor=true;
        opts.project.cursor=Some(serde_json::json!({
            "style":{"shape":"dot","size":96,"color":"#00ff00","smoothing":0,"clickEffect":"none"},
            "tracks":{"m":{"events":[{"type":"move","t":0,"x":0.5,"y":0.5}]}}
        }));
        // project_for uses a stable media id; match it rather than assume it.
        let id=opts.project.segments[0].media_id.clone();
        let tracks=opts.project.cursor.as_mut().unwrap()["tracks"].as_object_mut().unwrap();
        let track=tracks.remove("m").unwrap();tracks.insert(id,track);
        let config:crate::cursor_export::CursorConfig=serde_json::from_value(opts.project.cursor.clone().unwrap()).unwrap();
        let activity=super::CursorArtifact(t.dir.join("activity.ass"));
        let mut file=std::fs::File::create(&activity.0).unwrap();
        let (w,h)=super::picture_size(&opts).unwrap();
        crate::cursor_export::write_ass(&mut file,&config,&opts.project,w,h,30.,||false).unwrap();
        drop(file);
        assert!(build_reencode_argv(&opts,2.,None,None).is_err());
        let argv=build_reencode_argv(&opts,2.,None,Some(&activity.0)).unwrap();
        let graph=&argv[argv.iter().position(|a|a=="-filter_complex").unwrap()+1];
        assert!(graph.contains("[catv]fps=30[animatedv]"));
        assert!(graph.contains("[animatedv]ass="));
        assert!(graph.contains("[cursorv]"));
        let argv:Vec<_>=argv.into_iter().filter(|a|a!="-hwaccel"&&a!="videotoolbox").collect();
        let output=Command::new(&t.ffmpeg).args(argv).output().unwrap();
        assert!(output.status.success(),"{}",String::from_utf8_lossy(&output.stderr));
        let frame=frame_rgb(&t,Path::new(&opts.output_path),1.,1280,720);
        assert!(close(rgb_at(&frame,1280,640,360),[0,255,0],35),"cursor pixel {:?}",rgb_at(&frame,1280,640,360));
        assert!(close(rgb_at(&frame,1280,654,360),[0,255,0],40),"cursor must grow with zoom before scene framing");
        assert!(blue(rgb_at(&frame,1280,10,10)),"scene must remain outside picture");
        let path=activity.0.clone();drop(activity);assert!(!path.exists());
    }

    // ---- Burned-in captions (real ffmpeg + libass) ----------------------------

    fn caption_export(spec: &str) -> crate::captions_export::CaptionExport {
        serde_json::from_str(spec).unwrap()
    }

    /// The real argv with the captions ASS prepared the way `prepare_captions` does.
    fn run_with_captions(t: &Tools, opts: &ExportOpts, total: f64) {
        let (w, h) = super::final_size(opts).unwrap();
        let ass = t.dir.join(format!("caps-{}.ass", uuid::Uuid::new_v4()));
        let mut f = std::fs::File::create(&ass).unwrap();
        crate::captions_export::write_ass(&mut f, opts.captions.as_ref().unwrap(), w, h).unwrap();
        drop(f);
        let argv = super::build_reencode_argv_with(opts, total, None, None, Some(&ass)).unwrap();
        let argv: Vec<String> = argv.into_iter().filter(|a| a != "-hwaccel" && a != "videotoolbox").collect();
        let out = Command::new(&t.ffmpeg).args(argv).output().unwrap();
        assert!(out.status.success(), "ffmpeg: {}", String::from_utf8_lossy(&out.stderr));
    }

    /// Pixels matching `pred` in the box x0..x1, y0..y1 of a 1280x720 frame.
    fn count_in(frame: &[u8], x: (u32, u32), y: (u32, u32), pred: impl Fn([i32; 3]) -> bool) -> usize {
        let mut n = 0;
        for yy in y.0..y.1 {
            for xx in x.0..x.1 {
                if pred(rgb_at(frame, 1280, xx, yy)) {
                    n += 1;
                }
            }
        }
        n
    }
    fn green(p: [i32; 3]) -> bool {
        p[1] > 200 && p[0] < 80 && p[2] < 80
    }
    fn whiteish(p: [i32; 3]) -> bool {
        p.iter().all(|c| *c > 220)
    }
    fn captioned(t: &Tools, name: &str, spec: &str, scene: Option<SceneRender>) -> PathBuf {
        let source = make_source(t);
        let mut p = one_segment(&source);
        p.segments[0].source_out = 2.;
        let out = t.dir.join(name);
        let mut opts = opts_for(p, &out, scene);
        opts.captions = Some(caption_export(spec));
        run_with_captions(t, &opts, 2.);
        out
    }

    const HELLO: &str = r#"{"start":0.5,"end":1.5,"lines":[[{"t":"Hello","s":0.5,"e":1.5}]]}"#;

    #[test]
    fn burned_caption_appears_at_the_right_time_and_position() {
        let Some(t) = tools() else { return };
        for position in ["bottom", "top", "middle"] {
            let spec = format!(r##"{{"style":{{"position":"{position}","boxColor":"#00ff00","boxOpacity":1,"size":60}},"cues":[{HELLO}]}}"##);
            let out = captioned(&t, &format!("{position}.mp4"), &spec, None);
            let at = |s: f64| frame_rgb(&t, &out, s, 1280, 720);
            let (top, mid, bottom) = ((0, 240), (240, 480), (480, 720));
            let band = |f: &[u8], y: (u32, u32)| count_in(f, (0, 1280), y, green);
            let on = at(1.0);
            let (gt, gm, gb) = (band(&on, top), band(&on, mid), band(&on, bottom));
            match position {
                "top" => assert!(gt > 400 && gm == 0 && gb == 0, "top {gt} {gm} {gb}"),
                "middle" => assert!(gm > 400 && gt == 0 && gb == 0, "middle {gt} {gm} {gb}"),
                _ => assert!(gb > 400 && gt == 0 && gm == 0, "bottom {gt} {gm} {gb}"),
            }
            for s in [0.2, 1.8] {
                let f = at(s);
                assert_eq!(band(&f, (0, 720)), 0, "{position}: no caption at {s}s");
            }
        }
    }

    #[test]
    fn spoken_word_highlight_moves_from_word_to_word() {
        let Some(t) = tools() else { return };
        let spec = r##"{"style":{"box":false,"outline":0,"shadow":0,"size":100,"color":"#ffffff","highlight":true,"highlightColor":"#0000ff"},
            "cues":[{"start":0.5,"end":1.5,"lines":[[{"t":"WWW","s":0.5,"e":1.0},{"t":"WWW","s":1.0,"e":1.5}]]}]}"##;
        let out = captioned(&t, "karaoke.mp4", spec, None);
        let side = |f: &[u8], right: bool, pred: fn([i32; 3]) -> bool| {
            let x = if right { (640, 1280) } else { (0, 640) };
            count_in(f, x, (480, 720), pred)
        };
        let first = frame_rgb(&t, &out, 0.75, 1280, 720);
        assert!(side(&first, false, blue) > 300, "first word blue");
        assert_eq!(side(&first, true, blue), 0, "second word not blue yet");
        assert!(side(&first, true, whiteish) > 300, "second word plain");
        let second = frame_rgb(&t, &out, 1.25, 1280, 720);
        assert!(side(&second, true, blue) > 300, "second word blue");
        assert_eq!(side(&second, false, blue), 0, "first word back to plain");
        assert!(side(&second, false, whiteish) > 300, "first word plain");
    }

    #[test]
    fn captions_are_drawn_over_the_scene_and_braces_are_literal() {
        let Some(t) = tools() else { return };
        // The picture ends at y=648; a bottom caption box reaches below it, onto the blue scene.
        let spec = format!(r##"{{"style":{{"boxColor":"#00ff00","boxOpacity":1,"size":60}},"cues":[{HELLO}]}}"##);
        let out = captioned(&t, "scene.mp4", &spec, Some(blue_scene()));
        let f = frame_rgb(&t, &out, 1.0, 1280, 720);
        assert!(count_in(&f, (0, 1280), (652, 720), green) > 300, "caption over scene background");
        assert!(blue(rgb_at(&f, 1280, 10, 10)), "scene still frames the picture");
        // Literal braces must render; as an unescaped override block they would vanish.
        let braces = r##"{"style":{"box":false,"outline":0,"size":100},"cues":[{"start":0.5,"end":1.5,"lines":[[{"t":"{WW}","s":0.5,"e":1.5}]]}]}"##;
        let out = captioned(&t, "braces.mp4", braces, None);
        let f = frame_rgb(&t, &out, 1.0, 1280, 720);
        assert!(count_in(&f, (0, 1280), (480, 720), whiteish) > 300, "braces and text drawn");
    }

    /// One 1280x720 frame of grey with `ass_file` drawn on it, through the same graph stage.
    fn render_ass(t: &Tools, ass: &Path) -> Vec<u8> {
        let graph = crate::captions_export::filter_stage("0:v", ass, "o", false);
        let out = Command::new(&t.ffmpeg)
            .args(["-v", "error", "-f", "lavfi", "-i", "color=c=0x303030:s=1280x720:r=1:d=1"])
            .args(["-filter_complex", &graph, "-map", "[o]", "-frames:v", "1", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"])
            .output()
            .unwrap();
        assert!(out.status.success(), "ffmpeg: {}", String::from_utf8_lossy(&out.stderr));
        out.stdout
    }

    fn script_for(word: &str) -> String {
        let spec = format!(
            r#"{{"style":{{"box":false,"outline":0,"size":100,"font":"Arial"}},"cues":[{{"start":0,"end":1,"lines":[[{{"t":"{word}","s":0,"e":1}}]]}}]}}"#
        );
        let mut buf = Vec::new();
        crate::captions_export::write_ass(&mut buf, &caption_export(&spec), 1280, 720).unwrap();
        String::from_utf8(buf).unwrap()
    }

    #[test]
    fn han_kana_and_hangul_draw_real_glyphs_not_empty_boxes() {
        let Some(t) = tools() else { return };
        let ink = |ass: &str, name: &str| -> usize {
            let f = t.dir.join(name);
            std::fs::write(&f, ass).unwrap();
            let frame = render_ass(&t, &f);
            count_in(&frame, (0, 1280), (480, 720), whiteish)
        };
        for (i, word) in ["你好吗", "ありがとう", "한국어"].iter().enumerate() {
            let with_fonts = script_for(word);
            // The same script without the font switches: what the exporter drew before (tofu boxes).
            let without: String = with_fonts
                .lines()
                .map(|l| {
                    if !l.starts_with("Dialogue:") {
                        return l.to_string();
                    }
                    let mut o = l.to_string();
                    for tag in ["{\\fnHiragino Sans GB}", "{\\fnApple SD Gothic Neo}", "{\\fnArial}"] {
                        o = o.replace(tag, "");
                    }
                    o
                })
                .collect::<Vec<_>>()
                .join("\n");
            assert!(with_fonts.contains("{\\fn"), "{word}: font switch emitted");
            let (a, b) = (ink(&with_fonts, &format!("a{i}.ass")), ink(&without, &format!("b{i}.ass")));
            assert!(a > 400, "{word}: glyphs drawn ({a})");
            // Real glyphs have a different (much more detailed) shape than the .notdef rectangle.
            // Hangul already falls back correctly on this libass; the switch is kept for safety.
            if i < 2 {
                assert!(a != b, "{word}: same ink with and without the font switch ({a} vs {b})");
            }
        }
    }

    #[test]
    fn filter_path_with_space_colon_quote_comma_still_reaches_libass() {
        let Some(t) = tools() else { return };
        let dir = t.dir.join("sp ace:co'lon,[x];y");
        std::fs::create_dir_all(&dir).unwrap();
        let f = dir.join("c a:p'.ass");
        std::fs::write(&f, script_for("Hello")).unwrap();
        let frame = render_ass(&t, &f);
        assert!(count_in(&frame, (0, 1280), (480, 720), whiteish) > 300, "caption drawn from an awkward path");
    }

    #[test]
    fn alpha_option_is_accepted_by_the_ass_filter() {
        let Some(t) = tools() else { return };
        let f = t.dir.join("alpha.ass");
        std::fs::write(&f, script_for("Hello")).unwrap();
        let graph = crate::captions_export::filter_stage("0:v", &f, "o", true);
        let out = Command::new(&t.ffmpeg)
            .args(["-v", "error", "-f", "lavfi", "-i", "color=c=0x303030:s=640x360:r=1:d=1,format=yuva444p"])
            .args(["-filter_complex", &graph, "-map", "[o]", "-frames:v", "1", "-f", "null", "-"])
            .output()
            .unwrap();
        assert!(out.status.success(), "{}", String::from_utf8_lossy(&out.stderr));
    }

    #[test]
    fn captions_force_a_re_encode_and_need_their_prepared_file() {
        let opts_with = |spec: &str| {
            let mut o = opts_for(fixture(), Path::new("/tmp/o.mp4"), None);
            o.captions = Some(caption_export(spec));
            o
        };
        let o = opts_with(&format!(r#"{{"cues":[{HELLO}]}}"#));
        assert!(super::captions_for(&o).is_some());
        assert!(super::build_reencode_argv_with(&o, 4., None, None, None).is_err());
        let a = Path::new("/t/c:a'b.ass");
        let argv = super::build_reencode_argv_with(&o, 4., None, None, Some(a)).unwrap();
        let graph = &argv[argv.iter().position(|x| x == "-filter_complex").unwrap() + 1];
        assert!(graph.contains("[catv]ass=filename=/t/c\\\\:a\\\\\\'b.ass[capv]"), "{graph}");
        assert!(graph.contains("[capv]") && argv.iter().any(|x| x == "[capv]"));
        // An empty cue list draws nothing and leaves the default argv untouched.
        let empty = opts_with(r#"{"cues":[]}"#);
        assert!(super::captions_for(&empty).is_none());
        assert_eq!(
            super::build_reencode_argv_with(&empty, 4., None, None, None).unwrap(),
            super::build_reencode_argv(&opts_for(fixture(), Path::new("/tmp/o.mp4"), None), 4., None, None).unwrap()
        );
    }

    #[test]
    fn annotations_stay_fixed_or_follow_zoom_and_keystrokes_draw_on_the_frame() {
        let Some(t)=tools() else {return};
        let source=make_split_source(&t);
        let out=t.dir.join("annotations.mp4");
        let mut opts=opts_for(one_segment(&source),&out,Some(blue_scene()));
        opts.zoom_regions=vec![zoom_region(1.0,4.0,2.0,0.75,0.5,0.0)];
        let id=opts.project.segments[0].media_id.clone();
        opts.project.annotations=Some(serde_json::json!([
            // Fixed: canvas-relative, unaffected by zoom.
            {"kind":"box","start":0,"end":5,"x":0.8,"y":0.45,"w":0.05,"h":0.1,"color":"#ffffff","filled":true},
            // Follows zoom: picture-relative, magnified with it.
            {"kind":"box","start":0,"end":5,"x":0.6,"y":0.45,"w":0.1,"h":0.1,"color":"#00ff00","filled":true,"followZoom":true}
        ]));
        opts.project.cursor=Some(serde_json::json!({"style":{"show":false},"tracks":{id:{"events":[{"type":"key","t":1.5,"mods":["cmd"]}]}}}));
        opts.project.keystrokes=Some(serde_json::json!({"enabled":true}));
        assert!(build_reencode_argv(&opts,5.,None,None).is_err(),"overlay files are required");
        let files=super::prepare_overlays(&opts).unwrap();
        let (follow,fixed,keys)=(files.follow.as_ref().unwrap().0.clone(),files.fixed.as_ref().unwrap().0.clone(),files.keys.as_ref().unwrap().0.clone());
        let argv=super::build_reencode_argv_opts(&opts,5.,None,files.paths()).unwrap();
        let graph=&argv[argv.iter().position(|a|a=="-filter_complex").unwrap()+1];
        assert!(graph.contains("[animatedv]ass=") && graph.contains("[outv]fps=30[framev];[framev]ass="),"{graph}");
        // Layer order: fixed annotations before key caps on the frame; no alpha by default.
        let frame_stage=&graph[graph.find("[outv]fps=30[framev]").unwrap()..];
        let name=|p:&std::path::Path|p.file_name().unwrap().to_string_lossy().into_owned();
        assert!(frame_stage.find(&name(&fixed)).unwrap()<frame_stage.find(&name(&keys)).unwrap());
        assert!(!graph.contains("alpha=1"));
        let argv:Vec<_>=argv.into_iter().filter(|a|a!="-hwaccel"&&a!="videotoolbox").collect();
        let o=Command::new(&t.ffmpeg).args(argv).output().unwrap();
        assert!(o.status.success(),"{}",String::from_utf8_lossy(&o.stderr));
        let before=frame_rgb(&t,&out,0.5,1280,720);
        let zoomed=frame_rgb(&t,&out,2.0,1280,720);
        for f in [&before,&zoomed] {
            assert!(close(rgb_at(f,1280,1056,360),[255,255,255],30),"fixed box stays put {:?}",rgb_at(f,1280,1056,360));
        }
        // Unzoomed: picture x 0.65 -> 128 + 0.65*1024 = 794. Zoomed 2x on (0.75,0.5): -> 0.3 -> 435.
        assert!(close(rgb_at(&before,1280,794,360),[0,255,0],40),"{:?}",rgb_at(&before,1280,794,360));
        assert!(close(rgb_at(&zoomed,1280,435,360),[0,255,0],40),"follow box zooms {:?}",rgb_at(&zoomed,1280,435,360));
        assert!(!close(rgb_at(&zoomed,1280,794,360),[0,255,0],80));
        // Keystroke cap: a dark box over the blue background at the bottom, only while shown.
        assert!(blue(rgb_at(&before,1280,640,683)));
        let cap=rgb_at(&zoomed,1280,640,683);
        assert!(cap[2]<130 && !blue(cap),"keystroke box {cap:?}");
        drop(files);assert!(!follow.exists()&&!fixed.exists()&&!keys.exists());
    }

    #[test]
    fn zoom_lands_on_the_focus_at_the_plateau_and_leaves_other_times_alone() {
        let Some(t) = tools() else {
            eprintln!("skipping: bundled ffmpeg/ffprobe not present");
            return;
        };
        let source = make_split_source(&t);
        let out = t.dir.join("zoom.mp4");
        let mut opts = opts_for(one_segment(&source), &out, None);
        // 2x zoom from 1.0 s to 4.0 s, settling on the right-hand blue half.
        opts.zoom_regions = vec![zoom_region(1.0, 4.0, 2.0, 0.75, 0.5, 400.0)];
        run_export_argv(&t, &opts);

        assert_eq!(probe(&t, &out, "stream=width,height"), "1280 720", "zoom keeps the frame size");

        // Before the zoom: the original split picture.
        let before = frame_rgb(&t, &out, 0.5, 1280, 720);
        assert!(red(rgb_at(&before, 1280, 200, 360)), "left is red before {:?}", rgb_at(&before, 1280, 200, 360));
        assert!(blue(rgb_at(&before, 1280, 1000, 360)));

        // On the plateau the window is the right half, so the whole frame is blue.
        let mid = frame_rgb(&t, &out, 2.5, 1280, 720);
        assert!(blue(rgb_at(&mid, 1280, 30, 360)), "left edge {:?}", rgb_at(&mid, 1280, 30, 360));
        assert!(blue(rgb_at(&mid, 1280, 640, 360)));
        assert!(blue(rgb_at(&mid, 1280, 1250, 360)));

        // After the zoom ends the picture is back to normal.
        let after = frame_rgb(&t, &out, 4.6, 1280, 720);
        assert!(red(rgb_at(&after, 1280, 200, 360)), "left is red after {:?}", rgb_at(&after, 1280, 200, 360));
    }

    #[test]
    fn zoom_eases_in_following_the_same_curve_as_the_preview() {
        let Some(t) = tools() else {
            return;
        };
        let source = make_split_source(&t);
        let out = t.dir.join("ease.mp4");
        let mut opts = opts_for(one_segment(&source), &out, None);
        opts.zoom_regions = vec![zoom_region(1.0, 4.0, 2.0, 0.75, 0.5, 1000.0)];
        run_export_argv(&t, &opts);

        // Halfway up the 1 s ease (t = 1.5): smooth(0.5) = 0.5, so scale 1.5 and the
        // centre has drifted to 0.5 + 0.25 * 0.5 = 0.625. The window starts at
        // 0.625 - 1/3 = 0.2917 of the source, so the red/blue boundary (source 0.5)
        // sits at (0.5 - 0.2917) / (2/3) = 0.3125 of the output width, x = 400.
        let f = frame_rgb(&t, &out, 1.5, 1280, 720);
        assert!(red(rgb_at(&f, 1280, 300, 360)), "x=300 red {:?}", rgb_at(&f, 1280, 300, 360));
        assert!(blue(rgb_at(&f, 1280, 500, 360)), "x=500 blue {:?}", rgb_at(&f, 1280, 500, 360));
    }

    #[test]
    fn moving_focus_matches_the_shared_typescript_samples_with_real_ffmpeg() {
        let Some(t) = tools() else { return; };
        let fixture: serde_json::Value = serde_json::from_str(include_str!("../../../tests/fixtures/followZoom.json")).unwrap();
        let source = make_split_source(&t);
        let out = t.dir.join("follow.mp4");
        let mut opts = opts_for(one_segment(&source), &out, None);
        opts.zoom_regions = vec![serde_json::from_value(fixture["region"].clone()).unwrap()];
        run_export_argv(&t, &opts);
        for sample in fixture["samples"].as_array().unwrap() {
            let time = sample["t"].as_f64().unwrap();
            let scale = sample["scale"].as_f64().unwrap();
            let cx = sample["cx"].as_f64().unwrap();
            let x0 = (cx - 0.5 / scale).clamp(0.0, 1.0 - 1.0 / scale);
            let boundary = ((0.5 - x0) * scale * 1280.0).round() as u32;
            let f = frame_rgb(&t, &out, time, 1280, 720);
            assert!(red(rgb_at(&f, 1280, boundary - 40, 360)), "red before predicted boundary at t={time}");
            assert!(blue(rgb_at(&f, 1280, boundary + 40, 360)), "blue after predicted boundary at t={time}");
        }
        assert!((probe(&t, &out, "format=duration").parse::<f64>().unwrap() - 5.0).abs() < 0.05);
    }

    #[test]
    fn zoom_followed_by_a_scene_still_frames_the_zoomed_picture() {
        let Some(t) = tools() else {
            return;
        };
        let source = make_split_source(&t);
        let out = t.dir.join("zoomscene.mp4");
        let mut opts = opts_for(one_segment(&source), &out, Some(blue_scene_green_bg()));
        opts.zoom_regions = vec![zoom_region(1.0, 4.0, 2.0, 0.75, 0.5, 400.0)];
        run_export_argv(&t, &opts);

        assert_eq!(probe(&t, &out, "stream=width,height"), "1280 720");
        let f = frame_rgb(&t, &out, 2.5, 1280, 720);
        // Canvas edge: the scene's green background, untouched by the zoom.
        assert!(close(rgb_at(&f, 1280, 10, 10), [0, 255, 0], 16), "bg {:?}", rgb_at(&f, 1280, 10, 10));
        // Inside the frame: zoomed onto the blue half.
        assert!(blue(rgb_at(&f, 1280, 300, 360)), "framed zoom {:?}", rgb_at(&f, 1280, 300, 360));
    }

    fn blue_scene_green_bg() -> SceneRender {
        let mut s = blue_scene();
        s.background = ResolvedBackground::Solid { color: "#00ff00".into() };
        s
    }

    #[test]
    fn zoom_keeps_the_edl_duration_across_cuts() {
        let Some(t) = tools() else {
            return;
        };
        let source = make_split_source(&t);
        let out = t.dir.join("cut.mp4");
        // Two kept pieces, 0-1.5 s and 3-5 s (3.5 s), zoomed across the join.
        let mut opts = opts_for(project_for(&source), &out, None);
        opts.zoom_regions = vec![zoom_region(1.0, 2.5, 2.0, 0.5, 0.5, 300.0)];
        run_export_argv(&t, &opts);
        let o = Command::new(&t.ffprobe)
            .args(["-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1"])
            .arg(&out)
            .output()
            .unwrap();
        let d: f64 = String::from_utf8_lossy(&o.stdout).trim().parse().unwrap();
        assert!((d - 3.5).abs() < 0.2, "duration {d}");
    }

    #[test]
    fn a_focus_in_the_corner_never_shows_empty_space() {
        let Some(t) = tools() else {
            return;
        };
        let source = make_split_source(&t);
        let out = t.dir.join("corner.mp4");
        let mut opts = opts_for(one_segment(&source), &out, None);
        opts.zoom_regions = vec![zoom_region(1.0, 4.0, 3.0, 1.0, 1.0, 300.0)];
        run_export_argv(&t, &opts);
        let f = frame_rgb(&t, &out, 2.5, 1280, 720);
        // Bottom-right of a 3x zoom is still picture (blue), and so is every corner.
        for (x, y) in [(2, 2), (1277, 2), (2, 717), (1277, 717)] {
            assert!(blue(rgb_at(&f, 1280, x, y)), "corner ({x},{y}) {:?}", rgb_at(&f, 1280, x, y));
        }
    }

    #[test]
    fn zoom_regions_force_the_full_re_encode_path() {
        let mut opts = opts_for(fixture(), Path::new("/tmp/o.mp4"), None);
        assert!(zoom_for(&opts).is_empty());
        opts.zoom_regions = vec![zoom_region(1.0, 4.0, 2.0, 0.5, 0.5, 400.0)];
        assert_eq!(zoom_for(&opts).len(), 1);
        // Audio-only exports have no picture to zoom.
        opts.preset = ExportPreset::PodcastAudio;
        assert!(zoom_for(&opts).is_empty());
    }

    #[test]
    fn the_argument_list_chains_zoom_then_scene() {
        let mut opts = opts_for(fixture(), Path::new("/tmp/o.mp4"), Some(blue_scene()));
        opts.zoom_regions = vec![zoom_region(1.0, 4.0, 2.0, 0.5, 0.5, 400.0)];
        let joined = build_reencode_argv(&opts, 4.0, None, None).unwrap().join(" ");
        let cadence_at=joined.find("[catv]fps=30[animatedv]").expect("animation receives steady frames");
        let zoom_at = joined.find("[animatedv]scale=w=").expect("zoom reads the animated concat output");
        assert!(cadence_at < zoom_at);
        let scene_at = joined.find("[zoomv]scale=").expect("scene reads the zoom output");
        assert!(zoom_at < scene_at);
        assert!(joined.contains("[outv]"));
    }

    // -----------------------------------------------------------------------
    // Export formats: argv shape, validation, and real ffmpeg + ffprobe checks.
    // -----------------------------------------------------------------------

    use super::{ExportFormat, ExportRange};

    /// The default MP4 argv must stay byte-for-byte what it was before formats
    /// existed (golden captured from v4.28.2).
    #[test]
    fn default_mp4_argv_is_byte_for_byte_unchanged() {
        let golden: Vec<Vec<String>> =
            serde_json::from_str(include_str!("../../../tests/fixtures/exportArgvGolden.json")).unwrap();
        let plain = opts_for(fixture(), Path::new("/o/plain.mp4"), None);
        assert_eq!(build_reencode_argv(&plain, 4.0, None, None).unwrap(), golden[0]);
        let mut z = opts_for(fixture(), Path::new("/o/z.mp4"), Some(blue_scene()));
        z.zoom_regions = vec![zoom_region(1.0, 4.0, 2.0, 0.5, 0.5, 400.0)];
        z.width = Some(1280);
        z.height = Some(720);
        z.fps = Some(30.0);
        z.codec = Some("hevc".into());
        assert_eq!(build_reencode_argv(&z, 4.0, Some(&PathBuf::from("/t/meta.txt")), None).unwrap(), golden[1]);
        let mut m = opts_for(music_project(), Path::new("/o/m.mp4"), None);
        m.width = Some(1920);
        m.height = Some(1080);
        assert_eq!(build_reencode_argv(&m, 4.0, None, None).unwrap(), golden[2]);
    }

    #[test]
    fn format_deserializes_with_mp4_as_the_default() {
        let f: ExportFormat = serde_json::from_str("\"prores-422-hq\"").unwrap();
        assert_eq!(f, ExportFormat::ProRes422Hq);
        assert_eq!(ExportFormat::default(), ExportFormat::Mp4);
    }

    #[test]
    fn validation_rejects_mismatched_extension_video_stems_and_bad_ranges() {
        let mut o = opts_for(fixture(), Path::new("/o/a.mp4"), None);
        assert!(super::validate(&o, 4.0).is_ok());
        o.format = ExportFormat::ProRes422;
        assert!(super::validate(&o, 4.0).unwrap_err().contains(".mov"));
        o.output_path = "/o/a.MOV".into();
        assert!(super::validate(&o, 4.0).is_ok(), "extension check ignores case");
        o.stems = true;
        assert!(super::validate(&o, 4.0).unwrap_err().contains("stems"));
        o.format = ExportFormat::Wav;
        o.output_path = "/o/a.wav".into();
        assert!(super::validate(&o, 4.0).is_ok());
        for (start, end) in [(-1.0, 2.0), (2.0, 2.0), (3.0, 1.0), (f64::NAN, 1.0), (4.0, 5.0)] {
            o.range = Some(ExportRange { start, end });
            assert!(super::validate(&o, 4.0).is_err(), "{start}..{end}");
        }
        o.range = Some(ExportRange { start: 1.0, end: 99.0 });
        assert!(super::validate(&o, 4.0).is_ok());
        assert_eq!(super::range_span(&o, 4.0), Some((1.0, 3.0)), "end clamps to the timeline");
    }

    #[test]
    fn the_podcast_preset_with_the_default_format_is_m4a() {
        let mut o = opts_for(fixture(), Path::new("/o/a.m4a"), None);
        o.preset = ExportPreset::PodcastAudio;
        assert_eq!(super::format_of(&o), ExportFormat::M4a);
        o.format = ExportFormat::Wav;
        assert_eq!(super::format_of(&o), ExportFormat::Wav);
    }

    #[test]
    fn audio_and_gif_graphs_only_build_the_streams_they_write() {
        let mut o = opts_for(fixture(), Path::new("/o/a.wav"), None);
        o.format = ExportFormat::Wav;
        let j = build_reencode_argv(&o, 4.0, None, None).unwrap().join(" ");
        assert!(j.contains("concat=n=2:v=0:a=1[mainvox]"), "{j}");
        assert!(!j.contains(":v]") && !j.contains("[outv]"), "{j}");
        o.format = ExportFormat::Gif;
        o.output_path = "/o/a.gif".into();
        let j = build_reencode_argv(&o, 4.0, None, None).unwrap().join(" ");
        assert!(j.contains("concat=n=2:v=1:a=0[outv]"), "{j}");
        assert!(j.contains("palettegen") && j.contains("paletteuse") && j.contains("-map [gifv]"), "{j}");
        assert!(!j.contains(":a]") && !j.contains("[outa]"), "{j}");
    }

    #[test]
    fn gif_rate_and_width_are_capped() {
        let mut o = opts_for(fixture(), Path::new("/o/a.gif"), None);
        o.format = ExportFormat::Gif;
        assert_eq!(super::gif_fps(&o), 15.0);
        assert_eq!(super::gif_width(&o), 640, "1920 source defaults down to 640");
        o.fps = Some(60.0);
        o.width = Some(3840);
        assert_eq!(super::gif_fps(&o), 30.0);
        assert_eq!(super::gif_width(&o), 960);
        o.fps = Some(10.0);
        o.width = Some(481);
        assert_eq!((super::gif_fps(&o), super::gif_width(&o)), (10.0, 480));
    }

    #[test]
    fn stem_paths_sit_beside_the_mix() {
        assert_eq!(
            super::stem_paths("/o/talk.wav", 2, &[false]),
            vec!["/o/talk-voice-1.wav", "/o/talk-voice-2.wav", "/o/talk-music-1.wav"]
        );
    }

    #[test]
    fn a_range_is_cut_inside_the_graph_after_the_mix() {
        let mut o = opts_for(music_project(), Path::new("/o/a.mp4"), None);
        o.range = Some(ExportRange { start: 0.5, end: 2.0 });
        let argv = build_reencode_argv(&o, 4.0, None, None).unwrap();
        let j = argv.join(" ");
        assert!(j.contains("[outv]trim=start=0.500000:duration=1.500000,setpts=PTS-STARTPTS[rangev]"), "{j}");
        assert!(j.contains("[outa]atrim=start=0.500000:duration=1.500000,asetpts=PTS-STARTPTS[outa_r]"), "{j}");
        assert!(j.contains("-map [rangev] -map [outa_r]"), "{j}");
        // Music is still laid out over the whole timeline before the slice.
        assert!(j.find("[vox_main]").unwrap() < j.find("[outa]atrim").unwrap());
        assert!(!argv.iter().any(|a| a == "-ss" || a == "-t"), "{j}");
    }

    #[test]
    fn a_gif_range_is_trimmed_before_the_palette_and_uses_per_frame_palettes() {
        let mut o = opts_for(fixture(), Path::new("/o/a.gif"), None);
        o.format = ExportFormat::Gif;
        o.range = Some(ExportRange { start: 1.0, end: 3.0 });
        let j = build_reencode_argv(&o, 4.0, None, None).unwrap().join(" ");
        let trim = j.find("[rangev]").expect("range trim");
        assert!(trim < j.find("split[gifa][gifb]").unwrap(), "{j}");
        assert!(j.contains("[rangev]fps=15"), "{j}");
        assert!(j.contains("palettegen=stats_mode=single") && j.contains("paletteuse=new=1"), "{j}");
    }

    #[test]
    fn gifs_longer_than_the_cap_need_a_range() {
        let mut o = opts_for(fixture(), Path::new("/o/a.gif"), None);
        o.format = ExportFormat::Gif;
        assert!(super::validate(&o, 120.0).unwrap_err().contains("limited to 60 s"));
        o.range = Some(ExportRange { start: 10.0, end: 70.0 });
        assert!(super::validate(&o, 120.0).is_ok());
        o.range = Some(ExportRange { start: 10.0, end: 71.0 });
        assert!(super::validate(&o, 120.0).is_err());
        o.format = ExportFormat::Mp4;
        o.output_path = "/o/a.mp4".into();
        o.range = None;
        assert!(super::validate(&o, 7200.0).is_ok(), "only GIF has a length cap");
    }

    #[test]
    fn chapters_in_a_range_are_shifted_and_clipped() {
        use crate::edl::Chapter;
        let c = |t: f64, n: &str| Chapter { id: n.into(), output_time: t, title: n.into() };
        let got = super::chapters_in_range(&[c(5.0, "b"), c(0.0, "a"), c(9.0, "c"), c(20.0, "d")], 6.0, 12.0);
        let got: Vec<(f64, &str)> = got.iter().map(|c| (c.output_time, c.title.as_str())).collect();
        assert_eq!(got, vec![(0.0, "b"), (3.0, "c")]);
        // A chapter exactly at the range start stays at 0.
        let got = super::chapters_in_range(&[c(0.0, "a"), c(6.0, "b")], 6.0, 12.0);
        assert_eq!(got.iter().map(|c| c.title.as_str()).collect::<Vec<_>>(), vec!["b"]);
    }

    #[test]
    fn stems_never_overwrite_an_existing_file_or_an_input() {
        let dir = std::env::temp_dir().join(format!("yusafcut-stems-{}", uuid::Uuid::new_v4()));
        std::fs::create_dir_all(&dir).unwrap();
        let mut o = opts_for(fixture(), &dir.join("talk.wav"), None);
        o.format = ExportFormat::Wav;
        o.stems = true;
        assert!(super::preflight(&o).is_ok());
        assert_eq!(super::stem_outputs(&o), vec![dir.join("talk-voice-1.wav").to_string_lossy().into_owned()]);
        std::fs::write(dir.join("talk-voice-1.wav"), b"x").unwrap();
        assert!(super::preflight(&o).unwrap_err().contains("already exists"));
        std::fs::remove_file(dir.join("talk-voice-1.wav")).unwrap();
        // A source whose name collides with a stem path.
        o.project.media.get_mut("m").unwrap().path = dir.join("talk-voice-1.wav").to_string_lossy().into_owned();
        assert!(super::preflight(&o).unwrap_err().contains("input"));
        // The main file may exist (the save dialog already asked).
        o.stems = false;
        std::fs::write(dir.join("talk.wav"), b"x").unwrap();
        assert!(super::preflight(&o).is_ok());
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn a_failed_export_removes_only_files_it_wrote() {
        let dir = std::env::temp_dir().join(format!("yusafcut-partial-{}", uuid::Uuid::new_v4()));
        std::fs::create_dir_all(&dir).unwrap();
        let mut o = opts_for(fixture(), &dir.join("talk.wav"), None);
        o.format = ExportFormat::Wav;
        o.stems = true;
        // An old main file the export never touched survives.
        std::fs::write(dir.join("talk.wav"), b"old").unwrap();
        std::thread::sleep(std::time::Duration::from_millis(20));
        let started = std::time::SystemTime::now();
        super::remove_partial_outputs(&o, started);
        assert!(dir.join("talk.wav").exists());
        // Files written after the start (partial main + stem) are removed.
        std::fs::write(dir.join("talk.wav"), b"partial").unwrap();
        std::fs::write(dir.join("talk-voice-1.wav"), b"partial").unwrap();
        super::remove_partial_outputs(&o, started);
        assert!(!dir.join("talk.wav").exists() && !dir.join("talk-voice-1.wav").exists());
        let _ = std::fs::remove_dir_all(&dir);
    }

    /// Peak resident memory (bytes) of a command, from macOS `/usr/bin/time -l`.
    fn run_measuring_rss(cmd: &Path, argv: &[String]) -> (std::process::Output, Option<u64>) {
        let out = Command::new("/usr/bin/time").arg("-l").arg(cmd).args(argv).output().unwrap();
        let rss = String::from_utf8_lossy(&out.stderr)
            .lines()
            .find(|l| l.contains("maximum resident set size"))
            .and_then(|l| l.split_whitespace().next()?.parse().ok());
        (out, rss)
    }

    #[test]
    fn a_short_gif_range_of_a_long_timeline_stays_short_and_small() {
        let Some(t) = tools() else { return };
        // A 120 s timeline with a moving picture, so every frame differs.
        let src = t.dir.join("long.mp4");
        let made = Command::new(&t.ffmpeg)
            .args(["-v", "error", "-y", "-f", "lavfi", "-i", "testsrc2=s=1280x720:r=30:d=120"])
            .args(["-f", "lavfi", "-i", "sine=frequency=440:sample_rate=48000:duration=120"])
            .args(["-c:v", "libx264", "-preset", "ultrafast", "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest"])
            .arg(&src)
            .output()
            .unwrap();
        assert!(made.status.success(), "{}", String::from_utf8_lossy(&made.stderr));
        let mut o = opts_for(one_segment(&src), &t.dir.join("short.gif"), None);
        o.project.segments[0].source_out = 120.0;
        o.project.media.get_mut("m").unwrap().duration = 120.0;
        o.format = ExportFormat::Gif;
        o.range = Some(ExportRange { start: 100.0, end: 102.0 });
        super::validate(&o, 120.0).unwrap();
        let argv: Vec<String> = build_reencode_argv(&o, 120.0, None, None)
            .unwrap()
            .into_iter()
            .filter(|a| a != "-hwaccel" && a != "videotoolbox")
            .collect();
        let (out, rss) = run_measuring_rss(&t.ffmpeg, &argv);
        assert!(out.status.success(), "{}", String::from_utf8_lossy(&out.stderr));
        let j = probe_json(&t, Path::new(&o.output_path));
        eprintln!("FFPROBE short.gif duration={} peak_rss={rss:?}", j["format"]["duration"]);
        assert!((duration(&j) - 2.0).abs() < 0.15, "{}", duration(&j));
        if let Some(rss) = rss {
            assert!(rss < 400 * 1024 * 1024, "peak RSS {} MB", rss / 1024 / 1024);
        }
    }

    fn music_project() -> Project {
        let mut p = fixture();
        p.media.insert(
            "music".into(),
            SourceMedia {
                id: "music".into(),
                path: "/tmp/song.mp3".into(),
                duration: 200.0,
                fps: 0.0,
                width: 0,
                height: 0,
                audio_sample_rate: 44100,
                sha256: "music".into(), pending_camera: None,
            },
        );
        p.audio_tracks.push(AudioTrack { id: "t1".into(), media_id: "music".into(), gain_db: -12.0, offset_sec: 1.0, ducks: true, ..Default::default() });
        p.audio_tracks.push(AudioTrack { id: "t2".into(), media_id: "music".into(), gain_db: -20.0, offset_sec: 0.0, ducks: false, ..Default::default() });
        p
    }

    /// A 5 s 1280x720 clip with a stereo 48 kHz tone at `freq`.
    fn make_av(t: &Tools, name: &str, color: &str, freq: u32) -> PathBuf {
        let path = t.dir.join(name);
        let audio = format!("sine=frequency={freq}:sample_rate=48000:duration=5,pan=stereo|c0=c0|c1=c0");
        let out = Command::new(&t.ffmpeg)
            .args(["-v", "error", "-y", "-f", "lavfi", "-i", &format!("color=c={color}:s=1280x720:r=30:d=5")])
            .args(["-f", "lavfi", "-i", &audio])
            .args(["-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest"])
            .arg(&path)
            .output()
            .unwrap();
        assert!(out.status.success(), "{}", String::from_utf8_lossy(&out.stderr));
        path
    }

    fn probe_json(t: &Tools, file: &Path) -> serde_json::Value {
        let out = Command::new(&t.ffprobe)
            .args(["-v", "error", "-show_streams", "-show_format", "-show_chapters", "-of", "json"])
            .arg(file)
            .output()
            .unwrap();
        assert!(out.status.success(), "ffprobe {}: {}", file.display(), String::from_utf8_lossy(&out.stderr));
        serde_json::from_slice(&out.stdout).unwrap()
    }

    fn duration(j: &serde_json::Value) -> f64 {
        j["format"]["duration"].as_str().unwrap().parse().unwrap()
    }

    fn streams<'a>(j: &'a serde_json::Value, kind: &str) -> Vec<&'a serde_json::Value> {
        j["streams"].as_array().unwrap().iter().filter(|s| s["codec_type"] == kind).collect()
    }

    /// Validate, build, and run an export with the real ffmpeg (software decode).
    fn export(t: &Tools, opts: &ExportOpts, chapters: Option<&PathBuf>) -> serde_json::Value {
        let total: f64 = opts.project.output_duration();
        super::validate(opts, total).expect("valid");
        let argv: Vec<String> = build_reencode_argv(opts, total, chapters, None)
            .unwrap()
            .into_iter()
            .filter(|a| a != "-hwaccel" && a != "videotoolbox")
            .collect();
        let out = Command::new(&t.ffmpeg).args(&argv).output().unwrap();
        assert!(out.status.success(), "ffmpeg {argv:?}: {}", String::from_utf8_lossy(&out.stderr));
        let j = probe_json(t, Path::new(&opts.output_path));
        eprintln!(
            "FFPROBE {}: format={} duration={} streams={}",
            Path::new(&opts.output_path).file_name().unwrap().to_string_lossy(),
            j["format"]["format_name"],
            j["format"]["duration"],
            j["streams"]
                .as_array()
                .unwrap()
                .iter()
                .map(|s| format!(
                    "{}:{} profile={} pix_fmt={} {}x{} r={} ch={} sr={} tag={}",
                    s["codec_type"], s["codec_name"], s["profile"], s["pix_fmt"], s["width"], s["height"],
                    s["r_frame_rate"], s["channels"], s["sample_rate"], s["codec_tag_string"]
                ))
                .collect::<Vec<_>>()
                .join(" | ")
        );
        j
    }

    fn formatted(t: &Tools, source: &Path, file: &str, format: ExportFormat) -> ExportOpts {
        let mut o = opts_for(project_for(source), &t.dir.join(file), None);
        o.format = format;
        o
    }

    #[test]
    fn mov_holds_h264_and_hevc_tagged_hvc1() {
        let Some(t) = tools() else { return };
        let src = make_av(&t, "a.mp4", "red", 440);
        let j = export(&t, &formatted(&t, &src, "h264.mov", ExportFormat::Mov), None);
        assert!(j["format"]["format_name"].as_str().unwrap().contains("mov"));
        assert_eq!(streams(&j, "video")[0]["codec_name"], "h264");
        assert_eq!(streams(&j, "audio")[0]["codec_name"], "aac");
        assert!((duration(&j) - 3.5).abs() < 0.15, "{}", duration(&j));
        let mut o = formatted(&t, &src, "hevc.mov", ExportFormat::Mov);
        o.codec = Some("hevc".into());
        let j = export(&t, &o, None);
        assert_eq!(streams(&j, "video")[0]["codec_name"], "hevc");
        assert_eq!(streams(&j, "video")[0]["codec_tag_string"], "hvc1");
    }

    /// First frame of `file` as RGBA (ffmpeg decodes ProRes 4444 alpha natively).
    fn frame_rgba(t: &Tools, file: &Path, w: u32, h: u32) -> Vec<u8> {
        let out = Command::new(&t.ffmpeg)
            .args(["-v", "error", "-i"])
            .arg(file)
            .args(["-frames:v", "1", "-f", "rawvideo", "-pix_fmt", "rgba", "-"])
            .output()
            .unwrap();
        assert!(out.status.success(), "{}", String::from_utf8_lossy(&out.stderr));
        assert_eq!(out.stdout.len(), (w * h * 4) as usize);
        out.stdout
    }

    fn device_scene(name: &str) -> SceneRender {
        let all: std::collections::HashMap<String, SceneRender> =
            serde_json::from_str(include_str!("../../../tests/fixtures/deviceFrameRender.json")).unwrap();
        all[name].clone()
    }

    #[test]
    fn a_device_frame_exports_end_to_end_and_its_text_file_is_removed() {
        let Some(t) = tools() else { return };
        let source = make_source(&t); // solid red
        let out = t.dir.join("device.mp4");
        let scene = device_scene("browser");
        let opts = opts_for(project_for(&source), &out, Some(scene.clone()));
        // The title is drawn from a prepared file: without it the argv is refused.
        assert!(build_reencode_argv(&opts, 3.5, None, None).is_err());
        let files = super::prepare_overlays(&opts).unwrap();
        let ass = files.frame_text.as_ref().unwrap().0.clone();
        assert!(ass.exists());
        let argv = super::build_reencode_argv_opts(&opts, 3.5, None, files.paths()).unwrap();
        let graph = &argv[argv.iter().position(|a| a == "-filter_complex").unwrap() + 1];
        assert!(graph.contains("[outv]ass=filename=") && graph.contains("[scenetv]"), "{graph}");
        let argv: Vec<String> = argv.into_iter().filter(|a| a != "-hwaccel" && a != "videotoolbox").collect();
        let run = Command::new(&t.ffmpeg).args(argv).output().unwrap();
        assert!(run.status.success(), "ffmpeg: {}", String::from_utf8_lossy(&run.stderr));
        drop(files);
        assert!(!ass.exists(), "the frame text file must be removed");

        assert_eq!(probe(&t, &out, "stream=width,height"), "960 540");
        let f = frame_rgb(&t, &out, 1.0, 960, 540);
        let fr = scene.frame.as_ref().unwrap();
        // Picture (red source), bar colour, traffic light.
        assert!(close(rgb_at(&f, 960, scene.content_x + scene.content_w / 2, scene.content_y + scene.content_h / 2), [255, 0, 0], 16));
        let bar = &fr.below[0];
        assert!(close(rgb_at(&f, 960, bar.rect.x as u32 + 190, bar.rect.y as u32 + 16), [44, 44, 47], 10));
        let light = &fr.above[0].rect;
        assert!(close(rgb_at(&f, 960, (light.x + light.w / 2.0) as u32, (light.y + light.h / 2.0) as u32), [108, 108, 114], 14));
        // Transparent padding is flattened to black in MP4.
        assert!(close(rgb_at(&f, 960, 3, 3), [0, 0, 0], 6));
        // Title text: pixels in the pill that differ from the pill colour.
        let pill = &fr.above[3].rect;
        let mut text_px = 0;
        for y in pill.y as u32..(pill.y + pill.h) as u32 {
            for x in pill.x as u32..(pill.x + pill.w) as u32 {
                if (rgb_at(&f, 960, x, y)[0] - 65).abs() > 40 { text_px += 1; }
            }
        }
        assert!(text_px > 40, "title text should be drawn, saw {text_px} px");
    }

    #[test]
    fn a_device_frame_with_zoom_keeps_the_frame_still_and_zooms_only_the_picture() {
        let Some(t) = tools() else { return };
        let source = make_split_source(&t);
        let out = t.dir.join("device-zoom.mp4");
        let scene = device_scene("laptop");
        let mut opts = opts_for(one_segment(&source), &out, Some(scene.clone()));
        opts.zoom_regions = vec![zoom_region(0.0, 4.0, 3.0, 0.5, 0.5, 0.0)];
        let files = super::prepare_overlays(&opts).unwrap();
        let argv = super::build_reencode_argv_opts(&opts, 5.0, None, files.paths()).unwrap();
        let argv: Vec<String> = argv.into_iter().filter(|a| a != "-hwaccel" && a != "videotoolbox").collect();
        let run = Command::new(&t.ffmpeg).args(argv).output().unwrap();
        assert!(run.status.success(), "ffmpeg: {}", String::from_utf8_lossy(&run.stderr));
        let f = frame_rgb(&t, &out, 2.0, 960, 540);
        let fr = scene.frame.as_ref().unwrap();
        // The device outline does not move or scale: bezel and base are where the layout put them.
        let lid = &fr.below[0].rect;
        assert!(close(rgb_at(&f, 960, lid.x as u32 + 6, (lid.y + lid.h / 2.0) as u32), [32, 32, 64], 10));
        let base = &fr.below[1].rect;
        assert!(close(rgb_at(&f, 960, base.x as u32 + 40, base.y as u32 + 4), [182, 182, 191], 10));
        // The picture inside is clipped to the screen (zoom never spills into the bezel).
        assert!(!close(rgb_at(&f, 960, fr.screen.x as u32 - 6, (fr.screen.y + fr.screen.h / 2.0) as u32), [255, 0, 0], 60));
    }

    fn transparent_scene() -> SceneRender {
        let mut s = blue_scene();
        s.background = ResolvedBackground::Transparent;
        s.radius_px = 0.0;
        s
    }

    #[test]
    fn prores_4444_keeps_a_transparent_scene_background_as_real_alpha() {
        let Some(t) = tools() else { return };
        let src = make_source(&t);
        let mut o = opts_for(project_for(&src), &t.dir.join("alpha.mov"), Some(transparent_scene()));
        o.format = ExportFormat::ProRes4444;
        let j = export(&t, &o, None);
        let v = streams(&j, "video")[0];
        assert_eq!(v["codec_name"], "prores");
        assert_eq!(v["profile"], "4444");
        // The encoder is fed yuva444p10le; ffprobe reports ProRes 4444 by the decoder's
        // native format, which is the 12-bit alpha variant.
        assert!(matches!(v["pix_fmt"].as_str(), Some("yuva444p10le" | "yuva444p12le")), "{}", v["pix_fmt"]);
        assert_eq!(v["codec_tag_string"], "ap4h");
        let f = frame_rgba(&t, &t.dir.join("alpha.mov"), 1280, 720);
        let at = |x: usize, y: usize| &f[(y * 1280 + x) * 4..(y * 1280 + x) * 4 + 4];
        assert_eq!(at(10, 10)[3], 0, "padding region must be transparent");
        assert_eq!(at(1270, 710)[3], 0);
        let c = at(640, 360);
        assert_eq!(c[3], 255, "content region must be opaque");
        assert!(c[0] > 225 && c[1] < 30 && c[2] < 30, "content is the red source: {c:?}");
    }

    /// A green caption box on the bottom of the frame for the whole first second.
    const GREEN_BOTTOM: &str = r##"{"style":{"position":"bottom","boxColor":"#00ff00","boxOpacity":1,"size":60},"cues":[{"start":0,"end":1.5,"lines":[[{"t":"Hello","s":0,"e":1.5}]]}]}"##;

    #[test]
    fn captions_over_a_transparent_scene_keep_alpha_in_prores_4444() {
        let Some(t) = tools() else { return };
        let src = make_source(&t);
        let mut p = one_segment(&src);
        p.segments[0].source_out = 2.;
        let out = t.dir.join("alpha-caps.mov");
        let mut o = opts_for(p, &out, Some(transparent_scene()));
        o.format = ExportFormat::ProRes4444;
        o.captions = Some(caption_export(GREEN_BOTTOM));
        let argv = super::build_reencode_argv_with(&o, 2., None, None, Some(Path::new("/x.ass"))).unwrap().join(" ");
        assert!(argv.contains(":alpha=1[capv]"), "{argv}");
        run_with_captions(&t, &o, 2.);
        let f = frame_rgba(&t, &out, 1280, 720);
        let at = |x: u32, y: u32| { let i = ((y * 1280 + x) * 4) as usize; [f[i], f[i + 1], f[i + 2], f[i + 3]] };
        // The content ends at y=648; below it is transparent padding the caption box reaches into.
        let mut drawn = 0;
        for y in 652..720 {
            for x in 0..1280 {
                let c = at(x, y);
                if c[3] > 200 && c[1] > 200 && c[0] < 80 && c[2] < 80 {
                    drawn += 1;
                }
            }
        }
        assert!(drawn > 300, "caption over transparent padding must be opaque green: {drawn}");
        assert_eq!(at(10, 10)[3], 0, "padding away from the caption stays transparent");
        assert_eq!(at(10, 700)[3], 0, "bottom padding beside the caption stays transparent");
        assert_eq!(at(1270, 700)[3], 0);
        assert_eq!(at(640, 360)[3], 255, "content stays opaque");
    }

    #[test]
    fn captions_are_placed_on_the_cropped_scene_canvas() {
        let Some(t) = tools() else { return };
        let src = make_source(&t);
        let mut p = one_segment(&src);
        p.segments[0].source_out = 2.;
        // "Original" aspect of a 640x720 crop: the canvas is the crop, not the 1280x720 source.
        let mut scene = blue_scene();
        (scene.canvas_w, scene.canvas_h) = (640, 720);
        (scene.content_x, scene.content_y, scene.content_w, scene.content_h) = (0, 0, 640, 720);
        scene.radius_px = 0.0;
        scene.crop = Some(crate::scene::CropPx { x: 320, y: 0, w: 640, h: 720 });
        let out = t.dir.join("crop-caps.mp4");
        let mut o = opts_for(p, &out, Some(scene));
        o.captions = Some(caption_export(GREEN_BOTTOM));
        assert_eq!(super::final_size(&o).unwrap(), (640, 720));
        run_with_captions(&t, &o, 2.);
        let f = frame_rgb(&t, &out, 1.0, 640, 720);
        let (mut n, mut sx, mut min_y) = (0u32, 0u32, 720u32);
        for y in 0..720 {
            for x in 0..640 {
                if green(rgb_at(&f, 640, x, y)) {
                    n += 1;
                    sx += x;
                    min_y = min_y.min(y);
                }
            }
        }
        assert!(n > 400, "caption drawn on the cropped canvas: {n}");
        let cx = sx / n;
        assert!((300..=340).contains(&cx), "caption centred on the 640 px canvas: {cx}");
        assert!(min_y > 480, "caption sits at the bottom: {min_y}");
    }

    /// Captions + a fixed annotation + key caps (+ optional scene): what each needs, faked paths.
    fn all_overlays(o: &mut ExportOpts) {
        o.captions = Some(caption_export(GREEN_BOTTOM));
        let id = o.project.segments[0].media_id.clone();
        o.project.annotations = Some(serde_json::json!([
            {"kind":"box","start":0,"end":2,"x":0.1,"y":0.05,"w":0.2,"h":0.1,"color":"#ffffff","filled":true}
        ]));
        o.project.cursor = Some(serde_json::json!({"style":{"show":false},"tracks":{id:{"events":[{"type":"key","t":0.5,"mods":["cmd"]}]}}}));
        o.project.keystrokes = Some(serde_json::json!({"enabled":true}));
    }

    #[test]
    fn frame_layer_is_fixed_annotations_then_captions_then_key_caps_with_alpha_only_when_kept() {
        let src = Path::new("/tmp/none.mp4");
        let mut p = one_segment(src);
        p.segments[0].source_out = 2.;
        let files = super::OverlayPaths {
            fixed: Some(Path::new("/t/fixed.ass")),
            captions: Some(Path::new("/t/caps.ass")),
            keys: Some(Path::new("/t/keys.ass")),
            ..Default::default()
        };
        for (format, scene, alpha) in [
            (ExportFormat::ProRes4444, Some(transparent_scene()), true),
            (ExportFormat::ProRes4444, None, false),
            (ExportFormat::Mp4, Some(transparent_scene()), false),
        ] {
            let mut o = opts_for(p.clone(), Path::new("/tmp/o.mov"), scene);
            o.format = format;
            all_overlays(&mut o);
            assert!(!super::overlays_for(&o).is_empty() && super::captions_for(&o).is_some());
            let argv = super::build_reencode_argv_opts(&o, 2., None, files).unwrap();
            let graph = &argv[argv.iter().position(|x| x == "-filter_complex").unwrap() + 1];
            let a = if alpha { ":alpha=1" } else { "" };
            let want = format!(
                "fps=30[framev];[framev]ass=filename=/t/fixed.ass{a}[fixv];[fixv]ass=filename=/t/caps.ass{a}[capv];[capv]ass=filename=/t/keys.ass{a}[keyv]"
            );
            assert!(graph.contains(&want), "{format:?} {graph}");
            assert_eq!(graph.matches("alpha=1").count(), if alpha { 3 } else { 0 }, "{graph}");
            assert!(argv.iter().any(|x| x == "[keyv]"), "key caps are the last video stage");
        }
    }

    #[test]
    fn captions_annotations_and_key_caps_all_draw_on_a_cropped_scene_without_covering_captions() {
        let Some(t) = tools() else { return };
        let src = make_source(&t);
        let mut p = one_segment(&src);
        p.segments[0].source_out = 2.;
        let mut scene = blue_scene();
        (scene.canvas_w, scene.canvas_h) = (640, 720);
        (scene.content_x, scene.content_y, scene.content_w, scene.content_h) = (0, 0, 640, 720);
        scene.radius_px = 0.0;
        scene.crop = Some(crate::scene::CropPx { x: 320, y: 0, w: 640, h: 720 });
        let render = |name: &str, keys: bool| -> Vec<u8> {
            let out = t.dir.join(name);
            let mut o = opts_for(p.clone(), &out, Some(scene.clone()));
            all_overlays(&mut o);
            if !keys {
                o.project.keystrokes = None;
            }
            let ass = t.dir.join(format!("caps-{name}.ass"));
            let mut f = std::fs::File::create(&ass).unwrap();
            crate::captions_export::write_ass(&mut f, o.captions.as_ref().unwrap(), 640, 720).unwrap();
            drop(f);
            let overlay = super::prepare_overlays(&o).unwrap();
            let files = super::OverlayPaths { captions: Some(&ass), ..overlay.paths() };
            let argv = super::build_reencode_argv_opts(&o, 2., None, files).unwrap();
            let argv: Vec<String> = argv.into_iter().filter(|a| a != "-hwaccel" && a != "videotoolbox").collect();
            let r = Command::new(&t.ffmpeg).args(argv).output().unwrap();
            assert!(r.status.success(), "ffmpeg: {}", String::from_utf8_lossy(&r.stderr));
            frame_rgb(&t, &out, 1.0, 640, 720)
        };
        let with = render("all-overlays.mp4", true);
        let without = render("no-keys.mp4", false);
        // Fixed annotation: a white box at (64..192, 36..108) of the 640x720 canvas.
        assert!(close(rgb_at(&with, 640, 128, 72), [255, 255, 255], 30), "{:?}", rgb_at(&with, 640, 128, 72));
        // Captions: the green box at the bottom, identical with and without key caps.
        let greens = |f: &[u8]| -> (u32, u32) {
            let (mut n, mut min_y) = (0, 720);
            for y in 0..720 { for x in 0..640 { if green(rgb_at(f, 640, x, y)) { n += 1; min_y = min_y.min(y); } } }
            (n, min_y)
        };
        let (n_with, cap_top) = greens(&with);
        let (n_without, _) = greens(&without);
        assert!(n_with > 400, "captions drawn: {n_with}");
        // Covering would remove green; allow 2 % for encoder chroma noise.
        assert!(n_with + n_without / 50 >= n_without, "key caps cover captions: {n_with} vs {n_without}");
        // Key caps: a dark cap on the red picture, entirely above the captions.
        let (mut dark, mut key_bottom) = (0, 0);
        for y in 0..720 { for x in 0..640 {
            let c = rgb_at(&with, 640, x, y);
            if c.iter().all(|v| *v < 80) { dark += 1; key_bottom = key_bottom.max(y); }
        } }
        assert!(dark > 300, "key caps drawn: {dark}");
        assert!(key_bottom < cap_top, "key caps ({key_bottom}) sit above the captions ({cap_top})");
        // Moved up to KEY_CAP_Y_ABOVE_CAPTIONS (576 px; the cap's padding reaches a little below).
        assert!((560..=600).contains(&key_bottom), "key caps moved above the captions: {key_bottom}");
    }

    #[test]
    fn a_transparent_background_flattens_to_black_in_formats_without_alpha() {
        let Some(t) = tools() else { return };
        let src = make_source(&t);
        let out = t.dir.join("flat.mp4");
        let o = opts_for(project_for(&src), &out, Some(transparent_scene()));
        let j = export(&t, &o, None);
        assert_eq!(streams(&j, "video")[0]["pix_fmt"], "yuv420p");
        let f = frame_rgb(&t, &out, 1.0, 1280, 720);
        assert!(close(rgb_at(&f, 1280, 10, 10), [0, 0, 0], 10), "padding is black");
        assert!(close(rgb_at(&f, 1280, 640, 360), [255, 0, 0], 16));
    }

    #[test]
    fn a_crop_sized_for_another_media_is_clamped_to_the_first_segments_media() {
        let Some(t) = tools() else { return };
        let src = make_source(&t); // 1280x720, the media the segments use
        let mut scene = blue_scene();
        // As if computed against a 1920x1080 first import.
        scene.crop = Some(crate::scene::CropPx { x: 960, y: 0, w: 1920, h: 1080 });
        let o = opts_for(project_for(&src), &t.dir.join("clamped.mp4"), Some(scene));
        let argv = build_reencode_argv(&o, 3.5, None, None).unwrap().join(" ");
        assert!(argv.contains("crop=1280:720:0:0,"), "{argv}");
        run_export_argv(&t, &o);
    }

    #[test]
    fn crop_keeps_only_the_chosen_region_of_the_source_in_the_export() {
        let Some(t) = tools() else { return };
        // Left half red, right half green, 1280x720.
        let src = t.dir.join("halves.mp4");
        let made = Command::new(&t.ffmpeg)
            .args(["-v", "error", "-y", "-f", "lavfi", "-i", "color=c=red:s=640x720:r=30:d=5"])
            .args(["-f", "lavfi", "-i", "color=c=0x00ff00:s=640x720:r=30:d=5"])
            .args(["-f", "lavfi", "-i", "sine=frequency=440:duration=5"])
            .args(["-filter_complex", "[0:v][1:v]hstack[v]", "-map", "[v]", "-map", "2:a"])
            .args(["-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest"])
            .arg(&src)
            .output()
            .unwrap();
        assert!(made.status.success(), "{}", String::from_utf8_lossy(&made.stderr));
        let mut scene = blue_scene();
        scene.content_x = 320;
        scene.content_y = 0;
        scene.content_w = 640;
        scene.content_h = 720;
        scene.radius_px = 0.0;
        scene.crop = Some(crate::scene::CropPx { x: 640, y: 0, w: 640, h: 720 });
        let out = t.dir.join("cropped.mp4");
        run_export_argv(&t, &opts_for(project_for(&src), &out, Some(scene)));
        let f = frame_rgb(&t, &out, 1.0, 1280, 720);
        assert!(close(rgb_at(&f, 1280, 330, 10), [0, 255, 0], 24), "left of content is the cropped-in green");
        assert!(close(rgb_at(&f, 1280, 950, 700), [0, 255, 0], 24));
        assert!(close(rgb_at(&f, 1280, 100, 360), [0, 0, 255], 12), "outside content is the background");
        assert!(!close(rgb_at(&f, 1280, 640, 360), [255, 0, 0], 60), "red half must be gone");
    }

    #[test]
    fn prores_422_and_hq_are_10_bit_422_in_mov_with_pcm_audio() {
        let Some(t) = tools() else { return };
        let src = make_av(&t, "a.mp4", "red", 440);
        for (format, profile) in [(ExportFormat::ProRes422, "Standard"), (ExportFormat::ProRes422Hq, "HQ")] {
            let j = export(&t, &formatted(&t, &src, &format!("{profile}.mov"), format), None);
            assert!(j["format"]["format_name"].as_str().unwrap().contains("mov"));
            let v = streams(&j, "video")[0];
            assert_eq!(v["codec_name"], "prores");
            assert_eq!(v["profile"], profile);
            assert_eq!(v["pix_fmt"], "yuv422p10le");
            assert_eq!(v["codec_tag_string"], if profile == "HQ" { "apch" } else { "apcn" });
            let a = streams(&j, "audio")[0];
            assert_eq!(a["codec_name"], "pcm_s16le");
            assert_eq!(a["channels"], 2);
            assert!((duration(&j) - 3.5).abs() < 0.15, "{}", duration(&j));
        }
    }

    #[test]
    fn gif_is_palette_encoded_capped_and_silent() {
        let Some(t) = tools() else { return };
        let src = make_av(&t, "a.mp4", "red", 440);
        let j = export(&t, &formatted(&t, &src, "a.gif", ExportFormat::Gif), None);
        assert_eq!(j["format"]["format_name"], "gif");
        let v = streams(&j, "video");
        assert_eq!(v.len(), 1);
        assert_eq!(v[0]["codec_name"], "gif");
        assert_eq!((v[0]["width"].as_u64(), v[0]["height"].as_u64()), (Some(640), Some(360)));
        assert_eq!(v[0]["r_frame_rate"], "15/1");
        assert!(streams(&j, "audio").is_empty());
        // Per-frame palettes still reproduce the picture's colour.
        let f = frame_rgb(&t, &t.dir.join("a.gif"), 1.0, 640, 360);
        assert!(close(rgb_at(&f, 640, 320, 180), [255, 0, 0], 20), "{:?}", rgb_at(&f, 640, 320, 180));
        assert!((duration(&j) - 3.5).abs() < 0.15, "{}", duration(&j));
    }

    #[test]
    fn m4a_and_wav_are_audio_only_with_the_source_channels() {
        let Some(t) = tools() else { return };
        let src = make_av(&t, "a.mp4", "red", 440);
        let j = export(&t, &formatted(&t, &src, "a.m4a", ExportFormat::M4a), None);
        assert!(streams(&j, "video").is_empty());
        let a = streams(&j, "audio")[0];
        assert_eq!((a["codec_name"].as_str(), a["channels"].as_u64()), (Some("aac"), Some(2)));
        assert!((duration(&j) - 3.5).abs() < 0.1, "{}", duration(&j));

        let j = export(&t, &formatted(&t, &src, "a.wav", ExportFormat::Wav), None);
        assert_eq!(j["format"]["format_name"], "wav");
        assert_eq!(j["streams"].as_array().unwrap().len(), 1);
        let a = streams(&j, "audio")[0];
        assert_eq!(a["codec_name"], "pcm_s16le");
        assert_eq!((a["channels"].as_u64(), a["sample_rate"].as_str()), (Some(2), Some("48000")));
        assert!((duration(&j) - 3.5).abs() < 0.02, "{}", duration(&j));
    }

    #[test]
    fn the_legacy_podcast_preset_now_writes_audio() {
        // Before formats this graph left [outv] unconnected and ffmpeg refused it.
        let Some(t) = tools() else { return };
        let src = make_av(&t, "a.mp4", "red", 440);
        let mut o = opts_for(project_for(&src), &t.dir.join("pod.m4a"), None);
        o.preset = ExportPreset::PodcastAudio;
        let j = export(&t, &o, None);
        assert_eq!(j["streams"].as_array().unwrap().len(), 1);
        assert_eq!(streams(&j, "audio")[0]["codec_name"], "aac");
    }

    /// Peak level in dB of `file` between `from` and `from + len` seconds.
    fn peak_db(t: &Tools, file: &Path, from: f64, len: f64) -> f64 {
        let out = Command::new(&t.ffmpeg)
            .args(["-hide_banner", "-ss", &from.to_string(), "-t", &len.to_string(), "-i"])
            .arg(file)
            .args(["-af", "volumedetect", "-f", "null", "-"])
            .output()
            .unwrap();
        let err = String::from_utf8_lossy(&out.stderr);
        let line = err.lines().find(|l| l.contains("max_volume:")).expect("volumedetect output");
        line.split("max_volume:").nth(1).unwrap().trim().trim_end_matches(" dB").parse().unwrap()
    }

    #[test]
    fn stems_write_one_file_per_source_and_music_track_aligned_with_the_mix() {
        let Some(t) = tools() else { return };
        let a = make_av(&t, "a.mp4", "red", 440);
        let b = make_av(&t, "b.mp4", "blue", 660);
        let music = make_av(&t, "music.mp4", "black", 220);
        let mut p = project_for(&a);
        let mut mb = p.media["m"].clone();
        mb.id = "b".into();
        mb.path = b.to_string_lossy().into_owned();
        p.media.insert("b".into(), mb);
        p.segments[1].media_id = "b".into(); // 0-1.5 s from a, then 1.5-3.5 s from b
        let mut mm = p.media["m"].clone();
        mm.id = "music".into();
        mm.path = music.to_string_lossy().into_owned();
        p.media.insert("music".into(), mm);
        p.audio_tracks.push(AudioTrack { id: "t".into(), media_id: "music".into(), gain_db: -6.0, offset_sec: 0.0, ducks: true, ..Default::default() });
        p.audio_tracks.push(AudioTrack { id: "u".into(), media_id: "music".into(), gain_db: -12.0, offset_sec: 0.5, ducks: false, ..Default::default() });
        for format in [ExportFormat::Wav, ExportFormat::M4a] {
            let ext = if format == ExportFormat::Wav { "wav" } else { "m4a" };
            let mut o = opts_for(p.clone(), &t.dir.join(format!("mix.{ext}")), None);
            o.format = format;
            o.stems = true;
            let mix = export(&t, &o, None);
            let names = super::stem_paths(&o.output_path, 2, &[false, false]);
            for path in &names {
                let j = probe_json(&t, Path::new(path));
                eprintln!(
                    "FFPROBE stem {}: codec={} duration={} ch={}",
                    Path::new(path).file_name().unwrap().to_string_lossy(),
                    streams(&j, "audio")[0]["codec_name"],
                    j["format"]["duration"],
                    streams(&j, "audio")[0]["channels"]
                );
                assert_eq!(streams(&j, "audio")[0]["codec_name"], streams(&mix, "audio")[0]["codec_name"]);
                assert!((duration(&j) - duration(&mix)).abs() < 0.05, "{path} {} vs {}", duration(&j), duration(&mix));
            }
            // voice-1 is source a: loud in the first piece, silent in the second; voice-2 the reverse.
            let (v1, v2, m1, m2) = (Path::new(&names[0]), Path::new(&names[1]), Path::new(&names[2]), Path::new(&names[3]));
            let levels = [peak_db(&t, v1, 0.2, 1.0), peak_db(&t, v1, 2.0, 1.0), peak_db(&t, v2, 0.2, 1.0), peak_db(&t, v2, 2.0, 1.0), peak_db(&t, m1, 0.2, 3.0)];
            eprintln!("STEM LEVELS {ext} (v1 a-part, v1 b-part, v2 a-part, v2 b-part, music): {levels:?}");
            // The second music track starts 0.5 s in.
            assert!(peak_db(&t, m2, 0.0, 0.4) < -80.0 && peak_db(&t, m2, 1.0, 1.0) > -40.0);
            assert!(levels[0] > -20.0 && levels[1] < -80.0, "{levels:?}");
            assert!(levels[2] < -80.0 && levels[3] > -20.0, "{levels:?}");
            assert!(levels[4] > -40.0, "music stem carries the music {levels:?}");
        }
    }

    /// Music beds used to break the export unless exactly one track ducked:
    /// an unused or reused sidechain label makes ffmpeg reject the graph.
    #[test]
    fn music_beds_export_with_zero_one_or_two_ducking_tracks() {
        let Some(t) = tools() else { return };
        let src = make_av(&t, "a.mp4", "red", 440);
        let music = make_av(&t, "music.mp4", "black", 220);
        for ducks in [[false, false], [true, false], [true, true]] {
            let mut o = formatted(&t, &src, &format!("bed-{}{}.mp4", ducks[0], ducks[1]), ExportFormat::Mp4);
            let mut mm = o.project.media["m"].clone();
            mm.id = "music".into();
            mm.path = music.to_string_lossy().into_owned();
            o.project.media.insert("music".into(), mm);
            for (i, d) in ducks.iter().enumerate() {
                o.project.audio_tracks.push(AudioTrack { id: format!("t{i}"), media_id: "music".into(), gain_db: -6.0, offset_sec: 0.0, ducks: *d, ..Default::default() });
            }
            let j = export(&t, &o, None);
            assert!((duration(&j) - 3.5).abs() < 0.15, "{ducks:?} {}", duration(&j));
        }
    }

    #[test]
    fn a_range_exports_only_that_span_with_chapters_shifted() {
        let Some(t) = tools() else { return };
        let src = make_av(&t, "a.mp4", "red", 440);
        let mut o = formatted(&t, &src, "range.mp4", ExportFormat::Mp4);
        o.range = Some(ExportRange { start: 1.0, end: 3.0 });
        let chapters = vec![
            crate::edl::Chapter { id: "1".into(), output_time: 0.0, title: "Intro".into() },
            crate::edl::Chapter { id: "2".into(), output_time: 2.0, title: "Main".into() },
        ];
        let meta = t.dir.join("meta.txt");
        // run_export shifts chapters into the range the same way.
        let shifted = super::chapters_in_range(&chapters, 1.0, 3.0);
        std::fs::write(&meta, super::build_chapter_ffmetadata(&shifted, 2.0)).unwrap();
        let j = export(&t, &o, Some(&meta));
        assert!((duration(&j) - 2.0).abs() < 0.1, "{}", duration(&j));
        assert_eq!(streams(&j, "video")[0]["codec_name"], "h264");
        eprintln!("FFPROBE range chapters: {}", j["chapters"]);
        let starts: Vec<f64> = j["chapters"]
            .as_array()
            .unwrap()
            .iter()
            .map(|c| c["start_time"].as_str().unwrap().parse().unwrap())
            .collect();
        assert!(starts.iter().any(|s| (s - 1.0).abs() < 0.05), "chapter at 2 s lands at 1 s: {starts:?}");

        // Ranges work for the other formats too.
        let mut w = formatted(&t, &src, "range.wav", ExportFormat::Wav);
        w.range = Some(ExportRange { start: 0.5, end: 1.25 });
        assert!((duration(&export(&t, &w, None)) - 0.75).abs() < 0.02);
    }

    /// The shared QA fixtures, when present on this machine: every format end to end.
    #[test]
    fn every_format_exports_the_qa_fixtures() {
        let Some(t) = tools() else { return };
        let dir = Path::new("/private/tmp/yc-qa/fixtures");
        for name in ["land_48k.mp4", "port_44k_mono.mp4"] {
            let src = dir.join(name);
            if !src.exists() {
                eprintln!("skipping {name}: fixture not present");
                continue;
            }
            let probe = probe_json(&t, &src);
            let v = streams(&probe, "video")[0];
            let (w, h) = (v["width"].as_u64().unwrap() as u32, v["height"].as_u64().unwrap() as u32);
            let channels = streams(&probe, "audio")[0]["channels"].as_u64().unwrap();
            let len = duration(&probe).min(4.0);
            let mut p = one_segment(&src);
            p.segments[0].source_out = len;
            let m = p.media.get_mut("m").unwrap();
            (m.width, m.height) = (w, h);
            for (format, ext) in [
                (ExportFormat::Mov, "mov"),
                (ExportFormat::ProRes422, "mov"),
                (ExportFormat::ProRes422Hq, "mov"),
                (ExportFormat::ProRes4444, "mov"),
                (ExportFormat::Gif, "gif"),
                (ExportFormat::M4a, "m4a"),
                (ExportFormat::Wav, "wav"),
            ] {
                let mut o = opts_for(p.clone(), &t.dir.join(format!("{name}-{format:?}.{ext}")), None);
                o.format = format;
                // Chapters ride along on every format (containers without chapter support ignore them).
                let meta = t.dir.join("chapters.txt");
                let ch = [crate::edl::Chapter { id: "1".into(), output_time: 1.0, title: "One".into() }];
                std::fs::write(&meta, super::build_chapter_ffmetadata(&ch, len)).unwrap();
                let j = export(&t, &o, Some(&meta));
                assert!((duration(&j) - len).abs() < 0.2, "{name} {format:?} {} vs {len}", duration(&j));
                if format != ExportFormat::Gif {
                    assert_eq!(streams(&j, "audio")[0]["channels"].as_u64(), Some(channels), "{name} {format:?}");
                }
            }
        }
    }

    // -----------------------------------------------------------------------
    // Mixer: mute / solo / fades / loudness, measured on real ffmpeg output.
    // The voice source is digital silence, so everything heard is a music track.
    // -----------------------------------------------------------------------

    /// A 5 s clip with a black picture and silent stereo audio.
    fn make_silent_av(t: &Tools, name: &str) -> PathBuf {
        let path = t.dir.join(name);
        let out = Command::new(&t.ffmpeg)
            .args(["-v", "error", "-y", "-f", "lavfi", "-i", "color=c=black:s=1280x720:r=30:d=5"])
            .args(["-f", "lavfi", "-i", "anullsrc=r=48000:cl=stereo:d=5"])
            .args(["-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest"])
            .arg(&path)
            .output()
            .unwrap();
        assert!(out.status.success(), "{}", String::from_utf8_lossy(&out.stderr));
        path
    }

    /// A 5 s stereo 16-bit WAV sine at `freq`, `vol_db` relative to ffmpeg's default (-21 dBFS RMS).
    fn make_tone(t: &Tools, name: &str, freq: u32, vol_db: i32) -> PathBuf {
        let path = t.dir.join(name);
        let src = format!(
            "sine=frequency={freq}:sample_rate=48000:duration=5,volume={vol_db}dB,pan=stereo|c0=c0|c1=c0,aformat=sample_fmts=s16"
        );
        let out = Command::new(&t.ffmpeg)
            .args(["-v", "error", "-y", "-f", "lavfi", "-i", &src, "-c:a", "pcm_s16le"])
            .arg(&path)
            .output()
            .unwrap();
        assert!(out.status.success(), "{}", String::from_utf8_lossy(&out.stderr));
        path
    }

    /// RMS level in dB of `file` between `from` and `from + len` seconds (-inf for digital silence).
    fn rms_db(t: &Tools, file: &Path, from: f64, len: f64) -> f64 {
        let out = Command::new(&t.ffmpeg)
            .args(["-hide_banner", "-nostats", "-ss", &from.to_string(), "-t", &len.to_string(), "-i"])
            .arg(file)
            .args(["-af", "astats=measure_perchannel=none:measure_overall=RMS_level", "-f", "null", "-"])
            .output()
            .unwrap();
        let err = String::from_utf8_lossy(&out.stderr);
        let line = err.lines().find(|l| l.contains("RMS level dB:")).unwrap_or_else(|| panic!("astats output: {err}"));
        line.split("RMS level dB:").nth(1).unwrap().trim().parse().unwrap()
    }

    /// Run the production measurement on a written file.
    fn measure(t: &Tools, file: &Path) -> super::AudioReport {
        let out = Command::new(&t.ffmpeg).args(super::measure_args(&file.to_string_lossy())).output().unwrap();
        let err = String::from_utf8_lossy(&out.stderr);
        super::parse_audio_report(&err).unwrap_or_else(|| panic!("unparsable measurement: {err}"))
    }

    /// A WAV export of the silent voice with `tracks` mixed under it; each track
    /// is `(media file, tweak)`. The edit is 3.5 s long.
    fn mixed(
        t: &Tools,
        name: &str,
        tracks: Vec<(&Path, Box<dyn Fn(&mut AudioTrack)>)>,
        loudness: Option<f64>,
    ) -> ExportOpts {
        let voice = make_silent_av(t, &format!("voice-{name}.mp4"));
        let mut o = formatted(t, &voice, &format!("out-{name}.wav"), ExportFormat::Wav);
        o.loudness_lufs = loudness;
        for (i, (path, tweak)) in tracks.into_iter().enumerate() {
            let id = format!("t{i}");
            let mut mm = o.project.media["m"].clone();
            mm.id = id.clone();
            mm.path = path.to_string_lossy().into_owned();
            o.project.media.insert(id.clone(), mm);
            let mut track = AudioTrack { id: id.clone(), media_id: id, ..Default::default() };
            tweak(&mut track);
            o.project.audio_tracks.push(track);
        }
        o
    }

    fn out_path(o: &ExportOpts) -> PathBuf {
        PathBuf::from(&o.output_path)
    }

    #[test]
    fn a_muted_track_is_silent_and_the_unmuted_control_is_not() {
        let Some(t) = tools() else { return };
        let tone = make_tone(&t, "a.wav", 440, 0);
        let muted = mixed(&t, "muted", vec![(&tone, Box::new(|tr| tr.muted = true))], None);
        export(&t, &muted, None);
        let silent = rms_db(&t, &out_path(&muted), 0.2, 3.0);
        let control = mixed(&t, "unmuted", vec![(&tone, Box::new(|_| {}))], None);
        export(&t, &control, None);
        let heard = rms_db(&t, &out_path(&control), 0.2, 3.0);
        eprintln!("MUTE: muted={silent} dB, unmuted control={heard} dB");
        assert!(silent < -90.0, "muted track leaked: {silent}");
        assert!(heard > -30.0 && heard < -15.0, "control level {heard}");
    }

    #[test]
    fn solo_isolates_a_track_and_wins_over_mute() {
        let Some(t) = tools() else { return };
        let loud = make_tone(&t, "loud.wav", 440, 0); // about -21 dB
        let quiet = make_tone(&t, "quiet.wav", 1000, -20); // about -41 dB
        let level = |name: &str, a: fn(&mut AudioTrack), b: fn(&mut AudioTrack)| {
            let o = mixed(&t, name, vec![(&loud, Box::new(a)), (&quiet, Box::new(b))], None);
            export(&t, &o, None);
            rms_db(&t, &out_path(&o), 0.2, 3.0)
        };
        let both = level("both", |_| {}, |_| {});
        let solo_quiet = level("solo-quiet", |_| {}, |b| b.solo = true);
        let solo_loud = level("solo-loud", |a| a.solo = true, |_| {});
        let solo_and_muted = level("solo-muted", |_| {}, |b| (b.solo, b.muted) = (true, true));
        let mute_loud = level("mute-loud", |a| a.muted = true, |_| {});
        let all_muted = level("all-muted", |a| a.muted = true, |b| b.muted = true);
        eprintln!(
            "SOLO: both={both} solo(quiet)={solo_quiet} solo(loud)={solo_loud} solo+muted(quiet)={solo_and_muted} mute(loud)={mute_loud} all muted={all_muted}"
        );
        assert!((both + 21.0).abs() < 1.5, "both {both}");
        assert!((solo_loud + 21.0).abs() < 1.5, "solo loud {solo_loud}");
        assert!((solo_quiet + 41.0).abs() < 1.5, "solo quiet isolates {solo_quiet}");
        assert!((solo_and_muted + 41.0).abs() < 1.5, "solo wins over mute {solo_and_muted}");
        assert!((mute_loud + 41.0).abs() < 1.5, "mute removes only that track {mute_loud}");
        assert!(all_muted < -90.0, "{all_muted}");
    }

    #[test]
    fn fades_ramp_monotonically_in_and_out() {
        let Some(t) = tools() else { return };
        let tone = make_tone(&t, "a.wav", 440, 0);
        let faded = mixed(&t, "fade", vec![(&tone, Box::new(|a| (a.fade_in_sec, a.fade_out_sec) = (1.0, 1.0)))], None);
        export(&t, &faded, None);
        let flat = mixed(&t, "nofade", vec![(&tone, Box::new(|_| {}))], None);
        export(&t, &flat, None);
        let win = |o: &ExportOpts, from: f64| rms_db(&t, &out_path(o), from, 0.25);
        // 3.5 s edit: ramp up 0-1 s, sustain 1-2.5 s, ramp down 2.5-3.5 s.
        let up: Vec<f64> = (0..4).map(|i| win(&faded, i as f64 * 0.25)).collect();
        let hold = [win(&faded, 1.25), win(&faded, 1.75), win(&faded, 2.1)];
        let down: Vec<f64> = (0..4).map(|i| win(&faded, 2.5 + i as f64 * 0.25)).collect();
        let plain_start = win(&flat, 0.0);
        eprintln!("FADE up={up:?} hold={hold:?} down={down:?} no-fade first window={plain_start}");
        assert!(up.windows(2).all(|w| w[1] > w[0] + 1.0), "fade-in must rise: {up:?}");
        assert!(down.windows(2).all(|w| w[1] < w[0] - 1.0), "fade-out must fall: {down:?}");
        assert!(hold.iter().all(|h| (h - hold[0]).abs() < 0.5), "sustain is flat: {hold:?}");
        assert!(up[0] < hold[0] - 12.0 && down[3] < hold[0] - 12.0, "ramps start/end near silence");
        assert!(up[3] < hold[0] && down[0] <= hold[0] + 0.5);
        assert!((plain_start - hold[0]).abs() < 0.5, "without a fade the first window is already full level");
    }

    #[test]
    fn the_fade_out_follows_the_end_of_a_short_track_not_the_edit() {
        // A 5 s track delayed by 2 s into a 3.5 s edit ends at 3.5 s; its fade-out must too.
        let Some(t) = tools() else { return };
        let tone = make_tone(&t, "a.wav", 440, 0);
        let o = mixed(&t, "late", vec![(&tone, Box::new(|a| (a.offset_sec, a.fade_out_sec) = (2.0, 1.0)))], None);
        export(&t, &o, None);
        let before = rms_db(&t, &out_path(&o), 0.2, 1.5);
        let early = rms_db(&t, &out_path(&o), 2.0, 0.25);
        let late = rms_db(&t, &out_path(&o), 3.25, 0.25);
        eprintln!("FADE-OUT on delayed track: before start={before} just after start={early} last window={late}");
        assert!(before < -90.0, "silent before the delayed start");
        assert!(early > -30.0 && late < early - 3.0, "{early} then {late}");
    }

    #[test]
    fn all_inaudible_tracks_leave_the_default_argv_unchanged() {
        let Some(t) = tools() else { return };
        let src = make_av(&t, "a.mp4", "red", 440);
        let plain = formatted(&t, &src, "plain.mp4", ExportFormat::Mp4);
        let mut muted = plain.clone();
        let mut mm = muted.project.media["m"].clone();
        mm.id = "music".into();
        muted.project.media.insert("music".into(), mm);
        muted.project.audio_tracks.push(AudioTrack { id: "t".into(), media_id: "music".into(), muted: true, ..Default::default() });
        let argv = |o: &ExportOpts| build_reencode_argv(o, 3.5, None, None).unwrap();
        assert_eq!(argv(&plain), argv(&muted), "a muted track adds nothing to the graph");
        assert!(!argv(&plain).iter().any(|a| a.contains("loudnorm") || a.contains("afade")));
        let mut norm = plain.clone();
        norm.loudness_lufs = Some(-16.0);
        let graph = argv(&norm).into_iter().find(|a| a.contains("concat")).unwrap();
        assert!(graph.contains("loudnorm=I=-16:TP=-1.5:LRA=11,aresample=48000[outa_ln]"), "{graph}");
    }

    #[test]
    fn loudnorm_lands_near_the_podcast_and_streaming_targets() {
        let Some(t) = tools() else { return };
        let tone = make_tone(&t, "a.wav", 440, 0);
        let off = mixed(&t, "ln-off", vec![(&tone, Box::new(|_| {}))], None);
        export(&t, &off, None);
        let baseline = measure(&t, &out_path(&off)).integrated_lufs.unwrap();
        for target in [-16.0, -14.0] {
            let o = mixed(&t, &format!("ln{target}"), vec![(&tone, Box::new(|_| {}))], Some(target));
            export(&t, &o, None);
            let r = measure(&t, &out_path(&o));
            eprintln!("LOUDNORM target {target}: measured {r:?} (off: {baseline} LUFS)");
            assert!((r.integrated_lufs.unwrap() - target).abs() < 1.5, "{target}: {r:?}");
            assert!(r.true_peak_dbtp.unwrap() <= -0.9, "true peak under the -1.5 dBTP ceiling (+ encoder slack): {r:?}");
            assert!((baseline - target).abs() > 1.5, "the source was not already at target ({baseline})");
        }
    }

    #[test]
    fn the_report_flags_clipping_and_reports_levels() {
        let Some(t) = tools() else { return };
        let hot = make_tone(&t, "hot.wav", 440, 20); // full-scale square-ish, already clipped
        let calm = make_tone(&t, "calm.wav", 440, 0);
        let clipping = mixed(&t, "hot", vec![(&hot, Box::new(|a| a.gain_db = 12.0))], None);
        export(&t, &clipping, None);
        let hot_report = measure(&t, &out_path(&clipping));
        let fine = mixed(&t, "calm", vec![(&calm, Box::new(|_| {}))], None);
        export(&t, &fine, None);
        let calm_report = measure(&t, &out_path(&fine));
        eprintln!("REPORT clipping: {hot_report:?}\nREPORT calm: {calm_report:?}");
        assert!(hot_report.clipped && hot_report.sample_peak_db.unwrap() >= -0.1, "{hot_report:?}");
        assert!(!calm_report.clipped && (calm_report.sample_peak_db.unwrap() + 18.0).abs() < 1.0, "{calm_report:?}");
        // A sine's RMS is 3 dB under its peak; the report agrees with the direct astats reading.
        let direct = rms_db(&t, &out_path(&fine), 0.2, 3.0);
        assert!((calm_report.integrated_lufs.unwrap() - direct).abs() < 3.5, "{calm_report:?} vs rms {direct}");
    }

    #[test]
    fn the_report_parser_reads_ffmpeg_output_and_rejects_noise() {
        let sample = "[Parsed_astats_0 @ 0x1] Overall\n[Parsed_astats_0 @ 0x1] Peak level dB: -3.250000\n\
[Parsed_ebur128_1 @ 0x2] Summary:\n\n  Integrated loudness:\n    I:         -15.9 LUFS\n    Threshold: -26.0 LUFS\n\n  Loudness range:\n    LRA:         4.2 LU\n    LRA low:   -19.0 LUFS\n\n  True peak:\n    Peak:       -1.7 dBFS\n";
        let r = super::parse_audio_report(sample).unwrap();
        assert_eq!(
            r,
            super::AudioReport {
                integrated_lufs: Some(-15.9),
                loudness_range_lu: Some(4.2),
                true_peak_dbtp: Some(-1.7),
                sample_peak_db: Some(-3.25),
                clipped: false
            }
        );
        let hot = sample.replace("-3.250000", "0.000000");
        assert!(super::parse_audio_report(&hot).unwrap().clipped);
        assert!(super::parse_audio_report("no audio streams").is_none());
        // A file name (or metadata) in the banner that looks like results must not shift parsing.
        let hostile = format!(
            "Input #0, wav, from '/x/Summary: I: -1.0 LUFS LRA: 9 True peak: Peak: 5 dBFS Peak level dB: 0.0.wav':\n{sample}"
        );
        assert_eq!(super::parse_audio_report(&hostile), super::parse_audio_report(sample));
    }

    #[test]
    fn digital_silence_reports_no_numbers_instead_of_infinity() {
        let silent = "[Parsed_astats_0 @ 0x1] Peak level dB: -inf\n[Parsed_ebur128_1 @ 0x2] Summary:\n\n  Integrated loudness:\n    I:         -70.0 LUFS\n\n  Loudness range:\n    LRA:         0.0 LU\n\n  True peak:\n    Peak:       -inf dBFS\n";
        let r = super::parse_audio_report(silent).unwrap();
        assert_eq!((r.sample_peak_db, r.true_peak_dbtp, r.clipped), (None, None, false));
        assert_eq!(r.integrated_lufs, Some(-70.0));
        // Serialises as plain JSON nulls, never an error.
        let json = serde_json::to_value(super::ExportReport { audio: Some(r) }).unwrap();
        assert!(json["audio"]["truePeakDbtp"].is_null() && json["audio"]["integratedLufs"] == -70.0);
    }

    /// The real thing: a silent export measures to a usable, partly empty report.
    #[test]
    fn a_silent_export_and_a_hostile_file_name_still_measure() {
        let Some(t) = tools() else { return };
        let o = mixed(&t, "Summary: I: -3 LUFS", vec![], None);
        export(&t, &o, None);
        let r = measure(&t, &out_path(&o));
        eprintln!("SILENT REPORT: {r:?}");
        assert!(r.sample_peak_db.is_none() && r.true_peak_dbtp.is_none() && !r.clipped, "{r:?}");
        serde_json::to_string(&super::ExportReport { audio: Some(r) }).unwrap();
        // And a normal export under the same hostile name parses to its real numbers.
        let tone = make_tone(&t, "a.wav", 440, 0);
        let o = mixed(&t, "Summary: Peak level dB: 0", vec![(&tone, Box::new(|_| {}))], None);
        export(&t, &o, None);
        let r = measure(&t, &out_path(&o));
        assert!(!r.clipped && (r.sample_peak_db.unwrap() + 18.0).abs() < 1.0, "{r:?}");
    }

    #[test]
    fn loudness_targets_outside_a_sane_range_are_rejected() {
        let o = |l| ExportOpts { loudness_lufs: Some(l), ..opts_for(fixture(), Path::new("/o/a.mp4"), None) };
        assert!(super::validate(&o(-16.0), 4.0).is_ok());
        for bad in [-40.0, 0.0, f64::NAN] {
            assert!(super::validate(&o(bad), 4.0).is_err(), "{bad}");
        }
    }

    /// Level in dB of `file`'s audio in [from, from+len) after `prefilter` (e.g. a bandpass).
    fn band_rms_db(t: &Tools, file: &Path, from: f64, len: f64, prefilter: &str) -> f64 {
        let out = Command::new(&t.ffmpeg)
            .args(["-hide_banner", "-nostats", "-ss", &from.to_string(), "-t", &len.to_string(), "-i"])
            .arg(file)
            .args(["-vn", "-af", &format!("{prefilter},astats=measure_perchannel=none:measure_overall=RMS_level"), "-f", "null", "-"])
            .output()
            .unwrap();
        let err = String::from_utf8_lossy(&out.stderr);
        let line = err.lines().find(|l| l.contains("RMS level dB:")).unwrap_or_else(|| panic!("astats output: {err}"));
        line.split("RMS level dB:").nth(1).unwrap().trim().parse().unwrap()
    }

    /// Speed + hold + crossfade feed the same downstream chain as a plain cut:
    /// scene with crop, a fixed annotation and a caption on the frame, and a
    /// ducked music bed, all at the mapped output times.
    #[test]
    fn timed_clips_feed_scene_crop_overlays_captions_and_ducked_music() {
        use crate::edl::{SegmentTiming, Transition, TransitionKind};
        let Some(t) = tools() else { return };
        let voice = make_av(&t, "voice.mp4", "red", 440);
        let music = make_av(&t, "music.mp4", "black", 220);
        let mut p = project_for(&voice);
        let base = p.segments[0].clone();
        let clip = |id: &str, a: f64, b: f64, timing: SegmentTiming| Segment {
            id: id.into(),
            source_in: a,
            source_out: b,
            words: vec![],
            timing,
            ..base.clone()
        };
        p.segments = vec![
            // 2 s at 2x = output 0..1
            clip("a", 0.0, 2.0, SegmentTiming { speed: Some(2.0), ..Default::default() }),
            // 1 s then a 1 s freeze = output 1..3
            clip("b", 2.0, 3.0, SegmentTiming { hold_sec: Some(1.0), ..Default::default() }),
            // crossfade in, 2 s = output 3..5
            clip("c", 3.0, 5.0, SegmentTiming {
                transition_in: Some(Transition { kind: TransitionKind::Crossfade, duration: 0.4 }),
                ..Default::default()
            }),
        ];
        let mapped = p.output_duration();
        assert!((mapped - 5.0).abs() < 1e-9);
        let mut mm = p.media["m"].clone();
        mm.id = "music".into();
        mm.path = music.to_string_lossy().into_owned();
        p.media.insert("music".into(), mm);
        p.audio_tracks.push(AudioTrack { id: "bed".into(), media_id: "music".into(), gain_db: -6.0, offset_sec: 0.0, ducks: true, ..Default::default() });
        // Fixed annotation over the hold only (output 1.2..2.8), on the padding above the picture.
        p.annotations = Some(serde_json::json!([
            {"kind":"box","start":1.2,"end":2.8,"x":0.1,"y":0.01,"w":0.2,"h":0.07,"color":"#ffffff","filled":true}
        ]));
        let mut scene = blue_scene();
        scene.crop = Some(crate::scene::CropPx { x: 160, y: 90, w: 960, h: 540 });
        let out = t.dir.join("timed-all.mp4");
        let mut o = opts_for(p, &out, Some(scene));
        o.captions = Some(caption_export(
            r##"{"style":{"position":"bottom","boxColor":"#00ff00","boxOpacity":1,"size":60},"cues":[{"start":3.4,"end":4.6,"lines":[[{"t":"Late","s":3.4,"e":4.6}]]}]}"##,
        ));
        let (w, h) = super::final_size(&o).unwrap();
        let ass = t.dir.join("timed-caps.ass");
        let mut f = std::fs::File::create(&ass).unwrap();
        crate::captions_export::write_ass(&mut f, o.captions.as_ref().unwrap(), w, h).unwrap();
        drop(f);
        let overlay = super::prepare_overlays(&o).unwrap();
        let files = super::OverlayPaths { captions: Some(&ass), ..overlay.paths() };
        let argv = super::build_reencode_argv_opts(&o, mapped, None, files).unwrap();
        let graph = &argv[argv.iter().position(|a| a == "-filter_complex").unwrap() + 1];
        assert!(graph.contains("xfade=") && graph.contains("setpts=(PTS-STARTPTS)/2.000000"), "{graph}");
        assert!(graph.contains("sidechaincompress"), "music ducks under the voice: {graph}");
        // This is a timing/compositing/pixel test, not a VideoToolbox driver test.
        // Virtual Macs can emit a scaler-driver diagnostic even on successful encoding.
        // Use the portable encoder while retaining every duration, colour and audio assertion.
        let argv: Vec<String> = argv.into_iter()
            .filter(|a| a != "-hwaccel" && a != "videotoolbox")
            .map(|a| if a == "h264_videotoolbox" { "libx264".into() } else { a })
            .collect();
        let r = Command::new(&t.ffmpeg).args(["-v", "error"]).args(&argv).output().unwrap();
        let err = String::from_utf8_lossy(&r.stderr);
        assert!(r.status.success() && err.trim().is_empty(), "ffmpeg: {err}");

        // Duration: within one frame of the mapped length.
        let frames: f64 = Command::new(&t.ffprobe)
            .args(["-v", "error", "-count_frames", "-select_streams", "v:0", "-show_entries", "stream=nb_read_frames", "-of", "default=nw=1:nk=1"])
            .arg(&out)
            .output()
            .map(|o| String::from_utf8_lossy(&o.stdout).trim().parse().unwrap())
            .unwrap();
        assert!((frames / 30.0 - mapped).abs() <= 1.0 / 30.0 + 1e-9, "{frames} frames vs {mapped} s");
        let audio = duration(&probe_json(&t, &out));
        assert!((audio - mapped).abs() <= 0.05, "file {audio} s vs {mapped} s");

        // Scene + crop: blue padding, red picture.
        let at = |time: f64| frame_rgb(&t, &out, time, 1280, 720);
        let (early, hold, late) = (at(0.5), at(2.0), at(4.0));
        for f in [&early, &hold, &late] {
            assert!(blue(rgb_at(f, 1280, 10, 360)), "padding {:?}", rgb_at(f, 1280, 10, 360));
            assert!(red(rgb_at(f, 1280, 640, 300)), "picture {:?}", rgb_at(f, 1280, 640, 300));
        }
        // Fixed annotation (128..384 x 7..57 of the canvas) only during the hold.
        let ann = |f: &[u8]| close(rgb_at(f, 1280, 256, 30), [255, 255, 255], 30);
        assert!(ann(&hold) && !ann(&early) && !ann(&late), "annotation at 2.0 only");
        // Caption (green box at the bottom) only at its output time, after the crossfade.
        let caps = |f: &[u8]| count_in(f, (0, 1280), (500, 720), green);
        assert!(caps(&late) > 400 && caps(&early) == 0 && caps(&hold) == 0, "caption {} {} {}", caps(&early), caps(&hold), caps(&late));

        // Music bed audible (220 Hz band), voice (440 Hz) too, through the whole edit.
        let music_db = band_rms_db(&t, &out, 0.2, 4.6, "bandpass=f=220:width_type=q:w=8");
        let voice_db = band_rms_db(&t, &out, 3.5, 1.0, "bandpass=f=440:width_type=q:w=8");
        eprintln!("timed-all: frames {frames}, file {audio} s, music {music_db:.1} dB, voice {voice_db:.1} dB");
        assert!(music_db > -50.0, "music audible: {music_db}");
        assert!(voice_db > -40.0, "voice audible: {voice_db}");
    }

    // ---- Voice-over takes (overlay / insert / override) -------------------

    /// An audio-only narration take: a `freq` Hz tone, `dur` seconds, as m4a.
    fn make_take(t: &Tools, name: &str, freq: u32, dur: f64) -> PathBuf {
        let path = t.dir.join(name);
        let out = Command::new(&t.ffmpeg)
            .args(["-v", "error", "-y", "-f", "lavfi", "-i", &format!("sine=frequency={freq}:sample_rate=48000:duration={dur}")])
            .args(["-c:a", "aac"])
            .arg(&path)
            .output()
            .unwrap();
        assert!(out.status.success(), "{}", String::from_utf8_lossy(&out.stderr));
        path
    }

    fn with_take(p: &mut Project, path: &Path, dur: f64, json: serde_json::Value) {
        let mut m = p.media["m"].clone();
        m.id = "take".into();
        m.path = path.to_string_lossy().into_owned();
        m.duration = dur;
        (m.width, m.height) = (0, 0);
        p.media.insert("take".into(), m);
        let mut v = serde_json::json!({"mediaId":"take","gainDb":0.0,"ducks":false,"kind":"voiceover"});
        v.as_object_mut().unwrap().extend(json.as_object().unwrap().clone());
        p.audio_tracks.push(serde_json::from_value(v).unwrap());
    }

    const ORIGINAL: &str = "bandpass=f=300:width_type=q:w=8,bandpass=f=300:width_type=q:w=8";
    const NARRATION: &str = "bandpass=f=2000:width_type=q:w=8,bandpass=f=2000:width_type=q:w=8";

    #[test]
    fn voice_over_override_silences_the_original_only_inside_its_interval() {
        let Some(t) = tools() else { return };
        let src = make_av(&t, "orig.mp4", "red", 300);
        let take = make_take(&t, "take.m4a", 2000, 1.5);
        let mut p = project_for(&src); // 3.5 s
        with_take(&mut p, &take, 1.5, serde_json::json!({"id":"vo","offsetSec":1.0,"mode":"overlay","overrideOriginal":true}));
        let out = t.dir.join("override.wav");
        let mut o = opts_for(p, &out, None);
        o.format = ExportFormat::Wav;
        let j = export(&t, &o, None);
        assert!((duration(&j) - 3.5).abs() < 0.05, "duration unchanged: {}", duration(&j));
        let before = band_rms_db(&t, &out, 0.3, 0.5, ORIGINAL);
        let inside = band_rms_db(&t, &out, 1.1, 1.3, ORIGINAL);
        let after = band_rms_db(&t, &out, 2.7, 0.6, ORIGINAL);
        let ramp = band_rms_db(&t, &out, 0.955, 0.04, ORIGINAL);
        let take_db = band_rms_db(&t, &out, 1.1, 1.3, NARRATION);
        eprintln!("override: original before {before:.1} inside {inside:.1} after {after:.1} ramp {ramp:.1}; take {take_db:.1} dB");
        assert!(before > -35.0 && after > -35.0, "original audible outside: {before} {after}");
        assert!(inside < before - 35.0, "original silent inside: {inside} vs {before}");
        assert!(ramp < before - 1.0 && ramp > inside + 10.0, "boundary fades: {ramp}");
        assert!(take_db > -35.0, "the replacement never mutes itself: {take_db}");
    }

    #[test]
    fn voice_over_overlay_keeps_the_video_length_and_both_voices() {
        let Some(t) = tools() else { return };
        let src = make_av(&t, "orig.mp4", "red", 300);
        let take = make_take(&t, "take.m4a", 2000, 1.5);
        let mut p = project_for(&src);
        with_take(&mut p, &take, 1.5, serde_json::json!({"id":"vo","offsetSec":1.0,"mode":"overlay"}));
        let out = t.dir.join("overlay.mp4");
        let j = export(&t, &opts_for(p, &out, None), None);
        assert!((duration(&j) - 3.5).abs() < 0.1, "video timing unchanged: {}", duration(&j));
        let orig = band_rms_db(&t, &out, 1.1, 1.3, ORIGINAL);
        let take_db = band_rms_db(&t, &out, 1.1, 1.3, NARRATION);
        let none = band_rms_db(&t, &out, 2.8, 0.5, NARRATION);
        eprintln!("overlay: original {orig:.1} take {take_db:.1} after {none:.1} dB");
        assert!(orig > -35.0 && take_db > -35.0, "mixed over: {orig} {take_db}");
        assert!(none < take_db - 30.0, "the take ends with its media: {none}");
    }

    #[test]
    fn voice_over_insert_holds_the_anchor_frame_and_shifts_later_content() {
        use crate::edl::SegmentTiming;
        let Some(t) = tools() else { return };
        let a = make_av(&t, "a.mp4", "red", 300);
        let b = make_av(&t, "b.mp4", "blue", 660);
        let take = make_take(&t, "take.m4a", 2000, 1.5);
        let mut p = project_for(&a);
        let mut mb = p.media["m"].clone();
        mb.id = "b".into();
        mb.path = b.to_string_lossy().into_owned();
        p.media.insert("b".into(), mb);
        p.segments[1].media_id = "b".into();
        let original = p.output_duration(); // 3.5: red 0-1.5, blue 1.5-3.5
        // What `addVoiceOverTake` writes for an insert at the cut (output 1.5):
        // the first clip holds its last frame for the take's length.
        p.segments[0].timing = SegmentTiming { hold_sec: Some(1.5), ..Default::default() };
        with_take(&mut p, &take, 1.5, serde_json::json!({"id":"vo","offsetSec":1.5,"mode":"insert","insertSec":1.5}));
        let out = t.dir.join("insert.mp4");
        let j = export(&t, &opts_for(p, &out, None), None);
        assert!((duration(&j) - (original + 1.5)).abs() < 0.1, "original + narration: {}", duration(&j));
        let at = |time: f64| rgb_at(&frame_rgb(&t, &out, time, 1280, 720), 1280, 640, 360);
        assert!(red(at(2.2)) && red(at(2.9)), "anchor frame held: {:?} {:?}", at(2.2), at(2.9));
        assert!(blue(at(3.2)), "later picture shifted: {:?}", at(3.2));
        let take_db = band_rms_db(&t, &out, 1.6, 1.3, NARRATION);
        let held_orig = band_rms_db(&t, &out, 1.6, 1.3, ORIGINAL);
        let later_early = band_rms_db(&t, &out, 2.8, 0.15, "bandpass=f=660:width_type=q:w=8");
        let later = band_rms_db(&t, &out, 3.1, 0.3, "bandpass=f=660:width_type=q:w=8");
        eprintln!("insert: take {take_db:.1} held original {held_orig:.1} later {later_early:.1}/{later:.1} dB");
        assert!(take_db > -35.0, "narration over the hold: {take_db}");
        assert!(held_orig < take_db - 30.0, "the hold is silent under the take: {held_orig}");
        assert!(later > -35.0 && later_early < later - 25.0, "later audio moved by exactly the take: {later_early} {later}");
    }

    #[test]
    fn music_ducks_under_a_voice_over_take() {
        let Some(t) = tools() else { return };
        let src = make_silent_av(&t, "silent.mp4"); // no original voice: only the take can duck
        let music = make_av(&t, "music.mp4", "black", 220);
        let take = make_take(&t, "take.m4a", 2000, 1.5);
        let mut p = project_for(&src);
        let mut mm = p.media["m"].clone();
        mm.id = "music".into();
        mm.path = music.to_string_lossy().into_owned();
        p.media.insert("music".into(), mm);
        p.audio_tracks.push(AudioTrack { id: "bed".into(), media_id: "music".into(), gain_db: 0.0, offset_sec: 0.0, ducks: true, ..Default::default() });
        with_take(&mut p, &take, 1.5, serde_json::json!({"id":"vo","offsetSec":1.5,"mode":"overlay","ducks":true}));
        let out = t.dir.join("ducked.wav");
        let mut o = opts_for(p, &out, None);
        o.format = ExportFormat::Wav;
        export(&t, &o, None);
        let bed = "bandpass=f=220:width_type=q:w=8,bandpass=f=220:width_type=q:w=8";
        let before = band_rms_db(&t, &out, 0.3, 1.0, bed);
        let during = band_rms_db(&t, &out, 1.9, 1.0, bed);
        let take_db = band_rms_db(&t, &out, 1.9, 1.0, NARRATION);
        eprintln!("ducking: music before {before:.1} during take {during:.1} dB; take {take_db:.1} dB");
        assert!(during < before - 2.5, "music ducks under the take: {before} -> {during}");
        assert!(take_db > -35.0, "the take itself is not ducked: {take_db}");
    }

    #[test]
    fn default_argv_has_no_voice_over_stages_and_old_takes_are_suppressed_by_newer_ones() {
        let mut p = fixture();
        p.audio_tracks.push(AudioTrack { id: "bed".into(), media_id: "m".into(), gain_db: -6.0, offset_sec: 0.0, ducks: false, ..Default::default() });
        let plain = build_reencode_argv(&opts_for(p.clone(), Path::new("/o/a.mp4"), None), p.output_duration(), None, None).unwrap().join(" ");
        assert!(!plain.contains("volume='") && !plain.contains("mainvox_vo") && plain.contains("atrim=0:"), "{plain}");
        let take = |id: &str| serde_json::json!({"id":id,"mediaId":"m","gainDb":0.0,"offsetSec":0.5,"ducks":false,"kind":"voiceover","overrideOriginal":true,"sourceIn":0.25,"sourceOut":1.0});
        p.audio_tracks.push(serde_json::from_value(take("old")).unwrap());
        p.audio_tracks.push(serde_json::from_value(take("new")).unwrap());
        let argv = build_reencode_argv(&opts_for(p.clone(), Path::new("/o/a.mp4"), None), p.output_duration(), None, None).unwrap().join(" ");
        assert!(argv.contains("[mainvox]asetnsamples=n=256:p=0,volume=volume='"), "{argv}");
        assert!(argv.contains("atrim=start=0.250000:end=1.000000"), "take trim: {argv}");
        // The older take carries the newer take's envelope; the newer none.
        let chain = |label: &str| argv.split(';').find(|c| c.ends_with(&format!("[{label}]"))).unwrap().to_string();
        assert!(chain("trk_raw_1").contains("volume=volume='"), "{}", chain("trk_raw_1"));
        assert!(!chain("trk_raw_2").contains("volume=volume='"), "{}", chain("trk_raw_2"));
    }

    /// Wave-2 integration: a light browser device frame (title text on the scene),
    /// an override voice-over take and burned-in captions in one real export.
    #[test]
    fn device_frame_override_take_and_captions_export_together() {
        let Some(t) = tools() else { return };
        let src = make_av(&t, "wave2.mp4", "red", 300);
        let take = make_take(&t, "wave2-take.m4a", 2000, 1.5);
        let mut p = project_for(&src); // 3.5 s
        with_take(&mut p, &take, 1.5, serde_json::json!({"id":"vo","offsetSec":1.0,"mode":"overlay","overrideOriginal":true}));
        let mut scene = device_scene("browserOdd"); // light title bar, 1002x564
        let fr = scene.frame.clone().unwrap();
        scene.frame.as_mut().unwrap().texts[0].text = "example.com/docs".into();
        let out = t.dir.join("wave2-out.mp4");
        let mut opts = opts_for(p, &out, Some(scene));
        let cue = r#"{"start":1.0,"end":2.0,"lines":[[{"t":"Hello","s":1.0,"e":2.0}]]}"#;
        opts.captions = Some(caption_export(&format!(r##"{{"style":{{"position":"bottom","boxColor":"#00ff00","boxOpacity":1,"size":40}},"cues":[{cue}]}}"##)));
        let (w, h) = super::final_size(&opts).unwrap();
        assert_eq!((w, h), (1002, 564));
        let caps = t.dir.join(format!("wave2-caps-{}.ass", uuid::Uuid::new_v4()));
        let mut cf = std::fs::File::create(&caps).unwrap();
        crate::captions_export::write_ass(&mut cf, opts.captions.as_ref().unwrap(), w, h).unwrap();
        drop(cf);
        let files = super::prepare_overlays(&opts).unwrap();
        assert!(files.frame_text.is_some(), "the browser title is a prepared ASS file");
        let paths = super::OverlayPaths { captions: Some(&caps), ..files.paths() };
        let argv = super::build_reencode_argv_opts(&opts, 3.5, None, paths).unwrap();
        let graph = argv[argv.iter().position(|a| a == "-filter_complex").unwrap() + 1].clone();
        assert!(graph.contains("[outv]ass=filename=") && graph.contains("[scenetv]"), "title stage: {graph}");
        assert!(graph.contains("[mainvox]asetnsamples=n=256:p=0,volume=volume='"), "override envelope: {graph}");
        let argv: Vec<String> = argv.into_iter().filter(|a| a != "-hwaccel" && a != "videotoolbox").collect();
        let run = Command::new(&t.ffmpeg).args(argv).output().unwrap();
        let err = String::from_utf8_lossy(&run.stderr);
        assert!(run.status.success(), "ffmpeg: {err}");
        assert!(!err.to_lowercase().contains("error"), "no ffmpeg error: {err}");
        assert_eq!(probe(&t, &out, "stream=width,height"), "1002 564");

        // Picture: red source inside the screen, light bar, dark title text in the pill.
        let f = frame_rgb(&t, &out, 1.5, w, h);
        let (sx, sy, sw, sh) = (fr.screen.x as u32, fr.screen.y as u32, fr.screen.w as u32, fr.screen.h as u32);
        assert!(close(rgb_at(&f, w, sx + sw / 2, sy + sh / 3), [255, 0, 0], 16));
        let bar = &fr.below[0];
        assert!(close(rgb_at(&f, w, (bar.rect.x + bar.rect.w) as u32 - 30, bar.rect.y as u32 + 14), [230, 230, 233], 10));
        let pill = &fr.above[3].rect;
        let mut text_px = 0;
        for y in pill.y as u32..(pill.y + pill.h) as u32 {
            for x in pill.x as u32..(pill.x + pill.w) as u32 {
                if (rgb_at(&f, w, x, y)[0] - 244).abs() > 60 { text_px += 1; }
            }
        }
        assert!(text_px > 40, "title text should be drawn, saw {text_px} px");

        // Captions: the green box is burned in on the canvas only while the cue is up.
        let greens = |f: &[u8]| {
            let mut n = 0;
            for y in h / 2..h { for x in 0..w { if green(rgb_at(f, w, x, y)) { n += 1; } } }
            n
        };
        assert!(greens(&f) > 400, "caption box at 1.5 s: {}", greens(&f));
        assert_eq!(greens(&frame_rgb(&t, &out, 0.4, w, h)), 0, "no caption at 0.4 s");

        // Override envelope: original silent only inside [1.0, 2.5), the take heard there.
        let before = band_rms_db(&t, &out, 0.3, 0.5, ORIGINAL);
        let inside = band_rms_db(&t, &out, 1.1, 1.3, ORIGINAL);
        let after = band_rms_db(&t, &out, 2.7, 0.6, ORIGINAL);
        let take_db = band_rms_db(&t, &out, 1.1, 1.3, NARRATION);
        eprintln!("wave2: original before {before:.1} inside {inside:.1} after {after:.1}; take {take_db:.1} dB; title px {text_px}");
        assert!(before > -35.0 && after > -35.0, "original audible outside: {before} {after}");
        assert!(inside < before - 35.0, "original silent inside: {inside} vs {before}");
        assert!(take_db > -35.0, "the take is heard: {take_db}");
        drop(files);
        let _ = std::fs::remove_file(&caps);
    }

    // -----------------------------------------------------------------------
    // Media overlays and privacy masks, end to end with the real ffmpeg.
    // -----------------------------------------------------------------------

    /// A 5 s 1280x720 fine checkerboard (8 px squares) with a tone: lots of
    /// detail, so a blur shows as a collapse of local contrast.
    fn make_checker(t: &Tools) -> PathBuf {
        let path = t.dir.join("checker.mp4");
        let out = Command::new(&t.ffmpeg)
            .args(["-v", "error", "-y", "-f", "lavfi", "-i"])
            .arg("color=c=gray:s=1280x720:r=30:d=5,geq=lum='if(mod(floor(X/8)+floor(Y/8),2),220,30)':cb=128:cr=128")
            .args(["-f", "lavfi", "-i", "sine=frequency=440:duration=5"])
            .args(["-c:v", "libx264", "-crf", "8", "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest"])
            .arg(&path)
            .output()
            .unwrap();
        assert!(out.status.success(), "{}", String::from_utf8_lossy(&out.stderr));
        path
    }

    /// Mean absolute difference between horizontal neighbours in a box of a `w`-wide RGB frame.
    fn detail(f: &[u8], w: u32, x: (u32, u32), y: (u32, u32)) -> f64 {
        let (mut sum, mut n) = (0i64, 0i64);
        for yy in y.0..y.1 {
            for xx in x.0..x.1 - 1 {
                let (a, b) = (rgb_at(f, w, xx, yy), rgb_at(f, w, xx + 1, yy));
                sum += (0..3).map(|c| (a[c] - b[c]).abs() as i64).sum::<i64>();
                n += 1;
            }
        }
        sum as f64 / n as f64
    }

    fn write_png(t: &Tools, name: &str, src: &str) -> String {
        let p = t.dir.join(name);
        let out = Command::new(&t.ffmpeg).args(["-v", "error", "-y", "-f", "lavfi", "-i", src, "-frames:v", "1"]).arg(&p).output().unwrap();
        assert!(out.status.success(), "{}", String::from_utf8_lossy(&out.stderr));
        p.to_string_lossy().into_owned()
    }

    /// Source (512..704, 288..432) is masked. Zoom 2x on the centre from 1 to 4 s,
    /// then the scene crops the zoomed picture to x 320..960 of 1280.
    fn masked_zoom_crop(t: &Tools, out: &Path) -> ExportOpts {
        let source = make_checker(t);
        let mut scene = blue_scene();
        (scene.canvas_w, scene.canvas_h) = (640, 720);
        (scene.content_x, scene.content_y, scene.content_w, scene.content_h) = (0, 0, 640, 720);
        scene.radius_px = 0.0;
        scene.crop = Some(crate::scene::CropPx { x: 320, y: 0, w: 640, h: 720 });
        let mut o = opts_for(one_segment(&source), out, Some(scene));
        o.zoom_regions = vec![zoom_region(1.0, 4.0, 2.0, 0.5, 0.5, 0.0)];
        o.project.masks = Some(serde_json::json!([{"id":"k","mediaId":"m","srcStart":0,"srcEnd":5,"x":0.4,"y":0.4,"w":0.15,"h":0.2,"effect":"blur","strength":40}]));
        o
    }

    #[test]
    fn a_mask_covers_its_source_region_under_zoom_and_crop_at_every_sampled_time() {
        let Some(t) = tools() else { return };
        let out = t.dir.join("mask-zoom-crop.mp4");
        let o = masked_zoom_crop(&t, &out);
        let argv = build_reencode_argv(&o, 5., None, None).unwrap();
        let graph = &argv[argv.iter().position(|a| a == "-filter_complex").unwrap() + 1];
        // Masks run per clip on the source frames, before concat, zoom and the scene's crop.
        let (m, cat, c) = (graph.find("gblur").unwrap(), graph.find("[catv]").unwrap(), graph.find("crop=640:720:320:0").unwrap());
        assert!(m < cat && cat < c, "{graph}");
        run_export_argv(&t, &o);
        // Unzoomed: output x = source x - 320. Zoomed (window 320..960 x 180..540, 2x):
        // output = 2 * source - (960, 360). Inner boxes keep 16 px off the edges.
        for (at, inside, outside) in [
            (0.5, ((208, 368), (304, 416)), ((420, 600), (304, 416))),
            (2.5, ((96, 416), (248, 472)), ((480, 630), (248, 472))),
            (3.5, ((96, 416), (248, 472)), ((480, 630), (248, 472))),
            (4.5, ((208, 368), (304, 416)), ((420, 600), (304, 416))),
        ] {
            let f = frame_rgb(&t, &out, at, 640, 720);
            let (i, o) = (detail(&f, 640, inside.0, inside.1), detail(&f, 640, outside.0, outside.1));
            assert!(i < 8.0 && o > 40.0, "at {at}: masked detail {i:.1}, unmasked {o:.1}");
        }
    }

    #[test]
    fn a_mask_is_applied_before_an_annotation_which_stays_sharp() {
        let Some(t) = tools() else { return };
        let out = t.dir.join("mask-note.mp4");
        let source = make_checker(&t);
        let mut p = one_segment(&source);
        p.segments[0].source_out = 2.;
        p.masks = Some(serde_json::json!([{"mediaId":"m","srcStart":0,"srcEnd":2,"x":0.25,"y":0.25,"w":0.5,"h":0.5,"effect":"blur","strength":60}]));
        // A white 12 px (at 1080) outline box inside the masked area: 8 px here.
        p.annotations = Some(serde_json::json!([{"kind":"box","start":0,"end":2,"x":0.4,"y":0.4,"w":0.2,"h":0.2,"color":"#ffffff","stroke":12}]));
        let opts = opts_for(p, &out, None);
        let files = super::prepare_overlays(&opts).unwrap();
        let argv = super::build_reencode_argv_opts(&opts, 2., None, files.paths()).unwrap();
        let graph = &argv[argv.iter().position(|a| a == "-filter_complex").unwrap() + 1];
        assert!(graph.find("gblur").unwrap() < graph.find("ass=").unwrap(), "{graph}");
        let argv: Vec<_> = argv.into_iter().filter(|a| a != "-hwaccel" && a != "videotoolbox").collect();
        let r = Command::new(&t.ffmpeg).args(argv).output().unwrap();
        assert!(r.status.success(), "{}", String::from_utf8_lossy(&r.stderr));
        let f = frame_rgb(&t, &out, 1.0, 1280, 720);
        // Left edge of the box at x = 512: crisp white on the stroke, blurred grey beside it.
        let edge = rgb_at(&f, 1280, 512, 360);
        assert!(whiteish(edge), "stroke stays sharp {edge:?}");
        let beside = rgb_at(&f, 1280, 500, 360);
        assert!(!whiteish(beside) && (beside[0] - 125).abs() < 50, "masked picture beside it {beside:?}");
        assert!(detail(&f, 1280, (340, 480), (200, 300)) < 8.0, "masked area is blurred");
    }

    #[test]
    fn gif_and_stems_never_carry_unmasked_pixels() {
        let Some(t) = tools() else { return };
        let source = make_checker(&t);
        let mut p = one_segment(&source);
        p.segments[0].source_out = 2.;
        p.masks = Some(serde_json::json!([{"mediaId":"m","srcStart":0,"srcEnd":2,"x":0,"y":0,"w":0.5,"h":1,"effect":"pixelate","strength":60}]));
        let out = t.dir.join("masked.gif");
        let mut o = opts_for(p.clone(), &out, None);
        o.format = ExportFormat::Gif;
        // The palette is generated after the masks, from masked frames only.
        let argv = build_reencode_argv(&o, 2., None, None).unwrap();
        let graph = &argv[argv.iter().position(|a| a == "-filter_complex").unwrap() + 1];
        assert!(graph.find("pixelize").unwrap() < graph.find("palettegen").unwrap(), "{graph}");
        run_export_argv(&t, &o);
        let f = frame_rgb(&t, &out, 1.0, 640, 360);
        let (masked, plain) = (detail(&f, 640, (20, 300), (20, 340)), detail(&f, 640, (340, 620), (20, 340)));
        assert!(masked * 4.0 < plain, "gif: masked half {masked:.1}, other half {plain:.1}");
        // Stems are audio-only: no picture, no mask stage, no video map at all.
        let mut a = opts_for(p, &t.dir.join("stems.wav"), None);
        a.format = ExportFormat::Wav;
        a.stems = true;
        let argv = build_reencode_argv(&a, 2., None, None).unwrap();
        assert!(!argv.iter().any(|x| x.contains("pixelize") || x.contains("[outv]") || x.contains(":v]")), "{argv:?}");
        // Masks (and overlays) always disable stream copy.
        let v = opts_for(o.project.clone(), Path::new("/o/x.mp4"), None);
        assert!(!super::layers_for(&v).is_empty());
    }

    #[test]
    fn overlays_draw_in_range_at_their_place_follow_zoom_and_keep_alpha_in_prores_4444() {
        let Some(t) = tools() else { return };
        let source = make_split_source(&t);
        let red_png = write_png(&t, "red.png", "color=0xff0000:s=64x64");
        let green_png = write_png(&t, "green.png", "color=0x00ff00:s=64x64");
        let mut p = one_segment(&source);
        p.overlays = Some(serde_json::json!([
            // Fixed on the canvas over the blue padding (x < 128), 1..2 s.
            {"path": red_png, "start":1,"end":2,"x":0.01,"y":0.4,"w":0.08,"h":0.2},
            // Follows zoom: picture-relative at (0.6..0.7, 0.45..0.55), whole clip.
            {"path": green_png, "start":0,"end":5,"x":0.6,"y":0.45,"w":0.1,"h":0.1,"followZoom":true}
        ]));
        let out = t.dir.join("overlays.mp4");
        let mut o = opts_for(p.clone(), &out, Some(blue_scene()));
        o.zoom_regions = vec![zoom_region(3.0, 5.0, 2.0, 0.75, 0.5, 0.0)];
        let argv = build_reencode_argv(&o, 5., None, None).unwrap();
        let graph = &argv[argv.iter().position(|a| a == "-filter_complex").unwrap() + 1];
        assert!(graph.contains("loop=loop=-1:size=1:start=0,trim=duration=1.000000"), "a still is repeated in the graph, bounded: {graph}");
        assert!(!argv.iter().any(|a| a == "-loop"), "no input loop (a corrupt file would retry forever)");
        run_export_argv(&t, &o);
        let at = |s: f64| frame_rgb(&t, &out, s, 1280, 720);
        let (before, during, after, zoomed) = (at(0.5), at(1.5), at(2.5), at(4.0));
        let fixed = |f: &[u8]| red(rgb_at(f, 1280, 64, 360));
        assert!(!fixed(&before) && fixed(&during) && !fixed(&after), "fixed overlay only from 1 to 2 s");
        assert!(blue(rgb_at(&during, 1280, 64, 250)), "padding above the overlay");
        // Picture x 0.65 -> 128 + 0.65 * 1024 = 794; zoomed 2x on (0.75, 0.5): 0.3 -> 435.
        assert!(close(rgb_at(&before, 1280, 794, 360), [0, 255, 0], 40));
        assert!(close(rgb_at(&zoomed, 1280, 435, 360), [0, 255, 0], 40), "follow overlay zooms {:?}", rgb_at(&zoomed, 1280, 435, 360));

        // ProRes 4444 over a transparent background: a half-transparent PNG on the padding.
        let half = write_png(&t, "half.png", "color=blue:s=64x64,format=rgba,geq=r='0':g='0':b='255':a='if(lt(X,32),255,0)'");
        p.overlays = Some(serde_json::json!([{"path": half, "start":0,"end":5,"x":0.0,"y":0.4,"w":0.1,"h":0.2,"opacity":1}]));
        let out = t.dir.join("overlay-alpha.mov");
        let mut o = opts_for(p, &out, Some(transparent_scene()));
        o.format = ExportFormat::ProRes4444;
        export(&t, &o, None);
        let f = frame_rgba(&t, &out, 1280, 720);
        let px = |x: usize, y: usize| &f[(y * 1280 + x) * 4..(y * 1280 + x) * 4 + 4];
        let opaque = px(30, 360);
        assert!(opaque[3] > 240 && opaque[2] > 200 && opaque[0] < 40, "opaque half drawn into alpha {opaque:?}");
        assert!(px(100, 360)[3] < 15, "transparent half stays transparent {:?}", px(100, 360));
        assert_eq!(px(10, 100)[3], 0, "padding away from the overlay");
    }

    #[test]
    fn a_video_overlay_plays_its_own_audio_only_when_included() {
        let Some(t) = tools() else { return };
        let voice = make_silent_av(&t, "voice.mp4");
        let clip = make_av(&t, "clip.mp4", "green", 880);
        let mut p = one_segment(&voice);
        p.overlays = Some(serde_json::json!([{"path": clip.to_string_lossy(), "start":1,"end":2.5,"trimIn":0.5,"hasAudio":true,"includeAudio":true,"gainDb":-6}]));
        let out = t.dir.join("ova.wav");
        let mut o = opts_for(p.clone(), &out, None);
        o.format = ExportFormat::Wav;
        let argv = build_reencode_argv(&o, 5., None, None).unwrap();
        assert!(argv.windows(2).any(|w| w[0] == "-ss" && w[1] == "0.500000"), "{argv:?}");
        export(&t, &o, None);
        let band = "bandpass=f=880:width_type=q:w=8";
        let inside = band_rms_db(&t, &out, 1.3, 0.9, band);
        let outside = band_rms_db(&t, &out, 3.0, 1.5, band);
        assert!(inside > -40.0 && outside < -70.0, "inside {inside:.1} dB, outside {outside:.1} dB");
        // Off: the overlay is silent and an audio-only export needs no overlay input at all.
        p.overlays.as_mut().unwrap()[0]["includeAudio"] = serde_json::json!(false);
        let o = opts_for(p, &t.dir.join("ova-off.wav"), None);
        let mut o = o;
        o.format = ExportFormat::Wav;
        let argv = build_reencode_argv(&o, 5., None, None).unwrap();
        assert!(!argv.iter().any(|a| a.contains("clip.mp4")), "{argv:?}");
    }

    #[test]
    fn check_coverage_renders_a_contact_sheet_through_the_export_graph() {
        let Some(t) = tools() else { return };
        let out = t.dir.join("unused.mp4");
        let o = masked_zoom_crop(&t, &out);
        let sheet = t.dir.join("sheet.png");
        assert!(super::coverage_opts(o.clone(), "nope", &sheet).is_err(), "unknown mask refused");
        let c = super::coverage_opts(o, "k", &sheet).unwrap();
        // One place on screen (0..5 s): before (clamped), first, middle, last frames.
        assert_eq!(c.contact_sheet.as_ref().unwrap().len(), 3, "{:?}", c.contact_sheet);
        let argv = build_reencode_argv(&c, 5., None, None).unwrap();
        assert!(!argv.iter().any(|a| a.contains("outa")), "no audio graph");
        let argv: Vec<String> = argv.into_iter().filter(|a| a != "-hwaccel" && a != "videotoolbox").collect();
        let r = Command::new(&t.ffmpeg).args(&argv).output().unwrap();
        assert!(r.status.success(), "{}", String::from_utf8_lossy(&r.stderr));
        // Three 480-wide frames with 4 px gaps.
        assert_eq!(probe(&t, &sheet, "stream=width"), "1448");
    }

    /// Regression (wave-2 QA): a raw clip with ONE mask and nothing else (no scene,
    /// zoom, crop, cursor, overlays, captions) left the sheet reading `[outv]`,
    /// which nothing wrote: "concat:out:v0 has output 0 (catv) unconnected".
    #[test]
    fn coverage_sheet_for_a_raw_clip_with_only_a_mask_renders_and_shows_no_green() {
        let Some(t) = tools() else { return };
        let src = make_flash(&t, "sheet-raw.mp4", "640x360", "x=0:y=0:w=320:h=360", "between(t,1,2.95)", "", &[]);
        let sheet_for = |x: f64, name: &str| -> (PathBuf, usize) {
            let mut p = flash_project(&src);
            p.masks = Some(serde_json::json!([{"id":"k","mediaId":"m","srcStart":1,"srcEnd":3,"x":x,"y":0,"w":0.5,"h":1}]));
            let sheet = t.dir.join(name);
            let c = super::coverage_opts(opts_for(p, &t.dir.join("unused.mp4"), None), "k", &sheet).unwrap();
            run_export_argv(&t, &c);
            (sheet, c.contact_sheet.unwrap().len())
        };
        let (sheet, n) = sheet_for(0., "raw-sheet.png");
        let cols = n.min(super::COVERAGE_COLUMNS);
        assert_eq!(probe(&t, &sheet, "stream=width"), (cols * 480 + (cols - 1) * 4).to_string());
        assert_eq!(green_frames(&t, &sheet), (0, 1), "the masked left half never shows green");
        // The method sees green when the mask covers the other half.
        assert_eq!(green_frames(&t, &sheet_for(0.5, "raw-sheet-probe.png").0).0, 1);
    }

    /// Every layer combination, with and without a contact sheet and a range,
    /// builds a graph whose labels all connect: real ffmpeg runs each one.
    #[test]
    fn every_layer_combination_with_sheet_and_range_runs_in_ffmpeg() {
        let Some(t) = tools() else { return };
        let src = make_flash(&t, "combo.mp4", "320x180", "x=0:y=0:w=160:h=180", "between(t,1,3)", "", &[]);
        let ass = t.dir.join("combo.ass");
        std::fs::write(&ass, script_for("Hi")).unwrap();
        let png = write_png(&t, "combo.png", "color=0xff0000:s=16x16");
        let cases: &[&[&str]] = &[
            &[], &["mask"], &["scene"], &["device"], &["zoom"], &["cursor"], &["cursor", "mask"],
            &["overlay"], &["follow_overlay"], &["fixed"], &["follow"], &["captions"], &["keys"], &["gif"],
            &["mask", "gif"], &["mask", "zoom"], &["mask", "captions"],
            &["scene", "zoom", "cursor", "mask", "overlay", "follow_overlay", "fixed", "follow", "captions", "keys"],
        ];
        for (i, case) in cases.iter().enumerate() {
            for (sheet, range) in [(false, false), (true, false), (false, true), (true, true)] {
                let has = |f: &str| case.contains(&f);
                let mut p = flash_project(&src);
                (p.media.get_mut("m").unwrap().width, p.media.get_mut("m").unwrap().height) = (320, 180);
                if has("mask") {
                    p.masks = Some(serde_json::from_str(&format!("[{LEFT_HALF}]")).unwrap());
                }
                let ov = |follow: bool| serde_json::json!({"path": png, "start":0,"end":4,"x":0.1,"y":0.1,"w":0.1,"h":0.1,"followZoom":follow});
                let ovs: Vec<_> = [("overlay", false), ("follow_overlay", true)].iter().filter(|(f, _)| has(f)).map(|(_, z)| ov(*z)).collect();
                if !ovs.is_empty() {
                    p.overlays = Some(serde_json::Value::Array(ovs));
                }
                let scene = if has("device") {
                    let mut s = device_scene("browserOdd");
                    s.frame.as_mut().unwrap().texts[0].text = "example.com".into();
                    Some(s)
                } else {
                    has("scene").then(blue_scene)
                };
                let ext = if sheet { "png" } else if has("gif") { "gif" } else { "mp4" };
                let mut o = opts_for(p, &t.dir.join(format!("combo-{i}-{sheet}-{range}.{ext}")), scene);
                if has("gif") {
                    o.format = super::ExportFormat::Gif;
                }
                if has("zoom") {
                    o.zoom_regions = vec![zoom_region(1.0, 3.0, 2.0, 0.5, 0.5, 0.0)];
                }
                if range {
                    o.range = Some(ExportRange { start: 0.5, end: 3.5 });
                }
                if sheet {
                    o.contact_sheet = Some(vec![0.2, 1.0, 2.0]);
                }
                let files = super::prepare_overlays(&o).unwrap();
                let pick = |f: &str| has(f).then_some(ass.as_path());
                let paths = super::OverlayPaths {
                    cursor: pick("cursor"),
                    follow: pick("follow"),
                    fixed: pick("fixed"),
                    captions: pick("captions"),
                    keys: pick("keys"),
                    ..files.paths()
                };
                let argv = super::build_reencode_argv_opts(&o, 4., None, paths).unwrap();
                let argv: Vec<String> = argv.into_iter().filter(|a| a != "-hwaccel" && a != "videotoolbox").collect();
                let r = Command::new(&t.ffmpeg).args(&argv).output().unwrap();
                assert!(r.status.success(), "{case:?} sheet={sheet} range={range}: {}", String::from_utf8_lossy(&r.stderr));
            }
        }
    }

    #[test]
    fn coverage_samples_every_occurrence_with_transition_and_edge_frames() {
        let t = super::coverage_times(&[(2., 3.), (6., 7.)], 30., 0.5, 10.);
        let f = 1. / 30.;
        for want in [2. - 0.5 - f, 2., 2.5, 3. - f, 3. + 0.5, 6. - 0.5 - f, 6., 6.5, 7. - f, 7. + 0.5] {
            assert!(t.iter().any(|x| (x - want).abs() < 1e-9), "{want} in {t:?}");
        }
    }

    /// A 4 s 1280x720 clip whose left half is a fine checkerboard while `when`
    /// (a geq expression of T) holds, flat grey otherwise; right half flat.
    fn make_timed_checker(t: &Tools, name: &str, when: &str, w: u32) -> PathBuf {
        let path = t.dir.join(name);
        let out = Command::new(&t.ffmpeg)
            .args(["-v", "error", "-y", "-f", "lavfi", "-i"])
            .arg(format!("color=c=gray:s={w}x720:r=30:d=4,geq=lum='if(({when})*lt(X,W/2),if(mod(floor(X/8)+floor(Y/8),2),220,30),128)':cb=128:cr=128"))
            .args(["-f", "lavfi", "-i", "sine=frequency=440:duration=4"])
            .args(["-c:v", "libx264", "-crf", "8", "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest"])
            .arg(&path)
            .output()
            .unwrap();
        assert!(out.status.success(), "{}", String::from_utf8_lossy(&out.stderr));
        path
    }

    /// Clips [0,2] and [2,4] of `source` with a 1 s `kind` transition into the second.
    fn two_clips(source: &Path, kind: crate::edl::TransitionKind, masks: serde_json::Value) -> Project {
        let mut p = project_for(source);
        p.media.get_mut("m").unwrap().duration = 4.0;
        (p.segments[0].source_in, p.segments[0].source_out) = (0., 2.);
        (p.segments[1].source_in, p.segments[1].source_out) = (2., 4.);
        p.segments[1].timing.transition_in = Some(crate::edl::Transition { kind, duration: 1.0 });
        p.masks = Some(masks);
        p
    }

    fn left_detail(t: &Tools, out: &Path, at: f64) -> f64 {
        detail(&frame_rgb(t, out, at, 1280, 720), 1280, (20, 620), (20, 700))
    }

    #[test]
    fn masks_cover_crossfade_and_dip_frames_on_both_sides_of_a_cut() {
        use crate::edl::TransitionKind::{Crossfade, Dip};
        let Some(t) = tools() else { return };
        let left = |a: f64, b: f64| serde_json::json!([{"mediaId":"m","srcStart":a,"srcEnd":b,"x":0,"y":0,"w":0.5,"h":1,"effect":"solid"}]);
        // Content appears at 2 s and is masked from 2 s: the incoming clip's padded
        // head frames inside the crossfade (1.5..2) must already be masked.
        let late = make_timed_checker(&t, "late.mp4", "gte(T,2)", 1280);
        let unmasked = t.dir.join("x-plain.mp4");
        run_export_argv(&t, &opts_for(two_clips(&late, Crossfade, serde_json::json!([])), &unmasked, None));
        assert!(left_detail(&t, &unmasked, 1.8) > 10.0, "the probe sees the content without a mask");
        for (kind, name) in [(Crossfade, "x-in.mp4"), (Dip, "d-in.mp4")] {
            let out = t.dir.join(name);
            run_export_argv(&t, &opts_for(two_clips(&late, kind, left(2., 4.)), &out, None));
            for at in [1.6, 1.8, 1.93, 2.05, 2.3, 3.0] {
                let d = left_detail(&t, &out, at);
                assert!(d < 0.5, "{name} at {at}: masked region detail {d:.2}");
            }
        }
        // Mirror: content until 2 s, masked until 2 s: the outgoing clip's padded tail.
        let early = make_timed_checker(&t, "early.mp4", "lt(T,2)", 1280);
        for (kind, name) in [(Crossfade, "x-out.mp4"), (Dip, "d-out.mp4")] {
            let out = t.dir.join(name);
            run_export_argv(&t, &opts_for(two_clips(&early, kind, left(0., 2.)), &out, None));
            for at in [1.0, 1.9, 2.07, 2.2, 2.4] {
                let d = left_detail(&t, &out, at);
                assert!(d < 0.5, "{name} at {at}: masked region detail {d:.2}");
            }
        }
    }

    #[test]
    fn every_copy_of_masked_footage_is_masked_including_a_tiny_mask_at_4x() {
        let Some(t) = tools() else { return };
        let source = make_checker(&t);
        // The same source range twice (a duplicated clip): both copies masked.
        let mut p = project_for(&source);
        (p.segments[0].source_in, p.segments[0].source_out) = (0., 2.);
        (p.segments[1].source_in, p.segments[1].source_out) = (0., 2.);
        p.masks = Some(serde_json::json!([{"mediaId":"m","srcStart":0,"srcEnd":2,"x":0,"y":0,"w":0.5,"h":1}]));
        let out = t.dir.join("dup.mp4");
        run_export_argv(&t, &opts_for(p, &out, None));
        for at in [1.0, 3.0] {
            let f = frame_rgb(&t, &out, at, 1280, 720);
            let (m, u) = (detail(&f, 1280, (20, 620), (20, 700)), detail(&f, 1280, (660, 1260), (20, 700)));
            assert!(m < 0.5 && u > 40.0, "copy at {at}: masked {m:.2}, other half {u:.2}");
        }
        // 0.11 s of source on a 4x clip (0.0275 s on screen). The source is grey with
        // green frames only in 1.0..1.1 s; without the mask green shows, with it never.
        let flash = t.dir.join("flash.mp4");
        let made = Command::new(&t.ffmpeg)
            .args(["-v", "error", "-y", "-f", "lavfi", "-i"])
            .arg("color=c=gray:s=1280x720:r=30:d=4,drawbox=x=0:y=0:w=iw:h=ih:color=0x00ff00:t=fill:enable='between(t,0.99,1.11)'")
            .args(["-f", "lavfi", "-i", "sine=frequency=440:duration=4"])
            .args(["-c:v", "libx264", "-crf", "8", "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest"])
            .arg(&flash)
            .output()
            .unwrap();
        assert!(made.status.success());
        let greens = |out: &Path| {
            (0..29).filter(|k| green(rgb_at(&frame_rgb(&t, out, *k as f64 / 30.0 + 0.001, 1280, 720), 1280, 640, 360))).count()
        };
        let fast = |masks: serde_json::Value, name: &str| {
            let mut p = one_segment(&flash);
            p.media.get_mut("m").unwrap().duration = 4.;
            p.segments[0].source_out = 4.;
            p.segments[0].timing.speed = Some(4.);
            p.masks = Some(masks);
            let out = t.dir.join(name);
            run_export_argv(&t, &opts_for(p, &out, None));
            out
        };
        assert!(greens(&fast(serde_json::json!([]), "fast-plain.mp4")) > 0, "the probe shows the flash unmasked");
        let out = fast(serde_json::json!([{"mediaId":"m","srcStart":1.0,"srcEnd":1.11,"x":0,"y":0,"w":1,"h":1,"color":"#ff0000"}]), "fast.mp4");
        assert_eq!(greens(&out), 0, "a 0.11 s mask at 4x (under one output frame) leaves no unmasked frame");
    }

    #[test]
    fn a_mask_is_placed_on_its_own_source_when_sources_differ_in_aspect() {
        let Some(t) = tools() else { return };
        let wide = make_timed_checker(&t, "wide.mp4", "1", 1280);
        let narrow = make_timed_checker(&t, "narrow.mp4", "1", 960);
        let mut p = project_for(&wide);
        (p.segments[0].source_in, p.segments[0].source_out) = (0., 2.);
        (p.segments[1].source_in, p.segments[1].source_out) = (0., 2.);
        let mut m2 = p.media["m"].clone();
        (m2.id, m2.path, m2.width, m2.sha256) = ("m2".into(), narrow.to_string_lossy().into_owned(), 960, "another-file".into());
        p.media.insert("m2".into(), m2);
        p.segments[1].media_id = "m2".into();
        // The 4:3 source's left half (its checker): x 0..480 of 960, pillarboxed to 160..640.
        p.masks = Some(serde_json::json!([{"mediaId":"m2","srcStart":0,"srcEnd":2,"x":0,"y":0,"w":0.5,"h":1}]));
        let out = t.dir.join("aspect.mp4");
        let mut o = opts_for(p, &out, None);
        (o.width, o.height) = (Some(1280), Some(720));
        run_export_argv(&t, &o);
        let first = frame_rgb(&t, &out, 1.0, 1280, 720);
        assert!(detail(&first, 1280, (20, 620), (20, 700)) > 40.0, "the 16:9 source is not masked");
        let second = frame_rgb(&t, &out, 3.0, 1280, 720);
        let d = detail(&second, 1280, (164, 636), (20, 700));
        assert!(d < 0.5, "the 4:3 source's masked half, where it is on screen: {d:.2}");
        assert!(rgb_at(&second, 1280, 400, 360).iter().all(|c| *c < 40), "solid black there");
    }

    #[test]
    fn the_cursor_is_hidden_inside_a_mask_and_key_caps_are_suppressed() {
        let Some(t) = tools() else { return };
        let source = make_source(&t);
        let mut p = one_segment(&source);
        p.segments[0].source_out = 2.;
        p.masks = Some(serde_json::json!([{"mediaId":"m","srcStart":0,"srcEnd":2,"x":0.4,"y":0.4,"w":0.2,"h":0.2,"color":"#0000ff"}]));
        let mut opts = opts_for(p, &t.dir.join("cursor-mask.mp4"), None);
        opts.draw_cursor = true;
        opts.project.cursor = Some(serde_json::json!({
            "style":{"shape":"dot","size":96,"color":"#00ff00","smoothing":0,"clickEffect":"none"},
            "tracks":{"m":{"events":[{"type":"move","t":0,"x":0.5,"y":0.5},{"type":"key","t":1.0,"mods":["cmd"]}]}}
        }));
        opts.project.keystrokes = Some(serde_json::json!({"enabled":true}));
        assert!(crate::annotations_export::keystroke_captions(&opts.project).is_empty(), "no key caps under a mask");
        let config: crate::cursor_export::CursorConfig = serde_json::from_value(opts.project.cursor.clone().unwrap()).unwrap();
        let activity = super::CursorArtifact(t.dir.join("activity.ass"));
        let mut file = std::fs::File::create(&activity.0).unwrap();
        crate::cursor_export::write_ass(&mut file, &config, &opts.project, 1280, 720, 30., || false).unwrap();
        drop(file);
        let argv = build_reencode_argv(&opts, 2., None, Some(&activity.0)).unwrap();
        let graph = &argv[argv.iter().position(|a| a == "-filter_complex").unwrap() + 1];
        assert!(graph.find("ass=").unwrap() < graph.find("cmk").unwrap(), "masks again after the cursor: {graph}");
        let argv: Vec<_> = argv.into_iter().filter(|a| a != "-hwaccel" && a != "videotoolbox").collect();
        let r = Command::new(&t.ffmpeg).args(argv).output().unwrap();
        assert!(r.status.success(), "{}", String::from_utf8_lossy(&r.stderr));
        let f = frame_rgb(&t, Path::new(&opts.output_path), 1., 1280, 720);
        assert!(blue(rgb_at(&f, 1280, 640, 360)), "the cursor inside the mask is covered {:?}", rgb_at(&f, 1280, 640, 360));
    }

    // -----------------------------------------------------------------------
    // Second privacy review: grey sources with a green box only inside the
    // masked span; an export must contain no frame with green in it.
    // -----------------------------------------------------------------------

    /// A grey `size` 30 fps 4 s clip with a tone and a green box (`drawbox` x:y:w:h)
    /// while `when` holds; `post` filters run after (e.g. transpose); `out` adds output options.
    fn make_flash(t: &Tools, name: &str, size: &str, boxed: &str, when: &str, post: &str, out: &[&str]) -> PathBuf {
        let path = t.dir.join(name);
        let r = Command::new(&t.ffmpeg)
            .args(["-v", "error", "-y", "-f", "lavfi", "-i"])
            .arg(format!("color=c=gray:s={size}:r=30:d=4,drawbox={boxed}:color=0x00ff00:t=fill:enable='{when}'{post}"))
            .args(["-f", "lavfi", "-i", "sine=frequency=440:duration=4"])
            .args(["-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest"])
            .args(out)
            .arg(&path)
            .output()
            .unwrap();
        assert!(r.status.success(), "{}", String::from_utf8_lossy(&r.stderr));
        path
    }

    /// (frames with a strongly green pixel on an 8 px grid, frames in total).
    fn green_frames(t: &Tools, file: &Path) -> (usize, usize) {
        let dims = probe(t, file, "stream=width,height");
        let mut it = dims.split_whitespace().map(|v| v.parse::<usize>().unwrap());
        let (w, h) = (it.next().unwrap(), it.next().unwrap());
        let out = Command::new(&t.ffmpeg).args(["-v", "error", "-i"]).arg(file).args(["-f", "rawvideo", "-pix_fmt", "rgb24", "-"]).output().unwrap();
        assert!(out.status.success());
        let frames: Vec<&[u8]> = out.stdout.chunks(w * h * 3).collect();
        let is_green = |f: &[u8]| (0..h).step_by(8).any(|y| (0..w).step_by(8).any(|x| {
            let i = (y * w + x) * 3;
            f[i + 1] > 180 && f[i] < 90 && f[i + 2] < 90
        }));
        (frames.iter().filter(|f| is_green(f)).count(), frames.len())
    }

    fn export_plain(t: &Tools, p: Project, name: &str, tweak: impl FnOnce(&mut ExportOpts)) -> PathBuf {
        let out = t.dir.join(name);
        let mut o = opts_for(p, &out, None);
        tweak(&mut o);
        run_export_argv(t, &o);
        out
    }

    fn flash_project(src: &Path) -> Project {
        let mut p = one_segment(src);
        p.media.get_mut("m").unwrap().duration = 4.;
        p.segments[0].source_out = 4.;
        p
    }

    const LEFT_HALF: &str = r#"{"mediaId":"m","srcStart":1,"srcEnd":3,"x":0,"y":0,"w":0.5,"h":1}"#;

    #[test]
    fn the_same_file_imported_twice_is_masked_in_both_media_items() {
        let Some(t) = tools() else { return };
        let src = make_flash(&t, "twice.mp4", "640x360", "x=0:y=0:w=320:h=360", "between(t,1,3)", "", &[]);
        let mut p = flash_project(&src);
        p.media.get_mut("m").unwrap().sha256 = "ab".repeat(32);
        let mut m2 = p.media["m"].clone();
        m2.id = "m2".into();
        p.media.insert("m2".into(), m2);
        let mut second = p.segments[0].clone();
        second.id = "s2".into();
        second.media_id = "m2".into();
        p.segments.push(second);
        p.masks = Some(serde_json::from_str(&format!("[{LEFT_HALF}]")).unwrap());
        let (green, total) = green_frames(&t, &export_plain(&t, p, "twice-out.mp4", |_| {}));
        assert_eq!((green, total), (0, 240), "no green in either copy");
    }

    #[test]
    fn a_rotated_clip_with_stale_stored_size_is_masked_on_its_decoded_frame() {
        let Some(t) = tools() else { return };
        // Portrait 360x640 content (green top half 1..3 s), stored as landscape + rotation.
        let land = make_flash(&t, "land.mp4", "360x640", "x=0:y=0:w=iw:h=ih/2", "between(t,1,3)", ",transpose=2", &[]);
        let rotated = t.dir.join("rotated.mp4");
        let r = Command::new(&t.ffmpeg).args(["-v", "error", "-y", "-display_rotation:v:0", "-90", "-i"]).arg(&land).args(["-c", "copy"]).arg(&rotated).output().unwrap();
        assert!(r.status.success(), "{}", String::from_utf8_lossy(&r.stderr));
        let mut p = flash_project(&rotated);
        // What a v4.28 build stored for this clip: the landscape size.
        (p.media.get_mut("m").unwrap().width, p.media.get_mut("m").unwrap().height) = (640, 360);
        p.masks = Some(serde_json::json!([{"mediaId":"m","srcStart":1,"srcEnd":3,"x":0,"y":0,"w":1,"h":0.5}]));
        let out = export_plain(&t, p, "rotated-out.mp4", |_| {});
        assert_eq!(probe(&t, &out, "stream=width,height"), "360 640", "exported upright");
        assert_eq!(green_frames(&t, &out).0, 0);
    }

    #[test]
    fn an_overlay_of_masked_footage_is_masked_too() {
        let Some(t) = tools() else { return };
        let src = make_flash(&t, "inset.mp4", "640x360", "x=0:y=0:w=320:h=360", "between(t,1,3)", "", &[]);
        let mut p = flash_project(&src);
        // Mask the source's left half 1..3 s, then grey it out in the main picture
        // too, and show the same file as a magnified inset from 0 to 3 s.
        p.masks = Some(serde_json::from_str(&format!("[{LEFT_HALF}]")).unwrap());
        p.overlays = Some(serde_json::json!([{"path": src.to_string_lossy(), "start":0,"end":3,"x":0.5,"y":0.5,"w":0.45,"h":0.45}]));
        let out = export_plain(&t, p, "inset-out.mp4", |o| o.range = Some(super::ExportRange { start: 0., end: 3. }));
        assert_eq!(green_frames(&t, &out), (0, 90), "no green in 90 frames, inset included");
    }

    #[test]
    fn variable_frame_rate_holds_of_a_masked_frame_stay_masked() {
        let Some(t) = tools() else { return };
        // VFR: frames between 1.95 and 3.0 s dropped, so the last green frame (~1.93 s)
        // stays on screen until 3 s, past the mask's end (2 s).
        let vfr = make_flash(&t, "vfr.mp4", "640x360", "x=0:y=0:w=320:h=360", "between(t,1,2)",
            ",select='not(between(t,1.95,3))'", &["-fps_mode", "vfr"]);
        let mk = || serde_json::json!([{"mediaId":"m","srcStart":1,"srcEnd":2,"x":0,"y":0,"w":0.5,"h":1}]);
        let mut p = flash_project(&vfr);
        p.masks = Some(mk());
        assert_eq!(green_frames(&t, &export_plain(&t, p.clone(), "vfr-plain.mp4", |_| {})).0, 0, "plain cut");
        // Constant-rate output paths (speed, export rate, cursor/zoom stage) duplicate the held frame.
        p.segments[0].timing.speed = Some(2.);
        assert_eq!(green_frames(&t, &export_plain(&t, p.clone(), "vfr-fast.mp4", |_| {})).0, 0, "2x");
        p.segments[0].timing.speed = None;
        let out = export_plain(&t, p, "vfr-zoom.mp4", |o| {
            o.zoom_regions = vec![zoom_region(0.5, 3.5, 1.5, 0.5, 0.5, 0.)];
            o.fps = Some(30.);
        });
        assert_eq!(green_frames(&t, &out).0, 0, "zoom + export fps");
    }

    #[test]
    fn mask_speed_crossfade_and_a_custom_export_rate_export_without_leaking() {
        use crate::edl::TransitionKind::Crossfade;
        let Some(t) = tools() else { return };
        let src = make_flash(&t, "xs.mp4", "640x360", "x=0:y=0:w=320:h=360", "between(t,2,4)", "", &[]);
        let mut p = two_clips(&src, Crossfade, serde_json::json!([{"mediaId":"m","srcStart":2,"srcEnd":4,"x":0,"y":0,"w":0.5,"h":1}]));
        p.segments[0].timing.speed = Some(2.);
        let out = export_plain(&t, p, "xs-out.mp4", |o| o.fps = Some(24.));
        let (green, total) = green_frames(&t, &out);
        assert!(total > 40, "exported {total} frames");
        assert_eq!(green, 0);
    }

    #[test]
    fn a_mask_on_a_source_without_a_size_refuses_the_export() {
        let mut p = fixture();
        p.media.get_mut("m").unwrap().width = 0;
        p.masks = Some(serde_json::json!([{"mediaId":"m","srcStart":0,"srcEnd":1}]));
        let err = build_reencode_argv(&opts_for(p, Path::new("/o/x.mp4"), None), 4., None, None).unwrap_err();
        assert!(err.contains("picture size is unknown"), "{err}");
    }

    #[test]
    fn coverage_samples_every_place_up_to_twelve_and_the_sheet_is_private() {
        let spans: Vec<(f64, f64)> = (0..13).map(|i| (i as f64 * 10., i as f64 * 10. + 2.)).collect();
        let t13 = super::coverage_times(&spans, 30., 0., 200.);
        assert!(t13.iter().all(|x| *x < 60.), "13 places: the first 6");
        let t12 = super::coverage_times(&spans[..12], 30., 0., 200.);
        assert!(t12.iter().any(|x| (*x - 111.).abs() < 1e-9), "12 places: all of them");
        assert_eq!((super::coverage_places(12), super::coverage_places(13)), (12, 6));
        let Some(t) = tools() else { return };
        use std::os::unix::fs::PermissionsExt;
        let (dir, guard) = super::private_sheet().unwrap();
        let sheet = guard.0.clone();
        let o = super::coverage_opts(masked_zoom_crop(&t, &t.dir.join("u.mp4")), "k", &sheet).unwrap();
        let argv: Vec<String> = build_reencode_argv(&o, 5., None, None).unwrap().into_iter().filter(|a| a != "-hwaccel" && a != "videotoolbox").collect();
        assert!(Command::new(&t.ffmpeg).args(&argv).output().unwrap().status.success());
        assert_eq!(std::fs::metadata(&dir.0).unwrap().permissions().mode() & 0o777, 0o700);
        assert_eq!(std::fs::metadata(&sheet).unwrap().permissions().mode() & 0o777, 0o600);
        assert!(std::fs::metadata(&sheet).unwrap().len() > 1000);
        let path = dir.0.clone();
        drop(dir);
        assert!(!path.exists(), "the folder is removed with the sheet");
    }

    // -----------------------------------------------------------------------
    // Third privacy review: a variable-rate frame from BEFORE a mask that stays
    // on screen into it (secret appears, then the screen is static).
    // -----------------------------------------------------------------------

    /// VFR source: green box from 0.9 s, frames between 0.95 s and 3.0 s dropped,
    /// so the green frame at ~0.93 s is on screen until 3.0 s.
    fn pre_span_hold(t: &Tools) -> PathBuf {
        make_flash(&t, "pre-hold.mp4", "640x360", "x=0:y=0:w=320:h=360", "between(t,0.9,3)",
            ",select='not(between(t,0.95,3))'", &["-fps_mode", "vfr"])
    }

    #[test]
    fn a_variable_rate_frame_held_into_a_mask_is_masked_where_it_is_on_screen() {
        use crate::edl::TransitionKind::Crossfade;
        let Some(t) = tools() else { return };
        let src = pre_span_hold(&t);
        let mk = || serde_json::json!([{"mediaId":"m","srcStart":1.0,"srcEnd":3.5,"x":0,"y":0,"w":0.5,"h":1}]);
        let mut p = flash_project(&src);
        p.masks = Some(mk());
        // Counted from 1.0 s on (before 1 s the green is legitimately unmasked).
        let after_one = |out: &Path, from: f64| {
            let cut = t.dir.join(format!("{}-tail.mp4", out.file_stem().unwrap().to_string_lossy()));
            let r = Command::new(&t.ffmpeg).args(["-v", "error", "-y", "-ss", &from.to_string(), "-i"]).arg(out).args(["-c:v", "libx264", "-crf", "8"]).arg(&cut).output().unwrap();
            assert!(r.status.success());
            green_frames(&t, &cut)
        };
        let plain = export_plain(&t, p.clone(), "pre-plain.mp4", |_| {});
        assert_eq!(after_one(&plain, 1.02).0, 0, "plain cut");
        let rate = export_plain(&t, p.clone(), "pre-30.mp4", |o| o.fps = Some(30.));
        assert_eq!(after_one(&rate, 1.02).0, 0, "30 fps export");
        let mut fast = p.clone();
        fast.segments[0].timing.speed = Some(2.);
        let out = export_plain(&t, fast, "pre-2x.mp4", |_| {});
        assert_eq!(after_one(&out, 0.52).0, 0, "2x");
        // A crossfade into a second clip of the same footage, with a custom rate.
        let mut x = two_clips(&src, Crossfade, mk());
        (x.segments[0].source_in, x.segments[0].source_out) = (0., 2.);
        (x.segments[1].source_in, x.segments[1].source_out) = (2., 4.);
        let out = export_plain(&t, x, "pre-x.mp4", |o| o.fps = Some(24.));
        assert_eq!(after_one(&out, 1.02).0, 0, "crossfade at 24 fps");
        // The unmasked probe does show the held green inside the span.
        let mut bare = flash_project(&src);
        bare.masks = Some(serde_json::json!([]));
        let none = export_plain(&t, bare, "pre-none.mp4", |o| o.fps = Some(30.));
        assert!(after_one(&none, 1.02).0 > 30, "the probe leaks without a mask");
    }

    #[test]
    fn an_old_media_item_without_a_checksum_and_a_new_import_of_its_path_are_one_file() {
        let Some(t) = tools() else { return };
        let src = make_flash(&t, "nosha.mp4", "640x360", "x=0:y=0:w=320:h=360", "between(t,1,3)", "", &[]);
        let mut p = flash_project(&src);
        p.media.get_mut("m").unwrap().sha256 = String::new(); // saved before hashing
        let mut m2 = p.media["m"].clone();
        (m2.id, m2.sha256) = ("m2".into(), "ab".repeat(32)); // imported again today
        p.media.insert("m2".into(), m2);
        let mut second = p.segments[0].clone();
        (second.id, second.media_id) = ("s2".into(), "m2".into());
        p.segments.push(second);
        p.masks = Some(serde_json::from_str(&format!("[{LEFT_HALF}]")).unwrap());
        assert_eq!(green_frames(&t, &export_plain(&t, p, "nosha-out.mp4", |_| {})), (0, 240));
    }

    #[test]
    fn the_cursor_pass_places_masks_on_the_decoded_frame_despite_a_stale_size() {
        let Some(t) = tools() else { return };
        let land = make_flash(&t, "cland.mp4", "360x640", "x=0:y=0:w=iw:h=ih", "between(t,1,3)", ",transpose=2", &[]);
        let rotated = t.dir.join("crot.mp4");
        let r = Command::new(&t.ffmpeg).args(["-v", "error", "-y", "-display_rotation:v:0", "-90", "-i"]).arg(&land).args(["-c", "copy"]).arg(&rotated).output().unwrap();
        assert!(r.status.success());
        let mut p = flash_project(&rotated);
        (p.media.get_mut("m").unwrap().width, p.media.get_mut("m").unwrap().height) = (640, 360); // stale
        p.masks = Some(serde_json::json!([{"mediaId":"m","srcStart":1,"srcEnd":3,"x":0,"y":0,"w":1,"h":1,"color":"#ff0000"}]));
        let mut opts = opts_for(p, &t.dir.join("crot-out.mp4"), None);
        opts.draw_cursor = true;
        opts.project.cursor = Some(serde_json::json!({
            "style":{"shape":"dot","size":160,"color":"#00ff00","smoothing":0,"clickEffect":"none"},
            "tracks":{"m":{"events":[{"type":"move","t":0,"x":0.5,"y":0.5}]}}
        }));
        let config: crate::cursor_export::CursorConfig = serde_json::from_value(opts.project.cursor.clone().unwrap()).unwrap();
        let activity = super::CursorArtifact(t.dir.join("crot.ass"));
        let mut file = std::fs::File::create(&activity.0).unwrap();
        crate::cursor_export::write_ass(&mut file, &config, &opts.project, 360, 640, 30., || false).unwrap();
        drop(file);
        let argv = build_reencode_argv(&opts, 4., None, Some(&activity.0)).unwrap();
        let graph = &argv[argv.iter().position(|a| a == "-filter_complex").unwrap() + 1];
        assert!(graph.contains("[cmk0_b]crop=w='"), "cursor pass from the decoded size: {graph}");
        let argv: Vec<_> = argv.into_iter().filter(|a| a != "-hwaccel" && a != "videotoolbox").collect();
        let r = Command::new(&t.ffmpeg).args(argv).output().unwrap();
        assert!(r.status.success(), "{}", String::from_utf8_lossy(&r.stderr));
        let out = t.dir.join("crot-out.mp4");
        // Within 1..3 s the cursor (green) is under the mask; outside it shows.
        let tail = t.dir.join("crot-mid.mp4");
        let r = Command::new(&t.ffmpeg).args(["-v", "error", "-y", "-ss", "1.05", "-t", "1.9", "-i"]).arg(&out).args(["-c:v", "libx264", "-crf", "8"]).arg(&tail).output().unwrap();
        assert!(r.status.success());
        assert_eq!(green_frames(&t, &tail).0, 0, "cursor hidden inside the mask");
        let early = frame_rgb(&t, &out, 0.5, 360, 640);
        assert!(green(rgb_at(&early, 360, 180, 320)), "the cursor shows outside the mask {:?}", rgb_at(&early, 360, 180, 320));
    }

    #[test]
    fn a_recording_overwritten_at_the_same_path_and_imported_again_is_masked() {
        let Some(t) = tools() else { return };
        let src = make_flash(&t, "samepath.mp4", "640x360", "x=0:y=0:w=320:h=360", "between(t,1,3)", "", &[]);
        let mut p = flash_project(&src);
        p.media.get_mut("m").unwrap().sha256 = "aa".repeat(32); // stale: the old recording
        let mut m2 = p.media["m"].clone();
        (m2.id, m2.sha256) = ("m2".into(), "bb".repeat(32)); // the new import, same path
        p.media.insert("m2".into(), m2);
        let mut second = p.segments[0].clone();
        (second.id, second.media_id) = ("s2".into(), "m2".into());
        p.segments.push(second);
        p.masks = Some(serde_json::from_str(&format!("[{LEFT_HALF}]")).unwrap());
        assert_eq!(green_frames(&t, &export_plain(&t, p, "samepath-out.mp4", |_| {})), (0, 240));
    }

    #[test]
    fn dim_surround_dims_a_variable_rate_frame_held_into_the_mask_once() {
        let Some(t) = tools() else { return };
        // Green left half from 0.9 s, held (VFR) until 3 s; the mask keeps the RIGHT
        // half bright from 1.0 s, so the green left half is the dimmed surround.
        let src = pre_span_hold(&t);
        let mut p = flash_project(&src);
        p.masks = Some(serde_json::json!([{"mediaId":"m","srcStart":1.0,"srcEnd":3.5,"x":0.5,"y":0,"w":0.5,"h":1,"effect":"dim","strength":80}]));
        let out = export_plain(&t, p, "dim-hold.mp4", |o| o.fps = Some(30.));
        let before = rgb_at(&frame_rgb(&t, &out, 0.95, 640, 360), 640, 160, 180);
        assert!(green(before), "bright green before the mask {before:?}");
        for at in [1.2, 1.6, 2.5] {
            let c = rgb_at(&frame_rgb(&t, &out, at, 640, 360), 640, 160, 180);
            assert!(c[1] < 110 && c[1] > 30, "dimmed once (twice would be ~10) at {at}: {c:?}");
            let bright = rgb_at(&frame_rgb(&t, &out, at, 640, 360), 640, 480, 180);
            assert!(bright[0] > 100, "the highlighted region stays bright {bright:?}");
        }
    }

    // -----------------------------------------------------------------------
    // Wave-2 final integration: privacy masks with device frames, voice-over
    // takes and clip ops, end to end with the real ffmpeg.
    // -----------------------------------------------------------------------

    /// Masked flash source behind a light browser frame (title text), a 2x zoom
    /// from 1 to 3 s and a scene crop; `masked` adds a solid mask over the box.
    fn device_zoom_crop_mask(t: &Tools, out: &Path, masked: bool) -> ExportOpts {
        let src = make_flash(t, "w2f-dev.mp4", "1280x720", "x=320:y=180:w=640:h=360", "gte(t,0)", "", &[]);
        let mut p = flash_project(&src);
        if masked {
            p.masks = Some(serde_json::json!([{"id":"k","mediaId":"m","srcStart":0,"srcEnd":4,"x":0.2,"y":0.2,"w":0.6,"h":0.6,"effect":"solid"}]));
        }
        let mut scene = device_scene("browserOdd");
        scene.frame.as_mut().unwrap().texts[0].text = "example.com/secret".into();
        scene.crop = Some(crate::scene::CropPx { x: 160, y: 90, w: 960, h: 540 });
        let mut o = opts_for(p, out, Some(scene));
        o.zoom_regions = vec![zoom_region(1.0, 3.0, 2.0, 0.5, 0.5, 0.0)];
        o
    }

    /// Runs the full graph with every prepared overlay file (device title included).
    fn run_with_overlays(t: &Tools, o: &ExportOpts) -> String {
        let files = super::prepare_overlays(o).unwrap();
        let argv = super::build_reencode_argv_opts(o, o.project.output_duration(), None, files.paths()).unwrap();
        let graph = argv[argv.iter().position(|a| a == "-filter_complex").unwrap() + 1].clone();
        let argv: Vec<String> = argv.into_iter().filter(|a| a != "-hwaccel" && a != "videotoolbox").collect();
        let run = Command::new(&t.ffmpeg).args(argv).output().unwrap();
        assert!(run.status.success(), "ffmpeg: {}", String::from_utf8_lossy(&run.stderr));
        graph
    }

    #[test]
    fn a_mask_stays_on_the_source_picture_under_a_device_frame_zoom_and_crop() {
        let Some(t) = tools() else { return };
        // Sanity: without the mask the green box is in every frame.
        let bare = t.dir.join("w2f-dev-bare.mp4");
        run_with_overlays(&t, &device_zoom_crop_mask(&t, &bare, false));
        let (g, n) = green_frames(&t, &bare);
        assert!(n >= 115 && g == n, "unmasked: green in {g} of {n}");

        let out = t.dir.join("w2f-dev-masked.mp4");
        let o = device_zoom_crop_mask(&t, &out, true);
        let graph = run_with_overlays(&t, &o);
        // Order: per-clip mask (source frames) -> concat -> zoom -> scene crop -> device title.
        let at = |s: &str| graph.find(s).unwrap_or_else(|| panic!("{s} missing: {graph}"));
        let (mask, cat, zoom, crop, title) = (at("[cm0]"), at("[catv]"), at("[zoomv]"), at("crop=960:540:160:90"), at("[scenetv]"));
        assert!(mask < cat && cat < zoom && zoom < crop && crop < title, "{graph}");
        let (g, n) = green_frames(&t, &out);
        assert_eq!((g, n.min(115)), (0, 115), "no green frame of {n}");

        // The device title is still drawn (dark text in the light address pill).
        let (w, h) = super::final_size(&o).unwrap();
        let pill = &o.scene.as_ref().unwrap().frame.as_ref().unwrap().above[3].rect;
        for when in [0.5, 2.0] {
            let f = frame_rgb(&t, &out, when, w, h);
            let mut text_px = 0;
            for y in pill.y as u32..(pill.y + pill.h) as u32 {
                for x in pill.x as u32..(pill.x + pill.w) as u32 {
                    if (rgb_at(&f, w, x, y)[0] - 244).abs() > 60 {
                        text_px += 1;
                    }
                }
            }
            assert!(text_px > 40, "title text at {when}: {text_px} px");
        }
    }

    #[test]
    fn coverage_sheet_works_with_a_device_frame() {
        let Some(t) = tools() else { return };
        let o = device_zoom_crop_mask(&t, &t.dir.join("w2f-unused.mp4"), true);
        let sheet = t.dir.join("w2f-sheet.png");
        let c = super::coverage_opts(o, "k", &sheet).unwrap();
        let graph = run_with_overlays(&t, &c);
        assert!(graph.contains("[scenetv]") && graph.contains("tile="), "{graph}");
        let n = c.contact_sheet.as_ref().unwrap().len() as u32;
        let width: u32 = probe(&t, &sheet, "stream=width").parse().unwrap();
        assert_eq!(width, n.min(5) * 480 + (n.min(5) - 1) * 4, "{n} frames");
        assert_eq!(green_frames(&t, &sheet), (0, 1), "the sheet shows only masked frames");
    }

    /// A voice-over insert take holding the last frame of `seg` for `hold` s
    /// (what `addVoiceOverTake` writes), its narration starting at output `at`.
    fn insert_take(t: &Tools, p: &mut Project, seg: usize, hold: f64, at: f64) {
        let take = make_take(t, "w2f-insert.m4a", 2000, hold);
        p.segments[seg].timing.hold_sec = Some(hold);
        with_take(p, &take, hold, serde_json::json!({"id":"vo","offsetSec":at,"mode":"insert","insertSec":hold}));
    }

    fn piece(p: &Project, id: &str, sin: f64, sout: f64) -> crate::edl::Segment {
        let mut s = p.segments[0].clone();
        s.id = id.into();
        (s.source_in, s.source_out) = (sin, sout);
        s.timing = Default::default();
        s
    }

    #[test]
    fn a_voice_over_insert_hold_of_masked_footage_is_masked() {
        let Some(t) = tools() else { return };
        // Green box on the left half only in the last half second of the first clip.
        let src = make_flash(&t, "w2f-hold.mp4", "640x360", "x=0:y=0:w=320:h=360", "between(t,1.5,2)", "", &[]);
        let mut p = flash_project(&src);
        p.segments = vec![piece(&p, "s1", 0., 2.), piece(&p, "s2", 2., 4.)];
        insert_take(&t, &mut p, 0, 1.5, 2.0);
        let bare = export_plain(&t, p.clone(), "w2f-hold-bare.mp4", |_| {});
        let (g, n) = green_frames(&t, &bare);
        assert!(g >= 50 && n >= 160, "unmasked: the held frame is green ({g} of {n})");
        p.masks = Some(serde_json::json!([{"id":"k","mediaId":"m","srcStart":1.5,"srcEnd":2.0,"x":0,"y":0,"w":0.5,"h":1}]));
        let out = export_plain(&t, p, "w2f-hold-masked.mp4", |_| {});
        let (g, n) = green_frames(&t, &out);
        assert_eq!(g, 0, "held frame masked: green in {g} of {n}");
        assert!((duration(&probe_json(&t, &out)) - 5.5).abs() < 0.1, "4 s + the 1.5 s take");
    }

    #[test]
    fn a_mask_never_changes_the_override_take_audio() {
        let Some(t) = tools() else { return };
        let src = make_flash(&t, "w2f-ovr.mp4", "640x360", "x=0:y=0:w=320:h=360", "between(t,1,3)", "", &[]);
        let take = make_take(&t, "w2f-ovr-take.m4a", 2000, 1.5);
        let mut p = flash_project(&src);
        with_take(&mut p, &take, 1.5, serde_json::json!({"id":"vo","offsetSec":1.0,"mode":"overlay","overrideOriginal":true}));
        let bare = export_plain(&t, p.clone(), "w2f-ovr-bare.mp4", |_| {});
        p.masks = Some(serde_json::from_str(&format!("[{LEFT_HALF}]")).unwrap());
        let env = |o: &ExportOpts| {
            let argv = build_reencode_argv(o, 4.0, None, None).unwrap();
            let g = argv[argv.iter().position(|a| a == "-filter_complex").unwrap() + 1].clone();
            g.split(';').filter(|c| c.contains("mainvox") || c.contains("trk_") || c.contains("outa")).map(str::to_string).collect::<Vec<_>>()
        };
        let masked_opts = opts_for(p.clone(), Path::new("/o/a.mp4"), None);
        assert_eq!(env(&masked_opts), env(&opts_for({ let mut q = p.clone(); q.masks = None; q }, Path::new("/o/a.mp4"), None)), "audio graph unchanged");
        assert!(env(&masked_opts).iter().any(|c| c.contains("[mainvox]asetnsamples=n=256:p=0,volume=volume='")), "override envelope present");
        let out = export_plain(&t, p, "w2f-ovr-masked.mp4", |_| {});
        assert_eq!(green_frames(&t, &out).0, 0, "masked");
        let pcm = |f: &Path| {
            let r = Command::new(&t.ffmpeg).args(["-v", "error", "-i"]).arg(f).args(["-map", "0:a", "-f", "s16le", "-"]).output().unwrap();
            assert!(r.status.success());
            r.stdout
        };
        assert!(pcm(&bare) == pcm(&out), "decoded audio identical with and without the mask");
        let inside = band_rms_db(&t, &out, 1.1, 1.3, ORIGINAL_440);
        let before = band_rms_db(&t, &out, 0.2, 0.6, ORIGINAL_440);
        let take_db = band_rms_db(&t, &out, 1.1, 1.3, NARRATION);
        assert!(inside < before - 35.0 && take_db > -35.0, "envelope: before {before} inside {inside} take {take_db}");
    }

    const ORIGINAL_440: &str = "bandpass=f=440:width_type=q:w=8,bandpass=f=440:width_type=q:w=8";

    #[test]
    fn duplicated_and_moved_masked_clips_with_an_insert_take_stay_masked() {
        let Some(t) = tools() else { return };
        let src = make_flash(&t, "w2f-dup.mp4", "640x360", "x=0:y=0:w=320:h=360", "between(t,1,3)", "", &[]);
        let mut p = flash_project(&src);
        // Moved: the second half first; then the first half (holding for a take);
        // then a duplicate of footage that crosses the mask.
        p.segments = vec![piece(&p, "s2", 2., 4.), piece(&p, "s1", 0., 2.), piece(&p, "dup", 0.5, 2.5)];
        insert_take(&t, &mut p, 1, 1.0, 4.0);
        let bare = export_plain(&t, p.clone(), "w2f-dup-bare.mp4", |_| {});
        let (g, n) = green_frames(&t, &bare);
        assert!(g >= 100 && n >= 205, "unmasked: green in {g} of {n}");
        p.masks = Some(serde_json::from_str(&format!("[{LEFT_HALF}]")).unwrap());
        let (g, n) = green_frames(&t, &export_plain(&t, p, "w2f-dup-masked.mp4", |_| {}));
        assert_eq!(g, 0, "every copy and the hold masked: green in {g} of {n}");
    }
}

// ---------------------------------------------------------------------------
// Benchmark hooks (append-only; no behaviour change). `examples/export_argv.rs`
// uses these so benchmarks run the exact argv the production exporter builds.
// ---------------------------------------------------------------------------

/// The production full re-encode argv (`build_reencode_argv`), exposed for benchmarks.
pub fn reencode_argv_for_bench(
    opts: &ExportOpts,
    total_duration: f64,
    chapter_meta: Option<&PathBuf>,
    cursor_file: Option<&std::path::Path>,
) -> Result<Vec<String>, String> {
    build_reencode_argv(opts, total_duration, chapter_meta, cursor_file)
}

/// Whether `run_export` would try smart-cut for these options (same predicate).
pub fn smart_cut_eligible(opts: &ExportOpts) -> bool {
    let audio_only = matches!(opts.preset, ExportPreset::PodcastAudio);
    !opts.project.segments.is_empty()
        && !opts.force_reencode
        && scene_for(opts).is_none()
        && zoom_for(opts).is_empty()
        && cursor_for(opts).is_none()
        && smart_cut::is_eligible(
            &opts.project,
            opts.codec.as_deref(),
            opts.width,
            opts.height,
            opts.fps,
            audio_only,
        )
}

/// Whether the production path would draw a cursor overlay for these options.
pub fn cursor_overlay_active_for_bench(opts: &ExportOpts) -> bool {
    cursor_for(opts).is_some()
}

/// Writes the cursor ASS exactly as `prepare_cursor` does (same size and fps
/// rules), to `path`. Returns `Ok(false)` when production would draw no cursor.
pub fn write_cursor_ass_for_bench(opts: &ExportOpts, path: &std::path::Path) -> Result<bool, String> {
    if cursor_for(opts).is_none() {
        return Ok(false);
    }
    let (w, h) = picture_size(opts)?;
    let fps = animation_fps(opts).min(60.);
    let mut project = opts.project.clone();
    let cursor: CursorConfig = serde_json::from_value(project.cursor.take().ok_or("cursor settings missing")?)
        .map_err(|e| format!("invalid cursor settings: {e}"))?;
    let mut file = std::io::BufWriter::new(std::fs::File::create(path).map_err(|e| e.to_string())?);
    write_ass(&mut file, &cursor, &project, w, h, fps, || false)?;
    std::io::Write::flush(&mut file).map_err(|e| e.to_string())?;
    Ok(true)
}
