//! Transcription commands:
//!   - `transcribe`     — extract 16kHz mono WAV, run whisper-cli, parse JSON, emit progress
//!   - `list_models`    — what is installed locally, what needs downloading
//!   - `download_model` — fetch a model from Hugging Face
//!
//! Only whisper.cpp is supported (via the `whisper-cli` sidecar with Core ML + Metal).
//! WhisperKit was removed in v3.2.0 — restore from commit 4726d25 if needed.
//!
//! Progress events are emitted on the channel `transcribe:progress` and
//! `model:download:progress`. Frontend subscribes via `ipc.ts`.

pub mod backend;

use crate::AppState;
use backend::{TranscribeTimings, WhisperBackend};
use crate::edl::Word;
use crate::jobs::JobKind;
use crate::transcribe::parse_whisper_json;
use futures_util::StreamExt as _;
use serde::{Deserialize, Serialize};
use std::path::PathBuf;
use tauri::{AppHandle, Emitter, Manager, State};
use tauri_plugin_shell::ShellExt;
use tauri_plugin_shell::process::CommandEvent;
use tokio::fs;
use tokio::io::AsyncWriteExt as _;

// ---------------------------------------------------------------------------
// TranscriptionEngine
// ---------------------------------------------------------------------------

/// Transcription backend. whisper.cpp only since v3.2.0.
///
/// WhisperKit was removed because ANE-quantized models produced less accurate
/// word timestamps, causing video/text drift. To restore it, see commit 4726d25.
#[derive(Debug, Serialize, Deserialize, Clone, Copy, PartialEq, Eq, Default)]
#[serde(rename_all = "kebab-case")]
pub enum TranscriptionEngine {
    #[default]
    WhisperCpp,
}

// ---------------------------------------------------------------------------
// WhisperModel (whisper.cpp / GGML)
// ---------------------------------------------------------------------------

#[derive(Debug, Serialize, Deserialize, Clone, Copy, PartialEq, Eq)]
#[serde(rename_all = "kebab-case")]
pub enum WhisperModel {
    Tiny,
    Base,
    Small,
    Medium,
    #[serde(rename = "large-v3-turbo")]
    LargeV3Turbo,
    /// Full large-v3 (non-turbo). Highest accuracy, ~3.1 GB. Receives DTW refinement.
    #[serde(rename = "large-v3")]
    LargeV3,
}

impl WhisperModel {
    pub fn filename(self) -> &'static str {
        match self {
            WhisperModel::Tiny => "ggml-tiny.bin",
            WhisperModel::Base => "ggml-base.bin",
            WhisperModel::Small => "ggml-small.bin",
            WhisperModel::Medium => "ggml-medium.bin",
            WhisperModel::LargeV3Turbo => "ggml-large-v3-turbo.bin",
            WhisperModel::LargeV3 => "ggml-large-v3.bin",
        }
    }

    /// Base name used in Core ML encoder filenames, e.g. "tiny", "large-v3-turbo".
    pub fn base_name(self) -> &'static str {
        match self {
            WhisperModel::Tiny => "tiny",
            WhisperModel::Base => "base",
            WhisperModel::Small => "small",
            WhisperModel::Medium => "medium",
            WhisperModel::LargeV3Turbo => "large-v3-turbo",
            WhisperModel::LargeV3 => "large-v3",
        }
    }

    /// The Core ML encoder directory that whisper-cli looks for next to the .bin.
    /// e.g. "ggml-tiny-encoder.mlmodelc"
    pub fn coreml_encoder_dir(self) -> String {
        format!("ggml-{}-encoder.mlmodelc", self.base_name())
    }

    /// The zip file name on HuggingFace that contains the Core ML encoder.
    pub fn coreml_encoder_zip(self) -> String {
        format!("ggml-{}-encoder.mlmodelc.zip", self.base_name())
    }

    pub fn size_mb(self) -> u64 {
        match self {
            WhisperModel::Tiny => 75,
            WhisperModel::Base => 142,
            WhisperModel::Small => 466,
            WhisperModel::Medium => 1500,
            WhisperModel::LargeV3Turbo => 1600,
            WhisperModel::LargeV3 => 3100,
        }
    }
}

// ---------------------------------------------------------------------------
// Shared ModelInfo (returned by list_models)
// ---------------------------------------------------------------------------

#[derive(Debug, Serialize)]
pub struct ModelInfo {
    pub engine: TranscriptionEngine,
    pub name: String,
    #[serde(rename = "sizeMb")]
    pub size_mb: u64,
    pub installed: bool,
}

// ---------------------------------------------------------------------------
// TranscribeOpts / TranscribeResult / TranscribeProgress
// ---------------------------------------------------------------------------

#[derive(Debug, Deserialize)]
pub struct TranscribeOpts {
    #[serde(rename = "mediaId")]
    pub media_id: String,
    #[serde(rename = "mediaPath")]
    pub media_path: String,
    /// Always "whisper-cpp" since v3.2.0.
    #[serde(rename = "engine", default)]
    pub engine: TranscriptionEngine,
    /// WhisperModel slug in kebab-case, e.g. "large-v3-turbo".
    #[serde(rename = "modelName")]
    pub model_name: String,
    /// Total media duration in seconds — used to emit accurate 0..1 progress.
    #[serde(rename = "mediaDuration", default)]
    pub media_duration: f64,
    /// BCP-47 language code. `None` / omitted → Whisper auto-detects.
    #[serde(rename = "language", default)]
    pub language: Option<String>,
    /// Output English regardless of source language (`--translate`).
    #[serde(rename = "translate", default)]
    pub translate: bool,
    /// Attempt speaker diarisation (`--diarize`).
    #[serde(rename = "diarize", default)]
    pub diarize: bool,
}

#[derive(Debug, Serialize)]
pub struct TranscribeResult {
    #[serde(rename = "mediaId")]
    pub media_id: String,
    pub words: Vec<Word>,
    pub engine: TranscriptionEngine,
    /// Backend whisper-cli actually ran on (from its stderr markers).
    #[serde(skip_serializing_if = "Option::is_none")]
    pub backend: Option<WhisperBackend>,
    /// Per-stage timings in milliseconds.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub timings: Option<TranscribeTimings>,
}

#[derive(Debug, Serialize, Clone)]
pub struct TranscribeProgress {
    #[serde(rename = "mediaId")]
    pub media_id: String,
    pub progress: f64,
    #[serde(rename = "currentTime")]
    pub current_time: f64,
}

// ---------------------------------------------------------------------------
// Path helpers
// ---------------------------------------------------------------------------

fn models_dir(app: &AppHandle) -> Result<PathBuf, String> {
    let mut p = app.path().app_data_dir().map_err(|e| e.to_string())?;
    p.push("models");
    Ok(p)
}

// ---------------------------------------------------------------------------
// list_models  (whisper.cpp GGML only)
// ---------------------------------------------------------------------------

#[tauri::command]
pub async fn list_models(app: AppHandle) -> Result<Vec<ModelInfo>, String> {
    let ggml_dir = models_dir(&app)?;
    let out = [
        WhisperModel::Tiny,
        WhisperModel::Base,
        WhisperModel::Small,
        WhisperModel::Medium,
        WhisperModel::LargeV3Turbo,
        WhisperModel::LargeV3,
    ]
    .iter()
    .map(|&m| ModelInfo {
        engine: TranscriptionEngine::WhisperCpp,
        name: serde_json::to_value(m)
            .ok()
            .and_then(|v| v.as_str().map(String::from))
            .unwrap_or_default(),
        size_mb: m.size_mb(),
        installed: ggml_dir.join(m.filename()).exists(),
    })
    .collect();
    Ok(out)
}

// ---------------------------------------------------------------------------
// download_model  (GGML bin + Core ML encoder zip)
// ---------------------------------------------------------------------------

/// Download a single file from HuggingFace whisper.cpp repo, emitting progress
/// events with the given `progress_name` key.
///
/// `phase` / `label` are forwarded verbatim in the event so the frontend can
/// display a human-readable status (e.g. "Downloading model file" vs
/// "Downloading Core ML encoder").  `progress_scale` and `progress_offset`
/// map the raw 0–1 file progress into the caller's combined progress range.
#[allow(clippy::too_many_arguments)]
async fn download_hf_file(
    app: &AppHandle,
    job: Option<&crate::jobs::JobHandle>,
    url: &str,
    dest: &PathBuf,
    progress_name: impl Serialize,
    progress_scale: f64,
    progress_offset: f64,
    phase: &str,
    label: &str,
) -> Result<(), String> {
    let tmp = dest.with_extension(format!(
        "{}.partial",
        dest.extension().unwrap_or_default().to_string_lossy()
    ));
    // Remove any stale partial left by a previously interrupted download.
    if tmp.exists() {
        let _ = fs::remove_file(&tmp).await;
    }

    let resp = or_cancel(job, reqwest::get(url))
        .await?
        .map_err(|e| e.to_string())?;
    if !resp.status().is_success() {
        return Err(format!(
            "download failed ({}): {}",
            dest.display(),
            resp.status()
        ));
    }
    let total = resp.content_length().unwrap_or(0);
    let mut stream = resp.bytes_stream();
    let mut file = fs::File::create(&tmp).await.map_err(|e| e.to_string())?;
    let mut downloaded: u64 = 0;

    loop {
        let next = match or_cancel(job, stream.next()).await {
            Ok(next) => next,
            Err(e) => {
                drop(file);
                let _ = fs::remove_file(&tmp).await;
                return Err(e);
            }
        };
        let Some(chunk) = next else { break };
        let chunk = chunk.map_err(|e| e.to_string())?;
        file.write_all(&chunk).await.map_err(|e| e.to_string())?;
        downloaded += chunk.len() as u64;
        let raw = if total > 0 {
            downloaded as f64 / total as f64
        } else {
            0.0
        };
        let progress = (raw * progress_scale + progress_offset).clamp(0.0, 1.0);
        app.emit(
            "model:download:progress",
            serde_json::json!({
                "name": progress_name,
                "phase": phase,
                "label": label,
                "progress": progress,
                "bytesDownloaded": downloaded,
                "bytesTotal": total,
            }),
        )
        .ok();
    }

    file.flush().await.map_err(|e| e.to_string())?;
    drop(file);
    fs::rename(&tmp, dest).await.map_err(|e| e.to_string())?;
    Ok(())
}

/// Run `fut`, resolving to `Err("cancelled")` as soon as the job is cancelled.
/// With no job the future simply runs to completion.
async fn or_cancel<F: std::future::Future>(
    job: Option<&crate::jobs::JobHandle>,
    fut: F,
) -> Result<F::Output, String> {
    let Some(job) = job else {
        return Ok(fut.await);
    };
    let notify = job.cancel_notify();
    let cancelled = notify.notified();
    tokio::pin!(cancelled);
    cancelled.as_mut().enable();
    if job.is_cancelled() {
        return Err("cancelled".into());
    }
    tokio::select! {
        _ = &mut cancelled => Err("cancelled".into()),
        out = fut => Ok(out),
    }
}

/// Unzip a Core ML encoder zip into `parent_dir`, then remove the zip.
///
/// Extraction goes to a scratch directory and is renamed into place only when
/// complete, so a cancelled or failed unzip never leaves a half-extracted
/// `.mlmodelc` that later looks "installed". Cancelling kills `unzip`
/// (`kill_on_drop`) and cleans up.
async fn unzip_coreml_encoder(
    job: Option<&crate::jobs::JobHandle>,
    zip_path: &PathBuf,
    parent_dir: &PathBuf,
    encoder_dir_name: &str,
) -> Result<(), String> {
    let scratch = parent_dir.join(format!(".unzip-{}", uuid::Uuid::new_v4()));
    let result = async {
        fs::create_dir_all(&scratch).await.map_err(|e| e.to_string())?;
        let mut cmd = tokio::process::Command::new("unzip");
        cmd.arg("-o")
            .arg(zip_path)
            .arg("-d")
            .arg(&scratch)
            .stdout(std::process::Stdio::null())
            .stderr(std::process::Stdio::piped())
            .kill_on_drop(true);
        let output = or_cancel(job, cmd.output())
            .await?
            .map_err(|e| format!("failed to run unzip: {e}"))?;
        if !output.status.success() {
            let stderr = String::from_utf8_lossy(&output.stderr);
            return Err(format!("unzip failed: {stderr}"));
        }
        let extracted = scratch.join(encoder_dir_name);
        if !extracted.exists() {
            return Err(format!("unzip produced no {encoder_dir_name}"));
        }
        let final_dir = parent_dir.join(encoder_dir_name);
        if final_dir.exists() {
            let _ = fs::remove_dir_all(&final_dir).await;
        }
        fs::rename(&extracted, &final_dir)
            .await
            .map_err(|e| e.to_string())?;
        Ok(())
    }
    .await;
    let _ = fs::remove_dir_all(&scratch).await;
    if result.is_ok() {
        let _ = fs::remove_file(zip_path).await;
    }
    result
}

/// Download a whisper.cpp GGML model (bin + optional Core ML encoder).
///
/// Combined progress weighting across the full operation:
///   0 %  → 75 %  — GGML .bin download          (phase: "model")
///  75 %  → 95 %  — Core ML encoder download     (phase: "coreml")
///  95 %  → 100 % — unzip / preparation          (phase: "unzip")
///        100 %   — complete                     (phase: "complete")
async fn download_whisper_cpp_model(
    app: &AppHandle,
    job: &crate::jobs::JobHandle,
    name: WhisperModel,
) -> Result<(), String> {
    let dir = models_dir(app)?;
    fs::create_dir_all(&dir).await.map_err(|e| e.to_string())?;

    let bin_url = format!(
        "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/{}",
        name.filename()
    );
    let bin_dest = dir.join(name.filename());
    // .bin: combined 0 % → 75 %
    download_hf_file(app, Some(job), &bin_url, &bin_dest, name, 0.75, 0.0, "model", "Downloading model file").await?;
    // Core ML encoder: combined 75 % → 95 % (download) + 95 % → 100 % (unzip)
    ensure_coreml_encoder(app, Some(job), &dir, name, 0.75, 0.20).await?;

    app.emit(
        "model:download:progress",
        serde_json::json!({
            "name": name,
            "phase": "complete",
            "label": "Model ready",
            "progress": 1.0,
            "bytesDownloaded": 0u64,
            "bytesTotal": 0u64,
        }),
    )
    .ok();

    Ok(())
}

#[tauri::command]
pub async fn download_model(
    app: AppHandle,
    state: State<'_, AppState>,
    engine: TranscriptionEngine,
    name: String,
) -> Result<(), String> {
    let job = state
        .jobs
        .create(
            &app,
            JobKind::DownloadModel,
            format!("Downloading model: {name}"),
        )
        .await;
    job.mark_running().await;

    // Only whisper-cpp is supported since v3.2.0.
    let _ = engine; // always WhisperCpp
    let model: WhisperModel = serde_json::from_value(serde_json::Value::String(name))
        .map_err(|e| format!("unknown model: {e}"))?;
    let result = download_whisper_cpp_model(&app, &job, model).await;

    match &result {
        Ok(()) => job.mark_completed().await,
        Err(_) if job.is_cancelled() => job.mark_cancelled().await,
        Err(e) => job.mark_failed(e.clone()).await,
    }
    result
}

// ---------------------------------------------------------------------------
// delete_model  — remove downloaded GGML bin + Core ML encoder directory
// ---------------------------------------------------------------------------

/// Delete a downloaded whisper.cpp model and its associated Core ML encoder.
///
/// Missing files are silently ignored — only real filesystem errors are returned.
/// The `engine` argument is accepted for API consistency but always treated as
/// `WhisperCpp` (the only supported engine).
#[tauri::command]
pub async fn delete_model(
    app: AppHandle,
    _engine: TranscriptionEngine,
    name: String,
) -> Result<(), String> {
    let model: WhisperModel = serde_json::from_value(serde_json::Value::String(name))
        .map_err(|e| format!("unknown model: {e}"))?;

    let dir = models_dir(&app)?;

    // Remove the GGML binary (.bin).
    let bin_path = dir.join(model.filename());
    if bin_path.exists() {
        fs::remove_file(&bin_path)
            .await
            .map_err(|e| format!("failed to remove {}: {e}", bin_path.display()))?;
    }

    // Remove the Core ML encoder directory (.mlmodelc) if present.
    let encoder_dir = dir.join(model.coreml_encoder_dir());
    if encoder_dir.exists() {
        fs::remove_dir_all(&encoder_dir)
            .await
            .map_err(|e| format!("failed to remove {}: {e}", encoder_dir.display()))?;
    }

    Ok(())
}

// ---------------------------------------------------------------------------
// ensure_coreml_encoder — whisper.cpp Core ML companion (unchanged)
// ---------------------------------------------------------------------------

/// Ensure the Core ML encoder directory exists for `name`, downloading and
/// unzipping it if necessary.
///
/// `progress_offset` and `progress_scale` place this step inside the caller's
/// combined progress range.  The download occupies the first 90 % of
/// `progress_scale`; the unzip step occupies the remaining 10 %.
///
/// Returns `Ok(true)` if the encoder is available (was already present or was
/// successfully installed), `Ok(false)` on failure (the backend ladder drops
/// Core ML), and `Err("cancelled")` when the job is cancelled mid-way.
async fn ensure_coreml_encoder(
    app: &AppHandle,
    job: Option<&crate::jobs::JobHandle>,
    models: &PathBuf,
    name: WhisperModel,
    progress_offset: f64,
    progress_scale: f64,
) -> Result<bool, String> {
    let encoder_dir = models.join(name.coreml_encoder_dir());
    if encoder_dir.exists() {
        return Ok(true);
    }

    log::info!(
        "Core ML encoder missing for {} — downloading automatically",
        name.filename()
    );

    let zip_name = name.coreml_encoder_zip();
    let zip_dest = models.join(&zip_name);
    let zip_url = format!(
        "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/{}",
        zip_name
    );

    // Reserve the last 10 % of the allocated range for the unzip step.
    let dl_scale = progress_scale * 0.9;
    let unzip_progress = (progress_offset + dl_scale).clamp(0.0, 1.0);

    let ok = match download_hf_file(
        app,
        job,
        &zip_url,
        &zip_dest,
        name,
        dl_scale,
        progress_offset,
        "coreml",
        "Downloading Core ML encoder",
    )
    .await
    {
        Err(e) if e == "cancelled" => return Err(e),
        Err(e) => {
            log::warn!("Core ML encoder download failed: {e}");
            // Emit a skipped event so the UI knows this phase ended and won't appear stuck.
            app.emit(
                "model:download:progress",
                serde_json::json!({
                    "name": name,
                    "phase": "coreml-skipped",
                    "label": "Core ML encoder unavailable — using Metal only",
                    "progress": (progress_offset + progress_scale).clamp(0.0, 1.0),
                    "bytesDownloaded": 0u64,
                    "bytesTotal": 0u64,
                }),
            )
            .ok();
            false
        }
        Ok(()) => {
            // Unzip phase: notify the user so the UI doesn't freeze during extraction.
            app.emit(
                "model:download:progress",
                serde_json::json!({
                    "name": name,
                    "phase": "unzip",
                    "label": "Preparing Core ML encoder…",
                    "progress": unzip_progress,
                    "bytesDownloaded": 0u64,
                    "bytesTotal": 0u64,
                }),
            )
            .ok();

            match unzip_coreml_encoder(job, &zip_dest, models, &name.coreml_encoder_dir()).await {
                Err(e) if e == "cancelled" => {
                    let _ = fs::remove_file(&zip_dest).await;
                    return Err(e);
                }
                Err(e) => {
                    log::warn!("Core ML encoder unzip failed: {e}");
                    let _ = fs::remove_file(&zip_dest).await;
                    false
                }
                Ok(()) => {
                    log::info!("Core ML encoder installed for {}", name.filename());
                    true
                }
            }
        }
    };

    Ok(ok)
}

// ---------------------------------------------------------------------------
// transcribe  (public Tauri command)
// ---------------------------------------------------------------------------

#[tauri::command]
pub async fn transcribe(
    app: AppHandle,
    state: State<'_, AppState>,
    opts: TranscribeOpts,
) -> Result<TranscribeResult, String> {
    let job = state
        .jobs
        .create(
            &app,
            JobKind::Transcribe,
            format!("Transcribing (whisper.cpp) — {}", &opts.model_name),
        )
        .await;
    let _analysis = match super::preview::analysis_permit(&job).await {
        Ok(permit) => permit,
        Err(error) => { job.mark_cancelled().await; return Err(error); }
    };
    if job.is_cancelled() { job.mark_cancelled().await; return Err("cancelled".into()); }
    job.mark_running().await;
    let job_for_progress = job.clone();
    let media_id_for_progress = opts.media_id.clone();

    let result =
        transcribe_inner(&app, &opts, &job_for_progress, &media_id_for_progress).await;
    if job.is_cancelled() {
        job.mark_cancelled().await;
        return Err("cancelled".into());
    }
    match &result {
        Ok(_) => job.mark_completed().await,
        Err(e) => job.mark_failed(e.clone()).await,
    }
    result
}

async fn transcribe_inner(
    app: &AppHandle,
    opts: &TranscribeOpts,
    job: &crate::jobs::JobHandle,
    media_id: &str,
) -> Result<TranscribeResult, String> {
    app.emit(
        "transcribe:progress",
        TranscribeProgress {
            media_id: opts.media_id.clone(),
            progress: 0.01,
            current_time: 0.0,
        },
    )
    .ok();

    // 1) Extract audio to a temp wav (same for both engines)
    let wav = tempfile_with_ext("wav");
    let result = async {
    if job.is_cancelled() { return Err("cancelled".into()); }
    let extract_started = std::time::Instant::now();
    let shell = app.shell();
    let ffmpeg = shell
        .sidecar("ffmpeg")
        .map_err(|e| format!("ffmpeg sidecar not available: {e}"))?
        .args([
            "-y",
            "-nostdin",
            "-i", &opts.media_path,
            "-vn",
            "-ac", "1",
            "-ar", "16000",
            "-c:a", "pcm_s16le",
            wav.to_str().unwrap(),
        ]);
    let (mut rx, child) = ffmpeg.spawn().map_err(|e| format!("spawn ffmpeg: {e}"))?;
    let mut child = Some(child);
    let extracted = loop {
        let notify = job.cancel_notify();
        let cancelled = notify.notified();
        tokio::pin!(cancelled);
        cancelled.as_mut().enable();
        if job.is_cancelled() { break Err("cancelled".to_string()); }
        let event = tokio::select! {
            _ = &mut cancelled => break Err("cancelled".to_string()),
            event = rx.recv() => event,
        };
        match event {
            Some(CommandEvent::Terminated(t)) => {
                child.take();
                break if t.code == Some(0) { Ok(()) }
                    else { Err("ffmpeg failed extracting audio".to_string()) };
            }
            None => break Err("ffmpeg closed without an exit status".to_string()),
            _ => {},
        }
    };
    if let Some(child) = child {
        let _ = child.kill();
        // Wait for the writer to exit before removing its temporary output.
        let _ = tokio::time::timeout(std::time::Duration::from_secs(2), async {
            while let Some(event) = rx.recv().await {
                if matches!(event, CommandEvent::Terminated(_)) { break; }
            }
        }).await;
    }
    extracted?;
    let extraction_ms = extract_started.elapsed().as_secs_f64() * 1000.0;
    if job.is_cancelled() { return Err("cancelled".into()); }

    // 2) Transcribe with whisper.cpp
    let run = transcribe_whisper_cpp(app, opts, job, &wav).await?;
    let words = run.words;
    let mut timings = run.timings;
    timings.extraction_ms = Some(extraction_ms);
    if job.is_cancelled() { return Err("cancelled".into()); }

    let _ = media_id;

    // 3) Emit final "done"
    let total_duration = opts.media_duration.max(1.0);
    app.emit(
        "transcribe:progress",
        TranscribeProgress {
            media_id: opts.media_id.clone(),
            progress: 1.0,
            current_time: total_duration,
        },
    )
    .ok();

    Ok(TranscribeResult {
        media_id: opts.media_id.clone(),
        words,
        engine: opts.engine,
        backend: Some(run.backend),
        timings: Some(timings),
    })
    }.await;
    // Clean up on all paths: extraction failure, cancellation, parse error and success.
    let _ = fs::remove_file(&wav).await;
    let _ = fs::remove_file(wav.with_extension("wav.json")).await;
    result
}

// ---------------------------------------------------------------------------
// whisper.cpp path
// ---------------------------------------------------------------------------

/// Outcome of the whisper.cpp stage.
struct WhisperRun {
    words: Vec<Word>,
    backend: WhisperBackend,
    timings: TranscribeTimings,
}

/// Build the whisper-cli argument list. Pure so benchmarks can reuse the exact
/// production arguments. `language` is the raw request value: `None`, empty or
/// `"auto"` all mean auto-detect, which is passed explicitly (`--language auto`)
/// because the binary otherwise defaults to English.
pub fn whisper_args(
    model_path: &str,
    wav_path: &str,
    model_name: &str,
    language: Option<&str>,
    translate: bool,
    diarize: bool,
    backend: WhisperBackend,
) -> Vec<String> {
    let mut whisper_args: Vec<String> = vec![
        "-m".into(), model_path.to_string(),
        "-f".into(), wav_path.to_string(),
        "--output-json-full".into(),
        // ── Timestamp accuracy flags ─────────────────────────────────────
        // Split tokens at word boundaries so each Word gets its own tight
        // start/end offset rather than inheriting the whole segment range.
        "--split-on-word".into(),
        // Low probability threshold: keep all tokens, even uncertain ones.
        // The editor always shows every word; users decide what to delete.
        "--word-thold".into(), "0.01".into(),
        // Disable the maximum-segment-length cap. When max-len is set,
        // whisper can rush short segments to hit the token budget, which
        // compresses timestamps and causes video/text drift. Setting it to
        // 0 lets each segment run as long as needed for accurate timing.
        "--max-len".into(), "0".into(),
        // Use beam search with 5 candidates for better transcript quality.
        // This has no impact on timing but reduces hallucinations that can
        // also throw off the word index ↔ timestamp mapping.
        "--best-of".into(), "5".into(),
        "--beam-size".into(), "5".into(),
    ];

    // DTW-based word timestamp refinement (whisper.cpp ≥ 1.5).
    // Uses Dynamic Time Warping on the mel spectrogram to pin each word's
    // start/end to its actual audio onset — brings timing accuracy from
    // ~100 ms down to ~20 ms, similar to Descript-grade forced alignment.
    // Only available for the presets the bundled whisper-cli ships aheads for.
    if let Some(dtw) = dtw_preset_for_model(model_name) {
        whisper_args.push("--dtw".into());
        whisper_args.push(dtw.into());
    }

    // Backend flags (`--no-gpu` only on the Metal-off rungs of the ladder).
    for a in backend.extra_args() {
        whisper_args.push((*a).into());
    }
    // Language / translation flags
    let effective_language = language.filter(|l| !l.is_empty() && *l != "auto");
    whisper_args.push("--language".into());
    whisper_args.push(effective_language.unwrap_or("auto").to_string());
    if translate {
        whisper_args.push("--translate".into());
    }
    // Disfluent prompt: whisper tends to "clean up" um/uh unless the prompt
    // shows them, and the filler cutter can only remove what is transcribed.
    if let Some(prompt) = disfluent_prompt(effective_language) {
        whisper_args.push("--prompt".into());
        whisper_args.push(prompt.into());
    }
    // Speaker diarisation
    if diarize {
        whisper_args.push("--diarize".into());
    }
    whisper_args
}

async fn transcribe_whisper_cpp(
    app: &AppHandle,
    opts: &TranscribeOpts,
    job: &crate::jobs::JobHandle,
    wav: &PathBuf,
) -> Result<WhisperRun, String> {
    let models = models_dir(app)?;

    let model_enum: WhisperModel =
        serde_json::from_value(serde_json::Value::String(opts.model_name.clone()))
            .map_err(|_| format!("unknown whisper-cpp model: {}", opts.model_name))?;

    let model_path = models.join(model_enum.filename());
    if !model_path.exists() {
        return Err(format!(
            "model not installed: {}. Call download_model first.",
            model_enum.filename()
        ));
    }

    let prep_started = std::time::Instant::now();
    let use_coreml = ensure_coreml_encoder(app, Some(job), &models, model_enum, 0.0, 1.0).await?;
    let preparation_ms = prep_started.elapsed().as_secs_f64() * 1000.0;
    if job.is_cancelled() { return Err("cancelled".into()); }
    if !use_coreml {
        log::warn!(
            "Core ML encoder unavailable for {}",
            model_enum.filename()
        );
    }

    let model_str = model_path.to_str().unwrap().to_string();
    let wav_str = wav.to_str().unwrap().to_string();

    let rungs = backend::ladder(use_coreml, backend::BUNDLED_BINARY_SUPPORTS_FALLBACK);
    if rungs.is_empty() {
        return Err(format!(
            "Core ML encoder for {} is missing and could not be prepared; reconnect to download it or choose another model",
            opts.model_name
        ));
    }
    let mut last_err = String::new();
    let mut outcome: Option<(WhisperBackend, String)> = None;
    for (i, planned) in rungs.iter().copied().enumerate() {
        let args = whisper_args(
            &model_str,
            &wav_str,
            &opts.model_name,
            opts.language.as_deref(),
            opts.translate,
            opts.diarize,
            planned,
        );
        let (mut exit_ok, mut stderr) = run_whisper_cli(app, opts, job, args.clone()).await?;

        // A stale bundled binary rejects the --dtw preset before transcribing.
        // Retry once without DTW rather than failing the whole transcription.
        if !exit_ok && stderr_mentions_dtw_failure(&stderr) {
            log::warn!("whisper-cli rejected --dtw — retrying without DTW refinement");
            let (retry_ok, retry_stderr) =
                run_whisper_cli(app, opts, job, strip_dtw_args(args)).await?;
            exit_ok = retry_ok;
            stderr = retry_stderr;
        }

        if exit_ok {
            outcome = Some((backend::detect_backend(&stderr, planned), stderr));
            break;
        }
        last_err = format!("whisper-cli failed: {}", stderr.trim());
        if backend::is_init_failure(&stderr) && i + 1 < rungs.len() {
            log::warn!("whisper-cli init failed on {planned:?} — retrying on next backend");
            continue;
        }
        return Err(last_err);
    }
    let Some((ran, stderr)) = outcome else {
        return Err(last_err);
    };
    let wt = backend::parse_whisper_timings(&stderr);

    let json_path = wav.with_extension("wav.json");
    let parse_started = std::time::Instant::now();
    let json = fs::read_to_string(&json_path)
        .await
        .map_err(|e| format!("reading whisper json {}: {}", json_path.display(), e))?;
    let words = parse_whisper_json(&json).map_err(|e| e.to_string())?;
    let parse_ms = parse_started.elapsed().as_secs_f64() * 1000.0;

    Ok(WhisperRun {
        words,
        backend: ran,
        timings: TranscribeTimings {
            preparation_ms: Some(preparation_ms),
            extraction_ms: None,
            model_load_ms: wt.load_ms,
            mel_ms: wt.mel_ms,
            encode_ms: wt.encode_ms,
            decode_ms: wt.decode_ms,
            whisper_total_ms: wt.total_ms,
            parse_ms: Some(parse_ms),
        },
    })
}

/// Spawn whisper-cli with `args`, stream progress to the UI, and return
/// `(exit_ok, captured_stderr)`. Progress is driven by two sources,
/// reconciled so it only ever moves forward (`last_progress` is monotonic):
///   1. Real progress parsed from whisper-cli stderr timestamp lines.
///   2. A 1-second synthetic heartbeat, used whenever real progress lags or
///      never arrives (some whisper-cli builds buffer those lines until the
///      very end, which previously froze the overlay at 1%).
async fn run_whisper_cli(
    app: &AppHandle,
    opts: &TranscribeOpts,
    job: &crate::jobs::JobHandle,
    args: Vec<String>,
) -> Result<(bool, String), String> {
    if job.is_cancelled() { return Err("cancelled".into()); }
    let shell = app.shell();
    let whisper = shell
        .sidecar("whisper-cli")
        .map_err(|e| format!("whisper-cli sidecar not available: {e}"))?
        .args(args);

    let (mut rx, child) = whisper.spawn().map_err(|e| format!("spawn whisper-cli: {e}"))?;
    let mut child = Some(child);
    let mut stderr = String::new();
    let total_duration = opts.media_duration.max(1.0);

    let started_at = std::time::Instant::now();
    let mut last_progress: f64 = 0.01;
    let mut ticker = tokio::time::interval(std::time::Duration::from_secs(1));
    // Drop the immediate first tick so the heartbeat starts ~1 s in.
    ticker.tick().await;

    let result = loop {
        let notify = job.cancel_notify();
        let cancelled = notify.notified();
        tokio::pin!(cancelled);
        cancelled.as_mut().enable();
        if job.is_cancelled() { break Err("cancelled".to_string()); }
        tokio::select! {
            _ = &mut cancelled => break Err("cancelled".to_string()),
            maybe_ev = rx.recv() => {
                match maybe_ev {
                    Some(CommandEvent::Stderr(line)) => {
                        let line = String::from_utf8_lossy(&line).to_string();
                        stderr.push_str(&line);
                        stderr.push('\n');
                        if let Some(current_time) = parse_progress_line(&line) {
                            let real = (current_time / total_duration).clamp(0.02, 0.99);
                            // Never move backwards: only adopt real progress if it
                            // exceeds whatever synthetic progress already reported.
                            if real > last_progress {
                                last_progress = real;
                                app.emit(
                                    "transcribe:progress",
                                    TranscribeProgress {
                                        media_id: opts.media_id.clone(),
                                        progress: last_progress,
                                        current_time,
                                    },
                                )
                                .ok();
                                let eta = ((total_duration - current_time).max(0.0)) as i64;
                                job.set_progress(last_progress, Some(eta)).await;
                            }
                        }
                    }
                    Some(CommandEvent::Terminated(t)) => {
                        child.take();
                        break Ok(t.code == Some(0));
                    }
                    Some(_) => {}
                    None => break Err("whisper-cli closed without an exit status".to_string()),
                }
            }
            _ = ticker.tick() => {
                // Heartbeat: advance synthetic progress while Whisper is busy so
                // the overlay never looks frozen. Capped at 95% by the helper.
                let elapsed = started_at.elapsed().as_secs_f64();
                let synthetic = synthetic_transcribe_progress(elapsed, total_duration);
                if synthetic > last_progress {
                    last_progress = synthetic;
                    let current_time = (last_progress * total_duration).min(total_duration);
                    app.emit(
                        "transcribe:progress",
                        TranscribeProgress {
                            media_id: opts.media_id.clone(),
                            progress: last_progress,
                            current_time,
                        },
                    )
                    .ok();
                    job.set_progress(last_progress, None).await;
                }
            }
        }
    };

    if let Some(child) = child {
        let _ = child.kill();
        let _ = tokio::time::timeout(std::time::Duration::from_secs(2), async {
            while let Some(event) = rx.recv().await {
                if matches!(event, CommandEvent::Terminated(_)) { break; }
            }
        }).await;
    }
    Ok((result?, stderr))
}

// ---------------------------------------------------------------------------
// Progress line parsers
// ---------------------------------------------------------------------------

/// Synthetic transcription progress as a function of elapsed wall-clock time.
///
/// Used as a heartbeat when whisper-cli does not emit (or buffers) its stderr
/// timestamp lines, so the UI never appears frozen. The curve is monotonic,
/// starts at ~1 %, and is hard-capped at 95 % — real parsed progress (or the
/// final 100 % on completion) always takes over when available.
///
/// `media_duration` lightly scales the ramp so short clips reach high progress
/// sooner, but the knees are clamped to sane wall-clock bounds either way.
fn synthetic_transcribe_progress(elapsed_sec: f64, media_duration: f64) -> f64 {
    // Time to reach ~50 % and ~85 % respectively, bounded so neither tiny nor
    // huge media produces a degenerate curve.
    let knee1 = (media_duration * 0.5).clamp(20.0, 60.0);
    let knee2 = (media_duration * 1.5).clamp(knee1 + 30.0, 180.0);

    let p = if elapsed_sec <= knee1 {
        0.01 + (elapsed_sec / knee1) * (0.50 - 0.01)
    } else if elapsed_sec <= knee2 {
        0.50 + ((elapsed_sec - knee1) / (knee2 - knee1)) * (0.85 - 0.50)
    } else {
        // Approach 0.95 slowly over the following ~10 minutes.
        let extra = elapsed_sec - knee2;
        0.85 + (extra / 600.0) * (0.95 - 0.85)
    };
    p.clamp(0.01, 0.95)
}

/// Parse a whisper.cpp stderr progress line:
///   `[00:00:30.000 --> 00:00:32.500]` → 32.5 seconds
fn parse_progress_line(line: &str) -> Option<f64> {
    let line = line.trim();
    if !line.starts_with('[') {
        return None;
    }
    let arrow = line.find("--> ")?;
    let end = line[arrow + 4..].find(']')?;
    let ts = &line[arrow + 4..arrow + 4 + end];
    parse_timestamp(ts)
}

fn parse_timestamp(s: &str) -> Option<f64> {
    let mut parts = s.split(':');
    let h: u64 = parts.next()?.parse().ok()?;
    let m: u64 = parts.next()?.parse().ok()?;
    let s = parts.next()?;
    let secs: f64 = s.parse().ok()?;
    Some((h * 3600 + m * 60) as f64 + secs)
}

fn tempfile_with_ext(ext: &str) -> PathBuf {
    let mut p = std::env::temp_dir();
    p.push(format!("yusafcut-{}.{}", uuid::Uuid::new_v4(), ext));
    p
}

/// Map a model slug to the `--dtw` preset the bundled `whisper-cli` accepts.
///
/// DTW (Dynamic Time Warping) refines word timestamps using cross-attention
/// alignment, bringing per-word accuracy from ~100 ms down to ~20 ms. Modern
/// whisper.cpp (≥ 1.7.x) ships alignment heads for every preset below,
/// including `large.v3` and `large.v3.turbo` (dot-separated names).
///
/// If the bundled binary is older and rejects the preset, the caller retries
/// once without `--dtw` — see `stderr_mentions_dtw_failure`.
fn dtw_preset_for_model(model_name: &str) -> Option<&'static str> {
    match model_name {
        "tiny" => Some("tiny"),
        "base" => Some("base"),
        "small" => Some("small"),
        "medium" => Some("medium"),
        "large-v1" => Some("large.v1"),
        "large-v2" => Some("large.v2"),
        "large-v3" => Some("large.v3"),
        "large-v3-turbo" => Some("large.v3.turbo"),
        _ => None,
    }
}

/// True when a failed whisper-cli run looks like a DTW-preset rejection
/// (stale bundled binary) rather than a genuine transcription failure.
fn stderr_mentions_dtw_failure(stderr: &str) -> bool {
    let s = stderr.to_lowercase();
    s.contains("dtw") && (s.contains("unknown") || s.contains("invalid"))
}

/// Initial prompt that primes whisper to keep hesitations (um, uh, hmm) in the
/// transcript. English-only: a non-English language gets no prompt.
fn disfluent_prompt(language: Option<&str>) -> Option<&'static str> {
    match language {
        None | Some("en") => Some("Um, so, uh, I was, you know, thinking... hmm, well, uh, let me, um, explain."),
        Some(_) => None,
    }
}

/// Remove `--dtw <preset>` from an argument list.
fn strip_dtw_args(args: Vec<String>) -> Vec<String> {
    let mut out = Vec::with_capacity(args.len());
    let mut skip_next = false;
    for a in args {
        if skip_next {
            skip_next = false;
            continue;
        }
        if a == "--dtw" {
            skip_next = true;
            continue;
        }
        out.push(a);
    }
    out
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn disfluent_prompt_only_for_english_or_auto() {
        assert!(disfluent_prompt(None).unwrap().contains("Um"));
        assert!(disfluent_prompt(Some("en")).is_some());
        assert!(disfluent_prompt(Some("fr")).is_none());
    }

    #[test]
    fn parses_whisper_cpp_progress_line() {
        let line = "[00:00:30.500 --> 00:00:32.500]  hello world";
        assert_eq!(parse_progress_line(line), Some(32.5));
    }

    #[test]
    fn rejects_non_progress_lines() {
        assert_eq!(parse_progress_line("loading model"), None);
        assert_eq!(parse_progress_line("[foo]"), None);
    }

    #[test]
    fn coreml_encoder_names() {
        assert_eq!(
            WhisperModel::Tiny.coreml_encoder_dir(),
            "ggml-tiny-encoder.mlmodelc"
        );
        assert_eq!(
            WhisperModel::LargeV3Turbo.coreml_encoder_dir(),
            "ggml-large-v3-turbo-encoder.mlmodelc"
        );
        assert_eq!(
            WhisperModel::Tiny.coreml_encoder_zip(),
            "ggml-tiny-encoder.mlmodelc.zip"
        );
    }

    #[test]
    fn synthetic_progress_starts_low_and_is_capped() {
        // Starts at ~1 % and never exceeds the 95 % cap, even far out.
        assert!((synthetic_transcribe_progress(0.0, 120.0) - 0.01).abs() < 1e-6);
        assert!(synthetic_transcribe_progress(0.0, 120.0) >= 0.01);
        assert!(synthetic_transcribe_progress(100_000.0, 120.0) <= 0.95);
        assert!(synthetic_transcribe_progress(100_000.0, 5.0) <= 0.95);
    }

    #[test]
    fn synthetic_progress_is_monotonic() {
        // Across a wide range of elapsed times the curve must never decrease.
        let mut prev = 0.0;
        for sec in 0..2000 {
            let p = synthetic_transcribe_progress(sec as f64, 120.0);
            assert!(p >= prev - 1e-9, "regressed at {sec}s: {p} < {prev}");
            assert!(p <= 0.95 + 1e-9);
            prev = p;
        }
    }

    #[test]
    fn dtw_preset_supported_models() {
        assert_eq!(dtw_preset_for_model("tiny"), Some("tiny"));
        assert_eq!(dtw_preset_for_model("base"), Some("base"));
        assert_eq!(dtw_preset_for_model("small"), Some("small"));
        assert_eq!(dtw_preset_for_model("medium"), Some("medium"));
        // Modern whisper.cpp names large-model presets with dots.
        assert_eq!(dtw_preset_for_model("large-v1"), Some("large.v1"));
        assert_eq!(dtw_preset_for_model("large-v2"), Some("large.v2"));
        assert_eq!(dtw_preset_for_model("large-v3"), Some("large.v3"));
        assert_eq!(dtw_preset_for_model("large-v3-turbo"), Some("large.v3.turbo"));
    }

    #[test]
    fn dtw_preset_unknown_model_returns_none() {
        assert_eq!(dtw_preset_for_model("unknown-model"), None);
        assert_eq!(dtw_preset_for_model(""), None);
    }

    #[test]
    fn detects_dtw_rejection_in_stderr() {
        // New binary, bad preset name:
        assert!(stderr_mentions_dtw_failure(
            "error: unknown DTW preset 'large.v3.turbo'"
        ));
        // Old binary that has no --dtw flag at all:
        assert!(stderr_mentions_dtw_failure("error: unknown argument: --dtw"));
        // Unrelated failures must NOT trigger the retry:
        assert!(!stderr_mentions_dtw_failure("ggml_metal_init: failed"));
        assert!(!stderr_mentions_dtw_failure(""));
    }

    #[test]
    fn strip_dtw_args_removes_flag_and_value() {
        let args: Vec<String> = vec!["-m", "model.bin", "--dtw", "large.v3", "-f", "audio.wav"]
            .into_iter()
            .map(String::from)
            .collect();
        let stripped = strip_dtw_args(args);
        assert_eq!(stripped, vec!["-m", "model.bin", "-f", "audio.wav"]);
    }

    #[test]
    fn strip_dtw_args_is_noop_without_flag() {
        let args: Vec<String> = vec!["-m", "model.bin"].into_iter().map(String::from).collect();
        assert_eq!(strip_dtw_args(args.clone()), args);
    }

    fn args_for(lang: Option<&str>, translate: bool, diarize: bool, b: WhisperBackend, model: &str) -> Vec<String> {
        whisper_args("/m/ggml.bin", "/t/a.wav", model, lang, translate, diarize, b)
    }

    const BASE: [&str; 15] = [
        "-m", "/m/ggml.bin", "-f", "/t/a.wav", "--output-json-full", "--split-on-word",
        "--word-thold", "0.01", "--max-len", "0", "--best-of", "5", "--beam-size", "5",
        "--dtw",
    ];
    const EN_PROMPT: &str =
        "Um, so, uh, I was, you know, thinking... hmm, well, uh, let me, um, explain.";

    fn strs(v: &[&str]) -> Vec<String> {
        v.iter().map(|s| s.to_string()).collect()
    }

    #[test]
    fn whisper_args_locked_english_default() {
        let mut want = strs(&BASE);
        want.extend(strs(&["large.v3.turbo", "--language", "en", "--prompt", EN_PROMPT]));
        assert_eq!(
            args_for(Some("en"), false, false, WhisperBackend::CoreMlMetal, "large-v3-turbo"),
            want
        );
    }

    #[test]
    fn whisper_args_auto_is_explicit_and_keeps_prompt() {
        for lang in [None, Some(""), Some("auto")] {
            let mut want = strs(&BASE);
            want.extend(strs(&["small", "--language", "auto", "--prompt", EN_PROMPT]));
            assert_eq!(args_for(lang, false, false, WhisperBackend::MetalOnly, "small"), want);
        }
    }

    #[test]
    fn whisper_args_translate_diarize_and_no_gpu_order() {
        let mut want = strs(&BASE);
        want.extend(strs(&[
            "medium", "--no-gpu", "--language", "fr", "--translate", "--diarize",
        ]));
        assert_eq!(args_for(Some("fr"), true, true, WhisperBackend::Cpu, "medium"), want);
    }

    #[test]
    fn whisper_args_unknown_model_has_no_dtw_and_retry_strip_matches() {
        let a = args_for(Some("de"), false, false, WhisperBackend::CoreMlMetal, "weird");
        assert!(!a.contains(&"--dtw".to_string()));
        let with = args_for(Some("de"), false, false, WhisperBackend::CoreMlMetal, "tiny");
        assert_eq!(strip_dtw_args(with), a);
    }

    #[test]
    fn transcription_engine_default_is_whisper_cpp() {
        let engine = TranscriptionEngine::default();
        assert_eq!(engine, TranscriptionEngine::WhisperCpp);
    }

    #[test]
    fn transcription_engine_deserialises_from_json() {
        let e: TranscriptionEngine =
            serde_json::from_str("\"whisper-cpp\"").unwrap();
        assert_eq!(e, TranscriptionEngine::WhisperCpp);
    }
}
