//! Tiny utility commands.

use tauri::Manager;

#[tauri::command]
pub async fn app_data_dir(app: tauri::AppHandle) -> Result<String, String> {
    let p = app.path().app_data_dir().map_err(|e| e.to_string())?;
    Ok(p.to_string_lossy().to_string())
}

#[tauri::command]
pub async fn reveal_in_finder(path: String) -> Result<(), String> {
    // We don't depend on macos-specific crates; shell out to `open -R` instead.
    let status = tokio::process::Command::new("open")
        .args(["-R", &path])
        .status()
        .await
        .map_err(|e| e.to_string())?;
    if !status.success() {
        return Err(format!("`open -R` exited with {status:?}"));
    }
    Ok(())
}

/// Retained native timing spans (empty unless `YUSAFCUT_PERF_SPANS=1`). Names and
/// durations only: no paths or media names.
#[tauri::command]
pub fn perf_spans_snapshot() -> Vec<crate::perf_spans::SpanRecord> {
    crate::perf_spans::snapshot()
}
