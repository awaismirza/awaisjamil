//! Pure helpers for whisper-cli backend selection, init-failure detection and
//! timing extraction. No I/O, so everything here is unit-tested.
//!
//! Capability facts (verified against the bundled binary, which statically
//! links ggml with Metal, Accelerate and Core ML):
//!   - Core ML is used whenever `ggml-<model>-encoder.mlmodelc` sits next to
//!     the `.bin`; there is no flag to turn it off.
//!   - `--no-gpu` disables Metal only. It does NOT disable Core ML.
//!
//! So the ladder is chosen by what is installed, not by adding `--no-gpu` when
//! the encoder is missing.

use serde::Serialize;

/// Which acceleration path a whisper-cli run used (or is planned to use).
#[derive(Debug, Serialize, Clone, Copy, PartialEq, Eq)]
#[serde(rename_all = "kebab-case")]
pub enum WhisperBackend {
    /// Core ML encoder + Metal decoder (default when the encoder is installed).
    CoreMlMetal,
    /// No Core ML encoder; Metal runs the whole model.
    MetalOnly,
    /// Core ML encoder with the Metal decoder disabled (`--no-gpu`).
    CoreMl,
    /// Neither Core ML nor Metal (`--no-gpu`, no encoder).
    Cpu,
}

impl WhisperBackend {
    /// Extra CLI flags this backend needs.
    pub fn extra_args(self) -> &'static [&'static str] {
        match self {
            WhisperBackend::CoreMlMetal | WhisperBackend::MetalOnly => &[],
            WhisperBackend::CoreMl | WhisperBackend::Cpu => &["--no-gpu"],
        }
    }
}

/// Whether the bundled whisper-cli can initialise without the Core ML encoder.
/// Measured false: it exits 3 ("failed to load Core ML model", "failed to
/// initialize whisper context") with or without `--no-gpu`. Only flip this if
/// a probe or marker proves a rebuilt binary supports fallback.
pub const BUNDLED_BINARY_SUPPORTS_FALLBACK: bool = false;

/// Ordered backends to try, best first. Empty means no backend can work (the
/// encoder is absent and the binary cannot fall back): the caller must fail
/// fast instead of retrying. With the encoder present the real ladder is
/// Core ML+Metal then Core ML with the decoder on CPU (`--no-gpu`).
pub fn ladder(coreml_encoder_present: bool, binary_supports_fallback: bool) -> Vec<WhisperBackend> {
    if coreml_encoder_present {
        vec![WhisperBackend::CoreMlMetal, WhisperBackend::CoreMl]
    } else if binary_supports_fallback {
        vec![WhisperBackend::MetalOnly, WhisperBackend::Cpu]
    } else {
        Vec::new()
    }
}

/// What whisper-cli reported about its own initialisation.
#[derive(Debug, Default, Clone, Copy, PartialEq, Eq)]
pub struct BackendMarkers {
    pub coreml_loaded: bool,
    pub metal_used: bool,
}

/// Scan stderr for the markers whisper.cpp prints during context init.
pub fn parse_backend_markers(stderr: &str) -> BackendMarkers {
    let mut m = BackendMarkers::default();
    for line in stderr.lines() {
        let l = line.to_lowercase();
        if l.contains("core ml model loaded") {
            m.coreml_loaded = true;
        }
        if l.contains("using metal backend")
            || l.contains("use gpu    = 1")
            || l.contains("use gpu = 1")
            || l.contains("ggml_metal_init: found device")
        {
            m.metal_used = true;
        }
    }
    m
}

/// The backend that actually ran: stderr markers win; if none were printed we
/// fall back to what was planned.
pub fn detect_backend(stderr: &str, planned: WhisperBackend) -> WhisperBackend {
    let m = parse_backend_markers(stderr);
    if !m.coreml_loaded && !m.metal_used {
        return planned;
    }
    match (m.coreml_loaded, m.metal_used) {
        (true, true) => WhisperBackend::CoreMlMetal,
        (true, false) => WhisperBackend::CoreMl,
        (false, true) => WhisperBackend::MetalOnly,
        (false, false) => unreachable!(),
    }
}

/// True when a failed run died while initialising the model/backend (so a
/// lower ladder rung may succeed), as opposed to a bad argument or bad audio.
pub fn is_init_failure(stderr: &str) -> bool {
    let s = stderr.to_lowercase();
    // DTW preset rejections are handled by the dedicated retry.
    if s.contains("dtw") && (s.contains("unknown") || s.contains("invalid")) {
        return false;
    }
    [
        "failed to initialize whisper context",
        "failed to load model",
        "failed to load core ml model",
        "failed to initialize core ml",
        "ggml_metal_init: failed",
        "failed to initialize metal",
        "failed to allocate metal",
        "whisper_init_from_file_with_params_no_state: failed",
        "whisper_init_state: failed",
    ]
    .iter()
    .any(|marker| s.contains(marker))
}

/// Timings reported by one job, in milliseconds. `None` = not measured.
#[derive(Debug, Serialize, Clone, Copy, Default, PartialEq)]
pub struct TranscribeTimings {
    #[serde(rename = "preparationMs")]
    pub preparation_ms: Option<f64>,
    #[serde(rename = "extractionMs")]
    pub extraction_ms: Option<f64>,
    #[serde(rename = "modelLoadMs")]
    pub model_load_ms: Option<f64>,
    #[serde(rename = "melMs")]
    pub mel_ms: Option<f64>,
    #[serde(rename = "encodeMs")]
    pub encode_ms: Option<f64>,
    #[serde(rename = "decodeMs")]
    pub decode_ms: Option<f64>,
    #[serde(rename = "whisperTotalMs")]
    pub whisper_total_ms: Option<f64>,
    #[serde(rename = "parseMs")]
    pub parse_ms: Option<f64>,
}

/// Timings parsed from `whisper_print_timings` lines.
#[derive(Debug, Default, Clone, Copy, PartialEq)]
pub struct WhisperTimings {
    pub load_ms: Option<f64>,
    pub mel_ms: Option<f64>,
    pub encode_ms: Option<f64>,
    pub decode_ms: Option<f64>,
    pub total_ms: Option<f64>,
}

/// Parse e.g. `whisper_print_timings:   encode time =  1900.12 ms /     1 runs (...)`.
/// The last occurrence of each key wins (a DTW retry prints twice).
pub fn parse_whisper_timings(stderr: &str) -> WhisperTimings {
    let mut t = WhisperTimings::default();
    for line in stderr.lines() {
        let Some(rest) = line.trim().strip_prefix("whisper_print_timings:") else {
            continue;
        };
        let Some((key, value)) = rest.split_once('=') else {
            continue;
        };
        let Some(ms) = value
            .split_whitespace()
            .next()
            .and_then(|v| v.parse::<f64>().ok())
        else {
            continue;
        };
        match key.trim() {
            "load time" => t.load_ms = Some(ms),
            "mel time" => t.mel_ms = Some(ms),
            "encode time" => t.encode_ms = Some(ms),
            "decode time" => t.decode_ms = Some(ms),
            "total time" => t.total_ms = Some(ms),
            _ => {}
        }
    }
    t
}

#[cfg(test)]
mod tests {
    use super::*;

    const GOOD: &str = "\
whisper_init_state: Core ML model loaded
ggml_metal_init: found device: Apple M1 Pro
whisper_backend_init_gpu: using Metal backend
whisper_print_timings:     load time =   612.50 ms
whisper_print_timings:     fallbacks =   0 p /   0 h
whisper_print_timings:      mel time =    12.34 ms
whisper_print_timings:   sample time =     5.00 ms /   100 runs (    0.05 ms per run)
whisper_print_timings:   encode time =  1900.12 ms /     1 runs ( 1900.12 ms per run)
whisper_print_timings:   decode time =   300.00 ms /    30 runs (   10.00 ms per run)
whisper_print_timings:    total time =  3000.99 ms
";

    #[test]
    fn ladder_follows_capability() {
        let present = vec![WhisperBackend::CoreMlMetal, WhisperBackend::CoreMl];
        assert_eq!(ladder(true, false), present);
        assert_eq!(ladder(true, true), present);
        assert_eq!(
            ladder(false, true),
            vec![WhisperBackend::MetalOnly, WhisperBackend::Cpu]
        );
        // Encoder absent and no fallback support: nothing to try.
        assert!(ladder(false, false).is_empty());
        assert!(!BUNDLED_BINARY_SUPPORTS_FALLBACK);
    }

    #[test]
    fn only_metal_off_rungs_add_no_gpu() {
        assert!(WhisperBackend::CoreMlMetal.extra_args().is_empty());
        assert!(WhisperBackend::MetalOnly.extra_args().is_empty());
        assert_eq!(WhisperBackend::Cpu.extra_args(), &["--no-gpu"]);
        assert_eq!(WhisperBackend::CoreMl.extra_args(), &["--no-gpu"]);
    }

    #[test]
    fn markers_detect_coreml_and_metal() {
        let m = parse_backend_markers(GOOD);
        assert!(m.coreml_loaded && m.metal_used);
        assert_eq!(
            detect_backend(GOOD, WhisperBackend::Cpu),
            WhisperBackend::CoreMlMetal
        );
    }

    #[test]
    fn markers_detect_partial_backends() {
        assert_eq!(
            detect_backend("whisper_init_state: Core ML model loaded", WhisperBackend::Cpu),
            WhisperBackend::CoreMl
        );
        assert_eq!(
            detect_backend("whisper_backend_init_gpu: using Metal backend", WhisperBackend::Cpu),
            WhisperBackend::MetalOnly
        );
        assert_eq!(
            detect_backend("whisper_context_params: use gpu    = 1", WhisperBackend::Cpu),
            WhisperBackend::MetalOnly
        );
        // No markers: fall back to the plan.
        assert_eq!(detect_backend("", WhisperBackend::Cpu), WhisperBackend::Cpu);
    }

    #[test]
    fn init_failure_markers() {
        assert!(is_init_failure(
            "whisper_init_state: failed to load Core ML model from 'x'\nerror: failed to initialize whisper context"
        ));
        assert!(is_init_failure("ggml_metal_init: failed to initialize Metal"));
        assert!(!is_init_failure("error: unknown argument: --dtw"));
        assert!(!is_init_failure("error: invalid DTW preset, failed to load model"));
        assert!(!is_init_failure("error: failed to read audio file"));
        assert!(!is_init_failure(""));
    }

    #[test]
    fn parses_print_timings() {
        let t = parse_whisper_timings(GOOD);
        assert_eq!(t.load_ms, Some(612.5));
        assert_eq!(t.mel_ms, Some(12.34));
        assert_eq!(t.encode_ms, Some(1900.12));
        assert_eq!(t.decode_ms, Some(300.0));
        assert_eq!(t.total_ms, Some(3000.99));
    }

    #[test]
    fn timings_ignore_garbage_and_keep_last() {
        assert_eq!(parse_whisper_timings("nothing here"), WhisperTimings::default());
        let s = "whisper_print_timings:     load time =   1.0 ms\nwhisper_print_timings:     load time =   2.0 ms\nwhisper_print_timings:   encode time = abc ms";
        let t = parse_whisper_timings(s);
        assert_eq!(t.load_ms, Some(2.0));
        assert_eq!(t.encode_ms, None);
    }
}
