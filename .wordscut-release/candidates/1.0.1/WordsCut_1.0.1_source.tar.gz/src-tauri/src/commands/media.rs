//! `import_media` — run ffprobe + sha256 on a video file and return parsed metadata;
//! `probe_media` — the metadata alone (checksum attached later via `hash_media`).

use crate::edl::SourceMedia;
use crate::media::{parse_ffprobe_json, sha256_file};
use std::path::Path;
use tauri_plugin_shell::process::CommandEvent;
use tauri_plugin_shell::ShellExt;

/// `import_media` — ffprobe metadata AND the full-file SHA-256, joined. Kept
/// for callers that need the checksum before they insert the media (file
/// pickers, drag and drop, relink). The recording hand-off uses
/// [`probe_media`] + [`hash_media`] instead so the take is playable before the
/// whole file has been read.
#[tauri::command]
pub async fn import_media(app: tauri::AppHandle, path: String) -> Result<SourceMedia, String> {
    let p = Path::new(&path);
    if !p.exists() {
        return Err(format!("file not found: {}", path));
    }

    // Probe and streaming hash can run independently; join both so a failed
    // hash never abandons a still-running sidecar.
    let _total = crate::perf_spans::Span::start("import.total");
    let hash = async {
        let _span = crate::perf_spans::Span::start("import.sha256");
        sha256_file(p).await.map_err(|e| e.to_string())
    };
    let probe = async {
        let _span = crate::perf_spans::Span::start("import.ffprobe");
        ffprobe_json(&app, &path).await
    };
    let (sha, stdout): (Result<String, String>, Result<String, String>) = tokio::join!(hash, probe);
    parse_ffprobe_json(&path, sha?, &stdout?).map_err(|e| e.to_string())
}

/// Metadata only: the same [`SourceMedia`] as `import_media` but with an EMPTY
/// `sha256` (the project's existing "no checksum recorded" value; never a
/// placeholder hash). The caller computes the checksum later with
/// `hash_media` and attaches it with a project / media / path guard.
#[tauri::command]
pub async fn probe_media(app: tauri::AppHandle, path: String) -> Result<SourceMedia, String> {
    if !Path::new(&path).exists() {
        return Err(format!("file not found: {}", path));
    }
    let _span = crate::perf_spans::Span::start("import.probe_only");
    let stdout = ffprobe_json(&app, &path).await?;
    parse_ffprobe_json(&path, String::new(), &stdout).map_err(|e| e.to_string())
}

/// `ffprobe -show_format -show_streams` JSON of `path` via the bundled sidecar.
async fn ffprobe_json(app: &tauri::AppHandle, path: &str) -> Result<String, String> {
    let shell = app.shell();
    let cmd = shell
        .sidecar("ffprobe")
        .map_err(|e| format!("ffprobe sidecar not available: {e}"))?
        .args(["-v", "error", "-print_format", "json", "-show_format", "-show_streams", path]);

    let (mut rx, _child) = cmd.spawn().map_err(|e| format!("spawn ffprobe: {e}"))?;

    let mut stdout = String::new();
    let mut stderr = String::new();
    while let Some(event) = rx.recv().await {
        match event {
            CommandEvent::Stdout(line) => {
                stdout.push_str(&String::from_utf8_lossy(&line));
                stdout.push('\n');
            }
            CommandEvent::Stderr(line) => {
                stderr.push_str(&String::from_utf8_lossy(&line));
                stderr.push('\n');
            }
            CommandEvent::Terminated(t) => {
                if t.code != Some(0) {
                    return Err(format!("ffprobe failed: {}", stderr.trim()));
                }
                return Ok(stdout);
            }
            _ => {}
        }
    }
    Err("ffprobe closed without an exit status".into())
}

/// Picture size of a file as decoded today (rotation applied), without hashing
/// it. Projects from before rotation-aware probing stored landscape sizes for
/// rotated phone clips; the editor refreshes them on open.
#[tauri::command]
pub async fn probe_media_size(app: tauri::AppHandle, path: String) -> Result<(u32, u32), String> {
    probe_size(&app, &path).await
}

/// Decoded size of `path` via the bundled ffprobe.
pub(crate) async fn probe_size(app: &tauri::AppHandle, path: &str) -> Result<(u32, u32), String> {
    let path = path.to_string();
    if !Path::new(&path).is_file() {
        return Err(format!("file not found: {path}"));
    }
    let out = app
        .shell()
        .sidecar("ffprobe")
        .map_err(|e| format!("ffprobe sidecar not available: {e}"))?
        .args(["-v", "error", "-print_format", "json", "-show_format", "-show_streams", &path])
        .output()
        .await
        .map_err(|e| e.to_string())?;
    if out.status.code() != Some(0) {
        return Err("ffprobe failed".into());
    }
    let m = parse_ffprobe_json(&path, String::new(), &String::from_utf8_lossy(&out.stdout)).map_err(|e| e.to_string())?;
    Ok((m.width, m.height))
}

/// Streamed SHA-256 of a file (never loaded whole). Backfills projects saved
/// without checksums so privacy masks match the same file by content.
#[tauri::command]
pub async fn hash_media(path: String) -> Result<String, String> {
    let p = Path::new(&path);
    if !p.is_file() {
        return Err(format!("file not found: {path}"));
    }
    sha256_file(p).await.map_err(|e| e.to_string())
}
