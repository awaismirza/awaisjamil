//! Tauri commands that expose the JobQueue to the frontend.

use crate::AppState;
use crate::jobs::JobSnapshot;
use tauri::State;

#[tauri::command]
pub async fn list_jobs(state: State<'_, AppState>) -> Result<Vec<JobSnapshot>, String> {
    Ok(state.jobs.list().await)
}

/// Cancel a job by id. The worker is notified asynchronously and will (a)
/// kill any child process it owns, (b) call `mark_cancelled`. The command
/// returns immediately — frontend should rely on the `jobs:update` event for
/// the eventual status change.
#[tauri::command]
pub async fn cancel_job(state: State<'_, AppState>, id: String) -> Result<(), String> {
    state.jobs.cancel(&id).await?;
    state.export.cancel(Some(&id)).await;
    Ok(())
}
