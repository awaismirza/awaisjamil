//! Disposable preview cache identity and FFmpeg arguments, independent of Tauri.

use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum PreviewQuality {
    Balanced,
    Low,
}

impl PreviewQuality {
    pub fn max_dimension(self) -> u32 {
        match self {
            Self::Balanced => 1280,
            Self::Low => 640,
        }
    }

    fn crf(self) -> &'static str {
        match self {
            Self::Balanced => "24",
            Self::Low => "28",
        }
    }
}

/// Length-prefix every field so separators inside paths/variants cannot alias.
/// Metadata participates alongside the stored hash to invalidate modified media
/// even when a project's stored source hash predates the current file contents.
pub fn cache_key(
    source_path: &str,
    stored_sha: &str,
    file_len: u64,
    modified_nanos: u128,
    variant: &str,
) -> String {
    let mut hash = Sha256::new();
    let file_len_bytes = file_len.to_be_bytes();
    let modified_bytes = modified_nanos.to_be_bytes();
    for field in [
        b"yusafcut-preview-cache-v1".as_slice(),
        source_path.as_bytes(),
        stored_sha.as_bytes(),
        file_len_bytes.as_slice(),
        modified_bytes.as_slice(),
        variant.as_bytes(),
    ] {
        hash.update((field.len() as u64).to_be_bytes());
        hash.update(field);
    }
    hex::encode(hash.finalize())
}

/// Decode source-aligned mono PCM. Raw PCM has no timestamps, so explicitly
/// insert leading silence (or trim negative PTS) before discarding timestamps.
pub fn waveform_args(input: &str) -> Vec<String> {
    [
        "-nostdin",
        "-v",
        "error",
        "-threads",
        "2",
        "-filter_threads",
        "1",
        "-i",
        input,
        "-map",
        "0:a:0",
        "-vn",
        "-ac",
        "1",
        "-af",
        "aresample=8000:first_pts=0",
        "-ar",
        "8000",
        "-f",
        "s16le",
        "pipe:1",
    ]
    .into_iter()
    .map(str::to_owned)
    .collect()
}

/// Pass these as process arguments, never through a shell. Preserve source
/// timing and optional audio; do not trim, change frame rate, or offset tracks.
pub fn proxy_args(input: &str, output: &str, quality: PreviewQuality) -> Vec<String> {
    let dimension = quality.max_dimension();
    // Quotes belong to FFmpeg's expression parser, not a shell. The single
    // filter argument retains aspect ratio, rounds down to even dimensions,
    // and only raises pathological dimensions smaller than two pixels to two.
    let scale = format!(
        "scale=w='max(2,trunc(iw*min(1,{dimension}/max(iw,ih))/2)*2)':h='max(2,trunc(ih*min(1,{dimension}/max(iw,ih))/2)*2)'"
    );
    let output = if output.starts_with('-') {
        format!("./{output}")
    } else {
        output.to_owned()
    };
    [
        "-y",
        "-nostdin",
        "-filter_threads",
        "1",
        "-i",
        input,
        "-map",
        "0:v:0",
        "-map",
        "0:a:0?",
        "-vf",
        &scale,
        "-c:v",
        "libx264",
        "-preset",
        "ultrafast",
        "-crf",
        quality.crf(),
        "-pix_fmt",
        "yuv420p",
        "-threads",
        "2",
        "-fps_mode",
        "passthrough",
        "-c:a",
        "aac",
        "-ar",
        "48000",
        "-movflags",
        "+faststart",
        "-f",
        "mp4",
        &output,
    ]
    .into_iter()
    .map(str::to_owned)
    .collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    fn option<'a>(args: &'a [String], flag: &str) -> &'a str {
        let index = args.iter().position(|arg| arg == flag).unwrap();
        &args[index + 1]
    }

    #[test]
    fn waveform_decoder_is_bounded_mono_and_source_aligned() {
        let input = "/tmp/source with spaces.mp4";
        let args = waveform_args(input);
        assert_eq!(option(&args, "-i"), input);
        assert_eq!(option(&args, "-threads"), "2");
        assert_eq!(option(&args, "-filter_threads"), "1");
        assert_eq!(option(&args, "-ac"), "1");
        assert_eq!(option(&args, "-ar"), "8000");
        assert_eq!(option(&args, "-f"), "s16le");
        assert_eq!(option(&args, "-af"), "aresample=8000:first_pts=0");
        assert!(args.iter().any(|arg| arg == "-nostdin"));
        assert_eq!(args.last().unwrap(), "pipe:1");
    }

    #[test]
    fn real_ffmpeg_waveform_preserves_delayed_audio_source_time() {
        use std::{
            path::PathBuf,
            process::Command,
            time::{SystemTime, UNIX_EPOCH},
        };
        let ffmpeg =
            PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("binaries/ffmpeg-aarch64-apple-darwin");
        if !ffmpeg.is_file() {
            eprintln!("skipping delayed-audio waveform test: bundled ffmpeg not present");
            return;
        }
        struct Fixture(PathBuf);
        impl Drop for Fixture {
            fn drop(&mut self) {
                let _ = std::fs::remove_dir_all(&self.0);
            }
        }
        let dir = Fixture(std::env::temp_dir().join(format!(
            "yusafcut-waveform-offset-{}-{}", std::process::id(),
            SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_nanos()
        )));
        std::fs::create_dir_all(&dir.0).unwrap();
        let source = dir.0.join("delayed audio.mp4");
        let generated = Command::new(&ffmpeg)
            .args([
                "-y",
                "-nostdin",
                "-v",
                "error",
                "-f",
                "lavfi",
                "-i",
                "color=black:s=32x32:r=10:d=4",
                "-itsoffset",
                "1.5",
                "-f",
                "lavfi",
                "-i",
                "sine=frequency=440:sample_rate=8000:duration=2.5",
                "-map",
                "0:v:0",
                "-map",
                "1:a:0",
                "-c:v",
                "libx264",
                "-threads",
                "1",
                "-c:a",
                "aac",
            ])
            .arg(&source)
            .output()
            .unwrap();
        assert!(
            generated.status.success(),
            "fixture: {}",
            String::from_utf8_lossy(&generated.stderr)
        );
        let decoded = Command::new(&ffmpeg)
            .args(waveform_args(source.to_str().unwrap()))
            .output()
            .unwrap();
        assert!(
            decoded.status.success(),
            "decode: {}",
            String::from_utf8_lossy(&decoded.stderr)
        );
        assert_eq!(decoded.stdout.len() % 2, 0);
        let samples: Vec<_> = decoded
            .stdout
            .chunks_exact(2)
            .map(|bytes| i16::from_le_bytes([bytes[0], bytes[1]]))
            .collect();
        let duration = samples.len() as f64 / 8000.0;
        assert!(
            (3.95..4.15).contains(&duration),
            "source duration: {duration}"
        );
        // The first second precedes the delayed stream; its tone belongs at
        // source time 1.5 s, rather than at the first decoded sample.
        assert!(samples[..8000].iter().all(|sample| *sample == 0));
        assert!(samples[16000..24000]
            .iter()
            .any(|sample| i32::from(*sample).abs() > 1000));
    }

    #[test]
    fn qualities_have_stable_names_dimensions_and_encoding_settings() {
        for (quality, name, dimension, crf) in [
            (PreviewQuality::Balanced, "balanced", 1280, "24"),
            (PreviewQuality::Low, "low", 640, "28"),
        ] {
            assert_eq!(serde_json::to_value(quality).unwrap(), name);
            assert_eq!(
                serde_json::from_value::<PreviewQuality>(name.into()).unwrap(),
                quality
            );
            assert_eq!(quality.max_dimension(), dimension);
            let args = proxy_args("/input.mov", "/cache/proxy.mp4", quality);
            assert_eq!(option(&args, "-c:v"), "libx264");
            assert_eq!(option(&args, "-preset"), "ultrafast");
            assert_eq!(option(&args, "-crf"), crf);
            assert_eq!(option(&args, "-threads"), "2");
            assert_eq!(option(&args, "-filter_threads"), "1");
            assert_eq!(option(&args, "-movflags"), "+faststart");
            assert_eq!(option(&args, "-f"), "mp4");
        }
    }

    #[test]
    fn dimensions_are_bounded_without_upscaling_and_rounded_even() {
        for quality in [PreviewQuality::Balanced, PreviewQuality::Low] {
            let args = proxy_args("/input", "/output", quality);
            let filter = option(&args, "-vf");
            let factor = format!("min(1,{}/max(iw,ih))", quality.max_dimension());
            assert_eq!(filter.matches(&factor).count(), 2);
            assert!(filter.contains("w='max(2,trunc(iw*"));
            assert!(filter.contains("h='max(2,trunc(ih*"));
            assert_eq!(filter.matches("/2)*2)").count(), 2);
            assert_eq!(args.iter().filter(|arg| arg.as_str() == "-vf").count(), 1);
        }
    }

    #[test]
    fn retains_timing_and_optional_audio() {
        let args = proxy_args("/input", "/output", PreviewQuality::Balanced);
        let maps: Vec<_> = args
            .windows(2)
            .filter(|pair| pair[0] == "-map")
            .map(|pair| pair[1].as_str())
            .collect();
        assert_eq!(maps, ["0:v:0", "0:a:0?"]);
        assert_eq!(option(&args, "-c:a"), "aac");
        assert_eq!(option(&args, "-ar"), "48000");
        assert_eq!(option(&args, "-fps_mode"), "passthrough");
        for flag in [
            "-ss",
            "-to",
            "-t",
            "-r",
            "-itsoffset",
            "-shortest",
            "-copyts",
            "-start_at_zero",
        ] {
            assert!(!args.iter().any(|arg| arg == flag));
        }
    }

    #[test]
    fn paths_remain_single_literal_arguments_and_dash_outputs_are_safe() {
        let input = "/tmp/a b';$(touch surprise).mov";
        let output = "/tmp/out ;' $(echo no).mp4";
        let args = proxy_args(input, output, PreviewQuality::Low);
        assert_eq!(option(&args, "-i"), input);
        assert_eq!(args.last().unwrap(), output);
        assert!(args.iter().any(|arg| arg == "-y"));
        assert!(args.iter().any(|arg| arg == "-nostdin"));
        let dash = proxy_args("-input.mov", "-output.mp4", PreviewQuality::Low);
        assert_eq!(option(&dash, "-i"), "-input.mov");
        assert_eq!(dash.last().unwrap(), "./-output.mp4");
    }

    #[test]
    fn every_identity_field_invalidates_the_cache() {
        let base = cache_key("/source", "sha", 42, 123, "balanced");
        assert_eq!(base.len(), 64);
        assert_eq!(base, cache_key("/source", "sha", 42, 123, "balanced"));
        for key in [
            cache_key("/other", "sha", 42, 123, "balanced"),
            cache_key("/source", "changed", 42, 123, "balanced"),
            cache_key("/source", "sha", 43, 123, "balanced"),
            cache_key("/source", "sha", 42, 124, "balanced"),
            cache_key("/source", "sha", 42, 123, "low"),
        ] {
            assert_ne!(base, key);
        }
        assert_ne!(
            cache_key("ab", "c", 42, 123, "x"),
            cache_key("a", "bc", 42, 123, "x")
        );
    }
}
