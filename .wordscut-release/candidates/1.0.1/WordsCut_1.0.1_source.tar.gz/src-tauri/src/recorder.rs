//! Recorder — pure logic for the in-app screen/camera/voice recorder.
//!
//! Everything here is side-effect free (arg builders, parsers, manifest
//! generation) so it can be unit-tested without spawning ffmpeg. The actual
//! process management lives in `commands::record`.

use serde::{Deserialize, Serialize};
use std::path::Path;

// ---------------------------------------------------------------------------
// Device enumeration
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, Serialize, PartialEq)]
#[serde(rename_all = "camelCase")]
pub struct VideoDevice {
    pub index: u32,
    pub name: String,
    pub is_screen: bool,
}

#[derive(Debug, Clone, Serialize, PartialEq)]
#[serde(rename_all = "camelCase")]
pub struct AudioDevice {
    pub index: u32,
    pub name: String,
}

#[derive(Debug, Clone, Serialize, Default, PartialEq)]
#[serde(rename_all = "camelCase")]
pub struct RecordingDevices {
    pub video: Vec<VideoDevice>,
    pub audio: Vec<AudioDevice>,
    /// Which recorder produced this listing: "native" (ScreenCaptureKit helper)
    /// or "ffmpeg" (avfoundation fallback). Empty on a bare `default()`.
    pub backend: String,
    /// Capturable windows. Only the native helper can list them.
    pub windows: Vec<WindowDevice>,
    /// Permission state reported by the native helper, when it answered.
    pub permissions: Option<serde_json::Value>,
    /// Native recorder only: size of each screen in points, for area selection.
    pub displays: Vec<DisplayInfo>,
}

/// A screen's geometry, keyed by the same index as its [`VideoDevice`].
#[derive(Debug, Clone, Serialize, PartialEq)]
#[serde(rename_all = "camelCase")]
pub struct DisplayInfo {
    pub index: u32,
    pub width: f64,
    pub height: f64,
}

/// A rectangle of one display in that display's points, origin top-left.
#[derive(Debug, Clone, Copy, Deserialize, Serialize, PartialEq)]
pub struct AreaRect {
    pub x: f64,
    pub y: f64,
    pub width: f64,
    pub height: f64,
}

#[derive(Debug, Clone, Serialize, PartialEq)]
#[serde(rename_all = "camelCase")]
pub struct WindowDevice {
    pub id: u32,
    pub title: String,
    pub app: String,
}

/// Parse the stderr of `ffmpeg -f avfoundation -list_devices true -i ""`.
///
/// The listing looks like:
/// ```text
/// [AVFoundation indev @ 0x...] AVFoundation video devices:
/// [AVFoundation indev @ 0x...] [0] FaceTime HD Camera
/// [AVFoundation indev @ 0x...] [1] Capture screen 0
/// [AVFoundation indev @ 0x...] AVFoundation audio devices:
/// [AVFoundation indev @ 0x...] [0] MacBook Pro Microphone
/// ```
pub fn parse_avfoundation_devices(stderr: &str) -> RecordingDevices {
    #[derive(PartialEq)]
    enum Section {
        None,
        Video,
        Audio,
    }
    let mut section = Section::None;
    let mut out = RecordingDevices::default();

    for line in stderr.lines() {
        if line.contains("AVFoundation video devices") {
            section = Section::Video;
            continue;
        }
        if line.contains("AVFoundation audio devices") {
            section = Section::Audio;
            continue;
        }
        if section == Section::None {
            continue;
        }
        // Device lines end with `] [<idx>] <name>` — take the *last* bracket pair.
        let Some((idx, name)) = parse_device_line(line) else {
            continue;
        };
        match section {
            Section::Video => out.video.push(VideoDevice {
                index: idx,
                is_screen: name.starts_with("Capture screen"),
                name,
            }),
            Section::Audio => out.audio.push(AudioDevice { index: idx, name }),
            Section::None => {}
        }
    }
    out
}

fn parse_device_line(line: &str) -> Option<(u32, String)> {
    // Take the FIRST `[digits]` pair as the device index — the log prefix
    // (`[AVFoundation indev @ 0x…]`) never parses as pure digits, and device
    // names may themselves contain bracketed numbers further right.
    let mut found: Option<(u32, usize)> = None;
    let mut i = 0;
    while let Some(open_rel) = line[i..].find('[') {
        let open = i + open_rel;
        let Some(close_rel) = line[open..].find(']') else {
            break;
        };
        let close_abs = open + close_rel;
        let inner = &line[open + 1..close_abs];
        if !inner.is_empty() && inner.bytes().all(|b| b.is_ascii_digit()) {
            found = Some((inner.parse().ok()?, close_abs));
            break;
        }
        i = close_abs + 1;
    }
    let (idx, name_start) = found?;
    let name = line[name_start + 1..].trim();
    if name.is_empty() {
        return None;
    }
    Some((idx, name.to_string()))
}

// ---------------------------------------------------------------------------
// Recording options + ffmpeg argument builder
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, Copy, PartialEq, Default, Deserialize, Serialize)]
#[serde(rename_all = "kebab-case")]
pub enum RecordMode {
    #[default]
    Screen,
    ScreenCamera,
    Camera,
    Voiceover,
}

impl RecordMode {
    pub fn as_str(&self) -> &'static str {
        match self {
            RecordMode::Screen => "screen",
            RecordMode::ScreenCamera => "screen-camera",
            RecordMode::Camera => "camera",
            RecordMode::Voiceover => "voiceover",
        }
    }

    pub fn extension(&self) -> &'static str {
        match self {
            RecordMode::Voiceover => "m4a",
            _ => "mp4",
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Deserialize, Serialize)]
#[serde(rename_all = "kebab-case")]
pub enum PipCorner {
    TopLeft,
    TopRight,
    BottomLeft,
    BottomRight,
}

#[derive(Debug, Clone, Copy, PartialEq, Deserialize, Serialize)]
#[serde(rename_all = "kebab-case")]
pub enum PipSize {
    Small,
    Medium,
    Large,
}

impl PipSize {
    /// Webcam bubble width as a fraction of the main (screen) width.
    fn fraction(&self) -> f32 {
        match self {
            PipSize::Small => 0.18,
            PipSize::Medium => 0.25,
            PipSize::Large => 0.33,
        }
    }
}

#[derive(Debug, Clone, Default, Deserialize, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct RecordOptions {
    pub mode: RecordMode,
    /// avfoundation video index of the screen to capture.
    pub screen_index: Option<u32>,
    /// avfoundation video index of the camera.
    pub camera_index: Option<u32>,
    /// avfoundation audio index of the microphone. `None` disables audio.
    pub audio_index: Option<u32>,
    pub fps: Option<u32>,
    pub pip_corner: Option<PipCorner>,
    pub pip_size: Option<PipSize>,
    /// Native recorder only: capture this window (by window id) instead of a
    /// whole display.
    #[serde(default)]
    pub window_id: Option<u32>,
    /// Native recorder only: capture this rectangle of the chosen screen.
    /// Ignored when `window_id` is set.
    #[serde(default)]
    pub area: Option<AreaRect>,
    /// Native recorder only: also record the system audio of the captured screen.
    #[serde(default)]
    pub system_audio: Option<bool>,
    /// What the editor will do with the take, echoed in `RecordingResult`
    /// (`"voiceover-take"`: the voice-over review, never the timeline append).
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub purpose: Option<String>,
    /// Native recorder only, opt-in: log which shortcut / non-printable keys were
    /// pressed (`docs/cursor-events.md`). Off by default.
    #[serde(default)]
    pub record_key_identity: Option<bool>,
    /// Second opt-in, needs `record_key_identity`: also log ordinary characters.
    #[serde(default)]
    pub record_all_characters: Option<bool>,
}

const PIP_MARGIN: u32 = 28;

/// Fragmented MP4 plus a flush on every packet. Without `-flush_packets 1` ffmpeg
/// buffers its output, so a killed process leaves a 28-byte file with no footage.
const FLUSH_PACKETS: [&str; 2] = ["-flush_packets", "1"];

/// Fragmented MP4: the file is playable up to the last keyframe even if ffmpeg
/// is killed or crashes mid-take (a normal MP4 writes its index at the end, so a
/// crash leaves an unreadable "moov atom not found" file and the take is lost).
/// The finished recording is remuxed to a normal MP4 afterwards.
const FRAGMENTED_MP4: &str = "+frag_keyframe+empty_moov+default_base_moof";

/// Where the camera track of a screen + camera segment is written, beside the
/// screen file: `seg-000.mp4` -> `seg-000.camera.mp4`.
pub fn camera_path_for(screen: &Path) -> std::path::PathBuf {
    let stem = screen.file_stem().and_then(|s| s.to_str()).unwrap_or("segment");
    let ext = screen.extension().and_then(|s| s.to_str()).unwrap_or("mp4");
    screen.with_file_name(format!("{stem}.camera.{ext}"))
}

/// Where the composited (picture-in-picture) segment is written.
pub fn composited_path_for(screen: &Path) -> std::path::PathBuf {
    let stem = screen.file_stem().and_then(|s| s.to_str()).unwrap_or("segment");
    screen.with_file_name(format!("{stem}.pip.mp4"))
}

/// Build the full ffmpeg argument list for one recording segment.
pub fn build_ffmpeg_args(opts: &RecordOptions, output: &Path) -> Result<Vec<String>, String> {
    let fps = opts.fps.unwrap_or(30).clamp(10, 60).to_string();
    let audio = opts
        .audio_index
        .map(|i| i.to_string())
        .unwrap_or_else(|| "none".into());
    let mut args: Vec<String> = vec![
        "-y".into(), "-hide_banner".into(), "-nostats".into(),
        "-stats_period".into(), "0.1".into(), "-progress".into(), "pipe:1".into(),
    ];

    match opts.mode {
        RecordMode::Screen | RecordMode::ScreenCamera => {
            let screen = opts
                .screen_index
                .ok_or("screen recording requires a screen device")?;
            // A keyframe every second bounds what a crash can lose to about a second.
            let gop = opts.fps.unwrap_or(30).clamp(10, 60).to_string();
            args.extend([
                "-f".into(),
                "avfoundation".into(),
                "-framerate".into(),
                fps.clone(),
                "-capture_cursor".into(),
                "1".into(),
                "-capture_mouse_clicks".into(),
                "1".into(),
                "-i".into(),
                format!("{screen}:{audio}"),
            ]);

            let with_camera = opts.mode == RecordMode::ScreenCamera;
            if with_camera {
                let camera = opts
                    .camera_index
                    .ok_or("screen + camera recording requires a camera device")?;
                args.extend([
                    "-f".into(),
                    "avfoundation".into(),
                    "-framerate".into(),
                    fps.clone(),
                    "-i".into(),
                    format!("{camera}:none"),
                ]);
                // Each input goes to its own file. Mixing the live camera into the
                // screen here (a multi-input filter graph) crashes some ffmpeg 7.1
                // builds with "Assertion best_input >= 0 failed"; the two files are
                // composited after the take, from finished files, which is safe.
                args.extend(["-map".into(), "0:v".into()]);
                if opts.audio_index.is_some() {
                    args.extend(["-map".into(), "0:a".into()]);
                }
            }

            args.extend([
                "-c:v".into(),
                "h264_videotoolbox".into(),
                "-b:v".into(),
                "8000k".into(),
                "-pix_fmt".into(),
                "yuv420p".into(),
                "-g".into(),
                gop.clone(),
            ]);
            if opts.audio_index.is_some() {
                args.extend(["-c:a".into(), "aac".into(), "-b:a".into(), "192k".into()]);
            }
            args.extend(FLUSH_PACKETS.map(String::from));
            args.extend(["-movflags".into(), FRAGMENTED_MP4.into()]);
            args.push(output.to_string_lossy().into_owned());

            if with_camera {
                args.extend([
                    "-map".into(),
                    "1:v".into(),
                    "-c:v".into(),
                    "h264_videotoolbox".into(),
                    "-b:v".into(),
                    "4000k".into(),
                    "-pix_fmt".into(),
                    "yuv420p".into(),
                    "-g".into(),
                    gop,
                    "-flush_packets".into(),
                    "1".into(),
                    "-movflags".into(),
                    FRAGMENTED_MP4.into(),
                    camera_path_for(output).to_string_lossy().into_owned(),
                ]);
            }
            return Ok(args);
        }
        RecordMode::Camera => {
            let camera = opts
                .camera_index
                .ok_or("camera recording requires a camera device")?;
            args.extend([
                "-f".into(),
                "avfoundation".into(),
                "-framerate".into(),
                fps.clone(),
                "-i".into(),
                format!("{camera}:{audio}"),
                "-c:v".into(),
                "h264_videotoolbox".into(),
                "-b:v".into(),
                "6000k".into(),
                "-pix_fmt".into(),
                "yuv420p".into(),
            ]);
            if opts.audio_index.is_some() {
                args.extend(["-c:a".into(), "aac".into(), "-b:a".into(), "192k".into()]);
            }
        }
        RecordMode::Voiceover => {
            if opts.audio_index.is_none() {
                return Err("voice-over recording requires a microphone".into());
            }
            args.extend([
                "-f".into(),
                "avfoundation".into(),
                "-i".into(),
                format!(":{audio}"),
                "-c:a".into(),
                "aac".into(),
                "-b:a".into(),
                "192k".into(),
            ]);
        }
    }

    // Fragmented, so an interrupted segment is still salvageable.
    if opts.mode != RecordMode::Voiceover {
        args.extend(FLUSH_PACKETS.map(String::from));
        args.extend(["-movflags".into(), FRAGMENTED_MP4.into()]);
    }
    args.push(output.to_string_lossy().into_owned());
    Ok(args)
}

/// filter_complex string compositing the camera into a corner of the screen.
pub(crate) fn pip_filter(opts: &RecordOptions) -> String {
    let frac = opts.pip_size.unwrap_or(PipSize::Medium).fraction();
    let m = PIP_MARGIN;
    let (x, y) = match opts.pip_corner.unwrap_or(PipCorner::BottomRight) {
        PipCorner::TopLeft => (format!("{m}"), format!("{m}")),
        PipCorner::TopRight => (format!("main_w-overlay_w-{m}"), format!("{m}")),
        PipCorner::BottomLeft => (format!("{m}"), format!("main_h-overlay_h-{m}")),
        PipCorner::BottomRight => (
            format!("main_w-overlay_w-{m}"),
            format!("main_h-overlay_h-{m}"),
        ),
    };
    // `scale` with a reference input sizes the camera relative to the screen:
    // `ref_w` is the screen's width, `iw`/`ih` are the camera's own. Widths are
    // forced even for yuv420p. (The older `scale2ref` form read `main_w` as the
    // camera in ffmpeg 7.1, which made the bubble half its intended size.)
    format!(
        "[1:v][0:v]scale=w='trunc(ref_w*{frac}/2)*2':h='trunc(ref_w*{frac}*ih/iw/2)*2'[cam];[0:v][cam]overlay={x}:{y}:shortest=1"
    )
}

// ---------------------------------------------------------------------------
// Segment concat
// ---------------------------------------------------------------------------

/// Manifest for ffmpeg's concat demuxer. Paths are single-quoted with
/// embedded quotes escaped per ffmpeg's `'\''` convention.
pub fn build_concat_manifest(segments: &[std::path::PathBuf]) -> String {
    let mut out = String::new();
    for seg in segments {
        let path = seg.to_string_lossy().replace('\'', "'\\''");
        out.push_str(&format!("file '{path}'\n"));
    }
    out
}

/// Composite a finished camera file into a finished screen file (picture in
/// picture) and keep the screen's audio. Both inputs are complete files, so the
/// filter graph has no live sources to stall.
pub fn composite_args(
    screen: &Path,
    camera: &Path,
    output: &Path,
    opts: &RecordOptions,
) -> Vec<String> {
    vec![
        "-y".into(),
        "-hide_banner".into(),
        "-i".into(),
        screen.to_string_lossy().into_owned(),
        "-i".into(),
        camera.to_string_lossy().into_owned(),
        "-filter_complex".into(),
        format!("{}[outv]", pip_filter(opts)),
        "-map".into(),
        "[outv]".into(),
        "-map".into(),
        "0:a?".into(),
        "-c:v".into(),
        "h264_videotoolbox".into(),
        "-b:v".into(),
        "8000k".into(),
        "-pix_fmt".into(),
        "yuv420p".into(),
        "-c:a".into(),
        "copy".into(),
        "-movflags".into(),
        "+faststart".into(),
        output.to_string_lossy().into_owned(),
    ]
}

/// Rewrite a (possibly fragmented) segment as a normal MP4 without re-encoding.
pub fn remux_args(input: &Path, output: &Path) -> Vec<String> {
    vec![
        "-y".into(),
        "-hide_banner".into(),
        "-i".into(),
        input.to_string_lossy().into_owned(),
        "-c".into(),
        "copy".into(),
        "-movflags".into(),
        "+faststart".into(),
        output.to_string_lossy().into_owned(),
    ]
}

pub fn concat_args(manifest: &Path, output: &Path) -> Vec<String> {
    vec![
        "-y".into(),
        "-hide_banner".into(),
        "-f".into(),
        "concat".into(),
        "-safe".into(),
        "0".into(),
        "-i".into(),
        manifest.to_string_lossy().into_owned(),
        "-c".into(),
        "copy".into(),
        "-movflags".into(),
        "+faststart".into(),
        output.to_string_lossy().into_owned(),
    ]
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;
    use std::path::PathBuf;

    const SAMPLE: &str = "\
[AVFoundation indev @ 0x7f8] AVFoundation video devices:
[AVFoundation indev @ 0x7f8] [0] FaceTime HD Camera
[AVFoundation indev @ 0x7f8] [1] OBS Virtual Camera
[AVFoundation indev @ 0x7f8] [2] Capture screen 0
[AVFoundation indev @ 0x7f8] [3] Capture screen 1
[AVFoundation indev @ 0x7f8] AVFoundation audio devices:
[AVFoundation indev @ 0x7f8] [0] MacBook Pro Microphone
[AVFoundation indev @ 0x7f8] [1] External USB Mic [2]
: Input/output error";

    /// Both wave-2 additions to `RecordOptions` (voice-over `purpose`, key-identity
    /// opt-ins) read and write the camelCase names the editor sends.
    #[test]
    fn purpose_and_key_identity_round_trip_in_camel_case() {
        let json = r#"{"mode":"screen","purpose":"voiceover-take","recordKeyIdentity":true,"recordAllCharacters":false}"#;
        let o: RecordOptions = serde_json::from_str(json).unwrap();
        assert_eq!(o.purpose.as_deref(), Some("voiceover-take"));
        assert_eq!(o.record_key_identity, Some(true));
        assert_eq!(o.record_all_characters, Some(false));
        let back = serde_json::to_value(&o).unwrap();
        assert_eq!(back["purpose"], "voiceover-take");
        assert_eq!(back["recordKeyIdentity"], true);
        assert_eq!(back["recordAllCharacters"], false);
        assert!(back.get("record_key_identity").is_none());
    }

    #[test]
    fn parses_video_and_audio_sections() {
        let d = parse_avfoundation_devices(SAMPLE);
        assert_eq!(d.video.len(), 4);
        assert_eq!(d.audio.len(), 2);
        assert_eq!(d.video[0].name, "FaceTime HD Camera");
        assert!(!d.video[0].is_screen);
        assert!(d.video[2].is_screen);
        assert_eq!(d.video[3].name, "Capture screen 1");
        assert_eq!(d.audio[0].name, "MacBook Pro Microphone");
    }

    #[test]
    fn device_name_containing_brackets_keeps_full_name() {
        // "[1] External USB Mic [2]" — the trailing "[2]" is part of the name.
        let d = parse_avfoundation_devices(SAMPLE);
        assert_eq!(d.audio[1].index, 1);
        assert_eq!(d.audio[1].name, "External USB Mic [2]");
    }

    #[test]
    fn screen_args_include_cursor_capture_and_audio() {
        let opts = RecordOptions {
            mode: RecordMode::Screen,
            screen_index: Some(2),
            camera_index: None,
            audio_index: Some(0),
            fps: None,
            pip_corner: None,
            pip_size: None,
            ..Default::default()
        };
        let args = build_ffmpeg_args(&opts, Path::new("/tmp/seg-000.mp4")).unwrap();
        let joined = args.join(" ");
        assert!(joined.contains("-i 2:0"));
        assert!(joined.contains("-capture_cursor 1"));
        assert!(joined.contains("h264_videotoolbox"));
        assert!(joined.contains("-c:a aac"));
    }

    #[test]
    fn screen_without_mic_omits_audio_codec() {
        let opts = RecordOptions {
            mode: RecordMode::Screen,
            screen_index: Some(1),
            camera_index: None,
            audio_index: None,
            fps: Some(60),
            pip_corner: None,
            pip_size: None,
            ..Default::default()
        };
        let args = build_ffmpeg_args(&opts, Path::new("/tmp/s.mp4")).unwrap();
        let joined = args.join(" ");
        assert!(joined.contains("-i 1:none"));
        assert!(!joined.contains("-c:a"));
        assert!(joined.contains("-framerate 60"));
    }

    fn pip_opts(corner: PipCorner, size: PipSize) -> RecordOptions {
        RecordOptions {
            mode: RecordMode::ScreenCamera,
            screen_index: Some(2),
            camera_index: Some(0),
            audio_index: Some(0),
            fps: None,
            pip_corner: Some(corner),
            pip_size: Some(size),
            ..Default::default()
        }
    }

    #[test]
    fn screen_camera_records_two_separate_files_with_no_live_filter_graph() {
        let args = build_ffmpeg_args(
            &pip_opts(PipCorner::TopLeft, PipSize::Small),
            Path::new("/tmp/seg-000.mp4"),
        )
        .unwrap();
        let joined = args.join(" ");
        // The live multi-input filter graph is what crashed ffmpeg 7.1.
        assert!(!joined.contains("-filter_complex"));
        assert!(!joined.contains("scale2ref"));
        assert!(!joined.contains("overlay"));
        // Two avfoundation inputs, two outputs.
        assert_eq!(joined.matches("avfoundation").count(), 2);
        assert!(joined.contains("/tmp/seg-000.mp4"));
        assert!(joined.contains("/tmp/seg-000.camera.mp4"));
        // Screen (+ mic) to the first file, camera only to the second.
        assert!(joined.contains("-map 0:v -map 0:a"));
        assert!(joined.contains("-map 1:v"));
        assert!(joined.contains("-i 2:0"));
        assert!(joined.contains("-i 0:none"));
    }

    #[test]
    fn screen_camera_without_a_mic_maps_no_audio() {
        let mut o = pip_opts(PipCorner::BottomRight, PipSize::Medium);
        o.audio_index = None;
        let joined = build_ffmpeg_args(&o, Path::new("/tmp/s.mp4")).unwrap().join(" ");
        assert!(!joined.contains("0:a"));
        assert!(!joined.contains("-c:a"));
    }

    #[test]
    fn segments_are_fragmented_so_a_crash_cannot_lose_the_take() {
        for mode in [RecordMode::Screen, RecordMode::ScreenCamera, RecordMode::Camera] {
            let mut o = pip_opts(PipCorner::BottomRight, PipSize::Medium);
            o.mode = mode;
            let joined = build_ffmpeg_args(&o, Path::new("/tmp/s.mp4")).unwrap().join(" ");
            assert!(joined.contains("frag_keyframe+empty_moov"), "{mode:?}: {joined}");
            assert!(joined.contains("-flush_packets 1"), "{mode:?} must flush every packet");
            assert!(!joined.contains("+faststart"), "{mode:?} must not rely on a closing index");
        }
    }

    #[test]
    fn screen_camera_has_two_fragmented_outputs() {
        let joined = build_ffmpeg_args(
            &pip_opts(PipCorner::BottomRight, PipSize::Medium),
            Path::new("/tmp/s.mp4"),
        )
        .unwrap()
        .join(" ");
        assert_eq!(joined.matches("frag_keyframe+empty_moov").count(), 2);
        assert_eq!(joined.matches("-flush_packets 1").count(), 2);
    }

    #[test]
    fn camera_and_composited_paths_sit_beside_the_screen_file() {
        assert_eq!(
            camera_path_for(Path::new("/r/seg-003.mp4")),
            PathBuf::from("/r/seg-003.camera.mp4")
        );
        assert_eq!(
            composited_path_for(Path::new("/r/seg-003.mp4")),
            PathBuf::from("/r/seg-003.pip.mp4")
        );
    }

    #[test]
    fn composite_overlays_the_camera_in_the_chosen_corner_and_keeps_audio() {
        let args = composite_args(
            Path::new("/r/s.mp4"),
            Path::new("/r/s.camera.mp4"),
            Path::new("/r/s.pip.mp4"),
            &pip_opts(PipCorner::TopLeft, PipSize::Small),
        );
        let joined = args.join(" ");
        assert!(joined.contains("overlay=28:28:shortest=1[outv]"));
        assert!(joined.contains("-map [outv] -map 0:a?"));
        assert!(joined.contains("-c:a copy"));
        assert!(joined.contains("+faststart"));
        assert!(joined.ends_with("/r/s.pip.mp4"));
    }

    #[test]
    fn remux_copies_streams_into_a_normal_mp4() {
        let joined = remux_args(Path::new("/r/in.mp4"), Path::new("/r/out.mp4")).join(" ");
        assert!(joined.contains("-c copy"));
        assert!(joined.contains("+faststart"));
    }

    #[test]
    fn joined_segments_are_also_written_as_a_normal_mp4() {
        let joined = concat_args(Path::new("/r/c.txt"), Path::new("/r/out.mp4")).join(" ");
        assert!(joined.contains("+faststart"));
    }

    #[test]
    fn voiceover_is_audio_only() {
        let opts = RecordOptions {
            mode: RecordMode::Voiceover,
            screen_index: None,
            camera_index: None,
            audio_index: Some(1),
            fps: None,
            pip_corner: None,
            pip_size: None,
            ..Default::default()
        };
        let args = build_ffmpeg_args(&opts, Path::new("/tmp/v.m4a")).unwrap();
        let joined = args.join(" ");
        assert!(joined.contains("-i :1"));
        assert!(!joined.contains("videotoolbox"));
    }

    #[test]
    fn missing_required_device_errors() {
        let opts = RecordOptions {
            mode: RecordMode::Screen,
            screen_index: None,
            camera_index: None,
            audio_index: None,
            fps: None,
            pip_corner: None,
            pip_size: None,
            ..Default::default()
        };
        assert!(build_ffmpeg_args(&opts, Path::new("/tmp/x.mp4")).is_err());
    }

    #[test]
    fn concat_manifest_escapes_quotes() {
        let segs = vec![
            PathBuf::from("/tmp/a/seg-000.mp4"),
            PathBuf::from("/tmp/it's/seg-001.mp4"),
        ];
        let m = build_concat_manifest(&segs);
        assert_eq!(
            m,
            "file '/tmp/a/seg-000.mp4'\nfile '/tmp/it'\\''s/seg-001.mp4'\n"
        );
    }

    // -----------------------------------------------------------------------
    // Real ffmpeg: composite finished files, and salvage a killed recording.
    // -----------------------------------------------------------------------

    use std::process::{Command, Stdio};

    fn bin(name: &str) -> Option<PathBuf> {
        let p = Path::new(env!("CARGO_MANIFEST_DIR")).join(format!("binaries/{name}-aarch64-apple-darwin"));
        let big = std::fs::metadata(&p).map(|m| m.len() > 1_000_000).unwrap_or(false);
        (big && Command::new(&p).arg("-version").output().map(|o| o.status.success()).unwrap_or(false))
            .then_some(p)
    }

    struct Dir(PathBuf);
    impl Dir {
        fn new() -> Self {
            let d = std::env::temp_dir().join(format!("yusafcut-rec-{}", uuid::Uuid::new_v4()));
            std::fs::create_dir_all(&d).unwrap();
            Dir(d)
        }
    }
    impl Drop for Dir {
        fn drop(&mut self) {
            let _ = std::fs::remove_dir_all(&self.0);
        }
    }

    /// Software-encode test source with the same movflags the recorder uses.
    fn make_clip(ffmpeg: &Path, out: &Path, colour: &str, size: &str, secs: u32, audio: bool) {
        let mut cmd = Command::new(ffmpeg);
        cmd.args(["-v", "error", "-y", "-f", "lavfi", "-i"])
            .arg(format!("color=c={colour}:s={size}:r=30:d={secs}"));
        if audio {
            cmd.args(["-f", "lavfi", "-i"]).arg(format!("sine=frequency=440:duration={secs}"));
        }
        cmd.args(["-c:v", "libx264", "-pix_fmt", "yuv420p", "-g", "60"]);
        if audio {
            cmd.args(["-c:a", "aac", "-shortest"]);
        }
        cmd.args(["-movflags", FRAGMENTED_MP4]).arg(out);
        let o = cmd.output().unwrap();
        assert!(o.status.success(), "{}", String::from_utf8_lossy(&o.stderr));
    }

    /// The composite uses h264_videotoolbox; swap in libx264 so the test also runs without a GPU encoder.
    fn software(args: Vec<String>) -> Vec<String> {
        args.into_iter().map(|a| if a == "h264_videotoolbox" { "libx264".into() } else { a }).collect()
    }

    fn frame(ffmpeg: &Path, file: &Path, w: u32, h: u32) -> Vec<u8> {
        let o = Command::new(ffmpeg)
            .args(["-v", "error", "-ss", "0.5", "-i"])
            .arg(file)
            .args(["-frames:v", "1", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"])
            .output()
            .unwrap();
        assert!(o.status.success());
        assert_eq!(o.stdout.len(), (w * h * 3) as usize);
        o.stdout
    }

    fn rgb(f: &[u8], w: u32, x: u32, y: u32) -> [i32; 3] {
        let i = ((y * w + x) * 3) as usize;
        [f[i] as i32, f[i + 1] as i32, f[i + 2] as i32]
    }

    fn near(a: [i32; 3], b: [i32; 3]) -> bool {
        a.iter().zip(b).all(|(x, y)| (x - y).abs() <= 18)
    }

    #[test]
    fn real_ffmpeg_composites_the_camera_into_the_corner_and_keeps_the_audio() {
        let (Some(ffmpeg), Some(ffprobe)) = (bin("ffmpeg"), bin("ffprobe")) else {
            eprintln!("skipping: bundled ffmpeg/ffprobe not present");
            return;
        };
        let dir = Dir::new();
        let screen = dir.0.join("seg-000.mp4");
        let camera = camera_path_for(&screen);
        let out = composited_path_for(&screen);
        make_clip(&ffmpeg, &screen, "blue", "1280x720", 2, true);
        make_clip(&ffmpeg, &camera, "red", "640x360", 2, false);

        let args = software(composite_args(
            &screen,
            &camera,
            &out,
            &pip_opts(PipCorner::BottomRight, PipSize::Medium),
        ));
        let o = Command::new(&ffmpeg).args(args).output().unwrap();
        assert!(o.status.success(), "{}", String::from_utf8_lossy(&o.stderr));

        let f = frame(&ffmpeg, &out, 1280, 720);
        // Screen (blue) elsewhere; camera (red, 320x180) bottom-right with a 28 px margin.
        assert!(near(rgb(&f, 1280, 100, 100), [0, 0, 255]), "{:?}", rgb(&f, 1280, 100, 100));
        assert!(near(rgb(&f, 1280, 1100, 600), [255, 0, 0]), "{:?}", rgb(&f, 1280, 1100, 600));
        assert!(near(rgb(&f, 1280, 1265, 705), [0, 0, 255]), "margin {:?}", rgb(&f, 1280, 1265, 705));

        let audio = Command::new(&ffprobe)
            .args(["-v", "error", "-select_streams", "a:0", "-show_entries", "stream=codec_name"])
            .args(["-of", "default=nw=1:nk=1"])
            .arg(&out)
            .output()
            .unwrap();
        assert!(String::from_utf8_lossy(&audio.stdout).contains("aac"), "audio track was lost");
    }

    #[test]
    fn real_ffmpeg_a_killed_recording_is_still_readable_and_can_be_remuxed() {
        let (Some(ffmpeg), Some(ffprobe)) = (bin("ffmpeg"), bin("ffprobe")) else {
            return;
        };
        let dir = Dir::new();
        let broken = dir.0.join("seg.mp4");
        // A live source that would run for 60 s, killed after about 2 s: the crash case.
        let mut child = Command::new(&ffmpeg)
            .args(["-v", "error", "-y", "-re", "-f", "lavfi", "-i", "testsrc2=s=640x360:r=30:d=60"])
            // Low-latency encode, like the hardware encoder the recorder uses (software x264
            // otherwise holds back about a second of frames); a keyframe every half second.
            .args(["-c:v", "libx264", "-preset", "ultrafast", "-tune", "zerolatency"])
            .args(["-pix_fmt", "yuv420p", "-g", "15", "-flush_packets", "1"])
            .args(["-movflags", FRAGMENTED_MP4])
            .arg(&broken)
            .stdin(Stdio::null())
            .spawn()
            .unwrap();
        std::thread::sleep(std::time::Duration::from_millis(3500));
        child.kill().unwrap();
        child.wait().unwrap();

        let probe = |f: &Path| {
            Command::new(&ffprobe)
                .args(["-v", "error", "-select_streams", "v:0", "-show_entries", "stream=codec_name"])
                .args(["-of", "default=nw=1:nk=1"])
                .arg(f)
                .output()
                .unwrap()
        };
        let p = probe(&broken);
        assert!(p.status.success(), "killed file unreadable: {}", String::from_utf8_lossy(&p.stderr));
        assert!(String::from_utf8_lossy(&p.stdout).contains("h264"));

        let fixed = dir.0.join("fixed.mp4");
        let o = Command::new(&ffmpeg).args(remux_args(&broken, &fixed)).output().unwrap();
        assert!(o.status.success(), "{}", String::from_utf8_lossy(&o.stderr));
        let dur = Command::new(&ffprobe)
            .args(["-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1"])
            .arg(&fixed)
            .output()
            .unwrap();
        let secs: f64 = String::from_utf8_lossy(&dur.stdout).trim().parse().unwrap_or(0.0);
        assert!(secs > 1.5, "salvaged only {secs} s of a 3.5 s take");
    }

    #[test]
    fn real_ffmpeg_a_normal_faststart_file_is_lost_when_killed_which_is_why_we_fragment() {
        let (Some(ffmpeg), Some(ffprobe)) = (bin("ffmpeg"), bin("ffprobe")) else {
            return;
        };
        let dir = Dir::new();
        let broken = dir.0.join("old.mp4");
        let mut child = Command::new(&ffmpeg)
            .args(["-v", "error", "-y", "-re", "-f", "lavfi", "-i", "testsrc2=s=640x360:r=30:d=60"])
            .args(["-c:v", "libx264", "-pix_fmt", "yuv420p", "-movflags", "+faststart"])
            .arg(&broken)
            .stdin(Stdio::null())
            .spawn()
            .unwrap();
        std::thread::sleep(std::time::Duration::from_millis(2500));
        child.kill().unwrap();
        child.wait().unwrap();
        let p = Command::new(&ffprobe).args(["-v", "error"]).arg(&broken).output().unwrap();
        // The failure the user saw: moov atom not found.
        assert!(!p.status.success() || String::from_utf8_lossy(&p.stderr).contains("moov"));
    }
}
