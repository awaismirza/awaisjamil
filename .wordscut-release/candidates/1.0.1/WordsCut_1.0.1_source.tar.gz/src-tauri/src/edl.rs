//! Rust mirror of the EDL types. Serialised identically to the TypeScript side
//! so projects round-trip without loss.

use serde::{Deserialize, Serialize};
use std::collections::HashMap;

pub type MediaId = String;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SourceMedia {
    pub id: MediaId,
    pub path: String,
    pub duration: f64,
    pub fps: f64,
    pub width: u32,
    pub height: u32,
    #[serde(rename = "audioSampleRate")]
    pub audio_sample_rate: u32,
    /// Lower-case hex SHA-256 of the file, or "" while none is recorded (saved
    /// before hashing, or a recording whose checksum is still being computed).
    #[serde(default)]
    pub sha256: String,
    /// A screen + camera recording whose camera composite has not replaced
    /// this file yet (4.49.1). Saved with the project so the composite resumes
    /// on open; cleared when it is swapped in or given up. Older builds ignore
    /// the key.
    #[serde(
        rename = "pendingCamera",
        default,
        deserialize_with = "lenient_pending_camera",
        skip_serializing_if = "Option::is_none"
    )]
    pub pending_camera: Option<PendingCamera>,
}

/// A malformed marker is dropped instead of failing the project load.
fn lenient_pending_camera<'de, D: serde::Deserializer<'de>>(d: D) -> Result<Option<PendingCamera>, D::Error> {
    let raw = Option::<serde_json::Value>::deserialize(d)?;
    Ok(raw.and_then(|v| serde_json::from_value(v).ok()))
}

/// See [`SourceMedia::pending_camera`]. Values are kept as written (strings);
/// the editor validates them before it asks for a composite.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct PendingCamera {
    #[serde(rename = "tracksDir")]
    pub tracks_dir: String,
    #[serde(rename = "pipCorner", default, skip_serializing_if = "Option::is_none")]
    pub pip_corner: Option<String>,
    #[serde(rename = "pipSize", default, skip_serializing_if = "Option::is_none")]
    pub pip_size: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Word {
    pub id: String,
    pub text: String,
    pub start: f64,
    pub end: f64,
    pub confidence: f64,
    #[serde(skip_serializing_if = "Option::is_none", default)]
    pub speaker: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Segment {
    pub id: String,
    #[serde(rename = "mediaId")]
    pub media_id: MediaId,
    pub words: Vec<Word>,
    #[serde(rename = "sourceIn")]
    pub source_in: f64,
    #[serde(rename = "sourceOut")]
    pub source_out: f64,
    /// Speed, hold, mute and transition. All optional; absent fields round-trip as absent.
    #[serde(flatten)]
    pub timing: SegmentTiming,
}

/// Per-clip timing, mirroring the optional fields of the TypeScript `Segment`.
///
/// Deserialised leniently (see the `Deserialize` impl): a malformed or
/// unknown value falls back to its default instead of failing the whole
/// project load, and keys this build does not know are kept in `extra` so a
/// save never drops what a newer build wrote.
#[derive(Debug, Clone, Default, Serialize, PartialEq)]
pub struct SegmentTiming {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub speed: Option<f64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub muted: Option<bool>,
    #[serde(default, rename = "holdSec", skip_serializing_if = "Option::is_none")]
    pub hold_sec: Option<f64>,
    #[serde(default, rename = "transitionIn", skip_serializing_if = "Option::is_none")]
    pub transition_in: Option<Transition>,
    /// Segment keys this build does not recognise, written back verbatim.
    #[serde(flatten)]
    pub extra: serde_json::Map<String, serde_json::Value>,
}

impl<'de> Deserialize<'de> for SegmentTiming {
    fn deserialize<D: serde::Deserializer<'de>>(d: D) -> Result<Self, D::Error> {
        let mut m = serde_json::Map::<String, serde_json::Value>::deserialize(d)?;
        let num = |v: Option<serde_json::Value>| v.and_then(|v| v.as_f64());
        Ok(Self {
            speed: num(m.remove("speed")),
            muted: m.remove("muted").and_then(|v| v.as_bool()),
            hold_sec: num(m.remove("holdSec")),
            transition_in: m.remove("transitionIn").and_then(|v| serde_json::from_value(v).ok()),
            extra: m,
        })
    }
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "lowercase")]
pub enum TransitionKind {
    Crossfade,
    Dip,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq)]
pub struct Transition {
    pub kind: TransitionKind,
    pub duration: f64,
}

// Limits shared with src/lib/edl.ts.
pub const MIN_SPEED: f64 = 0.25;
pub const MAX_SPEED: f64 = 4.0;
/// Model limit; inserted voice-over narration is a hold, so this is far above
/// the Timing panel's own 30 s (`HOLD_UI_MAX_SEC` in edl.ts).
pub const MAX_HOLD_SEC: f64 = 3600.0;
pub const MIN_TRANSITION_SEC: f64 = 0.1;
pub const MAX_TRANSITION_SEC: f64 = 2.0;

impl Segment {
    /// Effective speed, always finite and inside MIN_SPEED..=MAX_SPEED (`segmentSpeed`).
    pub fn speed(&self) -> f64 {
        match self.timing.speed {
            Some(s) if s.is_finite() && s > 0.0 => s.clamp(MIN_SPEED, MAX_SPEED),
            _ => 1.0,
        }
    }
    /// Effective freeze-frame hold in output seconds (`segmentHold`).
    pub fn hold(&self) -> f64 {
        match self.timing.hold_sec {
            Some(h) if h.is_finite() && h > 0.0 => h.min(MAX_HOLD_SEC),
            _ => 0.0,
        }
    }
    pub fn muted(&self) -> bool {
        self.timing.muted == Some(true)
    }
    /// Output seconds of footage, before any hold (`segmentPlayLength`).
    pub fn play_len(&self) -> f64 {
        (self.source_out - self.source_in).max(0.0) / self.speed()
    }
    /// Output seconds this clip occupies (`segmentOutputLength`).
    pub fn output_len(&self) -> f64 {
        let play = self.play_len();
        if play > 0.0 { play + self.hold() } else { 0.0 }
    }
    /// Source time shown `local` output seconds into this clip (`entrySourceAt`).
    pub fn source_at(&self, local: f64) -> f64 {
        (self.source_in + local.max(0.0) * self.speed()).min(self.source_out)
    }
    /// True when the clip can never be stream-copied (`hasTimingEffects`).
    pub fn has_timing_effects(&self) -> bool {
        self.speed() != 1.0 || self.hold() > 0.0 || self.muted() || self.timing.transition_in.is_some()
    }
}

/// Half the effective duration of the transition into `segments[i]` (`transitionHalf`).
pub fn transition_half(segments: &[Segment], i: usize) -> f64 {
    let (Some(seg), Some(prev)) = (segments.get(i), i.checked_sub(1).and_then(|p| segments.get(p))) else {
        return 0.0;
    };
    let Some(t) = seg.timing.transition_in else { return 0.0 };
    if !t.duration.is_finite() {
        return 0.0;
    }
    let d = t.duration.clamp(MIN_TRANSITION_SEC, MAX_TRANSITION_SEC);
    (d / 2.0).min(prev.output_len() / 2.0).min(seg.output_len() / 2.0).max(0.0)
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "kebab-case")]
pub enum ExportPreset {
    #[serde(rename = "youtube-1080p")]
    Youtube1080p,
    #[serde(rename = "podcast-audio")]
    PodcastAudio,
    Custom,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProjectSettings {
    #[serde(rename = "exportPreset")]
    pub export_preset: ExportPreset,
    #[serde(rename = "paddingMs")]
    pub padding_ms: u32,
}

/// A named jump-point on the OUTPUT timeline. Used during export to write
/// ffmetadata `[CHAPTER]` blocks (YouTube / Apple-Podcasts compatible).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Chapter {
    pub id: String,
    #[serde(rename = "outputTime")]
    pub output_time: f64,
    pub title: String,
}

/// A music bed / sfx track laid under the main spoken EDL. Mixed in only at
/// export — never mutates the source media. The mediaId must reference an
/// entry in `Project::media`.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct AudioTrack {
    pub id: String,
    #[serde(rename = "mediaId")]
    pub media_id: MediaId,
    /// Volume adjustment in dB. 0 = unity.
    #[serde(rename = "gainDb")]
    pub gain_db: f64,
    /// When on the output timeline the track begins, in seconds.
    #[serde(rename = "offsetSec")]
    pub offset_sec: f64,
    /// If true, sidechain-compress the track under the main voice.
    pub ducks: bool,
    /// Silence this track in the mix (export and preview). Distinct from hiding a timeline lane.
    #[serde(default, skip_serializing_if = "std::ops::Not::not")]
    pub muted: bool,
    /// If any track is soloed, only soloed tracks are heard; solo wins over mute.
    #[serde(default, skip_serializing_if = "std::ops::Not::not")]
    pub solo: bool,
    /// Linear fade-in from the start of the track, seconds. 0 = none.
    #[serde(default, rename = "fadeInSec", skip_serializing_if = "is_zero")]
    pub fade_in_sec: f64,
    /// Linear fade-out ending where the track ends on the timeline, seconds. 0 = none.
    #[serde(default, rename = "fadeOutSec", skip_serializing_if = "is_zero")]
    pub fade_out_sec: f64,
    /// Voice-over fields; all absent on music beds.
    #[serde(flatten)]
    pub voice: VoiceOverFields,
}

/// The optional voice-over fields of the TypeScript `AudioTrack` (`kind`,
/// `sourceIn`, `sourceOut`, `mode`, `overrideOriginal`, `insertSec`).
///
/// Lenient like `SegmentTiming`: a malformed value falls back to absent instead
/// of failing the project load, and unknown keys (the take's `words`, fields of
/// newer builds) are kept in `extra` and written back verbatim.
#[derive(Debug, Clone, Default, Serialize, PartialEq)]
pub struct VoiceOverFields {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub kind: Option<String>,
    #[serde(default, rename = "sourceIn", skip_serializing_if = "Option::is_none")]
    pub source_in: Option<f64>,
    #[serde(default, rename = "sourceOut", skip_serializing_if = "Option::is_none")]
    pub source_out: Option<f64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub mode: Option<String>,
    #[serde(default, rename = "overrideOriginal", skip_serializing_if = "Option::is_none")]
    pub override_original: Option<bool>,
    #[serde(default, rename = "insertSec", skip_serializing_if = "Option::is_none")]
    pub insert_sec: Option<f64>,
    #[serde(flatten)]
    pub extra: serde_json::Map<String, serde_json::Value>,
}

impl<'de> Deserialize<'de> for VoiceOverFields {
    fn deserialize<D: serde::Deserializer<'de>>(d: D) -> Result<Self, D::Error> {
        let mut m = serde_json::Map::<String, serde_json::Value>::deserialize(d)?;
        let num = |v: Option<serde_json::Value>| v.and_then(|v| v.as_f64()).filter(|v| v.is_finite());
        let text = |v: Option<serde_json::Value>| v.and_then(|v| v.as_str().map(str::to_owned));
        Ok(Self {
            kind: text(m.remove("kind")),
            source_in: num(m.remove("sourceIn")),
            source_out: num(m.remove("sourceOut")),
            mode: text(m.remove("mode")),
            override_original: m.remove("overrideOriginal").and_then(|v| v.as_bool()),
            insert_sec: num(m.remove("insertSec")),
            extra: m,
        })
    }
}

/// Ramp length of the override envelope, outside the interval (`OVERRIDE_FADE_SEC`).
pub const OVERRIDE_FADE_SEC: f64 = 0.05;

impl AudioTrack {
    pub fn is_voice_over(&self) -> bool {
        self.voice.kind.as_deref() == Some("voiceover")
    }
    /// (trim-in, seconds that play) inside the media (`voiceOverLength`). Music
    /// beds play their whole file from 0.
    pub fn media_range(&self, media_duration: f64) -> (f64, f64) {
        let dur = if media_duration > 0.0 { media_duration } else { f64::INFINITY };
        if !self.is_voice_over() {
            return (0.0, dur);
        }
        let sin = self.voice.source_in.unwrap_or(0.0).max(0.0);
        let sout = self.voice.source_out.unwrap_or(dur).min(dur);
        (sin, (sout - sin).max(0.0))
    }
    /// (start, len) on the output timeline (`trackSpan`).
    pub fn span(&self, media_duration: f64, total: f64) -> (f64, f64) {
        let start = if self.offset_sec.is_finite() { self.offset_sec.max(0.0) } else { 0.0 };
        let (_, len) = self.media_range(media_duration);
        (start, len.min(total - start).max(0.0))
    }
}

/// Gain expression (ffmpeg `volume` with `eval=frame`, `t` = output seconds)
/// that is 0 inside every interval and ramps back to 1 over `OVERRIDE_FADE_SEC`
/// outside it (`envelopeGain`). None when there is nothing to suppress.
pub fn envelope_expr(intervals: &[(f64, f64)]) -> Option<String> {
    if intervals.is_empty() {
        return None;
    }
    let f = OVERRIDE_FADE_SEC;
    Some(
        intervals
            .iter()
            .map(|(a, b)| format!("clip(max(({a:.6}-t)/{f},(t-{b:.6})/{f}),0,1)"))
            .collect::<Vec<_>>()
            .join("*"),
    )
}

fn is_zero(v: &f64) -> bool {
    *v == 0.0
}

impl Project {
    /// The tracks that are heard: if any is soloed only soloed ones (solo wins
    /// over mute), otherwise every track that is not muted. Mirrors `audibleTracks`
    /// in `src/lib/audioMix.ts`.
    pub fn audible_tracks(&self) -> Vec<&AudioTrack> {
        let any_solo = self.audio_tracks.iter().any(|t| t.solo);
        self.audio_tracks.iter().filter(|t| if any_solo { t.solo } else { !t.muted }).collect()
    }

    /// Replacement intervals of heard override takes, in track order (later =
    /// newer), clipped to the edit. Mirrors `replacementIntervals` in audioMix.ts.
    pub fn replacement_intervals(&self, total: f64) -> Vec<(String, f64, f64)> {
        self.audible_tracks()
            .into_iter()
            .filter(|t| t.is_voice_over() && t.voice.override_original == Some(true))
            .filter_map(|t| {
                let dur = self.media.get(&t.media_id).map_or(0.0, |m| m.duration);
                let (start, len) = t.span(dur, total);
                (len > 0.0).then(|| (t.id.clone(), start, start + len))
            })
            .collect()
    }

    /// Intervals that silence track `id`: override takes added after it (latest
    /// wins). Empty for music beds and for the newest take (`suppressorsOf`).
    pub fn suppressors_of(&self, id: &str, total: f64) -> Vec<(f64, f64)> {
        let Some(i) = self.audio_tracks.iter().position(|t| t.id == id) else { return vec![] };
        if !self.audio_tracks[i].is_voice_over() {
            return vec![];
        }
        let later: Vec<&str> = self.audio_tracks[i + 1..].iter().map(|t| t.id.as_str()).collect();
        self.replacement_intervals(total)
            .into_iter()
            .filter(|(tid, _, _)| later.contains(&tid.as_str()))
            .map(|(_, a, b)| (a, b))
            .collect()
    }
}

/// Fade lengths clamped to the clip: each within `0..=len`, scaled down together
/// when they would overlap. Mirrors `resolveFades` in `src/lib/audioMix.ts`.
pub fn resolve_fades(fade_in: f64, fade_out: f64, len: f64) -> (f64, f64) {
    let clean = |v: f64| if v.is_finite() { v.clamp(0.0, len.max(0.0)) } else { 0.0 };
    let (fi, fo) = (clean(fade_in), clean(fade_out));
    if fi + fo > len && fi + fo > 0.0 {
        let k = len.max(0.0) / (fi + fo);
        (fi * k, fo * k)
    } else {
        (fi, fo)
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Project {
    pub version: u32,
    pub id: String,
    pub name: String,
    #[serde(rename = "createdAt")]
    pub created_at: String,
    #[serde(rename = "updatedAt")]
    pub updated_at: String,
    pub media: HashMap<MediaId, SourceMedia>,
    pub segments: Vec<Segment>,
    pub settings: ProjectSettings,
    /// Complete source transcription snapshots; absent on legacy projects.
    #[serde(default, rename = "originalTranscripts", skip_serializing_if = "Option::is_none")]
    pub original_transcripts: Option<HashMap<MediaId, Vec<Word>>>,
    /// Optional — older v2.0 projects deserialise with `chapters = Vec::new()`.
    #[serde(default)]
    pub chapters: Vec<Chapter>,
    /// Optional — older projects deserialise with `audio_tracks = Vec::new()`.
    #[serde(default, rename = "audioTracks")]
    pub audio_tracks: Vec<AudioTrack>,
    /// The frame around the video (background, padding, corners, shadow).
    /// Kept as raw JSON: the frontend owns and validates its shape, and the
    /// exporter receives it already resolved. Stored here so saving and
    /// loading a project never drops it.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub scene: Option<serde_json::Value>,
    /// Spans of the output timeline where the picture is zoomed in. Raw JSON for
    /// the same reason as `scene`; the exporter receives them validated.
    #[serde(default, rename = "zoomRegions", skip_serializing_if = "Option::is_none")]
    pub zoom_regions: Option<serde_json::Value>,
    /// Source-time cursor tracks and styling, validated by the frontend.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub cursor: Option<serde_json::Value>,
    /// Caption look (`CaptionStyle` in captionStyle.ts), raw JSON validated on use.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub captions: Option<serde_json::Value>,
    /// Text, arrows and boxes on the output timeline. Raw JSON like `scene`;
    /// `annotations_export::sanitize` validates it before drawing.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub annotations: Option<serde_json::Value>,
    /// Keystroke overlay preferences (opt-in), validated by `annotations_export`.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub keystrokes: Option<serde_json::Value>,
    /// Image / video overlays on the output timeline. Raw JSON like `annotations`;
    /// `layers_export::sanitize_overlays` validates it before export.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub overlays: Option<serde_json::Value>,
    /// Privacy masks (source-picture coordinates). Raw JSON; `layers_export::sanitize_masks`.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub masks: Option<serde_json::Value>,
}

impl Project {
    /// Length of the output timeline: every clip at its speed plus its hold
    /// (`totalDuration`). Transitions are overlap-neutral and never change it.
    pub fn output_duration(&self) -> f64 {
        self.segments.iter().map(Segment::output_len).sum()
    }
    pub fn has_timing_effects(&self) -> bool {
        self.segments.iter().any(Segment::has_timing_effects)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn timing_fields_are_optional_and_round_trip_exactly() {
        let old = serde_json::json!({"id":"s","mediaId":"m","words":[],"sourceIn":0.0,"sourceOut":4.0});
        let seg: Segment = serde_json::from_value(old.clone()).unwrap();
        assert_eq!(seg.timing, SegmentTiming::default());
        assert_eq!(serde_json::to_value(&seg).unwrap(), old, "old segments save unchanged");
        let new = serde_json::json!({"id":"s","mediaId":"m","words":[],"sourceIn":0.0,"sourceOut":4.0,
            "speed":2.0,"muted":true,"holdSec":1.5,"transitionIn":{"kind":"crossfade","duration":0.5}});
        let seg: Segment = serde_json::from_value(new.clone()).unwrap();
        assert_eq!(serde_json::to_value(&seg).unwrap(), new);
        assert_eq!(seg.output_len(), 3.5);
        assert_eq!(seg.source_at(1.0), 2.0);
        assert_eq!(seg.source_at(3.0), 4.0, "the hold shows the last frame");
    }

    #[test]
    fn shared_timing_fixture_matches_the_typescript_mapping_and_round_trips() {
        let fixture: serde_json::Value =
            serde_json::from_str(include_str!("../../tests/fixtures/timingProject.json")).unwrap();
        let project: Project = serde_json::from_value(fixture["project"].clone()).unwrap();
        let want = &fixture["expected"];
        assert_eq!(project.output_duration(), want["outputDuration"].as_f64().unwrap());
        let mut end = 0.0;
        for (i, seg) in project.segments.iter().enumerate() {
            end += seg.output_len();
            assert_eq!(end, want["outputEnds"][i].as_f64().unwrap(), "end of clip {i}");
            assert_eq!(transition_half(&project.segments, i), want["transitionHalves"][i].as_f64().unwrap());
        }
        // Saving never adds, drops or reorders a timing field (camelCase, absent stays absent).
        let saved = serde_json::to_value(&project).unwrap();
        for (i, seg) in fixture["project"]["segments"].as_array().unwrap().iter().enumerate() {
            assert_eq!(&saved["segments"][i], seg);
        }
    }

    #[test]
    fn hostile_timing_values_fall_back_to_defaults_and_unknown_keys_survive() {
        let fixture: serde_json::Value =
            serde_json::from_str(include_str!("../../tests/fixtures/hostileTiming.json")).unwrap();
        let raw = fixture["raw"].as_array().unwrap();
        let want = fixture["sanitized"].as_array().unwrap();
        for (r, w) in raw.iter().zip(want) {
            let seg: Segment = serde_json::from_value(r.clone()).expect("never fails the load");
            assert_eq!(&serde_json::to_value(&seg).unwrap(), w);
        }
        let segs: Vec<Segment> = serde_json::from_value(fixture["raw"].clone()).unwrap();
        let total: f64 = segs.iter().map(Segment::output_len).sum();
        assert_eq!(total, fixture["outputDuration"].as_f64().unwrap());
    }

    #[test]
    fn timing_values_are_clamped_like_the_frontend() {
        let mut seg: Segment = serde_json::from_value(serde_json::json!(
            {"id":"s","mediaId":"m","words":[],"sourceIn":0.0,"sourceOut":8.0,"speed":100.0,"holdSec":-1.0})).unwrap();
        assert_eq!(seg.speed(), MAX_SPEED);
        assert_eq!(seg.hold(), 0.0);
        seg.timing.speed = Some(f64::NAN);
        assert_eq!(seg.speed(), 1.0);
        let a = seg.clone();
        let mut b = seg.clone();
        b.timing.transition_in = Some(Transition { kind: TransitionKind::Dip, duration: 10.0 });
        assert_eq!(transition_half(&[a.clone(), b.clone()], 1), MAX_TRANSITION_SEC / 2.0);
        assert_eq!(transition_half(&[b], 0), 0.0, "never on the first clip");
        let mut short = a;
        short.source_out = 0.4;
        let mut c = seg;
        c.timing.transition_in = Some(Transition { kind: TransitionKind::Crossfade, duration: 2.0 });
        assert!((transition_half(&[short, c], 1) - 0.2).abs() < 1e-12, "half of the shorter clip");
    }

    #[test]
    fn original_transcripts_are_optional_and_survive_roundtrip() {
        let mut value = serde_json::json!({
            "version":1,"id":"p","name":"n","createdAt":"x","updatedAt":"x",
            "media":{},"segments":[],"settings":{"exportPreset":"youtube-1080p","paddingMs":80}
        });
        let old: Project = serde_json::from_value(value.clone()).unwrap();
        assert!(old.original_transcripts.is_none());
        value["originalTranscripts"] = serde_json::json!({"m":[{"id":"w","text":"deleted","start":0.0,"end":1.0,"confidence":1.0}]});
        let project: Project = serde_json::from_value(value.clone()).unwrap();
        let saved = serde_json::to_value(project).unwrap();
        assert_eq!(saved["originalTranscripts"], value["originalTranscripts"]);
    }

    #[test]
    fn round_trip_empty_project() {
        let p = Project {
            version: 1,
            id: "abc".into(),
            name: "Test".into(),
            created_at: "2025-01-01T00:00:00Z".into(),
            updated_at: "2025-01-01T00:00:00Z".into(),
            media: HashMap::new(),
            segments: vec![],
            settings: ProjectSettings {
                export_preset: ExportPreset::Youtube1080p,
                padding_ms: 80,
            },
            chapters: vec![],
            audio_tracks: vec![],
            scene: None,
            zoom_regions: None,
            cursor: None,
            captions: None,
            annotations: None,
            keystrokes: None, overlays: None, masks: None,
            original_transcripts: None,
        };
        let json = serde_json::to_string(&p).unwrap();
        let back: Project = serde_json::from_str(&json).unwrap();
        assert_eq!(p.id, back.id);
        assert_eq!(p.settings.padding_ms, back.settings.padding_ms);
    }

    #[test]
    fn deserialise_typescript_shape() {
        // This exercises that camelCase field names match the frontend.
        let json = r#"{
            "version": 1,
            "id": "p",
            "name": "n",
            "createdAt": "2025-01-01T00:00:00Z",
            "updatedAt": "2025-01-01T00:00:00Z",
            "media": {},
            "segments": [
              {
                "id": "s",
                "mediaId": "m",
                "words": [
                  {"id":"w","text":"hi","start":0,"end":0.5,"confidence":0.9}
                ],
                "sourceIn": 0,
                "sourceOut": 5
              }
            ],
            "settings": { "exportPreset": "youtube-1080p", "paddingMs": 80 }
        }"#;
        let p: Project = serde_json::from_str(json).unwrap();
        assert_eq!(p.segments.len(), 1);
        assert_eq!(p.segments[0].words[0].text, "hi");
        assert_eq!(p.settings.export_preset, ExportPreset::Youtube1080p);
    }

    #[test]
    fn scene_survives_a_round_trip_untouched() {
        let json = r##"{
            "version": 1, "id": "p", "name": "n",
            "createdAt": "x", "updatedAt": "x",
            "media": {}, "segments": [],
            "settings": { "exportPreset": "youtube-1080p", "paddingMs": 80 },
            "scene": { "enabled": true, "aspect": "9:16", "paddingPct": 12,
                       "background": { "kind": "solid", "color": "#123456" } }
        }"##;
        let p: Project = serde_json::from_str(json).unwrap();
        let back: serde_json::Value = serde_json::to_value(&p).unwrap();
        assert_eq!(back["scene"]["aspect"], "9:16");
        assert_eq!(back["scene"]["background"]["color"], "#123456");
    }

    #[test]
    fn a_device_frame_in_the_scene_survives_even_when_hostile_or_unknown() {
        let json = r##"{
            "version": 1, "id": "p", "name": "n",
            "createdAt": "x", "updatedAt": "x",
            "media": {}, "segments": [],
            "settings": { "exportPreset": "youtube-1080p", "paddingMs": 80 },
            "scene": { "enabled": true,
                       "frame": { "kind": "browser", "theme": "dark", "title": "a {\\N} \u0000", "future": [1, null, {"x": 1}] } }
        }"##;
        let p: Project = serde_json::from_str(json).unwrap();
        let back: serde_json::Value = serde_json::to_value(&p).unwrap();
        assert_eq!(back["scene"]["frame"]["kind"], "browser");
        assert_eq!(back["scene"]["frame"]["theme"], "dark");
        assert!(back["scene"]["frame"]["future"].is_array());
    }

    #[test]
    fn a_project_without_a_scene_still_loads_and_saves_without_one() {
        let json = r#"{
            "version": 1, "id": "p", "name": "n",
            "createdAt": "x", "updatedAt": "x",
            "media": {}, "segments": [],
            "settings": { "exportPreset": "youtube-1080p", "paddingMs": 80 }
        }"#;
        let p: Project = serde_json::from_str(json).unwrap();
        assert!(p.scene.is_none());
        let back: serde_json::Value = serde_json::to_value(&p).unwrap();
        assert!(back.get("scene").is_none());
    }
    #[test]
    fn cursor_and_follow_keys_survive_project_serialisation() {
        let mut value = serde_json::json!({
            "version":1,"id":"p","name":"n","createdAt":"x","updatedAt":"x",
            "media":{},"segments":[],"settings":{"exportPreset":"youtube-1080p","paddingMs":80},
            "cursor":{"style":{"shape":"ring"},"tracks":{"m":{"events":[{"type":"key","t":1}]}}},
            "zoomRegions":[{"start":0,"end":2,"follow":true,"focusKeys":[{"t":1,"x":0.2,"y":0.3}]}]
        });
        let project: Project = serde_json::from_value(value.clone()).unwrap();
        let saved = serde_json::to_value(project).unwrap();
        assert_eq!(saved["cursor"], value["cursor"]);
        assert_eq!(saved["zoomRegions"], value["zoomRegions"]);
        value.as_object_mut().unwrap().remove("cursor");
        let old: Project = serde_json::from_value(value).unwrap();
        assert!(old.cursor.is_none());
    }

    fn track(id: &str) -> AudioTrack {
        AudioTrack { id: id.into(), media_id: "m".into(), ..Default::default() }
    }

    /// The JSON a TypeScript voice-over take serialises to (see tests/voiceover.test.ts).
    fn take_json() -> serde_json::Value {
        serde_json::json!({
            "id":"vo","mediaId":"take","gainDb":0.0,"offsetSec":2.0,"ducks":false,
            "kind":"voiceover","sourceIn":0.25,"sourceOut":3.0,"mode":"insert",
            "overrideOriginal":true,"insertSec":2.75,
            "words":[{"id":"w1","text":"hi","start":0.3,"end":0.6,"confidence":0.9}],
            "futureKey":{"a":1}
        })
    }

    #[test]
    fn voice_over_takes_round_trip_exactly_and_keep_unknown_keys() {
        let t: AudioTrack = serde_json::from_value(take_json()).unwrap();
        assert!(t.is_voice_over());
        assert_eq!(t.voice.source_in, Some(0.25));
        assert_eq!(t.voice.mode.as_deref(), Some("insert"));
        assert_eq!(t.voice.override_original, Some(true));
        assert_eq!(t.voice.insert_sec, Some(2.75));
        assert_eq!(serde_json::to_value(&t).unwrap(), take_json());
        assert_eq!(t.media_range(10.0), (0.25, 2.75));
        assert_eq!(t.span(10.0, 4.0), (2.0, 2.0), "clipped to the edit");
    }

    /// Every JSON number as f64, so `1` and `1.0` compare equal.
    fn norm(v: serde_json::Value) -> serde_json::Value {
        use serde_json::Value;
        match v {
            Value::Number(n) => serde_json::json!(n.as_f64().unwrap()),
            Value::Array(a) => Value::Array(a.into_iter().map(norm).collect()),
            Value::Object(o) => Value::Object(o.into_iter().map(|(k, v)| (k, norm(v))).collect()),
            other => other,
        }
    }

    /// `tests/fixtures/voiceoverProject.json` is what `addVoiceOverTake` writes
    /// (asserted in tests/voiceover.test.ts); Rust must keep every key.
    #[test]
    fn the_typescript_voice_over_fixture_round_trips_with_every_key() {
        let raw: serde_json::Value =
            serde_json::from_str(include_str!("../../tests/fixtures/voiceoverProject.json")).unwrap();
        let p: Project = serde_json::from_value(raw.clone()).unwrap();
        let t = &p.audio_tracks[0];
        assert!(t.is_voice_over());
        assert_eq!(t.voice.insert_sec, Some(2.75));
        assert!(t.voice.extra.contains_key("words"), "the take transcript is kept");
        assert_eq!(p.output_duration(), 12.75, "10 s of video + the 2.75 s hold");
        assert_eq!(p.replacement_intervals(p.output_duration()), vec![("vo".to_string(), 2.0, 4.75)]);
        let back = serde_json::to_value(&p).unwrap();
        assert_eq!(norm(back["audioTracks"].clone()), norm(raw["audioTracks"].clone()));
        assert_eq!(norm(back["segments"].clone()), norm(raw["segments"].clone()));
    }

    #[test]
    fn pending_camera_marker_round_trips_and_is_optional() {
        let base = serde_json::json!({"id":"m","path":"/r/rec-1/screen-camera-1.mp4","duration":4.0,"fps":30.0,
            "width":640,"height":360,"audioSampleRate":48000,"sha256":""});
        let m: SourceMedia = serde_json::from_value(base.clone()).unwrap();
        assert!(m.pending_camera.is_none());
        assert!(serde_json::to_value(&m).unwrap().get("pendingCamera").is_none(), "old shape unchanged");
        let mut with = base.clone();
        with["pendingCamera"] = serde_json::json!({"tracksDir":"/r/rec-1/tracks","pipCorner":"top-left","pipSize":"small"});
        let m: SourceMedia = serde_json::from_value(with.clone()).unwrap();
        assert_eq!(m.pending_camera.as_ref().unwrap().tracks_dir, "/r/rec-1/tracks");
        assert_eq!(serde_json::to_value(&m).unwrap(), with);
        let mut bad = base.clone();
        bad["pendingCamera"] = serde_json::json!(42);
        assert!(serde_json::from_value::<SourceMedia>(bad).unwrap().pending_camera.is_none());
        let mut no_sha = base;
        no_sha.as_object_mut().unwrap().remove("sha256");
        assert_eq!(serde_json::from_value::<SourceMedia>(no_sha).unwrap().sha256, "");
    }

    #[test]
    fn malformed_voice_over_fields_fall_back_instead_of_failing_the_load() {
        let mut v = take_json();
        v["sourceIn"] = "soon".into();
        v["overrideOriginal"] = 3.into();
        v["kind"] = serde_json::Value::Null;
        let t: AudioTrack = serde_json::from_value(v).unwrap();
        assert_eq!((t.voice.source_in, t.voice.override_original, t.voice.kind.clone()), (None, None, None));
        assert!(!t.is_voice_over());
        // A music bed plays its whole file regardless of stray trim keys.
        assert_eq!(t.media_range(5.0), (0.0, 5.0));
    }

    fn vo_project(tracks: Vec<AudioTrack>) -> Project {
        let mut p: Project = serde_json::from_value(serde_json::json!({
            "version":1,"id":"p","name":"p","createdAt":"x","updatedAt":"x","segments":[],
            "media":{"take":{"id":"take","path":"/t.m4a","duration":2.0,"fps":0,"width":0,"height":0,"audioSampleRate":48000,"sha256":""}},
            "settings":{"exportPreset":"youtube-1080p","paddingMs":80}
        })).unwrap();
        p.audio_tracks = tracks;
        p
    }

    fn take(id: &str, at: f64, over: bool) -> AudioTrack {
        let mut t: AudioTrack = serde_json::from_value(serde_json::json!({
            "id":id,"mediaId":"take","gainDb":0.0,"offsetSec":at,"ducks":false,"kind":"voiceover","mode":"overlay"
        })).unwrap();
        if over {
            t.voice.override_original = Some(true);
        }
        t
    }

    #[test]
    fn replacement_intervals_and_latest_wins_match_the_typescript_rules() {
        let mut p = vo_project(vec![take("a", 1.0, true), take("b", 2.0, true), take("c", 9.0, false), track("bed")]);
        let iv = p.replacement_intervals(10.0);
        assert_eq!(iv, vec![("a".into(), 1.0, 3.0), ("b".into(), 2.0, 4.0)]);
        // The older take is silenced by the newer one; the newest never by itself.
        assert_eq!(p.suppressors_of("a", 10.0), vec![(2.0, 4.0)]);
        assert!(p.suppressors_of("b", 10.0).is_empty());
        assert!(p.suppressors_of("bed", 10.0).is_empty(), "music beds are separate sources");
        // Muting a replacement restores what it replaced.
        p.audio_tracks[1].muted = true;
        assert!(p.suppressors_of("a", 10.0).is_empty());
        assert_eq!(p.replacement_intervals(10.0).len(), 1);
    }

    #[test]
    fn envelope_expression_is_zero_inside_and_ramps_outside() {
        assert_eq!(envelope_expr(&[]), None);
        let e = envelope_expr(&[(1.0, 2.0), (3.0, 4.0)]).unwrap();
        assert_eq!(
            e,
            "clip(max((1.000000-t)/0.05,(t-2.000000)/0.05),0,1)*clip(max((3.000000-t)/0.05,(t-4.000000)/0.05),0,1)"
        );
    }

    #[test]
    fn old_audio_tracks_load_unchanged_and_save_without_the_new_keys() {
        let old: AudioTrack = serde_json::from_value(
            serde_json::json!({"id":"t","mediaId":"m","gainDb":-6.0,"offsetSec":1.5,"ducks":true}),
        )
        .unwrap();
        assert!(!old.muted && !old.solo && old.fade_in_sec == 0.0 && old.fade_out_sec == 0.0);
        let saved = serde_json::to_value(&old).unwrap();
        assert_eq!(saved, serde_json::json!({"id":"t","mediaId":"m","gainDb":-6.0,"offsetSec":1.5,"ducks":true}));
    }

    #[test]
    fn mixer_fields_round_trip_with_camel_case_keys() {
        let t = AudioTrack { muted: true, solo: true, fade_in_sec: 1.5, fade_out_sec: 2.0, ..track("t") };
        let v = serde_json::to_value(&t).unwrap();
        assert_eq!((v["muted"].clone(), v["solo"].clone(), v["fadeInSec"].clone(), v["fadeOutSec"].clone()),
            (true.into(), true.into(), 1.5.into(), 2.0.into()));
        let back: AudioTrack = serde_json::from_value(v).unwrap();
        assert!(back.muted && back.solo && back.fade_in_sec == 1.5 && back.fade_out_sec == 2.0);
    }

    #[test]
    fn audible_tracks_follow_mute_and_solo_and_solo_wins() {
        let mut p: Project = serde_json::from_value(serde_json::json!({
            "version":1,"id":"p","name":"p","createdAt":"x","updatedAt":"x","media":{},"segments":[],
            "settings":{"exportPreset":"youtube-1080p","paddingMs":80},"chapters":[]
        })).unwrap();
        p.audio_tracks = vec![track("a"), track("b"), track("c")];
        let ids = |p: &Project| p.audible_tracks().iter().map(|t| t.id.clone()).collect::<Vec<_>>();
        assert_eq!(ids(&p), ["a", "b", "c"]);
        p.audio_tracks[1].muted = true;
        assert_eq!(ids(&p), ["a", "c"]);
        p.audio_tracks[1].solo = true; // muted AND soloed: solo wins, and only it plays
        assert_eq!(ids(&p), ["b"]);
        p.audio_tracks[2].solo = true;
        assert_eq!(ids(&p), ["b", "c"]);
    }

    #[test]
    fn fades_are_clamped_to_the_clip_and_scaled_when_they_overlap() {
        assert_eq!(resolve_fades(1.0, 2.0, 10.0), (1.0, 2.0));
        assert_eq!(resolve_fades(-1.0, f64::NAN, 10.0), (0.0, 0.0));
        assert_eq!(resolve_fades(20.0, 0.0, 10.0), (10.0, 0.0));
        let (i, o) = resolve_fades(6.0, 6.0, 9.0);
        assert!((i - 4.5).abs() < 1e-9 && (o - 4.5).abs() < 1e-9);
        assert_eq!(resolve_fades(2.0, 2.0, 0.0), (0.0, 0.0));
    }
    #[test]
    fn annotations_and_keystrokes_are_optional_and_round_trip() {
        let mut value = serde_json::json!({
            "version":1,"id":"p","name":"n","createdAt":"x","updatedAt":"x",
            "media":{},"segments":[],"settings":{"exportPreset":"youtube-1080p","paddingMs":80}
        });
        let old: Project = serde_json::from_value(value.clone()).unwrap();
        let saved = serde_json::to_value(&old).unwrap();
        assert!(saved.get("annotations").is_none() && saved.get("keystrokes").is_none());
        value["annotations"] = serde_json::json!([{"id":"a","kind":"text","start":0,"end":2,"text":"日本 {x}","futureField":1}]);
        value["keystrokes"] = serde_json::json!({"enabled":true,"mode":"shortcuts"});
        let p: Project = serde_json::from_value(value.clone()).unwrap();
        let saved = serde_json::to_value(p).unwrap();
        assert_eq!(saved["annotations"], value["annotations"]);
        assert_eq!(saved["keystrokes"], value["keystrokes"]);
    }

}
