//! Zoom regions for export: magnify the picture over spans of the output
//! timeline, with the same motion the preview shows.
//!
//! `src/lib/zoom.ts` defines the motion (`sampleZoom`): each region eases in
//! with a smoothstep, holds, and eases out, drifting the view centre from the
//! middle toward its focus point. This module writes that as ffmpeg
//! expressions of the frame time `t`:
//!
//!   envelope_i(t) = between(t, S, E) * smooth(min(1, (t-S)/D, (E-t)/D))
//!   zoom(t)       = 1 + sum (scale_i - 1) * envelope_i(t)
//!   centre(t)     = 0.5 + sum (focus_i - 0.5) * envelope_i(t)
//!
//! then scales each frame by zoom(t) (`eval=frame`) and crops a window of the
//! original size around the centre, clamped to stay inside the picture.
//! Regions never overlap, so at most one envelope is non-zero at a time.

use serde::Deserialize;
use std::fmt::Write as _;

pub const ZOOM_MIN_SCALE: f64 = 1.2;
pub const ZOOM_MAX_SCALE: f64 = 4.0;
/// Regions shorter than this are not worth a filter term.
const MIN_REGION_SEC: f64 = 0.05;

#[derive(Debug, Clone, Deserialize, PartialEq)]
pub struct FocusKey { pub t: f64, pub x: f64, pub y: f64 }

#[derive(Debug, Clone, Deserialize, PartialEq)]
#[serde(rename_all = "camelCase")]
pub struct ZoomRegion {
    #[serde(default)]
    pub id: String,
    pub start: f64,
    pub end: f64,
    pub scale: f64,
    #[serde(default = "half")]
    pub focus_x: f64,
    #[serde(default = "half")]
    pub focus_y: f64,
    #[serde(default = "default_ease_ms")]
    pub ease_ms: f64,
    #[serde(default)]
    pub follow: bool,
    #[serde(default)]
    pub focus_keys: Vec<FocusKey>,
}

fn half() -> f64 {
    0.5
}

fn default_ease_ms() -> f64 {
    450.0
}

/// Clamp every field, sort by start and resolve overlaps (an earlier region
/// keeps its span). Anything unusable is dropped, so the filter text is always valid.
pub fn sanitize(regions: &[ZoomRegion]) -> Vec<ZoomRegion> {
    let mut sorted: Vec<ZoomRegion> = regions
        .iter()
        .filter(|r| r.start.is_finite() && r.end.is_finite() && r.scale.is_finite())
        .cloned()
        .collect();
    sorted.sort_by(|a, b| a.start.partial_cmp(&b.start).unwrap_or(std::cmp::Ordering::Equal));

    let mut out: Vec<ZoomRegion> = Vec::new();
    let mut cursor = 0.0_f64;
    for mut r in sorted {
        r.start = r.start.max(cursor).max(0.0);
        if r.end - r.start < MIN_REGION_SEC {
            continue;
        }
        r.scale = r.scale.clamp(ZOOM_MIN_SCALE, ZOOM_MAX_SCALE);
        r.focus_x = if r.focus_x.is_finite() { r.focus_x.clamp(0.0, 1.0) } else { 0.5 };
        r.focus_y = if r.focus_y.is_finite() { r.focus_y.clamp(0.0, 1.0) } else { 0.5 };
        r.ease_ms = if r.ease_ms.is_finite() { r.ease_ms.clamp(0.0, 2000.0) } else { 450.0 };
        r.focus_keys.retain(|k| k.t.is_finite() && k.x.is_finite() && k.y.is_finite());
        r.focus_keys.sort_by(|a,b| a.t.total_cmp(&b.t));
        // Keep the last key at a duplicate time, like TypeScript.
        r.focus_keys.reverse();
        r.focus_keys.dedup_by(|a,b| a.t == b.t);
        r.focus_keys.reverse();
        for k in &mut r.focus_keys { k.x = k.x.clamp(0.0, 1.0); k.y = k.y.clamp(0.0, 1.0); }
        cursor = r.end;
        out.push(r);
    }
    out
}

/// The envelope of one region as an ffmpeg expression of `t`.
fn envelope(r: &ZoomRegion) -> String {
    let (s, e) = (r.start, r.end);
    let ease = (r.ease_ms / 1000.0).min((e - s) / 2.0);
    if ease < 0.001 {
        return format!("between(t,{s:.4},{e:.4})");
    }
    let p = format!("clip(min((t-{s:.4})/{ease:.4},({e:.4}-t)/{ease:.4}),0,1)");
    format!("between(t,{s:.4},{e:.4})*{p}*{p}*(3-2*{p})")
}

/// `base + sum(weight_i * envelope_i)`, skipping terms that contribute nothing.
fn sum_expr(base: f64, regions: &[ZoomRegion], weight: impl Fn(&ZoomRegion) -> f64) -> String {
    let mut expr = format!("{base}");
    for r in regions {
        let w = weight(r);
        if w.abs() < 1e-9 {
            continue;
        }
        let _ = write!(expr, "+({w:.5})*({})", envelope(r));
    }
    expr
}

/// Piecewise linear focus using clamped ramps. Holding endpoints matches focusAt.
fn focus_expr(r: &ZoomRegion, x_axis: bool) -> String {
    let value = |k: &FocusKey| if x_axis { k.x } else { k.y };
    if !r.follow || r.focus_keys.is_empty() {
        return format!("{:.6}", if x_axis { r.focus_x } else { r.focus_y });
    }
    let mut expr = format!("{:.6}", value(&r.focus_keys[0]));
    for pair in r.focus_keys.windows(2) {
        let (a, b) = (&pair[0], &pair[1]);
        let delta = value(b) - value(a);
        if delta.abs() > 1e-9 {
            let _ = write!(expr, "+({delta:.6})*clip((t-{:.6})/{:.6},0,1)", a.t, (b.t-a.t).max(0.000001));
        }
    }
    expr
}

fn centre_expr(regions: &[ZoomRegion], x_axis: bool) -> String {
    let mut expr = "0.5".to_string();
    for r in regions {
        if !r.follow || r.focus_keys.is_empty() {
            let w = (if x_axis { r.focus_x } else { r.focus_y }) - 0.5;
            if w.abs() > 1e-9 { let _ = write!(expr, "+({w:.5})*({})", envelope(r)); }
        } else {
            let focus = focus_expr(r, x_axis);
            let _ = write!(expr, "+(({focus})-0.5)*({})", envelope(r));
        }
    }
    expr
}

/// Filter that zooms `[input]` and outputs `[output]` at the same size `base_w` x `base_h`
/// (the size of the picture before zooming; made even). Returns `None` for no regions.
pub fn build_zoom_filter(
    regions: &[ZoomRegion],
    base_w: u32,
    base_h: u32,
    input: &str,
    output: &str,
) -> Result<Option<String>, String> {
    let regions = sanitize(regions);
    if regions.is_empty() {
        return Ok(None);
    }
    if base_w < 2 || base_h < 2 {
        return Err("zoom needs a picture with a size".into());
    }
    // Even sizes: the encoder needs them, and it keeps the scaled picture >= the crop.
    let (w0, h0) = (base_w & !1, base_h & !1);

    let z = sum_expr(1.0, &regions, |r| r.scale - 1.0);
    let cx = centre_expr(&regions, true);
    let cy = centre_expr(&regions, false);

    // The scaled picture's size, written out from zoom(t). The crop filter must not
    // use `iw`/`ih` for this: it keeps the size it saw on the first frame, so it
    // would never re-centre once `scale` starts changing the frame size.
    let sw = format!("trunc({w0}*({z})/2)*2");
    let sh = format!("trunc({h0}*({z})/2)*2");

    Ok(Some(format!(
        "[{input}]scale=w='{sw}':h='{sh}':eval=frame:flags=bicubic,\
         crop=w={w0}:h={h0}:x='clip(({cx})*({sw})-{w0}/2,0,({sw})-{w0})':y='clip(({cy})*({sh})-{h0}/2,0,({sh})-{h0})'[{output}]"
    )))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn region(start: f64, end: f64, scale: f64) -> ZoomRegion {
        ZoomRegion {
            id: "r".into(),
            start,
            end,
            scale,
            focus_x: 0.5,
            focus_y: 0.5,
            ease_ms: 500.0,
            follow: false,
            focus_keys: vec![],
        }
    }

    #[test]
    fn deserialises_the_frontend_shape() {
        let json = r#"{"id":"a","start":1.5,"end":4,"scale":2,"focusX":0.8,"focusY":0.2,"easeMs":300}"#;
        let r: ZoomRegion = serde_json::from_str(json).unwrap();
        assert_eq!(r.focus_x, 0.8);
        assert_eq!(r.ease_ms, 300.0);
        let minimal: ZoomRegion = serde_json::from_str(r#"{"start":1,"end":3,"scale":2}"#).unwrap();
        assert_eq!(minimal.focus_x, 0.5);
        assert_eq!(minimal.ease_ms, 450.0);
    }

    #[test]
    fn no_regions_means_no_filter() {
        assert_eq!(build_zoom_filter(&[], 1920, 1080, "a", "b").unwrap(), None);
    }

    #[test]
    fn sanitise_clamps_sorts_and_resolves_overlaps() {
        let mut far = region(10.0, 12.0, 9.0);
        far.focus_x = 4.0;
        far.ease_ms = 99999.0;
        let out = sanitize(&[far, region(0.0, 5.0, 2.0), region(3.0, 8.0, 2.0)]);
        assert_eq!(out.len(), 3);
        assert_eq!((out[0].start, out[0].end), (0.0, 5.0));
        assert_eq!((out[1].start, out[1].end), (5.0, 8.0));
        assert_eq!(out[2].scale, ZOOM_MAX_SCALE);
        assert_eq!(out[2].focus_x, 1.0);
        assert_eq!(out[2].ease_ms, 2000.0);
    }

    #[test]
    fn sanitise_drops_tiny_and_non_finite_regions() {
        let out = sanitize(&[region(1.0, 1.01, 2.0), region(f64::NAN, 3.0, 2.0), region(2.0, 5.0, f64::INFINITY)]);
        assert!(out.is_empty());
    }

    #[test]
    fn filter_scales_per_frame_then_crops_to_the_original_size() {
        let f = build_zoom_filter(&[region(2.0, 6.0, 2.0)], 1280, 720, "catv", "outv")
            .unwrap()
            .unwrap();
        assert!(f.starts_with("[catv]scale=w='trunc(1280*("));
        assert!(f.contains(":eval=frame"));
        assert!(f.contains("crop=w=1280:h=720:x='clip(("));
        // The crop never reads iw/ih, which would stay at the first frame's size.
        assert!(!f.contains("*iw") && !f.contains("*ih") && !f.contains("-iw") && !f.contains("-ih"));
        assert!(f.ends_with("[outv]"));
        assert!(f.contains("between(t,2.0000,6.0000)"));
    }

    #[test]
    fn odd_sizes_are_rounded_down_to_even() {
        let f = build_zoom_filter(&[region(1.0, 3.0, 2.0)], 1281, 721, "a", "b").unwrap().unwrap();
        assert!(f.contains("crop=w=1280:h=720"));
    }

    #[test]
    fn a_centred_region_adds_no_drift_terms() {
        let f = build_zoom_filter(&[region(1.0, 3.0, 2.0)], 1280, 720, "a", "b").unwrap().unwrap();
        // The x/y centre expressions are just 0.5 when focus is the middle.
        assert!(f.contains("x='clip((0.5)*(trunc(1280*("));
        assert!(f.contains("y='clip((0.5)*(trunc(720*("));
    }

    #[test]
    fn an_off_centre_focus_drifts_the_view() {
        let mut r = region(1.0, 3.0, 2.0);
        r.focus_x = 0.8;
        let f = build_zoom_filter(&[r], 1280, 720, "a", "b").unwrap().unwrap();
        assert!(f.contains("x='clip((0.5+(0.30000)*("));
    }

    #[test]
    fn a_region_with_no_ease_is_a_hard_step() {
        let mut r = region(1.0, 3.0, 2.0);
        r.ease_ms = 0.0;
        let f = build_zoom_filter(&[r], 1280, 720, "a", "b").unwrap().unwrap();
        assert!(!f.contains("clip(min("));
    }

    #[test]
    fn rejects_an_empty_picture() {
        assert!(build_zoom_filter(&[region(1.0, 3.0, 2.0)], 0, 720, "a", "b").is_err());
    }

    #[test]
    fn expressions_have_balanced_parentheses_even_with_many_regions() {
        let regions: Vec<ZoomRegion> = (0..30).map(|i| region(i as f64 * 3.0, i as f64 * 3.0 + 2.0, 2.0)).collect();
        let f = build_zoom_filter(&regions, 1920, 1080, "a", "b").unwrap().unwrap();
        let open = f.matches('(').count();
        let close = f.matches(')').count();
        assert_eq!(open, close);
        assert!(f.len() < 60_000, "filter text stays a sane size: {}", f.len());
    }
    #[test]
    fn follow_keys_are_validated_and_static_regions_still_load() {
        let mut r = region(1.0, 4.0, 2.0);
        r.follow = true;
        r.focus_keys = vec![FocusKey { t: 3.0, x: 9.0, y: -2.0 },
            FocusKey { t: 1.0, x: 0.2, y: 0.5 }, FocusKey { t: 1.0, x: 0.3, y: 0.5 },
            FocusKey { t: f64::NAN, x: 0.0, y: 0.0 }];
        let out = sanitize(&[r]);
        assert_eq!(out[0].focus_keys.len(), 2);
        assert_eq!(out[0].focus_keys[0].x, 0.3);
        assert_eq!(out[0].focus_keys[1].x, 1.0);
        let expr = focus_expr(&out[0], true);
        assert!(expr.contains("clip((t-1.000000)/2.000000,0,1)"));
        let old: ZoomRegion = serde_json::from_str(r#"{"start":1,"end":3,"scale":2}"#).unwrap();
        assert!(!old.follow && old.focus_keys.is_empty());
    }

}
