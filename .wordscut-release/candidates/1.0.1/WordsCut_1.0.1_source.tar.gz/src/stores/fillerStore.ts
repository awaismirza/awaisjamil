/**
 * Which filler phrases are currently selected. Everything that highlights,
 * counts or cuts fillers reads this, so the transcript highlight, the counts
 * and the cut always agree. Defaults to the safe hesitation sounds only.
 */

import { create } from "zustand";
import { SAFE_FILLERS } from "@/lib/fillers";

interface FillerState {
  selected: ReadonlySet<string>;
  toggle: (phrase: string) => void;
}

export const useFillerStore = create<FillerState>((set) => ({
  selected: new Set(SAFE_FILLERS),
  toggle: (phrase) =>
    set((s) => {
      const next = new Set(s.selected);
      if (next.has(phrase)) next.delete(phrase);
      else next.add(phrase);
      return { selected: next };
    }),
}));
