import { create } from "zustand";
import { clampScale, DEFAULT_ZOOM_SCALE } from "@/lib/zoom";

/**
 * Panel shown when the sidebar first opens. Kept here (not in the panel
 * registry) so the store has no component imports — the registry test asserts
 * this id exists.
 */
export const DEFAULT_PANEL = "cleanup";

interface EditorUiState {
  activePanel: string;
  inspectorOpen: boolean;
  aspectRatio: "16:9" | "9:16" | "1:1" | "4:3";
  previewZoom: number;
  autoZoomEnabled: boolean;
  /** Magnification used by the next zoom region you create (selection menu, timeline). */
  zoomLevel: number;
  /** The zoom region being edited on the timeline, if any. */
  selectedZoomId: string | null;
  /** The clip (segment id) selected on the timeline; the Zoom panel follows its media. */
  selectedClipId: string | null;

  /** Rail click: switch to the panel, or toggle the drawer when it is already active. */
  setActivePanel: (panel: string) => void;
  /** Show a panel and make sure the drawer is open (never toggles it closed). */
  openPanel: (panel: string) => void;
  setAspectRatio: (ar: "16:9" | "9:16" | "1:1" | "4:3") => void;
  setPreviewZoom: (zoom: number) => void;
  setAutoZoomEnabled: (enabled: boolean) => void;
  setZoomLevel: (level: number) => void;
  selectZoomRegion: (id: string | null) => void;
  selectClip: (id: string | null) => void;
}

export const useEditorUiStore = create<EditorUiState>((set, get) => ({
  activePanel: DEFAULT_PANEL,
  // Closed on launch: the transcript stays wide, and the rail opens a panel on demand.
  inspectorOpen: false,
  aspectRatio: "16:9",
  previewZoom: 1,
  autoZoomEnabled: true,
  zoomLevel: DEFAULT_ZOOM_SCALE,
  selectedZoomId: null,
  selectedClipId: null,

  setActivePanel: (panel) => {
    const { activePanel, inspectorOpen } = get();
    if (panel === activePanel) {
      set({ inspectorOpen: !inspectorOpen });
    } else {
      set({ activePanel: panel, inspectorOpen: true });
    }
  },
  openPanel: (panel) => set({ activePanel: panel, inspectorOpen: true }),
  setAspectRatio: (ar) => set({ aspectRatio: ar }),
  setPreviewZoom: (zoom) => set({ previewZoom: zoom }),
  setAutoZoomEnabled: (enabled) => set({ autoZoomEnabled: enabled }),
  setZoomLevel: (level) => set({ zoomLevel: clampScale(level) }),
  selectZoomRegion: (id) => set({ selectedZoomId: id }),
  selectClip: (id) => set({ selectedClipId: id }),
}));
