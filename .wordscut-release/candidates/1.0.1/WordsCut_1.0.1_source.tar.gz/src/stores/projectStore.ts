/**
 * The project store is the single source of truth for the EDL.
 *
 * Every edit funnels through this store; `zundo` wraps it to give us undo/redo
 * with a 50-step ring buffer (per spec Phase 4).
 *
 * Heuristic: snapshot on every edit. We are not concerned about memory — the
 * EDL is tiny compared to the media files it references.
 */

import { withSourceTranscript } from "@/lib/sourceTranscript";
import { temporal, type TemporalState } from "zundo";
import { create, useStore } from "zustand";
import {
  addAudioTrack,
  addChapter,
  addMediaWithTranscript,
  cutSilences,
  deleteWords,
  keepOutputRange,
  newProject,
  removeAudioTrack,
  removeChapter,
  renameChapter,
  restoreWordsDetailed,
  setSegmentTiming,
  totalDuration,
  type RestoreResult,
  type TimingPatch,
  trimSourceRanges,
  updateAudioTrack,
  wordIdsInOutputRange,
  type AudioTrack,
  type Project,
  type SourceMedia,
  type Word,
} from "@/lib/edl";
import {
  trimClipEdge,
  splitClipAt,
  rollEdit,
  duplicateClip,
  moveClip,
  deleteClip,
  type ClipEdge,
} from "@/lib/clipEdit";
import { addVoiceOverTake, setVoiceOverMode, type NewTake } from "@/lib/voiceover";
import type { VoiceOverMode } from "@/lib/edl";
import { findFillersInSegments } from "@/lib/fillers";
import type { PauseSegment } from "@/lib/ipc";
import { sanitizeProjectCursor, sanitizeCursorStyle, type CursorStyle } from "@/lib/cursorStyle";
import { sanitizeCaptionStyle, type CaptionStyle } from "@/lib/captionStyle";
import { sanitizeCursorTrack, type CursorTrack } from "@/lib/cursor";
import { sanitizeAutoZoom, type AutoZoomSettings } from "@/lib/autoZoom";
import { sanitizeScene, type SceneSettings } from "@/lib/scene";
import {
  makeAnnotation,
  MAX_ANNOTATIONS,
  sanitizeAnnotations,
  type Annotation,
  type AnnotationKind,
} from "@/lib/annotations";
import {
  countKeyNames,
  sanitizeKeystrokes,
  stripKeyNames,
  type KeystrokeSettings,
} from "@/lib/keystrokes";
import {
  makeOverlay,
  MAX_OVERLAYS,
  sanitizeOverlays,
  type MediaOverlay,
  type OverlayFileInfo,
} from "@/lib/layers";
import { makeMask, MAX_MASKS, migrateMasks, sanitizeMasks, type PrivacyMask } from "@/lib/masks";
import { useUIStore } from "@/stores/uiStore";
import {
  deleteBySourceRange as deleteBySourceRangeOp,
  deleteWordsByText as deleteWordsByTextOp,
  replaceText as replaceTextOp,
  setChapters as setChaptersOp,
  withZoom,
} from "@/lib/projectOps";
import {
  addZoomRegion as addRegion,
  clearZoomRange as clearRange,
  removeZoomRegion as removeRegion,
  sanitizeZoomRegions,
  updateZoomRegion as updateRegion,
  type NewZoomRegion,
  type ZoomRegion,
} from "@/lib/zoom";

interface ProjectState {
  project: Project;
  /** True when the project has unsaved changes since the last save. */
  dirty: boolean;
  /** Absolute path on disk; null for an unsaved project. */
  filePath: string | null;

  attachTranscript: (
    projectId: string,
    mediaId: string,
    words: Word[],
    source?: SourceMedia,
  ) => boolean;
  trimClip: (segmentId: string, edge: ClipEdge, sourceTime: number) => void;
  splitClip: (outputTime: number) => void;
  rollCut: (leftSegmentId: string, delta: number) => void;
  /** One undo step each. Return false when nothing changed. */
  duplicateClip: (segmentId: string) => boolean;
  moveClip: (segmentId: string, toIndex: number) => boolean;
  /** Ripple delete: later clips close the gap. */
  deleteClip: (segmentId: string) => boolean;
  /**
   * Point a media entry at a new file path (relink). Not an undoable edit: the
   * path is rewritten in the undo history too, so Undo never re-breaks the link.
   */
  relinkMediaPath: (
    projectId: string,
    mediaId: string,
    path: string,
    /** `background`: a value backfilled on open (checksum, probed size) that is not
     *  a user change: the project stays clean and it persists on the next real save. */
    fix?: { width?: number; height?: number; sha256?: string; background?: boolean },
  ) => boolean;
  /** Restore deleted words from the original transcript (one undo step). */
  restoreWords: (ids: Iterable<string>) => RestoreResult;
  /** Speed / mute / freeze-frame hold / transition of one clip. One undo step. */
  setSegmentTiming: (segmentId: string, patch: TimingPatch) => void;

  // Mutations
  setProject: (p: Project) => void;
  rename: (name: string) => void;
  addMediaWithTranscript: (media: SourceMedia, words: Word[]) => void;
  deleteWords: (ids: Iterable<string>) => void;
  deleteOutputRange: (markIn: number, markOut: number) => number;
  /** Keep only the output-time range [markIn, markOut]; drop everything else. */
  keepOutputRange: (markIn: number, markOut: number) => void;
  /** Delete every word whose source-media span overlaps [srcStart, srcEnd].
   *  Use this with timestamps returned by ffmpeg silencedetect, which operates
   *  on the original source file. Returns the count of words removed. */
  deleteBySourceRange: (srcStart: number, srcEnd: number) => number;
  /** Delete every word whose text (case-insensitive, punctuation-stripped)
   *  matches one of the given tokens. Returns the count of words removed. */
  deleteWordsByText: (tokens: ReadonlySet<string>) => number;
  /**
   * Delete every occurrence of the given filler phrases (multi-word phrases
   * match consecutive words). Returns the count of occurrences removed.
   */
  deleteFillers: (phrases: Iterable<string>) => number;
  /** Replace the text of every word whose token equals `find` (case-insensitive)
   *  with `replace`. Returns the count of replacements made. */
  replaceText: (
    find: string,
    replace: string,
    opts?: { caseSensitive?: boolean; wholeWord?: boolean },
  ) => number;
  /**
   * Cut the given silences (from ffmpeg silencedetect on the first media)
   * longer than `minDuration` seconds, leaving `keepSec` of silence in place.
   * Returns the count of silences actually cut (0 = nothing to do).
   */
  trimSilences: (
    silences: ReadonlyArray<{ start: number; end: number }>,
    opts: { minDuration: number; keepSec?: number },
  ) => number;
  /** Chapter ops on the OUTPUT timeline. */
  addChapter: (outputTime: number, title?: string) => void;
  removeChapter: (id: string) => void;
  renameChapter: (id: string, title: string) => void;
  /**
   * Bulk-replace all chapters with an AI-generated set.
   *
   * Each entry needs only `title` and `outputTime`; stable UUIDs are assigned
   * here. The existing chapter list is replaced, not merged, so the user gets
   * a clean slate they can edit from.
   */
  setChapters: (chapters: Array<{ title: string; outputTime: number }>) => void;
  /**
   * Change the frame around the video. The patch is merged into the current
   * scene and re-validated; the first change turns the scene on unless the
   * patch says otherwise. Undoable like any edit.
   */
  setScene: (patch: Partial<SceneSettings>) => void;
  /** Remove the scene entirely (back to plain video). */
  clearScene: () => void;

  /** Zoom regions on the OUTPUT timeline. Overlaps are always resolved, newest wins. */
  addZoomRegion: (input: NewZoomRegion) => string | null;
  updateZoomRegion: (id: string, patch: Partial<Omit<ZoomRegion, "id">>) => void;
  removeZoomRegion: (id: string) => void;
  /** Remove zoom over a span of the output timeline. */
  clearZoomRange: (start: number, end: number) => void;
  setCursorStyle: (patch: Partial<CursorStyle>) => void;
  /** Merge a patch into the caption style (sanitized; creates it on first use). */
  setCaptionStyle: (patch: Partial<CaptionStyle>) => void;
  /** Annotations on the OUTPUT timeline. Each call is one undo step. */
  addAnnotation: (kind: AnnotationKind, at: number) => string | null;
  updateAnnotation: (id: string, patch: Partial<Omit<Annotation, "id">>) => void;
  removeAnnotation: (id: string) => void;
  setKeystrokes: (patch: Partial<KeystrokeSettings>) => void;
  /** Remove recorded key names / secure flags from the cursor tracks in one step; returns how many events changed. */
  stripKeyNames: () => number;
  /** Image / video overlays on the OUTPUT timeline. Each call is one undo step. */
  addOverlay: (file: OverlayFileInfo, at: number, frameAspect: number) => string | null;
  updateOverlay: (id: string, patch: Partial<Omit<MediaOverlay, "id" | "kind" | "path">>) => void;
  removeOverlay: (id: string) => void;
  /**
   * Point every overlay using `oldPath` at a verified new file (relink). Like
   * `relinkMediaPath` it is not an undo step: history is rewritten too.
   */
  relinkOverlayPath: (projectId: string, oldPath: string, file: OverlayFileInfo) => boolean;
  /** Privacy masks on the OUTPUT timeline, in source-picture coordinates. One undo step each. */
  addMask: (at: number) => string | null;
  updateMask: (id: string, patch: Partial<Omit<PrivacyMask, "id">>) => void;
  removeMask: (id: string) => void;
  setAutoZoom: (patch: Partial<AutoZoomSettings>) => void;
  setCursorTrack: (mediaId: string, track: CursorTrack) => void;
  /** Attach an already parsed recording track without an extra undo step. */
  attachCursorTrack: (projectId: string, source: SourceMedia, track: CursorTrack) => boolean;
  /** One atomic undo step for a reviewed set. */
  applyZoomSuggestions: (regions: ZoomRegion[], replace: boolean) => void;
  /** Audio-track ops (music beds / sfx mixed under the main EDL). */
  addAudioTrack: (track: Omit<AudioTrack, "id">) => void;
  removeAudioTrack: (id: string) => void;
  updateAudioTrack: (id: string, patch: Partial<Omit<AudioTrack, "id" | "mediaId">>) => void;
  /** Keep a reviewed voice-over take (media + track + insert hold): one undo step.
   *  Null when `projectId` is no longer the open project. */
  addVoiceOverTake: (projectId: string, take: NewTake) => string | null;
  setVoiceOverMode: (id: string, mode: VoiceOverMode) => void;
  /** Background transcript of a kept take; not an undo step (history is rebased). */
  attachVoiceOverWords: (
    projectId: string,
    trackId: string,
    mediaId: string,
    words: Word[],
  ) => boolean;
  /** Add a SourceMedia entry without creating a transcript segment for it.
   *  Used when importing a music file purely as an audio-track input. */
  addMediaOnly: (media: SourceMedia) => void;
  markSaved: (path: string) => void;
  closeProject: () => void;

  // ---------------------------------------------------------------------------
  // Pause tokens — detected silences displayed as inline [0.6s] badges.
  //
  // Stored here (rather than uiStore) so they survive undo/redo of EDL edits
  // and can eventually be saved with the project file.
  //
  // Phase 1 limitation: pauseTokens are NOT yet written to the .scribe bundle.
  // TODO Phase 2: serialize pauseTokens into project.json so they reload.
  // ---------------------------------------------------------------------------

  /** Currently detected pause segments for the loaded project. */
  pauseTokens: PauseSegment[];
  /** Replace the pause list (e.g. after a fresh detect_pauses run). */
  setPauseTokens: (pauses: PauseSegment[]) => void;
  /** Remove a pause token by id without touching the EDL. */
  removePauseToken: (id: string) => void;
  /** Mark a pause as deleted (EDL cut already applied elsewhere). */
  markPauseDeleted: (id: string) => void;
  /**
   * Cut the pause out of the EDL (words are never touched) and remove its
   * badge. A no-op cut keeps the badge. Returns true when time was removed.
   */
  deletePauseById: (id: string) => boolean;
  /**
   * Cut every pause longer than `seconds`, leaving `keepSec` (default 0) of
   * silence, and remove the badges that were actually cut. Returns the count
   * of pauses cut.
   */
  deletePausesLongerThan: (seconds: number, keepSec?: number) => number;
  /**
   * Shorten every pause longer than `longerThan` to `shortenTo` seconds: the
   * middle of the pause is cut from the EDL (so preview and export both lose
   * it), keeping `shortenTo / 2` of silence on each side, and the badge is
   * updated. Returns the count of pauses shortened.
   */
  shortenPausesLongerThan: (opts: { longerThan: number; shortenTo: number }) => number;
}

/**
 * Cut each pause from the first media (where pauses are detected), leaving
 * `keep` seconds of silence split across both sides. Cuts go one at a time so
 * the caller learns which pauses really removed time; word spans are never
 * clipped (see `trimSourceRanges`).
 */
function cutPauses(
  project: Project,
  pauses: readonly PauseSegment[],
  keep: number,
): { project: Project; cutIds: Set<string> } {
  const mediaId = Object.keys(project.media)[0];
  const cutIds = new Set<string>();
  if (!mediaId) return { project, cutIds };
  let next = project;
  for (const pause of pauses) {
    const [after, cut] = trimSourceRanges(next, mediaId, [
      { start: pause.start + keep / 2, end: pause.end - keep / 2 },
    ]);
    if (cut > 0) {
      next = after;
      cutIds.add(pause.id);
    }
  }
  return { project: next, cutIds };
}

/** Apply a clip operation as a single store update (so a single undo step). */
function applyClipOp(
  set: (partial: Partial<ProjectState>) => void,
  get: () => ProjectState,
  op: (project: Project) => Project,
): boolean {
  const before = get().project;
  const project = op(before);
  if (project === before) return false;
  set({ project, dirty: true });
  return true;
}

export const useProjectStore = create<ProjectState>()(
  temporal(
    (set, _get) => ({
      project: newProject("Untitled"),
      dirty: false,
      filePath: null,
      pauseTokens: [],

      attachTranscript: (projectId, mediaId, words, source) => {
        const project = _get().project;
        if (project.id !== projectId) return false;
        const media = source ?? project.media[mediaId];
        if (!media) return false;
        const history = useProjectStore.temporal.getState();
        const wasTracking = history.isTracking;
        history.pause();
        const next =
          project.media[mediaId] === media
            ? withSourceTranscript(project, mediaId, words)
            : project;
        if (next !== project)
          set({ project: { ...next, updatedAt: new Date().toISOString() }, dirty: true });
        const rebase = (state: Partial<{ project: Project }>) =>
          state.project?.id === projectId && state.project.media[mediaId] === media
            ? { project: withSourceTranscript(state.project, mediaId, words) }
            : state;
        useProjectStore.temporal.setState({
          pastStates: history.pastStates.map(rebase),
          futureStates: history.futureStates.map(rebase),
        });
        if (wasTracking) history.resume();
        return next !== project;
      },
      trimClip: (id, edge, time) =>
        set((s) => {
          const mediaId = s.project.segments.find((segment) => segment.id === id)?.mediaId;
          const project = trimClipEdge(
            s.project,
            id,
            edge,
            time,
            s.project.originalTranscripts?.[mediaId ?? ""],
          );
          return project === s.project ? s : { project, dirty: true };
        }),
      splitClip: (time) =>
        set((s) => {
          const project = splitClipAt(s.project, time);
          return project === s.project ? s : { project, dirty: true };
        }),
      rollCut: (id, delta) =>
        set((s) => {
          const project = rollEdit(s.project, id, delta, s.project.originalTranscripts);
          return project === s.project ? s : { project, dirty: true };
        }),
      duplicateClip: (id) => applyClipOp(set, _get, (p) => duplicateClip(p, id)),
      moveClip: (id, to) => applyClipOp(set, _get, (p) => moveClip(p, id, to)),
      deleteClip: (id) => applyClipOp(set, _get, (p) => deleteClip(p, id)),
      relinkMediaPath: (projectId, mediaId, path, fix) => {
        const current = _get().project;
        if (current.id !== projectId || !current.media[mediaId]) return false;
        // A probed size (relink, or the refresh on open) replaces a stale stored one.
        // A checksum computed later (projects from before hashing) is recorded too.
        const dims = {
          ...(fix?.width && fix.height && fix.width > 0 && fix.height > 0
            ? { width: fix.width, height: fix.height }
            : {}),
          ...(fix?.sha256 && /^[0-9a-f]{64}$/.test(fix.sha256) ? { sha256: fix.sha256 } : {}),
        };
        const rewrite = (p: Project): Project =>
          p.id === projectId && p.media[mediaId]
            ? { ...p, media: { ...p.media, [mediaId]: { ...p.media[mediaId], path, ...dims } } }
            : p;
        const history = useProjectStore.temporal.getState();
        const wasTracking = history.isTracking;
        history.pause();
        set({ project: rewrite(current), ...(fix?.background ? {} : { dirty: true }) });
        const rebase = (state: Partial<{ project: Project }>) =>
          state.project ? { ...state, project: rewrite(state.project) } : state;
        useProjectStore.temporal.setState({
          pastStates: history.pastStates.map(rebase),
          futureStates: history.futureStates.map(rebase),
        });
        if (wasTracking) history.resume();
        return true;
      },
      restoreWords: (ids) => {
        const result = restoreWordsDetailed(_get().project, new Set(ids));
        if (result.project !== _get().project) set({ project: result.project, dirty: true });
        return result;
      },
      setSegmentTiming: (id, patch) =>
        set((s) => {
          const project = setSegmentTiming(s.project, id, patch);
          return project === s.project ? s : { project, dirty: true };
        }),
      setProject: (p) =>
        set({
          project: {
            ...withMigratedMasks(p),
            ...(p.cursor ? { cursor: sanitizeProjectCursor(p.cursor) } : {}),
            ...(p.captions ? { captions: sanitizeCaptionStyle(p.captions) } : {}),
          },
          dirty: true,
        }),

      rename: (name) =>
        set((s) => ({
          project: { ...s.project, name, updatedAt: new Date().toISOString() },
          dirty: true,
        })),

      addMediaWithTranscript: (media, words) =>
        set((s) => ({
          project: addMediaWithTranscript(s.project, media, words),
          dirty: true,
        })),

      deleteWords: (ids) =>
        set((s) => ({
          project: deleteWords(s.project, new Set(ids)),
          dirty: true,
        })),

      deleteOutputRange: (markIn, markOut) => {
        const project = _get().project;
        const ids = wordIdsInOutputRange(project, markIn, markOut);
        if (ids.length === 0) return 0;
        set({
          project: deleteWords(project, new Set(ids)),
          dirty: true,
        });
        return ids.length;
      },

      keepOutputRange: (markIn, markOut) => {
        const project = _get().project;
        const next = keepOutputRange(project, markIn, markOut);
        if (next === project) return;
        set({ project: next, dirty: true });
      },

      deleteBySourceRange: (srcStart, srcEnd) => {
        const { project, count } = deleteBySourceRangeOp(_get().project, srcStart, srcEnd);
        if (count === 0) return 0;
        set({ project, dirty: true });
        return count;
      },

      deleteFillers: (phrases) => {
        const project = _get().project;
        const matches = findFillersInSegments(project.segments, phrases);
        if (matches.length === 0) return 0;
        const ids = new Set(matches.flatMap((m) => m.wordIds));
        set({ project: deleteWords(project, ids), dirty: true });
        return matches.length;
      },

      deleteWordsByText: (tokens) => {
        const { project, count } = deleteWordsByTextOp(_get().project, tokens);
        if (count === 0) return 0;
        set({ project, dirty: true });
        return count;
      },

      replaceText: (find, replace, opts) => {
        const { project, count } = replaceTextOp(_get().project, find, replace, opts);
        if (count === 0) return 0;
        set({ project, dirty: true });
        return count;
      },

      trimSilences: (silences, opts) => {
        const project = _get().project;
        const mediaId = Object.keys(project.media)[0];
        if (!mediaId) return 0;
        const [next, cut] = cutSilences(project, mediaId, silences, opts);
        if (cut === 0) return 0;
        set({ project: next, dirty: true });
        return cut;
      },

      addChapter: (outputTime, title) =>
        set((s) => ({ project: addChapter(s.project, outputTime, title), dirty: true })),
      removeChapter: (id) => set((s) => ({ project: removeChapter(s.project, id), dirty: true })),
      renameChapter: (id, title) =>
        set((s) => ({ project: renameChapter(s.project, id, title), dirty: true })),
      setScene: (patch) =>
        set((s) => {
          const current = sanitizeScene(s.project.scene);
          const next = sanitizeScene({
            ...current,
            enabled: patch.enabled ?? true,
            ...patch,
          });
          return {
            project: { ...s.project, scene: next, updatedAt: new Date().toISOString() },
            dirty: true,
          };
        }),

      clearScene: () =>
        set((s) => {
          if (!s.project.scene) return s;
          const project = { ...s.project, updatedAt: new Date().toISOString() };
          delete project.scene;
          return { project, dirty: true };
        }),

      setCaptionStyle: (patch) =>
        set((s) => ({
          project: {
            ...s.project,
            captions: sanitizeCaptionStyle({
              ...sanitizeCaptionStyle(s.project.captions),
              ...patch,
            }),
            updatedAt: new Date().toISOString(),
          },
          dirty: true,
        })),
      setCursorStyle: (patch) =>
        set((s) => {
          const cursor = s.project.cursor ?? sanitizeProjectCursor(undefined);
          const next = { ...cursor, style: sanitizeCursorStyle({ ...cursor.style, ...patch }) };
          return {
            project: { ...s.project, cursor: next, updatedAt: new Date().toISOString() },
            dirty: true,
          };
        }),
      setAutoZoom: (patch) =>
        set((s) => {
          const cursor = s.project.cursor ?? sanitizeProjectCursor(undefined);
          const next = { ...cursor, autoZoom: sanitizeAutoZoom({ ...cursor.autoZoom, ...patch }) };
          return {
            project: { ...s.project, cursor: next, updatedAt: new Date().toISOString() },
            dirty: true,
          };
        }),
      attachCursorTrack: (projectId, source, track) => {
        const project = _get().project;
        if (project.id !== projectId || !track.events.length) return false;
        const history = useProjectStore.temporal.getState();
        const wasTracking = history.isTracking;
        const attach = (p: Project): Project => {
          if (p.id !== projectId || p.media[source.id] !== source) return p;
          const cursor = p.cursor ?? sanitizeProjectCursor(undefined);
          return { ...p, cursor: { ...cursor, tracks: { ...cursor.tracks, [source.id]: track } } };
        };
        history.pause();
        try {
          const next = attach(project);
          if (next !== project)
            set({ project: { ...next, updatedAt: new Date().toISOString() }, dirty: true });
          const rebase = (state: Partial<{ project: Project }>) => {
            if (!state.project) return state;
            const next = attach(state.project);
            return next === state.project ? state : { ...state, project: next };
          };
          useProjectStore.temporal.setState({
            pastStates: history.pastStates.map(rebase),
            futureStates: history.futureStates.map(rebase),
          });
          return next !== project;
        } finally {
          if (wasTracking) history.resume();
        }
      },
      setCursorTrack: (mediaId, track) =>
        set((s) => {
          if (
            !Object.hasOwn(s.project.media, mediaId) ||
            ["__proto__", "constructor", "prototype"].includes(mediaId)
          )
            return s;
          const cursor = s.project.cursor ?? sanitizeProjectCursor(undefined);
          const validated = sanitizeCursorTrack(track);
          const tracks = { ...cursor.tracks };
          if (validated.events.length) tracks[mediaId] = validated;
          else delete tracks[mediaId];
          const next = { ...cursor, tracks };
          return {
            project: { ...s.project, cursor: next, updatedAt: new Date().toISOString() },
            dirty: true,
          };
        }),
      applyZoomSuggestions: (regions, replace) =>
        set((s) => {
          const total = totalDuration(s.project);
          let next = replace ? [] : sanitizeZoomRegions(s.project.zoomRegions, total);
          for (const r of sanitizeZoomRegions(regions, total))
            next = addRegion(
              next.filter((old) => old.id !== r.id),
              r,
              total,
            );
          return { project: withZoom(s.project, next), dirty: true };
        }),

      addAnnotation: (kind, at) => {
        const project = _get().project;
        const total = totalDuration(project);
        const added = makeAnnotation(kind, at, total);
        const current = sanitizeAnnotations(project.annotations, total);
        if (!added || current.length >= MAX_ANNOTATIONS) return null;
        const list = [...current, added];
        set({ project: withAnnotations(project, list, total), dirty: true });
        return added.id;
      },

      updateAnnotation: (id, patch) => {
        const project = _get().project;
        const total = totalDuration(project);
        const current = sanitizeAnnotations(project.annotations, total);
        const i = current.findIndex((a) => a.id === id);
        if (i < 0) return;
        const next = [...current];
        next[i] = { ...current[i]!, ...patch, id };
        const result = withAnnotations(project, next, total);
        // An invalid patch (e.g. empty text) is refused rather than deleting the annotation.
        if (!result.annotations?.some((a) => a.id === id)) return;
        set({ project: result, dirty: true });
      },

      removeAnnotation: (id) => {
        const project = _get().project;
        const total = totalDuration(project);
        const current = sanitizeAnnotations(project.annotations, total);
        if (!current.some((a) => a.id === id)) return;
        set({
          project: withAnnotations(
            project,
            current.filter((a) => a.id !== id),
            total,
          ),
          dirty: true,
        });
      },

      addOverlay: (file, at, frameAspect) => {
        const project = _get().project;
        const total = totalDuration(project);
        const added = makeOverlay(file, at, total, frameAspect);
        const current = sanitizeOverlays(project.overlays, total);
        if (!added || current.length >= MAX_OVERLAYS) return null;
        set({ project: withLayer(project, "overlays", [...current, added], total), dirty: true });
        return added.id;
      },
      updateOverlay: (id, patch) => {
        const project = _get().project;
        const total = totalDuration(project);
        const current = sanitizeOverlays(project.overlays, total);
        const i = current.findIndex((o) => o.id === id);
        if (i < 0) return;
        const next = [...current];
        next[i] = { ...current[i]!, ...patch, id };
        const result = withLayer(project, "overlays", next, total);
        if (!result.overlays?.some((o) => o.id === id)) return;
        set({ project: result, dirty: true });
      },
      removeOverlay: (id) => {
        const project = _get().project;
        const total = totalDuration(project);
        const current = sanitizeOverlays(project.overlays, total);
        if (!current.some((o) => o.id === id)) return;
        const rest = current.filter((o) => o.id !== id);
        set({ project: withLayer(project, "overlays", rest, total), dirty: true });
      },
      relinkOverlayPath: (projectId, oldPath, file) => {
        const current = _get().project;
        if (current.id !== projectId || !current.overlays?.some((o) => o.path === oldPath))
          return false;
        const rewrite = (p: Project): Project =>
          p.id === projectId && p.overlays?.some((o) => o.path === oldPath)
            ? {
                ...p,
                overlays: p.overlays.map((o) =>
                  o.path === oldPath
                    ? {
                        ...o,
                        path: file.path,
                        ...(file.sha256 ? { sha256: file.sha256 } : {}),
                        srcW: file.width,
                        srcH: file.height,
                      }
                    : o,
                ),
              }
            : p;
        const history = useProjectStore.temporal.getState();
        const wasTracking = history.isTracking;
        history.pause();
        set({ project: rewrite(current), dirty: true });
        const rebase = (state: Partial<{ project: Project }>) =>
          state.project ? { ...state, project: rewrite(state.project) } : state;
        useProjectStore.temporal.setState({
          pastStates: history.pastStates.map(rebase),
          futureStates: history.futureStates.map(rebase),
        });
        if (wasTracking) history.resume();
        return true;
      },
      addMask: (at) => {
        const project = _get().project;
        const total = totalDuration(project);
        const added = makeMask(project, at);
        const current = sanitizeMasks(project.masks);
        if (!added || current.length >= MAX_MASKS) return null;
        set({ project: withLayer(project, "masks", [...current, added], total), dirty: true });
        return added.id;
      },
      updateMask: (id, patch) => {
        const project = _get().project;
        const total = totalDuration(project);
        const current = sanitizeMasks(project.masks);
        const i = current.findIndex((m) => m.id === id);
        if (i < 0) return;
        const next = [...current];
        next[i] = { ...current[i]!, ...patch, id };
        const result = withLayer(project, "masks", next, total);
        if (!result.masks?.some((m) => m.id === id)) return;
        set({ project: result, dirty: true });
      },
      removeMask: (id) => {
        const project = _get().project;
        const total = totalDuration(project);
        const current = sanitizeMasks(project.masks);
        if (!current.some((m) => m.id === id)) return;
        const rest = current.filter((m) => m.id !== id);
        set({ project: withLayer(project, "masks", rest, total), dirty: true });
      },

      setKeystrokes: (patch) =>
        set((s) => ({
          project: {
            ...s.project,
            keystrokes: sanitizeKeystrokes({
              ...sanitizeKeystrokes(s.project.keystrokes),
              ...patch,
            }),
            updatedAt: new Date().toISOString(),
          },
          dirty: true,
        })),

      stripKeyNames: () => {
        const before = _get().project;
        const count = countKeyNames(before);
        if (count === 0) return 0;
        set({ project: stripKeyNames(before), dirty: true });
        return count;
      },

      addZoomRegion: (input) => {
        const project = _get().project;
        const total = totalDuration(project);
        const current = sanitizeZoomRegions(project.zoomRegions, total);
        const id = input.id ?? crypto.randomUUID();
        const next = addRegion(current, { ...input, id }, total);
        if (!next.some((r) => r.id === id)) return null;
        set({ project: withZoom(project, next), dirty: true });
        return id;
      },

      updateZoomRegion: (id, patch) => {
        const project = _get().project;
        const total = totalDuration(project);
        const current = sanitizeZoomRegions(project.zoomRegions, total);
        set({ project: withZoom(project, updateRegion(current, id, patch, total)), dirty: true });
      },

      removeZoomRegion: (id) => {
        const project = _get().project;
        const current = sanitizeZoomRegions(project.zoomRegions, totalDuration(project));
        if (!current.some((r) => r.id === id)) return;
        set({ project: withZoom(project, removeRegion(current, id)), dirty: true });
      },

      clearZoomRange: (start, end) => {
        const project = _get().project;
        const current = sanitizeZoomRegions(project.zoomRegions, totalDuration(project));
        const next = clearRange(current, start, end);
        if (
          next.length === current.length &&
          next.every((r, i) => r.start === current[i]!.start && r.end === current[i]!.end)
        ) {
          return;
        }
        set({ project: withZoom(project, next), dirty: true });
      },

      setChapters: (chapters) =>
        set((s) => ({ project: setChaptersOp(s.project, chapters), dirty: true })),

      addAudioTrack: (track) =>
        set((s) => ({ project: addAudioTrack(s.project, track), dirty: true })),
      removeAudioTrack: (id) =>
        set((s) => ({ project: removeAudioTrack(s.project, id), dirty: true })),
      updateAudioTrack: (id, patch) =>
        set((s) => ({ project: updateAudioTrack(s.project, id, patch), dirty: true })),
      addVoiceOverTake: (projectId, take) => {
        const current = _get().project;
        if (current.id !== projectId) return null;
        const { project, id } = addVoiceOverTake(current, take);
        set({ project, dirty: true });
        return id;
      },
      setVoiceOverMode: (id, mode) =>
        set((s) => {
          const project = setVoiceOverMode(s.project, id, mode);
          return project === s.project ? s : { project, dirty: true };
        }),
      attachVoiceOverWords: (projectId, trackId, mediaId, words) => {
        const rewrite = (p: Project): Project =>
          p.id === projectId
            ? {
                ...p,
                audioTracks: (p.audioTracks ?? []).map((t) =>
                  t.id === trackId && t.mediaId === mediaId ? { ...t, words } : t,
                ),
              }
            : p;
        const current = _get().project;
        const has = (p: Project) =>
          p.id === projectId &&
          !!p.audioTracks?.some((t) => t.id === trackId && t.mediaId === mediaId);
        const history = useProjectStore.temporal.getState();
        const inHistory = [...history.pastStates, ...history.futureStates].some(
          (st) => st.project && has(st.project),
        );
        if (!has(current) && !inHistory) return false;
        const wasTracking = history.isTracking;
        history.pause();
        if (has(current)) set({ project: rewrite(current), dirty: true });
        const rebase = (state: Partial<{ project: Project }>) =>
          state.project ? { ...state, project: rewrite(state.project) } : state;
        useProjectStore.temporal.setState({
          pastStates: history.pastStates.map(rebase),
          futureStates: history.futureStates.map(rebase),
        });
        if (wasTracking) history.resume();
        return true;
      },
      addMediaOnly: (media) =>
        set((s) => ({
          project: {
            ...s.project,
            media: { ...s.project.media, [media.id]: media },
            updatedAt: new Date().toISOString(),
          },
          dirty: true,
        })),

      markSaved: (path) => set({ dirty: false, filePath: path }),

      closeProject: () =>
        set({
          project: newProject("Untitled"),
          dirty: false,
          filePath: null,
          pauseTokens: [],
        }),

      // -----------------------------------------------------------------------
      // Pause token actions
      // -----------------------------------------------------------------------

      setPauseTokens: (pauses) => set({ pauseTokens: pauses }),

      removePauseToken: (id) =>
        set((s) => ({ pauseTokens: s.pauseTokens.filter((p) => p.id !== id) })),

      markPauseDeleted: (id) =>
        set((s) => ({
          pauseTokens: s.pauseTokens.map((p) => (p.id === id ? { ...p, deleted: true } : p)),
        })),

      deletePauseById: (id) => {
        const { pauseTokens, project } = _get();
        const pause = pauseTokens.find((p) => p.id === id);
        if (!pause) return false;
        const { project: next, cutIds } = cutPauses(project, [pause], 0);
        if (cutIds.size === 0) return false;
        set({ project: next, dirty: true, pauseTokens: pauseTokens.filter((p) => p.id !== id) });
        return true;
      },

      deletePausesLongerThan: (seconds, keepSec = 0) => {
        const { pauseTokens, project } = _get();
        const keep = Math.max(0, keepSec);
        const targets = pauseTokens.filter((p) => !p.deleted && p.duration > seconds);
        if (targets.length === 0) return 0;
        const { project: next, cutIds } = cutPauses(project, targets, keep);
        if (cutIds.size === 0) return 0;
        set({
          project: next,
          dirty: true,
          pauseTokens: pauseTokens.filter((p) => !cutIds.has(p.id)),
        });
        return cutIds.size;
      },

      shortenPausesLongerThan: ({ longerThan, shortenTo }) => {
        const { pauseTokens, project } = _get();
        // Pauses are detected on the first media (see Toolbox handleShowPauses).
        const mediaId = Object.keys(project.media)[0];
        if (!mediaId) return 0;
        const keep = Math.max(0, shortenTo);
        const targets = pauseTokens.filter(
          (p) => !p.deleted && p.duration > longerThan && (p.shortenedTo ?? p.duration) > keep,
        );
        if (targets.length === 0) return 0;
        // Cut the middle of each pause; half of `keep` stays on either side.
        const [next] = trimSourceRanges(
          project,
          mediaId,
          targets.map((p) => ({ start: p.start + keep / 2, end: p.end - keep / 2 })),
        );
        const targetIds = new Set(targets.map((p) => p.id));
        set({
          // Only touch `project` when it changed, so a no-op adds no undo step.
          ...(next !== project ? { project: next, dirty: true } : {}),
          pauseTokens: pauseTokens.map((p) =>
            targetIds.has(p.id) ? { ...p, shortenedTo: keep } : p,
          ),
        });
        return targets.length;
      },
    }),
    {
      // Per spec: cap undo at 50 steps.
      limit: 50,
      // Only snapshot the `project` field — don't churn the stack on dirty/path changes.
      partialize: (state) => ({ project: state.project }),
      equality: (before, after) => before.project === after.project,
      // UI drags commit once on release. Record edits synchronously so source
      // analysis can rebase every existing undo snapshot without a delayed
      // history callback reintroducing untranscribed revisions.
    },
  ),
);

// Undo/redo restores only the project field. Saving followed by undo is a new
// unsaved revision too; baseline loads pause tracking and deliberately stay clean.
useProjectStore.subscribe((state, before) => {
  if (
    state.project !== before.project &&
    state.project.id === before.project.id &&
    !state.dirty &&
    useProjectStore.temporal.getState().isTracking
  )
    useProjectStore.setState({ dirty: true });
});

/**
 * Replace the project as loaded baseline state, not as an undoable edit.
 * Open/import/transcribe completion should not become "undo transcription".
 */
export function replaceProjectBaseline(
  project: Project,
  opts: { filePath?: string | null; dirty?: boolean } = {},
) {
  const temporalStore = useProjectStore.temporal.getState();
  temporalStore.pause();
  useProjectStore.setState({
    project: {
      ...withMigratedMasks(project),
      ...(project.cursor ? { cursor: sanitizeProjectCursor(project.cursor) } : {}),
      ...(project.captions ? { captions: sanitizeCaptionStyle(project.captions) } : {}),
    },
    dirty: opts.dirty ?? false,
    filePath: opts.filePath ?? null,
  });
  temporalStore.clear();
  setTimeout(() => {
    temporalStore.clear();
    temporalStore.resume();
  }, 150);
}

/**
 * Masks saved by an output-time build become source-anchored through the
 * project's timeline (`migrateMasks`); the user is told, and told loudly when
 * an old mask covered nothing and was removed.
 */
function withMigratedMasks(p: Project): Project {
  if (!Array.isArray(p.masks) || p.masks.length === 0) return p;
  const { masks, converted, dropped } = migrateMasks(p);
  if (converted > 0 || dropped > 0)
    useUIStore.getState().pushToast({
      title: "Privacy masks updated",
      description:
        `${converted} mask(s) from an older build now follow their source footage everywhere it plays.` +
        (dropped > 0 ? ` ${dropped} covered nothing on the timeline and were removed.` : "") +
        " Check them in the Overlays tab before exporting.",
      variant: dropped > 0 ? "destructive" : "default",
    });
  const next: Project = { ...p };
  if (masks.length > 0) next.masks = masks;
  else delete next.masks;
  return next;
}

/** The project with these annotations; none at all leaves the field off the file. */
function withAnnotations(project: Project, list: Annotation[], total: number): Project {
  const next: Project = { ...project, updatedAt: new Date().toISOString() };
  const clean = sanitizeAnnotations(list, total);
  if (clean.length > 0) next.annotations = clean;
  else delete next.annotations;
  return next;
}

/** True when the open project, or any undo / redo state, uses media at `path`
 *  (such a file is needed for redo and must never be deleted). */
export function isMediaPathReferenced(path: string): boolean {
  const { pastStates, futureStates } = useProjectStore.temporal.getState();
  return [
    useProjectStore.getState().project,
    ...[...pastStates, ...futureStates].map((s) => s.project),
  ]
    .filter((p): p is Project => !!p)
    .some((p) => Object.values(p.media).some((m) => m.path === path));
}

/** The project with this overlay / mask list; an empty list leaves the field off the file. */
function withLayer(
  project: Project,
  key: "overlays" | "masks",
  list: MediaOverlay[] | PrivacyMask[],
  total: number,
): Project {
  const next: Project = { ...project, updatedAt: new Date().toISOString() };
  if (key === "overlays") {
    const clean = sanitizeOverlays(list, total);
    if (clean.length > 0) next.overlays = clean;
    else delete next.overlays;
  } else {
    const clean = sanitizeMasks(list);
    if (clean.length > 0) next.masks = clean;
    else delete next.masks;
  }
  return next;
}

/** Helper for components to access undo/redo. */
export function useTemporalProjectStore<T>(
  selector: (state: TemporalState<{ project: Project }>) => T,
): T {
  // The temporal store is exposed as a method on the main store.
  return useStore(useProjectStore.temporal, selector);
}
