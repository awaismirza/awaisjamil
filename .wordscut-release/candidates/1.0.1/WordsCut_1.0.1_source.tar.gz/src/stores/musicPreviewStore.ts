/** Which music tracks the editor preview could not load or play (by track id). */

import { create } from "zustand";

interface MusicPreviewState {
  failed: Record<string, true>;
  setFailed: (trackId: string, failed: boolean) => void;
}

export const useMusicPreviewStore = create<MusicPreviewState>((set) => ({
  failed: {},
  setFailed: (trackId, failed) =>
    set((s) => {
      if (!!s.failed[trackId] === failed) return s;
      const next = { ...s.failed };
      if (failed) next[trackId] = true;
      else delete next[trackId];
      return { failed: next };
    }),
}));
