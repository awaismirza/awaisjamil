/** Persisted timeline view preferences. Deliberately separate from projectStore: no undo, no EDL. */
import { create } from "zustand";
import {
  applyPreset,
  resetView,
  sanitizePrefs,
  setHideEmpty,
  showPopulated,
  toggleLane,
  type LaneId,
  type TimelineViewPrefs,
  type ViewPreset,
} from "@/lib/timelineView";

export const TIMELINE_VIEW_KEY = "yusafcut.timelineView";

function load(): TimelineViewPrefs {
  try {
    const raw = window.localStorage?.getItem(TIMELINE_VIEW_KEY);
    return sanitizePrefs(raw ? JSON.parse(raw) : null);
  } catch {
    return resetView();
  }
}

function persist(p: TimelineViewPrefs) {
  try {
    window.localStorage?.setItem(TIMELINE_VIEW_KEY, JSON.stringify(p));
  } catch {
    /* storage unavailable: the view just won't survive a restart */
  }
}

interface State {
  prefs: TimelineViewPrefs;
  setPreset: (p: ViewPreset) => void;
  setLane: (id: LaneId, on: boolean) => void;
  setHideEmpty: (v: boolean) => void;
  showPopulated: (content: Partial<Record<LaneId, boolean>>) => void;
  reset: () => void;
}

export const useTimelineViewStore = create<State>((set, get) => {
  const update = (next: TimelineViewPrefs) => {
    persist(next);
    set({ prefs: next });
  };
  return {
    prefs: load(),
    setPreset: (p) => update(applyPreset(p, get().prefs)),
    setLane: (id, on) => update(toggleLane(get().prefs, id, on)),
    setHideEmpty: (v) => update(setHideEmpty(get().prefs, v)),
    showPopulated: (c) => update(showPopulated(get().prefs, c)),
    reset: () => update(resetView()),
  };
});
