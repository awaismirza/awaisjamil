/**
 * Voice-over workflow: record narration at the playhead, review the take, keep
 * it as an editable track (see `lib/voiceover.ts` for the model).
 *
 * State machine (one take at a time):
 *
 *   idle ─start─▶ countdown ─▶ starting ─▶ recording ─stop─▶ stopping ─▶ review
 *     ▲                                                                   │
 *     └──────────── keep / discard / Escape (take stays pending) ◀────────┘
 *
 * - The anchor is captured BEFORE the countdown, so playback during the take
 *   cannot move it; it is stored with its clip identity (`captureAnchor`) and
 *   resolved again when the take is kept, so edits made meanwhile are followed.
 * - Playback (when enabled) starts only once Rust reports the take live. Rust
 *   returns from `start_recording` after the first accepted microphone sample
 *   (native helper latch / FFmpeg first sample), so the take's t = 0 is the
 *   moment the picture starts moving from the anchor; `latencyMs` is a manual
 *   trim for whatever delay remains on a given machine.
 * - The take is started with `purpose: "voiceover-take"`, which Rust echoes in
 *   the result, so it is never auto-appended to the timeline.
 * - Every finished take is persisted (localStorage) before Rust's pending
 *   result is acknowledged, so a reload or restart can still review it.
 * - Discard deletes only the take's own recording folder, and only when no
 *   project state (undo / redo included) references the file.
 */

import { create } from "zustand";
import { v4 as uuidv4 } from "uuid";
import {
  ackRecordingResult,
  cancelRecording,
  discardRecordingTake,
  importMedia,
  listRecordingDevices,
  startRecording,
  stopRecording,
  transcribe,
  type RecordingDevices,
  type RecordingResult,
} from "@/lib/ipc";
import type { VoiceOverMode } from "@/lib/edl";
import { captureAnchor, MIN_TAKE_SEC, resolveAnchor, type VoiceOverAnchor } from "@/lib/voiceover";
import { formatTimecode } from "@/lib/timecode";
import { isMediaPathReferenced, useProjectStore } from "@/stores/projectStore";
import { usePlayerStore } from "@/stores/playerStore";
import { useSettingsStore } from "@/stores/settingsStore";
import { useUIStore } from "@/stores/uiStore";
import {
  bestInstalledModel,
  setVoiceOverActionGuard,
  setVoiceOverResultHandler,
  useRecordingStore,
} from "@/stores/recordingStore";

export type VoicePhase = "idle" | "countdown" | "starting" | "recording" | "stopping" | "review";

export interface VoiceOverDraft {
  id: string;
  projectId: string;
  projectName: string;
  anchor: VoiceOverAnchor;
  /** Rust session of the take; null until the start returns. */
  sessionId: string | null;
  /** Set once the take is finished. */
  path?: string;
  durationSec?: number;
  mode: VoiceOverMode;
  overrideOriginal: boolean;
}

export interface VoicePrefs {
  /** Remembered microphone, by name (indices change when devices come and go). */
  micName?: string;
  /** Defaults for a new take's review. */
  mode: VoiceOverMode;
  overrideOriginal: boolean;
  /** Play the video from the anchor while recording. */
  playWhileRecording: boolean;
  /** Trimmed off the start of every kept take (remaining input latency), ms. */
  latencyMs: number;
}

const STORAGE_KEY = "yusafcut.voiceover.v1";
const DEFAULT_PREFS: VoicePrefs = {
  mode: "overlay",
  overrideOriginal: false,
  playWhileRecording: true,
  latencyMs: 0,
};

interface Stored {
  prefs: VoicePrefs;
  /** Finished takes waiting for review, any project. */
  pending: VoiceOverDraft[];
  /** The take being recorded (recovers a result that lands after a reload). */
  armed: VoiceOverDraft | null;
}

function load(): Stored {
  try {
    const raw = JSON.parse(
      globalThis.localStorage?.getItem(STORAGE_KEY) ?? "null",
    ) as Partial<Stored> | null;
    const prefs = { ...DEFAULT_PREFS, ...(raw?.prefs ?? {}) };
    if (prefs.mode !== "insert") prefs.mode = "overlay";
    if (!Number.isFinite(prefs.latencyMs) || prefs.latencyMs < 0) prefs.latencyMs = 0;
    prefs.latencyMs = Math.min(prefs.latencyMs, 1000);
    const pending = Array.isArray(raw?.pending)
      ? raw!.pending.filter(
          (d) => d && typeof d.path === "string" && typeof d.projectId === "string",
        )
      : [];
    return { prefs, pending, armed: raw?.armed ?? null };
  } catch {
    return { prefs: { ...DEFAULT_PREFS }, pending: [], armed: null };
  }
}

function save(s: Stored) {
  try {
    globalThis.localStorage?.setItem(STORAGE_KEY, JSON.stringify(s));
  } catch {
    /* storage unavailable: drafts live for this session only */
  }
}

function toast(t: { title: string; description?: string; variant?: "destructive" }) {
  useUIStore.getState().pushToast(t);
}

const seek = (time: number, play = false) =>
  window.dispatchEvent(new CustomEvent("yusafcut:seek-output", { detail: { time, play } }));
const pausePlayback = () => window.dispatchEvent(new CustomEvent("yusafcut:pause"));

interface VoiceOverState {
  phase: VoicePhase;
  /** The take being recorded or reviewed. */
  draft: VoiceOverDraft | null;
  pending: VoiceOverDraft[];
  reviewOpen: boolean;
  countdown: number;
  prefs: VoicePrefs;
  devices: RecordingDevices | null;
  /** A keep is in progress (Return pressed twice keeps once). */
  busy: boolean;

  /** The start / stop shortcut: start, stop, cancel the countdown, or reopen a pending review. */
  toggle: () => void;
  start: (
    anchor?: VoiceOverAnchor,
    choices?: Pick<VoiceOverDraft, "mode" | "overrideOriginal">,
  ) => Promise<void>;
  stop: () => Promise<void>;
  /** A finished take with `purpose: "voiceover-take"` (any window, any source of Stop). */
  handleFinished: (result: RecordingResult) => Promise<void>;
  keep: () => Promise<void>;
  discard: () => Promise<void>;
  retake: () => Promise<void>;
  /** Escape: close the review, keep the take pending. */
  closeReview: () => void;
  /** Reopen the review of this project's oldest pending take. */
  openReview: () => boolean;
  setDraft: (patch: Partial<Pick<VoiceOverDraft, "mode" | "overrideOriginal">>) => void;
  setPrefs: (patch: Partial<VoicePrefs>) => void;
  refreshDevices: () => Promise<void>;
}

let generation = 0;
/** Sessions already turned into a draft (duplicate completion events). */
const handled = new Set<string>();
/** Stop pressed while the microphone was still starting. */
let stopRequested = false;

const initial = load();

export const useVoiceOverStore = create<VoiceOverState>()((set, get) => {
  const persist = (patch: Partial<Stored> = {}) => {
    const s = get();
    save({
      prefs: patch.prefs ?? s.prefs,
      pending: patch.pending ?? s.pending,
      armed:
        patch.armed !== undefined
          ? patch.armed
          : s.draft && !s.draft.path && s.phase !== "idle"
            ? s.draft
            : null,
    });
  };
  const reset = () => {
    stopRequested = false;
    set({ phase: "idle", draft: null, reviewOpen: false, countdown: 0, busy: false });
    persist({ armed: null });
  };
  const removePending = (id: string) => {
    const pending = get().pending.filter((d) => d.id !== id);
    set({ pending });
    persist({ pending });
  };

  return {
    phase: "idle",
    draft: null,
    pending: initial.pending,
    reviewOpen: false,
    countdown: 0,
    prefs: initial.prefs,
    devices: null,
    busy: false,

    toggle: () => {
      const { phase } = get();
      if (phase === "idle") {
        if (!get().openReview()) void get().start();
      } else if (phase === "countdown" || phase === "starting" || phase === "recording") {
        void get().stop();
      } else if (phase === "review" && !get().reviewOpen) {
        set({ reviewOpen: true });
      }
      // stopping: a stop is already on its way.
    },

    start: async (anchorIn, choices) => {
      if (get().phase !== "idle") return;
      const project = useProjectStore.getState().project;
      if (project.segments.length === 0) {
        toast({
          title: "Nothing to narrate",
          description: "Add a video before recording a voice-over.",
        });
        return;
      }
      const recorder = useRecordingStore.getState().phase;
      if (recorder === "recording" || recorder === "paused" || recorder === "countdown") {
        toast({ title: "A recording is already running" });
        return;
      }
      // (A take that is still being saved is refused by Rust, which owns the slot.)
      const gen = ++generation;
      stopRequested = false;
      // The anchor is fixed now: nothing that happens during the take moves it.
      const anchor = anchorIn ?? captureAnchor(project, usePlayerStore.getState().currentTime);
      pausePlayback();
      seek(resolveAnchor(project, anchor).outputTime);
      const { prefs } = get();
      const draft: VoiceOverDraft = {
        id: uuidv4(),
        projectId: project.id,
        projectName: project.name,
        anchor,
        sessionId: null,
        mode: choices?.mode ?? prefs.mode,
        overrideOriginal: choices?.overrideOriginal ?? prefs.overrideOriginal,
      };
      const countdownSec = useSettingsStore.getState().recording.countdownSec;
      set({ phase: "countdown", draft, countdown: countdownSec, reviewOpen: false });
      persist({ armed: draft });

      for (let n = countdownSec; n > 0; n--) {
        set({ countdown: n });
        await new Promise((r) => setTimeout(r, 1000));
        if (gen !== generation) return; // cancelled
      }
      if (gen !== generation) return;
      set({ phase: "starting", countdown: 0 });
      try {
        const devices = await listRecordingDevices().catch(() => get().devices);
        if (gen !== generation) return;
        if (devices) set({ devices });
        const audio = devices?.audio ?? [];
        const mic =
          audio.find((d) => d.name === get().prefs.micName) ??
          audio.find((d) => d.index === useRecordingStore.getState().opts.audioIndex) ??
          audio[0];
        if (!mic) throw new Error("No microphone found. Connect one, or allow microphone access.");
        const remembered = get().prefs.micName;
        if (!remembered) get().setPrefs({ micName: mic.name });
        else if (remembered !== mic.name)
          toast({
            title: `"${remembered}" is not connected`,
            description: `Recording with "${mic.name}".`,
          });
        const started = await startRecording({
          mode: "voiceover",
          audioIndex: mic.index,
          purpose: "voiceover-take",
        });
        useRecordingStore.getState().applySnapshot(started);
        if (gen !== generation) {
          // Cancelled while the microphone was starting.
          if (started.sessionId) await cancelRecording(started.sessionId).catch(() => {});
          return;
        }
        const live = { ...get().draft!, sessionId: started.sessionId };
        set({ phase: "recording", draft: live });
        persist({ armed: live });
        if (stopRequested) {
          await get().stop();
          return;
        }
        if (get().prefs.playWhileRecording) {
          seek(resolveAnchor(useProjectStore.getState().project, anchor).outputTime, true);
        }
      } catch (err) {
        if (gen !== generation) return;
        reset();
        toast({
          title: "Voice-over did not start",
          description: String(err),
          variant: "destructive",
        });
      }
    },

    stop: async () => {
      const { phase, draft } = get();
      if (phase === "countdown") {
        generation++;
        reset();
        return;
      }
      if (phase === "starting") {
        stopRequested = true; // honoured as soon as the take is live
        return;
      }
      if (phase !== "recording" || !draft?.sessionId) return;
      // Rust's live session wins over the id we started with (a restart from
      // another window gives the take a new id).
      const live = useRecordingStore.getState().session;
      const sessionId = live.phase !== "idle" && live.sessionId ? live.sessionId : draft.sessionId;
      set({ phase: "stopping", draft: { ...draft, sessionId } });
      pausePlayback();
      try {
        const result = await stopRecording(sessionId);
        await get().handleFinished({ ...result, purpose: "voiceover-take" });
      } catch (err) {
        if (get().phase !== "stopping") return; // the result already arrived
        const now = useRecordingStore.getState().session;
        if (now.phase !== "idle" && now.sessionId && now.sessionId !== sessionId) {
          // Stale id: stop the session that is actually live, once.
          set({ phase: "recording", draft: { ...get().draft!, sessionId: now.sessionId } });
          await get().stop();
          return;
        }
        if (now.phase !== "idle") return; // another Stop is saving it: `record:finished` follows
        // Nothing live and no result: say so instead of sitting on "Saving…".
        reset();
        toast({
          title: "Voice-over was not saved",
          description: String(err),
          variant: "destructive",
        });
      }
    },

    handleFinished: async (result) => {
      if (handled.has(result.sessionId)) return;
      handled.add(result.sessionId);
      // One take is in flight at a time, so the unfinished draft (here, or the
      // one stored before a reload) is this take's, even after a HUD restart
      // gave it a new session id.
      const current = get().draft;
      const stored = load().armed;
      const draft =
        (current && !current.path ? current : null) ?? (stored && !stored.path ? stored : null);
      const ack = () => void ackRecordingResult(result.sessionId).catch(() => {});
      pausePlayback();
      if (!draft) {
        ack();
        toast({
          title: "Voice-over take saved",
          description: `It could not be matched to a playhead position. File: ${result.path}`,
        });
        return;
      }
      if (!(result.durationSec >= MIN_TAKE_SEC)) {
        // State first (synchronously), so the idle snapshot that follows is not
        // mistaken for a lost take.
        reset();
        ack();
        toast({
          title: "Take too short, discarded",
          description: `Only ${result.durationSec.toFixed(1)} s was recorded.`,
        });
        if (!isMediaPathReferenced(result.path))
          await discardRecordingTake(result.path).catch(() => {});
        return;
      }
      const finished: VoiceOverDraft = {
        ...draft,
        sessionId: result.sessionId,
        path: result.path,
        durationSec: result.durationSec,
      };
      const pending = [...get().pending.filter((d) => d.id !== finished.id), finished];
      const here = useProjectStore.getState().project.id === finished.projectId;
      set({
        pending,
        phase: here ? "review" : "idle",
        draft: here ? finished : null,
        reviewOpen: here,
        busy: false,
      });
      persist({ pending, armed: null });
      ack(); // only after the draft is stored
      if (!here)
        toast({
          title: "Voice-over take saved",
          description: `It belongs to "${finished.projectName}". Open that project to review it.`,
        });
    },

    keep: async () => {
      const { draft, busy, prefs } = get();
      if (!draft?.path || busy) return;
      const project = useProjectStore.getState().project;
      if (project.id !== draft.projectId) {
        toast({ title: "This take belongs to another project", description: draft.projectName });
        return;
      }
      set({ busy: true });
      try {
        const media = await importMedia(draft.path);
        const now = useProjectStore.getState().project;
        const resolved = resolveAnchor(now, draft.anchor);
        const id = useProjectStore.getState().addVoiceOverTake(draft.projectId, {
          media,
          at: resolved.outputTime,
          mode: draft.mode,
          overrideOriginal: draft.overrideOriginal,
          ...(prefs.latencyMs > 0 ? { sourceIn: prefs.latencyMs / 1000 } : {}),
        });
        if (!id) {
          set({ busy: false });
          toast({
            title: "The project changed",
            description: "The take is still waiting for review.",
          });
          return;
        }
        removePending(draft.id);
        reset();
        toast({
          title: "Voice-over kept",
          description: resolved.moved
            ? `Its clip was removed, so it was placed at ${formatTimecode(resolved.outputTime)}.`
            : `${draft.mode === "insert" ? "Inserted" : "Mixed over the video"} at ${formatTimecode(resolved.outputTime)}.`,
        });
        if (useSettingsStore.getState().recording.autoTranscribe)
          void transcribeTake(draft.projectId, id, media.id, media.path, media.duration);
      } catch (err) {
        set({ busy: false });
        toast({
          title: "Could not keep the take",
          description: String(err),
          variant: "destructive",
        });
      }
    },

    discard: async () => {
      const { draft } = get();
      if (!draft?.path) return;
      if (!isMediaPathReferenced(draft.path)) {
        await discardRecordingTake(draft.path).catch((err) =>
          toast({ title: "The take file could not be deleted", description: String(err) }),
        );
      }
      removePending(draft.id);
      reset();
      toast({ title: "Take discarded" });
    },

    retake: async () => {
      const { draft } = get();
      if (!draft?.path) return;
      const { anchor, mode, overrideOriginal } = draft;
      await get().discard();
      // Same anchor and placement choices as the take it replaces.
      await get().start(anchor, { mode, overrideOriginal });
    },

    closeReview: () => {
      if (get().phase !== "review") return;
      set({ reviewOpen: false, phase: "idle", draft: null });
    },

    openReview: () => {
      if (get().phase !== "idle") return false;
      const projectId = useProjectStore.getState().project.id;
      const draft = get().pending.find((d) => d.projectId === projectId);
      if (!draft) return false;
      set({ phase: "review", draft, reviewOpen: true });
      return true;
    },

    setDraft: (patch) => {
      const draft = get().draft;
      if (!draft) return;
      const next = { ...draft, ...patch };
      const pending = get().pending.map((d) => (d.id === next.id ? next : d));
      set({ draft: next, pending });
      persist({ pending });
    },

    setPrefs: (patch) => {
      const prefs = { ...get().prefs, ...patch };
      set({ prefs });
      persist({ prefs });
    },

    refreshDevices: async () => {
      try {
        set({ devices: await listRecordingDevices() });
      } catch {
        /* keep the last list */
      }
    },
  };
});

/** Transcribe a kept take in the background; attaches only to its own project. */
async function transcribeTake(
  projectId: string,
  trackId: string,
  mediaId: string,
  mediaPath: string,
  mediaDuration: number,
) {
  const ui = useUIStore.getState();
  ui.setBackgroundTranscription(mediaId, 0);
  try {
    const model = await bestInstalledModel();
    if (!model) return;
    const result = await transcribe({
      mediaId,
      mediaPath,
      engine: "whisper-cpp",
      modelName: model,
      mediaDuration,
    });
    useProjectStore.getState().attachVoiceOverWords(projectId, trackId, mediaId, result.words);
  } catch (err) {
    toast({ title: "Voice-over kept; transcription failed", description: String(err) });
  } finally {
    ui.setBackgroundTranscription(mediaId, null);
  }
}

/** The pending takes of a project (for the Music panel and the start shortcut). */
export function pendingFor(projectId: string): VoiceOverDraft[] {
  return useVoiceOverStore.getState().pending.filter((d) => d.projectId === projectId);
}

/**
 * Editor-window wiring: route voice-over results here, follow project switches
 * and sessions that end without a result. Returns a disposer.
 */
export function initVoiceOver(): () => void {
  setVoiceOverResultHandler((r) => void useVoiceOverStore.getState().handleFinished(r));
  // While a take is live, the recorder's global shortcuts and tray act on it:
  // start/stop stops the take; pause and restart are refused (a paused take
  // would drift from the playing video, a restart would orphan the review).
  setVoiceOverActionGuard((action) => {
    const vo = useVoiceOverStore.getState();
    if (!["countdown", "starting", "recording", "stopping"].includes(vo.phase)) return false;
    if (action === "record") {
      vo.toggle();
      return true;
    }
    if (action === "pause" || action === "rerecord") {
      toast({
        title:
          action === "pause"
            ? "Pause is off during a voice-over"
            : "Restart is off during a voice-over",
        description: "Stop the take, then Retake from the review.",
      });
      return true;
    }
    return false;
  });
  const offProject = useProjectStore.subscribe((state, prev) => {
    if (state.project.id === prev.project.id) return;
    const vo = useVoiceOverStore.getState();
    if (vo.phase === "countdown") void vo.stop();
    if (vo.phase === "review") vo.closeReview();
    if (pendingFor(state.project.id).length > 0)
      toast({
        title: "A voice-over take is waiting for review",
        description: "Press the voice-over shortcut or use the Music panel to review it.",
      });
  });
  // A take that ended with no result (device lost, capture failed) frees the workflow.
  const offRecorder = useRecordingStore.subscribe((state, prev) => {
    const vo = useVoiceOverStore.getState();
    // A take still running from before a reload: let the shortcut stop it.
    if (vo.phase === "idle" && state.session.phase !== "idle" && state.session.sessionId) {
      const { armed } = load();
      if (armed && !armed.path && armed.sessionId === state.session.sessionId)
        useVoiceOverStore.setState({ phase: "recording", draft: armed });
      return;
    }
    if (state.session.phase !== "idle" || prev.session.phase === "idle") return;
    if (vo.phase !== "recording" && vo.phase !== "stopping") return;
    if (
      vo.draft?.sessionId &&
      prev.session.sessionId &&
      vo.draft.sessionId !== prev.session.sessionId
    )
      return;
    useVoiceOverStore.setState({ phase: "idle", draft: null, busy: false });
    save({ ...load(), armed: null });
    toast({
      title: "Voice-over was not saved",
      description: state.session.error ?? "The recording ended without a take.",
      variant: "destructive",
    });
  });
  return () => {
    setVoiceOverResultHandler(null);
    setVoiceOverActionGuard(null);
    offProject();
    offRecorder();
  };
}

/** Test hook: forget handled sessions and the module generation. */
export function resetVoiceOverForTests() {
  handled.clear();
  generation++;
  stopRequested = false;
  useVoiceOverStore.setState({
    phase: "idle",
    draft: null,
    pending: [],
    reviewOpen: false,
    countdown: 0,
    busy: false,
    prefs: { ...DEFAULT_PREFS },
  });
}
