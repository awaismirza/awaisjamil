import { loadRecordingCursorTrack } from "@/lib/cursorImport";
import { nextPaint } from "@/lib/paint";
import { markRecordingStage } from "@/lib/recordingTimeline";
import { deviceChanges, toStartOptions } from "@/lib/recorderSetup";
import { defaultDevicePatch, hasStoredOpts, loadStoredOpts, persistOpts } from "@/lib/recorderOpts";
/**
 * Recorder session state + orchestration.
 *
 * Rust owns the recording session (`recording_session.rs`). This store is a
 * mirror + action client: it applies `RecordingSnapshot`s (newest revision wins)
 * and sends actions that name the session id. It still owns what is genuinely
 * local to the editor window: device discovery, the pre-roll countdown, window
 * minimise while the screen is captured, system-wide shortcuts, and — in the
 * editor window only — the pipeline that imports, transcribes and appends a
 * finished recording to the END of the current EDL (driven by `record:finished`,
 * once per session id, so a second window can never import it twice).
 *
 * Global shortcuts are user-configurable (Settings → Shortcuts) and registered
 * through tauri-plugin-global-shortcut, so they work while other apps have
 * focus. The start/stop shortcut is always live; pause, restart, mark and
 * discard are registered only during a session. The menu-bar item mirrors the
 * session state and offers the same controls.
 */

import { create } from "zustand";
import { emitTo, listen } from "@tauri-apps/api/event";
import {
  ackRecordingResult,
  cancelJob,
  cancelRecording,
  compositeRecordingCamera,
  discardRecordingComposite,
  detectPauses,
  getRecordingSnapshot,
  hashMedia,
  probeMedia,
  listModels,
  listRecordingDevices,
  markRecording,
  onRecordFinished,
  onRecordSnapshot,
  onRecorderBarVisibility,
  openRecorderBar,
  pauseRecording,
  pendingRecordingResults,
  requestRecordingPermissions,
  type PermissionKind,
  restartRecording,
  setControllerHidden,
  resumeRecording,
  startRecording,
  stopRecording,
  onTrayAction,
  transcribe,
  updateTray,
  type PipCorner,
  type PipSize,
  type RecordingDevices,
  type RecordingResult,
  type RecordingSnapshot,
  type RecordMode,
  type RecordOptions,
  type WhisperModel,
} from "@/lib/ipc";
import { totalDuration, type PendingCamera, type SourceMedia } from "@/lib/edl";
import { SHORTCUT_DEFS, type ShortcutAction } from "@/lib/shortcuts";
import { trayModel } from "@/lib/trayModel";
import { idleSnapshot } from "@/lib/snapshotDefaults";
import { snapWordsToSilences } from "@/lib/timestampSnap";
import { writeTranscriptCache } from "@/lib/transcriptCache";
import { hasChecksum } from "@/lib/checksum";
import {
  attachDeferredChecksum,
  clearPendingCamera,
  COMPOSITE_REFUSED,
  compositeMismatch,
  isCompositeRefusal,
  referencedPaths,
  resolveRecordingSource,
  sharesFile,
  swapToComposite,
} from "@/lib/recordingHandoff";
import { useProjectStore } from "@/stores/projectStore";
import { usePlayerStore } from "@/stores/playerStore";
import { useSettingsStore } from "@/stores/settingsStore";
import { useUIStore } from "@/stores/uiStore";

let countdownGeneration = 0;
/** Sessions already handed to the importer in this window. */
const importedSessions = new Set<string>();
/** Best installed Whisper model for auto-transcribing a finished recording. */
const MODEL_PREFERENCE: WhisperModel[] = [
  "large-v3-turbo",
  "large-v3",
  "medium",
  "small",
  "base",
  "tiny",
];

export type RecorderPhase =
  | "idle"
  | "countdown"
  | "recording"
  | "paused"
  | "finalizing"
  | "processing";

/** Editor-local phases layered over Rust's idle: the pre-roll and the import. */
type LocalPhase = "countdown" | "processing" | null;

interface RecordingState {
  phase: RecorderPhase;
  /** The last applied Rust snapshot (the source of truth for everything below). */
  session: RecordingSnapshot;
  /** Rust's session id for the live take (null when idle). */
  sessionId: string | null;
  /** Revision of the last applied snapshot; older ones are ignored. */
  revision: number;
  /** Latest backend problem for this take, from the snapshot. */
  error: string | null;
  local: LocalPhase;
  dialogOpen: boolean;
  /** The floating recorder bar is up (it owns setup; the main window is hidden). */
  barOpen: boolean;
  /** 3 → 2 → 1 during the pre-roll countdown. */
  countdown: number;
  elapsedSec: number;
  /** Elapsed seconds of each "mark a moment" press in the current take. */
  markers: number[];
  devices: RecordingDevices | null;
  devicesError: string | null;
  /** Devices that disappeared since the last refresh (shown in the setup panel). */
  deviceNotices: string[];
  opts: RecordOptions;

  /** Mirror Rust's session. Returns false when the snapshot was stale. */
  applySnapshot: (snapshot: RecordingSnapshot) => boolean;
  finishLocal: (which: Exclude<LocalPhase, null>) => void;
  /** Record entry: the floating bar when enabled, else the setup dialog. */
  openDialog: () => void;
  /** The classic setup dialog, regardless of the style setting. */
  openSetupDialog: () => void;
  closeDialog: () => void;
  setOpts: (patch: Partial<RecordOptions>) => void;
  refreshDevices: () => Promise<void>;
  /** Show the system prompts for these permissions, then re-read the device list. */
  requestPermissions: (kinds: PermissionKind[]) => Promise<void>;
  /** Begin the countdown (length from Settings), then start capture. */
  beginCountdown: () => void;
  /**
   * One-press start with the last-used options: skips the setup dialog. Used by
   * the global shortcut and the menu-bar item when "quick start" is on.
   */
  quickStart: () => Promise<void>;
  /** Drop a marker at the current point of the take (becomes a chapter). */
  mark: () => Promise<void>;
  pause: () => Promise<void>;
  resume: () => Promise<void>;
  /** Discard the current take and immediately start a fresh one. */
  rerecord: () => Promise<void>;
  /** Stop and save; the editor's finished-handler imports the result. */
  stop: () => Promise<void>;
  /** Abort the session and throw the footage away. */
  cancel: () => Promise<void>;
}

export { idleSnapshot };

/** What the UI shows for a Rust phase, given the editor-local layer. */
export function derivePhase(snapshot: RecordingSnapshot, local: LocalPhase): RecorderPhase {
  switch (snapshot.phase) {
    case "starting":
      return "countdown";
    case "recording":
      return "recording";
    case "paused":
    case "interrupted":
      return "paused";
    case "finalizing":
      return "finalizing";
    case "idle":
      return local ?? "idle";
  }
}

function toast(t: { title: string; description?: string; variant?: "destructive" }) {
  useUIStore.getState().pushToast(t);
}

/**
 * Screen capture records the desktop — hide our own window while it runs, unless
 * the user turned that off in Settings.
 */
function capturesScreen(mode: RecordMode) {
  const captures = mode === "screen" || mode === "screen-camera";
  return captures && useSettingsStore.getState().recording.hideWindow;
}

async function minimizeMainWindow() {
  try {
    const { getCurrentWindow } = await import("@tauri-apps/api/window");
    await getCurrentWindow().minimize();
  } catch {
    /* browser preview */
  }
}

async function restoreMainWindow() {
  try {
    const { getCurrentWindow } = await import("@tauri-apps/api/window");
    const win = getCurrentWindow();
    await win.unminimize();
    // The recorder bar hides the main window outright; unminimize alone won't show it.
    await win.show?.();
    await win.setFocus();
  } catch {
    /* browser preview */
  }
}

/** Bring the main window back if something (the recorder bar) left it hidden. */
async function restoreIfHidden() {
  try {
    const { getCurrentWindow } = await import("@tauri-apps/api/window");
    const win = getCurrentWindow();
    if (!(await win.isVisible())) await restoreMainWindow();
  } catch {
    /* browser preview */
  }
}

export const useRecordingStore = create<RecordingState>()((set, get) => ({
  phase: "idle",
  session: idleSnapshot(),
  sessionId: null,
  revision: 0,
  error: null,
  local: null,
  dialogOpen: false,
  barOpen: false,
  countdown: 0,
  elapsedSec: 0,
  markers: [],
  devices: null,
  devicesError: null,
  deviceNotices: [],
  opts: loadStoredOpts(),

  applySnapshot: (snapshot) => {
    if (snapshot.revision <= get().revision) return false;
    // A take that ended (or never began) releases the countdown layer; a live one
    // already replaced it.
    const local = get().local === "countdown" && snapshot.phase !== "idle" ? null : get().local;
    set({
      session: snapshot,
      revision: snapshot.revision,
      sessionId: snapshot.sessionId,
      error: snapshot.error,
      elapsedSec: snapshot.elapsedSec,
      markers: snapshot.markers,
      local,
      phase: derivePhase(snapshot, local),
    });
    return true;
  },

  openDialog: () => {
    if (get().phase !== "idle") return;
    const useBar = isTauri() && useSettingsStore.getState().recording.setupStyle === "bar";
    if (!useBar) {
      get().openSetupDialog();
      return;
    }
    openRecorderBar().catch(() => {
      // The bar could not open (not idle in Rust, window error): use the dialog.
      get().openSetupDialog();
    });
  },

  openSetupDialog: () => {
    if (get().phase !== "idle") return;
    set({ dialogOpen: true });
    void get().refreshDevices();
  },

  closeDialog: () => set({ dialogOpen: false }),

  setOpts: (patch) => {
    const opts = { ...get().opts, ...patch };
    persistOpts(opts);
    set({ opts });
  },

  refreshDevices: async () => {
    try {
      const devices = await listRecordingDevices();
      const { opts } = get();
      // A mic the user switched off stays off (only once options were stored).
      const patch = defaultDevicePatch(opts, devices, {
        micOff: hasStoredOpts() && opts.audioIndex === undefined,
      });
      const deviceNotices = deviceChanges(opts, get().devices, devices);
      set({ devices, devicesError: null, deviceNotices, opts: { ...opts, ...patch } });
    } catch (err) {
      set({ devices: null, devicesError: String(err) });
    }
  },

  requestPermissions: async (kinds) => {
    try {
      await requestRecordingPermissions(kinds);
    } catch (err) {
      toast({
        title: "Permission request failed",
        description: String(err),
        variant: "destructive",
      });
    }
    await get().refreshDevices();
  },

  beginCountdown: () => {
    if (get().phase !== "idle") return;
    const generation = ++countdownGeneration;
    const { countdownSec } = useSettingsStore.getState().recording;
    set({ local: "countdown", phase: "countdown", countdown: countdownSec, dialogOpen: false });

    const startCapture = () => {
      set({ countdown: 0 });
      void (async () => {
        // Paint away countdown controls before capture can receive a frame.
        await nextPaint();
        await nextPaint();
        if (generation !== countdownGeneration || get().phase !== "countdown") return;
        if (capturesScreen(get().opts.mode)) {
          await minimizeMainWindow();
          // Give the minimise animation a beat so it isn't in the capture.
          await new Promise((r) => setTimeout(r, 350));
        }
        if (generation !== countdownGeneration || get().phase !== "countdown") return;
        try {
          const started = await startRecording(toStartOptions(get().opts, get().devices));
          get().applySnapshot(started);
          if (generation !== countdownGeneration && started.sessionId) {
            // Cancelled while the start request was in flight and Rust had not
            // published the session yet: cancel it by id now that it is known.
            await cancelRecording(started.sessionId).catch(() => {});
            await restoreMainWindow();
          }
        } catch (err) {
          const message = String(err);
          const cancelled = generation !== countdownGeneration || message.includes("cancelled");
          get().finishLocal("countdown");
          await restoreMainWindow();
          if (!cancelled)
            toast({
              title: "Recording failed to start",
              description: message,
              variant: "destructive",
            });
        }
      })();
    };

    if (countdownSec === 0) {
      startCapture();
      return;
    }

    const tick = () => {
      const { phase, countdown } = get();
      if (phase !== "countdown" || generation !== countdownGeneration) return; // cancelled
      if (countdown > 1) {
        set({ countdown: countdown - 1 });
        window.setTimeout(tick, 1000);
        return;
      }
      startCapture();
    };
    window.setTimeout(tick, 1000);
  },

  finishLocal: (which) => {
    if (get().local !== which) return;
    set({ local: null, countdown: 0, phase: derivePhase(get().session, null) });
  },

  quickStart: async () => {
    if (get().phase !== "idle") return;
    if (!get().devices) await get().refreshDevices();
    if (get().phase !== "idle") return;
    get().beginCountdown();
  },

  mark: async () => {
    const { phase, sessionId, markers } = get();
    if (phase !== "recording" || !sessionId) return;
    try {
      const at = await markRecording(sessionId);
      toast({
        title: "Moment marked",
        description: `Marker ${markers.length + 1} at ${Math.round(at)} s.`,
      });
    } catch {
      /* the take moved on (paused, stopped); nothing to mark */
    }
  },

  pause: async () => {
    const { phase, sessionId } = get();
    if (phase !== "recording" || !sessionId) return;
    try {
      await pauseRecording(sessionId);
      if (capturesScreen(get().opts.mode)) await restoreMainWindow();
    } catch (err) {
      toast({ title: "Pause failed", description: String(err), variant: "destructive" });
    }
  },

  resume: async () => {
    const { phase, sessionId } = get();
    if (phase !== "paused" || !sessionId) return;
    try {
      if (capturesScreen(get().opts.mode)) {
        await minimizeMainWindow();
        await new Promise((r) => setTimeout(r, 350));
      }
      await resumeRecording(sessionId);
    } catch (err) {
      toast({ title: "Resume failed", description: String(err), variant: "destructive" });
    }
  },

  rerecord: async () => {
    const { phase, sessionId } = get();
    if ((phase !== "recording" && phase !== "paused") || !sessionId) return;
    try {
      get().applySnapshot(await restartRecording(sessionId));
      toast({ title: "Re-recording", description: "Previous take discarded." });
    } catch (err) {
      await restoreMainWindow();
      toast({ title: "Re-record failed", description: String(err), variant: "destructive" });
    }
  },

  stop: async () => {
    const { phase, sessionId } = get();
    if ((phase !== "recording" && phase !== "paused") || !sessionId) return;
    markRecordingStage(sessionId, "stopRequested");
    try {
      // The result also arrives as `record:finished`; the importer owns it.
      await stopRecording(sessionId);
    } catch (err) {
      toast({ title: "Recording failed", description: String(err), variant: "destructive" });
    } finally {
      await restoreMainWindow();
    }
  },

  cancel: async () => {
    const { phase, sessionId } = get();
    if (phase === "countdown") {
      ++countdownGeneration;
      if (sessionId) {
        // Capture is starting: Rust interrupts it instead of waiting it out.
        await cancelRecording(sessionId).catch(() => {});
      } else {
        // Start not yet published; startCapture cancels it by id on return.
        get().finishLocal("countdown");
      }
      await restoreMainWindow();
      return;
    }
    if ((phase !== "recording" && phase !== "paused") || !sessionId) return;
    try {
      await cancelRecording(sessionId);
    } catch {
      /* already gone */
    }
    await restoreMainWindow();
    toast({ title: "Recording discarded" });
  },
}));

// ---------------------------------------------------------------------------
// Auto-append pipeline
// ---------------------------------------------------------------------------

/** Publish playable media before waiting for Whisper. Transcription attaches to
 * the still-current document and its surviving source ranges, never a snapshot
 * that could overwrite edits made while recognition ran.
 *
 * The take is probed only (no full-file read); its SHA-256 is computed in the
 * background and attached afterwards (`attachChecksumLater`). Resolves with the
 * inserted media and its project, or undefined when nothing was inserted. */
export async function appendRecordingToProject(
  path: string,
  markers: readonly number[] = [],
  eventsPath?: string,
  sessionId = "",
  /** Screen + camera take: saved on the entry until its composite is swapped in. */
  pendingCamera?: PendingCamera,
): Promise<{ media: SourceMedia; projectId: string } | undefined> {
  const projectId = useProjectStore.getState().project.id;
  const ui = useUIStore.getState();
  ui.setMediaLoading(true);
  let media: SourceMedia;
  markRecordingStage(sessionId, "importStarted");
  try {
    media = await probeMedia(path);
    if (pendingCamera) media = { ...media, pendingCamera };
    markRecordingStage(sessionId, "importProbed");
  } catch (err) {
    toast({
      title: "Failed to import recording",
      description: `${String(err)}. Recording saved at ${path}`,
      variant: "destructive",
    });
    return;
  } finally {
    ui.setMediaLoading(false);
  }
  if (useProjectStore.getState().project.id !== projectId) {
    toast({
      title: "Recording saved",
      description: `Project changed while importing. Import ${path} to add the take.`,
    });
    return;
  }
  const appendAt = totalDuration(useProjectStore.getState().project);
  const { autoTranscribe, markersBecomeChapters } = useSettingsStore.getState().recording;
  useProjectStore.getState().addMediaWithTranscript(media, []);
  markRecordingStage(sessionId, "inserted");
  markFirstFrame(sessionId);
  markPlayable(sessionId, media.path);
  void attachChecksumLater(media.id, media.path, projectId, sessionId);
  if (markersBecomeChapters)
    markers.forEach((t, i) =>
      useProjectStore
        .getState()
        .addChapter(appendAt + Math.min(media.duration, t), `Moment ${i + 1}`),
    );
  usePlayerStore.getState().clearTimelineRange();
  usePlayerStore.getState().setSelectedWordIds(new Set());
  usePlayerStore.getState().setPlaying(false);
  window.dispatchEvent(new CustomEvent("yusafcut:seek-output", { detail: { time: appendAt } }));
  toast({
    title: "Recording ready to play",
    description: autoTranscribe
      ? "Transcript will appear when background transcription finishes."
      : "Auto-transcribe is off. Add text from the Transcribe panel.",
  });
  if (eventsPath) void attachRecordingCursor(media, projectId, eventsPath);
  if (autoTranscribe) void transcribeRecording(media, projectId);
  return { media, projectId };
}

/**
 * Hash the take in the background and attach the checksum to the entry that
 * still points at `path` in project `projectId` (no undo step, project stays
 * clean). Until then the entry has no checksum: masks match it by path, the
 * transcript cache skips it and relink falls back to its structure check. A
 * failure leaves it without one; `backfillChecksums` retries on the next open.
 */
async function attachChecksumLater(
  mediaId: string,
  path: string,
  projectId: string,
  sessionId: string,
) {
  let sha256: string;
  try {
    sha256 = await hashMedia(path);
  } catch {
    return;
  }
  if (!attachDeferredChecksum(projectId, mediaId, path, sha256)) return;
  markRecordingStage(sessionId, "checksumAttached");
  // Words that arrived before the checksum could not be cached yet.
  const project = useProjectStore.getState().project;
  const words = project.originalTranscripts?.[mediaId];
  const current = project.media[mediaId];
  if (words && current && hasChecksum(current)) writeTranscriptCache(current, words);
}

/** Resolves true once playback is paused, false if the project changed first. */
function whenPaused(projectId: string): Promise<boolean> {
  if (useProjectStore.getState().project.id !== projectId) return Promise.resolve(false);
  if (!usePlayerStore.getState().playing) return Promise.resolve(true);
  return new Promise((resolve) => {
    const stop = (value: boolean) => {
      offPlayer();
      offProject();
      resolve(value);
    };
    const offPlayer = usePlayerStore.subscribe((s) => {
      if (!s.playing) stop(true);
    });
    const offProject = useProjectStore.subscribe((s) => {
      if (s.project.id !== projectId) stop(false);
    });
  });
}

const PIP_CORNERS: readonly PipCorner[] = ["top-left", "top-right", "bottom-left", "bottom-right"];
const PIP_SIZES: readonly PipSize[] = ["small", "medium", "large"];
/** `${projectId}:${mediaId}` of composites running in this window. */
const compositesInFlight = new Set<string>();

/**
 * Screen + camera take: the inserted clip is the screen picture and carries a
 * `pendingCamera` marker (saved with the project). Produce the picture-in-
 * picture file in a low-priority job and point the clip at it once it is
 * ready. Guards: same project (the job is cancelled on a switch), entry still
 * at the screen file in the PRESENT project and not shared with another entry,
 * the same picture length / size / sound (checked in Rust on the video stream,
 * and here), and playback paused (the `<video>` source changes). Never an undo
 * step.
 *
 * Outcomes:
 * - swapped: marker removed, "Camera added";
 * - definite refusal (Rust `COMPOSITE_REFUSED`, size / sound / length
 *   mismatch, a screen file shared with another entry): marker cleared, the
 *   clip stays screen-only, a toast names the camera file;
 * - interrupted by a project switch: the job is cancelled and the marker kept;
 *   if the same project is open again by the time the run settles (A -> B -> A)
 *   the composite restarts at once, otherwise it resumes on the next open;
 * - transient (cancelled from the Jobs list, ffmpeg killed, ffprobe or I/O
 *   failure, the insertion undone): marker kept, retried when the project is
 *   opened again.
 * A composite that was produced but not swapped in is deleted.
 */
export async function runCameraComposite(projectId: string, mediaId: string, sessionId = "") {
  const key = `${projectId}:${mediaId}`;
  const entry = useProjectStore.getState().project.media[mediaId];
  const pending = entry?.pendingCamera;
  if (useProjectStore.getState().project.id !== projectId || !entry || !pending) return;
  if (compositesInFlight.has(key)) return;
  compositesInFlight.add(key);
  const cameraFile = `${pending.tracksDir}/camera.mp4`;
  const giveUp = (why: string) => {
    clearPendingCamera(projectId, mediaId);
    toast({
      title: "Camera kept as a separate file",
      description: `${why} The clip plays without the camera; the camera recording is at ${cameraFile}.`,
    });
  };
  const retryLater = (why: string) =>
    toast({
      title: "Camera not added yet",
      description: `${why} It is tried again when this project is opened again (if it was saved).`,
    });
  let jobId: string | null = null;
  let switched = false;
  let produced: string | null = null;
  let swapped = false;
  const offProject = useProjectStore.subscribe((s) => {
    if (s.project.id === projectId || switched) return;
    switched = true;
    if (jobId) void cancelJob(jobId).catch(() => {});
  });
  try {
    produced = await compositeRecordingCamera(
      {
        tracksDir: pending.tracksDir,
        screenPath: entry.path,
        pipCorner: PIP_CORNERS.find((c) => c === pending.pipCorner),
        pipSize: PIP_SIZES.find((c) => c === pending.pipSize),
        keep: referencedPaths(projectId),
      },
      (id) => {
        jobId = id;
        if (switched) void cancelJob(id).catch(() => {});
      },
    );
    if (switched) return;
    const composite = await probeMedia(produced);
    const mismatch = compositeMismatch(entry, composite);
    if (mismatch) return giveUp(`The camera version does not line up (${mismatch}).`);
    if (!(await whenPaused(projectId))) return;
    if (sharesFile(projectId, mediaId, entry.path))
      return giveUp("Another clip uses the same screen file, so it was left unchanged.");
    if (!swapToComposite(projectId, mediaId, entry.path, composite))
      return retryLater("The clip was removed, undone or relinked before the camera was added.");
    swapped = true;
    markRecordingStage(sessionId, "cameraComposited");
    toast({ title: "Camera added to the recording" });
    void attachChecksumLater(mediaId, composite.path, projectId, "");
  } catch (err) {
    if (switched) return;
    if (isCompositeRefusal(err))
      giveUp(`The camera could not be added (${String(err).replace(COMPOSITE_REFUSED, "")}).`);
    else retryLater(`The camera could not be added this time (${String(err)}).`);
  } finally {
    offProject();
    compositesInFlight.delete(key);
    if (produced && !swapped) void discardRecordingComposite(produced).catch(() => {});
    if (switched && !swapped) {
      const now = useProjectStore.getState().project;
      // A -> B -> A: the project came back while this run was settling.
      if (now.id === projectId && now.media[mediaId]?.pendingCamera)
        void runCameraComposite(projectId, mediaId, sessionId);
      else retryLater("The project changed first.");
    }
  }
}

/** Start the pending camera composites of the open project (after it was opened). */
export function resumePendingCameras() {
  const project = useProjectStore.getState().project;
  for (const m of Object.values(project.media))
    if (m.pendingCamera) void runCameraComposite(project.id, m.id);
}

/**
 * Diagnostic only: stamp `playable` once the preview `<video>` has loaded THIS
 * file (its `currentSrc` ends with the path) far enough to play from the
 * playhead (`readyState >= HAVE_FUTURE_DATA`, which includes audio). A proxy
 * source never matches, so the mark is then simply absent.
 */
function markPlayable(sessionId: string, path: string) {
  if (!sessionId) return;
  let tries = 0;
  const check = () => {
    const v = document.querySelector("video");
    let src = "";
    try {
      src = v ? decodeURIComponent(v.currentSrc) : "";
    } catch {
      src = "";
    }
    if (v && src.endsWith(path) && v.readyState >= 3) {
      markRecordingStage(sessionId, "playable");
    } else if (++tries < 300) {
      globalThis.setTimeout(check, 50);
    }
  };
  check();
}
/** Diagnostic only: stamp the next presented frame of the preview `<video>`. */
function markFirstFrame(sessionId: string) {
  if (!sessionId) return;
  let tries = 0;
  const arm = () => {
    const v = document.querySelector("video");
    if (v && typeof v.requestVideoFrameCallback === "function") {
      v.requestVideoFrameCallback(() => markRecordingStage(sessionId, "firstFrame"));
    } else if (++tries < 20) {
      globalThis.setTimeout(arm, 100);
    }
  };
  arm();
}
async function attachRecordingCursor(media: SourceMedia, projectId: string, path: string) {
  const abort = new globalThis.AbortController();
  const unsubscribe = useProjectStore.subscribe((state) => {
    if (state.project.id !== projectId) abort.abort();
  });
  try {
    const track = await loadRecordingCursorTrack(path, abort.signal);
    abort.signal.throwIfAborted();
    // The entry may have gained its checksum or camera composite meanwhile.
    useProjectStore
      .getState()
      .attachCursorTrack(projectId, resolveRecordingSource(projectId, media), track);
  } catch (error) {
    if (!abort.signal.aborted)
      toast({
        title: "Recording added without cursor data",
        description: `The take is playable. Cursor data could not be loaded: ${String(error)}`,
      });
  } finally {
    unsubscribe();
  }
}
/** Best installed Whisper model, or undefined when none is installed. */
export async function bestInstalledModel(): Promise<WhisperModel | undefined> {
  return pickModel(await listModels());
}
const pickModel = (models: Awaited<ReturnType<typeof listModels>>) =>
  MODEL_PREFERENCE.find((name) => models.some((m) => m.name === name && m.installed));

async function transcribeRecording(media: SourceMedia, projectId: string) {
  const ui = useUIStore.getState();
  ui.setBackgroundTranscription(media.id, 0);
  try {
    const model = pickModel(await listModels());
    if (!model) {
      toast({
        title: "Recording added without text",
        description: "No Whisper model installed. Use the Transcribe panel to add text.",
      });
      return;
    }
    const result = await transcribe({
      mediaId: media.id,
      mediaPath: media.path,
      engine: "whisper-cpp",
      modelName: model,
      mediaDuration: media.duration,
    });
    let words = result.words;
    try {
      const silences = await detectPauses({
        mediaPath: media.path,
        noiseThreshold: -35,
        minDuration: 0.5,
      });
      words = snapWordsToSilences(words, silences);
    } catch {
      /* optional refinement */
    }
    // The entry may have gained its checksum or camera composite meanwhile; the
    // cache is keyed by checksum, so it is written only once one is known.
    const source = resolveRecordingSource(projectId, media);
    writeTranscriptCache(source, words);
    if (useProjectStore.getState().attachTranscript(projectId, media.id, words, source))
      toast({
        title: "Recording transcript ready",
        description: `${words.length} words added. Your timeline edits are preserved.`,
      });
  } catch (err) {
    toast({
      title: "Recording kept; transcription failed",
      description: String(err),
      variant: "destructive",
    });
  } finally {
    ui.setBackgroundTranscription(media.id, null);
  }
}

// ---------------------------------------------------------------------------
// Global shortcuts, menu-bar item and event stream
// ---------------------------------------------------------------------------

type ShortcutEvent = { state: "Pressed" | "Released" };

async function shortcutApi() {
  return import("@tauri-apps/plugin-global-shortcut");
}

const isTauri = () => "__TAURI_INTERNALS__" in window;

/** Run a recorder action, whether it came from a shortcut, the tray or the HUD. */
export function runRecorderAction(action: ShortcutAction) {
  // A voice-over take owns the session while it is live (see setVoiceOverActionGuard).
  if (voiceOverActionGuard?.(action)) return;
  const store = useRecordingStore.getState();
  switch (action) {
    case "record":
      if (store.phase === "recording" || store.phase === "paused") {
        void store.stop();
      } else if (store.phase === "countdown") {
        void store.cancel();
      } else if (store.phase === "idle") {
        if (store.barOpen) void emitTo("recorder-bar", "recorder-bar:record", null).catch(() => {});
        else if (store.dialogOpen) store.beginCountdown();
        else if (useSettingsStore.getState().recording.quickStart) void store.quickStart();
        else store.openDialog();
      }
      return;
    case "pause":
      if (store.phase === "recording") void store.pause();
      else if (store.phase === "paused") void store.resume();
      return;
    case "rerecord":
      if (
        (store.phase === "recording" || store.phase === "paused") &&
        !window.confirm("Discard this take and start again?")
      )
        return;
      void store.rerecord();
      return;
    case "mark":
      void store.mark();
      return;
    case "cancel":
      if (
        (store.phase === "recording" || store.phase === "paused") &&
        !window.confirm("Discard this recording? The take will be deleted.")
      )
        return;
      void store.cancel();
      return;
  }
}

/** Accelerators currently registered with the OS, by action. */
const registered = new Map<ShortcutAction, string>();
let syncChain: Promise<void> = Promise.resolve();

/**
 * Make the OS registrations match the settings and the session: the start/stop
 * shortcut always, the rest only while recording. Safe to call any time; calls
 * are serialised so a fast phase change can't interleave register/unregister.
 */
export function syncShortcuts(): Promise<void> {
  syncChain = syncChain.then(doSync).catch(() => {});
  return syncChain;
}

async function doSync() {
  if (!isTauri()) return;
  const { register, unregister } = await shortcutApi();
  const { phase } = useRecordingStore.getState();
  const inSession = phase === "recording" || phase === "paused";
  const shortcuts = useSettingsStore.getState().shortcuts;

  const desired = new Map<ShortcutAction, string>();
  for (const def of SHORTCUT_DEFS) {
    if (def.scope === "always" || inSession) desired.set(def.action, shortcuts[def.action]);
  }

  for (const [action, accelerator] of [...registered]) {
    if (desired.get(action) === accelerator) continue;
    await unregister(accelerator).catch(() => {});
    registered.delete(action);
  }
  for (const [action, accelerator] of desired) {
    if (registered.get(action) === accelerator) continue;
    try {
      await register(accelerator, (event: ShortcutEvent) => {
        if (event.state === "Pressed") runRecorderAction(action);
      });
      registered.set(action, accelerator);
    } catch {
      /* another app holds this combination — the HUD and menu-bar item still work */
    }
  }
}

async function unregisterAll() {
  if (!isTauri()) return;
  const { unregister } = await shortcutApi();
  for (const accelerator of registered.values()) await unregister(accelerator).catch(() => {});
  registered.clear();
}

/** Push the current phase, timer and shortcut hints to the menu-bar item. */
function syncTray() {
  if (!isTauri()) return;
  const { phase, elapsedSec, countdown } = useRecordingStore.getState();
  const shortcuts = useSettingsStore.getState().shortcuts;
  const { session } = useRecordingStore.getState();
  const screenTake = session.mode === "screen" || session.mode === "screen-camera";
  void updateTray(
    trayModel({
      phase,
      elapsedSec,
      countdown,
      shortcuts,
      keyNames: session.keyNames,
      controller: {
        available: screenTake && session.backend === "native",
        hidden: session.controllerHidden,
      },
    }),
  ).catch(() => {});
}

/**
 * Voice-over takes (`purpose: "voiceover-take"`) never go through the timeline
 * append below: the voice-over store registers its review handler here (a hook
 * rather than an import, to keep the two stores free of an import cycle).
 */
let voiceOverResultHandler: ((result: RecordingResult) => void) | null = null;
/** Returns true when it handled (or refused) a recorder action during a voice-over take. */
let voiceOverActionGuard: ((action: ShortcutAction) => boolean) | null = null;
export function setVoiceOverActionGuard(guard: ((action: ShortcutAction) => boolean) | null) {
  voiceOverActionGuard = guard;
}
export function setVoiceOverResultHandler(handler: ((result: RecordingResult) => void) | null) {
  voiceOverResultHandler = handler;
}

/** Import one finished take, once, then acknowledge it to Rust. Editor window only. */
export async function importFinishedRecording(result: RecordingResult) {
  if (result.purpose === "voiceover-take") {
    // Not acknowledged here: the handler acks once the draft is stored. With no
    // handler (should not happen) the result stays pending in Rust, never appended.
    voiceOverResultHandler?.(result);
    return;
  }
  if (importedSessions.has(result.sessionId)) return;
  importedSessions.add(result.sessionId);
  markRecordingStage(result.sessionId, "finishedReceived");
  useRecordingStore.setState((s) => ({
    local: "processing",
    phase: derivePhase(s.session, "processing"),
  }));
  try {
    if (result.warning)
      toast({ title: "Recording saved with a problem", description: result.warning });
    const added = await appendRecordingToProject(
      result.path,
      result.markers,
      result.eventsPath,
      result.sessionId,
      result.camera && result.tracksDir
        ? {
            tracksDir: result.tracksDir,
            pipCorner: result.camera.pipCorner,
            pipSize: result.camera.pipSize,
          }
        : undefined,
    );
    if (result.camera) {
      if (added) void runCameraComposite(added.projectId, added.media.id, result.sessionId);
      else
        toast({
          title: "Camera recording kept",
          description: `The camera of this take is a separate file: ${result.camera.path}`,
        });
    }
  } finally {
    useRecordingStore.getState().finishLocal("processing");
    void ackRecordingResult(result.sessionId).catch(() => {});
  }
}

let lastReportedError: string | null = null;
let lastAutoStopped: string | null = null;

/**
 * Apply an authoritative snapshot and run the editor-only reactions: tell the
 * user about backend problems and, if the capture source died mid-take, stop so
 * everything already written is kept instead of leaving a half-alive session.
 */
export function handleSnapshot(snapshot: RecordingSnapshot) {
  const before = useRecordingStore.getState().session;
  const applied = useRecordingStore.getState().applySnapshot(snapshot);
  if (!applied) return false;
  // A take ended from somewhere else (the desktop controller, the menu bar):
  // bring the editor back that was minimised out of the screen capture.
  if (
    before.phase !== "idle" &&
    snapshot.phase === "idle" &&
    capturesScreen(before.mode ?? "voiceover")
  )
    void restoreMainWindow();
  else if (before.phase !== "idle" && snapshot.phase === "idle") void restoreIfHidden();
  if (snapshot.error && snapshot.error !== lastReportedError) {
    lastReportedError = snapshot.error;
    toast({ title: "Recording error", description: snapshot.error, variant: "destructive" });
  } else if (!snapshot.error) {
    lastReportedError = null;
  }
  if (
    snapshot.phase === "interrupted" &&
    snapshot.sessionId &&
    snapshot.sessionId !== lastAutoStopped
  ) {
    lastAutoStopped = snapshot.sessionId;
    void useRecordingStore.getState().stop();
  }
  return true;
}

/**
 * One-time recorder wiring for the EDITOR window: shortcuts, the menu-bar item,
 * the snapshot mirror and the import pipeline. Other windows (the controller)
 * must not call this — they read snapshots and send actions only.
 */
export async function initRecorder(): Promise<() => void> {
  if (!isTauri()) return () => {};

  const disposers: Array<() => void> = [];

  await syncShortcuts();
  syncTray();
  disposers.push(() => void unregisterAll());

  // Re-register when the user rebinds a shortcut, or the session starts / ends.
  disposers.push(
    useSettingsStore.subscribe(() => {
      void syncShortcuts();
      syncTray();
    }),
  );
  disposers.push(
    useRecordingStore.subscribe((state, prev) => {
      if (state.phase !== prev.phase) void syncShortcuts();
      if (
        state.phase !== prev.phase ||
        state.countdown !== prev.countdown ||
        state.session.controllerHidden !== prev.session.controllerHidden ||
        state.session.keyNames !== prev.session.keyNames ||
        state.session.backend !== prev.session.backend ||
        Math.floor(state.elapsedSec) !== Math.floor(prev.elapsedSec)
      ) {
        syncTray();
      }
    }),
  );

  try {
    const unTray = await onTrayAction((id) => {
      if (id === "show") {
        void restoreMainWindow();
        return;
      }
      if (id === "controller") {
        void setControllerHidden(!useRecordingStore.getState().session.controllerHidden).catch(
          () => {},
        );
        return;
      }
      if (SHORTCUT_DEFS.some((d) => d.action === id)) runRecorderAction(id as ShortcutAction);
    });
    disposers.push(unTray);
  } catch {
    /* no menu-bar item on this platform */
  }

  // The floating bar: its visibility, option edits and "More options…".
  try {
    disposers.push(
      await onRecorderBarVisibility((visible) => useRecordingStore.setState({ barOpen: visible })),
    );
    // The bar already persisted these; apply without writing them back.
    const unOpts = await listen<RecordOptions>("recorder-bar:opts", (e) =>
      useRecordingStore.setState({ opts: e.payload }),
    );
    disposers.push(unOpts);
    const unDialog = await listen("recorder:open-dialog", () =>
      useRecordingStore.getState().openSetupDialog(),
    );
    disposers.push(unDialog);
  } catch {
    /* events unavailable */
  }

  // Subscribe first, then fetch: an event that lands in between is newer than
  // the fetch or equal to it, and `applySnapshot` keeps the highest revision.
  disposers.push(await onRecordSnapshot(handleSnapshot));
  disposers.push(await onRecordFinished((result) => void importFinishedRecording(result)));
  // Screen + camera takes saved before their camera composite was swapped in.
  resumePendingCameras();
  disposers.push(
    useProjectStore.subscribe((state, prev) => {
      if (state.project.id !== prev.project.id) resumePendingCameras();
    }),
  );
  try {
    handleSnapshot(await getRecordingSnapshot());
    // A take that finished while this window was reloading or not listening.
    for (const result of await pendingRecordingResults()) void importFinishedRecording(result);
  } catch {
    /* backend not ready yet; the next snapshot event brings the state */
  }

  return () => disposers.forEach((d) => d());
}
