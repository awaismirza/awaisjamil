/**
 * Persisted app settings: recorder shortcuts and recording defaults.
 * Stored in localStorage; every load goes through `sanitizeSettings`.
 */

import { create } from "zustand";
import {
  defaultSettings,
  sanitizeSettings,
  type RecordingSettings,
  type Settings,
} from "@/lib/settings";
import {
  defaultEditorShortcuts,
  EDITOR_SHORTCUT_DEFS,
  editorDef,
  editorDefsIn,
  editorProblemMessage,
  scopeOf,
  editorShortcutProblem,
  findEditorConflict,
  type EditorAction,
} from "@/lib/editorShortcuts";
import {
  defaultShortcuts,
  findShortcutConflict,
  normalizeAccelerator,
  problemMessage,
  SHORTCUT_DEFS,
  shortcutProblem,
  type ShortcutAction,
} from "@/lib/shortcuts";

const STORAGE_KEY = "yusafcut.settings";

function load(): Settings {
  try {
    const raw = window.localStorage?.getItem(STORAGE_KEY);
    return sanitizeSettings(raw ? JSON.parse(raw) : null);
  } catch {
    return defaultSettings();
  }
}

function persist(settings: Settings) {
  try {
    window.localStorage?.setItem(STORAGE_KEY, JSON.stringify(settings));
  } catch {
    /* storage unavailable — settings just won't survive a restart */
  }
}

export type SetShortcutResult = { ok: true } | { ok: false; reason: string };

interface SettingsState extends Settings {
  /** Bind an action to a new accelerator; refuses invalid, reserved and conflicting ones. */
  setShortcut: (action: ShortcutAction, accelerator: string) => SetShortcutResult;
  resetShortcut: (action: ShortcutAction) => void;
  resetShortcuts: () => void;
  setEditorShortcut: (action: EditorAction, accelerator: string) => SetShortcutResult;
  resetEditorShortcut: (action: EditorAction) => void;
  resetEditorShortcuts: () => void;
  setRecording: (patch: Partial<RecordingSettings>) => void;
}

export const useSettingsStore = create<SettingsState>()((set, get) => {
  const update = (patch: Partial<Settings>) => {
    const next: Settings = {
      shortcuts: patch.shortcuts ?? get().shortcuts,
      editorShortcuts: patch.editorShortcuts ?? get().editorShortcuts,
      recording: patch.recording ?? get().recording,
    };
    persist(next);
    set(next);
  };

  return {
    ...load(),

    setShortcut: (action, accelerator) => {
      const problem = shortcutProblem(accelerator);
      if (problem) return { ok: false, reason: problemMessage(problem) };
      const canon = normalizeAccelerator(accelerator)!;
      const conflict = findShortcutConflict(get().shortcuts, action, canon);
      if (conflict) {
        const label = SHORTCUT_DEFS.find((d) => d.action === conflict)?.label ?? conflict;
        return { ok: false, reason: `Already used by "${label}".` };
      }
      // A global shortcut that equals an editor hotkey would fire both.
      const editorHit = EDITOR_SHORTCUT_DEFS.find(
        (d) => normalizeAccelerator(get().editorShortcuts[d.action]) === canon,
      );
      if (editorHit) return { ok: false, reason: `Already used by "${editorHit.label}".` };
      update({ shortcuts: { ...get().shortcuts, [action]: canon } });
      return { ok: true };
    },

    setEditorShortcut: (action, accelerator) => {
      const problem = editorShortcutProblem(accelerator);
      if (problem) return { ok: false, reason: editorProblemMessage(problem) };
      const canon = normalizeAccelerator(accelerator)!;
      const s = get();
      const conflict = findEditorConflict(
        s.editorShortcuts,
        s.shortcuts,
        SHORTCUT_DEFS,
        action,
        canon,
      );
      if (conflict) return { ok: false, reason: `Already used by "${conflict}".` };
      update({ editorShortcuts: { ...s.editorShortcuts, [action]: canon } });
      return { ok: true };
    },

    resetEditorShortcut: (action) => {
      const def = defaultEditorShortcuts()[action];
      const editorShortcuts = { ...get().editorShortcuts };
      // If the default is held by another editor action, hand that one its default too.
      for (const d of editorDefsIn(scopeOf(editorDef(action)))) {
        if (d.action !== action && normalizeAccelerator(editorShortcuts[d.action]) === def) {
          editorShortcuts[d.action] = d.default;
        }
      }
      editorShortcuts[action] = def;
      update({ editorShortcuts });
    },

    resetEditorShortcuts: () => update({ editorShortcuts: defaultEditorShortcuts() }),

    resetShortcut: (action) => {
      const def = defaultShortcuts()[action];
      const conflict = findShortcutConflict(get().shortcuts, action, def);
      const shortcuts = { ...get().shortcuts };
      // If the default is held by another action, hand it back too so none collide.
      if (conflict) shortcuts[conflict] = defaultShortcuts()[conflict];
      shortcuts[action] = def;
      update({ shortcuts });
    },

    resetShortcuts: () => update({ shortcuts: defaultShortcuts() }),

    setRecording: (patch) => update({ recording: { ...get().recording, ...patch } }),
  };
});

/**
 * The recorder bar runs in its own webview and writes settings (countdown,
 * transcribe) to the same localStorage. A `storage` event only fires in the
 * OTHER windows, so reload here to keep this copy from going stale and
 * overwriting the bar's changes on the next write.
 */
if (typeof window !== "undefined" && typeof window.addEventListener === "function") {
  window.addEventListener("storage", (e) => {
    if (e.key !== null && e.key !== STORAGE_KEY) return;
    useSettingsStore.setState(load());
  });
}
