import { create } from "zustand";

/** Media of the open project whose files were not found. Not saved, not undoable. */
interface RelinkState {
  projectId: string | null;
  missingIds: string[];
  /** True once the user chose "Skip for now" for this set. */
  dismissed: boolean;
  setMissing: (projectId: string, ids: string[]) => void;
  resolve: (mediaId: string) => void;
  dismiss: () => void;
  clear: () => void;
}

export const useRelinkStore = create<RelinkState>((set) => ({
  projectId: null,
  missingIds: [],
  dismissed: false,
  setMissing: (projectId, ids) => set({ projectId, missingIds: ids, dismissed: false }),
  resolve: (mediaId) => set((s) => ({ missingIds: s.missingIds.filter((id) => id !== mediaId) })),
  dismiss: () => set({ dismissed: true }),
  clear: () => set({ projectId: null, missingIds: [], dismissed: false }),
}));
