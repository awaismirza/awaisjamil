import { parseCursorLog, type CursorTrack } from "../lib/cursor";
const worker = globalThis as unknown as {
  onmessage: (event: globalThis.MessageEvent<string>) => void;
  postMessage: (result: { track: CursorTrack } | { error: string }) => void;
};
worker.onmessage = ({ data }) => {
  try {
    worker.postMessage({ track: parseCursorLog(data) });
  } catch (error) {
    worker.postMessage({ error: String(error) });
  }
};
