/** Derived playback data. Cached by the immutable segment revision, never saved or undone. */
import {
  entryTiming,
  segmentOutputLength,
  type Segment,
  type TimelineEntry,
  type Word,
} from "./edl";
import { entryOutputAt, entryPlayEnd, entrySourceAt } from "./timeMap";
export interface IndexedEntry extends TimelineEntry {
  index: number;
  segment: Segment;
  words: readonly Word[];
  /** Prefix maxima allow first-active-word lookup even with overlapping timestamps. */
  wordEnds: number[];
}
export interface TimelineIndex {
  entries: IndexedEntry[];
  duration: number;
  byWordId: Map<string, Array<{ entry: IndexedEntry; word: Word; wordIndex: number }>>;
  byMediaId: Map<string, IndexedEntry[]>;
}
const cache = new WeakMap<readonly Segment[], TimelineIndex>();
function firstGreater(values: readonly number[], time: number): number {
  let lo = 0,
    hi = values.length;
  while (lo < hi) {
    const mid = (lo + hi) >>> 1;
    if (values[mid] <= time) lo = mid + 1;
    else hi = mid;
  }
  return lo;
}
export function getTimelineIndex(segments: readonly Segment[]): TimelineIndex {
  const existing = cache.get(segments);
  if (existing) return existing;
  const entries: IndexedEntry[] = [],
    byWordId: TimelineIndex["byWordId"] = new Map(),
    byMediaId: TimelineIndex["byMediaId"] = new Map();
  let duration = 0;
  for (const segment of segments) {
    const length = segmentOutputLength(segment);
    if (length <= 0) continue;
    const words = [...segment.words].sort((a, b) => a.start - b.start);
    let end = -Infinity;
    const wordEnds = words.map((w) => {
      end = Math.max(end, w.end);
      return end;
    });
    const entry: IndexedEntry = {
      index: entries.length,
      segmentId: segment.id,
      mediaId: segment.mediaId,
      sourceIn: segment.sourceIn,
      sourceOut: segment.sourceOut,
      outputStart: duration,
      outputEnd: duration + length,
      ...entryTiming(segment),
      segment,
      words,
      wordEnds,
    };
    entries.push(entry);
    duration += length;
    const media = byMediaId.get(segment.mediaId) ?? [];
    media.push(entry);
    byMediaId.set(segment.mediaId, media);
    words.forEach((word, wordIndex) => {
      const matches = byWordId.get(word.id) ?? [];
      matches.push({ entry, word, wordIndex });
      byWordId.set(word.id, matches);
    });
  }
  const index = { entries, duration, byWordId, byMediaId };
  cache.set(segments, index);
  return index;
}
/** Half-open output ranges: a cut belongs to the next entry; duration itself is outside. */
export function entryAtOutput(index: TimelineIndex, t: number): IndexedEntry | null {
  if (!Number.isFinite(t) || t < 0 || t >= index.duration) return null;
  let lo = 0,
    hi = index.entries.length;
  while (lo < hi) {
    const mid = (lo + hi) >>> 1;
    if (index.entries[mid].outputEnd <= t) lo = mid + 1;
    else hi = mid;
  }
  return index.entries[lo] ?? null;
}
export function indexedSource(index: TimelineIndex, t: number) {
  const entry = entryAtOutput(index, t);
  return entry ? { entry, segment: entry.segment, sourceTime: entrySourceAt(entry, t) } : null;
}
export function indexedWord(index: TimelineIndex, t: number) {
  const mapped = indexedSource(index, t);
  if (!mapped) return null;
  const { entry, sourceTime } = mapped;
  const i = firstGreater(entry.wordEnds, sourceTime);
  const word = entry.words[i];
  if (word && word.start <= sourceTime) return { ...mapped, word, wordIndex: i, silence: false };
  // Preceding word remains dimly highlighted through a silence; no DOM work per frame.
  let previous = Math.min(i - 1, entry.words.length - 1);
  while (previous >= 0 && entry.words[previous].end > sourceTime) previous--;
  return previous >= 0
    ? { ...mapped, word: entry.words[previous], wordIndex: previous, silence: true }
    : null;
}
/**
 * Anchored to an EDL entry, never a search for the first matching source range.
 * `ended` once the footage is done: the output time is then the start of the
 * entry's hold (equal to `outputEnd` when it has none).
 */
export function playbackPosition(index: TimelineIndex, entryNumber: number, sourceTime: number) {
  const entry = index.entries[entryNumber];
  if (!entry || !Number.isFinite(sourceTime)) return null;
  if (sourceTime >= entry.sourceOut)
    return {
      entry,
      outputTime: entryPlayEnd(entry),
      next: index.entries[entryNumber + 1] ?? null,
      ended: true,
    };
  return {
    entry,
    outputTime: entryOutputAt(entry, Math.max(entry.sourceIn, sourceTime)),
    next: null,
    ended: false,
  };
}
