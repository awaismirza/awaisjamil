/**
 * Editor hotkey registry: the actions, their defaults and the pure matching /
 * validation helpers. Reuses the accelerator grammar, reserved list and
 * capture helpers from shortcuts.ts. Pure module (no React, Tauri or store
 * imports, same rule as edl.ts).
 */

import {
  acceleratorFromEvent,
  normalizeAccelerator,
  RESERVED,
  type KeyEventLike,
  type ShortcutDef,
  type ShortcutMap,
} from "./shortcuts";

export type EditorAction =
  | "playPause"
  | "rewind"
  | "pause"
  | "forward"
  | "markIn"
  | "markOut"
  | "addChapter"
  | "clearSelection"
  | "extractRange"
  | "deleteWords"
  | "deleteWordsAlt"
  | "deleteRange"
  | "deleteRangeAlt"
  | "undo"
  | "redo"
  | "save"
  | "export"
  | "voiceOver"
  // Voice-over review dialog (scope "review"): only while that dialog has focus.
  | "voKeep"
  | "voMode"
  | "voOverride"
  | "voAudition"
  | "voRetake"
  | "voDiscard";

/** `editor`: the editor window hotkeys; `review`: keys inside the voice-over review dialog. */
export type EditorShortcutScope = "editor" | "review";

export type EditorShortcutMap = Record<EditorAction, string>;

export interface EditorShortcutDef {
  action: EditorAction;
  label: string;
  default: string;
  /**
   * Where the hotkey may fire while a text target has focus: `never` blocks it in
   * any input and in the transcript, `editable` allows the transcript
   * (contenteditable) but not real inputs, `always` allows both.
   */
  textScope: "never" | "editable" | "always";
  /** Key auto-repeat re-fires the action (undo / redo only; toggles must not). */
  repeatable?: boolean;
  /** Swallowed (not run) while a heavy edit is processing. */
  lockedWhileProcessing?: boolean;
  /**
   * Absent = "editor". Review keys are matched only by the voice-over review
   * dialog, so they may reuse editor keys (Space, O) without a clash; conflicts
   * are checked within one scope.
   */
  scope?: EditorShortcutScope;
}

export const scopeOf = (d: Pick<EditorShortcutDef, "scope">): EditorShortcutScope =>
  d.scope ?? "editor";

export const EDITOR_SHORTCUT_DEFS: readonly EditorShortcutDef[] = [
  {
    action: "playPause",
    label: "Play / pause",
    default: "Space",
    textScope: "never",
    lockedWhileProcessing: true,
  },
  {
    action: "rewind",
    label: "Rewind (Shift: slow)",
    default: "J",
    textScope: "never",
    lockedWhileProcessing: true,
  },
  {
    action: "pause",
    label: "Pause",
    default: "K",
    textScope: "never",
    lockedWhileProcessing: true,
  },
  {
    action: "forward",
    label: "Play / faster",
    default: "L",
    textScope: "never",
    lockedWhileProcessing: true,
  },
  { action: "markIn", label: "Set In", default: "I", textScope: "never" },
  { action: "markOut", label: "Set Out", default: "O", textScope: "never" },
  { action: "addChapter", label: "Add chapter at playhead", default: "B", textScope: "never" },
  {
    action: "clearSelection",
    label: "Clear selection and markers",
    default: "X",
    textScope: "never",
  },
  {
    action: "extractRange",
    label: "Extract marked range",
    default: "CmdOrCtrl+Shift+X",
    textScope: "never",
  },
  {
    action: "deleteWords",
    label: "Delete selected words",
    default: "Backspace",
    textScope: "never",
    lockedWhileProcessing: true,
  },
  {
    action: "deleteWordsAlt",
    label: "Delete selected words (alt)",
    default: "Delete",
    textScope: "never",
    lockedWhileProcessing: true,
  },
  {
    action: "deleteRange",
    label: "Delete marked range",
    default: "CmdOrCtrl+Backspace",
    textScope: "editable",
  },
  {
    action: "deleteRangeAlt",
    label: "Delete marked range (alt)",
    default: "CmdOrCtrl+Delete",
    textScope: "editable",
  },
  {
    action: "undo",
    label: "Undo",
    default: "CmdOrCtrl+Z",
    textScope: "editable",
    repeatable: true,
  },
  {
    action: "redo",
    label: "Redo",
    default: "CmdOrCtrl+Shift+Z",
    textScope: "editable",
    repeatable: true,
  },
  { action: "save", label: "Save", default: "CmdOrCtrl+S", textScope: "always" },
  { action: "export", label: "Export", default: "CmdOrCtrl+E", textScope: "always" },
  {
    action: "voiceOver",
    label: "Record voice-over at playhead (start / stop)",
    default: "CmdOrCtrl+Alt+V",
    textScope: "editable",
  },
  {
    action: "voKeep",
    label: "Keep the take",
    default: "Enter",
    textScope: "never",
    scope: "review",
  },
  {
    action: "voMode",
    label: "Switch Overlay / Insert",
    default: "M",
    textScope: "never",
    scope: "review",
  },
  {
    action: "voOverride",
    label: "Override existing narration on / off",
    default: "O",
    textScope: "never",
    scope: "review",
  },
  {
    action: "voAudition",
    label: "Play / stop the take",
    default: "Space",
    textScope: "never",
    scope: "review",
  },
  {
    action: "voRetake",
    label: "Retake at the same point",
    default: "R",
    textScope: "never",
    scope: "review",
  },
  {
    action: "voDiscard",
    label: "Discard the take",
    default: "D",
    textScope: "never",
    scope: "review",
  },
];

/** Definitions of one scope, in display order. */
export const editorDefsIn = (scope: EditorShortcutScope) =>
  EDITOR_SHORTCUT_DEFS.filter((d) => scopeOf(d) === scope);

export function defaultEditorShortcuts(): EditorShortcutMap {
  const map = {} as EditorShortcutMap;
  for (const d of EDITOR_SHORTCUT_DEFS) map[d.action] = d.default;
  return map;
}

export function editorDef(action: EditorAction): EditorShortcutDef {
  return EDITOR_SHORTCUT_DEFS.find((d) => d.action === action)!;
}

const DEFAULT_CANON = new Set(EDITOR_SHORTCUT_DEFS.map((d) => normalizeAccelerator(d.default)));

export type EditorShortcutProblem = "invalid" | "reserved";

/**
 * Plain keys are fine here (the hook guards typing), unlike global shortcuts.
 * macOS-reserved combinations are refused unless they are one of our own
 * defaults (Cmd+Z, Cmd+Shift+Z, Cmd+S are the app's own undo / redo / save).
 */
export function editorShortcutProblem(accelerator: string): EditorShortcutProblem | null {
  const canon = normalizeAccelerator(accelerator);
  if (!canon) return "invalid";
  if (RESERVED.has(canon) && !DEFAULT_CANON.has(canon)) return "reserved";
  return null;
}

export function editorProblemMessage(p: EditorShortcutProblem): string {
  return p === "invalid"
    ? "That key can't be used as a shortcut."
    : "macOS and most apps already use that one.";
}

/** Label of whatever else already holds this accelerator (editor map or recorder map). */
export function findEditorConflict(
  editor: EditorShortcutMap,
  recorder: ShortcutMap,
  recorderDefs: readonly ShortcutDef[],
  action: EditorAction,
  accelerator: string,
): string | null {
  const canon = normalizeAccelerator(accelerator);
  if (!canon) return null;
  const scope = scopeOf(editorDef(action));
  for (const d of editorDefsIn(scope)) {
    if (d.action !== action && normalizeAccelerator(editor[d.action]) === canon) return d.label;
  }
  // Global recorder shortcuts fire from anywhere, so no editor scope may reuse them.
  for (const d of recorderDefs) {
    if (normalizeAccelerator(recorder[d.action]) === canon) return d.label;
  }
  return null;
}

/** The action of `scope` bound to a canonical accelerator, if any. */
export function editorActionFor(
  map: EditorShortcutMap,
  accelerator: string,
  scope: EditorShortcutScope = "editor",
): EditorAction | null {
  for (const d of editorDefsIn(scope)) {
    if (normalizeAccelerator(map[d.action]) === accelerator) return d.action;
  }
  return null;
}

/** The review-dialog action for a key press (no modifiers expected, but any are matched exactly). */
export function matchReviewShortcut(
  map: EditorShortcutMap,
  e: KeyEventLike,
  mac: boolean,
): EditorAction | null {
  const acc = eventAccelerator(e, mac);
  return acc ? editorActionFor(map, acc, "review") : null;
}

/** Accelerator for a key press; the platform command key reads as CmdOrCtrl. */
export function eventAccelerator(e: KeyEventLike, mac: boolean): string | null {
  return acceleratorFromEvent(mac ? e : { ...e, metaKey: e.ctrlKey, ctrlKey: false });
}

/**
 * Resolve a key press to an editor action. Shift+<rewind key> is the slow
 * rewind, so it resolves to `rewind` with `slow: true` when Shift+key is unbound.
 */
export function matchEditorShortcut(
  map: EditorShortcutMap,
  e: KeyEventLike,
  mac: boolean,
): { action: EditorAction; slow: boolean } | null {
  const acc = eventAccelerator(e, mac);
  if (!acc) return null;
  const hit = editorActionFor(map, acc);
  if (hit) return { action: hit, slow: false };
  if (e.shiftKey) {
    const bare = eventAccelerator({ ...e, shiftKey: false }, mac);
    if (bare && editorActionFor(map, bare) === "rewind") return { action: "rewind", slow: true };
  }
  return null;
}
