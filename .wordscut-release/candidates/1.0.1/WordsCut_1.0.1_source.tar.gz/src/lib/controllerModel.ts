/**
 * What the desktop recording controller shows and allows for a session snapshot.
 * Pure, so every phase is tested without a window.
 */
import type { RecordingSnapshot } from "@/lib/ipc";
import { formatTimecode } from "@/lib/timecode";

export interface ControllerModel {
  status: "starting" | "recording" | "paused" | "interrupted" | "finalizing" | "idle";
  label: string;
  time: string;
  canPause: boolean;
  canResume: boolean;
  canStop: boolean;
  canMark: boolean;
  /** Restart and discard live in the overflow menu, behind a confirmation. */
  canRestart: boolean;
  canDiscard: boolean;
}

export function controllerModel(s: RecordingSnapshot): ControllerModel {
  const time = formatTimecode(s.elapsedSec, { ms: false });
  const none = {
    canPause: false,
    canResume: false,
    canStop: false,
    canMark: false,
    canRestart: false,
    canDiscard: false,
  };
  switch (s.phase) {
    case "starting":
      return { ...none, status: "starting", label: "Starting…", time, canDiscard: true };
    case "recording":
      return {
        ...none,
        status: "recording",
        label: "Recording",
        time,
        canPause: true,
        canStop: true,
        canMark: true,
        canRestart: true,
        canDiscard: true,
      };
    case "paused":
      return {
        ...none,
        status: "paused",
        label: "Paused",
        time,
        canResume: true,
        canStop: true,
        canRestart: true,
        canDiscard: true,
      };
    case "interrupted":
      return {
        ...none,
        status: "interrupted",
        label: "Capture stopped — save what was recorded",
        time,
        canStop: true,
        canDiscard: true,
      };
    case "finalizing":
      return { ...none, status: "finalizing", label: "Saving…", time };
    case "idle":
      return { ...none, status: "idle", label: "Not recording", time };
  }
}
