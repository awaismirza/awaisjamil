/**
 * Zoom regions: spans of the OUTPUT timeline where the picture is zoomed in.
 * Pure module (no React, Tauri or store imports, same rule as edl.ts).
 *
 * Rules every helper keeps:
 *   - regions never overlap and are always sorted by start;
 *   - a region is at least MIN_REGION_SEC long and lies inside the timeline;
 *   - scale is within [ZOOM_MIN_SCALE, ZOOM_MAX_SCALE], focus within 0..1.
 *
 * `sampleZoom` is the single definition of the motion. The preview uses it
 * directly and the exporter (`src-tauri/src/zoom.rs`) builds the same
 * expression for ffmpeg, so what you see is what you export.
 */

import type { TimelineEntry } from "./edl";
import { entryOutputAt, entryPlayEnd, entrySourceAt, mapHold } from "./timeMap";

export interface FocusKey {
  t: number;
  x: number;
  y: number;
}

export interface ZoomRegion {
  id: string;
  /** Output-timeline seconds. */
  start: number;
  end: number;
  /** 1.2 to 4: how far the picture is magnified at the plateau. */
  scale: number;
  /** The point (0..1 of the picture) the zoom settles on. 0.5, 0.5 is the centre. */
  focusX: number;
  focusY: number;
  /** Length of each ease in and ease out, in milliseconds. */
  easeMs: number;
  follow?: boolean;
  /** Absolute output seconds, linearly interpolated, held outside their span. */
  focusKeys?: FocusKey[];
}

export const ZOOM_MIN_SCALE = 1.2;
export const ZOOM_MAX_SCALE = 4;
export const DEFAULT_ZOOM_SCALE = 1.6;
export const MIN_REGION_SEC = 0.5;
export const DEFAULT_EASE_MS = 450;
export const MAX_EASE_MS = 2000;
/** Pieces shorter than this vanish when an edit cuts most of a region away. */
const RETIME_MIN_SEC = 0.2;
/** Pieces closer than this after an edit are one region again. */
const RETIME_JOIN_SEC = 0.02;

let counter = 0;
function newId(): string {
  counter += 1;
  return `zr-${Date.now().toString(36)}-${counter.toString(36)}-${Math.random().toString(36).slice(2, 6)}`;
}

const clamp = (n: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, n));

export function clampScale(scale: number): number {
  return clamp(Number.isFinite(scale) ? scale : DEFAULT_ZOOM_SCALE, ZOOM_MIN_SCALE, ZOOM_MAX_SCALE);
}

/** Focus key interpolation shared by sampling, trimming, dragging and edit retiming. */
export function focusAt(
  r: Pick<ZoomRegion, "follow" | "focusKeys" | "focusX" | "focusY">,
  t: number,
): { x: number; y: number } {
  const keys = r.follow ? r.focusKeys : undefined;
  if (!keys?.length) return { x: r.focusX, y: r.focusY };
  let lo = 0,
    hi = keys.length;
  while (lo < hi) {
    const mid = (lo + hi) >>> 1;
    if (keys[mid].t <= t) lo = mid + 1;
    else hi = mid;
  }
  const a = keys[Math.max(0, lo - 1)],
    b = keys[lo];
  if (!b || lo === 0) return { x: a.x, y: a.y };
  const f = (t - a.t) / (b.t - a.t);
  return { x: a.x + (b.x - a.x) * f, y: a.y + (b.y - a.y) * f };
}

export function sanitizeFocusKeys(raw: unknown): FocusKey[] {
  if (!Array.isArray(raw)) return [];
  const keys: FocusKey[] = [];
  for (const k of raw) {
    if (
      !k ||
      typeof k !== "object" ||
      ![k.t, k.x, k.y].every((n) => typeof n === "number" && Number.isFinite(n))
    )
      continue;
    keys.push({ t: k.t, x: clamp(k.x, 0, 1), y: clamp(k.y, 0, 1) });
  }
  keys.sort((a, b) => a.t - b.t);
  return keys.filter((k, i) => keys[i + 1]?.t !== k.t);
}

/** Preserve the interpolated focus at new endpoints instead of dropping it. */
function trimFocus(r: ZoomRegion, start: number, end: number): ZoomRegion {
  if (!r.focusKeys?.length) return { ...r, start, end };
  const active = { ...r, follow: true };
  return {
    ...r,
    start,
    end,
    focusKeys: [
      { t: start, ...focusAt(active, start) },
      ...r.focusKeys.filter((k) => k.t > start && k.t < end),
      { t: end, ...focusAt(active, end) },
    ],
  };
}

// ---------------------------------------------------------------------------
// Normalising
// ---------------------------------------------------------------------------

function sortByStart(regions: ZoomRegion[]): ZoomRegion[] {
  return [...regions].sort((a, b) => a.start - b.start || a.end - b.end);
}

/**
 * Sort, clamp to the timeline and resolve any overlap. Earlier regions keep
 * their span; a later region that starts inside one is shortened from the left,
 * and dropped if too little is left.
 */
export function normalizeRegions(regions: readonly ZoomRegion[], total: number): ZoomRegion[] {
  const out: ZoomRegion[] = [];
  let cursor = 0;
  for (const r of sortByStart(regions.map((x) => ({ ...x })))) {
    const start = Math.max(cursor, clamp(r.start, 0, total));
    const end = clamp(r.end, 0, total);
    if (end - start < MIN_REGION_SEC - 1e-9) continue;
    out.push(trimFocus(r, start, end));
    cursor = end;
  }
  return out;
}

/** Make any stored value into valid regions. Junk entries are dropped, numbers clamped. */
export function sanitizeZoomRegions(raw: unknown, total: number): ZoomRegion[] {
  if (!Array.isArray(raw)) return [];
  const parsed: ZoomRegion[] = [];
  for (const item of raw) {
    if (typeof item !== "object" || item === null) continue;
    const r = item as Record<string, unknown>;
    if (typeof r.start !== "number" || typeof r.end !== "number") continue;
    if (!Number.isFinite(r.start) || !Number.isFinite(r.end)) continue;
    parsed.push({
      ...(r.follow === true ? { follow: true } : {}),
      ...(Array.isArray(r.focusKeys) ? { focusKeys: sanitizeFocusKeys(r.focusKeys) } : {}),
      id: typeof r.id === "string" && r.id.length > 0 ? r.id : newId(),
      start: r.start,
      end: r.end,
      scale: clampScale(typeof r.scale === "number" ? r.scale : DEFAULT_ZOOM_SCALE),
      focusX: clamp(
        typeof r.focusX === "number" && Number.isFinite(r.focusX) ? r.focusX : 0.5,
        0,
        1,
      ),
      focusY: clamp(
        typeof r.focusY === "number" && Number.isFinite(r.focusY) ? r.focusY : 0.5,
        0,
        1,
      ),
      easeMs: clamp(
        typeof r.easeMs === "number" && Number.isFinite(r.easeMs) ? r.easeMs : DEFAULT_EASE_MS,
        0,
        MAX_EASE_MS,
      ),
    });
  }
  return normalizeRegions(parsed, total);
}

// ---------------------------------------------------------------------------
// Editing
// ---------------------------------------------------------------------------

export interface NewZoomRegion {
  start: number;
  end: number;
  scale?: number;
  focusX?: number;
  focusY?: number;
  easeMs?: number;
  follow?: boolean;
  focusKeys?: FocusKey[];
  id?: string;
}

/**
 * Put a region on the timeline. It wins any overlap: regions it covers vanish,
 * ones it partly covers are trimmed, and one it sits inside is split in two.
 * Returns the same list when the span is too short to be a region.
 */
export function addZoomRegion(
  regions: readonly ZoomRegion[],
  input: NewZoomRegion,
  total: number,
): ZoomRegion[] {
  const start = clamp(Math.min(input.start, input.end), 0, total);
  const end = clamp(Math.max(input.start, input.end), 0, total);
  if (end - start < MIN_REGION_SEC - 1e-9) return [...regions];

  const added: ZoomRegion = {
    ...(input.follow !== undefined ? { follow: input.follow } : {}),
    ...(input.focusKeys ? { focusKeys: sanitizeFocusKeys(input.focusKeys) } : {}),
    id: input.id ?? newId(),
    start,
    end,
    scale: clampScale(input.scale ?? DEFAULT_ZOOM_SCALE),
    focusX: clamp(input.focusX ?? 0.5, 0, 1),
    focusY: clamp(input.focusY ?? 0.5, 0, 1),
    easeMs: clamp(input.easeMs ?? DEFAULT_EASE_MS, 0, MAX_EASE_MS),
  };

  const kept: ZoomRegion[] = [];
  for (const r of regions) {
    if (r.end <= start || r.start >= end) {
      kept.push({ ...r });
      continue;
    }
    if (r.start < start && start - r.start >= MIN_REGION_SEC - 1e-9) {
      kept.push(trimFocus(r, r.start, start));
    }
    if (r.end > end && r.end - end >= MIN_REGION_SEC - 1e-9) {
      // The right-hand piece of a split gets a fresh id so ids stay unique.
      kept.push({ ...trimFocus(r, end, r.end), id: r.start < start ? newId() : r.id });
    }
  }
  return sortByStart([...kept, trimFocus(added, start, end)]);
}

export function removeZoomRegion(regions: readonly ZoomRegion[], id: string): ZoomRegion[] {
  return regions.filter((r) => r.id !== id).map((r) => ({ ...r }));
}

/**
 * Change a region. A new span is applied the same way as adding one, so moving
 * or stretching it over a neighbour trims that neighbour.
 */
export function updateZoomRegion(
  regions: readonly ZoomRegion[],
  id: string,
  patch: Partial<Omit<ZoomRegion, "id">>,
  total: number,
): ZoomRegion[] {
  const current = regions.find((r) => r.id === id);
  if (!current) return [...regions];
  const merged = { ...current, ...patch };
  // A manual focus choice on the timeline replaces automatic following.
  if (patch.follow === undefined && (patch.focusX !== undefined || patch.focusY !== undefined)) {
    merged.follow = false;
  }
  // Never let a drag shrink it below the minimum: hold the minimum length instead.
  let { start, end } = merged;
  if (end - start < MIN_REGION_SEC) {
    if (patch.start !== undefined && patch.end === undefined) start = end - MIN_REGION_SEC;
    else end = start + MIN_REGION_SEC;
  }
  if (end > total) {
    end = total;
    start = Math.max(0, end - Math.max(MIN_REGION_SEC, merged.end - merged.start));
  }
  if (start < 0) {
    end = Math.min(total, end - start);
    start = 0;
  }
  // Moving the whole region moves its keys. Edge resizing keeps source focus.
  if (
    patch.focusKeys === undefined &&
    patch.start !== undefined &&
    patch.end !== undefined &&
    Math.abs(patch.end - patch.start - (current.end - current.start)) < 1e-6
  ) {
    merged.focusKeys = current.focusKeys?.map((k) => ({ ...k, t: k.t + start - current.start }));
  }
  return addZoomRegion(removeZoomRegion(regions, id), { ...merged, start, end, id }, total);
}

/** Remove zoom over [start, end]: regions inside vanish, others are trimmed or split. */
export function clearZoomRange(
  regions: readonly ZoomRegion[],
  start: number,
  end: number,
): ZoomRegion[] {
  const lo = Math.min(start, end);
  const hi = Math.max(start, end);
  const out: ZoomRegion[] = [];
  for (const r of regions) {
    if (r.end <= lo || r.start >= hi) {
      out.push({ ...r });
      continue;
    }
    if (r.start < lo && lo - r.start >= MIN_REGION_SEC - 1e-9) out.push(trimFocus(r, r.start, lo));
    if (r.end > hi && r.end - hi >= MIN_REGION_SEC - 1e-9) {
      out.push({ ...trimFocus(r, hi, r.end), id: r.start < lo ? newId() : r.id });
    }
  }
  return sortByStart(out);
}

// ---------------------------------------------------------------------------
// Motion
// ---------------------------------------------------------------------------

/** Smoothstep: zero slope at both ends, so the zoom starts and stops gently. */
export function smooth(p: number): number {
  const x = clamp(p, 0, 1);
  return x * x * (3 - 2 * x);
}

/** How far into its zoom a region is at time `t`: 0 outside, 1 on the plateau. */
export function zoomEnvelope(r: ZoomRegion, t: number): number {
  if (t < r.start || t > r.end) return 0;
  const ease = Math.min(r.easeMs / 1000, (r.end - r.start) / 2);
  if (ease <= 0) return 1;
  return smooth(Math.min(1, (t - r.start) / ease, (r.end - t) / ease));
}

export interface ZoomSample {
  /** 1 = no zoom. */
  scale: number;
  /** Centre of the visible window, 0..1 of the picture, before edge clamping. */
  cx: number;
  cy: number;
}

export const NO_ZOOM: ZoomSample = { scale: 1, cx: 0.5, cy: 0.5 };

/** The zoom at output time `t`. Regions never overlap, so at most one contributes. */
export function sampleZoom(regions: readonly ZoomRegion[], t: number): ZoomSample {
  let scale = 1;
  let cx = 0.5;
  let cy = 0.5;
  for (const r of regions) {
    const e = zoomEnvelope(r, t);
    if (e === 0) continue;
    scale += (r.scale - 1) * e;
    const focus = focusAt(r, t);
    cx += (focus.x - 0.5) * e;
    cy += (focus.y - 0.5) * e;
  }
  return { scale, cx, cy };
}

/**
 * The visible window of the picture for a sample, as fractions of its width and
 * height. The window is kept fully inside the picture, so a focus near an edge
 * never shows empty space.
 */
export function viewWindow(s: ZoomSample): { x0: number; y0: number; w: number; h: number } {
  const w = 1 / s.scale;
  return {
    x0: clamp(s.cx - w / 2, 0, 1 - w),
    y0: clamp(s.cy - w / 2, 0, 1 - w),
    w,
    h: w,
  };
}

// ---------------------------------------------------------------------------
// Following edits
// ---------------------------------------------------------------------------

/**
 * Re-time regions after an edit removed output time, so each keeps covering the
 * same content. Goes through source time: a region loses the parts whose content
 * was cut and closes up over the gap. A region that loses (almost) everything
 * disappears; one split by an unrelated cut elsewhere stays whole.
 */
export function retimeZoomRegions(
  regions: readonly ZoomRegion[],
  oldTimeline: readonly TimelineEntry[],
  newTimeline: readonly TimelineEntry[],
  newTotal: number,
): ZoomRegion[] {
  const out: ZoomRegion[] = [];
  for (const r of regions) {
    const pieces: Array<{ start: number; end: number; keys?: FocusKey[] }> = [];
    for (const oe of oldTimeline) {
      const lo = Math.max(r.start, oe.outputStart);
      const hi = Math.min(r.end, oe.outputEnd);
      if (hi <= lo) continue;
      // Map one old output span onto a new one, rescaling focus keys with it.
      const push = (oldStart: number, oldEnd: number, start: number, end: number) => {
        if (end <= start || oldEnd <= oldStart) return;
        const ratio = (end - start) / (oldEnd - oldStart);
        const k = Math.abs(ratio - 1) < 1e-9 ? 1 : ratio;
        const clipped = trimFocus(r, oldStart, oldEnd);
        pieces.push({
          start,
          end,
          keys: clipped.focusKeys?.map((f) => ({ ...f, t: start + (f.t - oldStart) * k })),
        });
      };
      // The footage part goes through source time (speed may differ)...
      const playEnd = entryPlayEnd(oe);
      const srcLo = entrySourceAt(oe, lo);
      const srcHi = entrySourceAt(oe, Math.min(hi, playEnd));
      for (const ne of newTimeline) {
        if (ne.mediaId !== oe.mediaId) continue;
        const a = Math.max(srcLo, ne.sourceIn);
        const b = Math.min(srcHi, ne.sourceOut);
        if (b <= a) continue;
        push(
          entryOutputAt(oe, a),
          entryOutputAt(oe, b),
          entryOutputAt(ne, a),
          entryOutputAt(ne, b),
        );
      }
      // ...the hold part follows the same held frame.
      if (hi > playEnd) {
        const a = Math.max(lo, playEnd);
        const s = mapHold(oe, newTimeline, a);
        const e = mapHold(oe, newTimeline, hi - 1e-9);
        if (typeof s === "number" && typeof e === "number") push(a, hi, s, e + 1e-9);
      }
    }
    pieces.sort((p, q) => p.start - q.start);
    const joined: typeof pieces = [];
    for (const p of pieces) {
      const last = joined[joined.length - 1];
      if (last && p.start - last.end <= RETIME_JOIN_SEC) {
        // A cut is a discontinuity, not a quarter-second pan into removed footage.
        if (last.keys?.length && p.keys?.length) {
          const tail = last.keys[last.keys.length - 1];
          if (tail.t >= p.start) tail.t = p.start - 1e-6;
          last.keys.push(...p.keys);
        }
        last.end = Math.max(last.end, p.end);
      } else joined.push(p);
    }
    joined
      .filter((p) => p.end - p.start >= RETIME_MIN_SEC)
      .forEach((p, i) =>
        out.push({
          ...r,
          id: i === 0 ? r.id : newId(),
          start: p.start,
          end: p.end,
          ...(p.keys ? { focusKeys: p.keys } : {}),
        }),
      );
  }
  return normalizeRegions(out, newTotal);
}
