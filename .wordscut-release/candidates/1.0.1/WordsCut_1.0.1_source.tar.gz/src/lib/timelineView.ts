/** Pure timeline lane-visibility model. View state only: never touches the EDL. */

// Every id here renders. Future lanes (word detail, audio tracks) get added with their renderer.
export const LANE_IDS = ["clips", "waveform", "zoom", "chapters", "cutMap"] as const;
export type LaneId = (typeof LANE_IDS)[number];
export type ViewPreset = "simple" | "detailed" | "custom";

export type TimelineViewPrefs = {
  preset: ViewPreset;
  lanes: Record<LaneId, boolean>;
  hideEmpty: boolean;
};

export const LANE_LABELS: Record<LaneId, string> = {
  clips: "Clips",
  waveform: "Waveform",
  zoom: "Zoom regions",
  chapters: "Chapters",
  cutMap: "Cut map",
};

const lanes = (on: readonly LaneId[]): Record<LaneId, boolean> =>
  Object.fromEntries(LANE_IDS.map((id) => [id, on.includes(id)])) as Record<LaneId, boolean>;

export const SIMPLE: TimelineViewPrefs = {
  preset: "simple",
  lanes: lanes(["clips", "waveform", "zoom", "chapters"]), // cut map off
  hideEmpty: true,
};
export const DETAILED: TimelineViewPrefs = {
  preset: "detailed",
  lanes: lanes(LANE_IDS),
  hideEmpty: false,
};

export const resetView = (): TimelineViewPrefs => ({ ...SIMPLE, lanes: { ...SIMPLE.lanes } });

export function applyPreset(preset: ViewPreset, current: TimelineViewPrefs): TimelineViewPrefs {
  if (preset === "simple") return resetView();
  if (preset === "detailed") return { ...DETAILED, lanes: { ...DETAILED.lanes } };
  return { ...current, preset: "custom" };
}

export function toggleLane(p: TimelineViewPrefs, id: LaneId, on: boolean): TimelineViewPrefs {
  return { ...p, preset: "custom", lanes: { ...p.lanes, [id]: on } };
}

export const setHideEmpty = (p: TimelineViewPrefs, hideEmpty: boolean): TimelineViewPrefs => ({
  ...p,
  preset: "custom",
  hideEmpty,
});

/** Turn on exactly the lanes that currently have content. */
export function showPopulated(
  p: TimelineViewPrefs,
  content: Partial<Record<LaneId, boolean>>,
): TimelineViewPrefs {
  return {
    ...p,
    preset: "custom",
    hideEmpty: false,
    lanes: lanes(LANE_IDS.filter((i) => content[i])),
  };
}

/** Lanes to draw: switched on, and (when hiding empties) populated. */
export function resolveVisibleLanes(
  p: TimelineViewPrefs,
  content: Partial<Record<LaneId, boolean>>,
): LaneId[] {
  return LANE_IDS.filter((id) => p.lanes[id] && (!p.hideEmpty || content[id]));
}

/** Validate untrusted stored JSON; anything malformed falls back to Simple. */
export function sanitizePrefs(raw: unknown): TimelineViewPrefs {
  const r = raw as Partial<TimelineViewPrefs> | null;
  if (!r || typeof r !== "object" || !r.lanes || typeof r.lanes !== "object") return resetView();
  const stored = r.lanes;
  const preset: ViewPreset = ["simple", "detailed", "custom"].includes(r.preset as string)
    ? (r.preset as ViewPreset)
    : "custom";
  return {
    preset,
    hideEmpty: typeof r.hideEmpty === "boolean" ? r.hideEmpty : SIMPLE.hideEmpty,
    lanes: Object.fromEntries(
      LANE_IDS.map((id) => [id, typeof stored[id] === "boolean" ? stored[id] : SIMPLE.lanes[id]]),
    ) as Record<LaneId, boolean>,
  };
}
