/**
 * Cut navigation and live-caption helpers for the preview. Pure module (no
 * React, Tauri or store imports, same rule as edl.ts).
 */

import { entryPlayEnd, transitionHalf, type Project } from "./edl";
import { getTimelineIndex, indexedWord } from "./timelineIndex";

/** How long before a cut the preview lands, so the splice is heard in context. */
export const CUT_LEAD_IN_SEC = 1;

/** Source gaps smaller than this are the same take, not a cut (float noise). */
const CONTIGUOUS_EPS = 1e-6;

/**
 * Output times where the EDL jumps in the source: between two surviving
 * segments with removed time (or another clip) between them. Segments that
 * merely touch (a split with nothing removed) are not cuts.
 */
export function cutPoints(project: Project): number[] {
  const timeline = getTimelineIndex(project.segments).entries;
  const points: number[] = [];
  for (let i = 1; i < timeline.length; i++) {
    const prev = timeline[i - 1]!;
    const cur = timeline[i]!;
    const jumped =
      prev.mediaId !== cur.mediaId || Math.abs(cur.sourceIn - prev.sourceOut) > CONTIGUOUS_EPS;
    if (jumped) points.push(cur.outputStart);
  }
  return points;
}

export interface TimingMark {
  kind: "speed" | "hold" | "transition";
  /** Output-time span; a transition's span is its window around the cut. */
  start: number;
  end: number;
  label: string;
}

/** Spans of the output timeline with a speed change, a freeze-frame hold or a transition. */
export function timingMarks(project: Project): TimingMark[] {
  const marks: TimingMark[] = [];
  for (const e of getTimelineIndex(project.segments).entries) {
    if (e.speed)
      marks.push({
        kind: "speed",
        start: e.outputStart,
        end: entryPlayEnd(e),
        label: `${e.speed}×`,
      });
    if (e.holdSec)
      marks.push({
        kind: "hold",
        start: entryPlayEnd(e),
        end: e.outputEnd,
        label: `Freeze ${e.holdSec}s`,
      });
    const i = project.segments.indexOf(e.segment);
    const h = transitionHalf(project.segments, i);
    if (h > 0)
      marks.push({
        kind: "transition",
        start: e.outputStart - h,
        end: e.outputStart + h,
        label: e.segment.transitionIn!.kind === "dip" ? "Dip to black" : "Crossfade",
      });
  }
  return marks;
}

/** Where "next cut" should seek: lead-in before the first cut still ahead of `now`. */
export function nextCutTarget(points: readonly number[], now: number): number | null {
  for (const p of points) {
    const t = Math.max(0, p - CUT_LEAD_IN_SEC);
    if (t > now + 0.05) return t;
  }
  return null;
}

/** Where "previous cut" should seek: lead-in before the last cut already behind `now`. */
export function prevCutTarget(points: readonly number[], now: number): number | null {
  for (let i = points.length - 1; i >= 0; i--) {
    const t = Math.max(0, points[i]! - CUT_LEAD_IN_SEC);
    if (t < now - 0.5) return t;
  }
  return null;
}

/**
 * The words around the playhead as one caption line: `before` words before
 * the spoken word, the word itself, `after` words after it. Null when the
 * playhead is not on a spoken word (silence, or no transcript).
 */
export function captionAt(
  project: Project,
  outputTime: number,
  before = 3,
  after = 5,
): string | null {
  const mapped = indexedWord(getTimelineIndex(project.segments), outputTime);
  if (!mapped || mapped.silence) return null;
  return mapped.entry.words
    .slice(Math.max(0, mapped.wordIndex - before), mapped.wordIndex + after + 1)
    .map((w) => w.text.trim())
    .join(" ");
}
