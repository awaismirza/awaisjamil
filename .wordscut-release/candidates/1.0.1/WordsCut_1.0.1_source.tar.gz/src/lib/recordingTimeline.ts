/**
 * Stop-to-editor stage marks for one recording session. Pure bookkeeping on the
 * monotonic clock: no paths, no media names. Stages are recorded once, in the
 * order they happen, and summarised as elapsed milliseconds since Stop.
 *
 * Distinguishes (see docs/performance/recording-to-editor.md):
 *   A stop-to-editor-visible  = `inserted`
 *   B stop-to-first-frame     = `firstFrame`
 *   C stop-to-playable-audio  = `playable` (the preview `<video>` has loaded the
 *     take itself to HAVE_FUTURE_DATA; absent when a proxy is playing)
 *
 * Background stages, after the take is already editable (since 4.49):
 *   `checksumAttached`  the deferred SHA-256 landed on the media entry
 *   `cameraComposited`  a screen + camera clip now points at its camera composite
 *
 * `importProbed` is ffprobe only since 4.49 (the hash no longer blocks it).
 */
export type RecordingStage =
  | "stopRequested"
  | "finishedReceived"
  | "importStarted"
  | "importProbed"
  | "inserted"
  | "firstFrame"
  | "playable"
  | "checksumAttached"
  | "cameraComposited";

const MAX_SESSIONS = 16;
const marks = new Map<string, Partial<Record<RecordingStage, number>>>();
let lastSession: string | null = null;

const now = () => globalThis.performance.now();

export function markRecordingStage(sessionId: string, stage: RecordingStage, at = now()) {
  if (!sessionId) return;
  let m = marks.get(sessionId);
  if (!m) {
    if (marks.size >= MAX_SESSIONS) marks.delete(marks.keys().next().value as string);
    m = {};
    marks.set(sessionId, m);
  }
  if (m[stage] === undefined) m[stage] = at;
  lastSession = sessionId;
}

/** Elapsed ms from `stopRequested` for every stage reached; absent stages are omitted. */
export function recordingTimeline(sessionId: string): Partial<Record<RecordingStage, number>> {
  const m = marks.get(sessionId);
  if (!m || m.stopRequested === undefined) return {};
  const out: Partial<Record<RecordingStage, number>> = {};
  for (const [k, v] of Object.entries(m) as [RecordingStage, number][])
    out[k] = v - m.stopRequested;
  return out;
}

export function latestRecordingTimeline() {
  return lastSession ? { sessionId: lastSession, stages: recordingTimeline(lastSession) } : null;
}

export function resetRecordingTimelines() {
  marks.clear();
  lastSession = null;
}
