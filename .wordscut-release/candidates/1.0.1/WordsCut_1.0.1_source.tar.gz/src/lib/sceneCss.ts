/**
 * CSS for the live preview of a scene, derived from the same `sceneLayout`
 * numbers the exporter uses. Sizes are in `cqw` (1% of the stage's width), so
 * the preview scales with the window and stays proportional to the export.
 * Pure module: returns plain style objects.
 */

import {
  sceneLayout,
  type FrameShape,
  type FrameText,
  type Radii,
  type SceneBackground,
  type SceneSettings,
  type Size,
} from "./scene";

export interface SceneCss {
  /** Box with the canvas's aspect, fitted inside its host. */
  stage: Record<string, string | number>;
  /** Where the video sits on the stage. */
  content: Record<string, string | number>;
  /**
   * Full-frame layer inside `content`, positioned so only the cropped region
   * shows through `content`'s clipping. Null when there is no crop.
   */
  crop: Record<string, string | number> | null;
  /**
   * With a device frame: the box that clips the picture to the screen's shape
   * (`content` is then the screen), plus the shapes behind and over it. Null without a frame.
   */
  frame: {
    /** The picture's own rectangle inside `content` (the screen); letterboxed when smaller. */
    inset: Record<string, string | number>;
    /** Wrapper around the shapes behind the picture; carries the shadow of the outline. */
    belowGroup: Record<string, string | number>;
    below: FrameNodeCss[];
    above: FrameNodeCss[];
  } | null;
}

export interface FrameNodeCss {
  key: string;
  style: Record<string, string | number>;
  /** Present for text nodes. */
  text?: string;
}

/** Font used for device text (libass draws the export with Arial Unicode MS). */
const FRAME_FONT = '"Arial Unicode MS", Arial, Helvetica, sans-serif';

/** Light/dark squares behind a transparent background (the usual "nothing here" pattern). */
const CHECKER =
  "conic-gradient(#c9c9c9 25%, #ffffff 0 50%, #c9c9c9 0 75%, #ffffff 0) 0 0 / 24px 24px";

/** Percent of the stage width, as a CSS length. */
const cqw = (px: number, canvasW: number) => `${((px / canvasW) * 100).toFixed(4)}cqw`;
const pct = (px: number, total: number) => `${((px / total) * 100).toFixed(4)}%`;

const radiiCss = (r: Radii, canvasW: number) => r.map((v) => cqw(v, canvasW)).join(" ");

function shapeCss(s: FrameShape, i: number, k: string, W: number, H: number): FrameNodeCss {
  return {
    key: `${k}${i}`,
    style: {
      position: "absolute",
      left: pct(s.x, W),
      top: pct(s.y, H),
      width: pct(s.w, W),
      height: pct(s.h, H),
      borderRadius: radiiCss(s.radii, W),
      backgroundColor: s.color,
      ...(s.alpha < 1 ? { opacity: s.alpha } : {}),
    },
  };
}

function textCss(t: FrameText, i: number, W: number, H: number): FrameNodeCss {
  return {
    key: `t${i}`,
    text: t.text,
    style: {
      position: "absolute",
      left: pct(t.cx, W),
      top: pct(t.cy, H),
      transform: "translate(-50%, -50%)",
      fontSize: cqw(t.fontPx, W),
      lineHeight: 1,
      whiteSpace: "nowrap",
      color: t.color,
      fontFamily: FRAME_FONT,
      pointerEvents: "none",
      userSelect: "none",
    },
  };
}

export function backgroundCss(bg: SceneBackground, imageUrl?: string): Record<string, string> {
  switch (bg.kind) {
    case "solid":
      return { backgroundColor: bg.color };
    case "gradient":
      return { backgroundImage: `linear-gradient(${bg.angle}deg, ${bg.from}, ${bg.to})` };
    case "transparent":
      return { background: CHECKER };
    case "image":
      return imageUrl
        ? {
            backgroundColor: "#000000",
            backgroundImage: `url("${imageUrl}")`,
            backgroundSize: "cover",
            backgroundPosition: "center",
          }
        : { backgroundColor: "#000000" };
  }
}

/** Styles for an enabled scene. Callers show the plain video when it is not enabled. */
export function sceneCss(scene: SceneSettings, source: Size, imageUrl?: string): SceneCss {
  const l = sceneLayout(scene, source);
  const { content, shadow, crop } = l;
  const blur = cqw(shadow.sigmaPx * 2, l.canvasW); // CSS blur radius is about twice the Gaussian sigma
  // The layer is the whole source frame, scaled so the crop rect fills `content`.
  const cropCss = crop
    ? {
        position: "absolute",
        left: pct(-crop.x, crop.w),
        top: pct(-crop.y, crop.h),
        width: pct(source.w, crop.w),
        height: pct(source.h, crop.h),
      }
    : null;
  const fr = l.frame;
  const frame = fr
    ? {
        inset: {
          position: "absolute",
          left: pct(content.x - fr.screen.x, fr.screen.w),
          top: pct(content.y - fr.screen.y, fr.screen.h),
          width: pct(content.w, fr.screen.w),
          height: pct(content.h, fr.screen.h),
          overflow: "hidden",
        },
        belowGroup: {
          position: "absolute",
          inset: 0,
          pointerEvents: "none",
          filter:
            shadow.opacity > 0
              ? `drop-shadow(0 ${cqw(shadow.offsetY, l.canvasW)} ${blur} rgba(0, 0, 0, ${shadow.opacity.toFixed(3)}))`
              : "none",
        },
        below: fr.below.map((s, i) => shapeCss(s, i, "b", l.canvasW, l.canvasH)),
        above: [
          ...fr.above.map((s, i) => shapeCss(s, i, "a", l.canvasW, l.canvasH)),
          ...fr.texts.map((t, i) => textCss(t, i, l.canvasW, l.canvasH)),
        ],
      }
    : null;
  return {
    crop: cropCss,
    frame,
    stage: {
      position: "relative",
      containerType: "size",
      width: `min(100cqw, calc(100cqh * ${l.canvasW} / ${l.canvasH}))`,
      aspectRatio: `${l.canvasW} / ${l.canvasH}`,
      overflow: "hidden",
      ...backgroundCss(scene.background, imageUrl),
    },
    content: fr
      ? {
          // The screen: black, clipped to its corners; the picture sits in `frame.inset`.
          position: "absolute",
          left: pct(fr.screen.x, l.canvasW),
          top: pct(fr.screen.y, l.canvasH),
          width: pct(fr.screen.w, l.canvasW),
          height: pct(fr.screen.h, l.canvasH),
          borderRadius: radiiCss(fr.screenRadii, l.canvasW),
          overflow: "hidden",
          backgroundColor: "#000000",
        }
      : {
          position: "absolute",
          left: pct(content.x, l.canvasW),
          top: pct(content.y, l.canvasH),
          width: pct(content.w, l.canvasW),
          height: pct(content.h, l.canvasH),
          borderRadius: cqw(l.radiusPx, l.canvasW),
          overflow: "hidden",
          boxShadow:
            shadow.opacity > 0
              ? `0 ${cqw(shadow.offsetY, l.canvasW)} ${blur} rgba(0, 0, 0, ${shadow.opacity.toFixed(3)})`
              : "none",
        },
  };
}
