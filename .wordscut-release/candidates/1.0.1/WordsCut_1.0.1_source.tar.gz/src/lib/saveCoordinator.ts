/** All editor save paths share one queue; completions are tied to immutable snapshots. */
import type { Project } from "./edl";
import { saveProject } from "./ipc";
import { SaveQueue, normalizeSaveDestination } from "./saveQueue";
import { recordTiming } from "./playbackDiagnostics";
import { useProjectStore } from "@/stores/projectStore";
const queue = new SaveQueue<Project>(saveProject, (timing) =>
  recordTiming("save", timing.durationMs),
);
export async function saveProjectRevision(
  snapshot: Project,
  path: string,
  expectedPath: string | null,
) {
  const result = await queue.enqueue(path, snapshot);
  let current = false;
  if (result.status === "saved") {
    useProjectStore.setState((state) => {
      // New/open/Save As may have replaced the document while this write ran.
      if (
        state.project.id !== snapshot.id ||
        (state.filePath !== expectedPath &&
          (state.filePath === null ||
            normalizeSaveDestination(state.filePath) !== result.destination))
      )
        return state;
      current = state.project === snapshot;
      return { filePath: path, dirty: current ? false : state.dirty };
    });
  }
  return { ...result, current };
}
