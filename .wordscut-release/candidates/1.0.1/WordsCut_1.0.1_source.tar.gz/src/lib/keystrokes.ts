/**
 * Keystroke overlay: turns recorded `key` events (docs/cursor-events.md) into
 * on-screen key-cap captions. Pure module; mirrored by `keystroke_captions`
 * in src-tauri/src/annotations_export.rs.
 *
 * What the log can say: a `key` event always has its time and the held
 * modifiers (cmd, ctrl, alt, shift). Only when the user opted in at record time
 * does it also carry `name` (shortcut keys and non-printable keys; ordinary
 * characters only with the second opt-in) and `secure` (macOS secure input was
 * on: no identity recorded). Without a name a shortcut shows its modifiers plus
 * a generic "key" cap, and "all keys" mode shows "Typing"; secure presses show
 * "Typing (hidden)" in "all keys" mode.
 */

import { computeTimeline, segmentOutputLength, segmentSpeed, type Project } from "./edl";
import { maskOutputSpans, sanitizeMasks, sourceMasked } from "./masks";

export type KeystrokeMode = "shortcuts" | "all";
export interface KeystrokeSettings {
  /** Opt-in. Off unless the user turns it on. */
  enabled: boolean;
  /** `shortcuts` (default): only presses holding Cmd, Ctrl or Option. */
  mode: KeystrokeMode;
}
export const DEFAULT_KEYSTROKES: KeystrokeSettings = { enabled: false, mode: "shortcuts" };

export interface KeyCaption {
  /** Output seconds. */
  start: number;
  end: number;
  /** Key caps, left to right, e.g. ["⇧", "⌘", "key"]. */
  caps: string[];
  /** Presses merged into this caption. */
  count: number;
}

/** Presses of the same combination closer than this merge into one caption. */
export const KEY_MERGE_SEC = 1;
/** How long a caption stays up after its last press. */
export const KEY_HOLD_SEC = 1;
/** Text size of the caps, pixels at 1080 lines. */
export const KEY_FONT_PX = 44;
/**
 * Bottom edge of the key cap, as a fraction of the frame height. Frame-layer
 * order is fixed annotations, then captions, then key caps; when captions sit
 * at the bottom the caps move up to KEY_CAP_Y_ABOVE_CAPTIONS so they never cover them.
 * Same values as annotations_export.rs.
 */
export const KEY_CAP_Y = 0.94;
export const KEY_CAP_Y_ABOVE_CAPTIONS = 0.8;
export const keyCapY = (captionsAtBottom: boolean) =>
  captionsAtBottom ? KEY_CAP_Y_ABOVE_CAPTIONS : KEY_CAP_Y;

/** macOS menu order. */
const SYMBOLS: Array<[string, string]> = [
  ["ctrl", "⌃"],
  ["alt", "⌥"],
  ["shift", "⇧"],
  ["cmd", "⌘"],
];

export function sanitizeKeystrokes(raw: unknown): KeystrokeSettings {
  const r = raw && typeof raw === "object" ? (raw as Record<string, unknown>) : {};
  return {
    enabled: r.enabled === true,
    mode: r.mode === "all" ? "all" : "shortcuts",
  };
}

/** Caps for one press, or null when the mode does not show it. */
export function keyCaps(
  mods: readonly string[],
  mode: KeystrokeMode,
  name?: string,
  secure?: boolean,
): string[] | null {
  if (secure) return mode === "all" ? [TYPING_HIDDEN] : null;
  const shortcut = mods.some((m) => m === "cmd" || m === "ctrl" || m === "alt");
  if (shortcut) {
    return [...SYMBOLS.filter(([m]) => mods.includes(m)).map(([, s]) => s), keyCapText(name)];
  }
  if (mode !== "all") return null;
  return name !== undefined && keyCapText(name) !== "key" ? [keyCapText(name)] : ["Typing"];
}

export const TYPING_HIDDEN = "Typing (hidden)";

const NAMED_KEYS: Record<string, string> = {
  return: "↩",
  tab: "⇥",
  space: "Space",
  delete: "⌫",
  forwarddelete: "⌦",
  esc: "⎋",
  left: "←",
  right: "→",
  up: "↑",
  down: "↓",
  home: "Home",
  end: "End",
  pageup: "PgUp",
  pagedown: "PgDn",
  insert: "Ins",
  clear: "Clear",
};

/** The cap for a logged key name; "key" when there is none or it is not understood. Mirrors Rust. */
export function keyCapText(name: string | undefined): string {
  if (name === undefined) return "key";
  if (Object.hasOwn(NAMED_KEYS, name)) return NAMED_KEYS[name]!;
  if (/^f([1-9]|1\d|20)$/.test(name)) return name.toUpperCase();
  return [...name].length === 1 ? name.toUpperCase() : "key";
}

/** The text a caption shows, e.g. "⇧ ⌘ key ×3". Shared with the exporter. */
export function captionLabel(c: KeyCaption): string {
  const typing = c.caps.length === 1 && (c.caps[0] === "Typing" || c.caps[0] === TYPING_HIDDEN);
  return c.caps.join(" ") + (c.count > 1 && !typing ? ` ×${c.count}` : "");
}

/**
 * All captions on the output timeline: key events mapped through the EDL
 * (source -> output, repeats included), filtered by mode, merged, and laid
 * out one at a time (a new combination ends the previous caption).
 * Source -> output follows each clip's speed, and a hold adds output time with
 * no presses (mirrored by `keystroke_captions` in Rust).
 */
export function keystrokeCaptions(project: Project, settings: KeystrokeSettings): KeyCaption[] {
  if (!settings.enabled) return [];
  const tracks = project.cursor?.tracks ?? {};
  // Privacy: no key caps for presses under a mask, and none on screen while a mask shows.
  const masks = sanitizeMasks(project.masks);
  const masked = masks.length
    ? (() => {
        const tl = computeTimeline(project);
        return masks.flatMap((m) => maskOutputSpans(tl, m, project.media));
      })()
    : [];
  const presses: Array<{ t: number; caps: string[] }> = [];
  let offset = 0;
  for (const seg of project.segments) {
    const len = segmentOutputLength(seg);
    for (const e of tracks[seg.mediaId]?.events ?? []) {
      if (e.type !== "key" || e.t < seg.sourceIn || e.t >= seg.sourceOut) continue;
      if (sourceMasked(masks, project.media, seg.mediaId, e.t)) continue;
      const caps = keyCaps(e.mods, settings.mode, e.name, e.secure);
      if (caps) presses.push({ t: offset + (e.t - seg.sourceIn) / segmentSpeed(seg), caps });
    }
    offset += len;
  }
  presses.sort((a, b) => a.t - b.t);
  const out: KeyCaption[] = [];
  let lastT = -Infinity;
  for (const p of presses) {
    const last = out[out.length - 1];
    const gap = p.t - lastT;
    lastT = p.t;
    if (last && last.caps.join() === p.caps.join() && gap <= KEY_MERGE_SEC) {
      last.end = Math.min(offset, p.t + KEY_HOLD_SEC);
      last.count += 1;
      continue;
    }
    if (last && last.end > p.t) last.end = p.t;
    out.push({ start: p.t, end: Math.min(offset, p.t + KEY_HOLD_SEC), caps: p.caps, count: 1 });
  }
  for (const c of out)
    for (const [a, b] of masked) {
      if (a <= c.start && b > c.start) c.end = c.start;
      else if (a > c.start && a < c.end) c.end = a;
    }
  return out.filter((c) => c.end - c.start > 1e-3);
}

/** Number of recorded key events carrying a key name or secure flag. */
export function countKeyNames(project: Project): number {
  let n = 0;
  for (const t of Object.values(project.cursor?.tracks ?? {})) {
    for (const e of t.events) if (e.type === "key" && (e.name !== undefined || e.secure)) n++;
  }
  return n;
}

/**
 * The project with `name` / `secure` removed from every recorded key event (time and
 * modifiers stay). The same object when there is nothing to strip.
 */
export function stripKeyNames(project: Project): Project {
  if (!project.cursor || countKeyNames(project) === 0) return project;
  const tracks = Object.fromEntries(
    Object.entries(project.cursor.tracks).map(([id, t]) => [
      id,
      {
        ...t,
        events: t.events.map((e) =>
          e.type === "key" ? { type: "key" as const, t: e.t, mods: e.mods } : e,
        ),
      },
    ]),
  );
  return {
    ...project,
    cursor: { ...project.cursor, tracks },
    updatedAt: new Date().toISOString(),
  };
}

/** The caption showing at output time `t`, if any. */
export function keyCaptionAt(captions: readonly KeyCaption[], t: number): KeyCaption | null {
  return captions.find((c) => t >= c.start && t < c.end) ?? null;
}
