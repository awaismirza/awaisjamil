/**
 * Annotations: text, arrows and boxes drawn over the video on the OUTPUT
 * timeline. Pure module (no React, Tauri or store imports, same rule as edl.ts).
 *
 * Geometry is normalised (0..1) to the frame the annotation is drawn in: the
 * whole output frame (scene canvas, or the picture when there is no scene),
 * or the picture itself when `followZoom` is set, so it zooms with it.
 * Sizes (`stroke`, `fontSize`) are pixels at a 1080-line frame.
 *
 * The exporter (`src-tauri/src/annotations_export.rs`) re-validates with the
 * same rules and draws the same shapes as ASS vectors.
 */

import type { TimelineEntry } from "./edl";
import { retimeSpans } from "./timeMap";

export const ANNOTATION_KINDS = ["text", "arrow", "box"] as const;
export type AnnotationKind = (typeof ANNOTATION_KINDS)[number];

export interface Annotation {
  id: string;
  kind: AnnotationKind;
  /** Output-timeline seconds. */
  start: number;
  end: number;
  /** Text and box: top-left corner. Arrow: the tail. */
  x: number;
  y: number;
  /** Text and box: size. Arrow: head is (x + w, y + h); may be negative. */
  w: number;
  h: number;
  /** `#rrggbb`. */
  color: string;
  /** Outline / arrow width, pixels at 1080 lines. */
  stroke: number;
  /** Text size (CSS px, 1 em), pixels at 1080 lines. */
  fontSize: number;
  /** Box only: fill instead of outline. */
  filled?: boolean;
  text?: string;
  fadeInMs?: number;
  fadeOutMs?: number;
  /** Draw on the picture before zoom, so it moves with the zoom. */
  followZoom?: boolean;
}

export const MIN_ANNOTATION_SEC = 0.25;
export const DEFAULT_ANNOTATION_SEC = 3;
export const ANNOTATION_COLORS = [
  "#ff3b30",
  "#ffcc00",
  "#34c759",
  "#0a84ff",
  "#ffffff",
  "#000000",
] as const;
export const COLOR_NAMES: Record<(typeof ANNOTATION_COLORS)[number], string> = {
  "#ff3b30": "Red",
  "#ffcc00": "Yellow",
  "#34c759": "Green",
  "#0a84ff": "Blue",
  "#ffffff": "White",
  "#000000": "Black",
};
export const MAX_TEXT_LENGTH = 500;
/** More are dropped (same cap in annotations_export.rs). */
export const MAX_ANNOTATIONS = 500;
export const MAX_FADE_MS = 5000;
/** Text is drawn in this face in both preview and export (ships with macOS). */
export const ANNOTATION_FONT = "Arial Unicode MS";
const clamp = (n: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, n));
const num = (v: unknown, fallback: number) =>
  typeof v === "number" && Number.isFinite(v) ? v : fallback;

let counter = 0;
export function newAnnotationId(): string {
  counter += 1;
  return `an-${Date.now().toString(36)}-${counter.toString(36)}-${Math.random().toString(36).slice(2, 6)}`;
}

/**
 * Colour emoji: libass cannot draw Apple Color Emoji, so the export would show
 * empty boxes while the preview shows emoji. These are removed from text
 * (`is_emoji` in annotations_export.rs uses the same ranges). BMP symbols such
 * as (c) TM and the key symbols, and CJK / Hangul are kept: Arial Unicode MS draws them.
 */
export function isEmoji(c: string): boolean {
  const n = c.codePointAt(0)!;
  return (
    (n >= 0x1f000 && n <= 0x1faff) || // emoji, flags, skin tones
    n === 0xfe0f || // emoji presentation selector
    n === 0x20e3 || // keycap
    (n >= 0xe0020 && n <= 0xe007f) // tag sequences
  );
}
export const hasEmoji = (s: string) => Array.from(s).some(isEmoji);

/** Strip control characters (except newlines) and colour emoji; cap the length. */
export function cleanText(raw: string): string {
  // Same set as Rust's `char::is_control` (C0, DEL, C1); length counted in code points.
  const kept = Array.from(raw.replace(/\r\n?/g, "\n")).filter((c) => {
    const n = c.codePointAt(0)!;
    return c === "\n" || !(n < 0x20 || (n >= 0x7f && n <= 0x9f) || isEmoji(c));
  });
  return kept.slice(0, MAX_TEXT_LENGTH).join("");
}

/** One stored value -> a valid annotation, or null. Mirrors `sanitize` in annotations_export.rs. */
export function sanitizeAnnotation(raw: unknown, total: number): Annotation | null {
  if (!raw || typeof raw !== "object") return null;
  const r = raw as Record<string, unknown>;
  if (!ANNOTATION_KINDS.includes(r.kind as AnnotationKind)) return null;
  const kind = r.kind as AnnotationKind;
  if (typeof r.start !== "number" || typeof r.end !== "number") return null;
  const start = clamp(num(r.start, NaN), 0, total);
  const end = clamp(num(r.end, NaN), 0, total);
  if (!(end - start >= MIN_ANNOTATION_SEC - 1e-9)) return null;
  const x = clamp(num(r.x, 0.1), 0, 1);
  const y = clamp(num(r.y, 0.1), 0, 1);
  let w = num(r.w, 0.3);
  let h = num(r.h, 0.2);
  if (kind === "arrow") {
    w = clamp(x + w, 0, 1) - x;
    h = clamp(y + h, 0, 1) - y;
  } else {
    w = clamp(w, 0.01, Math.max(0.01, 1 - x));
    h = clamp(h, 0.01, Math.max(0.01, 1 - y));
  }
  const text = kind === "text" ? cleanText(typeof r.text === "string" ? r.text : "") : undefined;
  if (kind === "text" && !text!.trim()) return null;
  // Fades never overlap: scale both down to fit inside the span.
  let fadeIn = clamp(num(r.fadeInMs, 0), 0, MAX_FADE_MS);
  let fadeOut = clamp(num(r.fadeOutMs, 0), 0, MAX_FADE_MS);
  const span = (end - start) * 1000;
  if (fadeIn + fadeOut > span) {
    const f = span / (fadeIn + fadeOut);
    fadeIn = Math.floor(fadeIn * f);
    fadeOut = Math.floor(fadeOut * f);
  }
  return {
    id: typeof r.id === "string" && r.id.length > 0 ? r.id : newAnnotationId(),
    kind,
    start,
    end,
    x,
    y,
    w,
    h,
    color:
      typeof r.color === "string" && /^#[0-9a-fA-F]{6}$/.test(r.color)
        ? r.color.toLowerCase()
        : ANNOTATION_COLORS[0],
    stroke: clamp(num(r.stroke, 6), 1, 40),
    fontSize: clamp(num(r.fontSize, 64), 8, 200),
    ...(kind === "box" && r.filled === true ? { filled: true } : {}),
    ...(text !== undefined ? { text } : {}),
    ...(fadeIn > 0 ? { fadeInMs: fadeIn } : {}),
    ...(fadeOut > 0 ? { fadeOutMs: fadeOut } : {}),
    ...(r.followZoom === true ? { followZoom: true } : {}),
  };
}

/**
 * Make any stored value into valid annotations, sorted by start. Junk is
 * dropped; at most MAX_ANNOTATIONS valid ones are kept, in stored order.
 */
export function sanitizeAnnotations(raw: unknown, total: number): Annotation[] {
  if (!Array.isArray(raw)) return [];
  const seen = new Set<string>();
  const out: Annotation[] = [];
  for (const item of raw) {
    if (out.length >= MAX_ANNOTATIONS) break;
    const a = sanitizeAnnotation(item, total);
    if (!a) continue;
    if (seen.has(a.id)) a.id = newAnnotationId();
    seen.add(a.id);
    out.push(a);
  }
  return out.sort((a, b) => a.start - b.start || a.end - b.end);
}

/** A fresh annotation of `kind` starting at `at` (output seconds). */
export function makeAnnotation(kind: AnnotationKind, at: number, total: number): Annotation | null {
  const start = clamp(at, 0, Math.max(0, total - MIN_ANNOTATION_SEC));
  return sanitizeAnnotation(
    {
      kind,
      start,
      end: Math.min(total, start + DEFAULT_ANNOTATION_SEC),
      ...(kind === "text"
        ? { x: 0.1, y: 0.1, w: 0.5, h: 0.15, text: "Text" }
        : kind === "arrow"
          ? { x: 0.3, y: 0.3, w: 0.2, h: 0.15 }
          : { x: 0.35, y: 0.3, w: 0.3, h: 0.3 }),
      fadeInMs: 200,
      fadeOutMs: 200,
    },
    total,
  );
}

/** 0..1 visibility at output time `t` (linear fades, the same as ASS `\fad`). */
export function annotationOpacity(a: Annotation, t: number): number {
  if (t < a.start || t >= a.end) return 0;
  const fin = (a.fadeInMs ?? 0) / 1000;
  const fout = (a.fadeOutMs ?? 0) / 1000;
  let o = 1;
  if (fin > 0) o = Math.min(o, (t - a.start) / fin);
  if (fout > 0) o = Math.min(o, (a.end - t) / fout);
  return clamp(o, 0, 1);
}

/**
 * Arrow outline in frame pixels: a shaft of width `stroke` and a triangular
 * head (4 x stroke long and wide, never longer than the arrow). Shared shape
 * with `arrow_polygon` in annotations_export.rs.
 */
export function arrowPolygon(
  x1: number,
  y1: number,
  x2: number,
  y2: number,
  stroke: number,
): Array<[number, number]> {
  const len = Math.hypot(x2 - x1, y2 - y1);
  if (len < 1e-6) return [];
  const dx = (x2 - x1) / len,
    dy = (y2 - y1) / len;
  const nx = -dy,
    ny = dx;
  const head = Math.min(len, stroke * 4);
  const hw = stroke * 2;
  const sw = stroke / 2;
  const bx = x2 - dx * head,
    by = y2 - dy * head;
  return [
    [x1 + nx * sw, y1 + ny * sw],
    [bx + nx * sw, by + ny * sw],
    [bx + nx * hw, by + ny * hw],
    [x2, y2],
    [bx - nx * hw, by - ny * hw],
    [bx - nx * sw, by - ny * sw],
    [x1 - nx * sw, y1 - ny * sw],
  ];
}

/**
 * Re-time annotations after an edit, the same way zoom regions follow their
 * content (`retimeZoomRegions`): each span goes through source time, loses
 * the parts whose content was cut and closes up over the gap. One that loses
 * (almost) everything disappears; content now in two places gives two copies.
 * Only the first piece keeps the fade-in and only the last the fade-out.
 *
 * Speed and freeze-frame holds are honoured via the shared `timeMap` rules,
 * the same way `retimeZoomRegions` does it.
 */
export function retimeAnnotations(
  annotations: readonly Annotation[],
  oldTimeline: readonly TimelineEntry[],
  newTimeline: readonly TimelineEntry[],
  newTotal: number,
): Annotation[] {
  const out = retimeSpans(
    annotations,
    oldTimeline,
    newTimeline,
    newTotal,
    MIN_ANNOTATION_SEC,
    newAnnotationId,
  );
  // Re-validate: fades shrink with the span, too-short leftovers drop.
  return sanitizeAnnotations(out, newTotal);
}
