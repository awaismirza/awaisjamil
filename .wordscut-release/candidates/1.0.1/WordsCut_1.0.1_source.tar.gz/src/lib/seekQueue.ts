/** A source-time seek. sourceId also distinguishes an original from its proxy. */
export interface SeekTarget {
  readonly mediaId: string;
  readonly sourceId: string;
  readonly time: number;
  /** Use an exact currentTime assignment on drag release, rather than fastSeek. */
  readonly exact: boolean;
}

export interface SeekToken {
  readonly generation: number;
  readonly sequence: number;
  readonly mediaId: string;
  readonly sourceId: string;
}

export interface IssuedSeek extends SeekTarget {
  readonly token: SeekToken;
}

/**
 * Single-flight seek bookkeeping, independent of media elements or timers.
 * Execute each non-null return from request/complete, then acknowledge its token
 * when that specific operation finishes. A generic seeked event alone cannot
 * identify an operation: the adapter must retain its token and source identity.
 *
 * Requests arriving during a seek replace the queued target. An exact release
 * is always issued after the pending seek completes, even at the same time.
 * A changed media/source invalidates old operations immediately, allowing the
 * caller to switch sources without waiting for an event from the old decoder.
 */
export class SeekQueue {
  private generation = 0;
  private sequence = 0;
  private active: IssuedSeek | null = null;
  private queued: Readonly<SeekTarget> | null = null;

  request(target: SeekTarget): IssuedSeek | null {
    if (!Number.isFinite(target.time) || target.time < 0) {
      throw new RangeError("Seek time must be finite and non-negative");
    }
    const next = Object.freeze({ ...target });
    if (
      this.active &&
      (this.active.mediaId !== next.mediaId || this.active.sourceId !== next.sourceId)
    ) {
      this.reset();
    }
    if (this.active) {
      this.queued = next;
      return null;
    }
    return this.issue(next);
  }

  /** A stale completion cannot finish an active seek or release queued work. */
  complete(token: SeekToken): IssuedSeek | null {
    const current = this.active?.token;
    if (
      !current ||
      token.generation !== current.generation ||
      token.sequence !== current.sequence ||
      token.mediaId !== current.mediaId ||
      token.sourceId !== current.sourceId
    ) {
      return null;
    }
    this.active = null;
    const next = this.queued;
    this.queued = null;
    return next ? this.issue(next) : null;
  }

  /** Cancel queued work and invalidate all tokens, including after source reload. */
  reset(): void {
    this.generation += 1;
    this.active = null;
    this.queued = null;
  }

  private issue(target: SeekTarget): IssuedSeek {
    const token = Object.freeze({
      generation: this.generation,
      sequence: ++this.sequence,
      mediaId: target.mediaId,
      sourceId: target.sourceId,
    });
    this.active = Object.freeze({ ...target, token });
    return this.active;
  }
}
