/**
 * Clip-level (timeline) editing of the EDL: trim a clip's start or end, split,
 * delete, and move a cut. Pure module (no React, Tauri or store imports, same
 * rule as edl.ts), and every function returns a new Project.
 *
 * The transcript stays the source of truth for words, but a clip is just a
 * source-time range, so the timeline can reach audio the transcript has no word
 * for (a word Whisper missed). Extending a clip over audio that does have words
 * brings those words back, from `originalWords` (the untouched transcript of that
 * media). Words are never mutated; a word belongs to a clip when its midpoint
 * lies inside the clip's source range, so no word is ever owned by two clips.
 */

import {
  baseWordId,
  computeTimeline,
  entrySourceAt,
  inheritLineage,
  inheritTiming,
  insertOwnedHold,
  retimeAfterEdit,
  segmentHold,
  totalDuration,
  type Project,
  type Segment,
  type Word,
} from "./edl";
import { v4 as uuidv4 } from "uuid";

export { baseWordId };

/** A clip is never trimmed shorter than this, in seconds (about one frame). */
export const MIN_CLIP_SEC = 0.04;

export type ClipEdge = "start" | "end";

export interface ClipInfo {
  segmentId: string;
  mediaId: string;
  index: number;
  sourceIn: number;
  sourceOut: number;
  outputStart: number;
  outputEnd: number;
  wordCount: number;
}

export function listClips(project: Project): ClipInfo[] {
  const timeline = computeTimeline(project);
  return timeline.map((entry, index) => {
    const seg = project.segments[index]!;
    return {
      segmentId: seg.id,
      mediaId: seg.mediaId,
      index,
      sourceIn: seg.sourceIn,
      sourceOut: seg.sourceOut,
      outputStart: entry.outputStart,
      outputEnd: entry.outputEnd,
      wordCount: seg.words.length,
    };
  });
}

const mid = (w: Word) => (w.start + w.end) / 2;

/** Words of `pool` whose midpoint lies in [from, to). */
function wordsIn(pool: readonly Word[], from: number, to: number): Word[] {
  return pool.filter((w) => mid(w) >= from && mid(w) < to);
}

/** `<id>#<suffix>` for a word that would otherwise share an id with another clip. */
const suffixed = (w: Word): Word => ({
  ...w,
  id: `${baseWordId(w.id)}#${uuidv4().slice(0, 8)}`,
});

/**
 * Words pulled back from the original transcript keep their id unless that
 * would clash: when another clip (outside `except`) holds the same word, or the
 * clip already numbers its words with suffixes (it is a duplicate), they get a
 * fresh `#suffix`, so deleting a word in one copy never touches the other.
 */
function freshWordMaker(
  project: Project,
  except: readonly Segment[],
  own: readonly Word[],
): (w: Word) => Word {
  const held = new Set(
    project.segments
      .filter((s) => !except.includes(s))
      .flatMap((s) => s.words.map((w) => baseWordId(w.id))),
  );
  const usesSuffix = own.some((w) => w.id.includes("#"));
  return (w) => (usesSuffix || held.has(baseWordId(w.id)) ? suffixed(w) : w);
}

function indexOfSegment(project: Project, segmentId: string): number {
  return project.segments.findIndex((s) => s.id === segmentId);
}

/**
 * How far a clip's edge may move, as source times. It stays inside the media,
 * keeps a minimum length, and never reaches into the neighbouring clip's range
 * of the same media (which would play the same audio twice).
 */
export function edgeLimits(
  project: Project,
  segmentId: string,
  edge: ClipEdge,
): { min: number; max: number } | null {
  const i = indexOfSegment(project, segmentId);
  if (i < 0) return null;
  const seg = project.segments[i]!;
  const duration = project.media[seg.mediaId]?.duration ?? Number.POSITIVE_INFINITY;

  if (edge === "start") {
    const prev = project.segments[i - 1];
    // A neighbour only blocks when it is earlier in the same source.
    const floor =
      prev && prev.mediaId === seg.mediaId && prev.sourceOut <= seg.sourceIn ? prev.sourceOut : 0;
    return { min: floor, max: seg.sourceOut - MIN_CLIP_SEC };
  }
  const next = project.segments[i + 1];
  const ceil =
    next && next.mediaId === seg.mediaId && next.sourceIn >= seg.sourceOut
      ? next.sourceIn
      : duration;
  return { min: seg.sourceIn + MIN_CLIP_SEC, max: Math.min(ceil, duration) };
}

/**
 * Move one edge of a clip to `sourceTime` (clamped to `edgeLimits`). Extending
 * pulls in any `originalWords` found in the newly covered audio; trimming
 * inward drops the words that fall outside. Output after this clip shifts to
 * follow, and chapters and music keep pointing at the same content.
 */
export function trimClipEdge(
  project: Project,
  segmentId: string,
  edge: ClipEdge,
  sourceTime: number,
  originalWords?: readonly Word[],
): Project {
  const i = indexOfSegment(project, segmentId);
  const limits = edgeLimits(project, segmentId, edge);
  if (i < 0 || !limits || !Number.isFinite(sourceTime)) return project;
  const seg = project.segments[i]!;

  const t = Math.min(limits.max, Math.max(limits.min, sourceTime));
  const sourceIn = edge === "start" ? t : seg.sourceIn;
  const sourceOut = edge === "end" ? t : seg.sourceOut;
  if (sourceIn === seg.sourceIn && sourceOut === seg.sourceOut) return project;

  // Words that were already here stay while inside; originals add any that the
  // wider range now covers. De-duplicate by id.
  const byId = new Map<string, Word>();
  for (const w of wordsIn(seg.words, sourceIn, sourceOut)) byId.set(baseWordId(w.id), w);
  if (originalWords) {
    const fresh = freshWordMaker(project, [seg], seg.words);
    for (const w of wordsIn(originalWords, sourceIn, sourceOut)) {
      if (!byId.has(baseWordId(w.id))) byId.set(baseWordId(w.id), fresh(w));
    }
  }
  const words = [...byId.values()].sort((a, b) => a.start - b.start);

  const next: Segment = { ...seg, sourceIn, sourceOut, words };
  const segments = project.segments.map((s, k) => (k === i ? next : s));
  return retimeAfterEdit(project, { ...project, segments, updatedAt: new Date().toISOString() });
}

/**
 * Split the clip under `outputTime` into two touching clips. Nothing is
 * removed, so the output length is unchanged. A time on an existing cut, or too
 * close to either end, does nothing.
 */
export function splitClipAt(project: Project, outputTime: number): Project {
  const timeline = computeTimeline(project);
  const entry = timeline.find((e) => outputTime >= e.outputStart && outputTime < e.outputEnd);
  if (!entry) return project;
  const i = project.segments.findIndex((s) => s.id === entry.segmentId);
  const seg = project.segments[i]!;
  const at = entrySourceAt(entry, outputTime);
  if (at - seg.sourceIn < MIN_CLIP_SEC || seg.sourceOut - at < MIN_CLIP_SEC) return project;

  // Both halves keep the speed; the transition stays on the left, the hold on the right.
  // Lineage last: inheritTiming returns a new object and lineage is keyed by identity.
  const left: Segment = inheritLineage(
    inheritTiming(
      seg,
      {
        id: uuidv4(),
        mediaId: seg.mediaId,
        sourceIn: seg.sourceIn,
        sourceOut: at,
        words: wordsIn(seg.words, seg.sourceIn, at),
      },
      true,
      false,
    ),
    seg.id,
  );
  const right: Segment = inheritLineage(
    inheritTiming(
      seg,
      {
        id: uuidv4(),
        mediaId: seg.mediaId,
        sourceIn: at,
        sourceOut: seg.sourceOut,
        words: wordsIn(seg.words, at, seg.sourceOut),
      },
      false,
      true,
    ),
    seg.id,
  );
  const segments = [...project.segments.slice(0, i), left, right, ...project.segments.slice(i + 1)];
  return { ...project, segments, updatedAt: new Date().toISOString() };
}

const touch = (project: Project, segments: Segment[]): Project =>
  retimeAfterEdit(project, { ...project, segments, updatedAt: new Date().toISOString() });

/**
 * Ripple delete: remove a whole clip and close the gap. Chapters, zoom and music
 * after it move up; ones inside it go with it. Never empties the project.
 */
export function deleteClip(project: Project, segmentId: string): Project {
  const i = indexOfSegment(project, segmentId);
  if (i < 0 || project.segments.length <= 1) return project;
  return touch(
    project,
    project.segments.filter((_, k) => k !== i),
  );
}
export const rippleDeleteClip = deleteClip;

/**
 * Put a second copy of a clip straight after it. The copy plays the same source
 * range (repeats are allowed) and gets fresh ids, so deleting a word in one copy
 * leaves the other alone. Everything after shifts later by the clip's length.
 */
export function duplicateClip(project: Project, segmentId: string): Project {
  const i = indexOfSegment(project, segmentId);
  if (i < 0) return project;
  const seg = project.segments[i]!;
  const copy: Segment = {
    ...seg,
    id: uuidv4(),
    words: seg.words.map(suffixed),
  };
  // A hold that inserted narration owns is not copied without that narration:
  // the copy keeps only the user's own freeze.
  const own = segmentHold(seg) - insertOwnedHold(project, seg.id);
  if (own > 1e-9) copy.holdSec = own;
  else delete copy.holdSec;
  return touch(project, [
    ...project.segments.slice(0, i + 1),
    copy,
    ...project.segments.slice(i + 1),
  ]);
}

/**
 * Move a clip so it ends up at `toIndex` of the resulting order (clamped). Only
 * the order changes: source ranges and words are untouched, so the length is the
 * same and output time stays monotonic. Content follows its clip.
 */
export function moveClip(project: Project, segmentId: string, toIndex: number): Project {
  const i = indexOfSegment(project, segmentId);
  if (i < 0 || !Number.isFinite(toIndex)) return project;
  const to = Math.min(project.segments.length - 1, Math.max(0, Math.round(toIndex)));
  if (to === i) return project;
  const segments = project.segments.filter((_, k) => k !== i);
  segments.splice(to, 0, project.segments[i]!);
  return anchorOpening(project, touch(project, segments));
}

/**
 * After a reorder, keep the "opening" where it was: a chapter at 0:00 stays at
 * 0:00 and a music bed that starts at or before the first cut keeps its offset
 * (it is a bed under the whole piece, not under one clip). Everything else
 * follows its clip.
 */
function anchorOpening(before: Project, after: Project): Project {
  const firstCut = computeTimeline(before)[0]?.outputEnd ?? 0;
  const out: Project = { ...after };
  if (before.chapters?.length && after.chapters) {
    const home = new Set(before.chapters.filter((c) => c.outputTime === 0).map((c) => c.id));
    out.chapters = after.chapters.map((c) => (home.has(c.id) ? { ...c, outputTime: 0 } : c));
  }
  if (before.audioTracks?.length && after.audioTracks) {
    const bed = new Map(before.audioTracks.map((t) => [t.id, t.offsetSec]));
    out.audioTracks = after.audioTracks.map((t) => {
      const was = bed.get(t.id);
      return was !== undefined && was <= firstCut ? { ...t, offsetSec: was } : t;
    });
  }
  return out;
}

/** Move a clip one place (-1 earlier, +1 later) or more. */
export function moveClipBy(project: Project, segmentId: string, delta: number): Project {
  const i = indexOfSegment(project, segmentId);
  return i < 0 ? project : moveClip(project, segmentId, i + delta);
}

/**
 * Where a dragged clip lands when its left edge (the ghost's start) is at
 * `ghostStart` on the output timeline: the index of the nearest cut of the
 * timeline with the clip taken out (`dropBoundaries`), which is the index it
 * has after `moveClip`. Going by the start, not the centre, lets a long clip be
 * dragged past shorter ones, and the docked ghost and the indicator agree.
 */
export function dropIndexAt(project: Project, segmentId: string, ghostStart: number): number {
  const bounds = dropBoundaries(project, segmentId);
  let best = 0;
  for (let i = 1; i < bounds.length; i++)
    if (Math.abs(bounds[i]! - ghostStart) < Math.abs(bounds[best]! - ghostStart)) best = i;
  return best;
}

/**
 * Output times where a dragged clip can dock: every cut with the clip itself
 * taken out (start of the timeline included, its end too).
 */
export function dropBoundaries(project: Project, segmentId: string): number[] {
  const rest = { ...project, segments: project.segments.filter((s) => s.id !== segmentId) };
  const tl = computeTimeline(rest);
  return [0, ...tl.map((e) => e.outputEnd)];
}

/**
 * Roll a cut: move the end of `leftSegmentId` and the start of the clip after it
 * by the same amount, so the output length stays the same and only the point
 * where the two clips meet changes. Bounds are shared, because both edges move
 * together. A legacy word array belongs to the left clip's media; a map can
 * supply originals separately when the cut joins different media.
 */
export function rollEdit(
  project: Project,
  leftSegmentId: string,
  deltaSec: number,
  originalWords?: readonly Word[] | Readonly<Record<string, readonly Word[]>>,
): Project {
  const i = indexOfSegment(project, leftSegmentId);
  const right = project.segments[i + 1];
  if (i < 0 || !right || !Number.isFinite(deltaSec) || deltaSec === 0) return project;
  const left = project.segments[i]!;

  const leftDuration = project.media[left.mediaId]?.duration ?? Number.POSITIVE_INFINITY;
  // The partner's old edge is not a boundary: it moves by the same delta.
  const lo = Math.max(left.sourceIn + MIN_CLIP_SEC - left.sourceOut, -right.sourceIn);
  const hi = Math.min(
    leftDuration - left.sourceOut,
    right.sourceOut - MIN_CLIP_SEC - right.sourceIn,
  );
  const d = Math.min(hi, Math.max(lo, deltaSec));
  if (d === 0 || lo > hi) return project;

  const move = (segment: Segment, sourceIn: number, sourceOut: number): Segment => {
    const originals = Array.isArray(originalWords)
      ? segment.mediaId === left.mediaId
        ? originalWords
        : []
      : ((originalWords as Readonly<Record<string, readonly Word[]>> | undefined)?.[
          segment.mediaId
        ] ?? []);
    const fresh = freshWordMaker(project, [left, right], segment.words);
    const existing = [left, right]
      .filter((s) => s.mediaId === segment.mediaId)
      .flatMap((s) => s.words);
    const byId = new Map<string, Word>();
    // Keep corrected words already owned by this clip ahead of source originals.
    for (const word of wordsIn(
      [...segment.words, ...existing, ...originals],
      sourceIn,
      sourceOut,
    )) {
      if (!byId.has(baseWordId(word.id)))
        byId.set(baseWordId(word.id), originals.includes(word) ? fresh(word) : word);
    }
    return {
      ...segment,
      sourceIn,
      sourceOut,
      words: [...byId.values()].sort((a, b) => a.start - b.start),
    };
  };
  const segments = project.segments.map((segment, index) =>
    index === i
      ? move(left, left.sourceIn, left.sourceOut + d)
      : index === i + 1
        ? move(right, right.sourceIn + d, right.sourceOut)
        : segment,
  );
  return retimeAfterEdit(project, { ...project, segments, updatedAt: new Date().toISOString() });
}

/**
 * The nearest candidate to `time` within `tolerance`, or null. Used to snap a
 * dragged edge to word boundaries, the playhead or other clips' edges.
 */
export function snapTo(
  time: number,
  candidates: readonly number[],
  tolerance: number,
): number | null {
  let best: number | null = null;
  let bestDist = tolerance;
  for (const c of candidates) {
    const d = Math.abs(c - time);
    if (d <= bestDist) {
      best = c;
      bestDist = d;
    }
  }
  return best;
}

/** Source times worth snapping to for `mediaId`: word edges and clip edges. */
export function snapCandidates(
  project: Project,
  mediaId: string,
  originalWords?: readonly Word[],
  excludeSegmentId?: string,
): number[] {
  const out = new Set<number>();
  for (const w of originalWords ??
    project.segments.filter((s) => s.mediaId === mediaId).flatMap((s) => s.words)) {
    out.add(w.start);
    out.add(w.end);
  }
  for (const s of project.segments) {
    if (s.mediaId !== mediaId || s.id === excludeSegmentId) continue;
    out.add(s.sourceIn);
    out.add(s.sourceOut);
  }
  return [...out].sort((a, b) => a - b);
}

/** Total output length, re-exported so callers editing clips need only this module. */
export const outputDuration = totalDuration;
