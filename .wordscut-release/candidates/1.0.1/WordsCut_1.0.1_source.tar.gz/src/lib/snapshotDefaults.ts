import type { RecordingSnapshot } from "@/lib/ipc";

/** A snapshot of "nothing recording"; the starting point for every mirror. */
export function idleSnapshot(revision = 0): RecordingSnapshot {
  return {
    revision,
    sessionId: null,
    phase: "idle",
    backend: null,
    mode: null,
    elapsedSec: 0,
    markers: [],
    error: null,
    controllerHidden: false,
  };
}
