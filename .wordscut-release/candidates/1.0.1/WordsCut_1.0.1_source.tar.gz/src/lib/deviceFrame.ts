/**
 * Procedural device frames (browser window, laptop, phone, tablet) drawn
 * around the picture. Pure module, no React/Tauri imports. Everything is
 * generic rounded rectangles and circles: no artwork, no logos, no licences.
 *
 * `layoutFrame` is the single source of truth for the geometry. The preview
 * (`sceneCss.ts`) draws its shapes as CSS boxes and the exporter (`scene.rs`)
 * draws the very same integers as ffmpeg masks, so the two agree by
 * construction. Coordinates are canvas pixels.
 */

export const FRAME_KINDS = ["browser", "laptop", "phone", "tablet"] as const;
export type FrameKind = (typeof FRAME_KINDS)[number];
export type FrameTheme = "light" | "dark";

export interface DeviceFrame {
  kind: FrameKind;
  /** Browser: picks the default bar colour. Other kinds ignore it. */
  theme: FrameTheme;
  /** Bezel (or title bar) colour, `#rrggbb`. Absent = the kind's default. */
  color?: string;
  /** Browser only: text in the address pill. Plain text, no emoji. */
  title?: string;
  /** Phone only: the camera cutout over the picture. Absent = "dot". */
  cutout?: PhoneCutout;
}

export const PHONE_CUTOUTS = ["none", "dot", "notch"] as const;
export type PhoneCutout = (typeof PHONE_CUTOUTS)[number];

export const FRAME_TITLE_MAX = 80;

/** Corner radii in pixels: top-left, top-right, bottom-right, bottom-left. */
export type Radii = [number, number, number, number];

export interface PxRect {
  x: number;
  y: number;
  w: number;
  h: number;
}

export interface FrameShape extends PxRect {
  radii: Radii;
  /** `#rrggbb` */
  color: string;
  /** 0-1 */
  alpha: number;
  /** Part of the outline the shadow is cast from. */
  silhouette?: boolean;
}

export interface FrameText {
  text: string;
  /** Centre, canvas pixels. */
  cx: number;
  cy: number;
  fontPx: number;
  color: string;
}

export interface FrameLayout {
  /** Bounding box of the whole device. */
  outer: PxRect;
  /** The display area. Corners are clipped to `screenRadii`. */
  screen: PxRect;
  screenRadii: Radii;
  /** Drawn behind the picture. */
  below: FrameShape[];
  /** Drawn over the picture (notch, camera, traffic lights, address pill). */
  above: FrameShape[];
  texts: FrameText[];
}

export const DEFAULT_FRAME_COLOR: Record<FrameKind, string> = {
  browser: "#e6e6e9",
  laptop: "#1b1b1d",
  phone: "#18181a",
  tablet: "#1c1c1e",
};
export const DARK_BROWSER_COLOR = "#2c2c2f";

const HEX = /^#[0-9a-fA-F]{6}$/;

function isEmojiCp(n: number) {
  return (
    (n >= 0x1f000 && n <= 0x1faff) || n === 0xfe0f || n === 0x20e3 || (n >= 0xe0020 && n <= 0xe007f)
  );
}

/** Single line, no control characters or colour emoji (libass cannot draw them), capped. */
export function cleanFrameTitle(raw: unknown): string {
  if (typeof raw !== "string") return "";
  const text = Array.from(raw)
    .map((c) => {
      const n = c.codePointAt(0) ?? 0;
      return n < 0x20 || (n >= 0x7f && n <= 0x9f) ? " " : c;
    })
    .filter((c) => !isEmojiCp(c.codePointAt(0) ?? 0))
    .join("")
    .replace(/\s+/g, " ")
    .trim();
  return Array.from(text).slice(0, FRAME_TITLE_MAX).join("").trim();
}

/** A valid frame, or undefined when missing or malformed ("no frame"). */
export function sanitizeFrame(raw: unknown): DeviceFrame | undefined {
  if (typeof raw !== "object" || raw === null) return undefined;
  const r = raw as Record<string, unknown>;
  if (!FRAME_KINDS.includes(r.kind as FrameKind)) return undefined;
  const kind = r.kind as FrameKind;
  const theme: FrameTheme = r.theme === "dark" ? "dark" : "light";
  const title = kind === "browser" ? cleanFrameTitle(r.title) : "";
  return {
    kind,
    theme,
    ...(typeof r.color === "string" && HEX.test(r.color) ? { color: r.color.toLowerCase() } : {}),
    ...(title ? { title } : {}),
    ...(kind === "phone" && PHONE_CUTOUTS.includes(r.cutout as PhoneCutout)
      ? { cutout: r.cutout as PhoneCutout }
      : {}),
  };
}

// ---------------------------------------------------------------------------
// Colour helpers (pure, so both renderers get the same resolved hex)
// ---------------------------------------------------------------------------

function rgb(hex: string): [number, number, number] {
  return [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16)) as [number, number, number];
}

/** `a` moved `t` (0-1) of the way to `b`. */
export function mixHex(a: string, b: string, t: number): string {
  const [ar, ag, ab] = rgb(a);
  const [br, bg, bb] = rgb(b);
  const ch = (x: number, y: number) =>
    Math.round(x + (y - x) * t)
      .toString(16)
      .padStart(2, "0");
  return `#${ch(ar, br)}${ch(ag, bg)}${ch(ab, bb)}`;
}

/** Relative luminance 0-1 (sRGB, no gamma: good enough to pick light or dark text). */
function luma(hex: string) {
  const [r, g, b] = rgb(hex);
  return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
}

/** The frame's main colour: the user's choice, else the kind's default. */
export function frameColor(f: DeviceFrame): string {
  if (f.color) return f.color;
  return f.kind === "browser" && f.theme === "dark"
    ? DARK_BROWSER_COLOR
    : DEFAULT_FRAME_COLOR[f.kind];
}

// ---------------------------------------------------------------------------
// Geometry
// ---------------------------------------------------------------------------

/** Phone screens are 9:19.5 portrait, tablet screens 4:3 landscape; the rest follow the picture. */
export const PHONE_SCREEN_RATIO = 9 / 19.5;
export const TABLET_SCREEN_RATIO = 4 / 3;

/** Screen width/height for a kind. `null` = follows the picture. */
export function fixedScreenRatio(kind: FrameKind): number | null {
  return kind === "phone" ? PHONE_SCREEN_RATIO : kind === "tablet" ? TABLET_SCREEN_RATIO : null;
}

/** Every size and offset is an even whole number: 4:2:0 video places overlays on even pixels only. */
const r = (n: number) => Math.round(n / 2) * 2;

/** Estimated text width in em: wide glyphs (CJK, Hangul) count 1, the rest 0.58. */
function textEm(s: string) {
  return Array.from(s).reduce((sum, c) => {
    const n = c.codePointAt(0) ?? 0;
    return sum + (n >= 0x1100 ? 1 : 0.58);
  }, 0);
}

/** The text cut (with an ellipsis) so its estimated width fits `maxPx`. Same string for preview and export. */
export function fitText(text: string, fontPx: number, maxPx: number): string {
  const chars = Array.from(text);
  if (textEm(text) * fontPx <= maxPx) return text;
  while (chars.length > 1 && textEm(chars.join("") + "…") * fontPx > maxPx) chars.pop();
  return chars.join("").trimEnd() + "…";
}

interface Built {
  /** Screen rectangle relative to the device's top-left. */
  screen: PxRect;
  screenRadii: Radii;
  outerW: number;
  outerH: number;
  below: FrameShape[];
  above: FrameShape[];
  texts: FrameText[];
}

const all = (n: number): Radii => [n, n, n, n];
/** Radii limited to what a w x h box can hold (same limit in CSS and ffmpeg). */
const cap = (rad: Radii, w: number, h: number): Radii => {
  const m = Math.floor(Math.min(w, h) / 2);
  return rad.map((v) => Math.max(0, Math.min(v, m))) as Radii;
};
const shape = (
  x: number,
  y: number,
  w: number,
  h: number,
  radii: Radii,
  color: string,
  extra: Partial<FrameShape> = {},
): FrameShape => ({ x, y, w, h, radii: cap(radii, w, h), color, alpha: 1, ...extra });

/** One device around a `sw` x `sh` screen, with every size derived from the screen's shorter side. */
function build(f: DeviceFrame, sw: number, sh: number): Built {
  const u = Math.min(sw, sh);
  const color = frameColor(f);
  switch (f.kind) {
    case "browser": {
      const bar = Math.max(4, r(0.075 * u));
      const R = r(0.028 * u);
      const W = sw;
      const H = sh + bar;
      const body = shape(0, 0, W, H, all(R), color, { silhouette: true });
      const d = Math.max(2, r(0.36 * bar));
      const gap = r(0.28 * bar);
      const x0 = r(0.55 * bar);
      // Neutral grey dots (no brand colours); lighter on a dark bar.
      const dot = luma(color) > 0.5 ? "#b4b4ba" : "#6c6c72";
      const above: FrameShape[] = [dot, dot, dot].map((c, i) =>
        shape(x0 + i * (d + gap), r((bar - d) / 2), d, d, all(d), c),
      );
      const lightsEnd = x0 + 3 * d + 2 * gap;
      const texts: FrameText[] = [];
      const title = f.title ?? "";
      const pw = Math.min(r(0.5 * W), W - 2 * (lightsEnd + gap));
      if (title && pw >= 6 * bar) {
        const ph = Math.max(2, r(0.62 * bar));
        const light = luma(color) > 0.5;
        above.push(
          shape(
            r((W - pw) / 2),
            r((bar - ph) / 2),
            pw,
            ph,
            all(r(ph / 2)),
            mixHex(color, "#ffffff", light ? 0.55 : 0.1),
          ),
        );
        const fontPx = Math.round(0.4 * bar * 100) / 100;
        texts.push({
          text: fitText(title, fontPx, pw - ph),
          cx: W / 2,
          cy: bar / 2,
          fontPx,
          color: light ? "#4a4a50" : "#d4d4d9",
        });
      }
      return {
        screen: { x: 0, y: bar, w: sw, h: sh },
        screenRadii: cap([0, 0, R, R], sw, sh),
        outerW: W,
        outerH: H,
        below: [body],
        above,
        texts,
      };
    }
    case "laptop": {
      const t = Math.max(2, r(0.04 * u));
      const tb = Math.max(2, r(0.05 * u));
      const lidW = sw + 2 * t;
      const lidH = sh + t + tb;
      const baseW = lidW + 2 * r(0.05 * lidW);
      const baseH = Math.max(4, r(0.035 * u));
      const lidX = (baseW - lidW) / 2;
      const lid = shape(lidX, 0, lidW, lidH, [r(0.03 * u), r(0.03 * u), 2, 2], color, {
        silhouette: true,
      });
      const baseColor = mixHex(color, "#d0d0d5", 0.85);
      const base = shape(0, lidH, baseW, baseH, [0, 0, r(baseH / 2), r(baseH / 2)], baseColor, {
        silhouette: true,
      });
      const cd = Math.max(2, r(0.012 * u));
      const cam = shape(
        r((baseW - cd) / 2),
        r((t - cd) / 2),
        cd,
        cd,
        all(cd),
        mixHex(color, "#ffffff", 0.18),
      );
      return {
        screen: { x: lidX + t, y: t, w: sw, h: sh },
        screenRadii: cap(all(r(0.01 * u)), sw, sh),
        outerW: baseW,
        outerH: lidH + baseH,
        below: [lid, base],
        above: [cam],
        texts: [],
      };
    }
    case "phone": {
      const t = Math.max(2, r(0.05 * u));
      const W = sw + 2 * t;
      const H = sh + 2 * t;
      const Ro = r(0.16 * u);
      const body = shape(0, 0, W, H, all(Ro), color, { silhouette: true });
      // Generic camera cutout: a small dot (default), a plain notch, or nothing.
      const cutout = f.cutout ?? "dot";
      const above: FrameShape[] = [];
      if (cutout === "dot") {
        const d = Math.max(2, r(0.045 * u));
        above.push(shape(r((W - d) / 2), t + r(0.03 * u), d, d, all(d), "#050506"));
      } else if (cutout === "notch") {
        const nw = r(0.4 * u);
        const nh = Math.max(2, r(0.06 * u));
        above.push(shape(r((W - nw) / 2), t, nw, nh, [0, 0, r(nh / 2), r(nh / 2)], color));
      }
      return {
        screen: { x: t, y: t, w: sw, h: sh },
        screenRadii: cap(all(Math.max(0, Ro - t)), sw, sh),
        outerW: W,
        outerH: H,
        below: [body],
        above,
        texts: [],
      };
    }
    case "tablet": {
      const t = Math.max(2, r(0.07 * u));
      const W = sw + 2 * t;
      const H = sh + 2 * t;
      const Ro = r(0.09 * u);
      const body = shape(0, 0, W, H, all(Ro), color, { silhouette: true });
      const cd = Math.max(2, r(0.02 * u));
      const cam = shape(
        r((W - cd) / 2),
        r((t - cd) / 2),
        cd,
        cd,
        all(cd),
        mixHex(color, "#ffffff", 0.18),
      );
      return {
        screen: { x: t, y: t, w: sw, h: sh },
        screenRadii: cap(all(Math.max(0, Ro - t)), sw, sh),
        outerW: W,
        outerH: H,
        below: [body],
        above: [cam],
        texts: [],
      };
    }
  }
}

const evenPx = (n: number) => Math.max(2, Math.round(n / 2) * 2);

/** Screen size for a screen shorter side `u` and width/height `ratio`. */
function screenFor(u: number, ratio: number): [number, number] {
  return ratio >= 1 ? [evenPx(u * ratio), evenPx(u)] : [evenPx(u), evenPx(u / ratio)];
}

function shift(s: FrameShape, dx: number, dy: number): FrameShape {
  return { ...s, x: s.x + dx, y: s.y + dy };
}

export interface FramedLayout {
  frame: FrameLayout;
  /** Where the picture goes: inside the screen, centred, picture aspect kept. */
  content: PxRect;
}

/**
 * Place a device around a picture of width/height `pictureRatio`, as large as
 * fits `avail`, centred on `canvas`. Browser and laptop screens take the
 * picture's aspect (the picture fills the screen); phone and tablet screens
 * have a fixed aspect and the picture is letterboxed inside (contain).
 */
export function layoutFrame(
  f: DeviceFrame,
  pictureRatio: number,
  avail: { w: number; h: number },
  canvas: { w: number; h: number },
): FramedLayout {
  const adaptive = fixedScreenRatio(f.kind) === null;
  const ratio = fixedScreenRatio(f.kind) ?? (pictureRatio > 0 ? pictureRatio : 16 / 9);
  // Size at a reference screen, then scale: the chrome is linear in the screen's shorter side.
  const ref = build(f, ...screenFor(1000, ratio));
  let u = 1000 * Math.min(Math.max(2, avail.w) / ref.outerW, Math.max(2, avail.h) / ref.outerH);
  let b = build(f, ...screenFor(u, ratio));
  // Rounding can add a pixel or two: shrink until the device fits the canvas.
  for (let i = 0; i < 40 && (b.outerW > canvas.w || b.outerH > canvas.h) && u > 8; i++) {
    u *= 0.98;
    b = build(f, ...screenFor(u, ratio));
  }
  const ox = r((canvas.w - b.outerW) / 2);
  const oy = r((canvas.h - b.outerH) / 2);
  const screen = { ...b.screen, x: b.screen.x + ox, y: b.screen.y + oy };
  let content = screen;
  if (!adaptive) {
    // contain: the largest picture-aspect rectangle inside the screen
    let w = screen.w;
    let h = w / pictureRatio;
    if (h > screen.h) {
      h = screen.h;
      w = h * pictureRatio;
    }
    w = Math.min(evenPx(w), screen.w);
    h = Math.min(evenPx(h), screen.h);
    content = {
      x: screen.x + r((screen.w - w) / 2),
      y: screen.y + r((screen.h - h) / 2),
      w,
      h,
    };
  }
  return {
    content,
    frame: {
      outer: { x: ox, y: oy, w: b.outerW, h: b.outerH },
      screen,
      screenRadii: b.screenRadii,
      below: b.below.map((s) => shift(s, ox, oy)),
      above: b.above.map((s) => shift(s, ox, oy)),
      texts: b.texts.map((t) => ({ ...t, cx: t.cx + ox, cy: t.cy + oy })),
    },
  };
}
