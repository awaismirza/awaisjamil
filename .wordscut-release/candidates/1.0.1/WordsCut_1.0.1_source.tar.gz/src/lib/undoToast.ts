/** Toast for a bulk edit that offers one-click Undo, so a cut is never silent. */

import { useProjectStore } from "@/stores/projectStore";
import { useUIStore } from "@/stores/uiStore";

export function pushUndoToast(title: string, description?: string): void {
  useUIStore.getState().pushToast({
    title,
    description,
    action: {
      label: "Undo",
      onClick: () => useProjectStore.temporal.getState().undo(),
    },
  });
}
