/**
 * Pure Project operations shared by the Zustand store and the agent tools.
 * No React, Tauri or store imports (same rule as edl.ts). Every function
 * returns a new Project, or the same reference when nothing changed.
 */

import { deleteWords, type Project, type Segment } from "./edl";
import type { ZoomRegion } from "./zoom";

const EDGE_PUNCT = /^[\s.,!?;:"'()[\]{}—–-]+|[\s.,!?;:"'()[\]{}—–-]+$/g;

/** Strip surrounding punctuation/whitespace and lowercase. */
export function normaliseToken(s: string): string {
  return s.trim().replace(EDGE_PUNCT, "").toLowerCase();
}

/** The project with these zoom regions; none at all leaves the field off the file. */
export function withZoom(project: Project, regions: ZoomRegion[]): Project {
  const next: Project = { ...project, updatedAt: new Date().toISOString() };
  if (regions.length > 0) next.zoomRegions = regions;
  else delete next.zoomRegions;
  return next;
}

/** Replace all chapters; stable ids are assigned here. */
export function setChapters(
  project: Project,
  chapters: ReadonlyArray<{ title: string; outputTime: number }>,
): Project {
  return {
    ...project,
    chapters: chapters.map((c) => ({
      id: crypto.randomUUID(),
      title: c.title,
      outputTime: c.outputTime,
    })),
    updatedAt: new Date().toISOString(),
  };
}

/** Ids of every word whose source-media span overlaps [srcStart, srcEnd]. */
export function wordIdsInSourceRange(project: Project, srcStart: number, srcEnd: number): string[] {
  const ids: string[] = [];
  for (const seg of project.segments) {
    for (const w of seg.words) {
      if (w.end > srcStart && w.start < srcEnd) ids.push(w.id);
    }
  }
  return ids;
}

/** Delete every word overlapping a source-time range. `count` is the words removed. */
export function deleteBySourceRange(
  project: Project,
  srcStart: number,
  srcEnd: number,
): { project: Project; count: number } {
  const ids = wordIdsInSourceRange(project, srcStart, srcEnd);
  if (ids.length === 0) return { project, count: 0 };
  return { project: deleteWords(project, new Set(ids)), count: ids.length };
}

/** Delete every word whose normalised text is one of `tokens`. */
export function deleteWordsByText(
  project: Project,
  tokens: ReadonlySet<string>,
): { project: Project; count: number } {
  const ids: string[] = [];
  for (const seg of project.segments) {
    for (const w of seg.words) {
      if (tokens.has(normaliseToken(w.text))) ids.push(w.id);
    }
  }
  if (ids.length === 0) return { project, count: 0 };
  return { project: deleteWords(project, new Set(ids)), count: ids.length };
}

export interface ReplaceOptions {
  caseSensitive?: boolean;
  wholeWord?: boolean;
}

/**
 * Replace word text. Whole-word mode compares the punctuation-stripped token
 * and keeps trailing punctuation; otherwise every substring occurrence is
 * replaced. Timing is untouched. Returns the same project when nothing matched.
 */
export function replaceText(
  project: Project,
  find: string,
  replace: string,
  opts?: ReplaceOptions,
): { project: Project; count: number } {
  const caseSensitive = opts?.caseSensitive ?? false;
  const wholeWord = opts?.wholeWord ?? true;
  const needle = caseSensitive ? find : find.toLowerCase();
  if (needle.length === 0) return { project, count: 0 };
  let replaced = 0;
  const nextSegments = project.segments.map((seg) => ({
    ...seg,
    words: seg.words.map((w) => {
      const haystack = caseSensitive ? w.text : w.text.toLowerCase();
      if (wholeWord) {
        const norm = caseSensitive ? w.text.trim().replace(EDGE_PUNCT, "") : normaliseToken(w.text);
        if (norm === needle) {
          replaced++;
          // Preserve trailing punctuation so the transcript reads naturally
          const trailing = w.text.match(/[\s.,!?;:"'()[\]{}—–-]+$/)?.[0] ?? "";
          return { ...w, text: replace + trailing };
        }
        return w;
      }
      if (!haystack.includes(needle)) return w;
      const re = new RegExp(
        find.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"),
        caseSensitive ? "g" : "gi",
      );
      const newText = w.text.replace(re, () => {
        replaced++;
        return replace;
      });
      return { ...w, text: newText };
    }),
  }));
  if (replaced === 0) return { project, count: 0 };
  return {
    project: { ...project, segments: nextSegments, updatedAt: new Date().toISOString() },
    count: replaced,
  };
}

export interface WordMatch {
  wordIds: string[];
  /** The matched words joined with spaces. */
  text: string;
  segmentId: string;
  /** Matched words plus a few neighbours, for display. */
  context: string;
}

export interface FindOptions {
  wholeWord?: boolean;
  caseSensitive?: boolean;
  /** Neighbouring words on each side in `context`. Default 6. */
  contextWords?: number;
}

/**
 * Find a query in the transcript. Multi-word queries match consecutive words
 * inside one segment. Whole-word matching ignores surrounding punctuation.
 */
export function findWords(project: Project, query: string, opts: FindOptions = {}): WordMatch[] {
  const wholeWord = opts.wholeWord ?? true;
  const caseSensitive = opts.caseSensitive ?? false;
  const ctxN = opts.contextWords ?? 6;
  const fold = (s: string) => (caseSensitive ? s : s.toLowerCase());
  const parts = query
    .trim()
    .split(/\s+/)
    .filter((p) => p.length > 0)
    .map((p) => (wholeWord ? fold(p.replace(EDGE_PUNCT, "")) : fold(p)))
    .filter((p) => p.length > 0);
  if (parts.length === 0) return [];

  const norm = (text: string) =>
    wholeWord ? fold(text.trim().replace(EDGE_PUNCT, "")) : fold(text);
  const hit = (text: string, part: string) =>
    wholeWord ? norm(text) === part : fold(text).includes(part);

  const out: WordMatch[] = [];
  const scan = (seg: Segment) => {
    const words = seg.words;
    for (let i = 0; i + parts.length <= words.length; i++) {
      let ok = true;
      for (let k = 0; k < parts.length && ok; k++) ok = hit(words[i + k]!.text, parts[k]!);
      if (!ok) continue;
      const slice = words.slice(i, i + parts.length);
      out.push({
        wordIds: slice.map((w) => w.id),
        text: slice.map((w) => w.text.trim()).join(" "),
        segmentId: seg.id,
        context: words
          .slice(Math.max(0, i - ctxN), i + parts.length + ctxN)
          .map((w) => w.text.trim())
          .join(" "),
      });
      i += parts.length - 1;
    }
  };
  for (const seg of project.segments) scan(seg);
  return out;
}
