/** Per-destination saves. Callers must treat enqueued snapshots as immutable. */
export type SaveOutcome<T> = {
  status: "saved" | "superseded";
  destination: string;
  snapshot: T;
};

export interface SaveTiming {
  destination: string;
  durationMs: number;
  succeeded: boolean;
}

interface Request<T> {
  snapshot: T;
  resolve: (outcome: SaveOutcome<T>) => void;
  reject: (error: unknown) => void;
}

interface DestinationQueue<T> {
  pending?: Request<T>;
}

/** Lexical macOS/POSIX normalization. Symlink aliases require caller resolution. */
export function normalizeSaveDestination(path: string): string {
  if (!path || path.includes("\0")) throw new Error("Invalid save destination");
  const absolute = path.startsWith("/");
  const parts: string[] = [];
  for (const part of path.split("/")) {
    if (!part || part === ".") continue;
    if (part === ".." && parts.length && parts.at(-1) !== "..") parts.pop();
    else if (part !== ".." || !absolute) parts.push(part);
  }
  return `${absolute ? "/" : ""}${parts.join("/")}` || ".";
}

/**
 * One active write and at most one waiting snapshot per destination. Replaced
 * waiting requests resolve as superseded, never as saved. Failed writes reject
 * only their own request; the latest waiting save still runs.
 */
export class SaveQueue<T> {
  private readonly queues = new Map<string, DestinationQueue<T>>();

  constructor(
    private readonly write: (snapshot: T, destination: string) => Promise<void>,
    private readonly onDuration?: (timing: SaveTiming) => void,
    private readonly now: () => number = () => Date.now(),
  ) {}

  enqueue(destination: string, snapshot: T): Promise<SaveOutcome<T>> {
    const path = normalizeSaveDestination(destination);
    return new Promise((resolve, reject) => {
      const request = { snapshot, resolve, reject };
      const queue = this.queues.get(path);
      if (queue) {
        queue.pending?.resolve({
          status: "superseded",
          destination: path,
          snapshot: queue.pending.snapshot,
        });
        queue.pending = request;
      } else {
        const next: DestinationQueue<T> = {};
        this.queues.set(path, next);
        void this.drain(path, next, request);
      }
    });
  }

  private async drain(path: string, queue: DestinationQueue<T>, first: Request<T>) {
    let request: Request<T> | undefined = first;
    while (request) {
      const startedAt = this.now();
      let succeeded = false;
      try {
        await this.write(request.snapshot, path);
        succeeded = true;
        request.resolve({ status: "saved", destination: path, snapshot: request.snapshot });
      } catch (error) {
        request.reject(error);
      } finally {
        // Diagnostics must never interrupt persistence or strand waiting saves.
        try {
          this.onDuration?.({ destination: path, durationMs: this.now() - startedAt, succeeded });
        } catch {
          /* best-effort diagnostic */
        }
      }
      request = queue.pending;
      queue.pending = undefined;
    }
    this.queues.delete(path);
  }
}
