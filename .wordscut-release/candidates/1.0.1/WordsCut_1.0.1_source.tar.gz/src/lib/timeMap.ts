/**
 * The one output↔source rule for a timeline entry, shared by every consumer of
 * output time (preview, transcript, captions, zoom, chapters, music, export
 * mirrors in Rust). Pure; its own module so `zoom.ts` can use it without an
 * import cycle through `edl.ts`.
 *
 * Inside an entry, footage plays from `outputStart` to `outputEnd - holdSec`
 * at `speed` source seconds per output second; the remaining `holdSec` shows
 * the frame at `sourceOut`. Transitions never move output time.
 */
import type { TimelineEntry } from "./edl";

/** Output time where an entry's footage ends and its hold (if any) begins. */
export function entryPlayEnd(e: TimelineEntry): number {
  return e.outputEnd - (e.holdSec ?? 0);
}

/** Source time shown at output time `t` inside entry `e`, clamped to its source range. */
export function entrySourceAt(
  e: Pick<TimelineEntry, "outputStart" | "sourceIn" | "sourceOut" | "speed">,
  t: number,
): number {
  const local = Math.max(0, t - e.outputStart);
  return Math.min(e.sourceOut, e.sourceIn + local * (e.speed ?? 1));
}

/**
 * Across an edit, a time inside an old entry's hold follows the hold of the
 * same frame (same owner and `sourceOut`) in the new timeline, at the same
 * offset, clamped. `same` says which new entries continue `e` (default: same
 * media; the EDL passes segment-id lineage so a duplicated clip's hold lands
 * on the copy). `undefined` when `t` is not in a hold; null when that hold is gone.
 */
export function mapHold<T extends TimelineEntry>(
  e: TimelineEntry,
  newTl: readonly T[],
  t: number,
  same: (n: T) => boolean = (n) => n.mediaId === e.mediaId,
): number | null | undefined {
  const playEnd = entryPlayEnd(e);
  if (!e.holdSec || t < playEnd) return undefined;
  const n = newTl.find((x) => x.holdSec && same(x) && x.sourceOut === e.sourceOut);
  if (!n) return null;
  return entryPlayEnd(n) + Math.min(t - playEnd, Math.max(0, n.holdSec! - 1e-6));
}

/** Output time where source time `s` plays inside entry `e`. Not clamped. */
export function entryOutputAt(
  e: Pick<TimelineEntry, "outputStart" | "sourceIn" | "speed">,
  s: number,
): number {
  return e.outputStart + (s - e.sourceIn) / (e.speed ?? 1);
}

/** A span on the output timeline that follows its content through edits. */
export interface RetimeSpan {
  id: string;
  start: number;
  end: number;
  fadeInMs?: number;
  fadeOutMs?: number;
}

/** Pieces closer than this after an edit are one span again. */
const RETIME_JOIN_SEC = 0.02;

/**
 * Re-time spans after an edit, the same way zoom regions follow their content
 * (`retimeZoomRegions`): each span goes through source time, loses the parts
 * whose content was cut and closes up over the gap. One that keeps less than
 * `minSec` disappears; content now in two places gives two pieces (the later
 * ones with a fresh id from `newId`). Only the first piece keeps the fade-in and
 * only the last the fade-out. Speed and freeze-frame holds follow the rules
 * above. Shared by annotations, media overlays and privacy masks, which each
 * re-validate the result with their own sanitizer.
 */
export function retimeSpans<T extends RetimeSpan>(
  items: readonly T[],
  oldTimeline: readonly TimelineEntry[],
  newTimeline: readonly TimelineEntry[],
  newTotal: number,
  minSec: number,
  newId: () => string,
): T[] {
  const out: T[] = [];
  for (const a of items) {
    const pieces: Array<{ start: number; end: number }> = [];
    for (const oe of oldTimeline) {
      const lo = Math.max(a.start, oe.outputStart);
      const hi = Math.min(a.end, oe.outputEnd);
      if (hi <= lo) continue;
      // Footage goes through source time (speed may differ on either side)...
      const playEnd = entryPlayEnd(oe);
      const srcLo = entrySourceAt(oe, lo);
      const srcHi = entrySourceAt(oe, Math.min(hi, playEnd));
      for (const ne of newTimeline) {
        if (ne.mediaId !== oe.mediaId) continue;
        const s = Math.max(srcLo, ne.sourceIn);
        const e = Math.min(srcHi, ne.sourceOut);
        if (e <= s) continue;
        pieces.push({ start: entryOutputAt(ne, s), end: entryOutputAt(ne, e) });
      }
      // ...and the part over a freeze frame follows that same held frame.
      if (hi > playEnd) {
        const s = mapHold(oe, newTimeline, Math.max(lo, playEnd));
        const e = mapHold(oe, newTimeline, hi - 1e-9);
        if (typeof s === "number" && typeof e === "number")
          pieces.push({ start: s, end: e + 1e-9 });
      }
    }
    pieces.sort((p, q) => p.start - q.start);
    const joined: typeof pieces = [];
    for (const p of pieces) {
      const last = joined[joined.length - 1];
      if (last && p.start - last.end <= RETIME_JOIN_SEC) last.end = Math.max(last.end, p.end);
      else joined.push({ ...p });
    }
    const kept = joined.filter((p) => p.end - p.start >= minSec);
    kept.forEach((p, i) => {
      const piece: T = {
        ...a,
        id: i === 0 ? a.id : newId(),
        start: Math.max(0, p.start),
        end: Math.min(newTotal, p.end),
      };
      if (i > 0) delete piece.fadeInMs;
      if (i < kept.length - 1) delete piece.fadeOutMs;
      out.push(piece);
    });
  }
  return out;
}
