/**
 * Pure logic behind the compact recorder setup panel: mode mapping, what the
 * chosen source needs, why Start is disabled, capture-area geometry and the
 * "your device went away" notices. No React, no Tauri.
 */

import type {
  AreaRect,
  DisplayInfo,
  PermissionKind,
  PermissionState,
  RecordMode,
  RecordOptions,
  RecordingDevices,
  SourceKind,
} from "@/lib/ipc";

/** The three top-level choices in the panel. */
export type UiMode = "screen" | "camera" | "audio";

/** Mirrors `MIN_AREA_POINTS` in `native_capture.rs`. */
export const MIN_AREA_POINTS = 32;

export function uiModeOf(mode: RecordMode): UiMode {
  if (mode === "camera") return "camera";
  if (mode === "voiceover") return "audio";
  return "screen";
}

/** Screen + camera is "Screen" with the camera row switched on. */
export function modeFor(ui: UiMode, withCamera: boolean): RecordMode {
  if (ui === "camera") return "camera";
  if (ui === "audio") return "voiceover";
  return withCamera ? "screen-camera" : "screen";
}

export const needsScreen = (mode: RecordMode) => mode === "screen" || mode === "screen-camera";
export const needsCamera = (mode: RecordMode) => mode === "screen-camera" || mode === "camera";

export const isNative = (devices: RecordingDevices | null) => devices?.backend === "native";

/** The source the panel treats as selected; window/area need the native recorder. */
export function effectiveSource(opts: RecordOptions, devices: RecordingDevices | null): SourceKind {
  if (!isNative(devices)) return "display";
  return opts.sourceKind ?? "display";
}

/**
 * What goes to Rust: only the fields that belong to the chosen source, so a
 * stale window id or area from an earlier choice can never leak into a take.
 */
export function toStartOptions(
  opts: RecordOptions,
  devices: RecordingDevices | null,
): RecordOptions {
  const { windowId, area, ...rest } = opts;
  const out: RecordOptions = { ...rest };
  delete out.sourceKind;
  // Key identity is opt-in and native-only; the second flag means nothing without the first.
  if (!out.recordKeyIdentity || !isNative(devices) || !needsScreen(opts.mode)) {
    delete out.recordKeyIdentity;
    delete out.recordAllCharacters;
  }
  if (!needsScreen(opts.mode)) {
    delete out.systemAudio;
    return out;
  }
  const kind = effectiveSource(opts, devices);
  if (kind === "window" && windowId !== undefined) out.windowId = windowId;
  if (kind === "area" && area) out.area = area;
  return out;
}

/** Shown wherever the key-identity option is offered. */
export const KEY_IDENTITY_NOTE =
  "Records the names of shortcut keys (with ⌘ or ⌃) and keys like arrows, Esc and F-keys. In Screen and Area recording this includes keys pressed in any app while recording; in Window recording only while that window's app is in front. Password fields are normally hidden or missing because macOS withholds those presses, but Terminal or iTerm sudo and ssh prompts and many Electron or web fields are not protected unless Secure Keyboard Entry is on. Stays on between launches; shown as “Key names ON” while recording.";
export const ALL_CHARACTERS_NOTE =
  "Also records every character you type, plus Return, Tab, Space and Delete, so the log spells out what you typed, including anything typed into an unprotected password prompt. Resets to off each time WordsCut starts.";

export type Permissions = Partial<Record<PermissionKind, PermissionState>> | null | undefined;

/** Permissions the chosen options need before a take can start. */
export function requiredPermissions(opts: RecordOptions): PermissionKind[] {
  const out: PermissionKind[] = [];
  if (needsScreen(opts.mode)) out.push("screenRecording");
  if (needsCamera(opts.mode)) out.push("camera");
  if (opts.audioIndex !== undefined || opts.mode === "voiceover") out.push("microphone");
  // Key names come from the same event tap as typing bursts: macOS gates it behind Input Monitoring.
  if (opts.recordKeyIdentity && needsScreen(opts.mode)) out.push("inputMonitoring");
  return out;
}

export const PERMISSION_LABEL: Record<PermissionKind, string> = {
  screenRecording: "Screen Recording",
  camera: "Camera",
  microphone: "Microphone",
  inputMonitoring: "Input Monitoring",
};

export interface PermissionIssue {
  kind: PermissionKind;
  state: PermissionState;
}

/** Required permissions that are not granted. Only the native helper reports them. */
export function permissionIssues(
  opts: RecordOptions,
  devices: RecordingDevices | null,
): PermissionIssue[] {
  if (!isNative(devices) || !devices?.permissions) return [];
  const perms = devices.permissions;
  return requiredPermissions(opts).flatMap((kind) => {
    const state = perms[kind];
    return state && state !== "granted" ? [{ kind, state }] : [];
  });
}

export function isValidArea(area: AreaRect | undefined, display: DisplayInfo | undefined): boolean {
  if (!area) return false;
  const finite = [area.x, area.y, area.width, area.height].every(Number.isFinite);
  if (!finite || area.x < 0 || area.y < 0) return false;
  if (area.width < MIN_AREA_POINTS || area.height < MIN_AREA_POINTS) return false;
  if (
    display &&
    (area.x + area.width > display.width + 0.5 || area.y + area.height > display.height + 0.5)
  ) {
    return false;
  }
  return true;
}

/**
 * Why Start must stay disabled, as a sentence the user can act on — or null
 * when recording can begin. A permission that was never asked (`notDetermined`)
 * does not block: starting asks for it.
 */
export function startBlocker(
  opts: RecordOptions,
  devices: RecordingDevices | null,
  devicesError: string | null,
): string | null {
  if (devicesError) return "Devices could not be read. Try Refresh.";
  if (!devices) return "Looking for screens and devices…";
  const screens = devices.video.filter((d) => d.isScreen);
  const cameras = devices.video.filter((d) => !d.isScreen);

  if (needsScreen(opts.mode)) {
    const kind = effectiveSource(opts, devices);
    if (screens.length === 0) return "No display found.";
    if (kind === "window") {
      if (!devices.windows?.some((w) => w.id === opts.windowId))
        return "Choose a window to record.";
    } else {
      const screen = screens.find((s) => s.index === opts.screenIndex);
      if (!screen) return "Choose a display to record.";
      if (kind === "area") {
        const info = devices.displays?.find((d) => d.index === screen.index);
        if (!isValidArea(opts.area, info)) return "Drag on the preview to choose an area.";
      }
    }
  }
  if (needsCamera(opts.mode)) {
    if (cameras.length === 0) return "No camera found. Connect one or switch to Screen.";
    if (!cameras.some((c) => c.index === opts.cameraIndex)) return "Choose a camera.";
  }
  if (opts.mode === "voiceover") {
    if (devices.audio.length === 0) return "No microphone found. Connect one to record audio.";
    if (!devices.audio.some((m) => m.index === opts.audioIndex)) return "Choose a microphone.";
  } else if (
    opts.audioIndex !== undefined &&
    !devices.audio.some((m) => m.index === opts.audioIndex)
  ) {
    return "The selected microphone is gone. Choose another or turn the microphone off.";
  }
  const blocked = permissionIssues(opts, devices).find(
    (p) => p.state === "denied" || p.state === "restricted",
  );
  if (blocked?.kind === "inputMonitoring") {
    return "Input Monitoring access is off, so key names cannot be recorded. Turn it on in System Settings, or turn off Record key names.";
  }
  if (blocked) {
    const label = PERMISSION_LABEL[blocked.kind];
    return blocked.state === "restricted"
      ? `${label} is restricted on this Mac.`
      : `${label} access is off. Turn it on in System Settings.`;
  }
  return null;
}

// ---------------------------------------------------------------------------
// Capture area
// ---------------------------------------------------------------------------

export interface Point {
  x: number;
  y: number;
}

/** A drag across a preview (both ends 0–1 of its size) as a rect in display points. */
export function areaFromDrag(a: Point, b: Point, display: DisplayInfo): AreaRect {
  const clamp01 = (v: number) => Math.min(1, Math.max(0, v));
  const x0 = clamp01(Math.min(a.x, b.x));
  const x1 = clamp01(Math.max(a.x, b.x));
  const y0 = clamp01(Math.min(a.y, b.y));
  const y1 = clamp01(Math.max(a.y, b.y));
  return {
    x: Math.round(x0 * display.width),
    y: Math.round(y0 * display.height),
    width: Math.round((x1 - x0) * display.width),
    height: Math.round((y1 - y0) * display.height),
  };
}

/** Pull a typed-in rect back inside its display and above the minimum size. */
export function clampArea(area: AreaRect, display: DisplayInfo): AreaRect {
  const w = Math.min(display.width, Math.max(MIN_AREA_POINTS, Math.round(area.width) || 0));
  const h = Math.min(display.height, Math.max(MIN_AREA_POINTS, Math.round(area.height) || 0));
  const x = Math.min(display.width - w, Math.max(0, Math.round(area.x) || 0));
  const y = Math.min(display.height - h, Math.max(0, Math.round(area.y) || 0));
  return { x, y, width: w, height: h };
}

/** Where to draw the area over a preview, as percentages of its size. */
export function areaOverlayStyle(area: AreaRect, display: DisplayInfo) {
  return {
    left: `${(area.x / display.width) * 100}%`,
    top: `${(area.y / display.height) * 100}%`,
    width: `${(area.width / display.width) * 100}%`,
    height: `${(area.height / display.height) * 100}%`,
  };
}

// ---------------------------------------------------------------------------
// Device changes
// ---------------------------------------------------------------------------

type Names = { screen?: string; camera?: string; mic?: string };

function selectedNames(opts: RecordOptions, devices: RecordingDevices): Names {
  const video = (i?: number) => devices.video.find((d) => d.index === i)?.name;
  return {
    screen: video(opts.screenIndex),
    camera: video(opts.cameraIndex),
    mic: devices.audio.find((d) => d.index === opts.audioIndex)?.name,
  };
}

/**
 * Notices for devices that were selected before a refresh and are gone after it
 * (matched by name — indices shift when something is unplugged).
 */
export function deviceChanges(
  prevOpts: RecordOptions,
  prev: RecordingDevices | null,
  next: RecordingDevices,
): string[] {
  if (!prev) return [];
  const was = selectedNames(prevOpts, prev);
  const nextNames = {
    screen: new Set(next.video.filter((d) => d.isScreen).map((d) => d.name)),
    camera: new Set(next.video.filter((d) => !d.isScreen).map((d) => d.name)),
    mic: new Set(next.audio.map((d) => d.name)),
  };
  const out: string[] = [];
  if (was.screen && !nextNames.screen.has(was.screen))
    out.push(`Display “${was.screen}” was disconnected.`);
  if (was.camera && !nextNames.camera.has(was.camera))
    out.push(`Camera “${was.camera}” was disconnected.`);
  if (was.mic && !nextNames.mic.has(was.mic)) out.push(`Microphone “${was.mic}” was disconnected.`);
  return out;
}

// ---------------------------------------------------------------------------
// Browser media preview helpers
// ---------------------------------------------------------------------------

/** The browser device that is the same hardware as a recorder device name. */
export function matchWebDevice<T extends { label: string }>(
  list: T[],
  name: string | undefined,
): T | undefined {
  if (!name) return undefined;
  const lower = name.toLowerCase();
  const named = list.filter((d) => d.label !== "");
  return (
    named.find((d) => d.label === name) ??
    named.find((d) => {
      const label = d.label.toLowerCase();
      return label.includes(lower) || lower.includes(label);
    })
  );
}

/** Loudness 0–1 from unsigned 8-bit time-domain samples (128 = silence). */
export function micLevel(samples: ArrayLike<number>): number {
  if (samples.length === 0) return 0;
  let sum = 0;
  for (let i = 0; i < samples.length; i++) {
    const v = (samples[i] - 128) / 128;
    sum += v * v;
  }
  const rms = Math.sqrt(sum / samples.length);
  // Speech sits well below full scale; stretch it so the meter is readable.
  return Math.min(1, rms * 3.2);
}
