/** Precise frame transport, separate from the 10 Hz React timecode store. */
let frameTime = 0;
const listeners = new Set<(time: number) => void>();
export const getPlaybackFrame = () => frameTime;
export function publishPlaybackFrame(time: number) {
  if (!Number.isFinite(time)) return;
  frameTime = time;
  for (const listener of listeners) listener(time);
}
export function subscribePlaybackFrame(listener: (time: number) => void) {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}
