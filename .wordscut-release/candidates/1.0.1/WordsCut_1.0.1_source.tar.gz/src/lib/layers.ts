/**
 * Media overlays: images and videos placed over the output. Pure module, like
 * annotations.ts; `src-tauri/src/layers_export.rs` re-validates with the same
 * rules (shared fixture `tests/fixtures/layersSanitize.json`). Privacy masks
 * live in `masks.ts` (source-anchored).
 *
 * Time: the OUTPUT timeline; overlays follow their clip through edits
 * (`retimeSpans`, segment-id lineage in `retimeAfterEdit`).
 *
 * Space: normalised (0..1) to the finished frame (scene canvas, or the
 * letterboxed picture), or to the picture when `followZoom` is set.
 */

import type { TimelineEntry } from "./edl";
import { retimeSpans } from "./timeMap";

// ── Overlays ────────────────────────────────────────────────────────────────

export type OverlayKind = "image" | "video";

export interface MediaOverlay {
  id: string;
  /** Derived from the file extension: png/jpg/jpeg/gif = image, mp4/mov/m4v = video. */
  kind: OverlayKind;
  /** Absolute local path. Never copied or uploaded. */
  path: string;
  /** SHA-256 of the file when it was added; relinking refuses a different file. */
  sha256?: string;
  /** Pixel size of the file (0 = unknown). */
  srcW: number;
  srcH: number;
  /** Output-timeline seconds. */
  start: number;
  end: number;
  /** Top-left corner and size, normalised to the frame (or the picture with `followZoom`). */
  x: number;
  y: number;
  w: number;
  h: number;
  /** 0..1. */
  opacity: number;
  /** Degrees clockwise about the centre, -180..180. */
  rotation?: number;
  /** Corner radius, pixels at a 1080-line frame. */
  radius?: number;
  fadeInMs?: number;
  fadeOutMs?: number;
  /** Draw on the picture before zoom, so it moves with the zoom. */
  followZoom?: boolean;
  /** Video: seconds into the file shown at `start`. */
  trimIn?: number;
  /** Video: length of the file in seconds. */
  mediaDuration?: number;
  /** Video: the file has an audio stream. */
  hasAudio?: boolean;
  /** Video: mix the file's own audio (off by default). */
  includeAudio?: boolean;
  /** Video with audio: gain in dB, -60..12. */
  gainDb?: number;
}

export const MAX_OVERLAYS = 200;
export const MIN_OVERLAY_SEC = 0.25;
export const DEFAULT_IMAGE_SEC = 5;
export const MAX_OVERLAY_FADE_MS = 5000;
export const IMAGE_EXTENSIONS = ["png", "jpg", "jpeg", "gif"] as const;
export const VIDEO_EXTENSIONS = ["mp4", "mov", "m4v"] as const;
const MAX_PATH_CHARS = 4096;
/** Larger images are refused (decoder memory); export also passes `-max_pixels`. */
export const MAX_IMAGE_PX = 16384;

// ── Shared helpers ──────────────────────────────────────────────────────────

const clamp = (n: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, n));
const num = (v: unknown, fallback: number) =>
  typeof v === "number" && Number.isFinite(v) ? v : fallback;

let counter = 0;
function newId(prefix: string): string {
  counter += 1;
  return `${prefix}-${Date.now().toString(36)}-${counter.toString(36)}-${Math.random().toString(36).slice(2, 6)}`;
}
export const newOverlayId = () => newId("ov");

/** Output span shared by both: null when not two finite numbers or too short. */
function span(r: Record<string, unknown>, total: number, min: number) {
  if (typeof r.start !== "number" || typeof r.end !== "number") return null;
  const start = clamp(num(r.start, NaN), 0, total);
  const end = clamp(num(r.end, NaN), 0, total);
  return end - start >= min - 1e-9 ? { start, end } : null;
}

/** Position and size inside 0..1 (same rule as annotation boxes). */
function rect(r: Record<string, unknown>, dx: number, dy: number, dw: number, dh: number) {
  const x = clamp(num(r.x, dx), 0, 1);
  const y = clamp(num(r.y, dy), 0, 1);
  const w = clamp(num(r.w, dw), 0.01, Math.max(0.01, 1 - x));
  const h = clamp(num(r.h, dh), 0.01, Math.max(0.01, 1 - y));
  return { x, y, w, h };
}

/** Lower-cased extension of the last path component ("" when none). */
export function fileExtension(path: string): string {
  const base = path.slice(path.lastIndexOf("/") + 1);
  const dot = base.lastIndexOf(".");
  return dot > 0 ? base.slice(dot + 1).toLowerCase() : "";
}

export function fileName(path: string): string {
  return path.slice(path.lastIndexOf("/") + 1) || path;
}

/** The overlay kind for a path, or null when the type is not supported. */
export function overlayKindOf(path: string): OverlayKind | null {
  const ext = fileExtension(path);
  if ((IMAGE_EXTENSIONS as readonly string[]).includes(ext)) return "image";
  if ((VIDEO_EXTENSIONS as readonly string[]).includes(ext)) return "video";
  return null;
}

/** An absolute path with no control characters, or null. */
function cleanPath(v: unknown): string | null {
  if (typeof v !== "string" || !v.startsWith("/")) return null;
  const chars = Array.from(v);
  if (chars.length > MAX_PATH_CHARS) return null;
  for (const c of chars) {
    const n = c.codePointAt(0)!;
    if (n < 0x20 || (n >= 0x7f && n <= 0x9f)) return null;
  }
  return v;
}

// ── Overlay sanitizer ───────────────────────────────────────────────────────

/** One stored value -> a valid overlay, or null. Mirrors `sanitize_overlay` in layers_export.rs. */
export function sanitizeOverlay(raw: unknown, total: number): MediaOverlay | null {
  if (!raw || typeof raw !== "object") return null;
  const r = raw as Record<string, unknown>;
  const path = cleanPath(r.path);
  if (!path) return null;
  const kind = overlayKindOf(path);
  if (!kind) return null;
  const t = span(r, total, MIN_OVERLAY_SEC);
  if (!t) return null;
  if (num(r.srcW, 0) > MAX_IMAGE_PX || num(r.srcH, 0) > MAX_IMAGE_PX) return null;
  const box = rect(r, 0.6, 0.6, 0.3, 0.3);
  let fadeIn = clamp(num(r.fadeInMs, 0), 0, MAX_OVERLAY_FADE_MS);
  let fadeOut = clamp(num(r.fadeOutMs, 0), 0, MAX_OVERLAY_FADE_MS);
  const ms = (t.end - t.start) * 1000;
  if (fadeIn + fadeOut > ms) {
    const f = ms / (fadeIn + fadeOut);
    fadeIn = Math.floor(fadeIn * f);
    fadeOut = Math.floor(fadeOut * f);
  }
  const rotation = clamp(num(r.rotation, 0), -180, 180);
  const radius = clamp(num(r.radius, 0), 0, 540);
  const out: MediaOverlay = {
    id: typeof r.id === "string" && r.id.length > 0 ? r.id : newOverlayId(),
    kind,
    path,
    ...(typeof r.sha256 === "string" && /^[0-9a-f]{64}$/.test(r.sha256)
      ? { sha256: r.sha256 }
      : {}),
    srcW: Math.round(Math.max(0, num(r.srcW, 0))),
    srcH: Math.round(Math.max(0, num(r.srcH, 0))),
    ...t,
    ...box,
    opacity: clamp(num(r.opacity, 1), 0, 1),
    ...(rotation !== 0 ? { rotation } : {}),
    ...(radius > 0 ? { radius } : {}),
    ...(fadeIn > 0 ? { fadeInMs: fadeIn } : {}),
    ...(fadeOut > 0 ? { fadeOutMs: fadeOut } : {}),
    ...(r.followZoom === true ? { followZoom: true } : {}),
  };
  if (kind === "video") {
    const trimIn = clamp(num(r.trimIn, 0), 0, 1e6);
    const mediaDuration = clamp(num(r.mediaDuration, 0), 0, 1e7);
    const gainDb = clamp(num(r.gainDb, 0), -60, 12);
    if (trimIn > 0) out.trimIn = trimIn;
    if (mediaDuration > 0) out.mediaDuration = mediaDuration;
    if (r.hasAudio === true) {
      out.hasAudio = true;
      if (r.includeAudio === true) out.includeAudio = true;
      if (gainDb !== 0) out.gainDb = gainDb;
    }
  }
  return out;
}

/** Any stored value -> valid overlays sorted by start; at most MAX_OVERLAYS, in stored order. */
export function sanitizeOverlays(raw: unknown, total: number): MediaOverlay[] {
  return sanitizeList(raw, total, sanitizeOverlay, MAX_OVERLAYS, newOverlayId);
}

function sanitizeList<T extends { id: string; start: number; end: number }>(
  raw: unknown,
  total: number,
  one: (r: unknown, total: number) => T | null,
  max: number,
  fresh: () => string,
): T[] {
  if (!Array.isArray(raw)) return [];
  const seen = new Set<string>();
  const out: T[] = [];
  for (const item of raw) {
    if (out.length >= max) break;
    const a = one(item, total);
    if (!a) continue;
    if (seen.has(a.id)) a.id = fresh();
    seen.add(a.id);
    out.push(a);
  }
  return out.sort((a, b) => a.start - b.start || a.end - b.end);
}

// ── Construction ────────────────────────────────────────────────────────────

/** What the file probe tells us about a new overlay file. */
export interface OverlayFileInfo {
  path: string;
  sha256?: string;
  width: number;
  height: number;
  /** Seconds; images report ~0. */
  duration: number;
  hasAudio: boolean;
}

/**
 * A new overlay at `at` (output seconds): images for 5 s, videos for their own
 * length; 30 % of the frame wide with the file's aspect (`frameAspect` = frame
 * width / height), near the bottom right.
 */
export function makeOverlay(
  file: OverlayFileInfo,
  at: number,
  total: number,
  frameAspect: number,
): MediaOverlay | null {
  const kind = overlayKindOf(file.path);
  if (!kind) return null;
  const start = clamp(at, 0, Math.max(0, total - MIN_OVERLAY_SEC));
  const len =
    kind === "video" && file.duration > MIN_OVERLAY_SEC ? file.duration : DEFAULT_IMAGE_SEC;
  const w = 0.3;
  const aspect = file.width > 0 && file.height > 0 ? file.height / file.width : 9 / 16;
  const h = clamp(w * aspect * (frameAspect > 0 ? frameAspect : 16 / 9), 0.02, 0.9);
  return sanitizeOverlay(
    {
      path: file.path,
      sha256: file.sha256,
      srcW: file.width,
      srcH: file.height,
      start,
      end: Math.min(total, start + len),
      x: 1 - w - 0.04,
      y: Math.max(0, 1 - h - 0.06),
      w,
      h,
      opacity: 1,
      fadeInMs: 200,
      fadeOutMs: 200,
      ...(kind === "video" ? { mediaDuration: file.duration, hasAudio: file.hasAudio } : {}),
    },
    total,
  );
}

// ── Time ────────────────────────────────────────────────────────────────────

/** 0..1 visibility of an overlay at output time `t`: opacity times linear fades. */
export function overlayOpacity(o: MediaOverlay, t: number): number {
  if (t < o.start || t >= o.end) return 0;
  const fin = (o.fadeInMs ?? 0) / 1000;
  const fout = (o.fadeOutMs ?? 0) / 1000;
  let f = 1;
  if (fin > 0) f = Math.min(f, (t - o.start) / fin);
  if (fout > 0) f = Math.min(f, (o.end - t) / fout);
  return clamp(f, 0, 1) * o.opacity;
}

/** Seconds into a video overlay's file at output time `t`. */
export function overlayMediaTime(o: MediaOverlay, t: number): number {
  return (o.trimIn ?? 0) + Math.max(0, t - o.start);
}

/**
 * Re-time overlays after an edit (see `retimeSpans`). A video overlay keeps its
 * own clock: a later piece continues the file where the previous one stopped.
 */
export function retimeOverlays(
  overlays: readonly MediaOverlay[],
  oldTimeline: readonly TimelineEntry[],
  newTimeline: readonly TimelineEntry[],
  newTotal: number,
): MediaOverlay[] {
  const pieces = retimeSpans(
    overlays,
    oldTimeline,
    newTimeline,
    newTotal,
    MIN_OVERLAY_SEC,
    newOverlayId,
  );
  // Pieces of one overlay come together, earliest first; only the first keeps its id.
  const firsts = new Set(overlays.map((o) => o.id));
  let played = 0;
  for (const p of pieces) {
    if (firsts.has(p.id)) played = 0;
    else if (p.kind === "video") p.trimIn = (p.trimIn ?? 0) + played;
    played += p.end - p.start;
  }
  return sanitizeOverlays(pieces, newTotal);
}
