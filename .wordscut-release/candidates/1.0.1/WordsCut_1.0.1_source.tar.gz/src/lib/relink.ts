/**
 * Missing-media detection and relinking, kept free of React so it can be tested
 * on its own. The backend does the real verification (`relink_media`: duration,
 * streams and checksum); this module decides what to ask it about and cleans up
 * what it says back.
 */

import { findMissingMedia, hashMedia, probeMediaSize, relinkMedia } from "@/lib/ipc";
import type { Project, SourceMedia } from "@/lib/edl";
import { useProjectStore } from "@/stores/projectStore";
import { useRelinkStore } from "@/stores/relinkStore";

/** Media of `project` whose file is among `missingPaths`, in a stable order. */
export function missingSources(project: Project, missingPaths: readonly string[]): SourceMedia[] {
  const gone = new Set(missingPaths);
  return Object.values(project.media)
    .filter((m) => gone.has(m.path))
    .sort((a, b) => a.path.localeCompare(b.path));
}

/** The message from a rejected `invoke`, without Error prefixes. */
export function relinkErrorMessage(error: unknown): string {
  const raw = error instanceof Error ? error.message : String(error);
  return raw.replace(/^Error:\s*/, "").trim() || "That file could not be used.";
}

/**
 * Refresh stored picture sizes from the files as decoded today. Older builds
 * stored landscape sizes for rotated phone clips, which would misplace masks,
 * zoom and scene. Not an undo step and does not mark the project unsaved;
 * missing files are skipped.
 */
export async function refreshMediaSizes(project: Project): Promise<number> {
  let fixed = 0;
  for (const m of Object.values(project.media)) {
    if (!m.width || !m.height) continue; // audio-only and unknown sizes stay as they are
    try {
      const [width, height] = await probeMediaSize(m.path);
      // The source may have been relinked while it was probed: never overwrite that.
      const current = useProjectStore.getState().project.media[m.id];
      if (
        current?.path === m.path &&
        width > 0 &&
        height > 0 &&
        (width !== current.width || height !== current.height) &&
        useProjectStore
          .getState()
          .relinkMediaPath(project.id, m.id, m.path, { width, height, background: true })
      )
        fixed += 1;
    } catch {
      // Missing or unreadable: the relink check reports it.
    }
  }
  return fixed;
}

/**
 * Record the SHA-256 of sources saved without one (older projects), in the
 * background, so masks match the same file by checksum. Streamed, never
 * loaded whole; missing files are skipped. Not an undo step and does not
 * mark the project unsaved (it persists on the next real save).
 */
export async function backfillChecksums(project: Project): Promise<number> {
  let added = 0;
  for (const m of Object.values(project.media)) {
    if (m.sha256) continue;
    try {
      const sha256 = await hashMedia(m.path);
      const current = useProjectStore.getState().project.media[m.id];
      if (current && current.path === m.path && !current.sha256)
        if (
          useProjectStore
            .getState()
            .relinkMediaPath(project.id, m.id, m.path, { sha256, background: true })
        )
          added += 1;
    } catch {
      // Missing or unreadable: the relink check reports it.
    }
  }
  return added;
}

/** Ask the backend which sources are gone and open the relink dialog if any. */
export async function checkMissingMedia(project: Project): Promise<SourceMedia[]> {
  const paths = [...new Set(Object.values(project.media).map((m) => m.path))];
  let missing: SourceMedia[] = [];
  try {
    missing = paths.length ? missingSources(project, await findMissingMedia(paths)) : [];
  } catch {
    // If the check itself fails, do not nag: playback will report the real error.
  }
  // The user may have opened another project while the check ran.
  if (useProjectStore.getState().project.id === project.id) {
    useRelinkStore.getState().setMissing(
      project.id,
      missing.map((m) => m.id),
    );
  }
  return missing;
}

export type RelinkOutcome = { ok: true } | { ok: false; message: string };

/**
 * Try `path` for `media`. On success the project's media entry points at it
 * (not an undo step). A different file is refused with the backend's reason.
 */
export async function relinkSource(
  projectId: string,
  media: SourceMedia,
  path: string,
): Promise<RelinkOutcome> {
  let probed: SourceMedia;
  try {
    probed = await relinkMedia(path, media);
  } catch (error) {
    return { ok: false, message: relinkErrorMessage(error) };
  }
  // The project may have been closed or replaced while the file was checked.
  const size = { width: probed.width, height: probed.height };
  if (!useProjectStore.getState().relinkMediaPath(projectId, media.id, path, size)) {
    return { ok: false, message: "The project changed while the file was checked. Try again." };
  }
  useRelinkStore.getState().resolve(media.id);
  return { ok: true };
}
