/**
 * Filler-word detection — the single source of truth for what counts as a
 * filler. Pure module (no React, Tauri or store imports, same rule as edl.ts).
 *
 * Fillers are phrases of one or more words. Multi-word phrases ("you know")
 * match consecutive words in the same segment. The default set is limited to
 * non-words that are never part of real speech content; phrases that are also
 * ordinary words ("like", "so", "right") are opt-in.
 */

import type { Word } from "./edl";

/** Hesitation sounds only — safe to remove without touching meaning. */
export const SAFE_FILLERS: readonly string[] = [
  "um",
  "umm",
  "uh",
  "uhh",
  "er",
  "erm",
  "ah",
  "ahh",
  "hmm",
  "mm",
  "mhm",
];

/** Real words/phrases that are sometimes filler. Never selected by default. */
export const OPT_IN_FILLERS: readonly string[] = [
  "you know",
  "i mean",
  "sort of",
  "kind of",
  "like",
  "actually",
  "literally",
  "basically",
  "honestly",
  "right",
  "okay",
  "ok",
  "so",
];

/** Words of a multi-word filler must follow each other within this gap (s). */
export const MAX_PHRASE_GAP_SEC = 1;

const EDGE_PUNCT = /^[\s.,!?;:"'()[\]{}—–-]+|[\s.,!?;:"'()[\]{}—–-]+$/g;
const BREAKING_PUNCT = /[.,!?;:—–]$/;

/** Strip surrounding punctuation/whitespace and lowercase. */
export function normaliseFillerToken(text: string): string {
  return text.trim().replace(EDGE_PUNCT, "").toLowerCase();
}

/** One occurrence of a filler phrase in the transcript. */
export interface FillerMatch {
  /** The configured phrase that matched (lowercase, space separated). */
  phrase: string;
  /** Ids of the consecutive words that make up this occurrence. */
  wordIds: string[];
}

/**
 * Find non-overlapping filler occurrences in one run of consecutive words.
 * Longer phrases win over shorter ones at the same position. Words of a
 * multi-word phrase must be adjacent, close in time, and not separated by
 * punctuation ("you, know" is not "you know").
 */
export function findFillerMatches(
  words: readonly Word[],
  phrases: Iterable<string>,
): FillerMatch[] {
  const parsed = [
    ...new Set([...phrases].map((p) => p.trim().toLowerCase().split(/\s+/).join(" "))),
  ]
    .filter((p) => p.length > 0)
    .map((p) => ({ phrase: p, parts: p.split(" ") }))
    .sort((a, b) => b.parts.length - a.parts.length);
  if (parsed.length === 0) return [];

  const norm = words.map((w) => normaliseFillerToken(w.text));
  const matches: FillerMatch[] = [];
  let i = 0;
  while (i < words.length) {
    let hit: (typeof parsed)[number] | null = null;
    for (const cand of parsed) {
      if (i + cand.parts.length > words.length) continue;
      let ok = true;
      for (let k = 0; k < cand.parts.length && ok; k++) {
        if (norm[i + k] !== cand.parts[k]) ok = false;
        else if (k > 0) {
          const prev = words[i + k - 1]!;
          const cur = words[i + k]!;
          if (BREAKING_PUNCT.test(prev.text.trim()) || cur.start - prev.end > MAX_PHRASE_GAP_SEC) {
            ok = false;
          }
        }
      }
      if (ok) {
        hit = cand;
        break;
      }
    }
    if (hit) {
      matches.push({
        phrase: hit.phrase,
        wordIds: words.slice(i, i + hit.parts.length).map((w) => w.id),
      });
      i += hit.parts.length;
    } else {
      i++;
    }
  }
  return matches;
}

/**
 * Find fillers across a project's segments. Phrases never span a segment
 * boundary: a segment edge is a cut, not continuous speech.
 */
export function findFillersInSegments(
  segments: ReadonlyArray<{ words: readonly Word[] }>,
  phrases: Iterable<string>,
): FillerMatch[] {
  const list = [...phrases];
  return segments.flatMap((seg) => findFillerMatches(seg.words, list));
}

/** Ids of every word covered by a filler match. */
export function fillerWordIds(
  segments: ReadonlyArray<{ words: readonly Word[] }>,
  phrases: Iterable<string>,
): Set<string> {
  const ids = new Set<string>();
  for (const m of findFillersInSegments(segments, phrases)) for (const id of m.wordIds) ids.add(id);
  return ids;
}
