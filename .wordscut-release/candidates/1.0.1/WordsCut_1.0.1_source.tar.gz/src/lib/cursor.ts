/** Pure consumer of docs/cursor-events.md. Times always stay in source seconds. */
export interface CursorPoint {
  t: number;
  x: number;
  y: number;
  outside: boolean;
}
export type CursorShape = "arrow" | "ibeam" | "pointer" | "crosshair" | "resize" | "other";
export type CursorEvent =
  | (CursorPoint & { type: "move" })
  | (CursorPoint & { type: "down" | "up"; button: "left" | "right" | "other" })
  | { type: "key"; t: number; mods: string[]; name?: string; secure?: true }
  | { type: "scroll"; t: number; dx: number; dy: number }
  | { type: "cursorshape"; t: number; shape: CursorShape };
export interface CursorHeader {
  version: 1;
  target: "display" | "window" | "area";
  display: { width: number; height: number; scale: number };
  captured: { x: number; y: number; width: number; height: number };
}
export interface CursorTrack {
  header?: CursorHeader;
  events: CursorEvent[];
  /** Sorted, unique timestamps; at equal times the last position wins. */
  points: CursorPoint[];
}
const finite = (n: unknown): n is number => typeof n === "number" && Number.isFinite(n);
const unit = (n: number) => Math.max(0, Math.min(1, n));
const shapes: CursorShape[] = ["arrow", "ibeam", "pointer", "crosshair", "resize", "other"];

function record(value: unknown): Record<string, unknown> {
  return value && typeof value === "object" ? (value as Record<string, unknown>) : {};
}

function eventFrom(value: unknown): CursorEvent | null {
  const e = record(value);
  if (!finite(e.t) || e.t < 0) return null;
  const t = e.t;
  switch (e.type) {
    case "move":
    case "down":
    case "up": {
      if (!finite(e.x) || !finite(e.y)) return null;
      const p = { t, x: unit(e.x), y: unit(e.y), outside: e.outside === true };
      if (e.type === "move") return { type: "move", ...p };
      if (e.button !== "left" && e.button !== "right" && e.button !== "other") return null;
      return { type: e.type, button: e.button, ...p };
    }
    case "key":
      return {
        type: "key",
        t,
        mods: Array.isArray(e.mods)
          ? e.mods.filter((m): m is string => ["cmd", "ctrl", "alt", "shift"].includes(String(m)))
          : [],
        // Optional key identity (opt-in at record time); anything odd is dropped, the press stays.
        ...(typeof e.name === "string" && /^[^\p{Cc}\uF700-\uF8FF]{1,16}$/u.test(e.name)
          ? { name: e.name }
          : {}),
        ...(e.secure === true ? { secure: true as const } : {}),
      };
    case "scroll":
      return finite(e.dx) && finite(e.dy) ? { type: "scroll", t, dx: e.dx, dy: e.dy } : null;
    case "cursorshape":
      return shapes.includes(e.shape as CursorShape)
        ? { type: "cursorshape", t, shape: e.shape as CursorShape }
        : null;
    default:
      return null;
  }
}

/** Also validates tracks loaded from project JSON; derived points are never trusted. */
export function sanitizeCursorTrack(raw: unknown): CursorTrack {
  const r = record(raw);
  const events = (Array.isArray(r.events) ? r.events : [])
    .map(eventFrom)
    .filter((e): e is CursorEvent => e !== null)
    .sort((a, b) => a.t - b.t);
  const points: CursorPoint[] = [];
  for (const e of events) {
    if (!("x" in e)) continue;
    const p = { t: e.t, x: e.x, y: e.y, outside: e.outside };
    if (points.at(-1)?.t === p.t) points[points.length - 1] = p;
    else points.push(p);
  }
  const h = record(r.header);
  const d = record(h.display),
    c = record(h.captured);
  const header: CursorHeader | undefined =
    h.version === 1 &&
    (h.target === "display" || h.target === "window" || h.target === "area") &&
    finite(d.width) &&
    d.width > 0 &&
    finite(d.height) &&
    d.height > 0 &&
    finite(d.scale) &&
    d.scale > 0 &&
    finite(c.x) &&
    finite(c.y) &&
    finite(c.width) &&
    c.width > 0 &&
    finite(c.height) &&
    c.height > 0
      ? {
          version: 1,
          target: h.target,
          display: { width: d.width, height: d.height, scale: d.scale },
          captured: { x: c.x, y: c.y, width: c.width, height: c.height },
        }
      : undefined;
  return { ...(header ? { header } : {}), events, points };
}

/** Truncated final lines and unknown future fields/types are safe to ignore. */
export function parseCursorLog(log: string): CursorTrack {
  const events: unknown[] = [];
  let header: unknown;
  for (const line of log.split(/\r?\n/)) {
    try {
      const value: unknown = JSON.parse(line);
      if (record(value).type === "header") header ??= value;
      else events.push(value);
    } catch {
      /* A crashed recording can end with an incomplete line. */
    }
  }
  return sanitizeCursorTrack({ header, events });
}

/** Index of last timestamp <= t, shared by interpolation and idle detection. */
export function cursorPointIndex(points: readonly { t: number }[], t: number): number {
  let lo = 0,
    hi = points.length;
  while (lo < hi) {
    const mid = (lo + hi) >>> 1;
    if (points[mid].t <= t) lo = mid + 1;
    else hi = mid;
  }
  return lo - 1;
}

/** Hold at the end; absent before first sample. Visibility changes are discrete. */
export function cursorAt(track: CursorTrack, t: number): CursorPoint | null {
  if (!Number.isFinite(t)) return null;
  const i = cursorPointIndex(track.points, t);
  const a = track.points[i],
    b = track.points[i + 1];
  if (!a) return null;
  if (!b || a.outside !== b.outside) return { ...a, t };
  const f = (t - a.t) / (b.t - a.t);
  return { t, x: a.x + (b.x - a.x) * f, y: a.y + (b.y - a.y) * f, outside: a.outside };
}

/**
 * Symmetric time-window filter, convex weights: no overshoot, no playback-history
 * dependency, exact endpoints. Does not smear across an outside/inside boundary.
 * A moving window keeps this linear in recording length for normal 60 Hz logs.
 */
export function smoothCursorTrack(track: CursorTrack, seconds = 0.1): CursorTrack {
  if (!Number.isFinite(seconds) || seconds <= 0 || track.points.length < 3) return track;
  const radius = Math.min(0.5, seconds);
  const source = track.points;
  let left = 0,
    right = 0,
    sumX = 0,
    sumY = 0;
  const points = source.map((p, i) => {
    const runStart = i === 0 || source[i - 1].outside !== p.outside;
    if (runStart) {
      left = i;
      right = i;
      sumX = 0;
      sumY = 0;
    }
    while (
      right < source.length &&
      source[right].outside === p.outside &&
      source[right].t <= p.t + radius
    ) {
      sumX += source[right].x;
      sumY += source[right].y;
      right++;
    }
    while (left < right && source[left].t < p.t - radius) {
      sumX -= source[left].x;
      sumY -= source[left].y;
      left++;
    }
    const edge = runStart || i === source.length - 1 || source[i + 1].outside !== p.outside;
    return edge
      ? { ...p }
      : { ...p, x: unit(sumX / (right - left)), y: unit(sumY / (right - left)) };
  });
  return { ...track, points };
}
