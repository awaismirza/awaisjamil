// FCPXML 1.10 export of the EDL. Pure module: no React, Tauri or store imports.
// Every time is a whole number of sequence frames written as a rational
// ("1001/30000s"), so Final Cut never has to round. Output order = EDL order.
import type { Project } from "./edl";
import {
  computeTimeline,
  isVoiceOver,
  segmentHold,
  segmentSpeed,
  transitionHalf,
  voiceOverLength,
} from "./edl";
import { audibleTracks, trackMediaStart } from "./audioMix";

export interface FcpxmlResult {
  xml: string;
  /** Project features that have no FCPXML equivalent and were left out. */
  unsupported: string[];
}

const NTSC = [24000, 30000, 60000]; // x/1001 rates
const STANDARD_FPS = [24000 / 1001, 24, 25, 30000 / 1001, 30, 50, 60000 / 1001, 60];
const SNAP_TOLERANCE = 0.02; // relative; further off than this keeps its own rate (e.g. 15 fps)

/** Frame duration as [numerator, denominator] seconds, e.g. 29.97 -> [1001, 30000]. */
export function frameDuration(fps: number): [number, number] {
  let f = fps > 0 ? fps : 30;
  const near = STANDARD_FPS.reduce((best, s) => (Math.abs(s - f) < Math.abs(best - f) ? s : best));
  if (Math.abs(near - f) / near < SNAP_TOLERANCE) f = near;
  for (const n of NTSC) if (Math.abs(f - n / 1001) < 0.01) return [1001, n];
  if (Math.abs(f - Math.round(f)) < 0.001) return [1, Math.round(f)];
  return [1000, Math.round(f * 1000)];
}

// XML 1.0 forbids most control characters even when escaped.
// eslint-disable-next-line no-control-regex
const ILLEGAL_XML = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\uFFFE\uFFFF]/g;
const esc = (s: string) =>
  s
    .replace(ILLEGAL_XML, "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");

const fileUrl = (p: string) =>
  "file://" +
  p
    .split("/")
    .map((s) => encodeURIComponent(s))
    .join("/");

const basename = (p: string) => p.split("/").pop() || p;

export function buildFcpxml(project: Project): FcpxmlResult {
  const unsupported: string[] = [];
  const mediaList = Object.values(project.media);
  const video = mediaList.find((m) => m.width > 0 && m.height > 0);
  const seqFps = video?.fps ?? mediaList[0]?.fps ?? 30;
  const [fn, fd] = frameDuration(seqFps);
  const t = (frames: number) => (frames === 0 ? "0s" : `${frames * fn}/${fd}s`);
  const frames = (sec: number) => Math.round((sec * fd) / fn);
  if (Math.abs(fd / fn - seqFps) > 0.001)
    unsupported.push(
      `${seqFps} fps snapped to the standard ${Math.round((fd / fn) * 1000) / 1000} fps`,
    );

  // Spine clips on the sequence frame grid. Every boundary is frames() of the real
  // output time, so rounding never accumulates and the total is frames(total duration).
  const clips: { mediaId: string; start: number; dur: number; offset: number }[] = [];
  for (const e of computeTimeline(project)) {
    const m = project.media[e.mediaId];
    if (!m) {
      unsupported.push(`Segment ${e.segmentId} references missing media ${e.mediaId}; skipped`);
      continue;
    }
    const offset = frames(e.outputStart);
    const dur = frames(e.outputEnd) - offset;
    if (dur <= 0) {
      unsupported.push(`Segment ${e.segmentId} is shorter than one frame; skipped`);
      continue;
    }
    // Keep the clip inside the asset: shift the start back rather than run past the end.
    const start = Math.max(0, Math.min(frames(e.sourceIn), frames(m.duration) - dur));
    clips.push({ mediaId: e.mediaId, start, dur, offset });
  }
  // Speed, holds and transitions keep their output length on the spine (so chapters
  // and music stay aligned) but are not rebuilt as FCP retimes / transitions.
  const segs = project.segments;
  const sped = segs.filter((s) => segmentSpeed(s) !== 1).length;
  const held = segs.filter((s) => segmentHold(s) > 0).length;
  const muted = segs.filter((s) => s.muted).length;
  const faded = segs.filter((_, i) => transitionHalf(segs, i) > 0).length;
  if (sped) unsupported.push(`${sped} speed change(s): clips keep their timeline length at 1x`);
  if (held) unsupported.push(`${held} freeze frame(s): the hold plays on as footage`);
  if (muted) unsupported.push(`${muted} muted clip(s): audio is not muted`);
  if (faded) unsupported.push(`${faded} transition(s): exported as straight cuts`);
  const last = clips[clips.length - 1];
  const total = last ? last.offset + last.dur : 0;

  const used = new Set(clips.map((c) => c.mediaId));
  for (const a of project.audioTracks ?? []) used.add(a.mediaId);
  const assets = mediaList.filter((m) => used.has(m.id));
  for (const m of assets) {
    if (m.width > 0 && Math.abs(m.fps - seqFps) > 0.01)
      unsupported.push(`${m.path}: ${m.fps} fps media is conformed to the ${seqFps} fps sequence`);
  }
  const ids = new Map<string, string>();
  const taken = new Set<string>();
  for (const m of mediaList) {
    const base = `a_${m.id.replace(/[^A-Za-z0-9_]/g, "_")}`;
    let id = base;
    for (let n = 2; taken.has(id); n++) id = `${base}_${n}`;
    taken.add(id);
    ids.set(m.id, id);
  }
  const assetId = (id: string) => ids.get(id)!;

  // Each chapter goes on the clip whose output span contains it (last clip owns the end).
  const chapters = (project.chapters ?? []).slice().sort((a, b) => a.outputTime - b.outputTime);
  const byClip = clips.map(() => [] as typeof chapters);
  for (const ch of chapters) {
    const f = frames(ch.outputTime);
    const i = clips.findIndex((c) => f >= c.offset && f < c.offset + c.dur);
    const idx = i >= 0 ? i : clips.length - 1;
    if (idx >= 0) byClip[idx]!.push(ch);
  }
  const markersFor = (i: number) =>
    byClip[i]!.map((ch) => {
      const c = clips[i]!;
      const local = Math.min(c.dur - 1, Math.max(0, frames(ch.outputTime) - c.offset));
      return `<chapter-marker start="${t(c.start + local)}" duration="${t(1)}" value="${esc(ch.title)}"/>`;
    }).join("");

  // Music beds are connected (lane -1) to the first spine clip, in that clip's source time.
  const music = audibleTracks(project.audioTracks ?? [])
    .map((a) => {
      const m = project.media[a.mediaId];
      const first = clips[0];
      if (!m || !first) return "";
      let off = frames(a.offsetSec);
      // A voice-over take plays only its trim.
      const from = trackMediaStart(a);
      const until = isVoiceOver(a) ? from + voiceOverLength(a, m.duration) : m.duration;
      let skip = frames(from);
      if (off < 0) {
        skip += -off;
        off = 0;
      }
      const d = Math.min(frames(until) - skip, total - off);
      if (d < 1) return "";
      return `<asset-clip ref="${assetId(m.id)}" lane="-1" offset="${t(first.start + off)}" name="${esc(basename(m.path))}" start="${t(skip)}" duration="${t(d)}"><adjust-volume amount="${Number.isFinite(a.gainDb) ? a.gainDb : 0}dB"/></asset-clip>`;
    })
    .join("");

  const spine = clips
    .map((c, i) => {
      const m = project.media[c.mediaId]!;
      const inner = (i === 0 ? music : "") + markersFor(i);
      const open = `<asset-clip ref="${assetId(m.id)}" offset="${t(c.offset)}" name="${esc(basename(m.path))}" start="${t(c.start)}" duration="${t(c.dur)}" tcFormat="NDF"`;
      return inner ? `${open}>${inner}</asset-clip>` : `${open}/>`;
    })
    .join("\n          ");

  const assetXml = assets
    .map((m) => {
      const isVideo = m.width > 0 && m.height > 0;
      return `    <asset id="${assetId(m.id)}" name="${esc(basename(m.path))}" start="0s" duration="${t(frames(m.duration))}" ${isVideo ? `hasVideo="1" format="r1" ` : ""}${m.audioSampleRate > 0 ? `hasAudio="1" audioSources="1" audioChannels="2" audioRate="${m.audioSampleRate}"` : ""}>
      <media-rep kind="original-media" src="${esc(fileUrl(m.path))}"/>
    </asset>`;
    })
    .join("\n");

  if (project.scene?.enabled)
    unsupported.push("Scene (background, padding, corners, shadow, aspect)");
  if (project.zoomRegions?.length) unsupported.push(`Zoom regions (${project.zoomRegions.length})`);
  if (project.cursor && Object.keys(project.cursor.tracks).length > 0)
    unsupported.push("Cursor styling and cursor-driven zoom");
  if (project.annotations?.length) unsupported.push(`Annotations (${project.annotations.length})`);
  if (project.keystrokes?.enabled) unsupported.push("Keystroke overlay");
  if (project.overlays?.length)
    unsupported.push(`Image/video overlays (${project.overlays.length})`);
  // The FCPXML points at the original media, so a privacy mask is simply absent there.
  if (project.masks?.length)
    unsupported.push(
      `PRIVACY MASKS NOT APPLIED (${project.masks.length}): the source media is unblurred in the FCPXML`,
    );
  if (audibleTracks(project.audioTracks ?? []).some((a) => a.ducks))
    unsupported.push("Music ducking (tracks exported at fixed gain)");
  if (audibleTracks(project.audioTracks ?? []).some((a) => a.fadeInSec || a.fadeOutSec))
    unsupported.push("Music fades");
  if (audibleTracks(project.audioTracks ?? []).some((a) => isVoiceOver(a) && a.overrideOriginal))
    unsupported.push("Voice-over override (original audio is not muted under the take)");

  const name = esc(project.name);
  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE fcpxml>
<fcpxml version="1.10">
  <resources>
    <format id="r1" frameDuration="${fn}/${fd}s" width="${video?.width ?? 1920}" height="${video?.height ?? 1080}"/>
${assetXml}
  </resources>
  <library>
    <event name="${name}">
      <project name="${name}">
        <sequence format="r1" duration="${t(total)}" tcStart="0s" tcFormat="NDF" audioLayout="stereo" audioRate="48k">
          <spine>
          ${spine}
          </spine>
        </sequence>
      </project>
    </event>
  </library>
</fcpxml>
`;
  return { xml, unsupported };
}
