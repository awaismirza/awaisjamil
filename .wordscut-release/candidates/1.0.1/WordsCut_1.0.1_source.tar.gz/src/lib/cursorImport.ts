/** Keep large recording logs off the editor's main thread. */
import { parseCursorLog, type CursorTrack } from "./cursor";
import { readRecordingCursorLog } from "./ipc";
export async function loadRecordingCursorTrack(
  path: string,
  signal: globalThis.AbortSignal,
): Promise<CursorTrack> {
  const text = await readRecordingCursorLog(path);
  signal.throwIfAborted();
  // Keep the direct Worker(new URL(...)) form so Vite bundles the worker.
  const { Worker, URL } = globalThis;
  if (typeof Worker === "undefined") return parseCursorLog(text);
  const worker = new Worker(new URL("../workers/cursorLog.worker.ts", import.meta.url), {
    type: "module",
  });
  try {
    return await new Promise<CursorTrack>((resolve, reject) => {
      const abort = () => reject(new DOMException("Project changed", "AbortError"));
      signal.addEventListener("abort", abort, { once: true });
      const finish = () => signal.removeEventListener("abort", abort);
      worker.onmessage = ({
        data,
      }: globalThis.MessageEvent<{ track?: CursorTrack; error?: string }>) => {
        finish();
        if (data.track) resolve(data.track);
        else reject(new Error(data.error ?? "Cursor parser returned no track"));
      };
      worker.onerror = (event) => {
        finish();
        reject(new Error(event.message));
      };
      worker.onmessageerror = () => {
        finish();
        reject(new Error("Could not read parsed cursor data"));
      };
      worker.postMessage(text);
    });
  } finally {
    worker.terminate();
  }
}
