/**
 * Recorder shortcut registry: the actions, their defaults, and pure helpers to
 * validate, canonicalise, display and capture accelerators. Pure module (no
 * React, Tauri or store imports, same rule as edl.ts).
 *
 * Accelerators use the tauri-plugin-global-shortcut grammar: modifiers joined
 * by "+" and ending in one key, e.g. "CmdOrCtrl+Alt+R".
 */

export type ShortcutAction = "record" | "pause" | "rerecord" | "cancel" | "mark";

export interface ShortcutDef {
  action: ShortcutAction;
  label: string;
  description: string;
  /** `always` is registered whenever the app runs; `session` only while recording. */
  scope: "always" | "session";
  default: string;
}

export const SHORTCUT_DEFS: readonly ShortcutDef[] = [
  {
    action: "record",
    label: "Start / stop recording",
    description: "Works from any app. Stopping adds the take to your video.",
    scope: "always",
    default: "CmdOrCtrl+Alt+R",
  },
  {
    action: "pause",
    label: "Pause / resume",
    description: "Only while recording.",
    scope: "session",
    default: "CmdOrCtrl+Alt+P",
  },
  {
    action: "rerecord",
    label: "Restart the take",
    description: "Throws the current take away and starts again.",
    scope: "session",
    default: "CmdOrCtrl+Alt+E",
  },
  {
    action: "mark",
    label: "Mark a moment",
    description: "Drops a chapter at this point in the recording.",
    scope: "session",
    default: "CmdOrCtrl+Alt+M",
  },
  {
    action: "cancel",
    label: "Discard the recording",
    description: "Stops and deletes the take without adding it.",
    scope: "session",
    default: "CmdOrCtrl+Alt+Backspace",
  },
];

export type ShortcutMap = Record<ShortcutAction, string>;

export function defaultShortcuts(): ShortcutMap {
  const map = {} as ShortcutMap;
  for (const d of SHORTCUT_DEFS) map[d.action] = d.default;
  return map;
}

// ---------------------------------------------------------------------------
// Canonical form
// ---------------------------------------------------------------------------

const MODIFIER_ORDER = ["CmdOrCtrl", "Ctrl", "Alt", "Shift"] as const;
type Modifier = (typeof MODIFIER_ORDER)[number];

const MODIFIER_ALIASES: Record<string, Modifier> = {
  cmdorctrl: "CmdOrCtrl",
  commandorcontrol: "CmdOrCtrl",
  cmd: "CmdOrCtrl",
  command: "CmdOrCtrl",
  super: "CmdOrCtrl",
  meta: "CmdOrCtrl",
  ctrl: "Ctrl",
  control: "Ctrl",
  alt: "Alt",
  option: "Alt",
  opt: "Alt",
  shift: "Shift",
};

const NAMED_KEYS = [
  "Space",
  "Enter",
  "Backspace",
  "Delete",
  "ArrowUp",
  "ArrowDown",
  "ArrowLeft",
  "ArrowRight",
  "Comma",
  "Period",
  "Slash",
  "Minus",
  "Equal",
] as const;

const NAMED_KEY_LOOKUP = new Map(NAMED_KEYS.map((k) => [k.toLowerCase(), k]));

/** Canonical key name for a key token, or null when it is not supported. */
function canonicalKey(token: string): string | null {
  if (/^[a-z]$/i.test(token)) return token.toUpperCase();
  if (/^[0-9]$/.test(token)) return token;
  const f = /^f([1-9]|1[0-2])$/i.exec(token);
  if (f) return `F${f[1]}`;
  return NAMED_KEY_LOOKUP.get(token.toLowerCase()) ?? null;
}

/**
 * Put an accelerator into one canonical spelling (fixed modifier order,
 * upper-case letters), or null when it is malformed or uses an unsupported key.
 * Two accelerators are the same shortcut exactly when their canonical forms match.
 */
export function normalizeAccelerator(accelerator: string): string | null {
  const parts = accelerator
    .split("+")
    .map((p) => p.trim())
    .filter((p) => p.length > 0);
  if (parts.length === 0) return null;
  const keyToken = parts[parts.length - 1]!;
  const mods = new Set<Modifier>();
  for (const part of parts.slice(0, -1)) {
    const mod = MODIFIER_ALIASES[part.toLowerCase()];
    if (!mod) return null;
    mods.add(mod);
  }
  // A modifier can't also be the final key.
  if (MODIFIER_ALIASES[keyToken.toLowerCase()]) return null;
  const key = canonicalKey(keyToken);
  if (!key) return null;
  return [...MODIFIER_ORDER.filter((m) => mods.has(m)), key].join("+");
}

// ---------------------------------------------------------------------------
// Validation
// ---------------------------------------------------------------------------

export type ShortcutProblem = "invalid" | "needs-modifier" | "reserved";

/** Combinations that macOS or every app already uses; binding them would break the system. */
export const RESERVED = new Set([
  "CmdOrCtrl+Q",
  "CmdOrCtrl+W",
  "CmdOrCtrl+H",
  "CmdOrCtrl+M",
  "CmdOrCtrl+C",
  "CmdOrCtrl+V",
  "CmdOrCtrl+X",
  "CmdOrCtrl+Z",
  "CmdOrCtrl+A",
  "CmdOrCtrl+S",
  "CmdOrCtrl+Space",
  "CmdOrCtrl+Shift+Z",
  "CmdOrCtrl+Alt+Escape",
]);

/** A global shortcut needs a modifier, or it would fire on ordinary typing. */
export function shortcutProblem(accelerator: string): ShortcutProblem | null {
  const canon = normalizeAccelerator(accelerator);
  if (!canon) return "invalid";
  const parts = canon.split("+");
  const hasModifier = parts.length > 1;
  const isFunctionKey = /^F\d+$/.test(parts[parts.length - 1]!);
  if (!hasModifier && !isFunctionKey) return "needs-modifier";
  if (RESERVED.has(canon)) return "reserved";
  return null;
}

/** The other action already using this accelerator, if any. */
export function findShortcutConflict(
  map: ShortcutMap,
  action: ShortcutAction,
  accelerator: string,
): ShortcutAction | null {
  const canon = normalizeAccelerator(accelerator);
  if (!canon) return null;
  for (const def of SHORTCUT_DEFS) {
    if (def.action === action) continue;
    if (normalizeAccelerator(map[def.action]) === canon) return def.action;
  }
  return null;
}

// ---------------------------------------------------------------------------
// Display and capture
// ---------------------------------------------------------------------------

const MAC_SYMBOLS: Record<string, string> = {
  CmdOrCtrl: "⌘",
  Ctrl: "⌃",
  Alt: "⌥",
  Shift: "⇧",
  Space: "Space",
  Enter: "↵",
  Backspace: "⌫",
  Delete: "⌦",
  ArrowUp: "↑",
  ArrowDown: "↓",
  ArrowLeft: "←",
  ArrowRight: "→",
  Comma: ",",
  Period: ".",
  Slash: "/",
  Minus: "−",
  Equal: "=",
};

/** Mac-style label, in the order macOS prints modifiers: ⌃⌥⇧⌘ then the key. */
export function formatAccelerator(accelerator: string): string {
  const canon = normalizeAccelerator(accelerator);
  if (!canon) return accelerator;
  const parts = canon.split("+");
  const key = parts.pop()!;
  const order = ["Ctrl", "Alt", "Shift", "CmdOrCtrl"];
  const mods = order.filter((m) => parts.includes(m)).map((m) => MAC_SYMBOLS[m]!);
  return [...mods, MAC_SYMBOLS[key] ?? key].join("");
}

/** The slice of a KeyboardEvent that capture needs. */
export interface KeyEventLike {
  code: string;
  /** Layout-aware character; letters and digits match on this when present. */
  key?: string;
  metaKey: boolean;
  ctrlKey: boolean;
  altKey: boolean;
  shiftKey: boolean;
}

/**
 * Map a key press to an accelerator key. Letters and digits use `key` (layout-aware, so
 * AZERTY's Cmd+Z is Z); anything else (Space, arrows, F-keys, or Option-modified
 * characters on a Mac) falls back to `code`.
 */
function keyFromCode(code: string, key?: string): string | null {
  if (key && /^[a-z0-9]$/i.test(key)) return key.toUpperCase();
  const letter = /^Key([A-Z])$/.exec(code);
  if (letter) return letter[1]!;
  const digit = /^Digit([0-9])$/.exec(code);
  if (digit) return digit[1]!;
  return canonicalKey(code);
}

/**
 * Build an accelerator from a key press while the user is choosing a shortcut.
 * Returns null while only modifiers are held, or for a key we cannot register.
 * Cmd and Ctrl map to CmdOrCtrl together on a Mac only when just Cmd is held;
 * a held Ctrl stays Ctrl so ⌃ and ⌘ remain distinguishable.
 */
export function acceleratorFromEvent(e: KeyEventLike): string | null {
  const key = keyFromCode(e.code, e.key);
  if (!key) return null;
  const mods: Modifier[] = [];
  if (e.metaKey) mods.push("CmdOrCtrl");
  if (e.ctrlKey) mods.push("Ctrl");
  if (e.altKey) mods.push("Alt");
  if (e.shiftKey) mods.push("Shift");
  return normalizeAccelerator([...mods, key].join("+"));
}

export function problemMessage(problem: ShortcutProblem): string {
  switch (problem) {
    case "invalid":
      return "That key can't be used as a shortcut.";
    case "needs-modifier":
      return "Add ⌘, ⌥, ⌃ or ⇧ so it doesn't fire while typing.";
    case "reserved":
      return "macOS and most apps already use that one.";
  }
}
