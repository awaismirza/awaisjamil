/**
 * Pure mixing rules for music / SFX tracks and voice-over takes, shared by the
 * editor preview. The
 * export applies the same rules in Rust (`Project::audible_tracks`,
 * `resolve_fades` in `src-tauri/src/edl.rs`); keep the two in step.
 */

import { isVoiceOver, voiceOverLength, type AudioTrack, type SourceMedia } from "./edl";

/**
 * The tracks that are heard: if any is soloed only the soloed ones (solo wins
 * over mute), otherwise every track that is not muted.
 */
export function audibleTracks(tracks: readonly AudioTrack[]): AudioTrack[] {
  const anySolo = tracks.some((t) => t.solo);
  return tracks.filter((t) => (anySolo ? !!t.solo : !t.muted));
}

/**
 * Fade lengths clamped to the clip: each within 0..len, scaled down together
 * when they would overlap.
 */
export function resolveFades(
  fadeIn: number | undefined,
  fadeOut: number | undefined,
  len: number,
): { fadeIn: number; fadeOut: number } {
  const max = Math.max(0, len);
  const clean = (v: number | undefined) =>
    v !== undefined && Number.isFinite(v) ? Math.min(Math.max(v, 0), max) : 0;
  const fi = clean(fadeIn);
  const fo = clean(fadeOut);
  if (fi + fo > max && fi + fo > 0) {
    const k = max / (fi + fo);
    return { fadeIn: fi * k, fadeOut: fo * k };
  }
  return { fadeIn: fi, fadeOut: fo };
}

/**
 * Where a track sits on the output timeline. Like the export, a negative offset
 * is treated as 0 and the track ends with its media or with the edit.
 */
export function trackSpan(
  track: Pick<AudioTrack, "offsetSec"> & Partial<AudioTrack>,
  mediaDuration: number,
  total: number,
): { start: number; len: number } {
  const start = Math.max(0, Number.isFinite(track.offsetSec) ? track.offsetSec : 0);
  // A voice-over take plays only its trim; a music bed plays its whole file.
  const media = isVoiceOver(track)
    ? voiceOverLength(track as AudioTrack, mediaDuration)
    : mediaDuration > 0
      ? mediaDuration
      : Number.POSITIVE_INFINITY;
  return { start, len: Math.max(0, Math.min(media, total - start)) };
}

/** Where a take starts inside its own media (its trim-in). 0 for music beds. */
export function trackMediaStart(track: Partial<AudioTrack>): number {
  return isVoiceOver(track) ? Math.max(0, track.sourceIn ?? 0) : 0;
}

// ---------------------------------------------------------------------------
// Voice-over replacement ("override original narration")
// ---------------------------------------------------------------------------

/**
 * Ramp length of the override envelope. The ramps sit OUTSIDE the interval, so
 * the original is fully silent for the whole take and the take never moves.
 */
export const OVERRIDE_FADE_SEC = 0.05;

/** Output-time span over which an override take replaces what was there before. */
export interface ReplacementInterval {
  trackId: string;
  start: number;
  end: number;
}

/**
 * The effective replacement intervals, in track order (later = newer): every
 * heard voice-over take with `overrideOriginal`, clipped to the edit. A muted
 * (or solo-silenced) take replaces nothing, so disabling it restores the audio.
 * Mirrored in Rust (`Project::replacement_intervals`).
 */
export function replacementIntervals(
  tracks: readonly AudioTrack[],
  media: Readonly<Record<string, Pick<SourceMedia, "duration">>>,
  total: number,
): ReplacementInterval[] {
  const out: ReplacementInterval[] = [];
  for (const t of audibleTracks(tracks)) {
    if (!isVoiceOver(t) || !t.overrideOriginal) continue;
    const { start, len } = trackSpan(t, media[t.mediaId]?.duration ?? 0, total);
    if (len > 0) out.push({ trackId: t.id, start, end: start + len });
  }
  return out;
}

/** Linear gain 0..1 of something suppressed by `intervals` at output time `t`. */
export function envelopeGain(
  intervals: readonly Pick<ReplacementInterval, "start" | "end">[],
  t: number,
  fade = OVERRIDE_FADE_SEC,
): number {
  let g = 1;
  for (const { start, end } of intervals) {
    const ramp = Math.max((start - t) / fade, (t - end) / fade);
    g *= Math.min(1, Math.max(0, ramp));
  }
  return g;
}

/**
 * The intervals that silence track `trackId`: replacements by voice-over takes
 * added AFTER it (latest wins). A take never silences itself, and music beds are
 * never silenced (they are separate sources).
 */
export function suppressorsOf(
  tracks: readonly AudioTrack[],
  intervals: readonly ReplacementInterval[],
  trackId: string,
): ReplacementInterval[] {
  const i = tracks.findIndex((t) => t.id === trackId);
  if (i < 0 || !isVoiceOver(tracks[i]!)) return [];
  const later = new Set(tracks.slice(i + 1).map((t) => t.id));
  return intervals.filter((r) => later.has(r.trackId));
}

/** Linear gain (0..) a track contributes at output time `t`, fades included. 0 outside its span. */
export function trackGainAt(
  track: AudioTrack,
  mediaDuration: number,
  total: number,
  t: number,
): number {
  const { start, len } = trackSpan(track, mediaDuration, total);
  const local = t - start;
  if (!(local >= 0 && local < len)) return 0;
  const { fadeIn, fadeOut } = resolveFades(track.fadeInSec, track.fadeOutSec, len);
  let env = 1;
  if (fadeIn > 0 && local < fadeIn) env = Math.min(env, local / fadeIn);
  if (fadeOut > 0 && local > len - fadeOut) env = Math.min(env, (len - local) / fadeOut);
  return env * Math.pow(10, (Number.isFinite(track.gainDb) ? track.gainDb : 0) / 20);
}

export interface PreviewVoice {
  trackId: string;
  mediaId: string;
  /** Position inside the track's media, seconds. */
  mediaTime: number;
  /** Linear gain at this instant (may exceed 1 for boosted tracks). */
  gain: number;
}

/** Which tracks should be sounding at output time `t`, and where in their media. */
export function previewVoices(
  tracks: readonly AudioTrack[],
  media: Readonly<Record<string, Pick<SourceMedia, "duration">>>,
  total: number,
  t: number,
): PreviewVoice[] {
  const out: PreviewVoice[] = [];
  const intervals = replacementIntervals(tracks, media, total);
  for (const track of audibleTracks(tracks)) {
    const m = media[track.mediaId];
    if (!m) continue;
    const gain =
      trackGainAt(track, m.duration, total, t) *
      envelopeGain(suppressorsOf(tracks, intervals, track.id), t);
    const { start } = trackSpan(track, m.duration, total);
    if (t >= start && gain > 0) {
      out.push({
        trackId: track.id,
        mediaId: track.mediaId,
        mediaTime: t - start + trackMediaStart(track),
        gain,
      });
    }
  }
  return out;
}
