/** Opt-in, bounded local measurements. No content, paths, or network requests. */
export type TimingKind =
  | "frameWork"
  | "frameInterval"
  | "seek"
  | "seekPresented"
  | "cut"
  | "longTask"
  | "reactCommit"
  | "save"
  | "heapBytes";
const LIMIT = 4096;
const timings = new Map<TimingKind, number[]>();
let enabled = false;
let memoryTimer: ReturnType<typeof globalThis.setInterval> | undefined;
let observer: InstanceType<typeof globalThis.PerformanceObserver> | null = null;
export function diagnosticsEnabled() {
  return enabled;
}
export function recordTiming(kind: TimingKind, value: number) {
  if (!enabled || !Number.isFinite(value) || value < 0) return;
  const samples = timings.get(kind) ?? [];
  if (samples.length >= LIMIT) samples.splice(0, LIMIT / 4);
  samples.push(value);
  timings.set(kind, samples);
}
export function setDiagnosticsEnabled(value: boolean) {
  enabled = value;
  globalThis.clearInterval(memoryTimer);
  memoryTimer = value ? globalThis.setInterval(sampleMemory, 5000) : undefined;
  if (value) sampleMemory();
  observer?.disconnect();
  observer = null;
  if (
    value &&
    typeof globalThis.PerformanceObserver !== "undefined" &&
    globalThis.PerformanceObserver.supportedEntryTypes?.includes("longtask")
  ) {
    observer = new globalThis.PerformanceObserver((list) =>
      list.getEntries().forEach((e) => recordTiming("longTask", e.duration)),
    );
    observer.observe({ entryTypes: ["longtask"] });
  }
}
export function resetDiagnostics() {
  timings.clear();
}
export function diagnosticsReport() {
  const metrics: Record<string, { count: number; p50: number; p95: number; max: number }> = {};
  for (const [kind, samples] of timings) {
    const sorted = [...samples].sort((a, b) => a - b);
    const q = (p: number) => sorted[Math.max(0, Math.ceil(sorted.length * p) - 1)];
    metrics[kind] = {
      count: sorted.length,
      p50: q(0.5),
      p95: q(0.95),
      max: sorted[sorted.length - 1],
    };
  }
  return {
    enabled,
    sampleLimit: LIMIT,
    units: "milliseconds except heapBytes",
    metrics,
    notes: {
      seek: "request to seeked event, not presented frame",
      seekPresented: "request to first accepted playing frame; paused seeks unavailable",
      reactCommit: "requires development or profiling React build",
      heapBytes: "optional JS heap only; not process RSS",
    },
    unavailable: ["heapBytes", "longTask", "reactCommit", "seekPresented"].filter(
      (kind) => !timings.has(kind as TimingKind),
    ),
  };
}
export function sampleMemory() {
  const memory = (
    globalThis.performance as typeof globalThis.performance & {
      memory?: { usedJSHeapSize: number };
    }
  ).memory;
  if (memory) recordTiming("heapBytes", memory.usedJSHeapSize);
}
