/**
 * Resolve after the next painted frame, or after `timeoutMs`, whichever is first.
 * `requestAnimationFrame` never fires in a hidden or occluded WKWebView, so awaiting
 * it bare hangs forever once the window has been hidden (the recorder bar hides itself
 * before a take starts). The timeout turns "never" into a short fixed wait.
 */
export function nextPaint(timeoutMs = 120): Promise<void> {
  return new Promise<void>((resolve) => {
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      resolve();
    };
    globalThis.setTimeout(finish, timeoutMs);
    if (typeof globalThis.requestAnimationFrame === "function") {
      globalThis.requestAnimationFrame(() => finish());
    }
  });
}
