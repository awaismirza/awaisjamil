/**
 * Voice-over takes: pure model operations (no React, Tauri or store imports).
 *
 * A take is an `AudioTrack` with `kind: "voiceover"` (see edl.ts). It sits at an
 * output anchor (`offsetSec`) that follows its content through every edit by
 * segment-id lineage, like the music beds.
 *
 * - overlay: the take is mixed over the picture; the video timing never changes.
 * - insert:  the frame at the anchor is held (a freeze-frame `holdSec`, the same
 *   mechanism as the Timing panel) for the take's length, so everything after
 *   the anchor moves later by exactly that much and resumes on the next source
 *   frame. Routing through `computeTimeline` means captions, chapters, zoom,
 *   annotations, music and export all follow without special cases.
 * - override: the original clip audio is silent inside the take's replacement
 *   interval (`audioMix.replacementIntervals`); newer takes win over older ones.
 */

import { v4 as uuidv4 } from "uuid";
import {
  adjustInsertHold,
  computeTimeline,
  entryPlayEnd,
  entrySourceAt,
  entryOutputAt,
  insertTakeSec,
  isVoiceOver,
  projectAudioTracks,
  retimeAfterEdit,
  MAX_HOLD_SEC,
  segmentHold,
  totalDuration,
  voiceOverLength,
  type AudioTrack,
  type Project,
  type SourceMedia,
  type VoiceOverMode,
} from "./edl";
import { MIN_CLIP_SEC, splitClipAt } from "./clipEdit";
import { envelopeGain, replacementIntervals } from "./audioMix";

/** Takes shorter than this are treated as empty (a stray key press). */
export const MIN_TAKE_SEC = 0.3;

/**
 * Where a take was started, captured BEFORE recording begins so playback during
 * the take cannot move it. The clip identity lets the anchor survive edits made
 * while the take is recorded or reviewed.
 */
export interface VoiceOverAnchor {
  outputTime: number;
  segmentId?: string;
  mediaId?: string;
  /** Source time shown at the anchor inside that clip. */
  sourceTime?: number;
}

export function captureAnchor(project: Project, outputTime: number): VoiceOverAnchor {
  const total = totalDuration(project);
  const t = Math.max(0, Math.min(Number.isFinite(outputTime) ? outputTime : 0, total));
  const e = computeTimeline(project).find((x) => t >= x.outputStart && t < x.outputEnd);
  if (!e) return { outputTime: t };
  return {
    outputTime: t,
    segmentId: e.segmentId,
    mediaId: e.mediaId,
    sourceTime: entrySourceAt(e, t),
  };
}

/**
 * The anchor's output time in the project as it is now. `moved` is true when
 * its clip is gone and the stored output time (clamped) is used instead.
 */
export function resolveAnchor(
  project: Project,
  anchor: VoiceOverAnchor,
): { outputTime: number; moved: boolean } {
  const total = totalDuration(project);
  const tl = computeTimeline(project);
  if (anchor.segmentId !== undefined && anchor.sourceTime !== undefined) {
    const s = anchor.sourceTime;
    const same = tl.find((e) => e.segmentId === anchor.segmentId);
    if (same && s >= same.sourceIn && s <= same.sourceOut) {
      return { outputTime: Math.min(entryOutputAt(same, s), entryPlayEnd(same)), moved: false };
    }
    // Split or rebuilt since: the same source frame in a clip of the same media.
    const other = tl.find(
      (e) => e.mediaId === anchor.mediaId && s >= e.sourceIn && s < e.sourceOut,
    );
    if (other) return { outputTime: entryOutputAt(other, s), moved: false };
    return { outputTime: Math.min(anchor.outputTime, total), moved: true };
  }
  return { outputTime: Math.min(anchor.outputTime, total), moved: false };
}

/**
 * Hold the frame at output time `t` for `len` seconds. Returns the new project
 * and the output time where the held frame (and the narration) starts.
 * Splits the clip at `t` when needed; near a cut, the hold goes on the clip
 * that ends there; at the end, the last frame is held.
 */
export function insertHoldAt(
  project: Project,
  t: number,
  len: number,
): { project: Project; at: number; added: number } {
  if (project.segments.length === 0 || !(len > 0)) return { project, at: 0, added: 0 };
  const total = totalDuration(project);
  let at = Math.max(0, Math.min(t, total));
  let p = project;
  const tl = computeTimeline(p);
  let e = tl.find((x) => at >= x.outputStart && at < x.outputEnd) ?? tl[tl.length - 1]!;
  if (at < entryPlayEnd(e)) {
    const src = entrySourceAt(e, at);
    const seg = p.segments.find((s) => s.id === e.segmentId)!;
    const i = tl.indexOf(e);
    if (src - seg.sourceIn < MIN_CLIP_SEC && i > 0) {
      // On a cut: hold the clip that ends there.
      e = tl[i - 1]!;
      at = e.outputEnd;
    } else if (
      seg.sourceOut - src < MIN_CLIP_SEC ||
      seg.sourceOut - seg.sourceIn < 2 * MIN_CLIP_SEC
    ) {
      at = entryPlayEnd(e);
    } else {
      const s = Math.max(src, seg.sourceIn + MIN_CLIP_SEC);
      const splitAt = entryOutputAt(e, s);
      const split = splitClipAt(p, splitAt);
      const left = computeTimeline(split)[i];
      if (split !== p && left && Math.abs(entryPlayEnd(left) - splitAt) < 1e-6) {
        p = split;
        e = left;
        at = entryPlayEnd(left);
      } else {
        at = entryPlayEnd(e); // could not split here: hold the clip's last frame
      }
    }
  }
  // The narration starts where the clip's hold ends: after a freeze or earlier
  // insert takes already held there, so takes at one playhead never overlap.
  at = e.outputEnd;
  const seg = p.segments.find((s) => s.id === e.segmentId)!;
  const added = Math.max(0, Math.min(len, MAX_HOLD_SEC - segmentHold(seg)));
  if (added <= 0) return { project, at, added: 0 };
  const segments = p.segments.map((s) =>
    s.id === e.segmentId ? { ...s, holdSec: segmentHold(s) + added } : s,
  );
  return {
    project: retimeAfterEdit(p, { ...p, segments, updatedAt: new Date().toISOString() }),
    at,
    added,
  };
}

export interface NewTake {
  media: SourceMedia;
  /** Resolved output anchor. */
  at: number;
  mode: VoiceOverMode;
  overrideOriginal: boolean;
  gainDb?: number;
  /** Trim of the take (e.g. latency compensation), seconds. */
  sourceIn?: number;
  sourceOut?: number;
  id?: string;
}

/** Add a kept take (its media, the track and, for insert, the held frame) in one step. */
export function addVoiceOverTake(
  project: Project,
  take: NewTake,
): { project: Project; id: string } {
  const id = take.id ?? uuidv4();
  const base: AudioTrack = {
    id,
    mediaId: take.media.id,
    gainDb: take.gainDb ?? 0,
    offsetSec: Math.max(0, take.at),
    ducks: false,
    kind: "voiceover",
    mode: take.mode,
    ...(take.overrideOriginal ? { overrideOriginal: true } : {}),
    ...(take.sourceIn && take.sourceIn > 0 ? { sourceIn: take.sourceIn } : {}),
    ...(take.sourceOut !== undefined ? { sourceOut: take.sourceOut } : {}),
  };
  let next: Project = {
    ...project,
    media: { ...project.media, [take.media.id]: take.media },
    updatedAt: new Date().toISOString(),
  };
  const len = voiceOverLength(base, take.media.duration);
  if (take.mode === "insert" && len > 0 && next.segments.length > 0) {
    const held = insertHoldAt(next, take.at, len);
    next = held.project;
    base.offsetSec = held.at;
    base.insertSec = held.added;
    if (held.added <= 0) {
      base.mode = "overlay";
      delete base.insertSec;
    }
  } else {
    base.mode = "overlay";
  }
  return { project: { ...next, audioTracks: [...projectAudioTracks(next), base] }, id };
}

/** Switch a kept take between overlay and insert, adding or removing its held frame. */
export function setVoiceOverMode(project: Project, id: string, mode: VoiceOverMode): Project {
  const track = projectAudioTracks(project).find((t) => t.id === id);
  if (!track || !isVoiceOver(track) || (track.mode ?? "overlay") === mode) return project;
  const replace = (p: Project, patch: Partial<AudioTrack>): Project => ({
    ...p,
    audioTracks: projectAudioTracks(p).map((t) => {
      if (t.id !== id) return t;
      const next = { ...t, ...patch };
      if (patch.insertSec === undefined) delete next.insertSec;
      return next;
    }),
    updatedAt: new Date().toISOString(),
  });
  if (mode === "overlay") {
    const owned = insertTakeSec(track);
    const p = owned > 0 ? adjustInsertHold(project, id, -owned) : project;
    return replace(p, { mode: "overlay" });
  }
  const len = voiceOverLength(track, project.media[track.mediaId]?.duration ?? 0);
  if (len <= 0 || project.segments.length === 0) return project;
  // Insert the hold with the take itself out of the project, so retiming
  // cannot move its own anchor past the narration it is about to hold for.
  const others = {
    ...project,
    audioTracks: projectAudioTracks(project).filter((t) => t.id !== id),
  };
  const held = insertHoldAt(others, track.offsetSec, len);
  return {
    ...held.project,
    audioTracks: [
      ...projectAudioTracks(held.project).slice(0, indexOfTrack(project, id)),
      held.added > 0
        ? { ...track, mode: "insert", offsetSec: held.at, insertSec: held.added }
        : track,
      ...projectAudioTracks(held.project).slice(indexOfTrack(project, id)),
    ],
  };
}

const indexOfTrack = (p: Project, id: string) =>
  projectAudioTracks(p).findIndex((t) => t.id === id);

/** Seconds of the take that run past the end of the video (0 when it fits). */
export function voiceOverOverflow(project: Project, track: AudioTrack): number {
  const len = voiceOverLength(track, project.media[track.mediaId]?.duration ?? 0);
  return Math.max(0, Math.max(0, track.offsetSec) + len - totalDuration(project));
}

/** Linear gain of the original clip audio at output time `t` (override envelope). */
export function originalAudioGainAt(project: Project, t: number): number {
  const tracks = projectAudioTracks(project);
  if (!tracks.some((x) => x.overrideOriginal)) return 1;
  return envelopeGain(replacementIntervals(tracks, project.media, totalDuration(project)), t);
}

/** The voice-over takes in the project, in recording order. */
export function voiceOverTakes(project: Project): AudioTrack[] {
  return projectAudioTracks(project).filter(isVoiceOver);
}
