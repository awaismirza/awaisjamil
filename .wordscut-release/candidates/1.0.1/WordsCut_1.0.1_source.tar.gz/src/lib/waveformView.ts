import { entryAtOutput, type TimelineIndex } from "./timelineIndex";
import { entrySourceAt } from "./timeMap";
import type { PeakPyramid } from "./ipc";
/** Maximum amplitude in each visible pixel's source span. Silence stays zero.
 * Choose cached resolution near pixel density, including every touched bucket. */
export function waveformColumns(
  index: TimelineIndex,
  pyramids: Readonly<Record<string, PeakPyramid>>,
  left: number,
  width: number,
  pxPerSecond: number,
): Float32Array {
  const columns = new Float32Array(Math.max(0, Math.ceil(width)));
  if (pxPerSecond <= 0) return columns;
  for (let x = 0; x < columns.length; x++) {
    const start = (left + x) / pxPerSecond;
    const end = (left + x + 1) / pxPerSecond;
    let entry = entryAtOutput(index, start);
    while (entry && entry.outputStart < end) {
      const pyramid = pyramids[entry.mediaId];
      if (pyramid) {
        const samplesPerPixel = pyramid.sampleRate / pxPerSecond;
        let level = pyramid.levels[0];
        for (const candidate of pyramid.levels) {
          if (candidate.samplesPerPeak <= samplesPerPixel) level = candidate;
          else break;
        }
        if (level) {
          const rate = pyramid.sampleRate / level.samplesPerPeak;
          // Through the shared mapping: sped clips compress, holds read as silence.
          const a = entrySourceAt(entry, start);
          const b = entrySourceAt(entry, end);
          for (let i = Math.floor(a * rate); i < Math.ceil(b * rate) && i < level.peaks.length; i++)
            columns[x] = Math.max(columns[x], level.peaks[i] ?? 0);
        }
      }
      entry = index.entries[entry.index + 1] ?? null;
    }
  }
  return columns;
}
