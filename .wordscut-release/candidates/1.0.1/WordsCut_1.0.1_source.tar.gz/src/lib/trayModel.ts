/**
 * What the menu-bar item shows for each recorder phase. Pure module: the
 * recorder store feeds it the phase and shortcuts, the Rust tray applies the
 * result, and tests can check every state without a tray.
 */

import { formatTimecode } from "./timecode";
import { formatAccelerator, type ShortcutMap } from "./shortcuts";

export type TrayPhase = "idle" | "countdown" | "recording" | "paused" | "finalizing" | "processing";

export type TrayItemId = "record" | "pause" | "rerecord" | "mark" | "cancel" | "controller";

export interface TrayItemState {
  id: TrayItemId;
  label: string;
  enabled: boolean;
}

export interface TrayModel {
  /** Text shown next to the menu-bar icon, or null for icon only. */
  title: string | null;
  tooltip: string;
  items: TrayItemState[];
}

export interface TrayInput {
  phase: TrayPhase;
  elapsedSec: number;
  countdown: number;
  shortcuts: ShortcutMap;
  /** Key-name recording is on for this take; shown in the menu-bar title and tooltip. */
  keyNames?: "names" | "all" | null;
  /** Desktop controller state; only meaningful during a screen take. */
  controller?: { available: boolean; hidden: boolean };
}

export function trayModel({
  phase,
  elapsedSec,
  countdown,
  shortcuts,
  controller,
  keyNames,
}: TrayInput): TrayModel {
  const hint = (acc: string) => `    ${formatAccelerator(acc)}`;
  const time = formatTimecode(elapsedSec, { ms: false });

  const live = phase === "recording";
  const paused = phase === "paused";
  const session = live || paused;
  const busy = phase === "finalizing" || phase === "processing";

  let recordLabel = "Start Recording";
  if (session) recordLabel = "Stop and Add to Video";
  else if (phase === "countdown") recordLabel = "Starting…";
  else if (busy) recordLabel = phase === "finalizing" ? "Finishing up…" : "Adding recording…";

  const items: TrayItemState[] = [
    {
      id: "record",
      label: recordLabel + (session || phase === "idle" ? hint(shortcuts.record) : ""),
      enabled: phase === "idle" || session,
    },
    {
      id: "pause",
      label: (paused ? "Resume Recording" : "Pause Recording") + hint(shortcuts.pause),
      enabled: session,
    },
    {
      id: "rerecord",
      label: "Restart Take" + hint(shortcuts.rerecord),
      enabled: session,
    },
    {
      id: "mark",
      label: "Mark a Moment" + hint(shortcuts.mark),
      enabled: live,
    },
    {
      id: "cancel",
      label: "Discard Recording" + hint(shortcuts.cancel),
      enabled: session,
    },
    {
      id: "controller",
      label: controller?.hidden ? "Show Recording Controls" : "Hide Recording Controls",
      enabled: Boolean(controller?.available) && (session || phase === "finalizing"),
    },
  ];

  const keys = keyNames === "all" ? " · All characters ON" : keyNames ? " · Key names ON" : "";
  if (live) return { title: `● ${time}${keys}`, tooltip: `Recording ${time}${keys}`, items };
  if (paused) return { title: `❚❚ ${time}${keys}`, tooltip: `Paused at ${time}${keys}`, items };
  if (phase === "countdown") {
    return {
      title: countdown > 0 ? `${countdown}` : "…",
      tooltip: countdown > 0 ? "Recording starts soon" : "Starting capture…",
      items,
    };
  }
  if (busy) return { title: "…", tooltip: "Finishing the recording", items };
  return { title: null, tooltip: "WordsCut", items };
}
