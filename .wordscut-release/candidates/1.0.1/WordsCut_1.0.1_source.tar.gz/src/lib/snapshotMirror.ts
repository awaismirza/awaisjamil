/**
 * Keep a window's copy of the Rust recording session current.
 *
 * Subscribes to `record:snapshot` first, then fetches the current snapshot, and
 * only ever accepts a snapshot newer than the last one it applied — so the slower
 * initial fetch can never overwrite an event that already arrived. Used by
 * windows that only display/control the session (the desktop controller).
 */
import { getRecordingSnapshot, onRecordSnapshot, type RecordingSnapshot } from "@/lib/ipc";

export async function startSnapshotMirror(
  apply: (snapshot: RecordingSnapshot) => void,
  deps = { subscribe: onRecordSnapshot, fetch: getRecordingSnapshot },
): Promise<() => void> {
  let revision = -1;
  const accept = (snapshot: RecordingSnapshot) => {
    if (snapshot.revision <= revision) return;
    revision = snapshot.revision;
    apply(snapshot);
  };
  const unlisten = await deps.subscribe(accept);
  try {
    accept(await deps.fetch());
  } catch {
    /* the next event brings the state */
  }
  return unlisten;
}
