/**
 * Automatic chapter suggestions, computed from the transcript alone — no model,
 * no download, instant, and identical every time. Pure module (no React, Tauri
 * or store imports, same rule as edl.ts).
 *
 * Method (TextTiling-style topic segmentation):
 *   1. Group words into sentences (end punctuation, a long pause, or a cut).
 *   2. Score every sentence boundary: how different the vocabulary just before
 *      is from just after, plus a bonus for a pause, a cue phrase ("next",
 *      "let's move on") and a speaker change.
 *   3. Pick the best boundaries, keeping every chapter at least `minChapterSec`.
 *   4. Title each chapter from its opening sentence.
 *
 * Suggestions are only proposals: the UI lets the user edit or drop each one.
 */

import { computeTimeline, entryOutputAt, totalDuration, type Project, type Word } from "./edl";

export interface ChapterSuggestion {
  /** Position on the OUTPUT timeline, in seconds. */
  outputTime: number;
  title: string;
}

export interface AutoChapterOptions {
  /** Chapters wanted. Omit for a length-based default (about one per 90 s). */
  count?: number;
  /** No chapter may be shorter than this, in seconds. YouTube needs 10 s. */
  minChapterSec?: number;
}

export const DEFAULT_MIN_CHAPTER_SEC = 10;
const SECONDS_PER_CHAPTER = 90;
const MAX_AUTO_CHAPTERS = 12;
const SENTENCE_PAUSE_SEC = 0.9;
/** Window sizes (sentences each side) whose vocabulary distances are averaged. */
const WINDOW_SIZES = [2, 3, 4];
const TITLE_MAX_WORDS = 7;

const STOPWORDS = new Set(
  (
    "a about above after again all also am an and any are as at be because been before being below " +
    "between both but by can could did do does doing down during each few for from further get got " +
    "gonna had has have having he her here hers him his how i if in into is it its just kind let like " +
    "lot me more most my no nor not now of off on once one only or other our out over own really same " +
    "she should so some such than that the their them then there these they this those through to too " +
    "under until up us very want was we were what when where which while who why will with would yeah " +
    "you your um uh er erm ah hmm okay ok right well yes sort thing things going look looking"
  ).split(" "),
);

const LEADING_FILLERS = new Set([
  "so",
  "okay",
  "ok",
  "and",
  "but",
  "now",
  "alright",
  "right",
  "well",
  "um",
  "uh",
  "then",
  "also",
  "yeah",
  "like",
]);

const GREETING = /^(hey|hi|hello|welcome|good (morning|afternoon|evening)|what'?s up)\b/i;

/** Phrases that usually open a new section. */
const CUE_PHRASES =
  /^(next|now let'?s|now we|moving on|let'?s (talk|move|look|start|dive|get)|first(ly)?|second(ly)?|third(ly)?|finally|lastly|another|in this (section|part)|to start|to begin|step \d|number \d|the next|so let'?s|okay so let'?s|alright)\b/i;

interface Sentence {
  words: Word[];
  text: string;
  /** Output-timeline start of the first word. */
  start: number;
  /** Pause before this sentence within the same take, in seconds. */
  gapBefore: number;
  terms: string[];
  speaker?: string;
}

function termsOf(text: string): string[] {
  const out: string[] = [];
  for (const raw of text.toLowerCase().split(/[^a-z']+/)) {
    const w = raw.replace(/^'+|'+$/g, "");
    if (w.length < 3 || STOPWORDS.has(w)) continue;
    out.push(w.length > 4 && w.endsWith("s") ? w.slice(0, -1) : w);
  }
  return out;
}

function toSentences(project: Project): Sentence[] {
  const timeline = computeTimeline(project);
  const sentences: Sentence[] = [];
  for (const entry of timeline) {
    const seg = project.segments.find((s) => s.id === entry.segmentId);
    if (!seg || seg.words.length === 0) continue;
    let current: Word[] = [];
    let gapBefore = 0;
    const flush = (start: number) => {
      if (current.length === 0) return;
      const text = current.map((w) => w.text.trim()).join(" ");
      sentences.push({
        words: current,
        text,
        start,
        gapBefore,
        terms: termsOf(text),
        speaker: current[0]!.speaker,
      });
      current = [];
    };
    let startOut = 0;
    seg.words.forEach((w, i) => {
      if (current.length === 0) {
        startOut = entryOutputAt(entry, Math.max(entry.sourceIn, w.start));
        const prev = seg.words[i - 1];
        gapBefore = prev ? Math.max(0, w.start - prev.end) : 0;
      }
      current.push(w);
      const next = seg.words[i + 1];
      const endsSentence = /[.?!]["')\]]*$/.test(w.text.trim());
      const longPause = next ? next.start - w.end >= SENTENCE_PAUSE_SEC : false;
      if (endsSentence || longPause || !next) flush(startOut);
    });
  }
  return sentences;
}

function termCounts(sentences: Sentence[]): Map<string, number> {
  const m = new Map<string, number>();
  for (const s of sentences) for (const t of s.terms) m.set(t, (m.get(t) ?? 0) + 1);
  return m;
}

function cosine(a: Map<string, number>, b: Map<string, number>): number | null {
  if (a.size === 0 || b.size === 0) return null;
  let dot = 0;
  let na = 0;
  let nb = 0;
  for (const [, v] of a) na += v * v;
  for (const [, v] of b) nb += v * v;
  for (const [k, v] of a) dot += v * (b.get(k) ?? 0);
  return dot / Math.sqrt(na * nb);
}

/** Score the boundary after sentence `i` (between i and i + 1). Higher = better chapter start. */
function boundaryScore(sentences: Sentence[], i: number): number {
  // Averaging several window sizes breaks ties: a real topic change is distant
  // at every size, while a gap inside one topic is only distant at small ones.
  let lexical = 0;
  for (const k of WINDOW_SIZES) {
    const left = sentences.slice(Math.max(0, i - k + 1), i + 1);
    const right = sentences.slice(i + 1, i + 1 + k);
    const sim = cosine(termCounts(left), termCounts(right));
    lexical += sim === null ? 0.5 : 1 - sim;
  }
  lexical /= WINDOW_SIZES.length;
  const next = sentences[i + 1]!;
  const prev = sentences[i]!;
  const pause = (Math.min(next.gapBefore, 3) / 3) * 0.25;
  const cue = CUE_PHRASES.test(next.text) ? 0.25 : 0;
  const speaker = prev.speaker && next.speaker && prev.speaker !== next.speaker ? 0.15 : 0;
  return lexical * 0.6 + pause + cue + speaker;
}

function titleFor(sentences: Sentence[], isFirst: boolean, index: number): string {
  const first = sentences[0];
  if (!first) return `Chapter ${index + 1}`;
  if (isFirst && GREETING.test(first.text)) return "Introduction";
  const words = first.text.split(/\s+/);
  while (words.length > 1 && LEADING_FILLERS.has(words[0]!.toLowerCase().replace(/[^a-z']/g, ""))) {
    words.shift();
  }
  const clipped = words
    .slice(0, TITLE_MAX_WORDS)
    .join(" ")
    .replace(/[\s.,!?;:—–-]+$/g, "");
  if (!clipped) return `Chapter ${index + 1}`;
  return clipped.charAt(0).toUpperCase() + clipped.slice(1);
}

/** Default chapter count for a video of `durationSec`, honouring the minimum length. */
export function defaultChapterCount(durationSec: number, minChapterSec = DEFAULT_MIN_CHAPTER_SEC) {
  const byLength = Math.round(durationSec / SECONDS_PER_CHAPTER);
  const possible = Math.max(1, Math.floor(durationSec / minChapterSec));
  return Math.max(1, Math.min(MAX_AUTO_CHAPTERS, possible, Math.max(2, byLength)));
}

/**
 * Suggest chapters for the current EDL. The first chapter is always at 0:00.
 * Returns a single chapter when the video is too short to split.
 */
export function suggestChapters(
  project: Project,
  options: AutoChapterOptions = {},
): ChapterSuggestion[] {
  const minLen = options.minChapterSec ?? DEFAULT_MIN_CHAPTER_SEC;
  const duration = totalDuration(project);
  const sentences = toSentences(project);
  if (sentences.length === 0) return [];

  const wanted = Math.max(1, Math.round(options.count ?? defaultChapterCount(duration, minLen)));

  // Candidate boundaries: the start of every sentence after the first.
  const candidates = sentences
    .slice(1)
    .map((s, k) => ({ index: k + 1, time: s.start, score: boundaryScore(sentences, k) }))
    .filter((c) => c.time >= minLen && duration - c.time >= minLen)
    .sort((a, b) => b.score - a.score);

  const chosen: typeof candidates = [];
  for (const c of candidates) {
    if (chosen.length >= wanted - 1) break;
    if (chosen.every((o) => Math.abs(o.time - c.time) >= minLen)) chosen.push(c);
  }
  chosen.sort((a, b) => a.index - b.index);

  const starts = [{ index: 0, time: 0 }, ...chosen];
  return starts.map((c, n) => {
    const end = starts[n + 1]?.index ?? sentences.length;
    return {
      outputTime: c.time,
      title: titleFor(sentences.slice(c.index, end), n === 0, n),
    };
  });
}
