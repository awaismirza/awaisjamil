/**
 * Native Apple media engine: render-plan compiler, timing mirror and the
 * engine choice. Contract: `docs/native-engine.md`. The Swift side lives in
 * `native/yusafcut-engine` (EngineCore mirrors the timing rules below; the
 * parity fixture `tests/fixtures/native-engine-timing.json` pins both).
 *
 * Nothing here changes behaviour: `chooseEngine` returns "fallback" unless the
 * caller passes `enabled: true`, and no setting or UI does that yet.
 *
 * Pure apart from `nativeEngineCapabilities` (one Tauri invoke).
 */

import { invoke } from "@tauri-apps/api/core";
import { audibleTracks } from "./audioMix";
import { sceneActive } from "./scene";
import { isVoiceOver, segmentHold, segmentSpeed, type Project } from "./edl";

export const RENDER_PLAN_VERSION = 1;
/** Ticks per second of every plan time on the native side (Core Media timescale). */
export const TICKS_PER_SECOND = 90_000;

// ---------------------------------------------------------------------------
// Plan schema (mirrors native/yusafcut-engine/Sources/EngineCore/RenderPlan.swift)
// ---------------------------------------------------------------------------

export interface RationalFps {
  num: number;
  den: number;
}

export interface NormRect {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface PlanSource {
  id: string;
  path: string;
  duration?: number;
  hasVideo?: boolean;
  hasAudio?: boolean;
  crop?: NormRect;
}

export interface PlanClip {
  sourceId: string;
  sourceIn: number;
  sourceOut: number;
  speed?: number;
  holdSec?: number;
  muted?: boolean;
}

export interface GroupTrack {
  sourceId: string;
  role: "camera" | "audio";
  /** Seconds the track started after the primary source. Track time = source time - offsetSec. */
  offsetSec: number;
  gainDb?: number;
  placement?: NormRect;
}

export interface RecordingGroup {
  primarySourceId: string;
  tracks: GroupTrack[];
}

export interface AudioBed {
  sourceId: string;
  offsetSec: number;
  gainDb: number;
}

export interface RenderPlan {
  version: number;
  generation?: number;
  fps: RationalFps;
  /** Snap clips and holds to whole output frames. Absent = true. */
  quantize?: boolean;
  /** Fallback codes for features present that the engine cannot do, in REQUIRE_ORDER. */
  requires?: string[];
  sources: PlanSource[];
  clips: PlanClip[];
  groups?: RecordingGroup[];
  audioBeds?: AudioBed[];
}

// ---------------------------------------------------------------------------
// Reason codes (stable strings; mirror EngineCore/Reasons.swift and engine_bridge.rs)
// ---------------------------------------------------------------------------

/** Unsupported features, in the order the compiler reports them. */
export const REQUIRE_ORDER = [
  "transition",
  "zoom",
  "cursor",
  "scene",
  "device-frame",
  "crop",
  "captions",
  "annotations",
  "keystrokes",
  "overlays",
  "privacy-mask",
  "voice-over",
  "music-ducking",
  "audio-fade",
] as const;
export type UnsupportedFeature = (typeof REQUIRE_ORDER)[number];

/** Why the fallback engine was chosen. */
export type FallbackReason =
  | "disabled-by-setting"
  | "helper-missing"
  | "helper-failed"
  | "helper-timeout"
  | "helper-bad-output"
  | "disabled-by-env"
  | "macos-too-old"
  | "not-apple-silicon"
  | "no-metal-device"
  | "plan-version-unsupported"
  | "plan-empty"
  | "level-unavailable"
  | UnsupportedFeature
  | "unknown-feature"
  | (string & {});

// ---------------------------------------------------------------------------
// Timing (mirror of EngineCore/PlanTiming.swift: change both together)
// ---------------------------------------------------------------------------

export function toTicks(seconds: number): number {
  return Math.round(seconds * TICKS_PER_SECOND);
}

/** Ticks per output frame, or null when the rate is not whole ticks. */
export function frameTicks(fps: RationalFps): number | null {
  if (!(fps.num > 0 && fps.den > 0)) return null;
  const n = TICKS_PER_SECOND * fps.den;
  return n % fps.num === 0 ? n / fps.num : null;
}

/**
 * Whole frames per length by error diffusion over the running total (same rule
 * as `export_plan.rs::frame_counts` and `PlanTiming.frameCounts`).
 */
export function frameCounts(lens: readonly number[], fps: number): number[] {
  const out: number[] = [];
  let total = 0;
  let emitted = 0;
  for (const raw of lens) {
    const d = Number.isFinite(raw) ? Math.max(raw, 0) : 0;
    total += d;
    const n = Math.max(roundHalfAway((total - emitted) * fps + 1e-9), 0);
    emitted += n / fps;
    out.push(n);
  }
  if (!out.some((n) => n !== 0)) {
    const i = lens.findIndex((d) => Number.isFinite(d) && d > 0);
    if (i >= 0) out[i] = 1;
  }
  return out;
}

/** Swift `.rounded()` / Rust `f64::round`: halves away from zero. */
function roundHalfAway(x: number): number {
  return x < 0 ? -Math.round(-x) : Math.round(x);
}

function clipSpeed(c: PlanClip): number {
  return c.speed ?? 1;
}

function playSeconds(c: PlanClip): number {
  return Math.max(0, c.sourceOut - c.sourceIn) / clipSpeed(c);
}

export interface ClipTiming {
  clipIndex: number;
  sourceStart: number;
  consumed: number;
  play: number;
  hold: number;
  outputStart: number;
}

/** Where each clip lands, in ticks. Clips with no output are omitted. */
export function planLayout(plan: RenderPlan): ClipTiming[] {
  const out: ClipTiming[] = [];
  let cursor = 0;
  const ft = frameTicks(plan.fps);
  if ((plan.quantize ?? true) && ft !== null) {
    const lens: number[] = [];
    for (const c of plan.clips) {
      const play = playSeconds(c);
      lens.push(play, play > 0 ? Math.max(0, c.holdSec ?? 0) : 0);
    }
    const n = frameCounts(lens, plan.fps.num / plan.fps.den);
    plan.clips.forEach((c, i) => {
      const play = n[2 * i]! * ft;
      const hold = n[2 * i + 1]! * ft;
      if (play + hold === 0) return;
      const speed = clipSpeed(c);
      const consumed = speed === 1 ? play : roundHalfAway(play * speed);
      out.push({
        clipIndex: i,
        sourceStart: toTicks(Math.max(0, c.sourceIn)),
        consumed,
        play,
        hold,
        outputStart: cursor,
      });
      cursor += play + hold;
    });
  } else {
    plan.clips.forEach((c, i) => {
      const start = toTicks(Math.max(0, c.sourceIn));
      const consumed = Math.max(0, toTicks(c.sourceOut) - start);
      if (consumed === 0) return;
      const speed = clipSpeed(c);
      const play = speed === 1 ? consumed : roundHalfAway(consumed / speed);
      const hold = toTicks(Math.max(0, c.holdSec ?? 0));
      out.push({ clipIndex: i, sourceStart: start, consumed, play, hold, outputStart: cursor });
      cursor += play + hold;
    });
  }
  return out;
}

/** Total output ticks of a plan (what the native composition must last). */
export function planDurationTicks(plan: RenderPlan): number {
  const l = planLayout(plan);
  const last = l[l.length - 1];
  return last ? last.outputStart + last.play + last.hold : 0;
}

/** A float frame rate as an exact rational (NTSC rates become x000/1001). */
export function rationalFps(fps: number): RationalFps {
  if (!Number.isFinite(fps) || fps <= 0) return { num: 30, den: 1 };
  const ntsc = Math.round(fps * 1.001);
  if (Math.abs(fps - ntsc / 1.001) < 0.005 && Math.abs(fps - Math.round(fps)) > 0.005) {
    return { num: ntsc * 1000, den: 1001 };
  }
  return { num: Math.max(1, Math.round(fps)), den: 1 };
}

// ---------------------------------------------------------------------------
// Compiler: Project (EDL) -> RenderPlan
// ---------------------------------------------------------------------------

export interface CompileOptions {
  generation?: number;
  quantize?: boolean;
  /** The export burns captions in (an export option, not part of the project). */
  burnCaptions?: boolean;
  /**
   * Recording groups (camera / extra audio on a shared clock). The project has
   * no such field yet; the recording slice will supply it.
   */
  groups?: RecordingGroup[];
}

/** Features of `project` the native engine cannot do yet, in REQUIRE_ORDER. */
export function unsupportedFeatures(
  project: Project,
  opts: CompileOptions = {},
): UnsupportedFeature[] {
  const used = new Set(project.segments.map((s) => s.mediaId));
  const tracks = project.audioTracks ?? [];
  const beds = audibleTracks(tracks).filter((t) => !isVoiceOver(t));
  const scene = sceneActive(project.scene) ? project.scene : undefined;
  const cursor = project.cursor;
  const has: Record<UnsupportedFeature, boolean> = {
    transition: project.segments.some((s, i) => i > 0 && !!s.transitionIn),
    zoom: (project.zoomRegions?.length ?? 0) > 0,
    cursor: !!cursor && cursor.style.show && Object.keys(cursor.tracks).some((id) => used.has(id)),
    scene: !!scene,
    "device-frame": !!scene?.frame,
    crop: !!scene?.crop,
    captions: !!opts.burnCaptions,
    annotations: (project.annotations?.length ?? 0) > 0,
    keystrokes: !!project.keystrokes?.enabled,
    overlays: (project.overlays?.length ?? 0) > 0,
    "privacy-mask": (project.masks?.length ?? 0) > 0,
    "voice-over": tracks.some(isVoiceOver),
    "music-ducking": beds.some((t) => t.ducks),
    "audio-fade": beds.some((t) => (t.fadeInSec ?? 0) > 0 || (t.fadeOutSec ?? 0) > 0),
  };
  return REQUIRE_ORDER.filter((f) => has[f]);
}

/**
 * Compile the EDL into a render plan. Always succeeds; what the engine cannot
 * do is listed in `requires` so the choice can route it to the fallback.
 */
export function compileRenderPlan(project: Project, opts: CompileOptions = {}): RenderPlan {
  const clips: PlanClip[] = [];
  for (const seg of project.segments) {
    if (!(seg.sourceOut > seg.sourceIn)) continue;
    const speed = segmentSpeed(seg);
    const hold = segmentHold(seg);
    clips.push({
      sourceId: seg.mediaId,
      sourceIn: seg.sourceIn,
      sourceOut: seg.sourceOut,
      ...(speed !== 1 ? { speed } : {}),
      ...(hold > 0 ? { holdSec: hold } : {}),
      ...(seg.muted ? { muted: true } : {}),
    });
  }
  const beds = audibleTracks(project.audioTracks ?? []).filter((t) => !isVoiceOver(t));
  const ids = new Set<string>(clips.map((c) => c.sourceId));
  for (const b of beds) ids.add(b.mediaId);
  for (const g of opts.groups ?? []) for (const t of g.tracks) ids.add(t.sourceId);
  const sources: PlanSource[] = [];
  for (const id of ids) {
    const m = project.media[id];
    if (!m) continue;
    sources.push({
      id,
      path: m.path,
      duration: m.duration,
      hasVideo: m.width > 0 && m.height > 0,
      hasAudio: m.audioSampleRate > 0,
    });
  }
  const first = clips[0] ? project.media[clips[0].sourceId] : undefined;
  const requires = unsupportedFeatures(project, opts);
  return {
    version: RENDER_PLAN_VERSION,
    ...(opts.generation !== undefined ? { generation: opts.generation } : {}),
    fps: rationalFps(first?.fps ?? 30),
    ...(opts.quantize === false ? { quantize: false } : {}),
    ...(requires.length ? { requires } : {}),
    sources,
    clips,
    ...(opts.groups?.length ? { groups: opts.groups } : {}),
    ...(beds.length
      ? {
          audioBeds: beds.map((b) => ({
            sourceId: b.mediaId,
            offsetSec: b.offsetSec,
            gainDb: b.gainDb,
          })),
        }
      : {}),
  };
}

// ---------------------------------------------------------------------------
// Capabilities and the engine choice
// ---------------------------------------------------------------------------

export type EngineLevel = "probe" | "preview" | "export";

/** What `native_engine_capabilities` returns (helper JSON, or a stub when absent). */
export interface NativeEngineCapabilities {
  available: boolean;
  reason?: string | null;
  engineVersion?: string;
  planVersion?: number;
  macosVersion?: string;
  appleSilicon?: boolean;
  videoToolbox?: {
    h264Encode: boolean;
    hevcEncode: boolean;
    h264Hardware: boolean;
    hevcHardware: boolean;
  };
  metal?: { available: boolean; name?: string | null };
  levels?: string[];
}

/** Opt-in switch. No setting or UI sets it yet: native stays off everywhere. */
export interface NativeEngineSettings {
  enabled: boolean;
}
export const DEFAULT_NATIVE_ENGINE_SETTINGS: NativeEngineSettings = { enabled: false };

export interface EngineChoice {
  engine: "native" | "fallback";
  /** Null only when native was chosen. */
  reason: FallbackReason | null;
}

/**
 * Pick the engine for `operation`. Fallback unless everything lines up: the
 * opt-in is on, the helper is present and capable, the plan has nothing the
 * engine cannot do, and the helper implements that operation's level.
 */
export function chooseEngine(
  plan: RenderPlan,
  caps: NativeEngineCapabilities | null | undefined,
  opts: { settings?: NativeEngineSettings; operation?: EngineLevel } = {},
): EngineChoice {
  const settings = opts.settings ?? DEFAULT_NATIVE_ENGINE_SETTINGS;
  const operation = opts.operation ?? "preview";
  const fallback = (reason: FallbackReason): EngineChoice => ({ engine: "fallback", reason });
  if (!settings.enabled) return fallback("disabled-by-setting");
  if (!caps || !caps.available) return fallback(caps?.reason || "helper-missing");
  if ((caps.planVersion ?? RENDER_PLAN_VERSION) !== plan.version) {
    return fallback("plan-version-unsupported");
  }
  if (plan.clips.length === 0) return fallback("plan-empty");
  const first = plan.requires?.[0];
  if (first) {
    return fallback(
      (REQUIRE_ORDER as readonly string[]).includes(first) ? first : "unknown-feature",
    );
  }
  if (plan.sources.some((s) => s.crop)) return fallback("crop");
  if (!(caps.levels ?? []).includes(operation)) return fallback("level-unavailable");
  return { engine: "native", reason: null };
}

// ---------------------------------------------------------------------------
// Latest-request-wins
// ---------------------------------------------------------------------------

/**
 * Hands out increasing generation numbers; only the newest is current. A
 * result whose generation is not current is dropped, never applied.
 */
export class GenerationGate {
  private current = 0;
  next(): number {
    this.current += 1;
    return this.current;
  }
  isCurrent(generation: number | undefined | null): boolean {
    return generation === this.current;
  }
  /** Cancel everything in flight (e.g. project switch). */
  invalidate(): void {
    this.current += 1;
  }
}

// ---------------------------------------------------------------------------
// IPC
// ---------------------------------------------------------------------------

/** Ask the backend whether the native engine helper is present and what it can do. */
export function nativeEngineCapabilities(): Promise<NativeEngineCapabilities> {
  return invoke<NativeEngineCapabilities>("native_engine_capabilities");
}
