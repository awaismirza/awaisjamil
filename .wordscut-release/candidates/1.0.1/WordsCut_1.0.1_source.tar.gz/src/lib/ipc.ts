/**
 * Wrappers around `@tauri-apps/api` `invoke` calls. These functions are the
 * *only* place in the frontend that talks to Rust. Keep the shape of each call
 * in sync with the Rust commands in `src-tauri/src/commands/`.
 *
 * Each function returns a typed Promise. If a Rust command rejects with a
 * string, it surfaces as a thrown error here.
 */

import { Channel, invoke } from "@tauri-apps/api/core";
import { listen, type UnlistenFn } from "@tauri-apps/api/event";
import type { Project, SourceMedia, Word } from "./edl";
import type { CaptionExportCue } from "./captionLayout";
import type { CaptionStyle } from "./captionStyle";
import type { SceneRender } from "./scene";
import type { ZoomRegion } from "./zoom";
import type { TrayModel } from "./trayModel";

// ---------------------------------------------------------------------------
// Media import
// ---------------------------------------------------------------------------

/** Probe a video file with ffprobe and return parsed metadata. */
export function importMedia(path: string): Promise<SourceMedia> {
  return invoke<SourceMedia>("import_media", { path });
}

/**
 * Metadata only, without reading the whole file: `sha256` is "" (no checksum
 * recorded). Compute it afterwards with `hashMedia` and attach it with
 * `attachDeferredChecksum` (src/lib/recordingHandoff.ts).
 */
export function probeMedia(path: string): Promise<SourceMedia> {
  return invoke<SourceMedia>("probe_media", { path });
}

// ---------------------------------------------------------------------------
// Recorder
// ---------------------------------------------------------------------------

export type RecordMode = "screen" | "screen-camera" | "camera" | "voiceover";
export type PipCorner = "top-left" | "top-right" | "bottom-left" | "bottom-right";
export type PipSize = "small" | "medium" | "large";

export interface VideoDevice {
  index: number;
  name: string;
  isScreen: boolean;
}

export interface AudioDevice {
  index: number;
  name: string;
}

/** A capturable window (native recorder only). */
export interface WindowDevice {
  id: number;
  title: string;
  app: string;
}

/** A screen's size in points (native recorder only), keyed like its VideoDevice. */
export interface DisplayInfo {
  index: number;
  width: number;
  height: number;
}

/** A rectangle of one display in that display's points, origin top-left. */
export interface AreaRect {
  x: number;
  y: number;
  width: number;
  height: number;
}

export type PermissionKind = "screenRecording" | "camera" | "microphone" | "inputMonitoring";
export type PermissionState = "granted" | "denied" | "notDetermined" | "restricted";
export type SourceKind = "display" | "window" | "area";

export interface RecordingDevices {
  video: VideoDevice[];
  audio: AudioDevice[];
  /** "native" (ScreenCaptureKit helper) or "ffmpeg" (avfoundation fallback). */
  backend?: "native" | "ffmpeg";
  /** Native recorder only. */
  windows?: WindowDevice[];
  /** Native recorder only: screenRecording / camera / microphone / inputMonitoring states. */
  permissions?: Partial<Record<PermissionKind, PermissionState>> | null;
  /** Native recorder only: screen sizes for area selection. */
  displays?: DisplayInfo[];
}

export interface RecordOptions {
  mode: RecordMode;
  screenIndex?: number;
  cameraIndex?: number;
  /** Omit to record without a microphone. */
  audioIndex?: number;
  fps?: number;
  pipCorner?: PipCorner;
  pipSize?: PipSize;
  /** Which screen source the setup panel chose (display / window / area). UI-only. */
  sourceKind?: SourceKind;
  /** Native recorder only: capture this window instead of the whole screen. */
  windowId?: number;
  /** Native recorder only: capture this rectangle of the chosen screen. */
  area?: AreaRect;
  /** Native recorder only: also record the screen's system audio. */
  systemAudio?: boolean;
  /** Echoed in the result: "voiceover-take" goes to the voice-over review, not the timeline. */
  purpose?: RecordPurpose;
  /**
   * Native recorder only, opt-in (default off): also log which shortcut and
   * non-printable keys were pressed. See docs/cursor-events.md.
   */
  recordKeyIdentity?: boolean;
  /** Second opt-in, needs `recordKeyIdentity`: also log ordinary typed characters. */
  recordAllCharacters?: boolean;
}

export type RecordPurpose = "voiceover-take";

export type SessionPhase =
  | "idle"
  | "starting"
  | "recording"
  | "paused"
  | "finalizing"
  | "interrupted";

/**
 * The authoritative recording session, owned by Rust. Every window mirrors it:
 * fetch once (after subscribing) and keep whichever snapshot has the higher
 * `revision`. Actions must name `sessionId`; Rust rejects stale ones.
 */
export interface RecordingSnapshot {
  revision: number;
  sessionId: string | null;
  phase: SessionPhase;
  backend: "native" | "ffmpeg" | null;
  mode: RecordMode | null;
  /** Captured media time, not wall time. */
  elapsedSec: number;
  markers: number[];
  /** Latest problem for this (or the previous) take. */
  error: string | null;
  /** The user hid the desktop recording controller for this take. */
  controllerHidden: boolean;
  /** Key-name recording is on for this take (names only, or every character). */
  keyNames?: "names" | "all" | null;
}

export interface RecordingResult {
  sessionId: string;
  path: string;
  durationSec: number;
  mode: RecordMode;
  /** Native recorder only: folder with the separate aligned tracks + events.jsonl. */
  tracksDir?: string;
  /** Native recorder only: cursor/click/key log, format in docs/cursor-events.md. */
  eventsPath?: string;
  /** Elapsed media time of each "mark a moment" press. */
  markers: number[];
  /** The take was kept but something degraded (e.g. the camera was dropped). */
  warning?: string;
  /** `RecordOptions.purpose` of the take. */
  purpose?: RecordPurpose;
  /**
   * Native screen + camera takes: the camera was not composited at Stop. `path`
   * is the screen picture with the audio mix; the camera is a separate file and
   * is added by `compositeRecordingCamera` in the background.
   */
  camera?: RecordingCamera;
}

export interface RecordingCamera {
  /** `tracks/camera.mp4` of the take. */
  path: string;
  /** Seconds to add to the camera file's timestamps (0: shared take origin). */
  offsetSec: number;
  pipCorner: PipCorner;
  pipSize: PipSize;
}

/**
 * Background picture-in-picture of a screen + camera take: the file Stop
 * produced before 4.49, except that a camera which ended early only removes
 * the bubble (the picture always spans the screen track). Rust refuses a result
 * whose video length, size or sound differs from `screenPath`. Resolves with its path; `onStarted` receives the
 * job id first so the caller can `cancelJob` it. Changes nothing in the project.
 */
export function compositeRecordingCamera(
  request: {
    tracksDir: string;
    screenPath: string;
    pipCorner?: PipCorner;
    pipSize?: PipSize;
    /** Paths the project references: leftover composites among them are never swept. */
    keep?: string[];
  },
  onStarted: (jobId: string) => void,
): Promise<string> {
  const onEvent = new Channel<{ event: "started"; jobId: string }>();
  onEvent.onmessage = (message) => {
    if (message.event === "started") onStarted(message.jobId);
  };
  return invoke<string>("composite_recording_camera", { request, onEvent });
}

/** Delete a `camera-composite-*.mp4` the editor did not swap in (take folder only). */
export function discardRecordingComposite(path: string): Promise<void> {
  return invoke<void>("discard_recording_composite", { path });
}

/** Enumerate avfoundation screens, cameras, and microphones. */
export function listRecordingDevices(): Promise<RecordingDevices> {
  return invoke<RecordingDevices>("list_recording_devices");
}

/** Show the system prompts for these permissions; resolves with the new states. */
export function requestRecordingPermissions(
  kinds: PermissionKind[],
): Promise<Partial<Record<PermissionKind, PermissionState>>> {
  return invoke("request_recording_permissions", { kinds });
}

/** Open the System Settings pane where this permission is switched on. */
export function openPrivacySettings(kind: PermissionKind): Promise<void> {
  return invoke("open_privacy_settings", { kind });
}

/** A `data:` URL preview of a display or window (native recorder, idle only). */
export function recordingThumbnail(target: {
  screenIndex?: number;
  windowId?: number;
  maxWidth?: number;
}): Promise<string> {
  return invoke<string>("recording_thumbnail", target);
}

export function getRecordingSnapshot(): Promise<RecordingSnapshot> {
  return invoke<RecordingSnapshot>("get_recording_snapshot");
}

/** Resolves once capture is running; rejects if cancelled or capture failed. */
export function startRecording(opts: RecordOptions): Promise<RecordingSnapshot> {
  return invoke<RecordingSnapshot>("start_recording", { opts });
}

export function pauseRecording(sessionId: string): Promise<void> {
  return invoke<void>("pause_recording", { sessionId });
}

export function resumeRecording(sessionId: string): Promise<void> {
  return invoke<void>("resume_recording", { sessionId });
}

export function stopRecording(sessionId: string): Promise<RecordingResult> {
  return invoke<RecordingResult>("stop_recording", { sessionId });
}

/** Also interrupts a take that is still starting. */
export function cancelRecording(sessionId: string): Promise<void> {
  return invoke<void>("cancel_recording", { sessionId });
}

/** Discard the take and start a new one with the same options, as one action. */
export function restartRecording(sessionId: string): Promise<RecordingSnapshot> {
  return invoke<RecordingSnapshot>("restart_recording", { sessionId });
}

/** Marks the take's own media time; resolves to that time. */
export function markRecording(sessionId: string): Promise<number> {
  return invoke<number>("mark_recording", { sessionId });
}

/** Finished takes the editor has not acknowledged importing yet. */
export function pendingRecordingResults(): Promise<RecordingResult[]> {
  return invoke<RecordingResult[]>("pending_recording_results");
}

export function ackRecordingResult(sessionId: string): Promise<void> {
  return invoke<void>("ack_recording_result", { sessionId });
}

/** Hide/show the desktop recording controller for the live take. */
export function setControllerHidden(hidden: boolean): Promise<void> {
  return invoke<void>("set_controller_hidden", { hidden });
}

/** Grow/shrink the controller window for its overflow menu. */
export function setControllerExpanded(expanded: boolean): Promise<void> {
  return invoke<void>("set_controller_expanded", { expanded });
}

/** Restore and focus the MAIN editor window (never the calling window). */
export function showMainWindow(): Promise<void> {
  return invoke<void>("show_main_window");
}

/** Every authoritative change. Subscribe BEFORE calling getRecordingSnapshot. */
export function onRecordSnapshot(handler: (s: RecordingSnapshot) => void): Promise<UnlistenFn> {
  return listen<RecordingSnapshot>("record:snapshot", (e) => handler(e.payload));
}

/** A take finished saving. Only the editor window imports it. */
export function onRecordFinished(handler: (r: RecordingResult) => void): Promise<UnlistenFn> {
  return listen<RecordingResult>("record:finished", (e) => handler(e.payload));
}

/** Update the menu-bar item: title next to the icon, tooltip and the menu rows. */
export function updateTray(model: TrayModel): Promise<void> {
  return invoke("update_tray", { model });
}

/** A menu-bar menu row was clicked (`record`, `pause`, `rerecord`, `mark`, `cancel`, `show`). */
export function onTrayAction(handler: (id: string) => void): Promise<UnlistenFn> {
  return listen<string>("tray:action", (e) => handler(e.payload));
}

// ---------------------------------------------------------------------------
// Transcription
// ---------------------------------------------------------------------------

/**
 * Transcription engine — whisper.cpp only.
 *
 * WhisperKit (ANE) was removed in v3.2.0 due to word-timestamp inaccuracies
 * that caused video/text drift. To restore it, see commit 4726d25.
 */
export type TranscriptionEngine = "whisper-cpp";

/** whisper.cpp GGML model names (kebab-case, matches Rust WhisperModel). */
export type WhisperModel = "tiny" | "base" | "small" | "medium" | "large-v3-turbo" | "large-v3";

export interface TranscribeOptions {
  mediaId: string;
  mediaPath: string;
  engine?: TranscriptionEngine;
  modelName: WhisperModel;
  /** Total media duration in seconds — used to compute 0..1 progress. */
  mediaDuration?: number;
  /**
   * BCP-47 language code for the source audio (e.g. "fr", "es", "de").
   * Omit or pass "auto" to let Whisper detect the language.
   */
  language?: string;
  /** When true, Whisper outputs English regardless of the source language. */
  translate?: boolean;
  /**
   * When true, whisper-cli attempts to identify speakers via --diarize.
   * Requires whisper.cpp built with diarisation support.
   */
  diarize?: boolean;
}

export interface TranscribeResult {
  mediaId: string;
  words: Word[];
  engine: TranscriptionEngine;
  /** Backend whisper-cli actually ran on. */
  backend?: "core-ml-metal" | "metal-only" | "core-ml" | "cpu";
  /** Per-stage timings in milliseconds; absent fields were not measured. */
  timings?: TranscribeTimings;
}

export interface TranscribeTimings {
  preparationMs?: number | null;
  extractionMs?: number | null;
  modelLoadMs?: number | null;
  melMs?: number | null;
  encodeMs?: number | null;
  decodeMs?: number | null;
  whisperTotalMs?: number | null;
  parseMs?: number | null;
}

/** Kick off a transcription. Resolves when complete; subscribe to progress events
 * via `onTranscribeProgress` before calling this if you want a progress bar. */
export function transcribe(opts: TranscribeOptions): Promise<TranscribeResult> {
  return invoke<TranscribeResult>("transcribe", { opts });
}

export interface TranscribeProgress {
  mediaId: string;
  /** 0..1 */
  progress: number;
  /** Currently-decoded source timestamp, in seconds. */
  currentTime: number;
}

/** Subscribe to streaming progress for whichever transcription is running. */
export function onTranscribeProgress(
  handler: (p: TranscribeProgress) => void,
): Promise<UnlistenFn> {
  return listen<TranscribeProgress>("transcribe:progress", (e) => handler(e.payload));
}

// ---------------------------------------------------------------------------
// Model management
// ---------------------------------------------------------------------------

export interface ModelInfo {
  engine: TranscriptionEngine;
  /** WhisperModel slug, e.g. "large-v3-turbo". */
  name: string;
  /** Approximate disk size in MB. */
  sizeMb: number;
  /** Whether the model is already downloaded. */
  installed: boolean;
}

export function listModels(): Promise<ModelInfo[]> {
  return invoke<ModelInfo[]>("list_models");
}

/**
 * Download a model. Pass the model's `name` and `engine` as returned by
 * `listModels` — the backend uses the engine to pick the right download path.
 */
export function downloadModel(engine: TranscriptionEngine, name: string): Promise<void> {
  return invoke<void>("download_model", { engine, name });
}

/** Delete the downloaded GGML binary (and Core ML encoder) for a model. */
export function deleteModel(engine: TranscriptionEngine, name: string): Promise<void> {
  return invoke<void>("delete_model", { engine, name });
}

export interface ModelDownloadProgress {
  name: string;
  /** 0..1 combined progress across all phases */
  progress: number;
  /** Current phase: "model" | "coreml" | "coreml-skipped" | "unzip" | "complete" */
  phase?: string;
  /** Human-readable label for the current phase, e.g. "Downloading model file" */
  label?: string;
  bytesDownloaded: number;
  bytesTotal: number;
}

export function onModelDownloadProgress(
  handler: (p: ModelDownloadProgress) => void,
): Promise<UnlistenFn> {
  return listen<ModelDownloadProgress>("model:download:progress", (e) => handler(e.payload));
}

// ---------------------------------------------------------------------------
// Project I/O
// ---------------------------------------------------------------------------

export function saveProject(project: Project, path: string): Promise<void> {
  return invoke<void>("save_project", { project, path });
}

export function loadProject(path: string): Promise<Project> {
  return invoke<Project>("load_project", { path });
}

/**
 * Probe `path` and accept it only when it is the same footage as `expected`
 * (duration within tolerance, same streams, same SHA-256). Rejects with a
 * plain-language reason otherwise. The result keeps `expected.id`.
 */
/** Streamed SHA-256 of a local file (backfills projects saved without one). */
export function hashMedia(path: string): Promise<string> {
  return invoke<string>("hash_media", { path });
}

export interface NativeSpan {
  name: string;
  durationMs: number;
  startUnixMs: number;
  id: string | null;
}

/** Native timing spans; empty unless the app was started with YUSAFCUT_PERF_SPANS=1. */
export function perfSpansSnapshot(): Promise<NativeSpan[]> {
  return invoke<NativeSpan[]>("perf_spans_snapshot");
}

/** Decoded picture size of a file (rotation applied), without hashing it. */
export function probeMediaSize(path: string): Promise<[number, number]> {
  return invoke<[number, number]>("probe_media_size", { path });
}

export function relinkMedia(path: string, expected: SourceMedia): Promise<SourceMedia> {
  return invoke<SourceMedia>("relink_media", { path, expected });
}

/** The subset of `paths` that is not a readable file on disk. */
export function findMissingMedia(paths: string[]): Promise<string[]> {
  return invoke<string[]>("find_missing_media", { paths });
}

// ---------------------------------------------------------------------------
// Export
// ---------------------------------------------------------------------------

export type ExportPreset = "youtube-1080p" | "podcast-audio" | "custom";

/** Output container + codec. "mp4" (the default) is H.264/HEVC + AAC. ProRes is
 *  10-bit 4:2:2 in MOV with PCM audio; GIF has no audio; m4a/wav are audio only. */
export type ExportFormat =
  | "mp4"
  | "mov"
  | "prores-422"
  | "prores-422-hq"
  | "prores-4444"
  | "gif"
  | "m4a"
  | "wav";

export interface ExportOptions {
  project: Project;
  outputPath: string;
  preset: ExportPreset;
  /** Custom preset only — bitrate in kbps. */
  videoBitrateKbps?: number;
  audioBitrateKbps?: number;
  width?: number;
  height?: number;
  fps?: number;
  codec?: "h264" | "hevc";
  /** Bypass smart-cut and force the slow full re-encode path. Used by the
   *  "Force re-encode" advanced toggle in the export dialog. */
  forceReencode?: boolean;
  /** The frame around the video, already resolved to pixels. Forces a full re-encode. */
  scene?: SceneRender;
  /** Zoom regions on the output timeline. Any region forces a full re-encode. */
  zoomRegions?: ZoomRegion[];
  /** Draw Project.cursor before zoom/scene; activity logs are sent only once. */
  drawCursor?: boolean;
  /** Burn captions into the picture, above zoom and scene. Absent = no captions drawn. */
  captions?: { style: CaptionStyle; cues: CaptionExportCue[] };
  /** Omitted means "mp4" (or "m4a" for the podcast-audio preset). */
  format?: ExportFormat;
  /** Export only this span of the output timeline, in seconds. Forces a full re-encode. */
  range?: { start: number; end: number };
  /** Audio formats only: also write `<name>-voice-N` / `<name>-music-N` stems beside the mix. */
  stems?: boolean;
  /** Normalise the final mix to this integrated loudness (LUFS). Omitted = leave levels alone. Forces a full re-encode. */
  loudnessLufs?: number;
}

/** Levels of the written file, measured after export (absent for silent outputs). */
export interface ExportAudioReport {
  /** Each level is null when it is infinite (digital silence) or could not be read. */
  integratedLufs: number | null;
  loudnessRangeLu: number | null;
  truePeakDbtp: number | null;
  samplePeakDb: number | null;
  /** Sample peak at or above full scale: the mix clips. */
  clipped: boolean;
}

export interface ExportReport {
  audio: ExportAudioReport | null;
}

export function onExportMeasuring(handler: () => void): Promise<UnlistenFn> {
  return listen("export:measuring", () => handler());
}

export function exportVideo(opts: ExportOptions): Promise<ExportReport> {
  return invoke<ExportReport>("export_video", { opts });
}

/**
 * "Check coverage" for a privacy mask: a PNG contact sheet (bytes) of frames
 * around and inside every place the mask is on screen, rendered through the
 * real export graph as a cancellable job. Rendered to a local temp file that
 * the backend removes before returning.
 */
export function maskCoverageSheet(opts: ExportOptions, maskId: string): Promise<ArrayBuffer> {
  return invoke<ArrayBuffer>("mask_coverage_sheet", { opts, maskId });
}

export interface ExportProgress {
  /** 0..1 */
  progress: number;
  /** Encoded output time in seconds. */
  outputTimeSec: number;
  etaSec: number | null;
}

export function onExportProgress(handler: (p: ExportProgress) => void): Promise<UnlistenFn> {
  return listen<ExportProgress>("export:progress", (e) => handler(e.payload));
}

export function cancelExport(): Promise<void> {
  return invoke<void>("cancel_export");
}

// ---------------------------------------------------------------------------
// Misc
// ---------------------------------------------------------------------------

/** Return the path the app's `Application Support` directory. */
export function appDataDir(): Promise<string> {
  return invoke<string>("app_data_dir");
}

/** Open the export folder in Finder once a render is done. */
export function revealInFinder(path: string): Promise<void> {
  return invoke<void>("reveal_in_finder", { path });
}

// ---------------------------------------------------------------------------
// Jobs (background queue)
// ---------------------------------------------------------------------------

// AI / LLM features (detect_chapters, suggest_broll) were removed in v3.4.0
// to eliminate the Python/MLX sidecar dependency. Restore from commit
// 074d1d3 if needed.

export type JobKind =
  | "export"
  | "transcribe"
  | "download-model"
  | "snapshot"
  | "waveform"
  | "proxy"
  | "composite";
export type JobStatus = "queued" | "running" | "completed" | "failed" | "cancelled";

export interface JobSnapshot {
  id: string;
  kind: JobKind;
  title: string;
  status: JobStatus;
  /** 0..1 */
  progress: number;
  etaSec: number | null;
  createdAt: number;
  startedAt: number | null;
  finishedAt: number | null;
  error: string | null;
}

export function listJobs(): Promise<JobSnapshot[]> {
  return invoke<JobSnapshot[]>("list_jobs");
}

export function cancelJob(id: string): Promise<void> {
  return invoke<void>("cancel_job", { id });
}

export function onJobsUpdate(handler: (jobs: JobSnapshot[]) => void): Promise<UnlistenFn> {
  return listen<JobSnapshot[]>("jobs:update", (e) => handler(e.payload));
}

// ---------------------------------------------------------------------------
// Snapshots (project history / restore points)
// ---------------------------------------------------------------------------

export interface SnapshotIndex {
  id: string;
  label: string;
  createdAt: string;
  durationSec: number;
  segments: number;
}

export function createSnapshot(
  project: Project,
  projectPath: string,
  label: string,
): Promise<SnapshotIndex> {
  return invoke<SnapshotIndex>("create_snapshot", { project, projectPath, label });
}

export function listSnapshots(projectPath: string): Promise<SnapshotIndex[]> {
  return invoke<SnapshotIndex[]>("list_snapshots", { projectPath });
}

export function restoreSnapshot(projectPath: string, id: string): Promise<Project> {
  return invoke<Project>("restore_snapshot", { projectPath, id });
}

/** Remove recorded key names from every snapshot copy of the project; resolves to the event count. */
export function stripSnapshotKeyNames(projectPath: string): Promise<number> {
  return invoke<number>("strip_snapshot_key_names", { projectPath });
}

export function deleteSnapshot(projectPath: string, id: string): Promise<void> {
  return invoke<void>("delete_snapshot", { projectPath, id });
}

// ---------------------------------------------------------------------------
// Pause / silence detection
// ---------------------------------------------------------------------------

/** A contiguous silent range detected in the source media (source timestamps). */
export interface PauseSegment {
  /** Stable UUID assigned by the backend at detection time. */
  id: string;
  start: number;
  end: number;
  /** `end - start` — pre-computed by the backend. */
  duration: number;
  /**
   * True when this pause has been cut from the EDL.
   * Set by the frontend; not returned by the backend.
   */
  deleted?: boolean;
  /**
   * When non-null, the pause has been shortened to this many seconds.
   * The middle of the pause has been cut from the EDL (`trimSourceRanges`).
   */
  shortenedTo?: number | null;
}

export interface DetectPausesOpts {
  mediaPath: string;
  /** Noise floor in dB (negative). Default –35 dB. */
  noiseThreshold?: number;
  /** Minimum silence length in seconds. Default 0.5 s. */
  minDuration?: number;
}

/** Run ffmpeg silencedetect on the source file and return silent ranges. */
export function detectPauses(opts: DetectPausesOpts): Promise<PauseSegment[]> {
  const args: Record<string, unknown> = { mediaPath: opts.mediaPath };
  if (opts.noiseThreshold !== undefined) args.noiseThreshold = opts.noiseThreshold;
  if (opts.minDuration !== undefined) args.minDuration = opts.minDuration;
  // The Rust command takes a single `opts: DetectPausesOpts` parameter, so the
  // payload must be wrapped under an `opts` key — otherwise Tauri rejects the
  // call with "missing required key opts".
  return invoke<PauseSegment[]>("detect_pauses", { opts: args });
}

export interface PeakLevel {
  samplesPerPeak: number;
  peaks: number[];
}
export interface PeakPyramid {
  version: number;
  sampleRate: number;
  samplesPerPeak: number;
  levels: PeakLevel[];
}
export type PreviewQuality = "original" | "balanced" | "low";
export function generateWaveform(media: SourceMedia): Promise<PeakPyramid> {
  return invoke("generate_waveform", { media });
}
export function generatePreviewProxy(
  media: SourceMedia,
  quality: Exclude<PreviewQuality, "original">,
): Promise<string> {
  return invoke("generate_preview_proxy", { media, quality });
}

/** Only backend-owned recordings/events.jsonl paths are accepted. */
export function readRecordingCursorLog(path: string): Promise<string> {
  return invoke<string>("read_recording_cursor_log", { path });
}

/** Delete an unkept take's own `rec-*` folder (refused outside the recordings folder). */
export function discardRecordingTake(path: string): Promise<void> {
  return invoke<void>("discard_recording_take", { path });
}

// ── Recorder setup bar (floating window) ────────────────────────────────────
export function openRecorderBar(): Promise<void> {
  return invoke("open_recorder_bar");
}
export function closeRecorderBar(restoreMain: boolean): Promise<void> {
  return invoke("close_recorder_bar", { restoreMain });
}
export function hideRecorderBar(): Promise<void> {
  return invoke("hide_recorder_bar");
}
export function setRecorderBarHeight(height: number): Promise<void> {
  return invoke("set_recorder_bar_height", { height });
}
export function openRecordingsFolder(): Promise<void> {
  return invoke("open_recordings_folder");
}
export function onRecorderBarVisibility(handler: (visible: boolean) => void): Promise<UnlistenFn> {
  return listen<{ visible: boolean }>("recorder-bar:visibility", (e) => handler(e.payload.visible));
}
