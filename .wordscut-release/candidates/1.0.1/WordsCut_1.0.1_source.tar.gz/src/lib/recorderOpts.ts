/**
 * Pure helpers for the recorder options that are shared between the editor
 * window and the floating recorder bar: storage, defaults and the device
 * defaulting that runs after every device refresh. No React, no Tauri.
 */

import type { RecordOptions, RecordingDevices } from "@/lib/ipc";

export const OPTS_STORAGE_KEY = "yusafcut.recorderOptions";

export function defaultOpts(): RecordOptions {
  return {
    mode: "screen",
    fps: 30,
    pipCorner: "bottom-right",
    pipSize: "medium",
  };
}

/** The stored options merged over the defaults, or the defaults. */
export function loadStoredOpts(): RecordOptions {
  try {
    const raw = window.localStorage?.getItem(OPTS_STORAGE_KEY);
    if (raw)
      return withoutAllCharacters({
        ...defaultOpts(),
        ...(JSON.parse(raw) as Partial<RecordOptions>),
      });
  } catch {
    /* fall through */
  }
  return defaultOpts();
}

/** True when some options were stored before (so a missing mic means "off"). */
export function hasStoredOpts(): boolean {
  try {
    return Boolean(window.localStorage?.getItem(OPTS_STORAGE_KEY));
  } catch {
    return false;
  }
}

/**
 * "Also record all characters" is never stored: it is off again on every launch
 * (key names, the first opt-in, may persist and shows an indicator while recording).
 */
function withoutAllCharacters(opts: RecordOptions): RecordOptions {
  const rest = { ...opts };
  delete rest.recordAllCharacters;
  return rest;
}

export function persistOpts(opts: RecordOptions) {
  try {
    window.localStorage?.setItem(OPTS_STORAGE_KEY, JSON.stringify(withoutAllCharacters(opts)));
  } catch {
    /* ignore */
  }
}

/**
 * Default unset — or stale — device indices to the first available of each
 * kind. Stale matters when the recorder backend changes (the native helper and
 * ffmpeg number their devices differently). With `micOff` an unset microphone
 * stays unset, because that is how the user switched it off.
 */
export function defaultDevicePatch(
  opts: RecordOptions,
  devices: RecordingDevices,
  { micOff = false }: { micOff?: boolean } = {},
): Partial<RecordOptions> {
  const patch: Partial<RecordOptions> = {};
  const firstScreen = devices.video.find((d) => d.isScreen);
  const firstCamera = devices.video.find((d) => !d.isScreen);
  const firstMic = devices.audio[0];
  const hasVideo = (index: number | undefined, screen: boolean) =>
    devices.video.some((d) => d.index === index && d.isScreen === screen);
  const hasMic = (index: number | undefined) => devices.audio.some((d) => d.index === index);
  if (!hasVideo(opts.screenIndex, true) && firstScreen) patch.screenIndex = firstScreen.index;
  if (!hasVideo(opts.cameraIndex, false) && firstCamera) patch.cameraIndex = firstCamera.index;
  if (!hasMic(opts.audioIndex) && firstMic && !(micOff && opts.audioIndex === undefined)) {
    patch.audioIndex = firstMic.index;
  }
  return patch;
}
