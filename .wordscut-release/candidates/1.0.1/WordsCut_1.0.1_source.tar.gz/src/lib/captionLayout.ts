/**
 * Readable caption layout for burned-in and previewed captions.
 *
 * Pure and deterministic. Input is the words in OUTPUT time (already cut and
 * re-ordered, see `flattenWordsInOutputTime`); cue and word times are taken
 * from those timestamps and never invented: a cue starts at its first word's
 * start and ends at its last word's end. Words are atomic, a line break never
 * falls inside a word. Reading-speed and duration problems are reported as
 * warnings instead of being "fixed" by moving times.
 */

import { flattenWordsInOutputTime } from "./captions";
import type { Project } from "./edl";
import type { CaptionStyle } from "./captionStyle";

export interface TimedWord {
  text: string;
  /** Output-time seconds. */
  start: number;
  end: number;
}

export interface LayoutLimits {
  maxCharsPerLine: number;
  maxLines: number;
  /** A silence at least this long starts a new cue. */
  gapSeconds: number;
  maxCueSeconds: number;
  /** Cues shorter than this are reported (never stretched). */
  minCueSeconds: number;
  /** Reading speed above this (characters per second) is reported. */
  maxCps: number;
}

export const DEFAULT_LIMITS: Omit<LayoutLimits, "maxCharsPerLine" | "maxLines"> = {
  gapSeconds: 0.7,
  maxCueSeconds: 6,
  minCueSeconds: 0.8,
  maxCps: 20,
};

export interface CueWord extends TimedWord {
  /** Highlight window end: the next word's start, or the cue end. */
  until: number;
}
export interface LaidOutCue {
  index: number;
  start: number;
  end: number;
  lines: CueWord[][];
  text: string;
}
export interface CaptionWarning {
  cue: number;
  kind: "fast" | "short" | "long-word" | "invisible" | "emoji" | "glyph";
  message: string;
}
export interface CaptionLayout {
  cues: LaidOutCue[];
  warnings: CaptionWarning[];
}

/** Emoji and pictographs: libass cannot draw Apple Color Emoji (a bitmap font). */
const EMOJI_SRC =
  "(?:[\\u{1F000}-\\u{1FAFF}\\u{2600}-\\u{27BF}\\u{2B00}-\\u{2BFF}]|\\u{FE0F}|\\u{20E3})";
const EMOJI = new RegExp(EMOJI_SRC, "u");
const EMOJI_G = new RegExp(EMOJI_SRC, "gu");
/** Scripts the burned-in fonts are known to cover (Latin, Cyrillic, Greek, CJK, Hangul, punctuation). */
const OUTSIDE_COVERAGE =
  /[^\p{Script=Latin}\p{Script=Cyrillic}\p{Script=Greek}\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}\p{Script=Hangul}\p{Script=Common}\p{Script=Inherited}]/u;

const PUNCT_ONLY = /^[.,!?;:…)\]}"'’”»%]+$/;
const SENTENCE_END = /[.!?…]["'’”)]*$/;

/** Trim, drop empties and glue stand-alone punctuation tokens to the word before. */
export function normalizeWords(words: TimedWord[]): TimedWord[] {
  const out: TimedWord[] = [];
  for (const w of words) {
    const text = w.text.replace(/\s+/g, " ").trim();
    if (!text || !Number.isFinite(w.start) || !Number.isFinite(w.end)) continue;
    const prev = out[out.length - 1];
    if (prev && PUNCT_ONLY.test(text)) {
      prev.text += text;
      prev.end = Math.max(prev.end, w.end);
    } else out.push({ text, start: w.start, end: Math.max(w.end, w.start) });
  }
  // Words never start before the one before them, and never overlap it, so two
  // cues cannot be on screen at once. A word swallowed whole ends up with no
  // duration and is reported as "invisible" instead of being hidden silently.
  for (let i = 0; i + 1 < out.length; i++) {
    const a = out[i]!;
    const b = out[i + 1]!;
    b.start = Math.max(b.start, a.start);
    b.end = Math.max(b.end, b.start);
    if (a.end > b.start) a.end = b.start;
  }
  return out;
}

/** Greedy wrap into lines of at most `max` characters; an over-long word gets its own line. */
function wrap<T extends { text: string }>(words: T[], max: number): T[][] {
  const lines: T[][] = [];
  let len = 0;
  for (const w of words) {
    const cur = lines[lines.length - 1];
    if (cur && len + 1 + w.text.length <= max) {
      cur.push(w);
      len += 1 + w.text.length;
    } else {
      lines.push([w]);
      len = w.text.length;
    }
  }
  return lines;
}

export function layoutCaptions(input: TimedWord[], limits: LayoutLimits): CaptionLayout {
  const words = normalizeWords(input);
  const cues: LaidOutCue[] = [];
  const warnings: CaptionWarning[] = [];
  let group: TimedWord[] = [];

  const flush = () => {
    if (!group.length) return;
    const index = cues.length + 1;
    const start = group[0]!.start;
    const end = group[group.length - 1]!.end;
    const withUntil: CueWord[] = group.map((w, i) => ({
      ...w,
      until: i + 1 < group.length ? group[i + 1]!.start : end,
    }));
    const lines = wrap(withUntil, limits.maxCharsPerLine);
    const text = lines.map((l) => l.map((w) => w.text).join(" ")).join("\n");
    cues.push({ index, start, end, lines, text });
    const dur = end - start;
    const chars = text.replace(/\n/g, " ").length;
    if (dur > 0 && chars / dur > limits.maxCps)
      warnings.push({
        cue: index,
        kind: "fast",
        message: `Cue ${index} reads at ${(chars / dur).toFixed(0)} characters per second (limit ${limits.maxCps}).`,
      });
    if (dur < 0.01)
      warnings.push({
        cue: index,
        kind: "invisible",
        message: `Cue ${index} ("${text.slice(0, 20)}") has no duration, so it will not be drawn.`,
      });
    else if (dur < limits.minCueSeconds)
      warnings.push({
        cue: index,
        kind: "short",
        message: `Cue ${index} is on screen for ${dur.toFixed(2)} s (minimum ${limits.minCueSeconds} s).`,
      });
    if (lines.some((l) => l.length === 1 && l[0]!.text.length > limits.maxCharsPerLine))
      warnings.push({
        cue: index,
        kind: "long-word",
        message: `Cue ${index} has a word longer than ${limits.maxCharsPerLine} characters; it stays whole.`,
      });
    if (EMOJI.test(text))
      warnings.push({
        cue: index,
        kind: "emoji",
        message: `Cue ${index} has emoji: they show in the preview but will not appear in the burned-in video.`,
      });
    if (OUTSIDE_COVERAGE.test(text.replace(EMOJI_G, "")))
      warnings.push({
        cue: index,
        kind: "glyph",
        message: `Cue ${index} has characters (other than Latin, Cyrillic, Greek, Chinese, Japanese or Korean) that may not draw in the burned-in video.`,
      });
    group = [];
  };

  for (const w of words) {
    const prev = group[group.length - 1];
    if (prev) {
      const gap = w.start - prev.end;
      const dur = prev.end - group[0]!.start;
      const lines = wrap([...group, w], limits.maxCharsPerLine).length;
      if (
        gap >= limits.gapSeconds ||
        lines > limits.maxLines ||
        w.end - group[0]!.start > limits.maxCueSeconds ||
        (SENTENCE_END.test(prev.text) && dur > 1.2)
      )
        flush();
    }
    group.push(w);
  }
  flush();
  return { cues, warnings };
}

export function limitsFor(style: Pick<CaptionStyle, "maxCharsPerLine" | "maxLines">): LayoutLimits {
  return { ...DEFAULT_LIMITS, maxCharsPerLine: style.maxCharsPerLine, maxLines: style.maxLines };
}

/** Layout for a project's output timeline (cuts and clip order already applied). */
export function layoutProjectCaptions(
  project: Project,
  style: Pick<CaptionStyle, "maxCharsPerLine" | "maxLines">,
): CaptionLayout {
  const words = flattenWordsInOutputTime(project).map((w) => ({
    text: w.word.text,
    start: w.start,
    end: w.end,
  }));
  return layoutCaptions(words, limitsFor(style));
}

/** The cue on screen at output time `t`, and the word being spoken in it. */
export function cueAt(
  cues: LaidOutCue[],
  t: number,
): { cue: LaidOutCue; line: number; word: number } | null {
  let lo = 0;
  let hi = cues.length - 1;
  while (lo <= hi) {
    const mid = (lo + hi) >> 1;
    const c = cues[mid]!;
    if (t < c.start) hi = mid - 1;
    else if (t >= c.end) lo = mid + 1;
    else {
      for (let l = 0; l < c.lines.length; l++)
        for (let k = 0; k < c.lines[l]!.length; k++) {
          const w = c.lines[l]![k]!;
          if (t >= w.start && t < w.until) return { cue: c, line: l, word: k };
        }
      return { cue: c, line: -1, word: -1 };
    }
  }
  return null;
}

/** What the exporter needs: cue and word times and text only. */
export interface CaptionExportCue {
  start: number;
  end: number;
  lines: { t: string; s: number; e: number }[][];
}
export function toExportCues(cues: LaidOutCue[]): CaptionExportCue[] {
  return cues.map((c) => ({
    start: c.start,
    end: c.end,
    lines: c.lines.map((l) => l.map((w) => ({ t: w.text, s: w.start, e: w.until }))),
  }));
}

/** The cues with emoji (and their joiners) removed; words that become empty are dropped. */
export function stripEmoji(cues: LaidOutCue[]): LaidOutCue[] {
  const strip = (t: string) =>
    t
      .replace(EMOJI_G, "")
      .replace(/\u200D/g, "")
      .trim();
  const out: LaidOutCue[] = [];
  for (const c of cues) {
    const lines = c.lines
      .map((l) => l.map((w) => ({ ...w, text: strip(w.text) })).filter((w) => w.text))
      .filter((l) => l.length);
    if (!lines.length) continue;
    const text = lines.map((l) => l.map((w) => w.text).join(" ")).join("\n");
    out.push({ ...c, index: out.length + 1, lines, text });
  }
  return out;
}
