import type { Project, Word } from "./edl";
/** Recognition is source analysis, not an edit. Apply it to any surviving EDL
 * revision without recreating clips or overwriting words the user corrected. */
export function withSourceTranscript(project: Project, mediaId: string, words: Word[]): Project {
  if (!project.media[mediaId] || project.originalTranscripts?.[mediaId]) return project;
  const segments = project.segments.map((segment) => {
    if (segment.mediaId !== mediaId || segment.words.length) return segment;
    return {
      ...segment,
      words: words.filter((word) => {
        const midpoint = (word.start + word.end) / 2;
        return midpoint >= segment.sourceIn && midpoint < segment.sourceOut;
      }),
    };
  });
  return {
    ...project,
    segments,
    originalTranscripts: { ...project.originalTranscripts, [mediaId]: words },
  };
}
