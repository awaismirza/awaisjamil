/**
 * App settings model and tolerant loading. Pure module (no React, Tauri or
 * store imports, same rule as edl.ts).
 */

import {
  defaultEditorShortcuts,
  EDITOR_SHORTCUT_DEFS,
  editorDefsIn,
  editorShortcutProblem,
  scopeOf,
  type EditorShortcutMap,
} from "./editorShortcuts";
import {
  defaultShortcuts,
  normalizeAccelerator,
  SHORTCUT_DEFS,
  shortcutProblem,
  type ShortcutMap,
} from "./shortcuts";

export const COUNTDOWN_CHOICES = [0, 3, 5, 10] as const;
export type CountdownSec = (typeof COUNTDOWN_CHOICES)[number];

export type SetupStyle = "bar" | "dialog";

export interface RecordingSettings {
  /** Record opens the floating setup bar (default) or the setup dialog. */
  setupStyle: SetupStyle;
  /**
   * One press starts recording with the last-used options, skipping the setup
   * dialog. Applies to the global shortcut and the menu-bar item.
   */
  quickStart: boolean;
  /** Seconds of 3-2-1 before capture starts. 0 starts immediately. */
  countdownSec: CountdownSec;
  /** Minimise WordsCut while the screen is captured, so it is not in the footage. */
  hideWindow: boolean;
  /** Screen capture always hides these until capture exclusion exists. */
  showHUD: boolean;
  /** Normalized position in the available editor viewport. */
  hudPosition?: { x: number; y: number };
  /** Transcribe a finished recording with the best installed model. */
  autoTranscribe: boolean;
  /** Turn "mark a moment" presses into chapters on the finished recording. */
  markersBecomeChapters: boolean;
}

export interface Settings {
  shortcuts: ShortcutMap;
  /** Editor window hotkeys (Space, J/K/L, I/O, ...). */
  editorShortcuts: EditorShortcutMap;
  recording: RecordingSettings;
}

export function defaultSettings(): Settings {
  return {
    shortcuts: defaultShortcuts(),
    editorShortcuts: defaultEditorShortcuts(),
    recording: {
      setupStyle: "bar",
      quickStart: true,
      countdownSec: 3,
      hideWindow: true,
      showHUD: true,
      autoTranscribe: true,
      markersBecomeChapters: true,
    },
  };
}

function isRecord(v: unknown): v is Record<string, unknown> {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}

/**
 * Turn whatever was stored into a valid Settings. Anything missing, malformed,
 * unsupported, reserved or conflicting falls back to its default, so a bad or
 * old file can never leave the app without a working shortcut.
 */
export function sanitizeSettings(raw: unknown): Settings {
  const out = defaultSettings();
  if (!isRecord(raw)) return out;

  if (isRecord(raw.shortcuts)) {
    const taken = new Set<string>();
    for (const def of SHORTCUT_DEFS) {
      const value = raw.shortcuts[def.action];
      const canon = typeof value === "string" ? normalizeAccelerator(value) : null;
      if (canon && shortcutProblem(canon) === null && !taken.has(canon)) {
        out.shortcuts[def.action] = canon;
        taken.add(canon);
      } else {
        // Keep the default, but make sure a later custom value can't collide with it.
        taken.add(normalizeAccelerator(def.default) ?? def.default);
      }
    }
    // A default kept after a collision may itself now clash; resolve by restoring defaults.
    const seen = new Set<string>();
    let clash = false;
    for (const def of SHORTCUT_DEFS) {
      const canon = normalizeAccelerator(out.shortcuts[def.action]);
      if (!canon || seen.has(canon)) clash = true;
      else seen.add(canon);
    }
    if (clash) out.shortcuts = defaultShortcuts();
  }

  if (isRecord(raw.editorShortcuts)) {
    // Keys clash only inside one scope (editor window / voice-over review).
    const taken = new Map<string, Set<string>>();
    for (const def of EDITOR_SHORTCUT_DEFS) {
      const inScope = taken.get(scopeOf(def)) ?? new Set<string>();
      taken.set(scopeOf(def), inScope);
      const value = raw.editorShortcuts[def.action];
      const canon = typeof value === "string" ? normalizeAccelerator(value) : null;
      if (canon && editorShortcutProblem(canon) === null && !inScope.has(canon)) {
        out.editorShortcuts[def.action] = canon;
        inScope.add(canon);
      } else {
        inScope.add(normalizeAccelerator(def.default) ?? def.default);
      }
    }
  }
  // Any clash (inside one editor scope, or with a recorder shortcut) restores the
  // editor defaults, which never clash with each other or with recorder defaults.
  {
    let clash = false;
    for (const scope of ["editor", "review"] as const) {
      const seen = new Set<string>();
      const values = [
        ...Object.values(out.shortcuts),
        ...editorDefsIn(scope).map((d) => out.editorShortcuts[d.action]),
      ];
      for (const v of values) {
        const canon = normalizeAccelerator(v) ?? v;
        if (seen.has(canon)) clash = true;
        seen.add(canon);
      }
    }
    if (clash) out.editorShortcuts = defaultEditorShortcuts();
  }

  if (isRecord(raw.recording)) {
    const r = raw.recording;
    if (COUNTDOWN_CHOICES.includes(r.countdownSec as CountdownSec)) {
      out.recording.countdownSec = r.countdownSec as CountdownSec;
    }
    if (r.setupStyle === "bar" || r.setupStyle === "dialog")
      out.recording.setupStyle = r.setupStyle;
    if (typeof r.quickStart === "boolean") out.recording.quickStart = r.quickStart;
    if (typeof r.hideWindow === "boolean") out.recording.hideWindow = r.hideWindow;
    if (typeof r.showHUD === "boolean") out.recording.showHUD = r.showHUD;
    if (
      isRecord(r.hudPosition) &&
      typeof r.hudPosition.x === "number" &&
      Number.isFinite(r.hudPosition.x) &&
      typeof r.hudPosition.y === "number" &&
      Number.isFinite(r.hudPosition.y)
    ) {
      out.recording.hudPosition = {
        x: Math.max(0, Math.min(1, r.hudPosition.x)),
        y: Math.max(0, Math.min(1, r.hudPosition.y)),
      };
    }
    if (typeof r.autoTranscribe === "boolean") out.recording.autoTranscribe = r.autoTranscribe;
    if (typeof r.markersBecomeChapters === "boolean") {
      out.recording.markersBecomeChapters = r.markersBecomeChapters;
    }
  }
  return out;
}
