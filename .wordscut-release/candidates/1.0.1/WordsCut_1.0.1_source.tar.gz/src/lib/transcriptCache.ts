import type { Project, SourceMedia, Word } from "@/lib/edl";
import { hasChecksum } from "@/lib/checksum";

const TRANSCRIPT_CACHE_PREFIX = "yusafcut.transcript.v2.";

/**
 * Keyed by file content. Media without a recorded checksum (saved before
 * hashing, or a recording whose checksum is still being computed) has NO key:
 * it is neither read nor written, so two such files can never share the
 * `"yusafcut.transcript.v2."` bucket and receive each other's words.
 */
function transcriptCacheKey(media: SourceMedia): string | null {
  return hasChecksum(media) ? `${TRANSCRIPT_CACHE_PREFIX}${media.sha256}` : null;
}

export function readTranscriptCache(media: SourceMedia): Word[] | null {
  const key = transcriptCacheKey(media);
  if (!key) return null;
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as { words?: Word[] };
    return Array.isArray(parsed.words) ? parsed.words : null;
  } catch {
    return null;
  }
}

export function writeTranscriptCache(media: SourceMedia, words: Word[]) {
  const key = transcriptCacheKey(media);
  if (!key) return;
  try {
    localStorage.setItem(
      key,
      JSON.stringify({ mediaSha256: media.sha256, updatedAt: new Date().toISOString(), words }),
    );
  } catch {
    // Cache failure should never block editing.
  }
}

export function clearTranscriptCache(media: SourceMedia) {
  const key = transcriptCacheKey(media);
  if (!key) return;
  try {
    localStorage.removeItem(key);
  } catch {
    // Cache failure should never block editing.
  }
}

export function cacheProjectTranscripts(project: Project) {
  for (const media of Object.values(project.media)) {
    // Edited legacy EDL words are not a complete original transcript.
    const words = project.originalTranscripts?.[media.id];
    if (words) writeTranscriptCache(media, words);
  }
}
