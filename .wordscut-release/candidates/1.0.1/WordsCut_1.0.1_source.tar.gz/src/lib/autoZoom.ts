/** Model-free cursor activity proposals. Source events are clipped by the EDL first. */
import { cursorAt, smoothCursorTrack, type CursorTrack } from "./cursor";
import type { TimelineEntry } from "./edl";
import { entryOutputAt, entrySourceAt } from "./timeMap";
import { addZoomRegion, clampScale, normalizeRegions, type ZoomRegion } from "./zoom";

export interface AutoZoomSettings {
  enabled: boolean;
  scale: number;
  sensitivity: "low" | "medium" | "high";
  clicks: boolean;
  typing: boolean;
  follow: boolean;
}
export const DEFAULT_AUTO_ZOOM: AutoZoomSettings = {
  enabled: true,
  scale: 1.8,
  sensitivity: "medium",
  clicks: true,
  typing: true,
  follow: false,
};
export function sanitizeAutoZoom(raw: unknown): AutoZoomSettings {
  const r = raw && typeof raw === "object" ? (raw as Record<string, unknown>) : {};
  const bool = (key: keyof AutoZoomSettings) =>
    typeof r[key] === "boolean" ? (r[key] as boolean) : (DEFAULT_AUTO_ZOOM[key] as boolean);
  return {
    enabled: bool("enabled"),
    scale: clampScale(typeof r.scale === "number" ? r.scale : DEFAULT_AUTO_ZOOM.scale),
    sensitivity: r.sensitivity === "low" || r.sensitivity === "high" ? r.sensitivity : "medium",
    clicks: bool("clicks"),
    typing: bool("typing"),
    follow: bool("follow"),
  };
}
interface Trigger {
  t: number;
  x: number;
  y: number;
  click: boolean;
}
const RULES = {
  low: { gap: 1.5, clicks: 2, keys: 5, travel: 0.35 },
  medium: { gap: 2, clicks: 1, keys: 3, travel: 0.5 },
  high: { gap: 2.5, clicks: 1, keys: 2, travel: 0.65 },
};

/**
 * Each EDL entry is a separate shot: don't pad into a different clip or join
 * unrelated media. Repeated source ranges deliberately get repeated proposals.
 * Stable ids make repeated generation identical, including after reopening.
 */
export function generateAutoZoom(
  tracks: Readonly<Record<string, CursorTrack>>,
  timeline: readonly TimelineEntry[],
  options: Partial<AutoZoomSettings> = {},
): ZoomRegion[] {
  const opts = sanitizeAutoZoom(options);
  if (!opts.enabled) return [];
  const rule = RULES[opts.sensitivity];
  const total = timeline.at(-1)?.outputEnd ?? 0;
  let regions: ZoomRegion[] = [];
  for (const entry of timeline) {
    const track = tracks[entry.mediaId];
    if (!track) continue;
    const smoothed = opts.follow ? smoothCursorTrack(track, 0.15) : track;
    const triggers: Trigger[] = [];
    for (const e of track.events) {
      if (e.t < entry.sourceIn || e.t >= entry.sourceOut) continue;
      if (!(e.type === "down" && opts.clicks) && !(e.type === "key" && opts.typing)) continue;
      const pos = e.type === "down" ? e : cursorAt(track, e.t);
      if (!pos || pos.outside) continue;
      triggers.push({ t: e.t, x: pos.x, y: pos.y, click: e.type === "down" });
    }
    const clusters: Trigger[][] = [];
    for (const e of triggers) {
      const last = clusters.at(-1);
      if (last && e.t - last[last.length - 1].t <= rule.gap) last.push(e);
      else clusters.push([e]);
    }
    for (const cluster of clusters) {
      const clicks = cluster.filter((e) => e.click).length;
      if (clicks < rule.clicks && cluster.length - clicks < rule.keys) continue;
      const first = cluster[0].t,
        last = cluster[cluster.length - 1].t;
      // Include the intervening moves: two clicks at the same place can hide a big flick.
      const path = [
        ...cluster,
        ...track.points.filter(
          (p) =>
            p.t >= Math.max(entry.sourceIn, first - 0.4) &&
            p.t <= Math.min(entry.sourceOut, last + 1.2) &&
            !p.outside,
        ),
      ];
      const bounds = path.reduce(
        (b, p) => ({
          x0: Math.min(b.x0, p.x),
          x1: Math.max(b.x1, p.x),
          y0: Math.min(b.y0, p.y),
          y1: Math.max(b.y1, p.y),
        }),
        { x0: 1, x1: 0, y0: 1, y1: 0 },
      );
      const travel = Math.hypot(bounds.x1 - bounds.x0, bounds.y1 - bounds.y0);
      if (travel > rule.travel) continue;
      const start = entryOutputAt(entry, Math.max(entry.sourceIn, first - 0.4));
      const end = entryOutputAt(entry, Math.min(entry.sourceOut, last + 1.2));
      const half = 0.5 / opts.scale;
      const focus = (axis: "x" | "y") =>
        Math.max(
          half,
          Math.min(1 - half, cluster.reduce((n, p) => n + p[axis], 0) / cluster.length),
        );
      const focusKeys = [];
      if (opts.follow) {
        for (let t = start; t < end + 0.25; t += 0.25) {
          const time = Math.min(t, end);
          const point = cursorAt(smoothed, entrySourceAt(entry, time));
          focusKeys.push({
            t: time,
            x: point && !point.outside ? point.x : focus("x"),
            y: point && !point.outside ? point.y : focus("y"),
          });
          if (time === end) break;
        }
      }
      regions = addZoomRegion(
        regions,
        {
          id: `auto-${entry.segmentId}-${first.toFixed(6)}`,
          start,
          end,
          ...(opts.follow ? { follow: true, focusKeys } : {}),
          scale: opts.scale,
          focusX: focus("x"),
          focusY: focus("y"),
        },
        total,
      );
    }
  }
  return normalizeRegions(regions, total);
}
