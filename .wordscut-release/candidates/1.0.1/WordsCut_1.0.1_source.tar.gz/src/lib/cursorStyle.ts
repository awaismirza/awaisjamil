/** Project-owned cursor settings. Raw log paths never need to survive a save. */
import { sanitizeAutoZoom, type AutoZoomSettings } from "./autoZoom";
import { cursorAt, cursorPointIndex, sanitizeCursorTrack, type CursorTrack } from "./cursor";
export const CURSOR_SHAPES = ["arrow", "pointer", "dot", "ring", "crosshair", "macos"] as const;
export const CLICK_EFFECTS = ["none", "ripple", "ring", "bounce"] as const;
export interface CursorStyle {
  show: boolean;
  shape: (typeof CURSOR_SHAPES)[number];
  /** In source pixels, relative to a 1080-line picture. */
  size: number;
  color: string;
  /** Symmetric smoothing window in seconds, zero disables it. */
  smoothing: number;
  clickEffect: (typeof CLICK_EFFECTS)[number];
  hideWhenIdle: boolean;
  motionBlur: boolean;
}
export interface ProjectCursor {
  autoZoom: AutoZoomSettings;
  style: CursorStyle;
  tracks: Record<string, CursorTrack>;
}
export const DEFAULT_CURSOR_STYLE: CursorStyle = {
  show: true,
  shape: "macos",
  size: 32,
  color: "#ffffff",
  smoothing: 0.1,
  clickEffect: "ripple",
  hideWhenIdle: false,
  motionBlur: false,
};
const object = (raw: unknown): Record<string, unknown> =>
  raw && typeof raw === "object" ? (raw as Record<string, unknown>) : {};
export function sanitizeCursorStyle(raw: unknown): CursorStyle {
  const r = object(raw),
    d = DEFAULT_CURSOR_STYLE;
  const bool = (key: "show" | "hideWhenIdle" | "motionBlur") =>
    typeof r[key] === "boolean" ? (r[key] as boolean) : d[key];
  const num = (key: "size" | "smoothing", min: number, max: number) =>
    typeof r[key] === "number" && Number.isFinite(r[key])
      ? Math.max(min, Math.min(max, r[key] as number))
      : d[key];
  return {
    show: bool("show"),
    shape: CURSOR_SHAPES.includes(r.shape as CursorStyle["shape"])
      ? (r.shape as CursorStyle["shape"])
      : d.shape,
    size: num("size", 12, 96),
    color: typeof r.color === "string" && /^#[0-9a-f]{6}$/i.test(r.color) ? r.color : d.color,
    smoothing: num("smoothing", 0, 0.5),
    clickEffect: CLICK_EFFECTS.includes(r.clickEffect as CursorStyle["clickEffect"])
      ? (r.clickEffect as CursorStyle["clickEffect"])
      : d.clickEffect,
    hideWhenIdle: bool("hideWhenIdle"),
    motionBlur: bool("motionBlur"),
  };
}
export function sanitizeProjectCursor(raw: unknown): ProjectCursor {
  const r = object(raw),
    tracks: Record<string, CursorTrack> = {};
  for (const [id, value] of Object.entries(object(r.tracks))) {
    if (["__proto__", "constructor", "prototype"].includes(id)) continue;
    const track = sanitizeCursorTrack(value);
    if (track.events.length) tracks[id] = track;
  }
  return { autoZoom: sanitizeAutoZoom(r.autoZoom), style: sanitizeCursorStyle(r.style), tracks };
}

/** Time-based effects are deterministic on seek and never depend on CSS animation state. */
export const CLICK_EFFECT_SEC = 0.45;
export const CURSOR_IDLE_SEC = 1.5;
export function cursorAppearance(
  raw: CursorTrack,
  smoothed: CursorTrack,
  t: number,
  style: CursorStyle,
  clipStart = 0,
) {
  const point = cursorAt(smoothed, t);
  const index = cursorPointIndex(raw.events, t);
  const lastActivity = raw.events[index]?.t ?? -Infinity;
  const visible =
    style.show &&
    !!point &&
    !point.outside &&
    (!style.hideWhenIdle || t - lastActivity <= CURSOR_IDLE_SEC);
  const clicks: Array<{ t: number; x: number; y: number; progress: number }> = [];
  for (let i = index; i >= 0; i--) {
    const e = raw.events[i];
    if (e.t < Math.max(clipStart, t - CLICK_EFFECT_SEC)) break;
    if (e.type === "down" && !e.outside && style.clickEffect !== "none") {
      clicks.push({ t: e.t, x: e.x, y: e.y, progress: (t - e.t) / CLICK_EFFECT_SEC });
    }
  }
  const bounce =
    style.clickEffect === "bounce" && clicks.length
      ? 1 - 0.22 * Math.sin(Math.PI * clicks[0].progress)
      : 1;
  return { point, visible, clicks, bounce };
}
