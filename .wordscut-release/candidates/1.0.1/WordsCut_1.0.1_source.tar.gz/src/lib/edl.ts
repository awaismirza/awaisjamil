// EDL (Edit Decision List) — the central immutable data model.
//
// Everything in WordsCut is a thin layer over this structure. The transcript view,
// the player, and the export pipeline all derive their state from a Project.
//
// Invariants (must hold after every operation):
//   1. Words are never mutated. Their start/end always refer to the *source* media.
//   2. Source timecodes are immutable.
//   3. Segments are the unit of cut: deleting a word-range splits surrounding segments
//      and drops the middle segment(s).
//   4. All edits are pure EDL transformations — no edit ever touches a video file
//      until export.

import { v4 as uuidv4 } from "uuid";
import type { ProjectCursor } from "./cursorStyle";
import type { CaptionStyle } from "./captionStyle";
import type { SceneSettings } from "./scene";
import { retimeZoomRegions, sanitizeZoomRegions, type ZoomRegion } from "./zoom";
import { retimeAnnotations, sanitizeAnnotations, type Annotation } from "./annotations";
import { retimeOverlays, sanitizeOverlays, type MediaOverlay } from "./layers";
import type { PrivacyMask } from "./masks";
import type { KeystrokeSettings } from "./keystrokes";
import { entryOutputAt, entryPlayEnd, entrySourceAt, mapHold } from "./timeMap";

export type MediaId = string;

export interface SourceMedia {
  id: MediaId;
  path: string;
  duration: number; // seconds
  fps: number;
  width: number;
  height: number;
  audioSampleRate: number;
  /** Lower-case hex SHA-256, or "" while none is recorded (see src/lib/checksum.ts). */
  sha256: string;
  /**
   * Screen + camera recording whose camera composite has not replaced this
   * file yet; saved so it resumes on open (src/stores/recordingStore.ts,
   * `runCameraComposite`). Absent on every other media entry.
   */
  pendingCamera?: PendingCamera;
}

export interface PendingCamera {
  /** The take's `tracks/` folder (screen.mp4, camera.mp4, mic.m4a, system.m4a). */
  tracksDir: string;
  /** Validated against the known values before use. */
  pipCorner?: string;
  pipSize?: string;
}

export interface Word {
  id: string;
  text: string;
  start: number; // seconds, relative to source media
  end: number;
  confidence: number; // 0..1
  speaker?: string;
}

export interface Segment {
  id: string;
  mediaId: MediaId;
  words: Word[];
  sourceIn: number;
  sourceOut: number;
  /** Playback speed, MIN_SPEED..MAX_SPEED. Absent = 1. Output length = source length / speed. */
  speed?: number;
  /** Silence this clip's audio (e.g. a sped-up section). Absent = false. */
  muted?: boolean;
  /** Freeze the clip's last frame for this many seconds after it plays (silent). Absent = 0. */
  holdSec?: number;
  /** Transition from the previous clip into this one. Ignored on the first clip. */
  transitionIn?: Transition;
}

export type TransitionKind = "crossfade" | "dip";

/**
 * A transition centred on the cut before a clip. Overlap-neutral: it never
 * changes the output length or any output time. Each side gives up half the
 * duration (clamped to half of either clip). A crossfade blends the outgoing
 * clip into the incoming one, padding each side with its frozen edge frame
 * rather than reaching into removed source; a dip fades to black and back.
 */
export interface Transition {
  kind: TransitionKind;
  /** Seconds, centred on the cut. */
  duration: number;
}

export const MIN_SPEED = 0.25;
export const MAX_SPEED = 4;
/**
 * Longest freeze-frame hold the model keeps. Inserted voice-over narration is a
 * hold, so this is far above the Timing panel's own limit (`HOLD_UI_MAX_SEC`).
 * Mirrored in Rust (`edl::MAX_HOLD_SEC`).
 */
export const MAX_HOLD_SEC = 3600;
/** Longest hold the Timing panel slider offers. */
export const HOLD_UI_MAX_SEC = 30;
export const MIN_TRANSITION_SEC = 0.1;
export const MAX_TRANSITION_SEC = 2;

const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));

/** Effective speed of a clip: always finite and inside MIN_SPEED..MAX_SPEED. */
export function segmentSpeed(seg: { speed?: number }): number {
  const s = seg.speed;
  return typeof s === "number" && Number.isFinite(s) && s > 0 ? clamp(s, MIN_SPEED, MAX_SPEED) : 1;
}

/** Effective freeze-frame hold of a clip, in output seconds. */
export function segmentHold(seg: { holdSec?: number }): number {
  const h = seg.holdSec;
  return typeof h === "number" && Number.isFinite(h) && h > 0 ? Math.min(h, MAX_HOLD_SEC) : 0;
}

/** Output seconds a clip spends playing footage (before any hold). */
export function segmentPlayLength(seg: Segment): number {
  return Math.max(0, seg.sourceOut - seg.sourceIn) / segmentSpeed(seg);
}

/** Output seconds a clip occupies: footage at its speed, then its hold. */
export function segmentOutputLength(seg: Segment): number {
  const play = segmentPlayLength(seg);
  return play > 0 ? play + segmentHold(seg) : 0;
}

/** True when a clip changes timing or sound, so it can never be stream-copied. */
export function hasTimingEffects(seg: Segment): boolean {
  return segmentSpeed(seg) !== 1 || segmentHold(seg) > 0 || !!seg.muted || !!seg.transitionIn;
}

/**
 * Half the effective duration of the transition into `segments[i]`: the
 * requested half, clamped so it never takes more than half of either clip.
 * Zero when there is no transition or no clip before it. Mirrored in Rust
 * (`edl::transition_half`).
 */
export function transitionHalf(segments: readonly Segment[], i: number): number {
  const seg = segments[i];
  const prev = segments[i - 1];
  const t = seg?.transitionIn;
  if (!seg || !prev || !t || !Number.isFinite(t.duration)) return 0;
  const d = clamp(t.duration, MIN_TRANSITION_SEC, MAX_TRANSITION_SEC);
  return Math.max(0, Math.min(d / 2, segmentOutputLength(prev) / 2, segmentOutputLength(seg) / 2));
}

export type ExportPreset = "youtube-1080p" | "podcast-audio" | "custom";

export interface ProjectSettings {
  exportPreset: ExportPreset;
  paddingMs: number; // default audio padding around cuts
}

/** A named jump-point on the OUTPUT timeline. Used for YouTube/podcast chapters. */
export interface Chapter {
  id: string;
  /** Position in seconds on the *output* timeline (post-edits). */
  outputTime: number;
  title: string;
}

/**
 * An audio track laid under the main spoken EDL. Used for music beds, ambient
 * loops, sound effects. Mixed in at export time; never re-encodes the source.
 *
 * Tracks reference `project.media` like any other clip. The mediaId may point
 * to either an audio-only file (mp3 / m4a / wav) or a video — only the audio
 * stream is used.
 *
 * The track plays from `offsetSec` on the OUTPUT timeline. Negative offsets
 * are allowed (track starts before the visible content) and silently clipped
 * at 0 during mixing. `gainDb` is applied before the mix; positive boosts.
 * `ducks` enables sidechain ducking against the main voice — when the speaker
 * is talking the music drops by ~12 dB and recovers on the tail.
 */
export interface AudioTrack {
  id: string;
  mediaId: MediaId;
  /** Volume adjustment in dB. 0 = unity. Negative = quieter. */
  gainDb: number;
  /** When on the output timeline the track begins, in seconds. */
  offsetSec: number;
  /** If true, the main voice ducks this track via sidechain compression. */
  ducks: boolean;
  /** Silence this track in the mix (preview and export). Not the same as hiding a lane. */
  muted?: boolean;
  /** If any track is soloed only soloed tracks are heard; solo wins over mute. */
  solo?: boolean;
  /** Linear fade-in from the track's start, seconds. Absent or 0 = none. */
  fadeInSec?: number;
  /** Linear fade-out ending where the track ends on the timeline, seconds. Absent or 0 = none. */
  fadeOutSec?: number;

  // Voice-over takes (`kind: "voiceover"`, see `lib/voiceover.ts`). All absent on
  // music tracks, so older projects and music beds serialise exactly as before.
  // `offsetSec` is the take's output anchor; it follows its content through edits
  // by segment-id lineage like every other track (`retimeAfterEdit`).
  /** "voiceover" for recorded narration. Absent = music / sfx bed. */
  kind?: "voiceover";
  /** Trim inside the take's media, seconds. Absent = from 0 / to the media end. */
  sourceIn?: number;
  sourceOut?: number;
  /** overlay: mixed over the picture; insert: the anchor frame is held while it plays. */
  mode?: VoiceOverMode;
  /** Mute the original (clip) audio inside this take's replacement interval. */
  overrideOriginal?: boolean;
  /** Insert takes: seconds of freeze-frame hold this take added at its anchor. */
  insertSec?: number;
  /** Transcript of the take, in the take's own media time (for captions). */
  words?: Word[];
}

export type VoiceOverMode = "overlay" | "insert";

/** True for a recorded voice-over take. */
export function isVoiceOver(track: Pick<AudioTrack, "kind">): boolean {
  return track.kind === "voiceover";
}

export interface Project {
  version: 1;
  id: string;
  name: string;
  createdAt: string;
  updatedAt: string;
  media: Record<MediaId, SourceMedia>;
  segments: Segment[];
  settings: ProjectSettings;
  /** Full transcription snapshots, captured before destructive edits. Absent on legacy projects. */
  originalTranscripts?: Record<MediaId, Word[]>;
  /** Optional — older v2.0 projects don't have this field. Empty by default. */
  chapters?: Chapter[];
  /** Optional — music beds / sfx mixed under the main EDL. Empty by default. */
  audioTracks?: AudioTrack[];
  /** Optional — background, padding, corners and shadow around the video. Absent = none. */
  scene?: SceneSettings;
  /** Optional — spans of the output timeline where the picture is zoomed in. */
  zoomRegions?: ZoomRegion[];
  /** Source-time cursor tracks by media id, with project-owned zoom/style preferences. */
  cursor?: ProjectCursor;
  /** Optional — caption look for the preview and burned-in export. Absent = defaults. */
  captions?: CaptionStyle;
  /** Optional — text, arrows and boxes on the output timeline. Absent = none. */
  annotations?: Annotation[];
  /** Optional — keystroke overlay preferences (opt-in). Absent = off. */
  keystrokes?: KeystrokeSettings;
  /** Optional — images and videos placed over the output timeline. Absent = none. */
  overlays?: MediaOverlay[];
  /**
   * Optional — privacy masks, anchored to SOURCE time and picture (`masks.ts`);
   * never retimed: where they show is derived from the timeline. Absent = none.
   */
  masks?: PrivacyMask[];
}

export interface TimelineEntry {
  segmentId: string;
  mediaId: MediaId;
  sourceIn: number;
  sourceOut: number;
  outputStart: number;
  outputEnd: number;
  /** Present only when not 1. Source seconds per output second. */
  speed?: number;
  /** Present only when > 0. The last `holdSec` of [outputStart, outputEnd) is a freeze frame. */
  holdSec?: number;
}

export { entryOutputAt, entryPlayEnd, entrySourceAt };

/** Speed / hold fields for a timeline entry, omitted when default so old shapes are unchanged. */
export function entryTiming(seg: Segment): { speed?: number; holdSec?: number } {
  const speed = segmentSpeed(seg);
  const hold = segmentHold(seg);
  return { ...(speed !== 1 ? { speed } : {}), ...(hold > 0 ? { holdSec: hold } : {}) };
}

/**
 * Timing carried from a clip to a piece cut from it: speed and mute always,
 * the transition only on the first piece, the hold only on the last.
 */
export function inheritTiming(
  from: Segment,
  piece: Segment,
  first: boolean,
  last: boolean,
  holdSec = from.holdSec,
): Segment {
  const out: Segment = { ...piece };
  if (from.speed !== undefined) out.speed = from.speed;
  if (from.muted) out.muted = true;
  if (first && from.transitionIn) out.transitionIn = from.transitionIn;
  if (last && holdSec) out.holdSec = holdSec;
  return out;
}

// ---------------------------------------------------------------------------
// Pure functions over Project / Segment / Word
// ---------------------------------------------------------------------------

/** Default padding (in seconds) added around the boundaries of a cut to avoid
 * clipped consonants. Mirrors `settings.paddingMs` (ms) when applied. */
export const DEFAULT_PADDING_MS = 80;

/** Total duration of the output timeline in seconds. */
export function totalDuration(project: Project): number {
  return project.segments.reduce((acc, seg) => acc + segmentOutputLength(seg), 0);
}

/**
 * Compute output timecodes for each segment by concatenating in order.
 * This is the single source of truth for mapping source-time → output-time.
 */
export function computeTimeline(project: Project): TimelineEntry[] {
  let outputCursor = 0;
  const result: TimelineEntry[] = [];
  for (const seg of project.segments) {
    const segDuration = segmentOutputLength(seg);
    result.push({
      segmentId: seg.id,
      mediaId: seg.mediaId,
      sourceIn: seg.sourceIn,
      sourceOut: seg.sourceOut,
      outputStart: outputCursor,
      outputEnd: outputCursor + segDuration,
      ...entryTiming(seg),
    });
    outputCursor += segDuration;
  }
  return result;
}

/** Given an output time, find which segment is playing and where in the source. */
export function outputTimeToSource(
  project: Project,
  outputTime: number,
): { segment: Segment; sourceTime: number } | null {
  const timeline = computeTimeline(project);
  for (const entry of timeline) {
    if (outputTime >= entry.outputStart && outputTime < entry.outputEnd) {
      const segment = project.segments.find((s) => s.id === entry.segmentId);
      if (!segment) return null;
      return { segment, sourceTime: entrySourceAt(entry, outputTime) };
    }
  }
  return null;
}

/** Given a source time, find its output-time position if that source range survived. */
export function sourceTimeToOutput(
  project: Project,
  mediaId: MediaId,
  sourceTime: number,
): { segment: Segment; outputTime: number } | null {
  const timeline = computeTimeline(project);
  for (const entry of timeline) {
    if (entry.mediaId === mediaId && sourceTime >= entry.sourceIn && sourceTime < entry.sourceOut) {
      const segment = project.segments.find((s) => s.id === entry.segmentId);
      if (!segment) return null;
      return { segment, outputTime: entryOutputAt(entry, sourceTime) };
    }
  }
  return null;
}

/** Map a surviving word id to the output timeline. */
export function wordIdToOutputTime(
  project: Project,
  wordId: string,
): { word: Word; segment: Segment; outputTime: number; sourceTime: number } | null {
  const timeline = computeTimeline(project);
  for (const entry of timeline) {
    const segment = project.segments.find((s) => s.id === entry.segmentId);
    if (!segment) continue;
    const word = segment.words.find((w) => w.id === wordId);
    if (!word) continue;
    const sourceTime = Math.max(entry.sourceIn, Math.min(word.start, entry.sourceOut));
    return {
      word,
      segment,
      sourceTime,
      outputTime: entryOutputAt(entry, sourceTime),
    };
  }
  return null;
}

/** Return surviving word IDs whose output-time span overlaps the given range. */
export function wordIdsInOutputRange(project: Project, markIn: number, markOut: number): string[] {
  const start = Math.min(markIn, markOut);
  const end = Math.max(markIn, markOut);
  if (end <= start) return [];

  const ids: string[] = [];
  const timeline = computeTimeline(project);
  for (const entry of timeline) {
    const segment = project.segments.find((s) => s.id === entry.segmentId);
    if (!segment) continue;
    for (const word of segment.words) {
      const wordOutStart = entryOutputAt(entry, Math.max(entry.sourceIn, word.start));
      const wordOutEnd = entryOutputAt(entry, Math.max(entry.sourceIn, word.end));
      if (wordOutStart < end && wordOutEnd > start) ids.push(word.id);
    }
  }
  return ids;
}

/** Given a source time within a media file, find the *next* surviving segment
 * for that media (used by the player to skip deleted ranges). Returns null if
 * we're past the last segment for the media. */
export function nextSurvivingSegment(
  project: Project,
  mediaId: MediaId,
  sourceTime: number,
): Segment | null {
  // Segments are stored in *output order* — for "next surviving" we need source order.
  const candidates = project.segments
    .filter((s) => s.mediaId === mediaId)
    .filter((s) => s.sourceIn >= sourceTime);
  if (candidates.length === 0) return null;
  candidates.sort((a, b) => a.sourceIn - b.sourceIn);
  return candidates[0] ?? null;
}

/** Find the word whose [start, end) brackets the given source time. */
export function findWordAtSourceTime(segment: Segment, sourceTime: number): Word | null {
  for (const w of segment.words) {
    if (sourceTime >= w.start && sourceTime < w.end) return w;
  }
  return null;
}

/** Find which segment contains a given word id (and the index of the word within it). */
export function findWord(
  project: Project,
  wordId: string,
): { segment: Segment; segmentIndex: number; wordIndex: number } | null {
  for (let i = 0; i < project.segments.length; i++) {
    const seg = project.segments[i]!;
    const wi = seg.words.findIndex((w) => w.id === wordId);
    if (wi !== -1) return { segment: seg, segmentIndex: i, wordIndex: wi };
  }
  return null;
}

// ---------------------------------------------------------------------------
// Mutating helpers — always return a *new* Project; never mutate the input.
// ---------------------------------------------------------------------------

/**
 * Split a segment at a given word boundary. Returns up to 2 new segments. The
 * resulting segments share the same mediaId and are sliced at the boundary
 * between word[wordIndex - 1] and word[wordIndex] (so wordIndex=0 leaves the
 * "left" empty and returns just the original; wordIndex=words.length leaves the
 * "right" empty).
 */
export function splitSegmentAtWord(segment: Segment, wordIndex: number): Segment[] {
  if (wordIndex <= 0) return [segment];
  if (wordIndex >= segment.words.length) return [segment];

  const leftWords = segment.words.slice(0, wordIndex);
  const rightWords = segment.words.slice(wordIndex);

  const leftEnd = leftWords[leftWords.length - 1]!.end;
  const rightStart = rightWords[0]!.start;

  // Boundary in source-time: midpoint between the two adjacent words. This is
  // intentionally simple — phase 6 will refine using audio-aware silence detection.
  const boundary = (leftEnd + rightStart) / 2;

  const left: Segment = {
    id: uuidv4(),
    mediaId: segment.mediaId,
    words: leftWords,
    sourceIn: segment.sourceIn,
    sourceOut: Math.min(segment.sourceOut, boundary),
  };
  const right: Segment = {
    id: uuidv4(),
    mediaId: segment.mediaId,
    words: rightWords,
    sourceIn: Math.max(segment.sourceIn, boundary),
    sourceOut: segment.sourceOut,
  };
  return [inheritTiming(segment, left, true, false), inheritTiming(segment, right, false, true)];
}

/**
 * Delete a set of word IDs from the project. The IDs are expected to be a
 * contiguous range *within a single source media* but the operation tolerates
 * multi-segment ranges and gaps.
 *
 * Algorithm:
 *   1. For each affected segment, partition its words into [keep-left, drop, keep-right].
 *   2. Each non-empty side becomes its own segment.
 *   3. Apply `paddingMs` to the boundary so we keep a small amount of audio either side.
 */
export function deleteWords(project: Project, wordIds: ReadonlySet<string>): Project {
  if (wordIds.size === 0) return project;

  const paddingSec = (project.settings.paddingMs ?? DEFAULT_PADDING_MS) / 1000;
  const nextSegments: Segment[] = [];

  for (const seg of project.segments) {
    // Quick path: nothing to do
    if (!seg.words.some((w) => wordIds.has(w.id))) {
      nextSegments.push(seg);
      continue;
    }

    // Walk the words and break them into runs of (kept|dropped).
    type Run = { kept: boolean; words: Word[] };
    const runs: Run[] = [];
    let current: Run | null = null;
    for (const w of seg.words) {
      const kept = !wordIds.has(w.id);
      if (!current || current.kept !== kept) {
        current = { kept, words: [w] };
        runs.push(current);
      } else {
        current.words.push(w);
      }
    }

    // Convert kept runs into segments with appropriate source-time bounds.
    const keptIdx: number[] = [];
    runs.forEach((r, i) => {
      if (r.kept) keptIdx.push(i);
    });
    const fromSeg: Segment[] = [];
    for (let k = 0; k < keptIdx.length; k++) {
      const i = keptIdx[k]!;
      const run = runs[i]!;
      const prevRun = k > 0 ? runs[keptIdx[k - 1]!]! : null;
      const nextRun = k < keptIdx.length - 1 ? runs[keptIdx[k + 1]!]! : null;

      const firstWord = run.words[0]!;
      const lastWord = run.words[run.words.length - 1]!;

      // Source bounds: start at firstWord.start - padding (clamped to seg.sourceIn),
      // end at lastWord.end + padding (clamped to seg.sourceOut).
      // If this run is the very first/last in the segment, use the segment bounds
      // so we don't accidentally shave off pre/post-roll the user explicitly kept.
      // Padding next to a cut is capped by the size of the cut (see cutPadding)
      // so neighbouring kept segments never overlap in source time.
      const isFirstRun = i === 0;
      const isLastRun = i === runs.length - 1;
      const padBefore = prevRun
        ? cutPadding(paddingSec, firstWord.start - prevRun.words[prevRun.words.length - 1]!.end)
        : paddingSec;
      const padAfter = nextRun
        ? cutPadding(paddingSec, nextRun.words[0]!.start - lastWord.end)
        : paddingSec;
      const sourceIn = isFirstRun
        ? seg.sourceIn
        : Math.max(seg.sourceIn, firstWord.start - padBefore);
      const sourceOut = isLastRun
        ? seg.sourceOut
        : Math.min(seg.sourceOut, lastWord.end + padAfter);

      fromSeg.push(
        inheritTiming(
          seg,
          { id: uuidv4(), mediaId: seg.mediaId, words: run.words, sourceIn, sourceOut },
          k === 0,
          k === keptIdx.length - 1,
        ),
      );
    }
    nextSegments.push(...separateOverlaps(fromSeg).map((p) => inheritLineage(p, seg.id)));
  }

  return retimeAfterEdit(project, {
    ...project,
    segments: nextSegments,
    updatedAt: new Date().toISOString(),
  });
}

/**
 * Padding kept either side of a cut, capped at a quarter of the cut so at
 * least half of every cut is really removed and the two kept sides can never
 * reach each other. `gap` is the source-time distance between the surviving
 * words on either side of the cut.
 */
function cutPadding(paddingSec: number, gap: number): number {
  return Math.min(paddingSec, Math.max(0, gap) / 4);
}

/** Safety net for degenerate input (overlapping words): consecutive segments
 * cut from one parent must not overlap in source time. */
function separateOverlaps(segs: Segment[]): Segment[] {
  const out = segs.map((s) => ({ ...s }));
  for (let i = 1; i < out.length; i++) {
    const prev = out[i - 1]!;
    const cur = out[i]!;
    if (prev.sourceOut > cur.sourceIn) {
      const mid = (prev.sourceOut + cur.sourceIn) / 2;
      prev.sourceOut = mid;
      cur.sourceIn = mid;
    }
  }
  return out;
}

/**
 * Keep ONLY the given output-time range; everything outside it is dropped
 * (the inverse of deleting the range). Works in source time per segment, so
 * segments without words can be trimmed too. Words are never mutated: a word
 * is kept whole when its span overlaps the kept source range, mirroring
 * `wordIdsInOutputRange`. Returns the same project when nothing would change.
 */
export function keepOutputRange(project: Project, markIn: number, markOut: number): Project {
  const start = Math.min(markIn, markOut);
  const end = Math.max(markIn, markOut);
  if (!(end > start)) return project;

  const timeline = computeTimeline(project);
  const nextSegments: Segment[] = [];
  let changed = false;

  for (const entry of timeline) {
    const seg = project.segments.find((s) => s.id === entry.segmentId);
    if (!seg) continue;
    const lo = Math.max(start, entry.outputStart);
    const hi = Math.min(end, entry.outputEnd);
    if (!(hi > lo)) {
      changed = true;
      continue;
    }
    // Use the segment's own bounds verbatim when the range covers that edge, so
    // no float error creeps in from `sourceIn + (t - outputStart)`.
    const playEnd = entryPlayEnd(entry);
    const sourceOut = hi >= playEnd ? seg.sourceOut : entrySourceAt(entry, hi);
    let sourceIn = lo <= entry.outputStart ? seg.sourceIn : entrySourceAt(entry, lo);
    // The part of the hold inside the kept range survives as the new hold.
    let hold = Math.max(0, hi - Math.max(lo, playEnd));
    if (hold > 0) {
      // A hold needs a real frame to freeze: keep at least one source frame of
      // footage (export clones the last decoded frame, so a sliver with no
      // frame would hold nothing), and shorten the hold by the footage added
      // so the kept range keeps its length.
      const frame = 1 / (project.media[seg.mediaId]?.fps || 30);
      if (sourceOut - sourceIn < frame) {
        const was = (sourceOut - sourceIn) / segmentSpeed(seg);
        sourceIn = Math.max(seg.sourceIn, sourceOut - frame);
        hold = Math.max(0, hold - ((sourceOut - sourceIn) / segmentSpeed(seg) - was));
      }
    }
    if (sourceIn === seg.sourceIn && sourceOut === seg.sourceOut && hold === segmentHold(seg)) {
      nextSegments.push(seg);
      continue;
    }
    changed = true;
    nextSegments.push(
      // Lineage last: inheritTiming returns a new object and lineage is keyed by identity.
      inheritLineage(
        inheritTiming(
          seg,
          {
            id: uuidv4(),
            mediaId: seg.mediaId,
            words: seg.words.filter((w) => w.end > sourceIn && w.start < sourceOut),
            sourceIn,
            sourceOut,
          },
          lo <= entry.outputStart,
          true,
          hold,
        ),
        seg.id,
      ),
    );
  }

  // A range that misses the timeline entirely would leave an empty project; treat as no-op.
  if (!changed || nextSegments.length === 0) return project;
  return retimeAfterEdit(project, {
    ...project,
    segments: nextSegments,
    updatedAt: new Date().toISOString(),
  });
}

/**
 * After an edit that removes output time, move chapters and audio tracks so
 * they keep pointing at the same *content*. A chapter whose content was removed
 * is dropped; an audio track whose start was removed starts at the next
 * surviving content (or at the end of the new timeline).
 */
export function retimeAfterEdit(before: Project, after: Project): Project {
  const hasChapters = (after.chapters?.length ?? 0) > 0;
  const hasTracks = (after.audioTracks?.length ?? 0) > 0;
  const hasZoom = (after.zoomRegions?.length ?? 0) > 0;
  const hasAnnotations = (after.annotations?.length ?? 0) > 0;
  const hasOverlays = (after.overlays?.length ?? 0) > 0;
  if (!hasChapters && !hasTracks && !hasZoom && !hasAnnotations && !hasOverlays) return after;

  const { oldTl, newTl } = ownedTimelines(before, after);
  const newTotal = totalDuration(after);
  const next: Project = { ...after };
  // For range-based overlays (zoom, annotations) the "media" of each entry is the
  // clip it descends from, so retimers that match on mediaId match by clip.
  const oldById = oldTl.map((e) => ({ ...e, mediaId: e.segmentId }));
  const newByOwner = newTl.map((e) => ({ ...e, mediaId: e.owner }));

  if (hasChapters) {
    next.chapters = after.chapters!.flatMap((c) => {
      const t = mapOutputTimeStrict(oldTl, newTl, c.outputTime);
      return t === null ? [] : [{ ...c, outputTime: t }];
    });
  }
  if (hasZoom) {
    // Regions follow their clip (by segment identity), closing up over cuts. The
    // synthetic "media" of each entry is the clip it descends from, so two clips
    // that play the same source never share a region. Stored JSON is untrusted:
    // validate first so a bad value cannot make every edit throw.
    const regions = sanitizeZoomRegions(after.zoomRegions, totalDuration(before));
    const moved = retimeZoomRegions(regions, oldById, newByOwner, newTotal);
    if (moved.length > 0) next.zoomRegions = moved;
    else delete next.zoomRegions;
  }
  if (hasAnnotations) {
    // Same segment-id lineage as zoom: an annotation on a duplicated clip stays on that copy.
    const current = sanitizeAnnotations(after.annotations, totalDuration(before));
    const moved = retimeAnnotations(current, oldById, newByOwner, newTotal);
    if (moved.length > 0) next.annotations = moved;
    else delete next.annotations;
  }
  if (hasOverlays) {
    const moved = retimeOverlays(
      sanitizeOverlays(after.overlays, totalDuration(before)),
      oldById,
      newByOwner,
      newTotal,
    );
    if (moved.length > 0) next.overlays = moved;
    else delete next.overlays;
  }
  if (hasTracks) {
    next.audioTracks = after.audioTracks!.map((t) => {
      if (t.offsetSec < 0) return t;
      if (insertTakeSec(t) > 0) return retimeInsertTake(t, oldTl, newTl, newTotal);
      return { ...t, offsetSec: mapOutputTimeLenient(oldTl, newTl, t.offsetSec, newTotal) };
    });
  }
  return next;
}

// ---------------------------------------------------------------------------
// Segment identity through edits
//
// Two clips may play the same source range (duplicate clip), so source time
// alone cannot say which clip a chapter, zoom region or music bed belongs to.
// Retiming therefore goes by segment id first. An edit that splits or rebuilds a
// segment records which old segment(s) the new one came from (`inheritLineage`,
// kept in a WeakMap so it is never saved); only a new segment with no recorded
// parent falls back to source time, and only against old segments that nothing
// else claimed.
// ---------------------------------------------------------------------------

/** A duplicated clip's words get `<original id>#<suffix>`; this strips it. */
export const baseWordId = (id: string) => id.split("#")[0]!;

const lineage = new WeakMap<Segment, readonly string[]>();

/** Record that `seg` was cut from (or merged out of) the segments `parents`. */
export function inheritLineage<T extends Segment>(seg: T, ...parents: string[]): T {
  lineage.set(seg, parents);
  return seg;
}

interface OwnedEntry extends TimelineEntry {
  /** Id of the old segment this entry continues. */
  owner: string;
}

function ownedTimelines(
  before: Project,
  after: Project,
): { oldTl: TimelineEntry[]; newTl: OwnedEntry[] } {
  const oldTl = computeTimeline(before);
  const oldIds = new Set(oldTl.map((e) => e.segmentId));
  const entries = computeTimeline(after);
  const keys = after.segments.map((s, i) =>
    [s.id, ...(lineage.get(s) ?? [])].filter((k) => oldIds.has(k)).map((k) => [k, i] as const),
  );
  const claimed = new Set(keys.flatMap((k) => k.map(([id]) => id)));
  const dead = oldTl.filter((e) => !claimed.has(e.segmentId));
  const newTl: OwnedEntry[] = [];
  entries.forEach((n, i) => {
    let owners = keys[i]!.map(([id]) => id);
    if (owners.length === 0) {
      // No recorded parent: match by source time against unclaimed old clips only.
      const o = dead.find(
        (e) => e.mediaId === n.mediaId && e.sourceIn < n.sourceOut && n.sourceIn < e.sourceOut,
      );
      owners = o ? [o.segmentId] : [];
    }
    for (const owner of owners) newTl.push({ ...n, owner });
  });
  return { oldTl, newTl };
}

function mapOutputTimeStrict(
  oldTl: TimelineEntry[],
  newTl: OwnedEntry[],
  t: number,
): number | null {
  const e = oldTl.find((x) => t >= x.outputStart && t < x.outputEnd);
  if (!e) return null;
  const held = mapHold(e, newTl, t, (x) => x.owner === e.segmentId);
  if (held !== undefined) return held;
  const src = entrySourceAt(e, t);
  const n = newTl.find((x) => x.owner === e.segmentId && src >= x.sourceIn && src < x.sourceOut);
  return n ? entryOutputAt(n, src) : null;
}

/**
 * An insert take stays on its hold: the same frame's hold when it survives,
 * else a hold on a piece of the same clip big enough for it (the hold moved to
 * the last piece of a cut clip). When its held clip is gone, the take becomes
 * an overlay at the next content and owns no hold any more, so removing it
 * later can never shrink someone else's hold.
 */
function retimeInsertTake(
  t: AudioTrack,
  oldTl: TimelineEntry[],
  newTl: OwnedEntry[],
  newTotal: number,
): AudioTrack {
  const e = oldTl.find(
    (x) => x.holdSec && t.offsetSec >= entryPlayEnd(x) - 1e-3 && t.offsetSec < x.outputEnd,
  );
  if (e) {
    const into = Math.max(0, t.offsetSec - entryPlayEnd(e));
    const same = mapHold(
      e,
      newTl,
      Math.max(t.offsetSec, entryPlayEnd(e)),
      (x) => x.owner === e.segmentId,
    );
    if (typeof same === "number") return { ...t, offsetSec: same };
    const moved = newTl
      .filter((x) => x.owner === e.segmentId && (x.holdSec ?? 0) >= into + insertTakeSec(t) - 1e-3)
      .pop();
    if (moved) return { ...t, offsetSec: entryPlayEnd(moved) + into };
  }
  const orphan: AudioTrack = {
    ...t,
    mode: "overlay",
    offsetSec: mapOutputTimeLenient(oldTl, newTl, t.offsetSec, newTotal),
  };
  delete orphan.insertSec;
  return orphan;
}

function mapOutputTimeLenient(
  oldTl: TimelineEntry[],
  newTl: OwnedEntry[],
  t: number,
  newTotal: number,
): number {
  for (const e of oldTl) {
    if (e.outputEnd <= t) continue;
    const held = mapHold(e, newTl, t, (x) => x.owner === e.segmentId);
    if (typeof held === "number") return held;
    const a = entrySourceAt(e, t);
    for (const n of newTl) {
      if (n.owner !== e.segmentId) continue;
      const lo = Math.max(a, n.sourceIn);
      if (lo < Math.min(e.sourceOut, n.sourceOut)) return entryOutputAt(n, lo);
    }
  }
  return newTotal;
}

/**
 * Restore previously deleted words from `originalTranscripts`: the inverse of
 * `deleteWords`. See `restoreWordsDetailed` for placement rules and the
 * legacy-project limitation.
 */
export function restoreWords(project: Project, wordIds: ReadonlySet<string>): Project {
  return restoreWordsDetailed(project, wordIds).project;
}

/** Why a restore may do nothing: the project was made before originals were kept. */
export const RESTORE_LEGACY_MESSAGE =
  "This project has no saved original transcript, so deleted words cannot be restored. Use Undo, or retranscribe the media to enable restore.";

export interface RestoreResult {
  project: Project;
  /** Words put back on the timeline. */
  restored: number;
  /** Requested ids that are not live and not in any original transcript. */
  unavailable: number;
  /** Set when some media has no original transcript (legacy project). */
  limitation: string | null;
}

const wordMid = (w: Word) => (w.start + w.end) / 2;

/** Original words that no segment holds any more (deleted or trimmed away). */
export function deletedWords(project: Project): Word[] {
  const live = new Set(project.segments.flatMap((s) => s.words.map((w) => w.id)));
  return Object.entries(project.originalTranscripts ?? {})
    .filter(([mediaId]) => project.media[mediaId])
    .flatMap(([, words]) => words.filter((w) => !live.has(w.id)));
}

/**
 * Put deleted words back from `originalTranscripts`. Each run of adjacent
 * originals comes back as its own clip placed after the clip that precedes it in
 * source time (merged when the two touch); a word whose midpoint is already
 * inside a clip just rejoins that clip. Padding is the project's, clamped so the
 * new range never overlaps another clip of the same media or captures an
 * un-restored word. Without originals nothing changes and `limitation` says why.
 */
export function restoreWordsDetailed(
  project: Project,
  wordIds: ReadonlySet<string>,
): RestoreResult {
  const originals = project.originalTranscripts ?? {};
  const limitation = Object.keys(project.media).some((id) => !originals[id])
    ? RESTORE_LEGACY_MESSAGE
    : null;
  const live = new Set(project.segments.flatMap((s) => s.words.map((w) => w.id)));
  const wanted = new Set([...wordIds].filter((id) => !live.has(id)));
  const known = new Set<string>();
  const pad = (project.settings.paddingMs ?? DEFAULT_PADDING_MS) / 1000;
  const EPS = 1e-6;
  let segments = project.segments;
  let restored = 0;

  for (const [mediaId, words] of Object.entries(originals)) {
    const media = project.media[mediaId];
    if (!media) continue;
    const pick = (w: Word) => wanted.has(w.id);
    words.forEach((w) => pick(w) && known.add(w.id));
    // Words already inside a clip's range rejoin that clip.
    const uncovered = new Set<string>();
    for (const w of words.filter(pick)) {
      // A clip that already has this word (perhaps under a duplicate's suffix) is
      // never given it twice; the word then comes back as a clip of its own.
      const k = segments.findIndex(
        (s) =>
          s.mediaId === mediaId &&
          wordMid(w) >= s.sourceIn &&
          wordMid(w) < s.sourceOut &&
          !s.words.some((x) => baseWordId(x.id) === baseWordId(w.id)),
      );
      if (k < 0) uncovered.add(w.id);
      else {
        segments = segments.map((s, n) =>
          n === k ? { ...s, words: [...s.words, w].sort((a, b) => a.start - b.start) } : s,
        );
        restored++;
      }
    }
    for (let i = 0; i < words.length; i++) {
      if (!uncovered.has(words[i]!.id)) continue;
      const same = segments.filter((s) => s.mediaId === mediaId);
      const first = words[i]!;
      const next = same.filter((s) => s.sourceIn >= wordMid(first));
      const nextIn = next.reduce((m, s) => Math.min(m, s.sourceIn), Infinity);
      const run: Word[] = [first];
      while (uncovered.has(words[i + 1]?.id ?? "") && wordMid(words[i + 1]!) < nextIn)
        run.push(words[++i]!);
      const last = run[run.length - 1]!;
      const prior = same
        .filter((s) => s.sourceOut <= wordMid(first))
        .reduce<Segment | null>((m, s) => (!m || s.sourceOut >= m.sourceOut ? s : m), null);
      const after = next.find((s) => s.sourceIn === nextIn) ?? null;
      const before = words[words.indexOf(first) - 1];
      const beyond = words[words.indexOf(last) + 1];
      const start = Math.min(
        wordMid(first) - EPS,
        Math.max(first.start - pad, prior?.sourceOut ?? 0, before ? wordMid(before) + EPS : 0),
      );
      const end = Math.max(
        wordMid(last) + EPS,
        Math.min(
          last.end + pad,
          after?.sourceIn ?? media.duration,
          beyond ? wordMid(beyond) : Infinity,
        ),
      );
      const seg: Segment = {
        id: uuidv4(),
        mediaId,
        words: run,
        sourceIn: Math.max(0, start),
        sourceOut: end,
      };
      const at = prior
        ? segments.indexOf(prior) + 1
        : after
          ? segments.indexOf(after)
          : segments.length;
      segments = joinTouching([...segments.slice(0, at), seg, ...segments.slice(at)], at);
      restored += run.length;
    }
  }
  const unavailable = [...wanted].filter((id) => !known.has(id)).length;
  if (restored === 0) return { project, restored, unavailable, limitation };
  return {
    project: retimeAfterEdit(project, {
      ...project,
      segments,
      updatedAt: new Date().toISOString(),
    }),
    restored,
    unavailable,
    limitation,
  };
}

/** Merge the clip at `at` with source-contiguous neighbours of the same media. */
function joinTouching(segments: Segment[], at: number): Segment[] {
  const out = [...segments];
  // Only clips that play the same way join: a restored 1x piece next to a 2x
  // clip stays its own clip. A hold must stay at the very end and a transition
  // at the very start, so `a` may not hold and `b` may not have a transition.
  const touches = (a: Segment, b: Segment) =>
    a.mediaId === b.mediaId &&
    Math.abs(a.sourceOut - b.sourceIn) < 1e-6 &&
    segmentSpeed(a) === segmentSpeed(b) &&
    !!a.muted === !!b.muted &&
    segmentHold(a) === 0 &&
    !b.transitionIn;
  const merge = (a: Segment, b: Segment): Segment =>
    inheritLineage(
      {
        ...a,
        sourceOut: b.sourceOut,
        words: [...a.words, ...b.words],
        ...(b.holdSec ? { holdSec: b.holdSec } : {}),
      },
      a.id,
      b.id,
      ...(lineage.get(a) ?? []),
      ...(lineage.get(b) ?? []),
    );
  if (at + 1 < out.length && touches(out[at]!, out[at + 1]!))
    out.splice(at, 2, merge(out[at]!, out[at + 1]!));
  if (at > 0 && touches(out[at - 1]!, out[at]!))
    out.splice(at - 1, 2, merge(out[at - 1]!, out[at]!));
  return out;
}

/**
 * Cut detected silences out of the timeline, leaving `keepSec` of silence
 * (half on each side) in place. Silences come from signal analysis
 * (ffmpeg silencedetect), never from word gaps: DTW word spans absorb the
 * silence before a word, so gaps between words are not reliable. Only silences
 * longer than `minDuration` are cut. Returns `[nextProject, cutCount]`.
 */
export function cutSilences(
  project: Project,
  mediaId: string,
  silences: ReadonlyArray<{ start: number; end: number }>,
  options: { minDuration: number; keepSec?: number },
): [Project, number] {
  const keep = Math.max(0, options.keepSec ?? 0);
  const ranges = silences
    .filter((s) => s.end - s.start > options.minDuration)
    .map((s) => ({ start: s.start + keep / 2, end: s.end - keep / 2 }));
  return trimSourceRanges(project, mediaId, ranges);
}

/** Cuts shorter than this (seconds) are ignored — below one audio frame. */
const MIN_CUT_SEC = 0.001;

/**
 * Remove source-time ranges of one media from the timeline, splitting the
 * segments that contain them. Used to shorten detected pauses. A cut never
 * removes or clips a word: each range is reduced by every word span it touches,
 * so only audio between words goes. Returns `[nextProject, cutCount]`, where
 * `cutCount` is the number of input ranges that removed any time; the same
 * project is returned when nothing changed.
 */
export function trimSourceRanges(
  project: Project,
  mediaId: string,
  ranges: ReadonlyArray<{ start: number; end: number }>,
): [Project, number] {
  const cutRanges = new Set<number>();
  const nextSegments: Segment[] = [];

  for (const seg of project.segments) {
    if (seg.mediaId !== mediaId) {
      nextSegments.push(seg);
      continue;
    }

    // Clip every range to the segment, then subtract the word spans from it.
    const cuts: { start: number; end: number; range: number }[] = [];
    ranges.forEach((r, range) => {
      let pieces = [
        { start: Math.max(r.start, seg.sourceIn), end: Math.min(r.end, seg.sourceOut) },
      ];
      for (const w of seg.words) {
        pieces = pieces.flatMap((p) =>
          w.end <= p.start || w.start >= p.end
            ? [p]
            : [
                { start: p.start, end: w.start },
                { start: w.end, end: p.end },
              ],
        );
      }
      for (const p of pieces) if (p.end - p.start >= MIN_CUT_SEC) cuts.push({ ...p, range });
    });
    if (cuts.length === 0) {
      nextSegments.push(seg);
      continue;
    }

    // Merge overlapping cuts, then emit the kept pieces between them.
    cuts.sort((a, b) => a.start - b.start);
    const merged: { start: number; end: number }[] = [];
    for (const c of cuts) {
      cutRanges.add(c.range);
      const last = merged[merged.length - 1];
      if (last && c.start <= last.end) last.end = Math.max(last.end, c.end);
      else merged.push({ start: c.start, end: c.end });
    }
    let keptFrom = seg.sourceIn;
    const bounds = [...merged, { start: seg.sourceOut, end: seg.sourceOut }];
    bounds.forEach((cut, k) => {
      const keptTo = cut.start;
      const isFirst = k === 0;
      const isLast = k === bounds.length - 1;
      if (keptTo - keptFrom >= MIN_CUT_SEC) {
        const piece: Segment = {
          id: uuidv4(),
          mediaId: seg.mediaId,
          // Cuts avoid word spans, so each word sits wholly inside one kept
          // piece; the outer pieces also take words that overhang the segment.
          words: seg.words.filter((w) => {
            const mid = (w.start + w.end) / 2;
            return (isFirst || mid >= keptFrom) && (isLast || mid < keptTo);
          }),
          sourceIn: keptFrom,
          sourceOut: keptTo,
        };
        nextSegments.push(inheritLineage(inheritTiming(seg, piece, isFirst, isLast), seg.id));
      }
      keptFrom = cut.end;
    });
  }

  if (cutRanges.size === 0) return [project, 0];
  return [
    retimeAfterEdit(project, {
      ...project,
      segments: nextSegments,
      updatedAt: new Date().toISOString(),
    }),
    cutRanges.size,
  ];
}

export interface TimingPatch {
  speed?: number;
  muted?: boolean;
  holdSec?: number;
  /** null removes the transition. */
  transitionIn?: Transition | null;
}

/**
 * Change one clip's speed, mute, hold or transition. Values are clamped and
 * defaults are stored as absent, so a clip set back to normal is byte-identical
 * to one that was never changed. Chapters, zoom and music follow their content
 * through the re-timed output (`retimeAfterEdit`). A transition on the first
 * clip has no cut to sit on and is refused. Same project back when nothing changes.
 */
export function setSegmentTiming(project: Project, segmentId: string, patch: TimingPatch): Project {
  const i = project.segments.findIndex((s) => s.id === segmentId);
  if (i < 0) return project;
  const seg = project.segments[i]!;
  const next: Segment = { ...seg };
  if (patch.speed !== undefined) {
    const speed = segmentSpeed({ speed: patch.speed });
    if (speed === 1) delete next.speed;
    else next.speed = speed;
  }
  if (patch.muted !== undefined) {
    if (patch.muted) next.muted = true;
    else delete next.muted;
  }
  if (patch.holdSec !== undefined) {
    // The part of the hold that inserted voice-over narration owns is not
    // editable here; only the user's own freeze on top of it is.
    const hold = Math.max(
      segmentHold({ holdSec: patch.holdSec }),
      insertOwnedHold(project, segmentId),
    );
    if (hold > 0) next.holdSec = hold;
    else delete next.holdSec;
  }
  if (patch.transitionIn !== undefined) {
    const t = patch.transitionIn;
    if (!t) delete next.transitionIn;
    else if (i === 0 || (t.kind !== "crossfade" && t.kind !== "dip")) return project;
    else {
      const duration = Number.isFinite(t.duration) ? t.duration : MIN_TRANSITION_SEC;
      next.transitionIn = {
        kind: t.kind,
        duration: clamp(duration, MIN_TRANSITION_SEC, MAX_TRANSITION_SEC),
      };
    }
  }
  const same = (["speed", "muted", "holdSec"] as const).every((k) => next[k] === seg[k]);
  const sameT =
    next.transitionIn?.kind === seg.transitionIn?.kind &&
    next.transitionIn?.duration === seg.transitionIn?.duration;
  if (same && sameT) return project;
  const segments = project.segments.map((s, k) => (k === i ? next : s));
  return retimeAfterEdit(project, { ...project, segments, updatedAt: new Date().toISOString() });
}

/** Add a new source media + initial single-segment-covers-everything EDL. */
export function addMediaWithTranscript(
  project: Project,
  media: SourceMedia,
  words: Word[],
): Project {
  const segment: Segment = {
    id: uuidv4(),
    mediaId: media.id,
    words,
    sourceIn: 0,
    sourceOut: media.duration,
  };
  return {
    ...project,
    media: { ...project.media, [media.id]: media },
    segments: [...project.segments, segment],
    ...(words.length
      ? { originalTranscripts: { ...project.originalTranscripts, [media.id]: words } }
      : {}),
    updatedAt: new Date().toISOString(),
  };
}

// ---------------------------------------------------------------------------
// Chapters — pure helpers. All return a new Project; never mutate.
// ---------------------------------------------------------------------------

/** Read chapters defensively — handles older projects without the field. */
export function projectChapters(project: Project): Chapter[] {
  return project.chapters ?? [];
}

/** Add a chapter at the given output-time. Returns a new project; chapters are
 * stored in ascending outputTime order so the timeline and exporter don't have
 * to re-sort. Duplicate times are allowed (one wins; the user can rename). */
export function addChapter(project: Project, outputTime: number, title = "Chapter"): Project {
  const id = uuidv4();
  const chapter: Chapter = {
    id,
    outputTime: Math.max(0, Math.min(outputTime, totalDuration(project))),
    title: title.trim() || "Chapter",
  };
  const next = [...projectChapters(project), chapter].sort((a, b) => a.outputTime - b.outputTime);
  return { ...project, chapters: next, updatedAt: new Date().toISOString() };
}

export function removeChapter(project: Project, id: string): Project {
  const next = projectChapters(project).filter((c) => c.id !== id);
  if (next.length === projectChapters(project).length) return project;
  return { ...project, chapters: next, updatedAt: new Date().toISOString() };
}

export function renameChapter(project: Project, id: string, title: string): Project {
  const next = projectChapters(project).map((c) =>
    c.id === id ? { ...c, title: title.trim() || "Chapter" } : c,
  );
  return { ...project, chapters: next, updatedAt: new Date().toISOString() };
}

// ---------------------------------------------------------------------------
// Audio tracks — pure helpers. All return a new Project; never mutate.
// ---------------------------------------------------------------------------

/** Read audio tracks defensively — older projects don't have the field. */
export function projectAudioTracks(project: Project): AudioTrack[] {
  return project.audioTracks ?? [];
}

/** Add a new music bed / sfx track. The media must already be in
 * `project.media`. Returns a new project. */
export function addAudioTrack(
  project: Project,
  track: Omit<AudioTrack, "id"> & { id?: string },
): Project {
  if (!project.media[track.mediaId]) {
    throw new Error(`audio track references unknown media: ${track.mediaId}`);
  }
  const next: AudioTrack = {
    id: track.id ?? uuidv4(),
    mediaId: track.mediaId,
    gainDb: clampGain(track.gainDb),
    offsetSec: Number.isFinite(track.offsetSec) ? track.offsetSec : 0,
    ducks: !!track.ducks,
    ...mixerFields(track),
  };
  return {
    ...project,
    audioTracks: [...projectAudioTracks(project), next],
    updatedAt: new Date().toISOString(),
  };
}

/**
 * Remove a track. Removing an insert voice-over also removes the freeze-frame
 * hold it added, so everything after it closes up again (one undo step).
 */
export function removeAudioTrack(project: Project, id: string): Project {
  const tracks = projectAudioTracks(project);
  const track = tracks.find((t) => t.id === id);
  if (!track) return project;
  // Give the hold back first (it is matched to this take), then drop the take.
  const held =
    insertTakeSec(track) > 0 ? adjustInsertHold(project, id, -insertTakeSec(track)) : project;
  return {
    ...held,
    audioTracks: projectAudioTracks(held).filter((t) => t.id !== id),
    updatedAt: new Date().toISOString(),
  };
}

/** Seconds of hold an insert voice-over take owns (0 for everything else). */
export function insertTakeSec(track: AudioTrack): number {
  const s = track.insertSec;
  return isVoiceOver(track) && track.mode === "insert" && typeof s === "number" && s > 0 ? s : 0;
}

/** The insert takes whose anchor lies in the hold of timeline entry `e`. */
function insertTakesIn(project: Project, e: TimelineEntry): AudioTrack[] {
  if (!e.holdSec) return [];
  const from = entryPlayEnd(e) - 1e-3;
  return projectAudioTracks(project).filter(
    (t) => insertTakeSec(t) > 0 && t.offsetSec >= from && t.offsetSec < e.outputEnd - 1e-9,
  );
}

/**
 * Seconds of a clip's hold that belong to insert voice-over takes (the rest is
 * the user's own Timing-panel freeze). Never more than the hold itself.
 */
export function insertOwnedHold(project: Project, segmentId: string): number {
  const e = computeTimeline(project).find((x) => x.segmentId === segmentId);
  if (!e?.holdSec) return 0;
  const owned = insertTakesIn(project, e).reduce((sum, t) => sum + insertTakeSec(t), 0);
  return Math.min(e.holdSec, owned);
}

/**
 * Grow (delta > 0) or shrink the freeze-frame hold owned by insert take
 * `trackId`, then move chapters, zoom, annotations and the other tracks with
 * their content. Insert takes later in the same hold move by `delta` too, so
 * stacked takes stay back to back. Matched by the take: nothing changes when
 * the take no longer sits in a hold it owns, so a user's own Timing-panel hold
 * is never shrunk.
 */
export function adjustInsertHold(project: Project, trackId: string, delta: number): Project {
  const track = projectAudioTracks(project).find((t) => t.id === trackId);
  if (!track || insertTakeSec(track) <= 0) return project;
  const entry = computeTimeline(project).find((e) =>
    insertTakesIn(project, e).some((t) => t.id === trackId),
  );
  if (!entry) return project;
  const hold = entry.holdSec! + delta;
  if (hold < -1e-3 || hold > MAX_HOLD_SEC) return project;
  const owners = new Map(insertTakesIn(project, entry).map((t) => [t.id, t.offsetSec]));
  const segments = project.segments.map((s) => {
    if (s.id !== entry.segmentId) return s;
    const next: Segment = { ...s };
    if (hold > 1e-9) next.holdSec = hold;
    else delete next.holdSec;
    return next;
  });
  const next = retimeAfterEdit(project, {
    ...project,
    segments,
    updatedAt: new Date().toISOString(),
  });
  // Retiming keeps each take at its offset inside the hold; takes after this
  // one shift by the change instead, so stacked takes stay back to back.
  return {
    ...next,
    audioTracks: projectAudioTracks(next).map((t) => {
      const was = owners.get(t.id);
      if (was === undefined) return t;
      return { ...t, offsetSec: was > track.offsetSec + 1e-9 ? was + delta : was };
    }),
  };
}

/** Seconds of a take's media that play: its trim, inside the media. */
export function voiceOverLength(track: AudioTrack, mediaDuration: number): number {
  const dur = mediaDuration > 0 ? mediaDuration : Number.POSITIVE_INFINITY;
  const sin = Math.max(0, track.sourceIn ?? 0);
  const sout = Math.min(dur, track.sourceOut ?? dur);
  return Math.max(0, sout - sin);
}

export function updateAudioTrack(
  project: Project,
  id: string,
  patch: Partial<Omit<AudioTrack, "id" | "mediaId">>,
): Project {
  const tracks = projectAudioTracks(project);
  const idx = tracks.findIndex((t) => t.id === id);
  if (idx === -1) return project;
  const cur = tracks[idx]!;
  // Kind, mode and the owned hold change only through the voice-over helpers
  // (`setVoiceOverMode`); an insert take's anchor is pinned to its hold.
  const rest = { ...patch };
  delete rest.kind;
  delete rest.mode;
  delete rest.insertSec;
  const pinned = insertTakeSec(cur) > 0;
  const next: AudioTrack = {
    ...cur,
    ...rest,
    gainDb: patch.gainDb !== undefined ? clampGain(patch.gainDb) : cur.gainDb,
    offsetSec:
      !pinned && patch.offsetSec !== undefined && Number.isFinite(patch.offsetSec)
        ? patch.offsetSec
        : cur.offsetSec,
    ...mixerFields(patch),
    ...trimFields(cur, patch),
  };
  const out = tracks.slice();
  out[idx] = next;
  const updated: Project = { ...project, audioTracks: out, updatedAt: new Date().toISOString() };
  if (!pinned) return updated;
  // An insert take's hold follows its trimmed length.
  const len = voiceOverLength(next, project.media[cur.mediaId]?.duration ?? 0);
  const delta = len - insertTakeSec(cur);
  if (Math.abs(delta) < 1e-9) return updated;
  const held = adjustInsertHold(updated, id, delta);
  if (held === updated) return project; // hold gone or over the limit: refuse rather than desync
  return {
    ...held,
    audioTracks: projectAudioTracks(held).map((t) => (t.id === id ? { ...t, insertSec: len } : t)),
  };
}

/** Source trim, cleaned: finite, in order, absent when it is the default. */
function trimFields(cur: AudioTrack, patch: Partial<AudioTrack>): Partial<AudioTrack> {
  if (patch.sourceIn === undefined && patch.sourceOut === undefined) return {};
  const sin = patch.sourceIn ?? cur.sourceIn;
  const sout = patch.sourceOut ?? cur.sourceOut;
  const out: Partial<AudioTrack> = {};
  out.sourceIn = sin !== undefined && Number.isFinite(sin) && sin > 0 ? sin : undefined;
  out.sourceOut =
    sout !== undefined && Number.isFinite(sout) && sout > (out.sourceIn ?? 0) ? sout : undefined;
  return out;
}

/**
 * The mixer fields present in `src`, cleaned. Off values become absent so old
 * projects, and tracks that never use the mixer, serialise exactly as before.
 */
function mixerFields(
  src: Partial<Pick<AudioTrack, "muted" | "solo" | "fadeInSec" | "fadeOutSec">>,
): Partial<AudioTrack> {
  const out: Partial<AudioTrack> = {};
  if (src.muted !== undefined) out.muted = src.muted ? true : undefined;
  if (src.solo !== undefined) out.solo = src.solo ? true : undefined;
  for (const k of ["fadeInSec", "fadeOutSec"] as const) {
    const v = src[k];
    if (v !== undefined) out[k] = Number.isFinite(v) && v > 0 ? Math.min(v, 600) : undefined;
  }
  return out;
}

/** Clamp gain to a sensible range: -60 dB (effectively silent) to +12 dB. */
function clampGain(db: number): number {
  if (!Number.isFinite(db)) return 0;
  return Math.max(-60, Math.min(12, db));
}

/** Create a brand new empty project. */
export function newProject(name: string): Project {
  const now = new Date().toISOString();
  return {
    version: 1,
    id: uuidv4(),
    name,
    createdAt: now,
    updatedAt: now,
    media: {},
    segments: [],
    settings: {
      exportPreset: "youtube-1080p",
      paddingMs: DEFAULT_PADDING_MS,
    },
    chapters: [],
    audioTracks: [],
  };
}
