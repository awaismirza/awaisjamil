/**
 * Pure builder for the export request, extracted from Toolbar.runExport so the
 * UI and the agent tools produce identical ExportOptions.
 */

import { totalDuration, type ExportPreset, type Project } from "./edl";
import type { ExportAudioReport, ExportFormat, ExportOptions } from "./ipc";
import { layoutProjectCaptions, stripEmoji, toExportCues } from "./captionLayout";
import { sanitizeCaptionStyle } from "./captionStyle";
import {
  resolveSceneForExport,
  sanitizeScene,
  sceneActive,
  sceneSourceMedia,
  sceneTransparent,
} from "./scene";
import { sanitizeZoomRegions } from "./zoom";

export interface ExportUiSettings {
  resolution: "original" | "720p" | "1080p" | "4k" | "custom";
  customWidth: number;
  customHeight: number;
  codec: "auto" | "h264" | "hevc";
  fps?: string | number;
  videoBitrateKbps?: number;
  audioBitrateKbps?: number;
  forceReencode?: boolean;
  /** Omitted means MP4 (M4A for the podcast-audio preset). */
  format?: ExportFormat;
  /** Output-timeline span in seconds; either end may be omitted. */
  rangeStart?: number;
  rangeEnd?: number;
  /** Audio formats only: also write one file per source and music track. */
  stems?: boolean;
  /** Target integrated loudness in LUFS (-16 podcast, -14 streaming); omitted = off. */
  loudnessLufs?: number;
  /** Burn captions into the picture (default off). Ignored for audio formats. */
  burnCaptions?: boolean;
  /** With burnCaptions: drop emoji from the burned text (libass cannot draw them). */
  stripCaptionEmoji?: boolean;
}

export type { ExportFormat };

/** Label, file extension and kind of every export format (mirrors export.rs). */
export const EXPORT_FORMATS: Record<ExportFormat, { label: string; ext: string; audio: boolean }> =
  {
    mp4: { label: "MP4 (H.264 / HEVC)", ext: "mp4", audio: false },
    mov: { label: "MOV (H.264 / HEVC)", ext: "mov", audio: false },
    "prores-422": { label: "ProRes 422 (MOV)", ext: "mov", audio: false },
    "prores-422-hq": { label: "ProRes 422 HQ (MOV)", ext: "mov", audio: false },
    "prores-4444": { label: "ProRes 4444, keeps transparency (MOV)", ext: "mov", audio: false },
    gif: { label: "Animated GIF", ext: "gif", audio: false },
    m4a: { label: "Audio only, AAC (.m4a)", ext: "m4a", audio: true },
    wav: { label: "Audio only, WAV", ext: "wav", audio: true },
  };

/** The format actually written: the podcast preset with no explicit choice is M4A. */
export function effectiveFormat(preset: ExportPreset, format?: ExportFormat): ExportFormat {
  const f = format ?? "mp4";
  return preset === "podcast-audio" && f === "mp4" ? "m4a" : f;
}

/** Formats that can carry a transparent scene background (HAS_ALPHA in export.rs). */
export const ALPHA_FORMATS: readonly ExportFormat[] = ["prores-4444"];

/**
 * Warning when a transparent background is exported to a format that cannot
 * hold it (it is flattened onto black), else null.
 */
export function transparencyWarning(project: Project, format: ExportFormat): string | null {
  if (EXPORT_FORMATS[format].audio || ALPHA_FORMATS.includes(format)) return null;
  if (!sceneTransparent(sanitizeScene(project.scene)) || Object.keys(project.media).length === 0)
    return null;
  return `The scene background is transparent, but ${EXPORT_FORMATS[format].label.split(" (")[0]} cannot store transparency. It will be exported on a black background. Choose ProRes 4444 to keep it.`;
}

/** Longest GIF the exporter writes (GIF_MAX_SECONDS in export.rs). */
export const GIF_MAX_SECONDS = 60;

/**
 * Range / length problems the backend would reject, as a message for the
 * user, or null when the request is fine. Mirrors `validate` in export.rs so
 * the UI and agents fail before a save dialog or a background job.
 */
export function exportRequestProblem(project: Project, s: ExportUiSettings): string | null {
  const total = totalDuration(project);
  const { rangeStart: start, rangeEnd: end } = s;
  for (const v of [start, end])
    if (v !== undefined && (!Number.isFinite(v) || v < 0))
      return "Range times must be zero or more seconds.";
  if (start !== undefined && start >= total)
    return `Range start must be before the end of the edit (${total.toFixed(1)} s).`;
  if (end !== undefined && end <= (start ?? 0)) return "Range end must be after its start.";
  if (end !== undefined && end > total + 1e-6)
    return `Range end is past the end of the edit (${total.toFixed(1)} s).`;
  const length = (end ?? total) - (start ?? 0);
  const format = effectiveFormat(project.settings.exportPreset, s.format);
  if (format === "gif" && length > GIF_MAX_SECONDS + 1e-6)
    return `GIF export is limited to ${GIF_MAX_SECONDS} s; set a range (${length.toFixed(1)} s now).`;
  return null;
}

export function buildExportOptions(
  project: Project,
  s: ExportUiSettings,
  outputPath: string,
): ExportOptions {
  const resolution = s.resolution;
  const dims: { width?: number; height?: number } =
    resolution === "original"
      ? {}
      : resolution === "720p"
        ? { width: 1280, height: 720 }
        : resolution === "1080p"
          ? { width: 1920, height: 1080 }
          : resolution === "4k"
            ? { width: 3840, height: 2160 }
            : {
                width: Math.max(16, s.customWidth),
                height: Math.max(16, s.customHeight),
              };

  // The frame around the video, resolved to pixels so the exporter draws exactly
  // what the preview shows. A disabled scene exports as plain video.
  const sceneSettings = sanitizeScene(project.scene);
  const firstMedia = sceneSourceMedia(project);
  const scene =
    sceneActive(sceneSettings) && firstMedia
      ? resolveSceneForExport(
          sceneSettings,
          { w: firstMedia.width, h: firstMedia.height },
          dims.width !== undefined && dims.height !== undefined
            ? { w: dims.width, h: dims.height }
            : undefined,
        )
      : undefined;

  // Zoom regions, validated against the edited timeline's length.
  const zoomRegions = sanitizeZoomRegions(project.zoomRegions, totalDuration(project));

  const format = effectiveFormat(project.settings.exportPreset, s.format);
  const captionStyle = sanitizeCaptionStyle(project.captions);
  const captionCues =
    s.burnCaptions && !EXPORT_FORMATS[format].audio
      ? toExportCues(
          s.stripCaptionEmoji
            ? stripEmoji(layoutProjectCaptions(project, captionStyle).cues)
            : layoutProjectCaptions(project, captionStyle).cues,
        )
      : [];
  const hasRange = s.rangeStart !== undefined || s.rangeEnd !== undefined;

  return {
    project,
    outputPath,
    preset: project.settings.exportPreset,
    ...dims,
    // "auto" means: don't specify a codec, so the smart-cut path can stream-copy
    // the source. Explicit h264/hevc disables smart-cut.
    codec: s.codec === "auto" ? undefined : s.codec,
    fps: s.fps ? Number(s.fps) : undefined,
    videoBitrateKbps: s.videoBitrateKbps,
    audioBitrateKbps: s.audioBitrateKbps,
    forceReencode: s.forceReencode,
    scene,
    zoomRegions: zoomRegions.length > 0 ? zoomRegions : undefined,
    drawCursor: project.cursor?.style.show ?? false,
    ...(captionCues.length > 0 ? { captions: { style: captionStyle, cues: captionCues } } : {}),
    // Only sent when they differ from the default so plain MP4 requests are unchanged.
    ...(format !== "mp4" ? { format } : {}),
    ...(hasRange
      ? { range: { start: s.rangeStart ?? 0, end: s.rangeEnd ?? totalDuration(project) } }
      : {}),
    ...(s.stems && EXPORT_FORMATS[format].audio ? { stems: true } : {}),
    ...(s.loudnessLufs !== undefined && format !== "gif" ? { loudnessLufs: s.loudnessLufs } : {}),
  };
}

/** Toast text for the post-export audio report; every level may be missing. */
export function describeAudioReport(
  a: ExportAudioReport | null | undefined,
): { clipped: boolean; text: string } | null {
  if (!a) return null;
  const n = (v: number | null | undefined, unit: string) =>
    typeof v === "number" && Number.isFinite(v) ? `${v.toFixed(1)} ${unit}` : null;
  const parts = [
    n(a.integratedLufs, "LUFS"),
    n(a.truePeakDbtp, "dBTP true peak"),
    n(a.samplePeakDb, "dB peak"),
  ].filter((p): p is string => p !== null);
  return { clipped: !!a.clipped, text: parts.length ? parts.join(", ") : "silent" };
}

/** What the Export dialog should warn about before burning captions in. */
export function captionBurnNotes(project: Project) {
  const { cues, warnings } = layoutProjectCaptions(project, sanitizeCaptionStyle(project.captions));
  const count = (kind: string) => warnings.filter((w) => w.kind === kind).length;
  return {
    noTranscript: cues.length === 0,
    emojiCues: count("emoji"),
    glyphCues: count("glyph"),
    invisibleCues: count("invisible"),
  };
}
