/**
 * Recording hand-off: what may change on a recording's media entry AFTER it was
 * inserted, without an undo step and without breaking the background attaches
 * (transcript, cursor) that identify the entry by object identity.
 *
 * Two late facts exist (docs/architecture.md, "Recording hand-off"):
 *   1. its SHA-256, computed after the take is already playable;
 *   2. for screen + camera takes, the camera composite that replaces the
 *      screen-only file once a background job has produced it.
 *
 * Both rewrite the entry in the present AND every undo / redo state, mapping
 * one old object to ONE new object, so states that shared the entry still
 * share it (the identity checks in `attachTranscript` / `attachCursorTrack`
 * keep working through undo). Every write is guarded by project id, media id
 * and the path the fact was computed for: a relinked, replaced or removed
 * entry, or another project, is never touched.
 */

import type { Project, SourceMedia } from "@/lib/edl";
import { hasChecksum, isChecksum } from "@/lib/checksum";
import { useProjectStore } from "@/stores/projectStore";

type HistoryState = Partial<{ project: Project }>;

/**
 * Rewrite media `mediaId` wherever `match` accepts it (present, past and
 * future states of project `projectId`). Not an undo step. Returns true when
 * at least one state changed.
 */
function rewriteMedia(
  projectId: string,
  mediaId: string,
  match: (m: SourceMedia) => boolean,
  patch: (m: SourceMedia) => SourceMedia,
  markDirty: boolean,
): boolean {
  const store = useProjectStore;
  const current = store.getState().project;
  if (current.id !== projectId) return false;
  const media = new Map<SourceMedia, SourceMedia>();
  const projects = new Map<Project, Project>();
  let changed = false;
  const rewrite = (p: Project): Project => {
    if (p.id !== projectId) return p;
    const seen = projects.get(p);
    if (seen) return seen;
    const m = p.media[mediaId];
    let out = p;
    if (m && match(m)) {
      let next = media.get(m);
      if (!next) {
        next = patch(m);
        media.set(m, next);
      }
      out = { ...p, media: { ...p.media, [mediaId]: next } };
      changed = true;
    }
    projects.set(p, out);
    return out;
  };
  const history = store.temporal.getState();
  const wasTracking = history.isTracking;
  history.pause();
  try {
    const next = rewrite(current);
    if (next !== current) store.setState({ project: next, ...(markDirty ? { dirty: true } : {}) });
    const rebase = (state: HistoryState): HistoryState => {
      if (!state.project) return state;
      const p = rewrite(state.project);
      return p === state.project ? state : { ...state, project: p };
    };
    store.temporal.setState({
      pastStates: history.pastStates.map(rebase),
      futureStates: history.futureStates.map(rebase),
    });
  } finally {
    if (wasTracking) history.resume();
  }
  return changed;
}

/**
 * Attach a checksum computed after insertion. Only to the entry that still
 * points at `path` and still has none; never marks the project unsaved (it
 * persists with the next real save, like `backfillChecksums`).
 */
export function attachDeferredChecksum(
  projectId: string,
  mediaId: string,
  path: string,
  sha256: string,
): boolean {
  if (!isChecksum(sha256)) return false;
  return rewriteMedia(
    projectId,
    mediaId,
    (m) => m.path === path && !hasChecksum(m),
    (m) => ({ ...m, sha256 }),
    false,
  );
}

/** Seconds the composite may differ from the clip it replaces (about 2 frames at 30 fps). */
export const COMPOSITE_DURATION_TOLERANCE = 0.07;

type Facts = Pick<SourceMedia, "duration" | "width" | "height" | "audioSampleRate">;

/**
 * Can `composite` replace `clip` without moving an edit or changing what is
 * heard? Same picture size, same sound (present or not) and the same container
 * length. The VIDEO-stream length (the container is the longest stream) is
 * checked in Rust (`composite_lines_up`) before the path is returned. Returns
 * the reason when it cannot.
 */
export function compositeMismatch(clip: Facts, composite: Facts): string | null {
  if (composite.width !== clip.width || composite.height !== clip.height)
    return `picture size ${composite.width}x${composite.height} differs from ${clip.width}x${clip.height}`;
  if (composite.audioSampleRate > 0 !== clip.audioSampleRate > 0)
    return "one version has sound and the other has none";
  if (
    !Number.isFinite(composite.duration) ||
    Math.abs(composite.duration - clip.duration) > COMPOSITE_DURATION_TOLERANCE
  )
    return `length ${composite.duration.toFixed(2)} s differs from ${clip.duration.toFixed(2)} s`;
  return null;
}

/**
 * Does any OTHER media entry (present or undo / redo) use `path`, or the same
 * recorded checksum as `mediaId`? Then the file is shared: masks and other
 * clips identify it by path / checksum, so the recording entry must not move
 * to a different file on its own.
 */
export function sharesFile(projectId: string, mediaId: string, path: string): boolean {
  const store = useProjectStore;
  const present = store.getState().project;
  if (present.id !== projectId) return false;
  const own = present.media[mediaId]?.sha256 ?? "";
  const history = store.temporal.getState();
  const states = [
    present,
    ...history.pastStates.map((s) => s.project),
    ...history.futureStates.map((s) => s.project),
  ];
  return states.some(
    (p) =>
      p?.id === projectId &&
      Object.values(p.media).some(
        (m) => m.id !== mediaId && (m.path === path || (!!own && m.sha256 === own)),
      ),
  );
}

/**
 * Point a screen + camera recording at its camera composite. Only the entry
 * still at `fromPath` with a compatible size, sound and length changes; its
 * checksum is cleared (a different file) and computed again by the caller,
 * fps and sample rate come from the composite, and its `pendingCamera` marker
 * is removed. Marks the project unsaved: the saved file must reference the
 * composite.
 */
export function swapToComposite(
  projectId: string,
  mediaId: string,
  fromPath: string,
  composite: Pick<
    SourceMedia,
    "path" | "duration" | "width" | "height" | "fps" | "audioSampleRate"
  >,
): boolean {
  if (!composite.path || composite.path === fromPath) return false;
  // The PRESENT entry must accept it. If only undo / redo states hold the
  // entry (its insertion was undone), nothing is swapped: the caller keeps the
  // marker and the user is not told the camera was added.
  const present = useProjectStore.getState().project;
  const now = present.id === projectId ? present.media[mediaId] : undefined;
  if (!now || now.path !== fromPath || compositeMismatch(now, composite) !== null) return false;
  lineage(mediaId).add(composite.path);
  return rewriteMedia(
    projectId,
    mediaId,
    (m) => m.path === fromPath && compositeMismatch(m, composite) === null,
    (m) => {
      return {
        ...withoutPendingCamera(m),
        path: composite.path,
        sha256: "",
        fps: composite.fps > 0 ? composite.fps : m.fps,
        audioSampleRate: composite.audioSampleRate,
      };
    },
    true,
  );
}

/**
 * Give up on a pending camera composite: drop the marker from the entry still
 * at `path` (everywhere in history). Marks the project unsaved so the saved
 * file stops asking for it.
 */
export function clearPendingCamera(projectId: string, mediaId: string, path?: string): boolean {
  return rewriteMedia(
    projectId,
    mediaId,
    (m) => (path === undefined || m.path === path) && !!m.pendingCamera,
    withoutPendingCamera,
    true,
  );
}

/** Prefix of a DEFINITE composite refusal (Rust `COMPOSITE_REFUSED`); anything else is transient. */
export const COMPOSITE_REFUSED = "camera composite refused: ";

export function isCompositeRefusal(error: unknown): boolean {
  const text = error instanceof Error ? error.message : String(error);
  return text.includes(COMPOSITE_REFUSED);
}

/**
 * Every file path project `projectId` references (media and overlays, present
 * and undo / redo). A leftover composite in this list is never deleted.
 */
export function referencedPaths(projectId: string): string[] {
  const store = useProjectStore;
  const history = store.temporal.getState();
  const paths = new Set<string>();
  for (const p of [
    store.getState().project,
    ...history.pastStates.map((s) => s.project),
    ...history.futureStates.map((s) => s.project),
  ]) {
    if (p?.id !== projectId) continue;
    for (const m of Object.values(p.media)) if (m.path) paths.add(m.path);
    for (const o of p.overlays ?? []) if (o.path) paths.add(o.path);
  }
  return [...paths];
}

/** A copy of `m` without its `pendingCamera` key (absent, not `undefined`). */
function withoutPendingCamera(m: SourceMedia): SourceMedia {
  const copy = { ...m };
  delete copy.pendingCamera;
  return copy;
}

/** Paths a recording's media entry may legitimately have had (screen file, composite). */
const lineages = new Map<string, Set<string>>();
function lineage(mediaId: string): Set<string> {
  let paths = lineages.get(mediaId);
  if (!paths) {
    if (lineages.size > 64) lineages.delete(lineages.keys().next().value as string);
    paths = new Set();
    lineages.set(mediaId, paths);
  }
  return paths;
}

/**
 * The object the project holds TODAY for a recording inserted as `media`: the
 * same entry after a late checksum or composite swap, found in the present or
 * any undo / redo state. Falls back to `media` itself (the attach then finds
 * nothing to change, exactly as before). Never returns an entry that was
 * relinked to an unrelated file.
 */
export function resolveRecordingSource(projectId: string, media: SourceMedia): SourceMedia {
  const store = useProjectStore;
  const present = store.getState().project;
  if (present.id !== projectId) return media;
  const known = lineages.get(media.id);
  const ok = (m: SourceMedia | undefined): m is SourceMedia =>
    !!m &&
    (m === media ||
      ((m.path === media.path || !!known?.has(m.path)) &&
        Math.abs(m.duration - media.duration) <= COMPOSITE_DURATION_TOLERANCE));
  const history = store.temporal.getState();
  const states: Array<Project | undefined> = [
    present,
    ...history.futureStates.map((s) => s.project),
    ...[...history.pastStates].reverse().map((s) => s.project),
  ];
  for (const p of states) {
    if (p?.id !== projectId) continue;
    const m = p.media[media.id];
    if (ok(m)) return m;
  }
  return media;
}

/** Test hook. */
export function resetRecordingHandoff() {
  lineages.clear();
}
