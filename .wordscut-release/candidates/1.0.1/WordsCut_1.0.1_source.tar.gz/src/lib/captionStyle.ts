/**
 * Caption style: how burned-in and previewed captions look. Persisted as the
 * optional `Project.captions`; absent on old projects (defaults apply, nothing
 * changes for them). Pure module, mirrored by `captions_export.rs`.
 */

/** Fonts that ship with macOS, so the preview and libass resolve the same face. */
export const CAPTION_FONTS = [
  "Helvetica Neue",
  "Arial",
  "Verdana",
  "Trebuchet MS",
  "Georgia",
  "Menlo",
] as const;
export const CAPTION_POSITIONS = ["top", "middle", "bottom"] as const;
export const CAPTION_WEIGHTS = ["regular", "bold"] as const;

export interface CaptionStyle {
  font: (typeof CAPTION_FONTS)[number];
  /** Pixels on a 1080-line frame; scales with the frame. */
  size: number;
  weight: (typeof CAPTION_WEIGHTS)[number];
  color: string;
  /** Colour the word being spoken (karaoke style). */
  highlight: boolean;
  highlightColor: string;
  /** Outline width in 1080-line pixels; 0 = none. Ignored while the box is on. */
  outline: number;
  outlineColor: string;
  /** Drop shadow distance in 1080-line pixels; 0 = none. */
  shadow: number;
  /** Opaque box behind the text; replaces the outline. */
  box: boolean;
  boxColor: string;
  boxOpacity: number;
  position: (typeof CAPTION_POSITIONS)[number];
  maxCharsPerLine: number;
  maxLines: number;
}

export const DEFAULT_CAPTION_STYLE: CaptionStyle = {
  font: "Helvetica Neue",
  size: 48,
  weight: "bold",
  color: "#ffffff",
  highlight: false,
  highlightColor: "#ffd60a",
  outline: 3,
  outlineColor: "#000000",
  shadow: 0,
  box: true,
  boxColor: "#000000",
  boxOpacity: 0.7,
  position: "bottom",
  maxCharsPerLine: 32,
  maxLines: 2,
};

const hex = (v: unknown, d: string) =>
  typeof v === "string" && /^#[0-9a-f]{6}$/i.test(v) ? v.toLowerCase() : d;
const num = (v: unknown, d: number, min: number, max: number, int = false) => {
  if (typeof v !== "number" || !Number.isFinite(v)) return d;
  const c = Math.max(min, Math.min(max, v));
  return int ? Math.round(c) : c;
};
const pick = <T extends string>(list: readonly T[], v: unknown, d: T): T =>
  list.includes(v as T) ? (v as T) : d;

/** Every field falls back to the default when missing or invalid; never throws. */
export function sanitizeCaptionStyle(raw: unknown): CaptionStyle {
  const r = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;
  const d = DEFAULT_CAPTION_STYLE;
  return {
    font: pick(CAPTION_FONTS, r.font, d.font),
    size: num(r.size, d.size, 16, 140),
    weight: pick(CAPTION_WEIGHTS, r.weight, d.weight),
    color: hex(r.color, d.color),
    highlight: typeof r.highlight === "boolean" ? r.highlight : d.highlight,
    highlightColor: hex(r.highlightColor, d.highlightColor),
    outline: num(r.outline, d.outline, 0, 12),
    outlineColor: hex(r.outlineColor, d.outlineColor),
    shadow: num(r.shadow, d.shadow, 0, 12),
    box: typeof r.box === "boolean" ? r.box : d.box,
    boxColor: hex(r.boxColor, d.boxColor),
    boxOpacity: num(r.boxOpacity, d.boxOpacity, 0, 1),
    position: pick(CAPTION_POSITIONS, r.position, d.position),
    maxCharsPerLine: num(r.maxCharsPerLine, d.maxCharsPerLine, 10, 60, true),
    maxLines: num(r.maxLines, d.maxLines, 1, 3, true),
  };
}
