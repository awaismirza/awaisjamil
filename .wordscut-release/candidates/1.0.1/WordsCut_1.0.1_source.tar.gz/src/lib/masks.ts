/**
 * Privacy masks, SOURCE-ANCHORED. Pure module (no React / Tauri / store).
 *
 * A mask hides a region of one source file over a span of that file's own
 * time: `{ mediaId, srcStart, srcEnd, region }`. Where it shows on the output
 * timeline is never stored: it is derived from the timeline at every use
 * (preview, export, coverage check), so EVERY occurrence of that source
 * content is masked — duplicated clips, restored words, moved clips, the same
 * source range used twice, speed and freeze-frame changes. Nothing is retimed,
 * so an edit can never leave a sliver uncovered.
 *
 * The region is normalised to that source's own picture (before scaling,
 * zoom, scene and crop). A mask is a static region: it does not follow content
 * that moves inside the recording.
 *
 * `src-tauri/src/layers_export.rs` re-validates with the same rules (shared
 * fixture `tests/fixtures/layersSanitize.json`) and applies masks per clip,
 * on the source frames, before any transition, freeze frame or overlay.
 */
import { computeTimeline, type Project, type SourceMedia, type TimelineEntry } from "./edl";
import { entryOutputAt, entryPlayEnd, entrySourceAt } from "./timeMap";

export const MASK_EFFECTS = ["blur", "pixelate", "solid", "dim"] as const;
export type MaskEffect = (typeof MASK_EFFECTS)[number];
export type MaskShape = "rect" | "ellipse";

export interface PrivacyMask {
  id: string;
  /** The source file whose picture is masked. */
  mediaId: string;
  /** Source-file seconds. */
  srcStart: number;
  srcEnd: number;
  /** Normalised to that source's picture. */
  x: number;
  y: number;
  w: number;
  h: number;
  shape: MaskShape;
  effect: MaskEffect;
  /**
   * blur: Gaussian sigma and pixelate: block size, both pixels at 1080 lines
   * of the source; dim: how much the surround is darkened, percent; solid: 0.
   */
  strength: number;
  /** solid: fill colour, `#rrggbb`. */
  color: string;
}

export const MAX_MASKS = 200;
/** Smallest width / height (fraction of the source picture) a mask may have. */
export const MIN_MASK_SIZE = 0.01;
/** Shortest source span a mask may have. */
export const MIN_MASK_SRC_SEC = 0.001;
/** A derived on-screen span is never shorter than one frame at 30 fps: extended, never dropped. */
export const MIN_SPAN_SEC = 1 / 30;
export const DEFAULT_MASK_SEC = 3;
/** [min, max, default] strength per effect. Floors keep text unreadable at 1080p. */
export const MASK_STRENGTH: Record<MaskEffect, readonly [number, number, number]> = {
  blur: [12, 100, 30],
  pixelate: [16, 200, 32],
  solid: [0, 0, 0],
  dim: [10, 95, 65],
};
/** Below these, small text may still be readable: the panel warns in red. */
export const SAFE_FOR_TEXT: Partial<Record<MaskEffect, number>> = { blur: 30, pixelate: 24 };
/** Export floors in output pixels (also in layers_export.rs): a small source cannot weaken a mask. */
export const MIN_BLUR_PX = 6;
export const MIN_BLOCK_PX = 8;
export const MASK_EFFECT_LABEL: Record<MaskEffect, string> = {
  blur: "Blur",
  pixelate: "Pixelate",
  solid: "Solid fill",
  dim: "Dim surroundings",
};

const clamp = (n: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, n));
const num = (v: unknown, fallback: number) =>
  typeof v === "number" && Number.isFinite(v) ? v : fallback;
const fin = (v: unknown): v is number => typeof v === "number" && Number.isFinite(v);

let counter = 0;
export function newMaskId(): string {
  counter += 1;
  return `mk-${Date.now().toString(36)}-${counter.toString(36)}-${Math.random().toString(36).slice(2, 6)}`;
}

/** One stored value -> a valid mask, or null. Mirrors `sanitize_mask` in layers_export.rs. */
export function sanitizeMask(raw: unknown): PrivacyMask | null {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return null;
  const r = raw as Record<string, unknown>;
  if (typeof r.mediaId !== "string" || r.mediaId.length === 0 || r.mediaId.length > 200)
    return null;
  if (!fin(r.srcStart) || !fin(r.srcEnd)) return null;
  const srcStart = Math.max(0, r.srcStart);
  const srcEnd = r.srcEnd;
  // Epsilon: a 1 ms span computed as 0.000999… must not be dropped (here or in Rust).
  if (!(srcEnd - srcStart >= MIN_MASK_SRC_SEC - 1e-9)) return null;
  const x = clamp(num(r.x, 0.35), 0, 1);
  const y = clamp(num(r.y, 0.35), 0, 1);
  // A stored size under 1 % is refused, never silently grown into a 1 % box.
  const w = num(r.w, 0.3);
  const h = num(r.h, 0.2);
  if (w < MIN_MASK_SIZE || h < MIN_MASK_SIZE) return null;
  const effect: MaskEffect = MASK_EFFECTS.includes(r.effect as MaskEffect)
    ? (r.effect as MaskEffect)
    : "solid";
  const [lo, hi, dflt] = MASK_STRENGTH[effect];
  return {
    id: typeof r.id === "string" && r.id.length > 0 ? r.id : newMaskId(),
    mediaId: r.mediaId,
    srcStart,
    srcEnd,
    x,
    y,
    w: clamp(w, MIN_MASK_SIZE, Math.max(MIN_MASK_SIZE, 1 - x)),
    h: clamp(h, MIN_MASK_SIZE, Math.max(MIN_MASK_SIZE, 1 - y)),
    shape: r.shape === "ellipse" ? "ellipse" : "rect",
    effect,
    strength: clamp(num(r.strength, dflt), lo, hi),
    color:
      typeof r.color === "string" && /^#[0-9a-fA-F]{6}$/.test(r.color)
        ? r.color.toLowerCase()
        : "#000000",
  };
}

/** Valid masks in stored order (at most MAX_MASKS), sorted by source then start. */
export function sanitizeMasks(raw: unknown): PrivacyMask[] {
  if (!Array.isArray(raw)) return [];
  const seen = new Set<string>();
  const out: PrivacyMask[] = [];
  for (const item of raw) {
    if (out.length >= MAX_MASKS) break;
    const m = sanitizeMask(item);
    if (!m) continue;
    if (seen.has(m.id)) m.id = newMaskId();
    seen.add(m.id);
    out.push(m);
  }
  return out.sort(
    (a, b) =>
      (a.mediaId < b.mediaId ? -1 : a.mediaId > b.mediaId ? 1 : 0) ||
      a.srcStart - b.srcStart ||
      a.srcEnd - b.srcEnd,
  );
}

/** A stored mask from the output-time builds (4.43.0 before source anchoring). */
const isLegacy = (r: unknown): r is Record<string, unknown> =>
  !!r &&
  typeof r === "object" &&
  !("mediaId" in (r as object)) &&
  fin((r as Record<string, unknown>).start) &&
  fin((r as Record<string, unknown>).end);

/**
 * Masks of a loaded project, converting old output-time masks to source
 * anchoring through the project's current timeline: each clip a legacy span
 * touches becomes one source mask (a freeze frame masks the last 0.05 s of
 * its clip). `dropped`: legacy masks that touch no content (they hid nothing).
 * Mirrors `source_masks` in layers_export.rs.
 */
export function migrateMasks(project: Pick<Project, "masks" | "segments" | "media">): {
  masks: PrivacyMask[];
  converted: number;
  dropped: number;
} {
  const raw: unknown[] = Array.isArray(project.masks) ? (project.masks as unknown[]) : [];
  let converted = 0;
  let dropped = 0;
  const tl = computeTimeline(project as Project);
  const out: unknown[] = [];
  for (const r of raw) {
    if (!isLegacy(r)) {
      out.push(r);
      continue;
    }
    const pieces = legacyPieces(tl, r.start as number, r.end as number);
    if (pieces.length === 0) dropped += 1;
    else converted += 1;
    pieces.forEach((p, i) => {
      const piece: Record<string, unknown> = { ...r, ...p, id: i === 0 ? r.id : newMaskId() };
      delete piece.start;
      delete piece.end;
      out.push(piece);
    });
  }
  return { masks: sanitizeMasks(out), converted, dropped };
}

function legacyPieces(tl: readonly TimelineEntry[], start: number, end: number) {
  const pieces: Array<{ mediaId: string; srcStart: number; srcEnd: number }> = [];
  for (const e of tl) {
    const lo = Math.max(start, e.outputStart);
    const hi = Math.min(end, e.outputEnd);
    if (hi <= lo) continue;
    const playEnd = entryPlayEnd(e);
    if (lo < playEnd) {
      const s = entrySourceAt(e, lo);
      const t = entrySourceAt(e, Math.min(hi, playEnd));
      pieces.push({ mediaId: e.mediaId, srcStart: s, srcEnd: Math.max(t, s + MIN_MASK_SRC_SEC) });
    }
    if (hi > playEnd)
      pieces.push({
        mediaId: e.mediaId,
        srcStart: Math.max(0, e.sourceOut - 0.05),
        srcEnd: e.sourceOut,
      });
  }
  return pieces;
}

type MediaMap = Readonly<Record<string, Pick<SourceMedia, "path" | "sha256"> | undefined>>;

/**
 * Are two media the same content? Yes when both checksums are known and equal,
 * OR when the paths are equal: at export time one path is one set of bytes,
 * even when a stored checksum is stale (a recording overwritten in place and
 * imported again). Erring towards "same" can only mask more, never less. The
 * same file imported twice gets two media ids, so a mask covers both. Mirrors
 * `same_file` in layers_export.rs (shared fixture `contentPairs`).
 */
export function sameFile(
  a: { path?: string; sha256?: string } | undefined,
  b: { path?: string; sha256?: string } | undefined,
): boolean {
  if (!a || !b) return false;
  if (a.sha256 && b.sha256 && a.sha256 === b.sha256) return true;
  return !!a.path && a.path === b.path;
}

/** Does media `id` show the same content as the mask's source? */
export function sameContent(media: MediaMap, maskMedia: string, id: string): boolean {
  return id === maskMedia || sameFile(media[maskMedia], media[id]);
}

/** Other media items that are the same file as `mediaId` (by checksum or path). */
export function duplicateSources(media: MediaMap, mediaId: string): string[] {
  return Object.keys(media).filter((id) => id !== mediaId && sameContent(media, mediaId, id));
}

/** Freeze frames show the frame at `sourceOut`: masked when the mask reaches this close to it. */
const HOLD_TOLERANCE = 0.05;

/**
 * Every span of the output timeline where `m`'s source content is on screen:
 * each clip of that source playing any of [srcStart, srcEnd], at its speed,
 * plus a freeze frame of a masked last frame. Each span is at least
 * MIN_SPAN_SEC long (extended, never dropped); overlapping spans merge.
 * Mirrors `mask_output_spans` in layers_export.rs.
 */
export function maskOutputSpans(
  timeline: readonly TimelineEntry[],
  m: Pick<PrivacyMask, "mediaId" | "srcStart" | "srcEnd">,
  media: MediaMap,
): Array<[number, number]> {
  const spans: Array<[number, number]> = [];
  for (const e of timeline) {
    if (!sameContent(media, m.mediaId, e.mediaId)) continue;
    const s = Math.max(m.srcStart, e.sourceIn);
    const t = Math.min(m.srcEnd, e.sourceOut);
    if (t > s) spans.push([entryOutputAt(e, s), entryOutputAt(e, t)]);
    const playEnd = entryPlayEnd(e);
    if (e.holdSec && m.srcStart <= e.sourceOut && m.srcEnd >= e.sourceOut - HOLD_TOLERANCE)
      spans.push([playEnd, e.outputEnd]);
  }
  spans.sort((a, b) => a[0] - b[0]);
  const merged: Array<[number, number]> = [];
  for (const [a, b] of spans) {
    const span: [number, number] = [a, Math.max(b, a + MIN_SPAN_SEC)];
    const last = merged[merged.length - 1];
    if (last && span[0] <= last[1] + 1e-9) last[1] = Math.max(last[1], span[1]);
    else merged.push(span);
  }
  return merged;
}

export const projectMaskSpans = (project: Project, m: PrivacyMask) =>
  maskOutputSpans(computeTimeline(project), m, project.media);

export const spansContain = (spans: ReadonlyArray<[number, number]>, t: number) =>
  spans.some(([a, b]) => t >= a && t < b);

/** Is source time `t` of `mediaId` inside any mask (one frame of margin)? */
export function sourceMasked(
  masks: readonly PrivacyMask[],
  media: MediaMap,
  mediaId: string,
  t: number,
  margin = 1 / 30,
): boolean {
  return masks.some(
    (m) =>
      sameContent(media, m.mediaId, mediaId) && t >= m.srcStart - margin && t <= m.srcEnd + margin,
  );
}

/** Every place is sampled up to this many; above it, the first 6 (`coverage_places` in export.rs). */
export const coveragePlaces = (n: number) => (n <= 12 ? n : 6);

/**
 * Masks whose source file is the same file as an overlay (path or checksum):
 * the export applies them to that overlay too; the preview does not.
 */
export function masksOnOverlayFile(
  project: Pick<Project, "masks" | "media">,
  overlay: { path: string; sha256?: string },
): PrivacyMask[] {
  return sanitizeMasks(project.masks).filter((m) => {
    const src = project.media[m.mediaId];
    return sameFile(src, overlay);
  });
}

/** Masks narrower or lower than this (fraction of the source) hide almost nothing: the panel warns. */
export const SMALL_MASK = 0.03;

function entryAt(tl: readonly TimelineEntry[], t: number, end = false) {
  return (
    tl.find((e) =>
      end ? t > e.outputStart && t <= e.outputEnd : t >= e.outputStart && t < e.outputEnd,
    ) ?? (tl.length && t >= tl[tl.length - 1]!.outputEnd ? tl[tl.length - 1] : undefined)
  );
}

/** Source time shown at output time `t` if it plays `mediaId` (else null). */
export function sourceTimeAt(
  project: Project,
  mediaId: string,
  t: number,
  end = false,
): number | null {
  const e = entryAt(computeTimeline(project), t, end);
  if (!e || e.mediaId !== mediaId) return null;
  return t >= entryPlayEnd(e) ? e.sourceOut : entrySourceAt(e, t);
}

/** A new solid mask over 3 s of whatever source plays at output time `at`. */
export function makeMask(project: Project, at: number): PrivacyMask | null {
  const e = entryAt(computeTimeline(project), at);
  if (!e) return null;
  const media = project.media[e.mediaId];
  const limit = media && media.duration > 0 ? media.duration : Infinity;
  let srcStart = at >= entryPlayEnd(e) ? e.sourceOut : entrySourceAt(e, at);
  const srcEnd = Math.min(limit, srcStart + DEFAULT_MASK_SEC * (e.speed ?? 1));
  if (srcEnd - srcStart < 0.1) srcStart = Math.max(0, srcEnd - DEFAULT_MASK_SEC);
  return sanitizeMask({ mediaId: e.mediaId, srcStart, srcEnd, effect: "solid" });
}

/** Does a cursor-following zoom overlap any of the mask's on-screen spans? */
export function maskFollowZoomOverlap(
  spans: ReadonlyArray<[number, number]>,
  zoomRegions: ReadonlyArray<{ start: number; end: number; follow?: boolean }>,
): boolean {
  return zoomRegions.some((z) => z.follow && spans.some(([a, b]) => z.start < b && z.end > a));
}
