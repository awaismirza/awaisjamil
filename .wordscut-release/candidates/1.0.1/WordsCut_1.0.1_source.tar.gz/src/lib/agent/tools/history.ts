import { totalDuration } from "@/lib/edl";
import { ToolError, objectSchema, round3, type ActionTool } from "../toolTypes";

export const history: ActionTool<{ action: "undo" | "redo"; steps: number }> = {
  name: "history",
  title: "Undo / redo",
  description:
    "Undoes or redoes edits (applies immediately, no confirm). Each agent apply is one step. Returns how many steps were done.",
  kind: "action",
  mutates: true,
  inputSchema: objectSchema(
    {
      action: { type: "string", enum: ["undo", "redo"] },
      steps: { type: "integer", minimum: 1, maximum: 50, default: 1 },
    },
    ["action"],
  ),
  async run(input, ctx) {
    const busy = ctx.busyReason();
    if (busy) throw new ToolError("BUSY", `Editor is busy: ${busy}`);
    const done = input.action === "undo" ? ctx.undo(input.steps) : ctx.redo(input.steps);
    return {
      done,
      revision: ctx.revision(),
      durationSec: round3(totalDuration(ctx.getProject())),
    };
  },
};
