import { totalDuration } from "@/lib/edl";
import {
  buildExportOptions,
  EXPORT_FORMATS,
  effectiveFormat,
  exportRequestProblem,
  type ExportFormat,
  type ExportUiSettings,
} from "@/lib/exportOptions";
import { ToolError, objectSchema, round3, type ActionTool } from "../toolTypes";
import { checkOutputPath, extOf } from "./pathChecks";

interface ExportStartInput {
  confirm?: boolean;
  outputPath: string;
  resolution: "original" | "720p" | "1080p" | "4k";
  codec: "auto" | "h264" | "hevc";
  fps?: number;
  overwrite: boolean;
  format?: ExportFormat;
  rangeStart?: number;
  rangeEnd?: number;
  stems?: boolean;
}

export const exportStart: ActionTool<ExportStartInput> = {
  name: "export_start",
  title: "Export video",
  description:
    "With confirm:false returns the resolved export options (plan). With confirm:true starts the export in the background and returns immediately; poll export_status. Ignores baseRevision.",
  kind: "action",
  mutates: true,
  inputSchema: objectSchema(
    {
      confirm: { type: "boolean", default: false },
      baseRevision: { type: "integer", minimum: 0, description: "Accepted but ignored." },
      outputPath: {
        type: "string",
        minLength: 1,
        maxLength: 4096,
        description:
          "Absolute output path; its extension must match the format (.mp4, .mov for mov/ProRes, .gif, .m4a, .wav).",
      },
      resolution: {
        type: "string",
        enum: ["original", "720p", "1080p", "4k"],
        default: "original",
      },
      codec: { type: "string", enum: ["auto", "h264", "hevc"], default: "auto" },
      fps: { type: "integer", enum: [24, 25, 30, 50, 60] },
      overwrite: { type: "boolean", default: false },
      format: {
        type: "string",
        enum: Object.keys(EXPORT_FORMATS),
        description:
          "Default: mp4 (m4a for the podcast-audio preset, mov when outputPath ends in .mov). ProRes 422 / 422 HQ are 10-bit 4:2:2 in MOV and prores-4444 is 4:4:4 with an alpha channel (it keeps a transparent Look background; every other video format flattens it to black); gif is silent, capped at 30 fps / 960 px wide and 60 s (use a range for longer edits); m4a and wav are audio only.",
      },
      rangeStart: {
        type: "number",
        minimum: 0,
        description: "Export only from this output-timeline second.",
      },
      rangeEnd: {
        type: "number",
        minimum: 0,
        description: "Export only up to this output-timeline second.",
      },
      stems: {
        type: "boolean",
        default: false,
        description:
          "m4a/wav only: also write <name>-voice-N and <name>-music-N files beside the mix. The export fails before starting if any of those files already exists.",
      },
    },
    ["outputPath"],
  ),
  async run(input, ctx) {
    const project = ctx.getProject();
    if (Object.keys(project.media).length === 0 || project.segments.length === 0)
      throw new ToolError("NO_MEDIA", "Nothing to export");
    if (ctx.exportStatus().running) throw new ToolError("BUSY", "An export is already running");
    const busy = ctx.busyReason();
    if (busy) throw new ToolError("BUSY", `Editor is busy: ${busy}`);
    const preset = project.settings.exportPreset;
    const format = effectiveFormat(
      preset,
      input.format ?? (extOf(input.outputPath) === ".mov" ? "mov" : undefined),
    );
    await checkOutputPath(
      ctx,
      input.outputPath,
      [`.${EXPORT_FORMATS[format].ext}`],
      input.overwrite,
    );
    if (input.stems && !EXPORT_FORMATS[format].audio)
      throw new ToolError("INVALID_INPUT", "stems need an audio format (m4a or wav)");
    const settings: ExportUiSettings = {
      resolution: input.resolution,
      customWidth: 0,
      customHeight: 0,
      codec: input.codec,
      ...(input.fps !== undefined ? { fps: input.fps } : {}),
      format,
      ...(input.rangeStart !== undefined ? { rangeStart: input.rangeStart } : {}),
      ...(input.rangeEnd !== undefined ? { rangeEnd: input.rangeEnd } : {}),
      ...(input.stems ? { stems: true } : {}),
    };
    const problem = exportRequestProblem(project, settings);
    if (problem) throw new ToolError("INVALID_INPUT", problem);

    const full = buildExportOptions(project, settings, input.outputPath);
    if (input.confirm === true) {
      ctx.startExport(full);
      return { started: true, outputPath: input.outputPath };
    }
    const { project: _project, ...options } = full;
    void _project;
    return {
      started: false,
      summary: `Export ${round3(totalDuration(project))}s to ${input.outputPath}`,
      options,
      next: "Call again with confirm:true to start the export, then poll export_status.",
    };
  },
};

export const exportStatus: ActionTool<Record<string, never>> = {
  name: "export_status",
  title: "Export status",
  description: "Read-only. Whether an export is running, its progress (0-1) and the last result.",
  kind: "query",
  mutates: false,
  inputSchema: objectSchema(),
  async run(_input, ctx) {
    const s = ctx.exportStatus();
    return { running: s.running, progress: s.progress, lastResult: s.lastResult };
  },
};

export const exportCancel: ActionTool<Record<string, never>> = {
  name: "export_cancel",
  title: "Cancel export",
  description: "Cancels the running export, if any.",
  kind: "action",
  mutates: true,
  inputSchema: objectSchema(),
  async run(_input, ctx) {
    if (!ctx.exportStatus().running) return { cancelled: false };
    await ctx.cancelExport();
    return { cancelled: true };
  },
};
