import { buildCues, buildSrt, buildVtt } from "@/lib/captions";
import { ToolError, objectSchema, type ActionTool } from "../toolTypes";
import { checkOutputPath } from "./pathChecks";

const MAX_INLINE_BYTES = 1024 * 1024;

export const captionsExport: ActionTool<{
  format: "srt" | "vtt";
  outputPath?: string;
  overwrite: boolean;
}> = {
  name: "captions_export",
  title: "Export captions",
  description:
    "Builds SRT or WebVTT captions from the current edit. With outputPath it writes the file; without it returns the text (truncated at 1 MiB).",
  kind: "action",
  mutates: false,
  inputSchema: objectSchema(
    {
      format: { type: "string", enum: ["srt", "vtt"] },
      outputPath: {
        type: "string",
        minLength: 1,
        maxLength: 4096,
        description: "Absolute .srt/.vtt path.",
      },
      overwrite: { type: "boolean", default: false },
    },
    ["format"],
  ),
  async run(input, ctx) {
    const project = ctx.getProject();
    if (!project.segments.some((s) => s.words.length > 0))
      throw new ToolError("NO_TRANSCRIPT", "The project has no transcript to build captions from");
    const content = input.format === "srt" ? buildSrt(project) : buildVtt(project);
    const cueCount = buildCues(project).length;
    if (!input.outputPath) {
      if (content.length > MAX_INLINE_BYTES)
        return { content: content.slice(0, MAX_INLINE_BYTES), truncated: true, cueCount };
      return { content, cueCount };
    }
    await checkOutputPath(ctx, input.outputPath, [`.${input.format}`], input.overwrite);
    await ctx.writeTextFile(input.outputPath, content, input.overwrite);
    return { outputPath: input.outputPath, cueCount };
  },
};
