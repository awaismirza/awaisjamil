import { computeTimeline, totalDuration, type Project } from "@/lib/edl";
import { generateAutoZoom } from "@/lib/autoZoom";
import { withZoom } from "@/lib/projectOps";
import {
  MIN_REGION_SEC,
  addZoomRegion,
  clearZoomRange,
  removeZoomRegion,
  sanitizeZoomRegions,
  type ZoomRegion,
} from "@/lib/zoom";
import type { JsonSchema } from "../protocol";
import { RANGE_SCHEMA, editSchema, round3, type EditInput, type EditTool } from "../toolTypes";

interface ZoomInput extends EditInput {
  add?: {
    start: number;
    end: number;
    scale: number;
    focusX: number;
    focusY: number;
    easeMs: number;
  }[];
  removeIds?: string[];
  clearRanges?: { start: number; end: number }[];
  auto?: { sensitivity?: "low" | "medium" | "high"; replace: boolean };
}

const ADD_ITEM: JsonSchema = {
  type: "object",
  additionalProperties: false,
  properties: {
    start: { type: "number", minimum: 0 },
    end: { type: "number", minimum: 0 },
    scale: { type: "number", minimum: 1.2, maximum: 4, default: 1.6 },
    focusX: { type: "number", minimum: 0, maximum: 1, default: 0.5 },
    focusY: { type: "number", minimum: 0, maximum: 1, default: 0.5 },
    easeMs: { type: "number", minimum: 0, maximum: 2000, default: 450 },
  },
  required: ["start", "end"],
};

const same = (a: ZoomRegion[], b: ZoomRegion[]) => JSON.stringify(a) === JSON.stringify(b);

export const zoomEdit: EditTool<ZoomInput> = {
  name: "zoom_edit",
  title: "Edit zoom regions",
  description:
    "Plans (confirm:false) or applies (confirm:true) zoom region changes on the output timeline. Order: auto, clearRanges, removeIds, add. Regions shorter than 0.5 s are rejected.",
  kind: "edit",
  inputSchema: editSchema({
    add: { type: "array", maxItems: 200, items: ADD_ITEM },
    removeIds: { type: "array", maxItems: 200, items: { type: "string", maxLength: 64 } },
    clearRanges: { type: "array", maxItems: 200, items: RANGE_SCHEMA },
    auto: {
      type: "object",
      additionalProperties: false,
      properties: {
        sensitivity: { type: "string", enum: ["low", "medium", "high"] },
        replace: { type: "boolean", default: false },
      },
      description: "Propose zooms from recorded cursor activity.",
    },
  }),
  compute(project: Project, input) {
    const total = totalDuration(project);
    const before = sanitizeZoomRegions(project.zoomRegions, total);
    let regions = before;
    const details: Record<string, unknown> = {};
    const parts: string[] = [];

    if (input.auto) {
      const tracks = project.cursor?.tracks ?? {};
      const hasData = Object.values(tracks).some((t) => t.events.length > 0);
      if (!hasData) {
        details.autoSkipped = "no cursor data";
      } else {
        const proposed = generateAutoZoom(tracks, computeTimeline(project), {
          ...project.cursor?.autoZoom,
          enabled: true,
          ...(input.auto.sensitivity ? { sensitivity: input.auto.sensitivity } : {}),
        });
        let next = input.auto.replace ? [] : regions;
        for (const r of proposed)
          next = addZoomRegion(
            next.filter((old) => old.id !== r.id),
            r,
            total,
          );
        regions = next;
        details.autoProposed = proposed.length;
        parts.push(`auto ${proposed.length}`);
      }
    }
    for (const r of input.clearRanges ?? []) regions = clearZoomRange(regions, r.start, r.end);
    if (input.clearRanges?.length) parts.push(`cleared ${input.clearRanges.length} range(s)`);

    const unknownIds: string[] = [];
    let removed = 0;
    for (const id of input.removeIds ?? []) {
      if (!regions.some((r) => r.id === id)) unknownIds.push(id);
      else {
        regions = removeZoomRegion(regions, id);
        removed++;
      }
    }
    if (removed) parts.push(`removed ${removed}`);
    if (unknownIds.length) details.unknownIds = unknownIds;

    const rejected: { index: number; reason: string }[] = [];
    let added = 0;
    (input.add ?? []).forEach((a, index) => {
      const lo = Math.max(0, Math.min(a.start, a.end));
      const hi = Math.min(total, Math.max(a.start, a.end));
      if (hi - lo < MIN_REGION_SEC - 1e-9) {
        rejected.push({ index, reason: `shorter than ${MIN_REGION_SEC}s inside the timeline` });
        return;
      }
      regions = addZoomRegion(regions, a, total);
      added++;
    });
    if (added) parts.push(`added ${added}`);
    if (rejected.length) details.rejected = rejected;

    details.regions = regions.map((r) => ({
      id: r.id,
      start: round3(r.start),
      end: round3(r.end),
      scale: r.scale,
    }));
    if (same(regions, before)) return { next: project, summary: "Nothing to do", details };
    return {
      next: withZoom(project, regions),
      summary: `Zoom: ${parts.join(", ") || "updated"}`,
      details,
    };
  },
};
