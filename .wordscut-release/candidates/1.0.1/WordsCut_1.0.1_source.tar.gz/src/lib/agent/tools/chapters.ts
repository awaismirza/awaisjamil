import {
  addChapter,
  projectChapters,
  removeChapter,
  renameChapter,
  totalDuration,
  type Project,
} from "@/lib/edl";
import { suggestChapters } from "@/lib/autoChapters";
import { setChapters } from "@/lib/projectOps";
import type { JsonSchema } from "../protocol";
import {
  ToolError,
  editSchema,
  objectSchema,
  round3,
  type ActionTool,
  type EditInput,
  type EditTool,
} from "../toolTypes";

const CHAPTER_INPUT: JsonSchema = {
  type: "object",
  additionalProperties: false,
  properties: {
    time: { type: "number", minimum: 0, description: "Output-timeline seconds." },
    title: { type: "string", maxLength: 120 },
  },
  required: ["time"],
};

export const chaptersSuggest: ActionTool<{ count?: number; minChapterSec: number }> = {
  name: "chapters_suggest",
  title: "Suggest chapters",
  description:
    "Read-only. Proposes chapter times and titles from the transcript. Apply with chapters_edit {fromSuggestions}.",
  kind: "query",
  mutates: false,
  inputSchema: objectSchema({
    count: { type: "integer", minimum: 1, maximum: 50 },
    minChapterSec: { type: "number", minimum: 1, maximum: 600, default: 10 },
  }),
  async run(input, ctx) {
    const suggestions = suggestChapters(ctx.getProject(), {
      ...(input.count !== undefined ? { count: input.count } : {}),
      minChapterSec: input.minChapterSec,
    });
    return {
      suggestions: suggestions.map((s) => ({ time: round3(s.outputTime), title: s.title })),
    };
  },
};

interface ChaptersInput extends EditInput {
  set?: { time: number; title?: string }[];
  fromSuggestions?: { count?: number };
  removeIds?: string[];
  rename?: { id: string; title: string }[];
  add?: { time: number; title?: string }[];
}

const clampTime = (project: Project, t: number) => Math.max(0, Math.min(t, totalDuration(project)));

export const chaptersEdit: EditTool<ChaptersInput> = {
  name: "chapters_edit",
  title: "Edit chapters",
  description:
    "Plans (confirm:false) or applies (confirm:true) chapter changes. Order: set or fromSuggestions (exclusive), removeIds, rename, add. Times are output-timeline seconds.",
  kind: "edit",
  inputSchema: editSchema({
    set: {
      type: "array",
      maxItems: 200,
      items: CHAPTER_INPUT,
      description: "Replace all chapters.",
    },
    fromSuggestions: {
      type: "object",
      additionalProperties: false,
      properties: { count: { type: "integer", minimum: 1, maximum: 50 } },
      description: "Replace all chapters with the automatic suggestions.",
    },
    removeIds: { type: "array", maxItems: 200, items: { type: "string", maxLength: 64 } },
    rename: {
      type: "array",
      maxItems: 200,
      items: {
        type: "object",
        additionalProperties: false,
        properties: {
          id: { type: "string", maxLength: 64 },
          title: { type: "string", maxLength: 120 },
        },
        required: ["id", "title"],
      },
    },
    add: { type: "array", maxItems: 200, items: CHAPTER_INPUT },
  }),
  compute(project, input) {
    if (input.set && input.fromSuggestions)
      throw new ToolError("INVALID_INPUT", "/set: set and fromSuggestions are mutually exclusive");
    let next = project;
    const parts: string[] = [];
    const unknownIds: string[] = [];

    if (input.set) {
      const chapters = input.set
        .map((c) => ({
          title: c.title?.trim() || "Chapter",
          outputTime: clampTime(project, c.time),
        }))
        .sort((a, b) => a.outputTime - b.outputTime);
      next = setChapters(next, chapters);
      parts.push(`set ${chapters.length}`);
    } else if (input.fromSuggestions) {
      if (!project.segments.some((s) => s.words.length > 0))
        throw new ToolError("NO_TRANSCRIPT", "Chapter suggestions need a transcript");
      const chapters = suggestChapters(project, {
        ...(input.fromSuggestions.count !== undefined
          ? { count: input.fromSuggestions.count }
          : {}),
      });
      next = setChapters(next, chapters);
      parts.push(`set ${chapters.length} suggested`);
    }
    if (input.removeIds) {
      let removed = 0;
      for (const id of input.removeIds) {
        const after = removeChapter(next, id);
        if (after === next) unknownIds.push(id);
        else {
          next = after;
          removed++;
        }
      }
      if (removed) parts.push(`removed ${removed}`);
    }
    if (input.rename) {
      let renamed = 0;
      for (const r of input.rename) {
        if (!projectChapters(next).some((c) => c.id === r.id)) {
          unknownIds.push(r.id);
          continue;
        }
        next = renameChapter(next, r.id, r.title);
        renamed++;
      }
      if (renamed) parts.push(`renamed ${renamed}`);
    }
    if (input.add) {
      for (const c of input.add) next = addChapter(next, c.time, c.title ?? "Chapter");
      if (input.add.length) parts.push(`added ${input.add.length}`);
    }

    const details: Record<string, unknown> = {
      chapters: projectChapters(next).map((c) => ({
        id: c.id,
        time: round3(c.outputTime),
        title: c.title,
      })),
      ...(unknownIds.length ? { unknownIds } : {}),
    };
    if (parts.length === 0) return { next: project, summary: "Nothing to do", details };
    return { next, summary: `Chapters: ${parts.join(", ")}`, details };
  },
};
