import type { AgentContext } from "../protocol";
import { ToolError } from "../toolTypes";

export function extOf(path: string): string {
  const base = path.split("/").pop() ?? path;
  const i = base.lastIndexOf(".");
  return i <= 0 ? "" : base.slice(i).toLowerCase();
}

/**
 * Check an output file path: absolute, parent exists, allowed extension, and
 * no accidental overwrite. Rust re-checks on write; this gives early, clear errors.
 */
export async function checkOutputPath(
  ctx: AgentContext,
  path: string,
  extensions: readonly string[],
  overwrite: boolean,
): Promise<void> {
  if (path.includes("\0")) throw new ToolError("PATH_REJECTED", "Path contains a NUL character");
  const ext = extOf(path);
  if (!extensions.includes(ext))
    throw new ToolError("PATH_REJECTED", `Output path must end in ${extensions.join(" or ")}`);
  const info = await ctx.pathInfo(path);
  if (!info.absolute) throw new ToolError("PATH_REJECTED", "Output path must be absolute");
  if (info.isDir) throw new ToolError("PATH_REJECTED", "Output path is a directory");
  if (!info.parentExists)
    throw new ToolError("PATH_REJECTED", "The parent folder of the output path does not exist");
  if (info.exists && !overwrite)
    throw new ToolError(
      "PATH_REJECTED",
      "File already exists",
      "Pass overwrite:true to replace it.",
    );
}
