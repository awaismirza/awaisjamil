import { flattenWordsInOutputTime } from "@/lib/captions";
import { findWords } from "@/lib/projectOps";
import { RANGE_SCHEMA, objectSchema, round3, type ActionTool } from "../toolTypes";

const SENTENCE_END = /[.!?]["')\]]*$/;
const SENTENCE_GAP_SEC = 0.9;

interface OutWord {
  id: string;
  text: string;
  start: number;
  end: number;
  confidence: number;
}

interface Sentence {
  start: number;
  end: number;
  text: string;
  wordIds: string[];
}

function outputWords(project: Parameters<typeof flattenWordsInOutputTime>[0]): OutWord[] {
  return flattenWordsInOutputTime(project).map((w) => ({
    id: w.word.id,
    text: w.word.text,
    start: round3(w.start),
    end: round3(w.end),
    confidence: w.word.confidence,
  }));
}

function toSentences(words: OutWord[]): Sentence[] {
  const out: Sentence[] = [];
  let cur: OutWord[] = [];
  const flush = () => {
    if (cur.length === 0) return;
    out.push({
      start: cur[0]!.start,
      end: cur[cur.length - 1]!.end,
      text: cur
        .map((w) => w.text.trim())
        .join(" ")
        .replace(/\s+([.,!?;:])/g, "$1"),
      wordIds: cur.map((w) => w.id),
    });
    cur = [];
  };
  for (const w of words) {
    const prev = cur[cur.length - 1];
    if (prev && (SENTENCE_END.test(prev.text.trim()) || w.start - prev.end >= SENTENCE_GAP_SEC))
      flush();
    cur.push(w);
  }
  flush();
  return out;
}

function mmss(t: number): string {
  const s = Math.floor(Math.max(0, t));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const body = `${String(m).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
  return h > 0 ? `${h}:${body}` : body;
}

interface GetInput {
  format: "words" | "sentences" | "text";
  offset: number;
  limit: number;
  range?: { start: number; end: number };
}

export const transcriptGet: ActionTool<GetInput> = {
  name: "transcript_get",
  title: "Get transcript",
  description:
    "Read-only. Returns the transcript of the current edit (deleted words are gone) as words, sentences or timestamped text, in output-timeline seconds. Paged with offset/limit; follow nextOffset.",
  kind: "query",
  mutates: false,
  inputSchema: objectSchema({
    format: { type: "string", enum: ["words", "sentences", "text"], default: "sentences" },
    offset: { type: "integer", minimum: 0, default: 0 },
    limit: { type: "integer", minimum: 1, maximum: 5000, default: 1000 },
    range: { ...RANGE_SCHEMA, description: "Only items overlapping this output-time range." },
  }),
  async run(input, ctx) {
    const project = ctx.getProject();
    let words = outputWords(project);
    const range = input.range;
    const inRange = <T extends { start: number; end: number }>(x: T) =>
      !range || (x.start < range.end && x.end > range.start);
    words = words.filter(inRange);
    const base = (total: number, shown: number) => ({
      total,
      offset: input.offset,
      nextOffset: input.offset + shown < total ? input.offset + shown : null,
      revision: ctx.revision(),
    });
    if (input.format === "words") {
      const page = words.slice(input.offset, input.offset + input.limit);
      return { words: page, ...base(words.length, page.length) };
    }
    const sentences = toSentences(words);
    const page = sentences.slice(input.offset, input.offset + input.limit);
    if (input.format === "sentences")
      return { sentences: page, ...base(sentences.length, page.length) };
    const text = page.map((s) => `[${mmss(s.start)}] ${s.text}`).join("\n");
    return { text, ...base(sentences.length, page.length) };
  },
};

interface SearchInput {
  query: string;
  wholeWord: boolean;
  caseSensitive: boolean;
  maxResults: number;
}

export const transcriptSearch: ActionTool<SearchInput> = {
  name: "transcript_search",
  title: "Search transcript",
  description:
    "Read-only. Finds a word or phrase in the current transcript. Multi-word queries match consecutive words. Returns word ids and output-time spans.",
  kind: "query",
  mutates: false,
  inputSchema: objectSchema(
    {
      query: { type: "string", minLength: 1, maxLength: 200 },
      wholeWord: { type: "boolean", default: true },
      caseSensitive: { type: "boolean", default: false },
      maxResults: { type: "integer", minimum: 1, maximum: 500, default: 100 },
    },
    ["query"],
  ),
  async run(input, ctx) {
    const project = ctx.getProject();
    const times = new Map(outputWords(project).map((w) => [w.id, w]));
    const all = findWords(project, input.query, {
      wholeWord: input.wholeWord,
      caseSensitive: input.caseSensitive,
    }).flatMap((m) => {
      const first = times.get(m.wordIds[0]!);
      const last = times.get(m.wordIds[m.wordIds.length - 1]!);
      if (!first || !last) return [];
      return [
        { wordIds: m.wordIds, text: m.text, start: first.start, end: last.end, context: m.context },
      ];
    });
    return { matches: all.slice(0, input.maxResults), total: all.length };
  },
};
