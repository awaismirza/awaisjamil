import {
  cutSilences,
  deleteWords,
  keepOutputRange,
  totalDuration,
  wordIdsInOutputRange,
  DEFAULT_PADDING_MS,
  type Project,
} from "@/lib/edl";
import { findFillersInSegments } from "@/lib/fillers";
import { replaceText } from "@/lib/projectOps";
import type { AgentContext } from "../protocol";
import { validate } from "../schema";
import {
  RANGE_SCHEMA,
  ToolError,
  editSchema,
  round3,
  type EditInput,
  type EditResult,
  type EditTool,
} from "../toolTypes";
import { chaptersEdit } from "./chapters";
import { zoomEdit } from "./zoom";

const plural = (n: number, one: string, many = `${one}s`) => `${n} ${n === 1 ? one : many}`;

// ---------------------------------------------------------------------------
// 6. edit_cut_words
// ---------------------------------------------------------------------------

interface CutWordsInput extends EditInput {
  wordIds?: string[];
  ranges?: { start: number; end: number }[];
}

export const editCutWords: EditTool<CutWordsInput> = {
  name: "edit_cut_words",
  title: "Cut words",
  description:
    "Plans (confirm:false) or applies (confirm:true) deletion of words, given as wordIds or as output-time ranges (exactly one of the two).",
  kind: "edit",
  needs: { transcript: true },
  inputSchema: editSchema({
    wordIds: {
      type: "array",
      minItems: 1,
      maxItems: 20000,
      items: { type: "string", maxLength: 64 },
    },
    ranges: { type: "array", minItems: 1, maxItems: 500, items: RANGE_SCHEMA },
  }),
  compute(project, input) {
    if ((input.wordIds === undefined) === (input.ranges === undefined))
      throw new ToolError("INVALID_INPUT", "/: provide exactly one of wordIds or ranges");
    const ids = new Set<string>();
    const details: Record<string, unknown> = {};
    if (input.wordIds) {
      const known = new Set(project.segments.flatMap((s) => s.words.map((w) => w.id)));
      const unknown: string[] = [];
      for (const id of input.wordIds) {
        if (known.has(id)) ids.add(id);
        else unknown.push(id);
      }
      if (unknown.length > 0) details.unknownIds = unknown.slice(0, 100);
      if (ids.size === 0)
        throw new ToolError("NOT_FOUND", "None of the wordIds exist in the project");
    } else {
      for (const r of input.ranges!)
        for (const id of wordIdsInOutputRange(project, r.start, r.end)) ids.add(id);
    }
    if (ids.size === 0) return { next: project, summary: "Nothing to do", details };
    return {
      next: deleteWords(project, ids),
      summary: `Cut ${plural(ids.size, "word")}`,
      details,
    };
  },
};

// ---------------------------------------------------------------------------
// 7. edit_cut_range
// ---------------------------------------------------------------------------

interface CutRangeInput extends EditInput {
  start: number;
  end: number;
  mode: "delete" | "keep";
}

export const editCutRange: EditTool<CutRangeInput> = {
  name: "edit_cut_range",
  title: "Cut or keep a time range",
  description:
    "Plans (confirm:false) or applies (confirm:true) removal of an output-time range (mode delete) or removal of everything outside it (mode keep).",
  kind: "edit",
  inputSchema: editSchema(
    {
      start: { type: "number", minimum: 0 },
      end: { type: "number", minimum: 0 },
      mode: { type: "string", enum: ["delete", "keep"], default: "delete" },
    },
    ["start", "end"],
  ),
  compute(project, input) {
    if (!(input.end > input.start))
      throw new ToolError("INVALID_INPUT", "/end: must be greater than start");
    if (input.mode === "keep") {
      const next = keepOutputRange(project, input.start, input.end);
      return {
        next,
        summary:
          next === project
            ? "Nothing to do"
            : `Kept ${round3(input.start)}s to ${round3(input.end)}s`,
      };
    }
    const ids = wordIdsInOutputRange(project, input.start, input.end);
    if (ids.length === 0) return { next: project, summary: "Nothing to do" };
    return {
      next: deleteWords(project, new Set(ids)),
      summary: `Cut ${round3(input.start)}s to ${round3(input.end)}s (${plural(ids.length, "word")})`,
    };
  },
};

// ---------------------------------------------------------------------------
// 8. edit_cut_fillers
// ---------------------------------------------------------------------------

interface CutFillersInput extends EditInput {
  phrases?: string[];
}

export const editCutFillers: EditTool<CutFillersInput, string[]> = {
  name: "edit_cut_fillers",
  title: "Cut filler words",
  description:
    "Plans (confirm:false) or applies (confirm:true) removal of filler words. Defaults to the editor's selected fillers (um, uh, er...). Multi-word phrases match consecutive words.",
  kind: "edit",
  needs: { transcript: true },
  inputSchema: editSchema({
    phrases: {
      type: "array",
      minItems: 1,
      maxItems: 100,
      items: { type: "string", minLength: 1, maxLength: 40 },
    },
  }),
  async prepare(input, ctx) {
    return input.phrases ?? ctx.selectedFillers();
  },
  compute(project, _input, phrases) {
    const matches = findFillersInSegments(project.segments, phrases);
    if (matches.length === 0)
      return { next: project, summary: "Nothing to do", details: { byPhrase: {} } };
    const byPhrase: Record<string, number> = {};
    for (const m of matches) byPhrase[m.phrase] = (byPhrase[m.phrase] ?? 0) + 1;
    const ids = new Set(matches.flatMap((m) => m.wordIds));
    return {
      next: deleteWords(project, ids),
      summary: `Removed ${plural(matches.length, "filler")}`,
      details: { byPhrase },
    };
  },
};

// ---------------------------------------------------------------------------
// 9. edit_trim_silences
// ---------------------------------------------------------------------------

interface TrimSilencesInput extends EditInput {
  minDurationSec: number;
  keepSec?: number;
  noiseThresholdDb: number;
}

interface SilencePrep {
  mediaId: string;
  silences: { start: number; end: number }[];
}

export const editTrimSilences: EditTool<TrimSilencesInput, SilencePrep> = {
  name: "edit_trim_silences",
  title: "Trim silences",
  description:
    "Plans (confirm:false) or applies (confirm:true) removal of silences found by audio analysis on the first media. Runs detection on every call, including plans, so it can take several seconds.",
  kind: "edit",
  needs: { media: true },
  inputSchema: editSchema({
    minDurationSec: { type: "number", minimum: 0.2, maximum: 10, default: 0.6 },
    keepSec: {
      type: "number",
      minimum: 0,
      maximum: 2,
      description: "Silence left in place. Default: twice the project padding.",
    },
    noiseThresholdDb: { type: "number", minimum: -80, maximum: -10, default: -35 },
  }),
  async prepare(input, ctx: AgentContext) {
    const project = ctx.getProject();
    const mediaId = Object.keys(project.media)[0];
    const media = mediaId ? project.media[mediaId] : undefined;
    if (!mediaId || !media) throw new ToolError("NO_MEDIA", "The project has no media");
    const found = await ctx.detectPauses({
      mediaPath: media.path,
      noiseThreshold: input.noiseThresholdDb,
      minDuration: input.minDurationSec,
    });
    return { mediaId, silences: found.map((p) => ({ start: p.start, end: p.end })) };
  },
  compute(project, input, prep) {
    const keepSec =
      input.keepSec ?? 2 * ((project.settings.paddingMs ?? DEFAULT_PADDING_MS) / 1000);
    const [next, cut] = cutSilences(project, prep.mediaId, prep.silences, {
      minDuration: input.minDurationSec,
      keepSec,
    });
    const long = prep.silences.filter((s) => s.end - s.start > input.minDurationSec);
    const details = {
      mediaId: prep.mediaId,
      silencesFound: prep.silences.length,
      silencesCut: cut,
      sourceRanges: long
        .slice(0, 200)
        .map((s) => ({ start: round3(s.start + keepSec / 2), end: round3(s.end - keepSec / 2) })),
    };
    if (cut === 0) return { next: project, summary: "Nothing to do", details };
    return { next, summary: `Trimmed ${plural(cut, "silence")}`, details };
  },
};

// ---------------------------------------------------------------------------
// 10. edit_replace_text
// ---------------------------------------------------------------------------

interface ReplaceInput extends EditInput {
  find: string;
  replace: string;
  caseSensitive: boolean;
  wholeWord: boolean;
}

export const editReplaceText: EditTool<ReplaceInput> = {
  name: "edit_replace_text",
  title: "Replace text",
  description:
    "Plans (confirm:false) or applies (confirm:true) a find-and-replace on transcript words. Changes word text only (captions), never timing or the audio.",
  kind: "edit",
  needs: { transcript: true },
  inputSchema: editSchema(
    {
      find: { type: "string", minLength: 1, maxLength: 200 },
      replace: { type: "string", maxLength: 200 },
      caseSensitive: { type: "boolean", default: false },
      wholeWord: { type: "boolean", default: true },
    },
    ["find", "replace"],
  ),
  compute(project, input) {
    const { project: next, count } = replaceText(project, input.find, input.replace, {
      caseSensitive: input.caseSensitive,
      wholeWord: input.wholeWord,
    });
    if (count === 0) return { next: project, summary: "Nothing to do", details: { replaced: 0 } };
    return {
      next,
      summary: `Replaced ${plural(count, "occurrence")} of "${input.find}"`,
      details: { replaced: count },
    };
  },
};

// ---------------------------------------------------------------------------
// 13. edit_batch
// ---------------------------------------------------------------------------

type BatchStepTool = EditTool<any, any>;

export const BATCHABLE: readonly BatchStepTool[] = [
  editCutWords,
  editCutRange,
  editCutFillers,
  editTrimSilences,
  editReplaceText,
  chaptersEdit,
  zoomEdit,
];

interface BatchInput extends EditInput {
  steps: { name: string; input: Record<string, unknown> }[];
}

interface BatchPrep {
  steps: { tool: BatchStepTool; input: Record<string, unknown>; prep: unknown }[];
}

function checkNeeds(tool: BatchStepTool, project: Project): void {
  if (tool.needs?.media && Object.keys(project.media).length === 0)
    throw new ToolError("NO_MEDIA", "The project has no media");
  if (tool.needs?.transcript && !project.segments.some((s) => s.words.length > 0))
    throw new ToolError("NO_TRANSCRIPT", "The project has no transcript");
}

export const editBatch: EditTool<BatchInput, BatchPrep> = {
  name: "edit_batch",
  title: "Batch edit",
  description:
    "Plans (confirm:false) or applies (confirm:true) several edit steps as ONE undo step. Each step is {name, input} for an edit tool; per-step confirm/baseRevision are ignored and later steps see the result of earlier ones.",
  kind: "edit",
  inputSchema: editSchema(
    {
      steps: {
        type: "array",
        minItems: 1,
        maxItems: 50,
        items: {
          type: "object",
          additionalProperties: false,
          properties: {
            name: { type: "string", enum: BATCHABLE.map((t) => t.name) },
            input: {
              type: "object",
              description: "Input of the named tool.",
              additionalProperties: true,
            },
          },
          required: ["name"],
        },
      },
    },
    ["steps"],
  ),
  async prepare(input, ctx) {
    const steps: BatchPrep["steps"] = [];
    for (const [i, step] of input.steps.entries()) {
      const tool = BATCHABLE.find((t) => t.name === step.name)!;
      const checked = validate(tool.inputSchema, step.input ?? {});
      if (!checked.ok)
        throw new ToolError(
          "INVALID_INPUT",
          `/steps/${i}/input${checked.pointer}: ${checked.message}`,
        );
      const value = checked.value as Record<string, unknown>;
      const prep = tool.prepare ? await tool.prepare(value, ctx) : undefined;
      steps.push({ tool, input: value, prep });
    }
    return { steps };
  },
  compute(project, _input, prep): EditResult {
    let current = project;
    const log: { name: string; summary: string; removedSec: number }[] = [];
    for (const [i, step] of prep.steps.entries()) {
      try {
        checkNeeds(step.tool, current);
        const before = totalDuration(current);
        const r = step.tool.compute(current, step.input, step.prep) as EditResult;
        log.push({
          name: step.tool.name,
          summary: r.summary,
          removedSec: round3(Math.max(0, before - totalDuration(r.next))),
        });
        current = r.next;
      } catch (e) {
        if (e instanceof ToolError)
          throw new ToolError(e.code, `Step ${i} (${step.tool.name}): ${e.message}`, e.hint);
        throw e;
      }
    }
    const details = { steps: log };
    if (current === project) return { next: project, summary: "Nothing to do", details };
    const done = log.filter((s) => s.summary !== "Nothing to do").map((s) => s.summary);
    return { next: current, summary: `Batch of ${log.length}: ${done.join("; ")}`, details };
  },
};
