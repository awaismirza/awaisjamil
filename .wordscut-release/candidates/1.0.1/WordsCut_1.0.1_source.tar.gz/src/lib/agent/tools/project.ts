import { computeTimeline, projectChapters, totalDuration, type Project } from "@/lib/edl";
import { addRecentProject } from "@/lib/recentProjects";
import { sanitizeZoomRegions } from "@/lib/zoom";
import type { AgentContext } from "../protocol";
import { ToolError, objectSchema, round3, type ActionTool } from "../toolTypes";
import { extOf } from "./pathChecks";

export function buildProjectInfo(project: Project, ctx: AgentContext): Record<string, unknown> {
  const used = new Set((project.audioTracks ?? []).map((t) => t.mediaId));
  const media = Object.values(project.media).map((m) => ({
    id: m.id,
    path: m.path,
    durationSec: round3(m.duration),
    width: m.width,
    height: m.height,
    fps: m.fps,
    hasTranscript:
      (project.originalTranscripts?.[m.id]?.length ?? 0) > 0 ||
      project.segments.some((s) => s.mediaId === m.id && s.words.length > 0),
  }));
  const original = Object.values(project.media)
    .filter((m) => !used.has(m.id) || project.segments.some((s) => s.mediaId === m.id))
    .reduce((n, m) => n + m.duration, 0);
  return {
    name: project.name,
    filePath: ctx.getFilePath(),
    dirty: ctx.isDirty(),
    revision: ctx.revision(),
    durationSec: round3(totalDuration(project)),
    originalDurationSec: round3(original),
    media,
    wordCount: project.segments.reduce((n, s) => n + s.words.length, 0),
    segmentCount: project.segments.length,
    chapterCount: projectChapters(project).length,
    zoomRegionCount: project.zoomRegions?.length ?? 0,
    busy: ctx.busyReason(),
  };
}

export const projectInfo: ActionTool<Record<string, never>> = {
  name: "project_info",
  title: "Project info",
  description:
    "Read-only summary of the open project: name, file path, dirty flag, revision, durations, media, counts and whether the editor is busy.",
  kind: "query",
  mutates: false,
  inputSchema: objectSchema(),
  async run(_input, ctx) {
    return buildProjectInfo(ctx.getProject(), ctx);
  },
};

export const edlGet: ActionTool<{ include: string[] }> = {
  name: "edl_get",
  title: "Get edit decision list",
  description:
    "Read-only. Returns the output timeline, segments (without word arrays), chapters and zoom regions. All times are output-timeline seconds unless named source*.",
  kind: "query",
  mutates: false,
  inputSchema: objectSchema({
    include: {
      type: "array",
      maxItems: 4,
      items: { type: "string", enum: ["timeline", "segments", "chapters", "zoomRegions"] },
      default: ["timeline", "chapters", "zoomRegions"],
      description: "Which parts to return.",
    },
  }),
  async run(input, ctx) {
    const project = ctx.getProject();
    const include = new Set(input.include);
    const total = totalDuration(project);
    const out: Record<string, unknown> = { durationSec: round3(total), revision: ctx.revision() };
    const timeline = computeTimeline(project);
    if (include.has("timeline")) {
      out.timeline = timeline.map((t) => ({
        segmentId: t.segmentId,
        mediaId: t.mediaId,
        sourceIn: round3(t.sourceIn),
        sourceOut: round3(t.sourceOut),
        outputStart: round3(t.outputStart),
        outputEnd: round3(t.outputEnd),
      }));
    }
    if (include.has("segments")) {
      out.segments = project.segments.map((s, i) => ({
        id: s.id,
        mediaId: s.mediaId,
        sourceIn: round3(s.sourceIn),
        sourceOut: round3(s.sourceOut),
        outputStart: round3(timeline[i]?.outputStart ?? 0),
        wordCount: s.words.length,
        firstWordId: s.words[0]?.id ?? null,
        lastWordId: s.words[s.words.length - 1]?.id ?? null,
      }));
    }
    if (include.has("chapters")) {
      out.chapters = projectChapters(project).map((c) => ({
        id: c.id,
        time: round3(c.outputTime),
        title: c.title,
      }));
    }
    if (include.has("zoomRegions")) {
      out.zoomRegions = sanitizeZoomRegions(project.zoomRegions, total).map((r) => ({
        id: r.id,
        start: round3(r.start),
        end: round3(r.end),
        scale: r.scale,
        focusX: r.focusX,
        focusY: r.focusY,
        easeMs: r.easeMs,
        follow: r.follow ?? false,
      }));
    }
    return out;
  },
};

export const projectOpen: ActionTool<{ path: string; discardUnsaved: boolean }> = {
  name: "project_open",
  title: "Open project",
  description:
    "Opens a .scribe project (or its project.json) in the editor, replacing the current one. Fails with DIRTY_PROJECT when there are unsaved changes unless discardUnsaved is true.",
  kind: "action",
  mutates: true,
  inputSchema: objectSchema(
    {
      path: {
        type: "string",
        minLength: 1,
        maxLength: 4096,
        description: "Absolute path to a .scribe folder.",
      },
      discardUnsaved: { type: "boolean", default: false },
    },
    ["path"],
  ),
  async run(input, ctx) {
    const busy = ctx.busyReason();
    if (busy) throw new ToolError("BUSY", `Editor is busy: ${busy}`);
    const info = await ctx.pathInfo(input.path);
    if (!info.absolute) throw new ToolError("PATH_REJECTED", "Path must be absolute");
    if (!info.exists) throw new ToolError("NOT_FOUND", `No such project: ${input.path}`);
    const base = input.path.replace(/\/+$/, "").split("/").pop() ?? "";
    const okDir = info.isDir && extOf(base) === ".scribe";
    const okFile = info.isFile && base === "project.json";
    if (!okDir && !okFile)
      throw new ToolError("PATH_REJECTED", "Expected a .scribe project folder or its project.json");
    if (ctx.isDirty() && !input.discardUnsaved)
      throw new ToolError(
        "DIRTY_PROJECT",
        "The open project has unsaved changes",
        "Call project_save first, or pass discardUnsaved:true.",
      );
    await ctx.openProject(input.path);
    return buildProjectInfo(ctx.getProject(), ctx);
  },
};

export const projectSave: ActionTool<{ path?: string }> = {
  name: "project_save",
  title: "Save project",
  description:
    "Saves the open project to its file, or to `path` (must end in .scribe). Without `path` the project must already have a file.",
  kind: "action",
  mutates: true,
  inputSchema: objectSchema({
    path: {
      type: "string",
      minLength: 1,
      maxLength: 4096,
      description: "Optional absolute .scribe path (Save As).",
    },
  }),
  async run(input, ctx) {
    const path = input.path ?? ctx.getFilePath();
    if (!path)
      throw new ToolError(
        "INVALID_INPUT",
        "The project has no file yet",
        "Pass `path` ending in .scribe.",
      );
    if (extOf(path.replace(/\/+$/, "")) !== ".scribe")
      throw new ToolError("PATH_REJECTED", "Project path must end in .scribe");
    if (input.path) {
      const info = await ctx.pathInfo(path);
      if (!info.absolute) throw new ToolError("PATH_REJECTED", "Path must be absolute");
      if (!info.parentExists) throw new ToolError("PATH_REJECTED", "Parent folder does not exist");
    }
    const result = await ctx.saveProject(path);
    addRecentProject(path);
    return { saved: true, path, current: result.current, revision: ctx.revision() };
  },
};
