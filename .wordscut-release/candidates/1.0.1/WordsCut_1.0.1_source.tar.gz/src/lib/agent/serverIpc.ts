/** Tauri command wrappers for the agent server dialog (docs/agent-cli-design.md §2.4). */

import { invoke } from "@tauri-apps/api/core";
import type { ServerInfo } from "@/lib/agent/protocol";

export function agentServerInfo(): Promise<ServerInfo> {
  return invoke<ServerInfo>("agent_server_info");
}

export function agentSetEnabled(enabled: boolean): Promise<ServerInfo> {
  return invoke<ServerInfo>("agent_set_enabled", { enabled });
}

export function agentRegenerateToken(): Promise<ServerInfo> {
  return invoke<ServerInfo>("agent_regenerate_token");
}
