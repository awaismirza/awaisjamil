/**
 * Pure builders for the copyable text in the Agent connection dialog
 * (docs/agent-cli-design.md §9). No React or Tauri imports.
 */

export const SERVER_NAME = "yusafcut";

/** Double-quote a value for a POSIX shell (escapes `\`, `"`, `$` and backticks). */
export function shellQuote(value: string): string {
  return `"${value.replace(/[\\"$`]/g, "\\$&")}"`;
}

/** `"<BIN>" agent readme` */
export function cliStartCommand(bin: string): string {
  return `${shellQuote(bin)} agent readme`;
}

export function cliExamples(
  bin: string,
  filePath: string | null,
): { label: string; cmd: string }[] {
  const q = shellQuote(bin);
  const project = shellQuote(filePath ?? "~/Movies/demo.scribe");
  return [
    { label: "Open a project", cmd: `${q} agent project open --path ${project} --json` },
    { label: "List tools", cmd: `${q} agent tool list` },
    {
      label: "Plan a silence trim",
      cmd: `${q} agent tool call --name edit_trim_silences --input-json '{"confirm":false}' --json`,
    },
  ];
}

export function claudeCodeCommand(bin: string): string {
  return `claude mcp add ${SERVER_NAME} -- ${shellQuote(bin)} mcp`;
}

/** `.mcp.json` for Claude Code and `~/.gemini/settings.json` for Gemini CLI. */
export function mcpServersJson(bin: string): string {
  return JSON.stringify(
    { mcpServers: { [SERVER_NAME]: { command: bin, args: ["mcp"] } } },
    null,
    2,
  );
}

/** `~/.codex/config.toml` (TOML basic strings share JSON's escaping). */
export function codexToml(bin: string): string {
  return [
    `[mcp_servers.${SERVER_NAME}]`,
    `command = ${JSON.stringify(bin)}`,
    `args = ["mcp"]`,
  ].join("\n");
}

export function httpHeader(token: string): string {
  return `Authorization: Bearer ${token}`;
}

export function maskToken(token: string): string {
  return "•".repeat(Math.min(Math.max(token.length, 8), 32));
}

export type ClientId = "claude" | "codex" | "gemini" | "other";

export interface Snippet {
  label: string;
  /** Where the text goes (file or shell). */
  hint: string;
  text: string;
}

export function clientSnippets(client: Exclude<ClientId, "other">, bin: string): Snippet[] {
  switch (client) {
    case "claude":
      return [
        { label: "Terminal", hint: "Run once in your shell", text: claudeCodeCommand(bin) },
        {
          label: ".mcp.json",
          hint: "Or add to your project's .mcp.json",
          text: mcpServersJson(bin),
        },
      ];
    case "codex":
      return [{ label: "config.toml", hint: "~/.codex/config.toml", text: codexToml(bin) }];
    case "gemini":
      return [
        { label: "settings.json", hint: "~/.gemini/settings.json", text: mcpServersJson(bin) },
      ];
  }
}
