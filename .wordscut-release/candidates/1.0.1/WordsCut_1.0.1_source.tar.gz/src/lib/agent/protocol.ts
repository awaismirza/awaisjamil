/**
 * Shared contracts for the Agent CLI / MCP feature (docs/agent-cli-design.md §2).
 * Pure types only: no React, Tauri or store imports.
 */

import type { Project } from "@/lib/edl";
import type { DetectPausesOpts, ExportOptions, PauseSegment } from "@/lib/ipc";

export type JsonSchema = {
  type?: "object" | "array" | "string" | "number" | "integer" | "boolean";
  description?: string;
  properties?: Record<string, JsonSchema>;
  required?: string[];
  additionalProperties?: boolean;
  items?: JsonSchema;
  enum?: readonly (string | number)[];
  minimum?: number;
  maximum?: number;
  minLength?: number;
  maxLength?: number;
  minItems?: number;
  maxItems?: number;
  default?: unknown;
  oneOf?: JsonSchema[];
};

export interface ToolCatalogEntry {
  /** `^[a-z][a-z0-9_]{1,63}$` (MCP-safe, no dots). */
  name: string;
  title: string;
  /** 1-3 sentences; says whether the tool plans or applies. */
  description: string;
  /** True when the tool accepts `confirm` / `baseRevision`. */
  mutates: boolean;
  longRunning?: boolean;
  /** Always `type: "object"` with `additionalProperties: false`. */
  inputSchema: JsonSchema;
}

export type AgentErrorCode =
  | "INVALID_INPUT"
  | "UNKNOWN_TOOL"
  | "NO_PROJECT"
  | "NO_MEDIA"
  | "NO_TRANSCRIPT"
  | "STALE_REVISION"
  | "DIRTY_PROJECT"
  | "BUSY"
  | "PATH_REJECTED"
  | "NOT_FOUND"
  | "EDITOR_NOT_READY"
  | "TIMEOUT"
  | "UNAUTHORIZED"
  | "INTERNAL";

export interface AgentError {
  code: AgentErrorCode;
  message: string;
  hint?: string;
}

export type ToolOutcome =
  | { ok: true; tool: string; data: Record<string, unknown> }
  | { ok: false; tool: string; error: AgentError };

/** Rust -> webview event `agent:request`. */
export interface RelayRequest {
  id: string;
  name: string;
  input: unknown;
  deadlineMs: number;
}

/** Webview -> Rust command `agent_respond({ response })`. */
export interface RelayResponse {
  id: string;
  outcome: ToolOutcome;
}

export interface PathInfo {
  path: string;
  absolute: boolean;
  exists: boolean;
  isDir: boolean;
  isFile: boolean;
  parentExists: boolean;
  canonical: string | null;
}

export interface ServerInfo {
  available: boolean;
  unavailableReason: string | null;
  enabled: boolean;
  running: boolean;
  port: number | null;
  mcpUrl: string | null;
  token: string | null;
  binaryPath: string;
  connectionFile: string;
  appVersion: string;
}

export const AGENT_EVENT_REQUEST = "agent:request";

/** Everything a tool may touch. Tests pass fakes; the bridge passes the live context. */
export interface AgentContext {
  getProject(): Project;
  getFilePath(): string | null;
  isDirty(): boolean;
  /** +1 on every project reference change. */
  revision(): number;
  /** Export running, recording, processing overlay, ... or null when idle. */
  busyReason(): string | null;
  /** One undo step. Returns the new revision. */
  applyProject(next: Project, summary: string): Promise<number>;
  undo(steps: number): number;
  redo(steps: number): number;
  selectedFillers(): string[];
  detectPauses(opts: DetectPausesOpts): Promise<PauseSegment[]>;
  openProject(path: string): Promise<void>;
  saveProject(path: string): Promise<{ current: boolean }>;
  /** Fire and forget; status through `exportStatus()`. */
  startExport(opts: ExportOptions): void;
  exportStatus(): {
    running: boolean;
    progress: number | null;
    lastResult: null | { ok: boolean; outputPath: string; error?: string };
  };
  cancelExport(): Promise<void>;
  pathInfo(path: string): Promise<PathInfo>;
  writeTextFile(path: string, contents: string, overwrite: boolean): Promise<void>;
}
