/**
 * Small JSON-schema subset validator (no dependency). Supports type, enum,
 * minimum/maximum, minLength/maxLength, minItems/maxItems, required,
 * additionalProperties:false, default and oneOf. Applies defaults to missing
 * object properties and returns a new value; the input is never mutated.
 */

import type { JsonSchema } from "./protocol";

export type ValidationResult =
  | { ok: true; value: unknown }
  | { ok: false; pointer: string; message: string };

class Fail extends Error {
  constructor(
    public pointer: string,
    message: string,
  ) {
    super(message);
  }
}

const escapePointer = (key: string) => key.replace(/~/g, "~0").replace(/\//g, "~1");

function typeName(v: unknown): string {
  if (v === null) return "null";
  if (Array.isArray(v)) return "array";
  return typeof v;
}

function walk(schema: JsonSchema, value: unknown, pointer: string): unknown {
  if (schema.oneOf && schema.oneOf.length > 0) {
    let first: Fail | null = null;
    for (const option of schema.oneOf) {
      try {
        return walk(option, value, pointer);
      } catch (e) {
        if (!(e instanceof Fail)) throw e;
        first ??= e;
      }
    }
    throw first ?? new Fail(pointer, "does not match any allowed shape");
  }

  if (schema.enum && !schema.enum.includes(value as string | number)) {
    throw new Fail(
      pointer,
      `must be one of ${schema.enum.map((e) => JSON.stringify(e)).join(", ")}`,
    );
  }

  switch (schema.type) {
    case "object": {
      if (value === null || typeof value !== "object" || Array.isArray(value))
        throw new Fail(pointer, `must be an object, got ${typeName(value)}`);
      const obj = value as Record<string, unknown>;
      const props = schema.properties ?? {};
      for (const key of schema.required ?? []) {
        if (obj[key] === undefined)
          throw new Fail(`${pointer}/${escapePointer(key)}`, "is required");
      }
      if (schema.additionalProperties === false) {
        for (const key of Object.keys(obj)) {
          if (!Object.hasOwn(props, key))
            throw new Fail(`${pointer}/${escapePointer(key)}`, "is not an allowed property");
        }
      }
      const out: Record<string, unknown> = {};
      for (const [key, sub] of Object.entries(props)) {
        const child = `${pointer}/${escapePointer(key)}`;
        if (obj[key] === undefined) {
          if (sub.default !== undefined) out[key] = JSON.parse(JSON.stringify(sub.default));
        } else {
          out[key] = walk(sub, obj[key], child);
        }
      }
      for (const key of Object.keys(obj)) {
        if (!Object.hasOwn(props, key) && obj[key] !== undefined) out[key] = obj[key];
      }
      return out;
    }
    case "array": {
      if (!Array.isArray(value))
        throw new Fail(pointer, `must be an array, got ${typeName(value)}`);
      if (schema.minItems !== undefined && value.length < schema.minItems)
        throw new Fail(pointer, `must have at least ${schema.minItems} items`);
      if (schema.maxItems !== undefined && value.length > schema.maxItems)
        throw new Fail(pointer, `must have at most ${schema.maxItems} items`);
      const item = schema.items;
      return item ? value.map((v, i) => walk(item, v, `${pointer}/${i}`)) : [...value];
    }
    case "string": {
      if (typeof value !== "string")
        throw new Fail(pointer, `must be a string, got ${typeName(value)}`);
      if (schema.minLength !== undefined && value.length < schema.minLength)
        throw new Fail(pointer, `must be at least ${schema.minLength} characters`);
      if (schema.maxLength !== undefined && value.length > schema.maxLength)
        throw new Fail(pointer, `must be at most ${schema.maxLength} characters`);
      return value;
    }
    case "number":
    case "integer": {
      if (typeof value !== "number" || !Number.isFinite(value))
        throw new Fail(pointer, `must be a ${schema.type}, got ${typeName(value)}`);
      if (schema.type === "integer" && !Number.isInteger(value))
        throw new Fail(pointer, "must be an integer");
      if (schema.minimum !== undefined && value < schema.minimum)
        throw new Fail(pointer, `must be >= ${schema.minimum}`);
      if (schema.maximum !== undefined && value > schema.maximum)
        throw new Fail(pointer, `must be <= ${schema.maximum}`);
      return value;
    }
    case "boolean": {
      if (typeof value !== "boolean")
        throw new Fail(pointer, `must be a boolean, got ${typeName(value)}`);
      return value;
    }
    default:
      return value;
  }
}

/** Validate `value` against `schema`, filling defaults. Pointers are RFC 6901 ("" = root). */
export function validate(schema: JsonSchema, value: unknown): ValidationResult {
  try {
    return { ok: true, value: walk(schema, value, "") };
  } catch (e) {
    if (e instanceof Fail) return { ok: false, pointer: e.pointer, message: e.message };
    throw e;
  }
}
