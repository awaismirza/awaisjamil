/** Pure project diffing and plan/apply output shaping (docs/agent-cli-design.md §3, §4). */

import { computeTimeline, entryOutputAt, totalDuration, type Project } from "@/lib/edl";

export const MAX_REMOVED_WORDS = 200;

export interface RemovedWord {
  id: string;
  text: string;
  outputStart: number;
}

export interface ProjectDiff {
  durationBefore: number;
  durationAfter: number;
  removedSec: number;
  removedWords: RemovedWord[];
  removedWordCount: number;
  changedWordCount: number;
  chapters: { before: number; after: number };
  zoomRegions: { before: number; after: number };
}

const r3 = (n: number) => Math.round(n * 1000) / 1000;

export function diffProjects(before: Project, after: Project): ProjectDiff {
  const surviving = new Map<string, string>();
  for (const seg of after.segments) for (const w of seg.words) surviving.set(w.id, w.text);

  const removed: RemovedWord[] = [];
  let removedCount = 0;
  let changed = 0;
  for (const entry of computeTimeline(before)) {
    const seg = before.segments.find((s) => s.id === entry.segmentId);
    if (!seg) continue;
    for (const w of seg.words) {
      const text = surviving.get(w.id);
      if (text === undefined) {
        removedCount++;
        if (removed.length < MAX_REMOVED_WORDS) {
          const t = Math.max(entry.sourceIn, Math.min(w.start, entry.sourceOut));
          removed.push({
            id: w.id,
            text: w.text,
            outputStart: r3(entryOutputAt(entry, t)),
          });
        }
      } else if (text !== w.text) {
        changed++;
      }
    }
  }
  const durationBefore = totalDuration(before);
  const durationAfter = totalDuration(after);
  return {
    durationBefore: r3(durationBefore),
    durationAfter: r3(durationAfter),
    removedSec: r3(Math.max(0, durationBefore - durationAfter)),
    removedWords: removed,
    removedWordCount: removedCount,
    changedWordCount: changed,
    chapters: { before: before.chapters?.length ?? 0, after: after.chapters?.length ?? 0 },
    zoomRegions: { before: before.zoomRegions?.length ?? 0, after: after.zoomRegions?.length ?? 0 },
  };
}

export const PLAN_NEXT = "Call again with confirm:true (and baseRevision) to apply.";
export const UNDO_HINT = "history {action:'undo'}";

export interface OutputArgs {
  summary: string;
  revision: number;
  diff: ProjectDiff;
  details?: Record<string, unknown>;
}

export function planOutput(a: OutputArgs): Record<string, unknown> {
  return {
    applied: false,
    summary: a.summary,
    revision: a.revision,
    ...bodyOf(a),
    next: PLAN_NEXT,
  };
}

export function appliedOutput(a: OutputArgs): Record<string, unknown> {
  return { applied: true, summary: a.summary, revision: a.revision, ...bodyOf(a), undo: UNDO_HINT };
}

export function noopOutput(revision: number, diff: ProjectDiff, details?: Record<string, unknown>) {
  return {
    applied: false,
    summary: "Nothing to do",
    revision,
    ...bodyOf({ summary: "", revision, diff, details }),
  };
}

function bodyOf(a: OutputArgs): Record<string, unknown> {
  const d = a.diff;
  return {
    durationBefore: d.durationBefore,
    durationAfter: d.durationAfter,
    removedSec: d.removedSec,
    removedWords: d.removedWords,
    removedWordCount: d.removedWordCount,
    ...(d.changedWordCount > 0 ? { changedWordCount: d.changedWordCount } : {}),
    chapters: d.chapters,
    zoomRegions: d.zoomRegions,
    details: a.details ?? {},
  };
}
