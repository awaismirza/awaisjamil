/**
 * The live AgentContext: wires the registry's tools to the real stores and
 * Tauri commands (docs/agent-cli-design.md §4, §5).
 */

import { addRecentProject } from "@/lib/recentProjects";
import { cancelExport, detectPauses, exportVideo, type ExportOptions } from "@/lib/ipc";
import { openProjectAtPath } from "@/lib/projectActions";
import { saveProjectRevision } from "@/lib/saveCoordinator";
import { pushUndoToast } from "@/lib/undoToast";
import { useFillerStore } from "@/stores/fillerStore";
import { useProjectStore } from "@/stores/projectStore";
import { useRecordingStore } from "@/stores/recordingStore";
import { useUIStore } from "@/stores/uiStore";
import { agentPathInfo, agentWriteTextFile } from "./bridgeIpc";
import type { AgentContext, AgentErrorCode } from "./protocol";

/** Thrown by the live context; the bridge maps `code` into the ToolOutcome. */
export class AgentContextError extends Error {
  readonly code: AgentErrorCode;
  constructor(code: AgentErrorCode, message: string) {
    super(message);
    this.name = "AgentContextError";
    this.code = code;
  }
}

let revisionCounter = 0;
let unsubscribeRevision: (() => void) | null = null;
let lastExport: ReturnType<AgentContext["exportStatus"]>["lastResult"] = null;

/** Start counting project reference changes. Idempotent. */
export function startRevisionTracking(): void {
  if (unsubscribeRevision) return;
  unsubscribeRevision = useProjectStore.subscribe((state, before) => {
    if (state.project !== before.project) revisionCounter += 1;
  });
}

export function stopRevisionTracking(): void {
  unsubscribeRevision?.();
  unsubscribeRevision = null;
}

export function resetRevision(): void {
  revisionCounter = 0;
}

/** Resolves on the next animation frame, or after 50 ms when frames never fire (hidden window). */
function nextFrameOrTimeout(): Promise<void> {
  return new Promise<void>((resolve) => {
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      resolve();
    };
    if (typeof requestAnimationFrame === "function") requestAnimationFrame(() => finish());
    setTimeout(finish, 50);
  });
}

function busyReason(): string | null {
  const ui = useUIStore.getState();
  if (ui.exportingProgress !== null) return "An export is running";
  const phase = useRecordingStore.getState().phase;
  if (phase !== "idle") return `The recorder is busy (${phase})`;
  if (ui.isProcessingEdit) return "Another edit is processing";
  if (ui.mediaLoading) return "Media is loading";
  if (ui.transcribeProgress !== null) return "A transcription is running";
  return null;
}

export function createLiveContext(): AgentContext {
  startRevisionTracking();
  return {
    getProject: () => useProjectStore.getState().project,
    getFilePath: () => useProjectStore.getState().filePath,
    isDirty: () => useProjectStore.getState().dirty,
    revision: () => revisionCounter,
    busyReason,

    async applyProject(next, summary) {
      const reason = busyReason();
      if (reason) throw new AgentContextError("BUSY", reason);
      const ui = useUIStore.getState();
      const label = `Agent: ${summary}`;
      // Not uiStore.withProcessingEdit: it awaits a bare rAF, which never fires in a hidden window.
      ui.beginProcessingEdit(label);
      try {
        await nextFrameOrTimeout();
        useProjectStore.getState().setProject(next);
      } finally {
        useUIStore.getState().endProcessingEdit();
      }
      pushUndoToast(label);
      return revisionCounter;
    },

    undo(steps) {
      useProjectStore.temporal.getState().undo(steps);
      return revisionCounter;
    },
    redo(steps) {
      useProjectStore.temporal.getState().redo(steps);
      return revisionCounter;
    },

    selectedFillers: () => Array.from(useFillerStore.getState().selected),
    detectPauses: (opts) => detectPauses(opts),

    async openProject(path) {
      await openProjectAtPath(path);
      resetRevision();
      lastExport = null;
    },

    async saveProject(path) {
      const { project, filePath } = useProjectStore.getState();
      const result = await saveProjectRevision(project, path, filePath);
      if (result.status === "saved") addRecentProject(path);
      return { current: result.current };
    },

    startExport(opts: ExportOptions) {
      const ui = useUIStore.getState();
      ui.setExportingProgress(0);
      lastExport = null;
      void exportVideo(opts)
        .then(() => {
          lastExport = { ok: true, outputPath: opts.outputPath };
          useUIStore
            .getState()
            .pushToast({ title: "Export complete", description: opts.outputPath });
        })
        .catch((err: unknown) => {
          lastExport = { ok: false, outputPath: opts.outputPath, error: String(err) };
          useUIStore.getState().pushToast({
            title: "Export failed",
            description: String(err),
            variant: "destructive",
          });
        })
        .finally(() => useUIStore.getState().setExportingProgress(null));
    },

    exportStatus() {
      const progress = useUIStore.getState().exportingProgress;
      return { running: progress !== null, progress, lastResult: lastExport };
    },

    cancelExport: () => cancelExport(),
    pathInfo: (path) => agentPathInfo(path),
    writeTextFile: (path, contents, overwrite) => agentWriteTextFile(path, contents, overwrite),
  };
}
