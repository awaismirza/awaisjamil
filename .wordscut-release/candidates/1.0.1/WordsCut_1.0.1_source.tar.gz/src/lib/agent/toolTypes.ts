/** Tool definitions (docs/agent-cli-design.md §5). Pure types and small helpers. */

import type { Project } from "@/lib/edl";
import type { AgentContext, AgentErrorCode, JsonSchema } from "./protocol";

export class ToolError extends Error {
  constructor(
    public code: AgentErrorCode,
    message: string,
    public hint?: string,
  ) {
    super(message);
    this.name = "ToolError";
  }
}

interface ToolBase {
  name: string;
  title: string;
  description: string;
  inputSchema: JsonSchema;
}

export interface EditResult {
  next: Project;
  summary: string;
  details?: Record<string, unknown>;
}

export interface EditTool<I, P = void> extends ToolBase {
  kind: "edit";
  needs?: { media?: boolean; transcript?: boolean };
  prepare?(input: I, ctx: AgentContext): Promise<P>;
  /** Pure. Return `next === project` when there is nothing to do. */
  compute(project: Project, input: I, prep: P): EditResult;
}

export interface ActionTool<I> extends ToolBase {
  kind: "query" | "action";
  mutates: boolean;
  run(input: I, ctx: AgentContext): Promise<Record<string, unknown>>;
}

// The registry stores heterogeneous tools; the per-tool generics are checked where each is defined.
export type AnyTool = EditTool<any, any> | ActionTool<any>;

export interface EditInput {
  confirm?: boolean;
  baseRevision?: number;
}

export const CONFIRM_PROPS: Record<string, JsonSchema> = {
  confirm: {
    type: "boolean",
    default: false,
    description: "false (default) returns a plan only; true applies it as one undo step.",
  },
  baseRevision: {
    type: "integer",
    minimum: 0,
    description:
      "Revision from a previous result. Fails with STALE_REVISION if the project changed since.",
  },
};

export function objectSchema(
  properties: Record<string, JsonSchema> = {},
  required?: string[],
): JsonSchema {
  return {
    type: "object",
    additionalProperties: false,
    properties,
    ...(required && required.length > 0 ? { required } : {}),
  };
}

/** Object schema for a mutating tool: `confirm` and `baseRevision` are added. */
export function editSchema(
  properties: Record<string, JsonSchema> = {},
  required?: string[],
): JsonSchema {
  return objectSchema({ ...properties, ...CONFIRM_PROPS }, required);
}

export const RANGE_SCHEMA: JsonSchema = {
  type: "object",
  additionalProperties: false,
  properties: {
    start: { type: "number", minimum: 0 },
    end: { type: "number", minimum: 0 },
  },
  required: ["start", "end"],
};

export function round3(n: number): number {
  return Math.round(n * 1000) / 1000;
}
