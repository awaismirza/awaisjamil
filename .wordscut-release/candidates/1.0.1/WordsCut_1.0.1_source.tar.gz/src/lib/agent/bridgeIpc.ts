/** Tauri wrappers used by the agent bridge and live context (docs/agent-cli-design.md §2.4). */

import { invoke } from "@tauri-apps/api/core";
import { listen, type UnlistenFn } from "@tauri-apps/api/event";
import {
  AGENT_EVENT_REQUEST,
  type PathInfo,
  type RelayRequest,
  type RelayResponse,
  type ToolCatalogEntry,
} from "./protocol";

export function agentReady(catalog: ToolCatalogEntry[]): Promise<void> {
  return invoke<void>("agent_ready", { catalog });
}

export function agentRespond(response: RelayResponse): Promise<void> {
  return invoke<void>("agent_respond", { response });
}

export function agentPathInfo(path: string): Promise<PathInfo> {
  return invoke<PathInfo>("agent_path_info", { path });
}

export function agentWriteTextFile(
  path: string,
  contents: string,
  overwrite: boolean,
): Promise<void> {
  return invoke<void>("agent_write_text_file", { path, contents, overwrite });
}

export function onAgentRequest(handler: (req: RelayRequest) => void): Promise<UnlistenFn> {
  return listen<RelayRequest>(AGENT_EVENT_REQUEST, (e) => handler(e.payload));
}
