/**
 * Webview side of the agent relay: listens for `agent:request`, runs the tool
 * through the registry against the live context and answers with `agent_respond`.
 */

import { agentReady, agentRespond, onAgentRequest } from "./bridgeIpc";
import { AgentContextError, createLiveContext } from "./liveContext";
import type { AgentErrorCode, RelayRequest, ToolOutcome } from "./protocol";
import { callTool, catalog } from "./registry";

function internalOutcome(tool: string, err: unknown): ToolOutcome {
  if (err instanceof AgentContextError) {
    return { ok: false, tool, error: { code: err.code as AgentErrorCode, message: err.message } };
  }
  const message = err instanceof Error ? err.message : String(err);
  return { ok: false, tool, error: { code: "INTERNAL", message } };
}

/** Starts the bridge; resolves to a disposer that detaches the listener. */
export async function startAgentBridge(): Promise<() => void> {
  const ctx = createLiveContext();

  const handle = async (req: RelayRequest) => {
    let outcome: ToolOutcome;
    try {
      outcome = await callTool(req.name, req.input, ctx);
    } catch (err) {
      outcome = internalOutcome(req.name, err);
    }
    try {
      await agentRespond({ id: req.id, outcome });
    } catch (err) {
      console.error("agent_respond failed", err);
    }
  };

  const unlisten = await onAgentRequest((req) => void handle(req));
  try {
    await agentReady(catalog());
  } catch (err) {
    console.error("agent_ready failed", err);
  }
  return () => unlisten();
}
