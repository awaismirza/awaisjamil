/**
 * Tool registry: catalog, validation, and the plan/apply flow
 * (docs/agent-cli-design.md §4). Pure TS; everything live goes through AgentContext.
 */

import type { Project } from "@/lib/edl";
import type {
  AgentContext,
  AgentError,
  AgentErrorCode,
  JsonSchema,
  ToolCatalogEntry,
  ToolOutcome,
} from "./protocol";
import { appliedOutput, diffProjects, noopOutput, planOutput } from "./plan";
import { validate } from "./schema";
import { ToolError, type AnyTool, type EditTool } from "./toolTypes";
import { captionsExport } from "./tools/captions";
import { chaptersEdit, chaptersSuggest } from "./tools/chapters";
import {
  editBatch,
  editCutFillers,
  editCutRange,
  editCutWords,
  editReplaceText,
  editTrimSilences,
} from "./tools/edit";
import { exportCancel, exportStart, exportStatus } from "./tools/export";
import { history } from "./tools/history";
import { edlGet, projectInfo, projectOpen, projectSave } from "./tools/project";
import { transcriptGet, transcriptSearch } from "./tools/transcript";
import { zoomEdit } from "./tools/zoom";

/** Catalog order follows the numbering in the design doc §3. */
export const TOOLS: readonly AnyTool[] = [
  projectInfo,
  transcriptGet,
  transcriptSearch,
  edlGet,
  chaptersSuggest,
  editCutWords,
  editCutRange,
  editCutFillers,
  editTrimSilences,
  editReplaceText,
  chaptersEdit,
  zoomEdit,
  editBatch,
  history,
  projectOpen,
  projectSave,
  captionsExport,
  exportStart,
  exportStatus,
  exportCancel,
];

/** Responses larger than this are trimmed and flagged `truncated:true`. */
export const MAX_RESPONSE_BYTES = 4 * 1024 * 1024;

export function findTool(name: string): AnyTool | undefined {
  return TOOLS.find((t) => t.name === name);
}

function acceptsConfirm(schema: JsonSchema): boolean {
  return Object.hasOwn(schema.properties ?? {}, "confirm");
}

export function catalog(): ToolCatalogEntry[] {
  return TOOLS.map((t) => ({
    name: t.name,
    title: t.title,
    description: t.description,
    mutates: acceptsConfirm(t.inputSchema),
    ...(t.name === "export_start" ? { longRunning: true } : {}),
    inputSchema: t.inputSchema,
  }));
}

export function describeTool(name: string): ToolCatalogEntry | undefined {
  return catalog().find((t) => t.name === name);
}

function fail(tool: string, code: AgentErrorCode, message: string, hint?: string): ToolOutcome {
  const error: AgentError = { code, message, ...(hint ? { hint } : {}) };
  return { ok: false, tool, error };
}

function capSize(data: Record<string, unknown>): Record<string, unknown> {
  const size = (v: unknown) => JSON.stringify(v).length;
  if (size(data) <= MAX_RESPONSE_BYTES) return data;
  const out: Record<string, unknown> = { ...data };
  for (let guard = 0; guard < 64 && size(out) > MAX_RESPONSE_BYTES; guard++) {
    let key: string | null = null;
    let biggest = 0;
    for (const [k, v] of Object.entries(out)) {
      if (Array.isArray(v) && v.length > 1) {
        const n = size(v);
        if (n > biggest) {
          biggest = n;
          key = k;
        }
      }
    }
    if (!key) break;
    const arr = out[key] as unknown[];
    out[key] = arr.slice(0, Math.floor(arr.length / 2));
  }
  if (size(out) > MAX_RESPONSE_BYTES)
    return { truncated: true, note: "Response too large to return" };
  return { ...out, truncated: true };
}

function ok(tool: string, data: Record<string, unknown>): ToolOutcome {
  return { ok: true, tool, data: capSize(data) };
}

function needsProblem(tool: EditTool<unknown, unknown>, project: Project): ToolError | null {
  if (tool.needs?.media && Object.keys(project.media).length === 0)
    return new ToolError("NO_MEDIA", "The project has no media");
  if (tool.needs?.transcript && !project.segments.some((s) => s.words.length > 0))
    return new ToolError(
      "NO_TRANSCRIPT",
      "The project has no transcript",
      "Transcribe the media in the editor first.",
    );
  return null;
}

async function runEdit(
  tool: EditTool<Record<string, unknown>, unknown>,
  input: Record<string, unknown> & { confirm?: boolean; baseRevision?: number },
  ctx: AgentContext,
): Promise<ToolOutcome> {
  const busy = ctx.busyReason();
  if (busy)
    return fail(tool.name, "BUSY", `Editor is busy: ${busy}`, "Retry when the editor is idle.");

  const start = ctx.getProject();
  if (start.segments.length === 0 && Object.keys(start.media).length === 0)
    return fail(tool.name, "NO_PROJECT", "No project is open", "Call project_open first.");
  const problem = needsProblem(tool, start);
  if (problem) return fail(tool.name, problem.code, problem.message, problem.hint);

  const stale = (): ToolOutcome | null =>
    input.baseRevision !== undefined && input.baseRevision !== ctx.revision()
      ? fail(
          tool.name,
          "STALE_REVISION",
          `The project changed since revision ${input.baseRevision} (now ${ctx.revision()})`,
          "Re-read the project, re-plan, and retry with the new revision.",
        )
      : null;
  const staleNow = stale();
  if (staleNow) return staleNow;

  const prep = tool.prepare ? await tool.prepare(input, ctx) : undefined;

  // Preparation may be slow (silence detection); re-check before computing.
  const staleAfter = stale();
  if (staleAfter) return staleAfter;
  const before = ctx.getProject();
  const { next, summary, details } = tool.compute(before, input, prep);

  const diff = diffProjects(before, next);
  if (next === before) return ok(tool.name, noopOutput(ctx.revision(), diff, details));
  if (input.confirm !== true)
    return ok(tool.name, planOutput({ summary, revision: ctx.revision(), diff, details }));

  const revision = await ctx.applyProject(next, summary);
  return ok(tool.name, appliedOutput({ summary, revision, diff, details }));
}

/** Run a tool. Never throws: every failure becomes `{ok:false}`. */
export async function callTool(
  name: string,
  input: unknown,
  ctx: AgentContext,
): Promise<ToolOutcome> {
  const tool = findTool(name);
  if (!tool)
    return fail(
      name,
      "UNKNOWN_TOOL",
      `Unknown tool: ${name}`,
      "Use tool list to see available tools.",
    );

  const checked = validate(tool.inputSchema, input ?? {});
  if (!checked.ok)
    return fail(name, "INVALID_INPUT", `${checked.pointer || "/"}: ${checked.message}`);
  const value = checked.value as Record<string, unknown>;

  try {
    if (tool.kind === "edit")
      return await runEdit(tool as EditTool<Record<string, unknown>, unknown>, value, ctx);
    return ok(name, await tool.run(value, ctx));
  } catch (e) {
    if (e instanceof ToolError) return fail(name, e.code, e.message, e.hint);
    return fail(name, "INTERNAL", e instanceof Error ? e.message : String(e));
  }
}
