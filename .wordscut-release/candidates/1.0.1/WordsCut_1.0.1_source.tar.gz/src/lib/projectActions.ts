/** App-level project actions shared by the Toolbar and the agent bridge. */

import { loadProject } from "@/lib/ipc";
import { addRecentProject } from "@/lib/recentProjects";
import { backfillChecksums, checkMissingMedia, refreshMediaSizes } from "@/lib/relink";
import { cacheProjectTranscripts } from "@/lib/transcriptCache";
import { usePlayerStore } from "@/stores/playerStore";
import { replaceProjectBaseline } from "@/stores/projectStore";
import { useUIStore } from "@/stores/uiStore";

export const MEDIA_EXTENSIONS = ["mp4", "mov", "m4v", "mkv", "webm", "m4a", "wav"];

/**
 * Load a `.scribe` project as the new baseline (not undoable), reset the player,
 * remember it in the recent list and toast. Shows the media-loading dialog while
 * it runs. Rejects with the loader's error; the caller decides how to report it.
 */
export async function openProjectAtPath(path: string): Promise<void> {
  const ui = useUIStore.getState();
  ui.setMediaLoading(true);
  try {
    const loaded = await loadProject(path);
    cacheProjectTranscripts(loaded);
    replaceProjectBaseline(loaded, { dirty: false, filePath: path });
    usePlayerStore.getState().reset();
    addRecentProject(path);
    useUIStore.getState().pushToast({ title: "Project opened", description: path });
    await checkMissingMedia(loaded);
    // Sources saved without a checksum get one in the background (mask matching).
    void backfillChecksums(loaded);
    // Stale stored sizes (rotated clips from older builds) are corrected in the background.
    void refreshMediaSizes(loaded).then((n) => {
      if (n > 0)
        useUIStore.getState().pushToast({
          title: "Picture sizes updated",
          description: `${n} source(s) had a stored size that no longer matched the file (e.g. a rotated phone clip). Check masks, zoom and Look before exporting.`,
        });
    });
  } finally {
    useUIStore.getState().setMediaLoading(false);
  }
}
