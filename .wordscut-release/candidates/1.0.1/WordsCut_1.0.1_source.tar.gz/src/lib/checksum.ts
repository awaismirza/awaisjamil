/**
 * A media checksum is a lower-case hex SHA-256. The empty string is the
 * project's "no checksum recorded" value: projects saved before hashing, and a
 * fresh recording between insertion and its background hash. Code that keys or
 * matches on a checksum must treat "" as absent, never as a value two files
 * could share (the same rule as `sameFile` in masks.ts and `same_file` in
 * layers_export.rs).
 */
const SHA256 = /^[0-9a-f]{64}$/;

/** A well-formed checksum value, for accepting a newly computed one. */
export function isChecksum(value: unknown): value is string {
  return typeof value === "string" && SHA256.test(value);
}

/** Is a checksum recorded on this media entry? */
export function hasChecksum(media: { sha256?: string } | undefined | null): boolean {
  return typeof media?.sha256 === "string" && media.sha256.length > 0;
}
