import type { Segment, Word } from "./edl";
import { entryOutputAt } from "./timeMap";

/** Gap (ms) between two words that starts a new paragraph. */
export const PARAGRAPH_PAUSE_MS = 750;

export interface LayoutPause {
  id: string;
  start: number;
  deleted?: boolean;
}

export type LayoutToken<P extends LayoutPause> =
  | { kind: "word"; word: Word }
  | { kind: "pause"; pause: P };

export interface LayoutParagraph<P extends LayoutPause> {
  tokens: LayoutToken<P>[];
  words: Word[];
  segmentId: string;
}

/**
 * Lay the transcript out in OUTPUT order: segment by segment, never by source
 * time. Words of a clip appended later (a recording, an added file) therefore
 * stay at the end instead of interleaving with earlier clips that share the
 * same source timestamps. A clip boundary always starts a new paragraph.
 *
 * Pauses are detected on one media only (`pauseMediaId`); each is anchored to
 * the last word of its segment that starts before it (start times, never end
 * times: Whisper stretches word ends over the silence that follows them).
 */
export function layoutTranscript<P extends LayoutPause>(
  segments: readonly Segment[],
  pauses: readonly P[],
  pauseMediaId: string | undefined,
): LayoutParagraph<P>[] {
  const paragraphs: LayoutParagraph<P>[] = [];
  const seenPauses = new Set<string>();
  const live = pauses.filter((p) => !p.deleted);

  for (const segment of segments) {
    let current: LayoutParagraph<P> | null = null;
    let last: Word | null = null;
    const open = () => {
      current = { tokens: [], words: [], segmentId: segment.id };
      paragraphs.push(current);
      return current;
    };
    const stream: Array<{ start: number; order: 0 | 1; token: LayoutToken<P> }> = [];
    for (const word of segment.words)
      stream.push({ start: word.start, order: 0, token: { kind: "word", word } });
    if (segment.mediaId === pauseMediaId) {
      for (const pause of live) {
        if (seenPauses.has(pause.id)) continue;
        if (pause.start < segment.sourceIn || pause.start >= segment.sourceOut) continue;
        seenPauses.add(pause.id);
        stream.push({ start: pause.start, order: 1, token: { kind: "pause", pause } });
      }
    }
    stream.sort((a, b) => a.start - b.start || a.order - b.order);

    for (const { token } of stream) {
      if (token.kind === "word") {
        const word = token.word;
        const gapMs = last ? (word.start - last.end) * 1000 : 0;
        const endsSentence = last ? /[.?!]$/.test(last.text.trim()) : false;
        const target: LayoutParagraph<P> =
          !current || gapMs >= PARAGRAPH_PAUSE_MS || endsSentence ? open() : current;
        target.tokens.push(token);
        target.words.push(word);
        last = word;
      } else {
        (current ?? paragraphs[paragraphs.length - 1])?.tokens.push(token);
      }
    }
  }
  return paragraphs.filter((p) => p.words.length > 0);
}

/**
 * Word id -> zoom region id for every word whose output span overlaps a zoom
 * region. One pass over the timeline, regions sorted by start, so it stays
 * cheap on long transcripts.
 */
export function zoomWordMap(
  entries: readonly {
    segment?: Segment;
    outputStart: number;
    sourceIn: number;
    speed?: number;
  }[],
  regions: readonly { id: string; start: number; end: number }[],
): Map<string, string> {
  const map = new Map<string, string>();
  if (!regions.length) return map;
  const sorted = [...regions].sort((a, b) => a.start - b.start);
  for (const entry of entries) {
    if (!entry.segment) continue;
    for (const word of entry.segment.words) {
      const start = entryOutputAt(entry, Math.max(entry.sourceIn, word.start));
      const end = entryOutputAt(entry, Math.max(entry.sourceIn, word.end));
      const hit = sorted.find((r) => start < r.end && end > r.start);
      if (hit) map.set(word.id, hit.id);
    }
  }
  return map;
}
