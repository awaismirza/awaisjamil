/**
 * The "scene" around the video: background, padding, rounded corners, shadow
 * and output aspect. Pure module (no React, Tauri or store imports, same rule
 * as edl.ts).
 *
 * `sceneLayout` is the single source of truth for geometry. The live preview
 * scales its numbers to the preview size and the exporter receives them
 * resolved (`resolveSceneForExport`), so what you see is what is exported.
 */

import type { Project, SourceMedia } from "./edl";
import { layoutFrame, sanitizeFrame, type DeviceFrame, type FrameLayout } from "./deviceFrame";

export * from "./deviceFrame";

/**
 * The media whose frames enter the scene: the first segment's (what the
 * exporter feeds it), else the first imported. They differ when the clip
 * imported first is not the one the edit starts with.
 */
export function sceneSourceMedia(p: Pick<Project, "segments" | "media">): SourceMedia | undefined {
  const id = p.segments[0]?.mediaId;
  return (id ? p.media[id] : undefined) ?? Object.values(p.media)[0];
}

export const SCENE_ASPECTS = ["source", "16:9", "9:16", "1:1", "4:3"] as const;
export type SceneAspect = (typeof SCENE_ASPECTS)[number];

export type SceneBackground =
  | { kind: "solid"; color: string }
  /** `angle` is CSS-style: 0 = towards the top, 90 = towards the right. */
  | { kind: "gradient"; from: string; to: string; angle: number }
  | { kind: "image"; path: string }
  /** No backdrop: the preview shows a checkerboard; only alpha-capable export formats keep it. */
  | { kind: "transparent" };

/** A rectangle of the source picture, as fractions (0-1) of its width and height. */
export interface CropRect {
  x: number;
  y: number;
  w: number;
  h: number;
}

/** Smallest crop side, as a fraction of the source. */
export const CROP_MIN = 0.05;

export interface SceneSettings {
  enabled: boolean;
  aspect: SceneAspect;
  background: SceneBackground;
  /** Space around the video, as a percentage of the canvas's shorter side. */
  paddingPct: number;
  /** Corner radius, as a percentage of the video's shorter side. */
  radiusPct: number;
  /** Shadow strength, 0 (none) to 1. */
  shadow: number;
  /** Part of the source kept, applied before padding and layout. Absent = whole picture. */
  crop?: CropRect;
  /**
   * Device drawn around the picture. Absent = none. The scene's corner radius
   * and shadow then belong to the device (its outline), not to the picture.
   */
  frame?: DeviceFrame;
}

export const PADDING_MAX_PCT = 30;
export const RADIUS_MAX_PCT = 30;

/** Canvas height used for the output when the user has not chosen a size. */
export const BASE_CANVAS_HEIGHT = 1080;

export interface ScenePreset {
  id: string;
  name: string;
  background: SceneBackground;
}

/** Built-in backdrops. Gradients, so the app ships no image files. */
export const SCENE_PRESETS: readonly ScenePreset[] = [
  {
    id: "graphite",
    name: "Graphite",
    background: { kind: "gradient", from: "#232526", to: "#414345", angle: 160 },
  },
  {
    id: "midnight",
    name: "Midnight",
    background: { kind: "gradient", from: "#0f0c29", to: "#302b63", angle: 145 },
  },
  {
    id: "aurora",
    name: "Aurora",
    background: { kind: "gradient", from: "#5b3df5", to: "#19d3da", angle: 135 },
  },
  {
    id: "ocean",
    name: "Ocean",
    background: { kind: "gradient", from: "#2b5876", to: "#4e4376", angle: 160 },
  },
  {
    id: "forest",
    name: "Forest",
    background: { kind: "gradient", from: "#134e5e", to: "#71b280", angle: 150 },
  },
  {
    id: "sunset",
    name: "Sunset",
    background: { kind: "gradient", from: "#f6d365", to: "#fda085", angle: 135 },
  },
  {
    id: "lavender",
    name: "Lavender",
    background: { kind: "gradient", from: "#a18cd1", to: "#fbc2eb", angle: 120 },
  },
  {
    id: "peach",
    name: "Peach",
    background: { kind: "gradient", from: "#ffecd2", to: "#fcb69f", angle: 135 },
  },
  { id: "ink", name: "Ink", background: { kind: "solid", color: "#0f0f12" } },
  { id: "paper", name: "Paper", background: { kind: "solid", color: "#f4efe6" } },
  { id: "white", name: "White", background: { kind: "solid", color: "#ffffff" } },
  { id: "blue", name: "Blue", background: { kind: "solid", color: "#1d4ed8" } },
  { id: "transparent", name: "Transparent", background: { kind: "transparent" } },
];

export function defaultScene(): SceneSettings {
  return {
    enabled: false,
    aspect: "source",
    background: { ...SCENE_PRESETS[0]!.background } as SceneBackground,
    paddingPct: 8,
    radiusPct: 3,
    shadow: 0.6,
  };
}

// ---------------------------------------------------------------------------
// Tolerant loading
// ---------------------------------------------------------------------------

const HEX = /^#[0-9a-fA-F]{6}$/;

function clamp(n: number, lo: number, hi: number) {
  return Math.min(hi, Math.max(lo, n));
}

function num(v: unknown, fallback: number, lo: number, hi: number): number {
  return typeof v === "number" && Number.isFinite(v) ? clamp(v, lo, hi) : fallback;
}

function color(v: unknown, fallback: string): string {
  return typeof v === "string" && HEX.test(v) ? v.toLowerCase() : fallback;
}

function sanitizeBackground(raw: unknown, fallback: SceneBackground): SceneBackground {
  if (typeof raw !== "object" || raw === null) return fallback;
  const b = raw as Record<string, unknown>;
  if (b.kind === "solid") return { kind: "solid", color: color(b.color, "#0f0f12") };
  if (b.kind === "gradient") {
    return {
      kind: "gradient",
      from: color(b.from, "#232526"),
      to: color(b.to, "#414345"),
      angle: num(b.angle, 135, 0, 360),
    };
  }
  if (b.kind === "transparent") return { kind: "transparent" };
  if (b.kind === "image" && typeof b.path === "string" && b.path.length > 0) {
    return { kind: "image", path: b.path };
  }
  return fallback;
}

const round4 = (n: number) => Math.round(n * 10000) / 10000;

/** A valid crop, or undefined when it is missing, malformed or covers the whole picture. */
export function sanitizeCrop(raw: unknown): CropRect | undefined {
  if (typeof raw !== "object" || raw === null) return undefined;
  const c = raw as Record<string, unknown>;
  if (![c.x, c.y, c.w, c.h].every((v) => typeof v === "number" && Number.isFinite(v)))
    return undefined;
  const w = clamp(c.w as number, CROP_MIN, 1);
  const h = clamp(c.h as number, CROP_MIN, 1);
  const x = clamp(c.x as number, 0, 1 - w);
  const y = clamp(c.y as number, 0, 1 - h);
  if (x < 0.0005 && y < 0.0005 && w > 0.9995 && h > 0.9995) return undefined;
  return { x: round4(x), y: round4(y), w: round4(w), h: round4(h) };
}

/**
 * Make any stored value into a valid scene. Missing or malformed fields take
 * their defaults, so an old or hand-edited project file can never break the
 * preview or the export.
 */
export function sanitizeScene(raw: unknown): SceneSettings {
  const d = defaultScene();
  if (typeof raw !== "object" || raw === null) return d;
  const r = raw as Record<string, unknown>;
  const crop = sanitizeCrop(r.crop);
  const frame = sanitizeFrame(r.frame);
  return {
    ...(crop ? { crop } : {}),
    ...(frame ? { frame } : {}),
    enabled: r.enabled === true,
    aspect: SCENE_ASPECTS.includes(r.aspect as SceneAspect) ? (r.aspect as SceneAspect) : d.aspect,
    background: sanitizeBackground(r.background, d.background),
    paddingPct: num(r.paddingPct, d.paddingPct, 0, PADDING_MAX_PCT),
    radiusPct: num(r.radiusPct, d.radiusPct, 0, RADIUS_MAX_PCT),
    shadow: num(r.shadow, d.shadow, 0, 1),
  };
}

// ---------------------------------------------------------------------------
// Geometry
// ---------------------------------------------------------------------------

export interface Size {
  w: number;
  h: number;
}

/** Round to the nearest even integer, at least 2: video encoders need even sizes. */
export function even(n: number): number {
  return Math.max(2, Math.round(n / 2) * 2);
}

const ASPECT_RATIOS: Record<Exclude<SceneAspect, "source">, number> = {
  "16:9": 16 / 9,
  "9:16": 9 / 16,
  "1:1": 1,
  "4:3": 4 / 3,
};

/**
 * The largest centred crop with the given width:height ratio, in source
 * pixels, as fractions. Null when the ratio already matches the whole frame.
 */
export function cropForRatio(ratio: number, source: Size): CropRect | null {
  const srcRatio = source.w / source.h;
  if (!(ratio > 0) || Math.abs(srcRatio - ratio) < 1e-3) return null;
  const w = srcRatio > ratio ? ratio / srcRatio : 1;
  const h = srcRatio > ratio ? 1 : srcRatio / ratio;
  return { x: (1 - w) / 2, y: (1 - h) / 2, w, h };
}

export interface CropPx {
  x: number;
  y: number;
  w: number;
  h: number;
}

/**
 * The crop in whole source pixels with even offsets and size (4:2:0 video
 * needs them). Preview and export both use this, so they cut the same pixels.
 */
export function cropPixels(crop: CropRect, source: Size): CropPx {
  const sw = Math.max(2, Math.floor(source.w / 2) * 2);
  const sh = Math.max(2, Math.floor(source.h / 2) * 2);
  const w = Math.min(even(crop.w * source.w), sw);
  const h = Math.min(even(crop.h * source.h), sh);
  const x = Math.min(Math.round((crop.x * source.w) / 2) * 2, sw - w);
  const y = Math.min(Math.round((crop.y * source.h) / 2) * 2, sh - h);
  return { x, y, w, h };
}

/** Output canvas for an aspect. "source" keeps the source size. */
export function canvasSize(
  aspect: SceneAspect,
  source: Size,
  baseHeight = BASE_CANVAS_HEIGHT,
): Size {
  if (aspect === "source") return { w: even(source.w), h: even(source.h) };
  const ratio = ASPECT_RATIOS[aspect];
  // Portrait uses the base as its width so 9:16 is 1080x1920, not 608x1080.
  return ratio >= 1
    ? { w: even(baseHeight * ratio), h: even(baseHeight) }
    : { w: even(baseHeight), h: even(baseHeight / ratio) };
}

export interface SceneLayout {
  canvasW: number;
  canvasH: number;
  content: { x: number; y: number; w: number; h: number };
  radiusPx: number;
  shadow: { sigmaPx: number; opacity: number; offsetY: number };
  /** Source pixels kept (undefined = the whole picture). */
  crop?: CropPx;
  /** Device around the picture (preview and export draw these same shapes). */
  frame?: FrameLayout;
}

/**
 * Where the video sits on the canvas. The video keeps its own aspect, fits
 * inside the padded area and is centred. `canvas` overrides the default size
 * (used when the user picks an export resolution).
 */
export function sceneLayout(scene: SceneSettings, fullSource: Size, canvas?: Size): SceneLayout {
  // Everything below sees the cropped picture, so "Original" aspect and the
  // letterboxing follow the crop (a portrait crop of a landscape clip is portrait).
  const crop = scene.crop ? cropPixels(scene.crop, fullSource) : undefined;
  const source: Size = crop ? { w: crop.w, h: crop.h } : fullSource;
  const c = canvas ?? canvasSize(scene.aspect, source);
  const minSide = Math.min(c.w, c.h);
  const pad = (scene.paddingPct / 100) * minSide;
  const availW = Math.max(2, c.w - 2 * pad);
  const availH = Math.max(2, c.h - 2 * pad);

  const sourceRatio = source.w / source.h;
  let w = availW;
  let h = w / sourceRatio;
  if (h > availH) {
    h = availH;
    w = h * sourceRatio;
  }
  w = Math.min(even(w), c.w);
  h = Math.min(even(h), c.h);

  let x = Math.round((c.w - w) / 2);
  let y = Math.round((c.h - h) / 2);
  let radiusPx = Math.min((scene.radiusPct / 100) * Math.min(w, h), Math.min(w, h) / 2);
  const sigmaPx = scene.shadow * 0.025 * minSide;

  // A device frame replaces the plain rounded box: it is fitted into the padded
  // area, and the picture sits inside its screen (clipped by the screen's corners).
  let frame: FrameLayout | undefined;
  if (scene.frame) {
    const f = layoutFrame(scene.frame, sourceRatio, { w: availW, h: availH }, c);
    frame = f.frame;
    ({ x, y, w, h } = f.content);
    radiusPx = 0;
  }

  return {
    canvasW: c.w,
    canvasH: c.h,
    content: { x, y, w, h },
    ...(crop ? { crop } : {}),
    ...(frame ? { frame } : {}),
    radiusPx,
    shadow: {
      sigmaPx,
      opacity: scene.shadow === 0 ? 0 : 0.15 + 0.55 * scene.shadow,
      offsetY: sigmaPx * 0.8,
    },
  };
}

/** The endpoints of a CSS-style gradient line on a canvas, as ffmpeg's `gradients` filter wants them. */
export function gradientLine(w: number, h: number, angleDeg: number) {
  const a = (angleDeg * Math.PI) / 180;
  const dx = Math.sin(a);
  const dy = -Math.cos(a);
  // CSS gradient length: the line that just reaches the corners.
  const length = Math.abs(w * dx) + Math.abs(h * dy);
  const cx = w / 2;
  const cy = h / 2;
  return {
    x0: cx - (dx * length) / 2,
    y0: cy - (dy * length) / 2,
    x1: cx + (dx * length) / 2,
    y1: cy + (dy * length) / 2,
  };
}

// ---------------------------------------------------------------------------
// Export payload
// ---------------------------------------------------------------------------

export type ResolvedBackground =
  | { kind: "solid"; color: string }
  | { kind: "gradient"; from: string; to: string; x0: number; y0: number; x1: number; y1: number }
  | { kind: "image"; path: string }
  | { kind: "transparent" };

/** Everything the exporter needs, in pixels. No further maths on the Rust side. */
export interface SceneRender {
  canvasW: number;
  canvasH: number;
  contentX: number;
  contentY: number;
  contentW: number;
  contentH: number;
  radiusPx: number;
  shadowSigmaPx: number;
  shadowOpacity: number;
  shadowOffsetY: number;
  background: ResolvedBackground;
  /** Source pixels to keep, cut before the picture is scaled onto the canvas. */
  crop?: CropPx;
  /** Device shapes in canvas pixels; absent = no device. */
  frame?: Omit<FrameLayout, "outer">;
}

/** Does the scene leave the area around the picture transparent? */
export function sceneTransparent(scene: SceneSettings | undefined): boolean {
  return sceneActive(scene) && scene.background.kind === "transparent";
}

/** Is there anything to draw? A disabled scene exports exactly as before. */
export function sceneActive(scene: SceneSettings | undefined): scene is SceneSettings {
  return !!scene && scene.enabled;
}

export function resolveSceneForExport(
  scene: SceneSettings,
  source: Size,
  canvas?: Size,
): SceneRender {
  const l = sceneLayout(scene, source, canvas);
  const bg = scene.background;
  const background: ResolvedBackground =
    bg.kind === "gradient"
      ? {
          kind: "gradient",
          from: bg.from,
          to: bg.to,
          ...gradientLine(l.canvasW, l.canvasH, bg.angle),
        }
      : bg;
  return {
    canvasW: l.canvasW,
    canvasH: l.canvasH,
    contentX: l.content.x,
    contentY: l.content.y,
    contentW: l.content.w,
    contentH: l.content.h,
    radiusPx: l.radiusPx,
    shadowSigmaPx: l.shadow.sigmaPx,
    shadowOpacity: l.shadow.opacity,
    shadowOffsetY: l.shadow.offsetY,
    background,
    ...(l.crop ? { crop: l.crop } : {}),
    ...(l.frame
      ? {
          frame: {
            screen: l.frame.screen,
            screenRadii: l.frame.screenRadii,
            below: l.frame.below,
            above: l.frame.above,
            texts: l.frame.texts,
          },
        }
      : {}),
  };
}
