/**
 * StatusBar — bottom strip showing the active model, transcript metrics, and
 * the current / total timecode. Mirrors the design's footer chrome:
 *
 *   ● CoreML active · whisper-large-v3 · 1,124 words · 17 fillers · 4 deleted
 *                                                         Ready · 00:42.18 / 4:21.05
 */

import { useUIStore } from "@/stores/uiStore";
import { useMemo } from "react";
import { useProjectStore } from "@/stores/projectStore";
import { usePlayerStore } from "@/stores/playerStore";
import { totalDuration } from "@/lib/edl";
import { formatTimecode } from "@/lib/timecode";
import { findFillersInSegments } from "@/lib/fillers";
import { useFillerStore } from "@/stores/fillerStore";
import { JobsFlyout } from "@/components/StatusBar/JobsFlyout";

export function StatusBar() {
  const mediaLoading = useUIStore((s) => s.mediaLoading);
  const background = useUIStore((s) => s.backgroundTranscriptions);
  const recordingProgress = Object.values(background);
  const project = useProjectStore((s) => s.project);
  const dirty = useProjectStore((s) => s.dirty);
  const currentTime = usePlayerStore((s) => s.currentTime);

  const selectedFillers = useFillerStore((s) => s.selected);
  const { wordCount, fillerCount } = useMemo(() => {
    const words = project.segments.reduce((n, seg) => n + seg.words.length, 0);
    const fillers = findFillersInSegments(project.segments, selectedFillers).length;
    return { wordCount: words, fillerCount: fillers };
  }, [project, selectedFillers]);

  const duration = totalDuration(project);

  return (
    <div className="yusafcut-statusbar">
      <JobsFlyout />
      <span className="sep">·</span>
      <span className="chip">
        <span className="pulse" />
        CoreML active
      </span>
      <span className="sep">·</span>
      {mediaLoading ? (
        <span role="status">Opening media…</span>
      ) : recordingProgress.length > 0 ? (
        <span role="status">
          Recording ready · transcribing{" "}
          {Math.round(
            (recordingProgress.reduce((a, b) => a + b, 0) / recordingProgress.length) * 100,
          )}
          % · editing available
        </span>
      ) : (
        <span>Local transcription</span>
      )}
      {wordCount > 0 && (
        <>
          <span className="sep">·</span>
          <span>
            {wordCount.toLocaleString()} {wordCount === 1 ? "word" : "words"}
          </span>
          <span className="sep">·</span>
          <span>
            {fillerCount} filler{fillerCount === 1 ? "" : "s"}
          </span>
        </>
      )}
      <div className="spacer" />
      <span>{dirty ? "Unsaved" : "Ready"}</span>
      <span className="sep">·</span>
      <span>
        {formatTimecode(currentTime, { ms: false })}
        <span style={{ opacity: 0.5 }}> / </span>
        {formatTimecode(duration, { ms: false })}
      </span>
    </div>
  );
}
