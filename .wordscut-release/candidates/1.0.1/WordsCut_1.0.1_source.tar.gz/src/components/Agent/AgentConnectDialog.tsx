/**
 * "Project MCP Server" dialog: turn local agent access on or off and copy the
 * CLI / MCP connection details for Claude Code, Codex, Gemini CLI or any HTTP client.
 * Design: docs/agent-cli-design.md §9. All text comes from `connectSnippets`.
 */

import { useCallback, useEffect, useState } from "react";
import { Bot, Check, Copy, Eye, EyeOff, RefreshCw, TerminalSquare, Plug } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import type { ServerInfo } from "@/lib/agent/protocol";
import { agentRegenerateToken, agentServerInfo, agentSetEnabled } from "@/lib/agent/serverIpc";
import {
  cliExamples,
  cliStartCommand,
  clientSnippets,
  httpHeader,
  maskToken,
  type ClientId,
} from "@/lib/agent/connectSnippets";
import { cn } from "@/lib/utils";
import { useProjectStore } from "@/stores/projectStore";
import { useUIStore } from "@/stores/uiStore";

type Tab = "cli" | "mcp";

const CLIENTS: { id: ClientId; label: string }[] = [
  { id: "claude", label: "Claude Code" },
  { id: "codex", label: "Codex" },
  { id: "gemini", label: "Gemini CLI" },
  { id: "other", label: "Other (HTTP)" },
];

function CopyButton({ text, label }: { text: string; label: string }) {
  const [done, setDone] = useState(false);
  const pushToast = useUIStore((s) => s.pushToast);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(text);
      setDone(true);
      pushToast({ title: "Copied to clipboard" });
      setTimeout(() => setDone(false), 1500);
    } catch {
      pushToast({ title: "Copy failed", variant: "destructive" });
    }
  };
  return (
    <Button
      type="button"
      size="sm"
      variant="ghost"
      className="h-7 shrink-0 gap-1 px-2 text-xs"
      aria-label={`Copy ${label}`}
      onClick={() => void copy()}
    >
      {done ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
      {done ? "Copied" : "Copy"}
    </Button>
  );
}

function CodeRow({ label, hint, text }: { label: string; hint?: string; text: string }) {
  return (
    <div className="grid gap-1">
      <div className="flex items-center justify-between gap-2">
        <div className="min-w-0 text-xs font-medium">
          {label}
          {hint && <span className="ml-2 font-normal text-muted-foreground">{hint}</span>}
        </div>
        <CopyButton text={text} label={label} />
      </div>
      <pre className="max-h-40 overflow-auto whitespace-pre-wrap break-all rounded-md border bg-muted/50 px-3 py-2 font-mono text-xs leading-relaxed">
        {text}
      </pre>
    </div>
  );
}

function StatusPill({ info }: { info: ServerInfo | null }) {
  let text = "Loading…";
  let tone = "bg-muted text-muted-foreground";
  let dot = "bg-muted-foreground/60";
  if (info) {
    if (!info.available) {
      text = "Unavailable";
      tone = "bg-amber-500/15 text-amber-600 dark:text-amber-400";
      dot = "bg-amber-500";
    } else if (info.running) {
      text = `Running · 127.0.0.1:${info.port ?? "?"}`;
      tone = "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400";
      dot = "bg-emerald-500";
    } else {
      text = "Off";
    }
  }
  return (
    <span
      data-testid="agent-status"
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium",
        tone,
      )}
    >
      <span className={cn("h-1.5 w-1.5 rounded-full", dot)} />
      {text}
    </span>
  );
}

function Segmented<T extends string>({
  label,
  value,
  onChange,
  options,
}: {
  label: string;
  value: T;
  onChange: (v: T) => void;
  options: { id: T; label: string; icon?: React.ReactNode }[];
}) {
  return (
    <div
      role="tablist"
      aria-label={label}
      className="grid auto-cols-fr grid-flow-col gap-1 rounded-lg bg-muted p-1"
    >
      {options.map((o) => (
        <button
          key={o.id}
          type="button"
          role="tab"
          aria-selected={value === o.id}
          onClick={() => onChange(o.id)}
          className={cn(
            "inline-flex items-center justify-center gap-1.5 rounded-md px-2 py-1.5 text-xs font-medium transition-colors",
            value === o.id
              ? "bg-background text-foreground shadow-sm"
              : "text-muted-foreground hover:text-foreground",
          )}
        >
          {o.icon}
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function AgentConnectDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const filePath = useProjectStore((s) => s.filePath);
  const pushToast = useUIStore((s) => s.pushToast);
  const [info, setInfo] = useState<ServerInfo | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [tab, setTab] = useState<Tab>("cli");
  const [client, setClient] = useState<ClientId>("claude");
  const [reveal, setReveal] = useState(false);

  useEffect(() => {
    if (!open) return;
    let cancelled = false;
    setReveal(false);
    agentServerInfo().then(
      (i) => {
        if (!cancelled) {
          setInfo(i);
          setError(null);
        }
      },
      (e) => !cancelled && setError(String(e)),
    );
    return () => {
      cancelled = true;
    };
  }, [open]);

  const run = useCallback(
    async (fn: () => Promise<ServerInfo>) => {
      setBusy(true);
      try {
        setInfo(await fn());
        setError(null);
      } catch (e) {
        setError(String(e));
        pushToast({ title: "Agent server error", description: String(e), variant: "destructive" });
      } finally {
        setBusy(false);
      }
    },
    [pushToast],
  );

  const available = info?.available ?? false;
  const enabled = info?.enabled ?? false;
  const bin = info?.binaryPath ?? "";
  const token = info?.token ?? null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[88vh] max-w-[560px] gap-4 overflow-y-auto p-5">
        <DialogHeader className="space-y-2">
          <DialogTitle className="flex items-center gap-2 pr-6 text-base">
            <Bot className="h-4 w-4" />
            Project MCP Server
            <span className="ml-auto">
              <StatusPill info={info} />
            </span>
          </DialogTitle>
          <DialogDescription className="text-xs">
            Let AI CLIs edit this project while WordsCut is open. Local only: while on, any app
            running as you can connect.
          </DialogDescription>
        </DialogHeader>

        <div className="flex items-center justify-between gap-3 rounded-lg border px-3 py-2.5">
          <div className="min-w-0">
            <div id="agent-access-label" className="text-sm font-medium">
              Allow agent access
            </div>
            <div className="text-xs text-muted-foreground">
              {info && !info.available
                ? (info.unavailableReason ?? "Not available in this build")
                : "Starts a local server on 127.0.0.1 with a private token."}
            </div>
          </div>
          <button
            type="button"
            role="switch"
            aria-checked={enabled}
            aria-labelledby="agent-access-label"
            disabled={!available || busy}
            onClick={() => void run(() => agentSetEnabled(!enabled))}
            className={cn(
              "relative h-6 w-11 shrink-0 rounded-full transition-colors disabled:cursor-not-allowed disabled:opacity-50",
              enabled ? "bg-primary" : "bg-muted-foreground/30",
            )}
          >
            <span
              className={cn(
                "absolute left-0.5 top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform",
                enabled && "translate-x-5",
              )}
            />
          </button>
        </div>

        {error && (
          <p role="alert" className="text-xs text-destructive">
            {error}
          </p>
        )}

        <Segmented<Tab>
          label="Connection type"
          value={tab}
          onChange={setTab}
          options={[
            { id: "cli", label: "CLI", icon: <TerminalSquare className="h-3.5 w-3.5" /> },
            { id: "mcp", label: "MCP", icon: <Plug className="h-3.5 w-3.5" /> },
          ]}
        />

        {tab === "cli" && (
          <div className="grid gap-3">
            <CodeRow label="Binary path" text={bin || "…"} />
            <CodeRow label="Start here" hint="Prints the agent guide" text={cliStartCommand(bin)} />
            {cliExamples(bin, filePath).map((ex) => (
              <CodeRow key={ex.label} label={ex.label} text={ex.cmd} />
            ))}
            <p className="text-xs text-muted-foreground">
              Tip: add the binary&apos;s folder to your PATH to skip the full path.
            </p>
          </div>
        )}

        {tab === "mcp" && (
          <div className="grid gap-3">
            <Segmented<ClientId>
              label="MCP client"
              value={client}
              onChange={setClient}
              options={CLIENTS}
            />
            {client !== "other" ? (
              clientSnippets(client, bin).map((s) => (
                <CodeRow key={s.label} label={s.label} hint={s.hint} text={s.text} />
              ))
            ) : (
              <div className="grid gap-3">
                <CodeRow label="URL" text={info?.mcpUrl ?? "Turn on agent access to get a URL"} />
                <div className="grid gap-1">
                  <div className="flex items-center justify-between gap-2">
                    <div className="text-xs font-medium">Authorization header</div>
                    <div className="flex items-center">
                      <Button
                        type="button"
                        size="sm"
                        variant="ghost"
                        className="h-7 gap-1 px-2 text-xs"
                        disabled={!token}
                        onClick={() => setReveal((r) => !r)}
                      >
                        {reveal ? (
                          <EyeOff className="h-3.5 w-3.5" />
                        ) : (
                          <Eye className="h-3.5 w-3.5" />
                        )}
                        {reveal ? "Hide" : "Reveal"}
                      </Button>
                      {token && <CopyButton text={httpHeader(token)} label="header" />}
                      <Button
                        type="button"
                        size="sm"
                        variant="ghost"
                        className="h-7 gap-1 px-2 text-xs"
                        disabled={!token || busy}
                        onClick={() => void run(agentRegenerateToken)}
                      >
                        <RefreshCw className="h-3.5 w-3.5" />
                        Regenerate
                      </Button>
                    </div>
                  </div>
                  <pre
                    data-testid="agent-token"
                    className="overflow-auto whitespace-pre-wrap break-all rounded-md border bg-muted/50 px-3 py-2 font-mono text-xs"
                  >
                    {token
                      ? `Authorization: Bearer ${reveal ? token : maskToken(token)}`
                      : "No token while the server is off"}
                  </pre>
                </div>
                <p className="text-xs text-amber-600 dark:text-amber-400">
                  The port and token change every time WordsCut starts or you regenerate. Prefer the
                  other clients, which find them automatically.
                </p>
              </div>
            )}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
