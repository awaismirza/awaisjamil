import { useSyncExternalStore } from "react";
import {
  ANNOTATION_FONT,
  annotationOpacity,
  arrowPolygon,
  type Annotation,
} from "@/lib/annotations";
import {
  captionLabel,
  KEY_FONT_PX,
  keyCapY,
  keyCaptionAt,
  type KeyCaption,
} from "@/lib/keystrokes";
import { getPlaybackFrame, subscribePlaybackFrame } from "@/lib/playbackClock";

/**
 * Annotations (and keystroke caps) over a `width` x `height` frame. Same
 * geometry as annotations_export.rs: sizes are pixels at 1080 lines, text is
 * placed by its line box top (libass `\an7`), so the baseline sits 1.061 em
 * down and lines are 1.326 em apart (Arial Unicode MS metrics in libass).
 * Only this layer re-renders per frame.
 */
export function AnnotationOverlay({
  annotations,
  keys = [],
  captionsAtBottom = false,
  width,
  height,
  currentTime,
  playing,
}: {
  annotations: readonly Annotation[];
  keys?: readonly KeyCaption[];
  /** Styled captions at the bottom of the frame push the key caps up. */
  captionsAtBottom?: boolean;
  width: number;
  height: number;
  currentTime: number;
  playing: boolean;
}) {
  const frameTime = useSyncExternalStore(subscribePlaybackFrame, getPlaybackFrame);
  const t = playing ? frameTime : currentTime;
  if (width <= 0 || height <= 0) return null;
  const k = height / 1080;
  const key = keyCaptionAt(keys, t);
  const keyEm = KEY_FONT_PX * k;
  return (
    <svg
      className="cursor-overlay"
      viewBox={`0 0 ${width} ${height}`}
      preserveAspectRatio="xMidYMid meet"
      aria-hidden="true"
      data-testid="annotation-overlay"
    >
      {annotations.map((a) => {
        const opacity = annotationOpacity(a, t);
        if (opacity <= 0) return null;
        const x = a.x * width,
          y = a.y * height;
        const common = { opacity, "data-annotation": a.kind } as const;
        if (a.kind === "box") {
          return (
            <rect
              key={a.id}
              {...common}
              x={x}
              y={y}
              width={a.w * width}
              height={a.h * height}
              fill={a.filled ? a.color : "none"}
              stroke={a.filled ? "none" : a.color}
              strokeWidth={a.stroke * k}
            />
          );
        }
        if (a.kind === "arrow") {
          const points = arrowPolygon(x, y, x + a.w * width, y + a.h * height, a.stroke * k);
          return (
            <polygon
              key={a.id}
              {...common}
              points={points.map((p) => p.join(",")).join(" ")}
              fill={a.color}
            />
          );
        }
        const em = a.fontSize * k;
        return (
          <text
            key={a.id}
            {...common}
            x={x}
            y={y + em * 1.061}
            fontFamily={`"${ANNOTATION_FONT}", Arial, sans-serif`}
            fontSize={em}
            fill={a.color}
            stroke="#000"
            strokeWidth={Math.max(1, em * 0.05) * 2}
            paintOrder="stroke"
            style={{ whiteSpace: "pre" }}
          >
            {(a.text ?? "").split("\n").map((line, i) => (
              <tspan key={i} x={x} dy={i === 0 ? 0 : em * 1.326}>
                {line}
              </tspan>
            ))}
          </text>
        );
      })}
      {key && (
        <foreignObject x={0} y={0} width={width} height={height}>
          <div style={{ position: "relative", width: "100%", height: "100%" }}>
            <div
              data-testid="keystroke-caption"
              style={{
                position: "absolute",
                left: "50%",
                bottom: height * (1 - keyCapY(captionsAtBottom)) - keyEm * 0.35,
                transform: "translateX(-50%)",
                padding: keyEm * 0.35,
                fontFamily: `"${ANNOTATION_FONT}", Arial, sans-serif`,
                fontSize: keyEm,
                fontWeight: 700,
                lineHeight: 1.326,
                whiteSpace: "pre",
                color: "#fff",
                background: "rgba(32, 32, 32, 0.81)",
              }}
            >
              {captionLabel(key)}
            </div>
          </div>
        </foreignObject>
      )}
    </svg>
  );
}
