/**
 * Video preview panel with full playback controls.
 *
 * Key behaviours:
 *  - When there are no transcribed words yet the video plays freely (no EDL constraints).
 *  - Seeking from transcript/waveform (yusafcut:seek-source) calls el.play() directly to
 *    avoid the React-state → effect cycle race condition.
 *  - Scrubber shows output-time progress; skip ±5 s; playback rate cycle; mute toggle.
 */

import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import {
  computeTimeline,
  entryPlayEnd,
  sourceTimeToOutput,
  transitionHalf,
  wordIdToOutputTime,
  type Project,
} from "@/lib/edl";
import { useProjectStore } from "@/stores/projectStore";
import { usePlayerStore } from "@/stores/playerStore";
import { useUIStore } from "@/stores/uiStore";
import { convertFileSrc } from "@tauri-apps/api/core";
import { Button } from "@/components/ui/button";
import {
  AlertTriangle,
  Captions,
  ChevronsLeft,
  ChevronsRight,
  Pause,
  Play,
  SkipBack,
  SkipForward,
  Volume2,
  VolumeX,
} from "lucide-react";
import { cutPoints, nextCutTarget, prevCutTarget, timingMarks } from "@/lib/cuts";
import { layoutProjectCaptions } from "@/lib/captionLayout";
import { sanitizeCaptionStyle } from "@/lib/captionStyle";
import { sanitizeScene, sceneActive, sceneLayout, sceneSourceMedia } from "@/lib/scene";
import { sanitizeAnnotations } from "@/lib/annotations";
import { keystrokeCaptions, sanitizeKeystrokes } from "@/lib/keystrokes";
import { sceneCss, type FrameNodeCss } from "@/lib/sceneCss";
import { NO_ZOOM, sampleZoom, sanitizeZoomRegions, viewWindow } from "@/lib/zoom";
import { formatTimecode } from "@/lib/timecode";
import { originalAudioGainAt } from "@/lib/voiceover";
import { LiveCaptionOverlay } from "./CaptionOverlay";
import { LiveCursorOverlay } from "./LiveCursorOverlay";
import { AnnotationOverlay } from "./AnnotationOverlay";
import { MaskLayer, MediaOverlayLayer } from "./LayerOverlays";
import { sanitizeOverlays } from "@/lib/layers";
import { maskOutputSpans, sanitizeMasks } from "@/lib/masks";
import {
  entryAtOutput,
  getTimelineIndex,
  indexedSource,
  indexedWord,
  playbackPosition,
  type IndexedEntry,
} from "@/lib/timelineIndex";
import {
  getPlaybackFrame,
  publishPlaybackFrame,
  subscribePlaybackFrame,
} from "@/lib/playbackClock";
import { recordTiming } from "@/lib/playbackDiagnostics";
import { sanitizeProjectCursor } from "@/lib/cursorStyle";
import { usePreviewSource } from "@/hooks/usePreviewSource";
import type { PreviewQuality } from "@/lib/ipc";
import { useCoalescedSeek } from "@/hooks/useCoalescedSeek";
import { useVideoFrameClock } from "@/hooks/useVideoFrameClock";
import { useEditorShortcutLabel } from "@/hooks/useShortcutLabel";

function firstMediaPath(project: Project): string | null {
  const ids = Object.keys(project.media);
  if (ids.length === 0) return null;
  return project.media[ids[0]!]!.path;
}

/** The frame a hold freezes on: half a frame before `sourceOut`, so the decoder
 * shows the clip's last frame rather than the one after it. */
function heldFrame(project: Project, e: IndexedEntry): number {
  return Math.max(e.sourceIn, e.sourceOut - 0.5 / (project.media[e.mediaId]?.fps || 30));
}

function firstMediaId(project: Project): string | null {
  return Object.keys(project.media)[0] ?? null;
}

const RATES = [0.5, 0.75, 1, 1.25, 1.5, 2] as const;

/** True when the project has at least one segment with transcribed words. */
/** Width over height of the exported frame: the scene canvas, else the source. */
function frameAspect(
  scene: Parameters<typeof sceneLayout>[0] | null,
  media: { width: number; height: number },
) {
  const size = { w: media.width, h: media.height };
  // sceneLayout sees the crop, so the caption frame matches the cropped canvas.
  const f = scene ? sceneLayout(scene, size) : null;
  return f ? f.canvasW / Math.max(1, f.canvasH) : size.w / Math.max(1, size.h);
}

function FrameNodes({ nodes }: { nodes: FrameNodeCss[] }) {
  return (
    <>
      {nodes.map((n) => (
        <div key={n.key} style={n.style}>
          {n.text}
        </div>
      ))}
    </>
  );
}

function hasWords(project: Project) {
  return project.segments.some((s) => s.words.length > 0);
}

function hasTimeline(project: Project) {
  return project.segments.length > 0;
}

function displayDurationForProgress(outputDuration: number, nativeDuration: number) {
  return outputDuration > 0 ? outputDuration : nativeDuration;
}

function videoErrorMessage(error: MediaError) {
  switch (error.code) {
    case MediaError.MEDIA_ERR_ABORTED:
      return "Playback was interrupted before the media loaded.";
    case MediaError.MEDIA_ERR_NETWORK:
      return "The media URL could not be read by the app.";
    case MediaError.MEDIA_ERR_DECODE:
      return "This video codec could not be decoded by the WebView.";
    case MediaError.MEDIA_ERR_SRC_NOT_SUPPORTED:
      return "The media source is not supported or is outside the allowed local-file scope.";
    default:
      return error.message || "Unknown media playback error.";
  }
}

export function VideoPreview() {
  const playPauseKey = useEditorShortcutLabel("playPause");
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const project = useProjectStore((s) => s.project);
  const playing = usePlayerStore((s) => s.playing);
  const muted = usePlayerStore((s) => s.muted);
  const rate = usePlayerStore((s) => s.rate);
  const currentTime = usePlayerStore((s) => s.currentTime);
  const selectedWordIds = usePlayerStore((s) => s.selectedWordIds);
  const setCurrentTime = usePlayerStore((s) => s.setCurrentTime);
  const setPlaying = usePlayerStore((s) => s.setPlaying);
  const toggleMuted = usePlayerStore((s) => s.toggleMuted);
  const setRate = usePlayerStore((s) => s.setRate);
  // Playback is locked while a heavy transcript/EDL edit is being applied so the
  // user can't start playback against a half-rebuilt timeline.
  const isProcessingEdit = useUIStore((s) => s.isProcessingEdit);
  const burnCaptions = useUIStore((s) => s.burnCaptions);
  const previewMasks = useUIStore((s) => s.previewMasks);

  const [scrubbing, setScrubbing] = useState(false);
  const [scrubValue, setScrubValue] = useState(0);
  const [nativeDuration, setNativeDuration] = useState(0);
  const [loadState, setLoadState] = useState<"idle" | "loading" | "ready" | "error">("idle");
  const [loadMessage, setLoadMessage] = useState<string>("");
  const [activeMediaId, setActiveMediaId] = useState<string | null>(() => firstMediaId(project));
  const pendingSeekRef = useRef<{ sourceTime: number; outputTime: number; play: boolean } | null>(
    null,
  );

  const sourceMedia = project.media[activeMediaId ?? firstMediaId(project) ?? ""];
  const preview = usePreviewSource(sourceMedia);
  const usingProxy = preview.usingProxy;
  const fallbackToOriginal = preview.fallback;
  const mediaPath = preview.path ?? firstMediaPath(project);
  const src = mediaPath ? convertFileSrc(mediaPath) : null;
  const index = useMemo(() => getTimelineIndex(project.segments), [project.segments]);
  const outputDuration = index.duration;
  const {
    seek: requestSeek,
    acceptFrame,
    isSeeking,
    generation,
  } = useCoalescedSeek(videoRef, activeMediaId ?? "", src ?? "", index);
  const timelineRef = useRef(index);
  const reconciledIndex = useRef<typeof index | null>(null);
  const playbackEntry = useRef(0);
  const pictureRef = useRef<HTMLDivElement | null>(null);
  const cutStarted = useRef<number | null>(null);
  const lastFrameAt = useRef<number | null>(null);
  const lastPublished = useRef({ at: -Infinity, word: "" });
  // Freeze-frame hold in progress: the <video> is paused on the held frame and
  // a rAF timer advances output time until the hold ends.
  const holdRef = useRef<{ raf: number } | null>(null);
  const startHoldRef = useRef<(entry: IndexedEntry, fromOutput: number) => void>(() => {});
  const stopHold = useCallback(() => {
    if (holdRef.current) cancelAnimationFrame(holdRef.current.raf);
    holdRef.current = null;
  }, []);
  useEffect(() => stopHold, [stopHold]);
  // Per-clip speed and mute ride on the single <video>: playbackRate = user rate
  // × clip speed (pitch is preserved by the WebView), muted = user mute || clip mute.
  const applyClipPlayback = useCallback((entry: IndexedEntry | null | undefined) => {
    const el = videoRef.current;
    if (!el) return;
    const { rate, muted } = usePlayerStore.getState();
    const wantRate = rate * (entry?.speed ?? 1);
    if (el.playbackRate !== wantRate) el.playbackRate = wantRate;
    const wantMuted = muted || !!entry?.segment.muted;
    if (el.muted !== wantMuted) el.muted = wantMuted;
  }, []);
  // Voice-over override: the clip's own audio follows the same envelope as the
  // export (silent inside each replacement interval, short ramps outside). The
  // player position updates about ten times a second, so the ramps step.
  useEffect(() => {
    const el = videoRef.current;
    if (!el) return;
    const gain = Math.min(1, Math.max(0, originalAudioGainAt(project, currentTime)));
    if (el.volume !== gain) el.volume = gain;
  }, [project, currentTime]);
  useLayoutEffect(() => {
    timelineRef.current = index;
    if (reconciledIndex.current === index) return;
    reconciledIndex.current = index;
    if (holdRef.current) {
      stopHold();
      setPlaying(false);
    }
    const outputTime = Math.max(
      0,
      Math.min(usePlayerStore.getState().currentTime, index.duration - 1e-6),
    );
    const mapped = indexedSource(index, outputTime);
    playbackEntry.current = mapped?.entry.index ?? 0;
    if (!mapped) return;
    const target = {
      sourceTime: mapped.sourceTime,
      outputTime,
      play: usePlayerStore.getState().playing,
    };
    const el = videoRef.current;
    if (mapped.entry.mediaId !== activeMediaId) {
      pendingSeekRef.current = target;
      setActiveMediaId(mapped.entry.mediaId);
    } else if (el && el.readyState >= 1) requestSeek(mapped.sourceTime);
    else pendingSeekRef.current = target;
    applyClipPlayback(mapped.entry);
  }, [index, activeMediaId, requestSeek, applyClipPlayback, setPlaying, stopHold]);
  const publishOutput = useCallback(
    (time: number, force = false) => {
      publishPlaybackFrame(time);
      const now = globalThis.performance.now();
      const active = indexedWord(index, time);
      const word = active ? `${active.entry.index}:${active.wordIndex}:${active.silence}` : "";
      if (
        force ||
        !usePlayerStore.getState().playing ||
        now - lastPublished.current.at >= 100 ||
        word !== lastPublished.current.word
      ) {
        lastPublished.current = { at: now, word };
        setCurrentTime(time);
      }
    },
    [index, setCurrentTime],
  );
  const hasTranscriptWords = hasWords(project);

  // While scrubbing, follow the drag; otherwise follow the player store.
  const displayedProgress = scrubbing
    ? scrubValue
    : displayDurationForProgress(outputDuration, nativeDuration) > 0
      ? Math.round(
          (currentTime / displayDurationForProgress(outputDuration, nativeDuration)) * 1000,
        )
      : 0;

  // Tracks the latest user intent so we can ignore stale Promise rejections
  // from interrupted el.play() calls — e.g. when a click-on-word seek races
  // the play/pause effect. Without this guard, an AbortError from the first
  // play() flips `playing` back to false and pauses the video immediately.
  const playIntentRef = useRef(false);

  const playVideo = useCallback(() => {
    const el = videoRef.current;
    if (!el) return false;
    playIntentRef.current = true;
    if (holdRef.current) return true;
    if (pendingSeekRef.current) pendingSeekRef.current.play = true;
    else {
      // Paused inside a hold: resume the hold timer, not the footage.
      const t = usePlayerStore.getState().currentTime;
      const entry = entryAtOutput(timelineRef.current, t);
      if (entry?.holdSec && t >= entryPlayEnd(entry)) {
        startHoldRef.current(entry, t);
        return true;
      }
    }
    if (!el.currentSrc && src) {
      el.load();
    }
    if (el.error) {
      setLoadState("error");
      setLoadMessage(videoErrorMessage(el.error));
      setPlaying(false);
      return false;
    }
    const promise = el.play();
    if (promise) {
      promise.catch((err: DOMException) => {
        if (err.name === "AbortError") return;
        setLoadState("error");
        setLoadMessage(err.message || "Playback failed.");
        if (playIntentRef.current) setPlaying(false);
      });
    }
    setPlaying(true);
    return true;
  }, [setPlaying, src]);

  useEffect(() => {
    const desiredMediaId =
      indexedSource(index, currentTime)?.segment.mediaId ?? firstMediaId(project);
    if (desiredMediaId && !project.media[activeMediaId ?? ""]) {
      setActiveMediaId(desiredMediaId);
    }
  }, [activeMediaId, currentTime, project, index]);

  useEffect(() => {
    const el = videoRef.current;
    if (!el) return;
    const pending =
      pendingSeekRef.current ??
      (() => {
        const outputTime = usePlayerStore.getState().playing
          ? getPlaybackFrame()
          : usePlayerStore.getState().currentTime;
        const initial = indexedSource(timelineRef.current, outputTime);
        return {
          sourceTime: initial?.sourceTime ?? outputTime,
          outputTime,
          play: usePlayerStore.getState().playing,
        };
      })();
    pendingSeekRef.current = pending;
    playIntentRef.current = pending?.play ?? false;
    if (!pending) {
      setCurrentTime(0);
      publishPlaybackFrame(0);
      setPlaying(false);
    } else {
      setCurrentTime(pending.outputTime);
      publishPlaybackFrame(pending.outputTime);
      setPlaying(pending.play);
    }
    setNativeDuration(0);
    setLoadState(src ? "loading" : "idle");
    setLoadMessage(src ? "Loading media..." : "");
    el.pause();
    try {
      el.currentTime = pending?.sourceTime ?? 0;
    } catch {
      /* ignored until metadata exists */
    }

    const applyPendingSeek = () => {
      const seek = pendingSeekRef.current;
      if (!seek) return;
      requestSeek(seek.sourceTime);
      setCurrentTime(seek.outputTime);
      publishPlaybackFrame(seek.outputTime);
      pendingSeekRef.current = null;
      if (seek.play) playVideo();
    };

    el.addEventListener("loadedmetadata", applyPendingSeek, { once: true });
    el.load();
    return () => el.removeEventListener("loadedmetadata", applyPendingSeek);
  }, [playVideo, requestSeek, setCurrentTime, setPlaying, src]);

  const pauseVideo = useCallback(() => {
    const el = videoRef.current;
    playIntentRef.current = false;
    stopHold();
    if (pendingSeekRef.current) pendingSeekRef.current.play = false;
    if (el) el.pause();
    setPlaying(false);
  }, [setPlaying, stopHold]);

  // ── Output-time seek helpers ──────────────────────────────────────────────
  const seekToOutputTime = useCallback(
    (targetOutput: number, opts: { play?: boolean } = {}) => {
      const el = videoRef.current;
      if (!el) return;
      const holding = !!holdRef.current;
      stopHold();
      const clamped = Math.max(0, Math.min(targetOutput, outputDuration || el.duration || 0));

      // Free-play mode: output time === source time before an EDL exists.
      if (!hasTimeline(project)) {
        requestSeek(clamped, !scrubbing);
        publishOutput(clamped, true);
        if (opts.play) playVideo();
        return;
      }

      const mapped = indexedSource(index, clamped);
      playbackEntry.current = mapped?.entry.index ?? Math.max(0, index.entries.length - 1);
      applyClipPlayback(mapped?.entry);
      if (mapped) {
        const mediaId = mapped.segment.mediaId;
        // Inside a hold: show the held frame (just before sourceOut) and, when
        // playing, run the hold timer from here instead of playing footage.
        const inHold = !!mapped.entry.holdSec && clamped >= entryPlayEnd(mapped.entry);
        // Pending seeks (another media, metadata not loaded) also land on the held frame.
        const sourceTarget = inHold ? heldFrame(project, mapped.entry) : mapped.sourceTime;
        if (inHold && mediaId === activeMediaId && el.readyState >= 1 && !pendingSeekRef.current) {
          requestSeek(heldFrame(project, mapped.entry), !scrubbing);
          publishOutput(clamped, true);
          if (opts.play || holding || usePlayerStore.getState().playing) {
            startHoldRef.current(mapped.entry, clamped);
          } else if (!el.paused) {
            pauseVideo();
          }
          return;
        }
        if (mediaId !== activeMediaId) {
          pendingSeekRef.current = {
            sourceTime: sourceTarget,
            outputTime: clamped,
            play: opts.play ?? usePlayerStore.getState().playing,
          };
          setActiveMediaId(mediaId);
          return;
        }
        if (pendingSeekRef.current || el.readyState < 1) {
          pendingSeekRef.current = {
            sourceTime: sourceTarget,
            outputTime: clamped,
            play: opts.play ?? usePlayerStore.getState().playing,
          };
        } else requestSeek(mapped.sourceTime, !scrubbing);
        publishOutput(clamped, true);
        if (opts.play) playVideo();
        return;
      }

      const timeline = index.entries;
      if (timeline.length > 0) {
        const last = timeline[timeline.length - 1]!;
        if (last.mediaId !== activeMediaId) {
          pendingSeekRef.current = {
            sourceTime: last.sourceOut,
            outputTime: outputDuration,
            play: false,
          };
          setActiveMediaId(last.mediaId);
          return;
        }
        requestSeek(last.sourceOut);
        publishOutput(outputDuration, true);
      }
    },
    [
      activeMediaId,
      outputDuration,
      project,
      index,
      publishOutput,
      playVideo,
      pauseVideo,
      requestSeek,
      scrubbing,
      stopHold,
      applyClipPlayback,
    ],
  );

  // Run a freeze-frame hold from `fromOutput` to the entry's end, then carry on
  // to the next clip (or stop at the end of the timeline). The <video> stays
  // paused on the held frame; the store keeps `playing` true throughout.
  useLayoutEffect(() => {
    startHoldRef.current = (entry, fromOutput) => startHold(entry, fromOutput);
  });
  const startHold = (entry: IndexedEntry, fromOutput: number) => {
    const el = videoRef.current;
    if (!el) return;
    stopHold();
    const hold = { raf: 0 };
    holdRef.current = hold;
    playIntentRef.current = true;
    el.pause();
    // The element ran on past sourceOut before this tick saw the end (several
    // source frames at 4x): park it back on the held frame.
    requestSeek(heldFrame(project, entry));
    setPlaying(true);
    // Advance by elapsed time × the rate at each frame, so changing the rate
    // mid-hold changes the pace from then on instead of jumping the playhead.
    let t = fromOutput;
    let last = globalThis.performance.now();
    const tick = () => {
      if (holdRef.current !== hold) return;
      const now = globalThis.performance.now();
      t += ((now - last) / 1000) * usePlayerStore.getState().rate;
      last = now;
      if (t < entry.outputEnd) {
        publishOutput(t);
        hold.raf = requestAnimationFrame(tick);
        return;
      }
      holdRef.current = null;
      const next = index.entries[entry.index + 1];
      if (next) seekToOutputTime(next.outputStart, { play: true });
      else {
        publishOutput(outputDuration, true);
        playIntentRef.current = false;
        setPlaying(false);
      }
    };
    hold.raf = requestAnimationFrame(tick);
  };

  // `precise` is the frame-accurate `mediaTime` from requestVideoFrameCallback
  // when available; falling back to `el.currentTime` (which can lag a frame).
  // Passing it explicitly removes one source of jitter in the word/timeline
  // sync — the worst-case error is now sub-millisecond instead of ~16ms.
  const syncPlaybackClock = useCallback(
    (precise?: number) => {
      const started = globalThis.performance.now();
      const el = videoRef.current;
      if (!el || scrubbing || el.seeking || pendingSeekRef.current || isSeeking()) return;
      if (holdRef.current) return; // the hold timer owns the clock
      if (lastFrameAt.current !== null && !el.paused)
        recordTiming("frameInterval", started - lastFrameAt.current);
      lastFrameAt.current = el.paused ? null : started;
      try {
        const srcTime = precise ?? el.currentTime;
        if (precise !== undefined && !acceptFrame(srcTime)) return;
        if (!index.entries.length) {
          publishOutput(srcTime);
          return;
        }
        let position = playbackPosition(index, playbackEntry.current, srcTime);
        if (!position || position.entry.mediaId !== activeMediaId) return;
        // Splitting a continuous take must not flush the decoder at every boundary.
        // (A clip ending in a hold is never passed through: the hold must run.)
        while (
          position.ended &&
          position.next &&
          !position.entry.holdSec &&
          position.next.mediaId === position.entry.mediaId &&
          Math.abs(position.next.sourceIn - position.entry.sourceOut) < 1e-6
        ) {
          playbackEntry.current = position.next.index;
          position = playbackPosition(index, playbackEntry.current, srcTime)!;
        }
        if (srcTime < position.entry.sourceIn - 0.05) return; // stale frame from an earlier seek
        applyClipPlayback(position.entry);
        if (el.paused && position.entry.holdSec) {
          // Parked on the held frame: the playhead sits inside the hold, not on the footage.
          const now = usePlayerStore.getState().currentTime;
          if (now >= entryPlayEnd(position.entry) && now <= position.entry.outputEnd) return;
        }
        if (position.ended && position.entry.holdSec && !el.paused) {
          // Resume from where the playhead already is inside this hold (a seek
          // into a hold on another media lands here), else from its start.
          const now = usePlayerStore.getState().currentTime;
          const from =
            now > position.outputTime && now < position.entry.outputEnd ? now : position.outputTime;
          publishOutput(from, true);
          startHoldRef.current(position.entry, from);
          return;
        }
        if (!position.ended) {
          if (cutStarted.current !== null) {
            recordTiming("cut", started - cutStarted.current);
            cutStarted.current = null;
          }
          publishOutput(position.outputTime);
          return;
        }
        if (position.next) {
          cutStarted.current = started;
          seekToOutputTime(position.next.outputStart, { play: true });
        } else {
          publishOutput(outputDuration, true);
          playIntentRef.current = false;
          el.pause();
          setPlaying(false);
        }
      } finally {
        recordTiming("frameWork", globalThis.performance.now() - started);
      }
    },
    [
      activeMediaId,
      applyClipPlayback,
      index,
      outputDuration,
      publishOutput,
      scrubbing,
      seekToOutputTime,
      setPlaying,
      acceptFrame,
      isSeeking,
    ],
  );

  // ── Drive play/pause state from store ────────────────────────────────────
  useEffect(() => {
    const el = videoRef.current;
    if (!el) return;
    if (playing && el.paused) {
      playVideo();
    } else if (!playing && !el.paused) {
      pauseVideo();
    }
  }, [pauseVideo, playVideo, playing]);

  useEffect(() => {
    applyClipPlayback(index.entries[playbackEntry.current]);
  }, [muted, rate, index, applyClipPlayback]);

  // ── Seek from transcript / waveform → start playing ─────────────────────
  // We only set currentTime here and flip the store flag. The play/pause
  // effect above is the single source of truth for el.play()/el.pause() —
  // keeping that invariant prevents the AbortError race we used to hit when
  // both this handler and the effect called play() in quick succession.
  useEffect(() => {
    const handler = (e: Event) => {
      const ce = e as CustomEvent<{ start: number; mediaId?: string }>;
      const el = videoRef.current;
      if (!el) return;
      const mediaId = ce.detail.mediaId ?? activeMediaId ?? firstMediaId(project);
      if (mediaId && hasTimeline(project)) {
        const mapped = sourceTimeToOutput(project, mediaId, ce.detail.start);
        if (mapped) {
          seekToOutputTime(mapped.outputTime, { play: true });
          return;
        }
      }
      if (mediaId && mediaId !== activeMediaId) {
        pendingSeekRef.current = {
          sourceTime: ce.detail.start,
          outputTime: ce.detail.start,
          play: true,
        };
        setActiveMediaId(mediaId);
      } else {
        el.currentTime = ce.detail.start;
        setCurrentTime(ce.detail.start);
        playVideo();
      }
    };
    window.addEventListener("yusafcut:seek-source", handler);
    return () => window.removeEventListener("yusafcut:seek-source", handler);
  }, [activeMediaId, playVideo, project, seekToOutputTime, setCurrentTime]);

  // ── Time update: skip deleted ranges, update store ────────────────────────
  useEffect(() => {
    const el = videoRef.current;
    if (!el) return;

    function onTimeUpdate() {
      // While paused, rVFC doesn't tick — we still need timeupdate to keep the
      // store in sync with manual seeks. While playing, rVFC dominates and this
      // is harmless redundancy.
      if (el!.paused && !el!.ended) syncPlaybackClock(el!.currentTime);
    }

    const onLoadedMetadata = () => {
      setNativeDuration(Number.isFinite(el.duration) ? el.duration : 0);
      setLoadState("ready");
      setLoadMessage("");
    };
    const onCanPlay = () => {
      setLoadState("ready");
      setLoadMessage("");
    };
    const onWaiting = () => {
      if (!el.paused) setLoadState("loading");
    };
    const onError = () => {
      if (usingProxy) {
        fallbackToOriginal();
        return;
      }
      setLoadState("error");
      setLoadMessage(el.error ? videoErrorMessage(el.error) : "Media failed to load.");
      setPlaying(false);
    };
    const onPlay = () => {
      setLoadState("ready");
      setPlaying(true);
    };
    const onPause = () => {
      // A hold pauses the <video> on purpose while playback carries on.
      if (!el.ended && !holdRef.current) setPlaying(false);
    };
    const onEnded = () => syncPlaybackClock(el.currentTime);
    const onSeeked = () => {
      if (el.paused) syncPlaybackClock(el.currentTime);
    };

    el.addEventListener("timeupdate", onTimeUpdate);
    el.addEventListener("loadedmetadata", onLoadedMetadata);
    el.addEventListener("canplay", onCanPlay);
    el.addEventListener("waiting", onWaiting);
    el.addEventListener("error", onError);
    el.addEventListener("play", onPlay);
    el.addEventListener("pause", onPause);
    el.addEventListener("ended", onEnded);
    el.addEventListener("seeked", onSeeked);
    return () => {
      el.removeEventListener("timeupdate", onTimeUpdate);
      el.removeEventListener("loadedmetadata", onLoadedMetadata);
      el.removeEventListener("canplay", onCanPlay);
      el.removeEventListener("waiting", onWaiting);
      el.removeEventListener("error", onError);
      el.removeEventListener("play", onPlay);
      el.removeEventListener("pause", onPause);
      el.removeEventListener("ended", onEnded);
      el.removeEventListener("seeked", onSeeked);
    };
  }, [setPlaying, syncPlaybackClock, usingProxy, fallbackToOriginal]);

  // Frame-accurate clock — uses requestVideoFrameCallback (sub-ms precision,
  // locked to video frame presentation) with rAF as a fallback. Replaces the
  // earlier rAF tick that drifted on non-vsync refresh rates.
  useVideoFrameClock(
    videoRef,
    useCallback(
      (mediaTime: number) => {
        syncPlaybackClock(mediaTime);
      },
      [syncPlaybackClock],
    ),
    playing,
    !!project.media[activeMediaId ?? ""]?.width,
    generation,
  );

  useEffect(() => {
    // Block starting playback while a heavy edit is processing (pausing is fine).
    const editLocked = () => useUIStore.getState().isProcessingEdit;
    function onPlay() {
      if (editLocked()) return;
      playVideo();
    }
    function onPause() {
      pauseVideo();
    }
    function onToggle() {
      if (usePlayerStore.getState().playing) pauseVideo();
      else if (!editLocked()) playVideo();
    }
    function onSeekOutput(e: Event) {
      const ce = e as CustomEvent<{ time: number; play?: boolean }>;
      const wantsPlay = ce.detail.play && !editLocked();
      seekToOutputTime(ce.detail.time, { play: wantsPlay });
    }

    window.addEventListener("yusafcut:play", onPlay);
    window.addEventListener("yusafcut:pause", onPause);
    window.addEventListener("yusafcut:toggle-play", onToggle);
    window.addEventListener("yusafcut:seek-output", onSeekOutput);
    return () => {
      window.removeEventListener("yusafcut:play", onPlay);
      window.removeEventListener("yusafcut:pause", onPause);
      window.removeEventListener("yusafcut:toggle-play", onToggle);
      window.removeEventListener("yusafcut:seek-output", onSeekOutput);
    };
  }, [activeMediaId, index, pauseVideo, playVideo, project, seekToOutputTime]);

  // If a heavy edit starts while playing, pause immediately so playback can't
  // run against a timeline that is being rebuilt.
  useEffect(() => {
    if (isProcessingEdit && usePlayerStore.getState().playing) {
      pauseVideo();
    }
  }, [isProcessingEdit, pauseVideo]);

  const seekToSelectedWord = useCallback(() => {
    const el = videoRef.current;
    if (!el || selectedWordIds.size === 0 || !hasWords(project)) return false;
    let best: ReturnType<typeof wordIdToOutputTime> = null;
    for (const id of selectedWordIds) {
      const mapped = wordIdToOutputTime(project, id);
      if (!mapped) continue;
      if (!best || mapped.outputTime < best.outputTime) best = mapped;
    }
    if (!best) return false;
    seekToOutputTime(best.outputTime);
    return true;
  }, [project, seekToOutputTime, selectedWordIds]);

  const handleScrubStart = () => {
    setScrubbing(true);
    setScrubValue(displayedProgress);
  };

  const handleScrubMove = (e: React.ChangeEvent<HTMLInputElement>) => {
    setScrubValue(Number(e.target.value));
  };

  const handleScrubEnd = (
    e: React.MouseEvent<HTMLInputElement> | React.TouchEvent<HTMLInputElement>,
  ) => {
    const fraction = Number((e.currentTarget as HTMLInputElement).value) / 1000;
    // Use source duration only before the EDL has any segment.
    const dur = hasTimeline(project) ? outputDuration : (videoRef.current?.duration ?? 0);
    seekToOutputTime(fraction * dur);
    setScrubbing(false);
  };

  const handleSkip = useCallback(
    (delta: number) => seekToOutputTime(currentTime + delta),
    [seekToOutputTime, currentTime],
  );

  // ── Cut navigation + live caption ─────────────────────────────────────────
  const [captionsOn, setCaptionsOn] = useState(true);
  const cuts = useMemo(() => cutPoints(project), [project]);
  const marks = useMemo(() => timingMarks(project), [project]);
  const prevCut = prevCutTarget(cuts, currentTime);
  const nextCut = nextCutTarget(cuts, currentTime);
  // Styled live captions: same layout and style the burned-in export uses.
  const captionStyle = useMemo(() => sanitizeCaptionStyle(project.captions), [project.captions]);
  const captionCues = useMemo(
    () =>
      captionsOn && hasWords(project) ? layoutProjectCaptions(project, captionStyle).cues : [],
    [captionsOn, project, captionStyle],
  );
  const jumpToCut = (target: number | null) => {
    if (target !== null) seekToOutputTime(target, { play: true });
  };

  // ── Scene: background, padding, corners and shadow around the picture ─────
  // The same wrapper elements always exist, with only their styles changing, so
  // turning the scene on or off never remounts the <video> or loses playback.
  const scene = sanitizeScene(project.scene);
  const firstMedia = sceneSourceMedia(project);
  const cursor = useMemo(() => sanitizeProjectCursor(project.cursor), [project.cursor]);
  const cursorSource = indexedSource(index, currentTime);
  const cursorMediaId = cursorSource?.segment.mediaId ?? activeMediaId;
  const cursorTrack = cursorMediaId ? cursor.tracks[cursorMediaId] : undefined;

  const sceneOn = sceneActive(scene) && !!firstMedia;
  const css = sceneOn
    ? sceneCss(
        scene,
        { w: firstMedia!.width, h: firstMedia!.height },
        scene.background.kind === "image" ? convertFileSrc(scene.background.path) : undefined,
      )
    : null;
  const fill = {
    width: "100%",
    height: "100%",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  } as const;

  // ── Zoom regions: magnify the picture inside its frame ────────────────────
  // Same motion the exporter renders (`sampleZoom`). The picture is clipped to
  // its own box, so zooming never spills over the frame or the letterbox bars.
  const zoomRegions = useMemo(
    () => sanitizeZoomRegions(project.zoomRegions, outputDuration),
    [project.zoomRegions, outputDuration],
  );
  // Transitions, centred on their cuts. A dip is previewed as a black overlay
  // with the same ramp as the export; a crossfade needs two decoders, so the
  // single <video> only shows a "crossfade" badge over its span (export renders it).
  const transitions = useMemo(() => {
    const starts = new Map(index.entries.map((e) => [e.segmentId, e.outputStart]));
    return project.segments.flatMap((s, i) => {
      const h = transitionHalf(project.segments, i);
      const at = starts.get(s.id);
      return h > 0 && at !== undefined && s.transitionIn
        ? [{ at, h, kind: s.transitionIn.kind }]
        : [];
    });
  }, [project.segments, index]);
  const dipRef = useRef<HTMLDivElement | null>(null);
  const crossfadeRef = useRef<HTMLDivElement | null>(null);
  useLayoutEffect(() => {
    const paint = (time: number) => {
      const near = transitions.find((x) => Math.abs(time - x.at) < x.h);
      if (dipRef.current)
        dipRef.current.style.opacity =
          near?.kind === "dip" ? String(1 - Math.abs(time - near.at) / near.h) : "0";
      if (crossfadeRef.current)
        crossfadeRef.current.style.display = near?.kind === "crossfade" ? "block" : "none";
    };
    paint(playing ? getPlaybackFrame() : currentTime);
    return subscribePlaybackFrame(paint);
  }, [currentTime, playing, transitions]);
  useLayoutEffect(() => {
    const paint = (time: number) => {
      const layer = pictureRef.current;
      if (!layer) return;
      const zoom = zoomRegions.length ? sampleZoom(zoomRegions, time) : NO_ZOOM;
      const view = viewWindow(zoom);
      layer.style.transform =
        zoom.scale > 1.0005
          ? `scale(${zoom.scale}) translate(${-view.x0 * 100}%, ${-view.y0 * 100}%)`
          : "none";
    };
    paint(playing ? getPlaybackFrame() : currentTime);
    return subscribePlaybackFrame(paint);
  }, [currentTime, playing, zoomRegions]);
  // ── Annotations and keystroke caps: fixed on the frame, or zooming with the picture ──
  const annotations = useMemo(
    () => sanitizeAnnotations(project.annotations, outputDuration),
    [project.annotations, outputDuration],
  );
  const keyCaptions = useMemo(
    () => keystrokeCaptions(project, sanitizeKeystrokes(project.keystrokes)),
    [project],
  );
  // ── Media overlays and privacy masks (same layer order as the export) ──
  const mediaOverlays = useMemo(
    () => sanitizeOverlays(project.overlays, outputDuration),
    [project.overlays, outputDuration],
  );
  const masks = useMemo(() => {
    if (!previewMasks) return [];
    const tl = computeTimeline(project);
    return sanitizeMasks(project.masks).map((m) => ({
      m,
      spans: maskOutputSpans(tl, m, project.media),
      width: project.media[m.mediaId]?.width ?? 0,
      height: project.media[m.mediaId]?.height ?? 0,
    }));
  }, [project, previewMasks]);
  const followMedia = mediaOverlays.filter((o) => o.followZoom);
  const fixedMedia = mediaOverlays.filter((o) => !o.followZoom);
  const followNotes = annotations.filter((a) => a.followZoom);
  const fixedNotes = annotations.filter((a) => !a.followZoom);
  const fixedOn = fixedNotes.length > 0 || keyCaptions.length > 0 || fixedMedia.length > 0;
  const frame =
    css && firstMedia
      ? (() => {
          const l = sceneLayout(scene, { w: firstMedia.width, h: firstMedia.height });
          return { w: l.canvasW, h: l.canvasH };
        })()
      : { w: firstMedia?.width ?? 0, h: firstMedia?.height ?? 0 };
  const fixedOverlay = fixedOn ? (
    <>
      {fixedMedia.length > 0 && (
        <MediaOverlayLayer
          overlays={fixedMedia}
          width={frame.w}
          height={frame.h}
          currentTime={currentTime}
          playing={playing}
        />
      )}
      <AnnotationOverlay
        annotations={fixedNotes}
        keys={keyCaptions}
        // Same rule as the export: only captions that are burned in push the key caps up.
        captionsAtBottom={burnCaptions && hasWords(project) && captionStyle.position === "bottom"}
        width={frame.w}
        height={frame.h}
        currentTime={currentTime}
        playing={playing}
      />
    </>
  ) : null;

  // Without a scene, clip to a box with the picture's own aspect (only when zoom,
  // cursor or overlays are in use, so they have the picture's exact rectangle).
  const pictureBox =
    !css &&
    (zoomRegions.length > 0 ||
      !!cursorTrack ||
      annotations.length > 0 ||
      fixedOn ||
      mediaOverlays.length > 0 ||
      masks.length > 0) &&
    firstMedia
      ? ({
          position: "relative",
          width: `min(100cqw, calc(100cqh * ${firstMedia.width} / ${firstMedia.height}))`,
          aspectRatio: `${firstMedia.width} / ${firstMedia.height}`,
          overflow: "hidden",
        } as const)
      : null;

  const cycleRate = () => {
    const idx = RATES.indexOf(rate as (typeof RATES)[number]);
    setRate(RATES[(idx + 1) % RATES.length] ?? 1);
  };

  const handlePlayPause = () => {
    if (playing) {
      setRate(1);
      pauseVideo();
      return;
    }
    if (isProcessingEdit) return; // locked while a heavy edit is processing
    seekToSelectedWord();
    playVideo();
  };

  // Display duration: use source duration in free-play mode, output duration otherwise
  useEffect(() => {
    const el = videoRef.current;
    if (!el) return;
    const onLoaded = () => setNativeDuration(el.duration || 0);
    el.addEventListener("loadedmetadata", onLoaded);
    if (el.duration) setNativeDuration(el.duration);
    return () => el.removeEventListener("loadedmetadata", onLoaded);
  }, [src]);

  const displayDuration = hasTranscriptWords ? outputDuration : nativeDuration;
  const pct = (displayedProgress / 1000) * 100;

  // ── No media loaded ───────────────────────────────────────────────────────
  if (!src) {
    return (
      <div className="flex h-full flex-col items-center justify-center gap-3 bg-black text-white/25">
        <Play className="h-12 w-12" strokeWidth={1} />
        <p className="text-sm">No media loaded</p>
      </div>
    );
  }

  return (
    <div className="flex h-full flex-col bg-black">
      {/* Video area */}
      <div className="flex flex-1 items-center justify-center overflow-hidden bg-black">
        <div
          className="relative flex h-full w-full items-center justify-center overflow-hidden bg-[radial-gradient(circle_at_center,rgba(255,255,255,0.06),transparent_48%)]"
          style={{ containerType: "size" }}
        >
          <div style={css ? css.stage : fill}>
            {/* Device frame: shapes behind the picture (they carry the shadow). */}
            {css?.frame && (
              <div aria-hidden="true" style={css.frame.belowGroup}>
                <FrameNodes nodes={css.frame.below} />
              </div>
            )}
            <div style={css ? css.content : (pictureBox ?? fill)}>
              {/* Picture box: the picture's own rectangle (smaller than a phone/tablet screen). */}
              <div style={css?.frame?.inset ?? fill}>
                {/* Crop window: the full frame, offset so only the kept region shows. */}
                <div style={css?.crop ?? fill}>
                  <div
                    ref={pictureRef}
                    style={{
                      ...fill,
                      position: "relative",
                      transformOrigin: "0 0",
                      willChange: "transform",
                    }}
                  >
                    <video
                      ref={videoRef}
                      src={src}
                      className={
                        css || pictureBox
                          ? "h-full w-full object-contain"
                          : "max-h-full max-w-full object-contain"
                      }
                      controls={false}
                      preload="metadata"
                      playsInline
                    />
                    {masks.length > 0 && (
                      <MaskLayer
                        masks={masks}
                        currentTime={currentTime}
                        playing={playing}
                        video={videoRef}
                      />
                    )}
                    <LiveCursorOverlay
                      index={index}
                      cursor={cursor}
                      media={project.media}
                      fallbackId={activeMediaId}
                      currentTime={currentTime}
                      playing={playing}
                    />
                    {followMedia.length > 0 && (
                      <MediaOverlayLayer
                        overlays={followMedia}
                        width={firstMedia?.width ?? 0}
                        height={firstMedia?.height ?? 0}
                        currentTime={currentTime}
                        playing={playing}
                      />
                    )}
                    {followNotes.length > 0 && (
                      <AnnotationOverlay
                        annotations={followNotes}
                        width={firstMedia?.width ?? 0}
                        height={firstMedia?.height ?? 0}
                        currentTime={currentTime}
                        playing={playing}
                      />
                    )}
                    <div
                      ref={dipRef}
                      aria-hidden="true"
                      className="pointer-events-none absolute inset-0 bg-black"
                      style={{ opacity: 0 }}
                    />
                  </div>
                </div>
              </div>
              {!css && fixedOverlay}
            </div>
            {/* Device frame: notch, camera, traffic lights and title, over the picture. */}
            {css?.frame && (
              <div aria-hidden="true" className="pointer-events-none absolute inset-0">
                <FrameNodes nodes={css.frame.above} />
              </div>
            )}
            {css && fixedOverlay}
          </div>
          {loadState === "loading" && (
            <div className="pointer-events-none absolute inset-0 flex items-center justify-center bg-black/45">
              <div className="rounded-md border border-white/10 bg-black/75 px-4 py-3 text-sm text-white/75">
                Loading media...
              </div>
            </div>
          )}
          {loadState === "error" && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/70 px-6 text-center">
              <div className="max-w-sm rounded-md border border-red-400/30 bg-red-950/35 px-4 py-3 text-sm text-red-100">
                <AlertTriangle className="mx-auto mb-2 h-5 w-5" />
                <p className="font-semibold">Video could not be loaded</p>
                <p className="mt-1 text-red-100/75">{loadMessage}</p>
              </div>
            </div>
          )}
          <div className="pointer-events-none absolute left-4 top-4 rounded bg-black/55 px-2 py-1 text-[11px] font-medium text-white/80">
            Preview · edited cut
          </div>
          <div
            ref={crossfadeRef}
            className="pointer-events-none absolute left-1/2 top-4 -translate-x-1/2 rounded bg-black/55 px-2 py-1 text-[11px] font-medium text-white/80"
            style={{ display: "none" }}
          >
            Crossfade · rendered on export
          </div>
          {captionCues.length > 0 && firstMedia && (
            <LiveCaptionOverlay
              cues={captionCues}
              style={captionStyle}
              aspect={frameAspect(sceneOn ? scene : null, firstMedia)}
              currentTime={currentTime}
              playing={playing}
            />
          )}
          <div className="pointer-events-none absolute right-4 top-4 rounded bg-black/55 px-2 py-1 text-[11px] tabular-nums text-white/75">
            {formatTimecode(currentTime, { ms: true })}
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="flex flex-col gap-2 border-t border-white/[0.08] bg-zinc-950 px-3 pb-3 pt-2.5">
        {preview.status && (
          <span role="status" className="text-[10px] text-white/50">
            {preview.status}
          </span>
        )}
        {/* Scrubber */}
        <div className="relative flex items-center">
          {/* Filled track */}
          <div
            className="pointer-events-none absolute left-0 h-1 rounded-l-full bg-white/70"
            style={{ width: `${pct}%` }}
          />
          {/* Speed (blue), freeze-frame hold (amber) and transition (white tick) markers. */}
          {outputDuration > 0 &&
            marks.map((m, i) => {
              const left = (Math.max(0, m.start) / outputDuration) * 100;
              const width = ((m.end - Math.max(0, m.start)) / outputDuration) * 100;
              return (
                <span
                  key={i}
                  aria-hidden="true"
                  title={m.label}
                  className={`tm-marker is-${m.kind}`}
                  style={
                    m.kind === "transition"
                      ? { left: `calc(${left + width / 2}% - 1px)` }
                      : { left: `${left}%`, width: `${width}%` }
                  }
                />
              );
            })}
          <input
            type="range"
            min={0}
            max={1000}
            value={displayedProgress}
            onMouseDown={handleScrubStart}
            onTouchStart={handleScrubStart}
            onChange={handleScrubMove}
            onMouseUp={handleScrubEnd}
            onTouchEnd={handleScrubEnd}
            className="scrubber w-full"
            aria-label="Playback position"
          />
        </div>

        {/* Button row */}
        <div className="flex items-center gap-0.5">
          <Button
            size="icon"
            variant="ghost"
            className="h-7 w-7 text-white/50 hover:bg-white/10 hover:text-white"
            onClick={() => jumpToCut(prevCut)}
            disabled={prevCut === null}
            title="Previous cut (lands 1 s before it)"
            aria-label="Previous cut"
          >
            <ChevronsLeft className="h-4 w-4" />
          </Button>

          <Button
            size="icon"
            variant="ghost"
            className="h-7 w-7 text-white/50 hover:bg-white/10 hover:text-white"
            onClick={() => handleSkip(-5)}
            title="Back 5 s (←)"
          >
            <SkipBack className="h-3.5 w-3.5" />
          </Button>

          <Button
            size="icon"
            variant="ghost"
            className="h-9 w-9 rounded-full bg-primary text-primary-foreground hover:bg-primary/90 hover:scale-105 transition-transform"
            onClick={handlePlayPause}
            disabled={isProcessingEdit && !playing}
            title={playing ? `Pause (${playPauseKey})` : `Play (${playPauseKey})`}
          >
            {playing ? (
              <Pause className="h-4 w-4 fill-current stroke-none" />
            ) : (
              <Play className="h-4 w-4 fill-current stroke-none" />
            )}
          </Button>

          <Button
            size="icon"
            variant="ghost"
            className="h-7 w-7 text-white/50 hover:bg-white/10 hover:text-white"
            onClick={() => handleSkip(5)}
            title="Forward 5 s (→)"
          >
            <SkipForward className="h-3.5 w-3.5" />
          </Button>

          <Button
            size="icon"
            variant="ghost"
            className="h-7 w-7 text-white/50 hover:bg-white/10 hover:text-white"
            onClick={() => jumpToCut(nextCut)}
            disabled={nextCut === null}
            title="Next cut (lands 1 s before it)"
            aria-label="Next cut"
          >
            <ChevronsRight className="h-4 w-4" />
          </Button>

          <span className="ml-1.5 select-none text-xs tabular-nums text-white/50">
            {formatTimecode(currentTime, { ms: false })}
            <span className="mx-1 text-white/25">/</span>
            {formatTimecode(displayDuration, { ms: false })}
          </span>

          <div className="ml-auto flex items-center gap-0.5">
            <select
              aria-label="Preview quality"
              className="max-w-24 rounded bg-zinc-900 px-1 py-1 text-xs text-white/70"
              value={preview.quality}
              onChange={(e) => preview.setQuality(e.target.value as PreviewQuality)}
            >
              <option value="original">Original</option>
              <option value="balanced">Balanced</option>
              <option value="low">Low</option>
            </select>
            <Button
              size="icon"
              variant="ghost"
              className={`h-7 w-7 hover:bg-white/10 hover:text-white ${captionsOn ? "text-primary" : "text-white/40"}`}
              onClick={() => setCaptionsOn((v) => !v)}
              aria-pressed={captionsOn}
              title={captionsOn ? "Hide live captions" : "Show live captions"}
              aria-label="Toggle live captions"
            >
              <Captions className="h-3.5 w-3.5" />
            </Button>
            <Button
              size="sm"
              variant="ghost"
              className="h-7 min-w-[34px] px-1.5 text-xs tabular-nums text-white/40 hover:bg-white/10 hover:text-white"
              onClick={cycleRate}
              title="Playback speed"
            >
              {rate === 1 ? "1×" : `${rate}×`}
            </Button>
            <Button
              size="icon"
              variant="ghost"
              className="h-7 w-7 text-white/50 hover:bg-white/10 hover:text-white"
              onClick={toggleMuted}
              title={muted ? "Unmute" : "Mute"}
            >
              {muted ? <VolumeX className="h-3.5 w-3.5" /> : <Volume2 className="h-3.5 w-3.5" />}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
