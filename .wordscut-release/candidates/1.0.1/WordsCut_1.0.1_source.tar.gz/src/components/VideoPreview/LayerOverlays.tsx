/**
 * Preview of media overlays and privacy masks (`src/lib/layers.ts`), as DOM
 * layers over the single preview `<video>`, which they never touch (the
 * pixelate canvas only reads its current frame). Same geometry as the export
 * (`layers_export.rs`): a box with the frame's aspect, positions in percent,
 * sizes in pixels at 1080 lines scaled with `cqh`.
 */
import { useEffect, useRef, useState, useSyncExternalStore, type CSSProperties } from "react";
import { convertFileSrc } from "@tauri-apps/api/core";
import { fileName, overlayMediaTime, overlayOpacity, type MediaOverlay } from "@/lib/layers";
import { MIN_BLOCK_PX, MIN_BLUR_PX, spansContain, type PrivacyMask } from "@/lib/masks";
import { getPlaybackFrame, subscribePlaybackFrame } from "@/lib/playbackClock";
import { usePlayerStore } from "@/stores/playerStore";

/** Seek a playing overlay video that has drifted further than this from the playhead. */
const DRIFT_SEC = 0.3;
/** Mount a video overlay this long before it shows, so it can load. */
const PRELOAD_SEC = 1;

function useFrameTime(currentTime: number, playing: boolean) {
  const frameTime = useSyncExternalStore(subscribePlaybackFrame, getPlaybackFrame);
  return playing ? frameTime : currentTime;
}

/** A box with the `width` x `height` aspect, centred and fitted like `object-contain`. */
function AspectBox({
  width,
  height,
  children,
  testId,
}: {
  width: number;
  height: number;
  children: React.ReactNode;
  testId: string;
}) {
  return (
    <div
      aria-hidden="true"
      data-testid={testId}
      className="pointer-events-none absolute inset-0 flex items-center justify-center"
      style={{ containerType: "size" }}
    >
      <div
        style={{
          position: "relative",
          width: `min(100cqw, calc(100cqh * ${width} / ${height}))`,
          aspectRatio: `${width} / ${height}`,
          containerType: "size",
          overflow: "hidden",
        }}
      >
        {children}
      </div>
    </div>
  );
}

const place = (r: { x: number; y: number; w: number; h: number }): CSSProperties => ({
  position: "absolute",
  left: `${r.x * 100}%`,
  top: `${r.y * 100}%`,
  width: `${r.w * 100}%`,
  height: `${r.h * 100}%`,
});

function MissingFile({ path }: { path: string }) {
  return (
    <div
      role="img"
      aria-label={`Missing overlay file ${fileName(path)}`}
      data-testid="overlay-missing"
      style={{
        width: "100%",
        height: "100%",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: 4,
        textAlign: "center",
        fontSize: 11,
        color: "#fff",
        background: "repeating-linear-gradient(45deg, #7f1d1d 0 8px, #450a0a 8px 16px)",
        border: "2px dashed #fca5a5",
      }}
    >
      Missing: {fileName(path)} — relink in Overlays
    </div>
  );
}

function OverlayVideo({ o, t, playing }: { o: MediaOverlay; t: number; playing: boolean }) {
  const ref = useRef<HTMLVideoElement>(null);
  const rate = usePlayerStore((s) => s.rate);
  const muted = usePlayerStore((s) => s.muted);
  const [broken, setBroken] = useState(false);
  const inSpan = t >= o.start && t < o.end;
  const mediaTime = overlayMediaTime(o, t);
  useEffect(() => {
    const el = ref.current;
    if (!el || broken) return;
    el.muted = muted || !o.includeAudio;
    el.volume = Math.min(1, 10 ** ((o.gainDb ?? 0) / 20));
    el.playbackRate = rate;
    const ended = o.mediaDuration !== undefined && mediaTime >= o.mediaDuration;
    const drift = Math.abs(el.currentTime - mediaTime);
    try {
      if (playing && inSpan && !ended) {
        if (el.paused || drift > DRIFT_SEC) el.currentTime = mediaTime;
        if (el.paused) void el.play().catch(() => {});
      } else {
        el.pause();
        if (drift > 0.05) el.currentTime = Math.min(mediaTime, o.mediaDuration ?? mediaTime);
      }
    } catch {
      // Metadata not loaded yet; the next frame retries.
    }
  });
  // Stop sound and release the file when the overlay leaves the window.
  useEffect(() => {
    const el = ref.current;
    return () => {
      el?.pause();
      el?.removeAttribute("src");
      el?.load();
    };
  }, []);
  if (broken) return <MissingFile path={o.path} />;
  return (
    <video
      ref={ref}
      src={convertFileSrc(o.path)}
      preload="auto"
      playsInline
      muted
      onError={() => setBroken(true)}
      style={{ width: "100%", height: "100%", objectFit: "fill", display: "block" }}
    />
  );
}

function OverlayImage({ o }: { o: MediaOverlay }) {
  const [broken, setBroken] = useState(false);
  if (broken) return <MissingFile path={o.path} />;
  return (
    <img
      src={convertFileSrc(o.path)}
      alt=""
      draggable={false}
      onError={() => setBroken(true)}
      style={{ width: "100%", height: "100%", objectFit: "fill", display: "block" }}
    />
  );
}

/**
 * Image and video overlays over a `width` x `height` frame. Videos are
 * mounted shortly before their span and removed after it, so only the ones
 * near the playhead hold a decoder.
 */
export function MediaOverlayLayer({
  overlays,
  width,
  height,
  currentTime,
  playing,
}: {
  overlays: readonly MediaOverlay[];
  width: number;
  height: number;
  currentTime: number;
  playing: boolean;
}) {
  const t = useFrameTime(currentTime, playing);
  if (width <= 0 || height <= 0) return null;
  const near = overlays.filter(
    (o) => t < o.end && t >= o.start - (o.kind === "video" ? PRELOAD_SEC : 0),
  );
  if (near.length === 0) return null;
  return (
    <AspectBox width={width} height={height} testId="media-overlays">
      {near.map((o) => (
        <div
          key={o.id}
          data-overlay={o.kind}
          style={{
            ...place(o),
            opacity: overlayOpacity(o, t),
            transform: o.rotation ? `rotate(${o.rotation}deg)` : undefined,
            borderRadius: o.radius ? `${(o.radius / 1080) * 100}cqh` : undefined,
            overflow: "hidden",
          }}
        >
          {o.kind === "video" ? (
            <OverlayVideo o={o} t={t} playing={playing} />
          ) : (
            <OverlayImage o={o} />
          )}
        </div>
      ))}
    </AspectBox>
  );
}

/** Pixelate by drawing the current video frame region small, then scaling it up unsmoothed. */
function PixelateCanvas({
  m,
  video,
  t,
}: {
  m: PrivacyMask;
  video: React.RefObject<HTMLVideoElement | null>;
  t: number;
}) {
  const ref = useRef<React.ElementRef<"canvas">>(null);
  const small = useRef<React.ElementRef<"canvas"> | null>(null);
  useEffect(() => {
    const canvas = ref.current;
    const el = video.current;
    const ctx = canvas?.getContext("2d");
    if (!canvas || !ctx) return;
    const draw = () => {
      // Until a frame can be pixelated the region is a solid fill: the raw
      // picture under it never shows (the canvas itself starts opaque too).
      if (!el || el.readyState < 2 || !el.videoWidth) {
        ctx.fillStyle = "#6b7280";
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        return;
      }
      const [vw, vh] = [el.videoWidth, el.videoHeight];
      const [sx, sy, sw, sh] = [m.x * vw, m.y * vh, Math.max(1, m.w * vw), Math.max(1, m.h * vh)];
      const block = Math.max(MIN_BLOCK_PX, (m.strength * Math.min(vw, vh)) / 1080);
      const [tw, th] = [Math.max(1, Math.ceil(sw / block)), Math.max(1, Math.ceil(sh / block))];
      small.current ??= document.createElement("canvas");
      const s = small.current;
      [s.width, s.height] = [tw, th];
      const sctx = s.getContext("2d");
      if (!sctx) return;
      sctx.drawImage(el, sx, sy, sw, sh, 0, 0, tw, th);
      [canvas.width, canvas.height] = [Math.round(sw), Math.round(sh)];
      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(s, 0, 0, tw, th, 0, 0, canvas.width, canvas.height);
    };
    draw();
    if (!el) return;
    // `t` alone can lag the picture (a seeked frame decodes after the time
    // changes; held or skipped clock updates): redraw on every presented frame,
    // or on every animation frame while playing where rVFC is missing.
    if (typeof el.requestVideoFrameCallback === "function") {
      let id = 0;
      const onFrame = () => {
        draw();
        id = el.requestVideoFrameCallback(onFrame);
      };
      id = el.requestVideoFrameCallback(onFrame);
      return () => el.cancelVideoFrameCallback(id);
    }
    let raf = 0;
    const tick = () => {
      if (!el.paused) draw();
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [m, video, t]);
  return (
    <canvas
      ref={ref}
      style={{ width: "100%", height: "100%", display: "block", background: "#6b7280" }}
    />
  );
}

/** One mask with the spans where its source content is on screen and its source's size. */
export interface MaskView {
  m: PrivacyMask;
  spans: ReadonlyArray<[number, number]>;
  width: number;
  height: number;
}

/**
 * Privacy masks inside the zoom wrapper, so they follow zoom and crop like
 * the export. Each mask is placed on ITS source's picture (the playing
 * `<video>` is fitted with `object-contain`, so a 4:3 source in a 16:9 box is
 * pillarboxed the same way). A preview only: the export applies masks per
 * clip on the source frames (`layers_export.rs`).
 */
export function MaskLayer({
  masks,
  currentTime,
  playing,
  video,
}: {
  masks: readonly MaskView[];
  currentTime: number;
  playing: boolean;
  video: React.RefObject<HTMLVideoElement | null>;
}) {
  const t = useFrameTime(currentTime, playing);
  const active = masks.filter((v) => v.width > 0 && v.height > 0 && spansContain(v.spans, t));
  if (active.length === 0) return null;
  // The decoded frame's own size wins over stored dimensions (older projects
  // stored landscape sizes for rotated phone clips).
  const el = video.current;
  const real =
    el && el.videoWidth > 0 && el.videoHeight > 0 ? [el.videoWidth, el.videoHeight] : null;
  return (
    <div data-testid="privacy-masks" className="pointer-events-none absolute inset-0">
      {active.map(({ m, width: storedW, height: storedH }) => {
        const [width, height] = real ?? [storedW, storedH];
        const round = m.shape === "ellipse" ? "50%" : 0;
        const style: CSSProperties = { ...place(m), borderRadius: round, overflow: "hidden" };
        if (m.effect === "blur") {
          const blur = `blur(max(${MIN_BLUR_PX}px, ${(m.strength / 1080) * 100}cqmin))`;
          Object.assign(style, { backdropFilter: blur, WebkitBackdropFilter: blur });
        } else if (m.effect === "solid") {
          style.background = m.color;
        } else if (m.effect === "dim") {
          style.boxShadow = `0 0 0 200vmax rgba(0, 0, 0, ${m.strength / 100})`;
        }
        return (
          <AspectBox key={m.id} width={width} height={height} testId="privacy-mask-box">
            <div data-mask={m.effect} style={style}>
              {m.effect === "pixelate" && <PixelateCanvas m={m} video={video} t={t} />}
            </div>
          </AspectBox>
        );
      })}
    </div>
  );
}
