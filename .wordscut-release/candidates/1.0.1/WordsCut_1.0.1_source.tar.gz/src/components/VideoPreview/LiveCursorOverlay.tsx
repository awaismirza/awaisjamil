import { useSyncExternalStore } from "react";
import { getPlaybackFrame, subscribePlaybackFrame } from "@/lib/playbackClock";
import { indexedSource, type TimelineIndex } from "@/lib/timelineIndex";
import type { ProjectCursor } from "@/lib/cursorStyle";
import type { SourceMedia } from "@/lib/edl";
import { CursorOverlay } from "./CursorOverlay";
/** Only this small effect layer renders per frame; the editor shell runs at timecode cadence. */
export function LiveCursorOverlay({
  index,
  cursor,
  media,
  fallbackId,
  currentTime,
  playing,
}: {
  index: TimelineIndex;
  cursor: ProjectCursor;
  media: Record<string, SourceMedia>;
  fallbackId: string | null;
  currentTime: number;
  playing: boolean;
}) {
  const frameTime = useSyncExternalStore(subscribePlaybackFrame, getPlaybackFrame);
  const t = playing ? frameTime : currentTime;
  const source = indexedSource(index, t);
  const id = source?.entry.mediaId ?? fallbackId;
  const item = id ? media[id] : undefined;
  return (
    <CursorOverlay
      track={id ? cursor.tracks[id] : undefined}
      style={cursor.style}
      t={source?.sourceTime ?? t}
      clipStart={source?.entry.sourceIn ?? 0}
      width={item?.width ?? 0}
      height={item?.height ?? 0}
    />
  );
}
