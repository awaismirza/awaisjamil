import { useMemo } from "react";
import { cursorAt, smoothCursorTrack, type CursorTrack } from "@/lib/cursor";
import { cursorAppearance, type CursorStyle } from "@/lib/cursorStyle";

/** All paths are bundled, with the pointer hotspot at the group's origin. */
function Glyph({ shape, color }: Pick<CursorStyle, "shape" | "color">) {
  const common = {
    stroke: "#171717",
    strokeWidth: 1.5,
    strokeLinejoin: "round" as const,
    fill: color,
  };
  switch (shape) {
    case "dot":
      return <circle r="5" {...common} />;
    case "ring":
      return <circle r="10" fill="none" stroke={color} strokeWidth="2.5" />;
    case "crosshair":
      return <path d="M-13 0H13M0-13V13" fill="none" stroke={color} strokeWidth="2" />;
    case "pointer":
      return (
        <path
          d="M0 0C0-3 5-3 5 0V11L7 9C9 8 11 9 11 11C14 8 17 10 17 13C20 11 23 13 23 16V23C23 30 8 32 5 25L-3 15C-5 11-1 9 2 12L5 15V0"
          {...common}
        />
      );
    case "macos":
      return (
        <path
          d="M0 0L0 30L8 22L14 34L20 31L14 19L25 19Z"
          fill="#101010"
          stroke={color}
          strokeWidth="1.8"
          strokeLinejoin="round"
        />
      );
    default:
      return <path d="M0 0L0 29L8 21L14 33L20 30L14 18L25 18Z" {...common} />;
  }
}
export function CursorOverlay({
  track,
  style,
  t,
  clipStart,
  width,
  height,
}: {
  track?: CursorTrack;
  style: CursorStyle;
  t: number;
  clipStart: number;
  width: number;
  height: number;
}) {
  const smoothed = useMemo(
    () => (track ? smoothCursorTrack(track, style.smoothing) : undefined),
    [track, style.smoothing],
  );
  if (!track || !smoothed || width <= 0 || height <= 0) return null;
  const sample = cursorAppearance(track, smoothed, t, style, clipStart);
  if (!sample.visible || !sample.point) return null;
  const size = (style.size * height) / 1080;
  const transform = (x: number, y: number, scale = 1) =>
    `translate(${x * width} ${y * height}) scale(${(size / 32) * scale})`;
  return (
    <svg
      className="cursor-overlay"
      viewBox={`0 0 ${width} ${height}`}
      preserveAspectRatio="xMidYMid meet"
      aria-hidden="true"
      data-testid="cursor-overlay"
    >
      {style.motionBlur &&
        [1 / 30, 1 / 60].map((age, i) => {
          const p = cursorAt(smoothed, t - age);
          if (!p || p.outside || t - age < clipStart) return null;
          const distance = Math.hypot(p.x - sample.point!.x, p.y - sample.point!.y);
          return distance > 0.001 ? (
            <g
              key={age}
              opacity={(i + 1) * 0.1}
              style={{ filter: `blur(${height / 1080}px)` }}
              transform={transform(p.x, p.y)}
            >
              <Glyph {...style} />
            </g>
          ) : null;
        })}
      {style.clickEffect !== "bounce" &&
        sample.clicks.map((click) => (
          <circle
            key={click.t}
            cx={click.x * width}
            cy={click.y * height}
            r={size * (style.clickEffect === "ripple" ? 0.4 + click.progress * 1.6 : 0.65)}
            fill="none"
            stroke={style.color}
            strokeWidth={(2 * height) / 1080}
            opacity={1 - click.progress}
          />
        ))}
      <g
        data-cursor-shape={style.shape}
        transform={transform(sample.point.x, sample.point.y, sample.bounce)}
      >
        <Glyph {...style} />
      </g>
    </svg>
  );
}
