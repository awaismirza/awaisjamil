import { useSyncExternalStore, type CSSProperties } from "react";
import { cueAt, type LaidOutCue } from "@/lib/captionLayout";
import type { CaptionStyle } from "@/lib/captionStyle";
import { getPlaybackFrame, subscribePlaybackFrame } from "@/lib/playbackClock";

const rgba = (hex: string, a: number) => {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${a})`;
};
/** Sizes are percent of the frame height (`cqh`), the same 1080-line scale the exporter uses. */
const px = (v: number) => `${((v / 1080) * 100).toFixed(4)}cqh`;

/**
 * One cue drawn with the caption style. `active` is the [line, word] being
 * spoken (highlighted when the style asks for it). Must sit inside a size
 * container whose height is the frame's: see `CaptionFrame`.
 */
export function CaptionBox({
  cue,
  style,
  active,
}: {
  cue: LaidOutCue;
  style: CaptionStyle;
  active: { line: number; word: number } | null;
}) {
  const text: CSSProperties = {
    fontFamily: `"${style.font}", "Helvetica Neue", Arial, sans-serif`,
    fontWeight: style.weight === "bold" ? 700 : 400,
    fontSize: px(style.size),
    lineHeight: 1.2,
    color: style.color,
    ...(style.box
      ? {
          background: rgba(style.boxColor, style.boxOpacity),
          padding: `0 ${px(style.size * 0.22)}`,
        }
      : {
          WebkitTextStroke:
            style.outline > 0 ? `${px(style.outline * 2)} ${style.outlineColor}` : undefined,
          paintOrder: "stroke fill",
          textShadow:
            style.shadow > 0
              ? `${px(style.shadow)} ${px(style.shadow)} ${px(style.shadow)} rgba(0,0,0,0.5)`
              : undefined,
        }),
  };
  return (
    <div style={{ textAlign: "center", whiteSpace: "pre" }}>
      {cue.lines.map((line, l) => (
        <div key={l}>
          <span style={{ ...text, display: "inline-block" }}>
            {line.map((w, k) => (
              <span
                key={k}
                style={
                  style.highlight && active?.line === l && active.word === k
                    ? { color: style.highlightColor }
                    : undefined
                }
              >
                {k > 0 ? " " : ""}
                {w.text}
              </span>
            ))}
          </span>
        </div>
      ))}
    </div>
  );
}

/** A box with the output frame's aspect, fitted and centred in its (size-container) parent. */
export function CaptionFrame({
  aspect,
  position,
  children,
}: {
  aspect: number;
  position: CaptionStyle["position"];
  children: React.ReactNode;
}) {
  return (
    <div
      aria-hidden="true"
      className="pointer-events-none absolute inset-0 m-auto"
      style={{
        width: `min(100cqw, calc(100cqh * ${aspect}))`,
        height: `min(100cqh, calc(100cqw / ${aspect}))`,
        containerType: "size",
      }}
    >
      <div
        className="absolute inset-x-[5%] flex flex-col items-center"
        style={
          position === "top"
            ? { top: "6%" }
            : position === "middle"
              ? { top: "50%", transform: "translateY(-50%)" }
              : { bottom: "6%" }
        }
      >
        {children}
      </div>
    </div>
  );
}

/** Live caption for the preview; only this layer re-renders per frame while playing. */
export function LiveCaptionOverlay({
  cues,
  style,
  aspect,
  currentTime,
  playing,
}: {
  cues: LaidOutCue[];
  style: CaptionStyle;
  aspect: number;
  currentTime: number;
  playing: boolean;
}) {
  const frameTime = useSyncExternalStore(subscribePlaybackFrame, getPlaybackFrame);
  const hit = cueAt(cues, playing ? frameTime : currentTime);
  if (!hit) return null;
  return (
    <CaptionFrame aspect={aspect} position={style.position}>
      <CaptionBox
        cue={hit.cue}
        style={style}
        active={hit.line >= 0 ? { line: hit.line, word: hit.word } : null}
      />
    </CaptionFrame>
  );
}
