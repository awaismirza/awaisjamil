/**
 * MusicPreview — plays the project's music / SFX tracks in step with the
 * preview, so a mix can be judged before export. Renders nothing.
 *
 * One HTMLAudioElement per track, driven from the player store (output-time
 * position, play/pause, rate, mute). Which tracks sound, where in their media
 * and how loud (gain, fades, mute, solo, offset) comes from the pure rules in
 * `lib/audioMix.ts`, the same ones the exporter follows.
 *
 * Limits, shown in the Music tracks dialog: ducking is export-only; element
 * volume cannot exceed 0 dB, so boosted tracks are capped there in preview;
 * the player position updates about ten times a second, so fades step at that rate.
 */

import { useEffect, useRef } from "react";
import { convertFileSrc } from "@tauri-apps/api/core";
import { previewVoices } from "@/lib/audioMix";
import { projectAudioTracks, totalDuration } from "@/lib/edl";
import { useMusicPreviewStore } from "@/stores/musicPreviewStore";
import { usePlayerStore } from "@/stores/playerStore";
import { useProjectStore } from "@/stores/projectStore";

/** Seek when a playing element has drifted further than this from the playhead. */
const DRIFT_SEC = 0.3;
/** Seek a paused element (scrubbing) when it is further than this. */
const PAUSED_SEEK_SEC = 0.05;
/** After a failed play() or seek, leave the element alone this long. */
const BACKOFF_MS = 2000;

interface Entry {
  el: HTMLAudioElement;
  src: string;
  /** The file cannot be decoded or loaded; cleared when its source changes. */
  broken: boolean;
  /** Do not touch the element before this time (ms, performance clock). */
  retryAt: number;
}

export function MusicPreview() {
  const project = useProjectStore((s) => s.project);
  const currentTime = usePlayerStore((s) => s.currentTime);
  const playing = usePlayerStore((s) => s.playing);
  const rate = usePlayerStore((s) => s.rate);
  const muted = usePlayerStore((s) => s.muted);
  const elements = useRef(new Map<string, Entry>());

  useEffect(() => {
    const tracks = projectAudioTracks(project);
    const live = elements.current;
    // Drop elements for removed tracks.
    for (const [id, entry] of live) {
      if (!tracks.some((t) => t.id === id)) {
        entry.el.pause();
        entry.el.removeAttribute("src");
        live.delete(id);
        useMusicPreviewStore.getState().setFailed(id, false);
      }
    }
    const voices = new Map(
      previewVoices(tracks, project.media, totalDuration(project), currentTime).map((v) => [
        v.trackId,
        v,
      ]),
    );
    for (const track of tracks) {
      const voice = voices.get(track.id);
      const path = project.media[track.mediaId]?.path;
      let entry = live.get(track.id);
      if (!voice || !path) {
        entry?.el.pause();
        continue;
      }
      const src = convertFileSrc(path);
      if (!entry) {
        const el = new Audio();
        el.preload = "auto";
        const created: Entry = { el, src: "", broken: false, retryAt: 0 };
        el.addEventListener("error", () => {
          created.broken = true;
          useMusicPreviewStore.getState().setFailed(track.id, true);
        });
        entry = created;
        live.set(track.id, entry);
      }
      const { el } = entry;
      if (entry.src !== src) {
        el.src = src;
        entry.src = src;
        entry.broken = false;
        entry.retryAt = 0;
        useMusicPreviewStore.getState().setFailed(track.id, false);
      }
      // A file that failed to load, one in back-off, or one that has played to
      // its end is left alone rather than re-seeked on every playhead update.
      if (entry.broken || globalThis.performance.now() < entry.retryAt) continue;
      if (el.ended && voice.mediaTime >= el.duration - 0.5) continue;
      const backOff = () => {
        entry.retryAt = globalThis.performance.now() + BACKOFF_MS;
      };
      el.muted = muted;
      el.volume = Math.min(1, voice.gain);
      el.playbackRate = rate;
      el.preservesPitch = true;
      const drift = Math.abs(el.currentTime - voice.mediaTime);
      if (playing) {
        if (el.paused || drift > DRIFT_SEC) {
          try {
            el.currentTime = voice.mediaTime;
          } catch {
            backOff(); // Metadata not loaded yet.
          }
        }
        if (el.paused) void el.play().catch(backOff);
      } else {
        el.pause();
        if (drift > PAUSED_SEEK_SEC) {
          try {
            el.currentTime = voice.mediaTime;
          } catch {
            backOff();
          }
        }
      }
    }
  }, [project, currentTime, playing, rate, muted]);

  // Stop everything on unmount.
  useEffect(() => {
    const live = elements.current;
    return () => {
      for (const { el } of live.values()) {
        el.pause();
        el.removeAttribute("src");
      }
      live.clear();
    };
  }, []);

  return null;
}
