/**
 * Find / Replace panel, shown in the sidebar.
 *
 * Operates on the EDL directly via the project store — every replacement is a
 * normal mutation so undo/redo works. Matches are highlighted in the
 * transcript while the panel is open. Filler removal lives in the Cleanup panel.
 */

import { useEffect, useMemo, useRef, useState } from "react";
import { useProjectStore } from "@/stores/projectStore";
import { useUIStore } from "@/stores/uiStore";
import { ChevronDown, ChevronUp, Replace, Search } from "lucide-react";

export function FindReplacePanel() {
  const replaceText = useProjectStore((s) => s.replaceText);
  const deleteWordsByText = useProjectStore((s) => s.deleteWordsByText);
  const pushToast = useUIStore((s) => s.pushToast);

  const [find, setFind] = useState("");
  const [replace, setReplace] = useState("");
  const [caseSensitive, setCaseSensitive] = useState(false);
  const [wholeWord, setWholeWord] = useState(true);
  const [matchIndex, setMatchIndex] = useState(0);

  const findInputRef = useRef<HTMLInputElement | null>(null);

  // Focus the find input when the panel opens.
  useEffect(() => {
    findInputRef.current?.focus();
  }, []);

  // Highlight matches in the editor whenever the search term changes.
  useEffect(() => {
    const root = document.querySelector(".transcript-editor");
    if (!root) return;
    root.querySelectorAll<HTMLElement>(".word.is-match").forEach((el) => {
      el.classList.remove("is-match", "is-current-match");
    });
    if (!find) return;
    const needle = caseSensitive ? find : find.toLowerCase();
    const wordEls = root.querySelectorAll<HTMLElement>(".word");
    const matches: HTMLElement[] = [];
    wordEls.forEach((el) => {
      const text = el.textContent ?? "";
      const haystack = caseSensitive ? text : text.toLowerCase();
      const isMatch = wholeWord
        ? haystack.replace(/^[\s.,!?;:"'()[\]{}—–-]+|[\s.,!?;:"'()[\]{}—–-]+$/g, "") === needle
        : haystack.includes(needle);
      if (isMatch) {
        el.classList.add("is-match");
        matches.push(el);
      }
    });
    if (matches.length > 0) {
      const idx = matchIndex % matches.length;
      matches[idx]!.classList.add("is-current-match");
      matches[idx]!.scrollIntoView({ behavior: "smooth", block: "center" });
    }
    return () => {
      root
        .querySelectorAll<HTMLElement>(".word.is-match")
        .forEach((el) => el.classList.remove("is-match", "is-current-match"));
    };
  }, [find, caseSensitive, wholeWord, matchIndex]);

  const matchCount = useMemo(() => {
    if (!find) return 0;
    const root = document.querySelector(".transcript-editor");
    if (!root) return 0;
    const needle = caseSensitive ? find : find.toLowerCase();
    let count = 0;
    root.querySelectorAll<HTMLElement>(".word").forEach((el) => {
      const text = el.textContent ?? "";
      const haystack = caseSensitive ? text : text.toLowerCase();
      const m = wholeWord
        ? haystack.replace(/^[\s.,!?;:"'()[\]{}—–-]+|[\s.,!?;:"'()[\]{}—–-]+$/g, "") === needle
        : haystack.includes(needle);
      if (m) count++;
    });
    return count;
  }, [find, caseSensitive, wholeWord]);

  function step(delta: number) {
    if (matchCount === 0) return;
    setMatchIndex((i) => (i + delta + matchCount) % matchCount);
  }

  function handleReplaceAll() {
    if (!find) return;
    const n = replaceText(find, replace, { caseSensitive, wholeWord });
    if (n === 0) {
      pushToast({ title: "No matches found" });
    } else {
      pushToast({ title: `Replaced ${n} ${n === 1 ? "word" : "words"}` });
    }
  }

  function handleRemoveFind() {
    if (!find) return;
    const n = deleteWordsByText(new Set([find.toLowerCase().trim()]));
    if (n === 0) {
      pushToast({ title: "No matches found" });
    } else {
      pushToast({ title: `Removed ${n} ${n === 1 ? "word" : "words"}` });
    }
  }

  const counter = find
    ? matchCount === 0
      ? "No matches"
      : `${(matchIndex % matchCount) + 1} of ${matchCount}`
    : "";

  return (
    <div className="fr-panel">
      <section className="fr-section">
        <label className="fr-field">
          <span className="fr-label">Find</span>
          <span className="fr-input-row">
            <Search className="h-4 w-4 shrink-0 text-muted-foreground" />
            <input
              ref={findInputRef}
              type="text"
              value={find}
              placeholder="Word or phrase"
              onChange={(e) => {
                setFind(e.target.value);
                setMatchIndex(0);
              }}
              onKeyDown={(e) => {
                if (e.key === "Enter") step(e.shiftKey ? -1 : 1);
              }}
              className="fr-input"
            />
          </span>
        </label>
        <div className="fr-nav">
          <span className="fr-counter" aria-live="polite">
            {counter}
          </span>
          <button
            type="button"
            className="fr-icon-btn"
            onClick={() => step(-1)}
            disabled={matchCount === 0}
            aria-label="Previous match"
            title="Previous (Shift+Enter)"
          >
            <ChevronUp className="h-4 w-4" />
          </button>
          <button
            type="button"
            className="fr-icon-btn"
            onClick={() => step(1)}
            disabled={matchCount === 0}
            aria-label="Next match"
            title="Next (Enter)"
          >
            <ChevronDown className="h-4 w-4" />
          </button>
        </div>
        <div className="fr-options">
          <label className="fr-option">
            <input
              type="checkbox"
              checked={caseSensitive}
              onChange={(e) => setCaseSensitive(e.target.checked)}
            />
            Match case
          </label>
          <label className="fr-option">
            <input
              type="checkbox"
              checked={wholeWord}
              onChange={(e) => setWholeWord(e.target.checked)}
            />
            Whole word
          </label>
        </div>
      </section>

      <section className="fr-section">
        <label className="fr-field">
          <span className="fr-label">Replace with</span>
          <span className="fr-input-row">
            <Replace className="h-4 w-4 shrink-0 text-muted-foreground" />
            <input
              type="text"
              value={replace}
              placeholder="Replacement text"
              onChange={(e) => setReplace(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") handleReplaceAll();
              }}
              className="fr-input"
            />
          </span>
        </label>
        <button type="button" className="cl-secondary" onClick={handleReplaceAll} disabled={!find}>
          Replace all
        </button>
        <button
          type="button"
          className="cl-secondary is-danger"
          onClick={handleRemoveFind}
          disabled={!find || matchCount === 0}
          title="Delete every occurrence of the search term"
        >
          Delete {matchCount > 0 ? `${matchCount} ` : ""}match{matchCount === 1 ? "" : "es"}
        </button>
      </section>
    </div>
  );
}
