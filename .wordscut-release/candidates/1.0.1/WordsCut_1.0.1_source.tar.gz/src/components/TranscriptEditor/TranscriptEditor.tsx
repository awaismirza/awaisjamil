/**
 * The primary editing surface — TipTap renders the transcript with each word as
 * a read-only WordNode. Click → seek + play. Select → highlight. Delete → drop
 * from the EDL.
 *
 * Layout:
 *   ┌─────────────────────────────────────────────────────────────┐
 *   │                                                              │
 *   │   00:12  Lorem ipsum dolor sit amet…                         │
 *   │                                                              │
 *   │   00:34  Consectetur adipiscing elit…                        │
 *   │                                                              │
 *   └─────────────────────────────────────────────────────────────┘
 *
 * Paragraph timestamps render as a *separate* React-controlled column on the
 * left, NOT as injected DOM inside each <p>. That avoids the historical
 * double-injection bug where a re-render could duplicate the stamp.
 */

import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { EditorContent, useEditor } from "@tiptap/react";
import Document from "@tiptap/extension-document";
import Paragraph from "@tiptap/extension-paragraph";
import Text from "@tiptap/extension-text";
import { WordNode } from "./WordNode";
import { PauseNode } from "./PauseNode";
import { SelectionMenu } from "./SelectionMenu";
import { useProjectStore } from "@/stores/projectStore";
import { usePlayerStore } from "@/stores/playerStore";
import { useUIStore } from "@/stores/uiStore";
import { findFillersInSegments } from "@/lib/fillers";
import { useFillerStore } from "@/stores/fillerStore";
import { computeTimeline, entryOutputAt, totalDuration, wordIdToOutputTime } from "@/lib/edl";
import { getTimelineIndex, indexedWord } from "@/lib/timelineIndex";
import { subscribePlaybackFrame, getPlaybackFrame } from "@/lib/playbackClock";
import { layoutTranscript, zoomWordMap } from "@/lib/transcriptLayout";
import { getTimelineIndex as timelineIndexFor } from "@/lib/timelineIndex";
import { sanitizeZoomRegions } from "@/lib/zoom";
import { useEditorUiStore } from "@/stores/editorUiStore";
import { formatTimecode } from "@/lib/timecode";
import { useEditorShortcutLabel } from "@/hooks/useShortcutLabel";

/** Friendly names for speaker IDs found in the transcript. */
const SPEAKER_NAMES: Record<string, string> = {
  A: "Maya",
  B: "Daniel",
  speaker_0: "Maya",
  speaker_1: "Daniel",
};

function speakerLabel(speakerId: string | undefined): string {
  if (!speakerId) return "Speaker";
  return SPEAKER_NAMES[speakerId] ?? speakerId;
}

/** Map raw speaker ID to a stable bucket ("A" or "B") for color theming. */
function speakerBucket(speakerId: string | undefined): "A" | "B" | "default" {
  if (!speakerId) return "default";
  if (speakerId === "A" || speakerId === "speaker_0") return "A";
  if (speakerId === "B" || speakerId === "speaker_1") return "B";
  // Fallback: hash to A/B so multi-speaker transcripts still get color variety.
  let h = 0;
  for (let i = 0; i < speakerId.length; i++) h = (h * 31 + speakerId.charCodeAt(i)) | 0;
  return h % 2 === 0 ? "A" : "B";
}

/** Render seconds as a compact MM:SS stamp (no milliseconds). */
function stamp(seconds: number): string {
  return formatTimecode(seconds, { ms: false });
}

function getSelectedWordIds(root: HTMLElement): string[] {
  const selection = window.getSelection();
  if (!selection || selection.rangeCount === 0 || selection.isCollapsed) return [];
  const range = selection.getRangeAt(0);
  const ids: string[] = [];
  root.querySelectorAll<HTMLElement>("[data-word-id]").forEach((el) => {
    try {
      if (range.intersectsNode(el)) {
        const id = el.dataset.wordId;
        if (id) ids.push(id);
      }
    } catch {
      // Firefox/WebKit can throw for detached nodes during fast re-renders.
    }
  });
  return ids;
}

function nodeIsInside(root: HTMLElement, node: Node | null): boolean {
  if (!node) return false;
  const el = node.nodeType === Node.ELEMENT_NODE ? (node as Element) : node.parentElement;
  return !!el && root.contains(el);
}

export function TranscriptEditor() {
  const undoKey = useEditorShortcutLabel("undo");
  const project = useProjectStore((s) => s.project);
  const deletePauseById = useProjectStore((s) => s.deletePauseById);
  const setSelectedWordIds = usePlayerStore((s) => s.setSelectedWordIds);
  // Pause tokens now live in projectStore so they survive undo/redo of EDL edits.
  const pauseTokens = useProjectStore((s) => s.pauseTokens);
  const selectedWordIds = usePlayerStore((s) => s.selectedWordIds);
  const withProcessingEdit = useUIStore((s) => s.withProcessingEdit);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const editorRef = useRef<HTMLDivElement | null>(null);

  // Track each paragraph's vertical position so we can render the floating
  // timestamp column at exactly the same y as its <p>.
  const [paragraphTops, setParagraphTops] = useState<number[]>([]);

  // Flatten all words across segments in output order.
  const words = useMemo(() => project.segments.flatMap((s) => s.words), [project.segments]);
  const pauseMediaId = Object.keys(project.media)[0];
  const layout = useMemo(
    () => layoutTranscript(project.segments, pauseTokens, pauseMediaId),
    [project.segments, pauseTokens, pauseMediaId],
  );
  // The timestamp column shows OUTPUT time, so an appended clip reads as the end of the video.
  const zoomWords = useMemo(
    () =>
      zoomWordMap(
        timelineIndexFor(project.segments).entries,
        sanitizeZoomRegions(project.zoomRegions, totalDuration(project)),
      ),
    [project],
  );
  const paragraphs = useMemo(() => {
    const entries = new Map(computeTimeline(project).map((e) => [e.segmentId, e]));
    return layout.map((p) => {
      const entry = entries.get(p.segmentId);
      const first = p.words[0]!;
      const startTime = entry
        ? entryOutputAt(entry, Math.max(entry.sourceIn, first.start))
        : first.start;
      return { words: p.words, startTime };
    });
  }, [layout, project]);

  // Per-paragraph speaker (first word in the paragraph wins).
  const paragraphSpeakers = useMemo(() => paragraphs.map((p) => p.words[0]?.speaker), [paragraphs]);

  // Fillers matching the current selection (multi-word aware). The same match
  // list drives the highlight here and the review list in the Cleanup panel.
  const selectedFillers = useFillerStore((st) => st.selected);
  const fillerMatches = useMemo(
    () => findFillersInSegments(project.segments, selectedFillers),
    [project.segments, selectedFillers],
  );
  const fillerIds = useMemo(
    () => new Set(fillerMatches.flatMap((m) => m.wordIds)),
    [fillerMatches],
  );

  const editor = useEditor({
    extensions: [Document, Paragraph, Text, WordNode, PauseNode],
    editable: false,
    content: { type: "doc", content: [] },
    editorProps: {
      attributes: {
        class: "transcript-editor",
      },
    },
  });

  const handleTranscriptClick = useCallback(
    (event: React.MouseEvent<HTMLDivElement>) => {
      const selection = window.getSelection();
      if (selection && !selection.isCollapsed) return;

      // Pause badge click: remove that pause by its stable id.
      const pauseEl = (event.target as HTMLElement | null)?.closest<HTMLElement>("[data-pause]");
      if (pauseEl && containerRef.current?.contains(pauseEl)) {
        const pauseId = pauseEl.dataset.pauseId;
        if (pauseId) void withProcessingEdit("Updating timeline…", () => deletePauseById(pauseId));
        return;
      }

      const wordEl = (event.target as HTMLElement | null)?.closest<HTMLElement>("[data-word-id]");
      if (!wordEl || !containerRef.current?.contains(wordEl)) return;
      const wordId = wordEl.dataset.wordId;
      if (!wordId) return;
      useEditorUiStore.getState().selectZoomRegion(wordEl.dataset.zoom ?? null);
      const mapped = wordIdToOutputTime(project, wordId);
      if (!mapped) return;
      window.dispatchEvent(
        new CustomEvent("yusafcut:seek-output", {
          detail: { time: mapped.outputTime, play: true },
        }),
      );
    },
    [project, deletePauseById, withProcessingEdit],
  );

  // Wire up keyboard deletion for selected pause nodes (fired by PauseNode's
  // addKeyboardShortcuts).  The custom event carries the stable pauseId.
  useEffect(() => {
    function onDeletePause(e: Event) {
      const pauseId = (e as CustomEvent<{ pauseId: string }>).detail.pauseId;
      if (pauseId) void withProcessingEdit("Updating timeline…", () => deletePauseById(pauseId));
    }
    window.addEventListener("yusafcut:delete-pause", onDeletePause);
    return () => window.removeEventListener("yusafcut:delete-pause", onDeletePause);
  }, [deletePauseById, withProcessingEdit]);

  // Re-render the TipTap document whenever the EDL or pause tokens change.
  // Pauses marked as `deleted` are omitted from the rebuild so they disappear
  // immediately — no duplicate badge problem since setPauseTokens always replaces.
  //
  // Pauses are placed by MERGING words and pauses into one time-sorted stream and
  // anchoring each pause after the last word whose *start* precedes the pause's
  // start. We deliberately compare against word START times, never word END
  // times: Whisper (especially large-v3 without DTW) stretches a word's `end` to
  // abut the next word, absorbing the silence into the preceding word — so the
  // inter-word "gap" is near-zero and any end/gap-based match silently drops the
  // badge. Start-anchoring always finds exactly one home for every pause.
  useEffect(() => {
    if (!editor) return;

    const paraContents: object[][] = layout.map((paragraph) => {
      const content: object[] = [];
      let wordCount = 0;
      for (const tok of paragraph.tokens) {
        if (tok.kind === "word") {
          const w = tok.word;
          if (wordCount++ > 0) content.push({ type: "text", text: " " });
          content.push({
            type: "word",
            attrs: {
              wordId: w.id,
              start: w.start,
              end: w.end,
              confidence: w.confidence,
              filler: fillerIds.has(w.id),
              zoom: zoomWords.get(w.id) ?? null,
            },
            content: [{ type: "text", text: w.text }],
          });
        } else {
          const p = tok.pause;
          // A visually shortened pause shows its shorter duration.
          content.push({
            type: "pause",
            attrs: {
              pauseId: p.id,
              srcStart: p.start,
              srcEnd: p.end,
              duration: p.shortenedTo ?? p.duration,
            },
          });
        }
      }
      return content;
    });

    const cleanDoc = {
      type: "doc",
      content: paraContents
        .filter((c) => c.length > 0)
        .map((content) => ({ type: "paragraph", content })),
    };

    editor.commands.setContent(cleanDoc as never, false);
  }, [editor, layout, fillerIds, zoomWords]);

  // Measure paragraph positions so the floating timestamp column lines up.
  // Re-measures on layout changes (resize, content change).
  useLayoutEffect(() => {
    function measure() {
      const root = editorRef.current;
      if (!root) return;
      const paras = root.querySelectorAll<HTMLElement>(".transcript-editor p");
      const rootRect = root.getBoundingClientRect();
      const tops: number[] = [];
      paras.forEach((p) => {
        const r = p.getBoundingClientRect();
        tops.push(r.top - rootRect.top + root.scrollTop);
      });
      setParagraphTops(tops);
    }
    measure();
    // Re-measure shortly after — TipTap's setContent renders async.
    const t = setTimeout(measure, 50);
    const ro = new ResizeObserver(measure);
    if (editorRef.current) ro.observe(editorRef.current);
    window.addEventListener("resize", measure);
    return () => {
      clearTimeout(t);
      ro.disconnect();
      window.removeEventListener("resize", measure);
    };
  }, [paragraphs, editor]);

  // Sync native text selection → selected word IDs. The editor is intentionally
  // read-only, so selection tracking has to come from the DOM rather than
  // ProseMirror transactions.
  useEffect(() => {
    function onSelectionChange() {
      const root = containerRef.current;
      const selection = window.getSelection();
      if (!root || !selection) return;
      if (!nodeIsInside(root, selection.anchorNode) && !nodeIsInside(root, selection.focusNode)) {
        return;
      }
      setSelectedWordIds(getSelectedWordIds(root));
    }
    document.addEventListener("selectionchange", onSelectionChange);
    return () => document.removeEventListener("selectionchange", onSelectionChange);
  }, [setSelectedWordIds]);

  // Highlight timeline/keyboard selections in the transcript too.
  useEffect(() => {
    const root = containerRef.current;
    if (!root) return;
    root
      .querySelectorAll<HTMLElement>(".word.is-selected")
      .forEach((el) => el.classList.remove("is-selected"));
    selectedWordIds.forEach((id) => {
      const el = root.querySelector<HTMLElement>(`[data-word-id="${CSS.escape(id)}"]`);
      if (el) el.classList.add("is-selected");
    });
  }, [selectedWordIds, paragraphs]);

  // Highlight the currently playing word.
  // During silence gaps between words we keep the preceding word dimly highlighted
  // (is-silence-after) so the playhead position stays visible in the transcript.
  useEffect(() => {
    const root = containerRef.current;
    if (!root) return;
    const index = getTimelineIndex(project.segments);
    let elements = new Map<string, HTMLElement[]>();
    let previous: HTMLElement | undefined;
    let previousKey = "";
    let manualUntil = 0;
    const onManualScroll = () => {
      manualUntil = Date.now() + 1800;
    };
    const paint = (time: number) => {
      const active = indexedWord(index, time);
      const key = active ? `${active.entry.index}:${active.wordIndex}:${active.silence}` : "";
      if (key === previousKey) return;
      previousKey = key;
      previous?.classList.remove("is-playing", "is-silence-after");
      previous = undefined;
      if (!active) return;
      const occurrence =
        index.byWordId
          .get(active.word.id)
          ?.findIndex(
            (item) => item.entry === active.entry && item.wordIndex === active.wordIndex,
          ) ?? 0;
      const matches = elements.get(active.word.id);
      const el = matches?.[Math.max(0, occurrence)] ?? matches?.[0];
      if (!el) return;
      el.classList.add(active.silence ? "is-silence-after" : "is-playing");
      previous = el;
      if (Date.now() < manualUntil) return;
      const rect = el.getBoundingClientRect(),
        viewport = root.getBoundingClientRect();
      if (rect.bottom > viewport.bottom || rect.top < viewport.top)
        el.scrollIntoView({ behavior: "auto", block: "center" });
    };
    const rebuild = () => {
      elements = new Map();
      root.querySelectorAll<HTMLElement>("[data-word-id]").forEach((el) => {
        const id = el.dataset.wordId;
        if (id) {
          const matches = elements.get(id) ?? [];
          matches.push(el);
          elements.set(id, matches);
        }
      });
      previousKey = "unpainted";
      paint(
        usePlayerStore.getState().playing
          ? getPlaybackFrame()
          : usePlayerStore.getState().currentTime,
      );
    };
    rebuild();
    const observer = new MutationObserver(rebuild);
    observer.observe(root, { childList: true, subtree: true });
    root.addEventListener("wheel", onManualScroll, { passive: true });
    const stopFrames = subscribePlaybackFrame(paint);
    const stopStore = usePlayerStore.subscribe((state, before) => {
      if (!state.playing && state.currentTime !== before.currentTime) paint(state.currentTime);
    });
    return () => {
      observer.disconnect();
      stopFrames();
      stopStore();
      root.removeEventListener("wheel", onManualScroll);
      previous?.classList.remove("is-playing", "is-silence-after");
    };
  }, [project.segments, paragraphs, editor]);

  // Click on a paragraph timestamp → seek to start of that paragraph.
  const seekToParagraph = useCallback(
    (wordId: string) => {
      const mapped = wordIdToOutputTime(project, wordId);
      if (!mapped) return;
      window.dispatchEvent(
        new CustomEvent("yusafcut:seek-output", {
          detail: { time: mapped.outputTime, play: true },
        }),
      );
    },
    [project],
  );

  // ── Empty / loading states ────────────────────────────────────────────────

  // All words deleted after transcription
  if (project.segments.length > 0 && words.length === 0) {
    return (
      <div className="flex h-full items-center justify-center text-center text-muted-foreground">
        <div>
          <p className="text-sm font-medium">All words deleted</p>
          <p className="mt-1 text-xs opacity-60">Press {undoKey} to undo</p>
        </div>
      </div>
    );
  }

  return (
    <div ref={containerRef} className="flex h-full w-full flex-col" onClick={handleTranscriptClick}>
      <SelectionMenu rootRef={containerRef} />
      <div className="transcript-scroll relative flex-1">
        <div ref={editorRef} className="relative">
          {/* Floating speaker + timestamp column — one chip per paragraph. */}
          <div className="pointer-events-none absolute left-0 top-0 z-[1] hidden md:block">
            {paragraphs.map((para, idx) => {
              const top = paragraphTops[idx];
              if (top === undefined) return null;
              const speakerId = paragraphSpeakers[idx];
              const bucket = speakerBucket(speakerId);
              const name = speakerId ? speakerLabel(speakerId) : null;
              return (
                <button
                  key={`${para.startTime}-${idx}`}
                  type="button"
                  onClick={() => seekToParagraph(para.words[0]!.id)}
                  className="paragraph-speaker-chip pointer-events-auto"
                  style={{ top }}
                  data-speaker={bucket}
                  title={`Jump to ${name ?? "this paragraph"}`}
                >
                  {name && <span className="name">{name}</span>}
                  <span className="ts">{stamp(para.startTime)}</span>
                </button>
              );
            })}
          </div>

          <EditorContent editor={editor} />
        </div>
      </div>
    </div>
  );
}
