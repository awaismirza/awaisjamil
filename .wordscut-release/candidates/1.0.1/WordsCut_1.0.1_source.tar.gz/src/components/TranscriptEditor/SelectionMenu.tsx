import { useCallback, useEffect, useRef, useState, type RefObject } from "react";
import { createPortal } from "react-dom";
import {
  BookmarkPlus,
  Copy,
  Crop,
  Flag,
  Gauge,
  Minus,
  Play,
  Plus,
  Scissors,
  ZoomIn,
  ZoomOut,
} from "lucide-react";
import { wordIdToOutputTime, type Word } from "@/lib/edl";
import { pushUndoToast } from "@/lib/undoToast";
import { useEditorUiStore } from "@/stores/editorUiStore";
import { usePlayerStore } from "@/stores/playerStore";
import { useProjectStore } from "@/stores/projectStore";
import { useUIStore } from "@/stores/uiStore";
import { useSettingsStore } from "@/stores/settingsStore";
import { formatAccelerator } from "@/lib/shortcuts";
import { MIN_REGION_SEC } from "@/lib/zoom";

const MENU_GAP_PX = 10;
const MENU_HALF_WIDTH_PX = 190;
const TITLE_MAX_WORDS = 7;

interface Anchor {
  x: number;
  y: number;
  /** True when the menu sits below the selection instead of above it. */
  below: boolean;
}

interface Picked {
  ids: string[];
  words: Word[];
  /** Output-timeline start of the first word and end of the last. */
  start: number;
  end: number;
  text: string;
}

function anchorFor(rect: { top: number; bottom: number; left: number; width: number }): Anchor {
  const below = rect.top < 72;
  const x = Math.min(
    window.innerWidth - MENU_HALF_WIDTH_PX,
    Math.max(MENU_HALF_WIDTH_PX, rect.left + rect.width / 2),
  );
  return { x, y: below ? rect.bottom + MENU_GAP_PX : rect.top - MENU_GAP_PX, below };
}

/** Resolve the selected word ids into times and text on the current timeline. */
function pick(ids: ReadonlySet<string>): Picked | null {
  if (ids.size === 0) return null;
  const project = useProjectStore.getState().project;
  const flat = project.segments.flatMap((s) => s.words).filter((w) => ids.has(w.id));
  if (flat.length === 0) return null;
  const first = wordIdToOutputTime(project, flat[0]!.id);
  const last = wordIdToOutputTime(project, flat[flat.length - 1]!.id);
  if (!first || !last) return null;
  return {
    ids: flat.map((w) => w.id),
    words: flat,
    start: first.outputTime,
    end: last.outputTime + Math.max(0, last.word.end - last.word.start),
    text: flat.map((w) => w.text.trim()).join(" "),
  };
}

function titleFrom(text: string): string {
  const clipped = text
    .split(/\s+/)
    .slice(0, TITLE_MAX_WORDS)
    .join(" ")
    .replace(/[\s.,!?;:—–-]+$/g, "");
  return clipped.charAt(0).toUpperCase() + clipped.slice(1);
}

/**
 * Floating quick-action menu over the selected transcript text: play, cut,
 * keep only, mark, copy, and start a chapter. Rendered in a portal so clicks on
 * it never reach the transcript's click-to-seek handler.
 */
export function SelectionMenu({ rootRef }: { rootRef: RefObject<HTMLElement | null> }) {
  const selectedIds = usePlayerStore((s) => s.selectedWordIds);
  const zoomLevel = useEditorUiStore((s) => s.zoomLevel);
  const setZoomLevel = useEditorUiStore((s) => s.setZoomLevel);
  const [anchor, setAnchor] = useState<Anchor | null>(null);
  const [dragging, setDragging] = useState(false);
  const [chapter, setChapter] = useState<{ title: string; picked: Picked } | null>(null);
  const menuRef = useRef<HTMLDivElement | null>(null);

  const placeFromSelection = useCallback(() => {
    const sel = window.getSelection();
    const root = rootRef.current;
    if (!sel || sel.rangeCount === 0 || sel.isCollapsed || !root) {
      setAnchor(null);
      return;
    }
    const range = sel.getRangeAt(0);
    if (!root.contains(range.commonAncestorContainer)) {
      setAnchor(null);
      return;
    }
    setAnchor(anchorFor(range.getBoundingClientRect()));
  }, [rootRef]);

  // Track the drag so the menu appears on mouse-up, not while selecting.
  useEffect(() => {
    const root = rootRef.current;
    if (!root) return;
    const down = () => setDragging(true);
    const up = () => {
      setDragging(false);
      requestAnimationFrame(placeFromSelection);
    };
    root.addEventListener("mousedown", down);
    document.addEventListener("mouseup", up);
    return () => {
      root.removeEventListener("mousedown", down);
      document.removeEventListener("mouseup", up);
    };
  }, [rootRef, placeFromSelection]);

  // Keep the menu on the selection while the transcript scrolls or resizes, and
  // drop it when the selection goes away (unless the chapter title is being typed).
  useEffect(() => {
    if (chapter) return;
    const refresh = () => placeFromSelection();
    document.addEventListener("selectionchange", refresh);
    document.addEventListener("scroll", refresh, true);
    window.addEventListener("resize", refresh);
    return () => {
      document.removeEventListener("selectionchange", refresh);
      document.removeEventListener("scroll", refresh, true);
      window.removeEventListener("resize", refresh);
    };
  }, [chapter, placeFromSelection]);

  const close = useCallback(() => {
    setChapter(null);
    setAnchor(null);
    window.getSelection()?.removeAllRanges();
    usePlayerStore.getState().setSelectedWordIds([]);
  }, []);

  // Esc closes; a click outside the menu while typing a chapter title cancels it.
  useEffect(() => {
    if (!anchor && !chapter) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") close();
    };
    const onDown = (e: MouseEvent) => {
      if (chapter && menuRef.current && !menuRef.current.contains(e.target as Node)) close();
    };
    window.addEventListener("keydown", onKey);
    document.addEventListener("mousedown", onDown);
    return () => {
      window.removeEventListener("keydown", onKey);
      document.removeEventListener("mousedown", onDown);
    };
  }, [anchor, chapter, close]);

  const visible = (anchor && !dragging && selectedIds.size > 0) || chapter;
  if (!visible || !anchor) return null;

  const picked = chapter?.picked ?? pick(selectedIds);
  if (!picked) return null;
  const n = picked.ids.length;

  // Buttons use mousedown-preventDefault so clicking them keeps the selection.
  const keepSelection = (e: React.MouseEvent) => e.preventDefault();

  function play() {
    window.dispatchEvent(
      new CustomEvent("yusafcut:seek-output", { detail: { time: picked!.start, play: true } }),
    );
  }

  function cut() {
    const ids = picked!.ids;
    close();
    void useUIStore.getState().withProcessingEdit("Updating timeline…", () => {
      useProjectStore.getState().deleteWords(ids);
      pushUndoToast(`Cut ${ids.length} word${ids.length === 1 ? "" : "s"}`);
    });
  }

  function keepOnly() {
    const { start, end } = picked!;
    close();
    void useUIStore.getState().withProcessingEdit("Updating timeline…", () => {
      useProjectStore.getState().keepOutputRange(start, end);
      pushUndoToast("Kept only the selection", "Everything else was cut.");
    });
  }

  function mark() {
    usePlayerStore.getState().setTimelineRange(picked!.start, picked!.end);
    useUIStore.getState().pushToast({
      title: "Range marked",
      description: `Use Extract or Delete selection in Tools, or ${formatAccelerator(useSettingsStore.getState().editorShortcuts.deleteRange)}.`,
    });
  }

  async function copy() {
    try {
      await navigator.clipboard.writeText(picked!.text);
      useUIStore.getState().pushToast({ title: "Copied" });
    } catch {
      useUIStore.getState().pushToast({ title: "Could not copy", variant: "destructive" });
    }
  }

  function zoomIn() {
    const { start, end, ids } = picked!;
    // A single short word is shorter than the minimum region: stretch it forward.
    const regionEnd = Math.max(end, start + MIN_REGION_SEC * 2);
    const id = useProjectStore.getState().addZoomRegion({ start, end: regionEnd, scale: zoomLevel });
    if (id) {
      useEditorUiStore.getState().selectZoomRegion(id);
      pushUndoToast(
        `Zoomed in ${zoomLevel.toFixed(1)}×`,
        `On the ${ids.length} selected word${ids.length === 1 ? "" : "s"}. Drag it on the timeline to adjust.`,
      );
    } else {
      useUIStore.getState().pushToast({ title: "Selection is too short to zoom", variant: "destructive" });
    }
  }

  function zoomOut() {
    const before = useProjectStore.getState().project.zoomRegions?.length ?? 0;
    const { start, end } = picked!;
    useProjectStore.getState().clearZoomRange(start, end);
    const changed = (useProjectStore.getState().project.zoomRegions ?? []).length !== before;
    if (changed) pushUndoToast("Zoom removed here");
    else useUIStore.getState().pushToast({ title: "No zoom on this selection" });
  }

  /** Open the Timing panel on the clip holding the first selected word. */
  function timing() {
    const seg = useProjectStore
      .getState()
      .project.segments.find((s) => s.words.some((w) => w.id === picked!.ids[0]));
    if (seg) useEditorUiStore.getState().selectClip(seg.id);
    useEditorUiStore.getState().openPanel("timing");
    close();
  }

  function addChapter() {
    if (!chapter) return;
    const title = chapter.title.trim() || "Chapter";
    useProjectStore.getState().addChapter(chapter.picked.start, title);
    pushUndoToast(`Chapter added: ${title}`);
    close();
  }

  const style = {
    left: anchor.x,
    top: anchor.y,
    transform: anchor.below ? "translateX(-50%)" : "translate(-50%, -100%)",
  } as const;

  return createPortal(
    <div
      ref={menuRef}
      className="sel-menu"
      style={style}
      role="toolbar"
      aria-label="Selection actions"
    >
      {chapter ? (
        <form
          className="sel-chapter"
          onSubmit={(e) => {
            e.preventDefault();
            addChapter();
          }}
        >
          <BookmarkPlus className="h-4 w-4" />
          <input
            autoFocus
            className="sel-chapter-input"
            aria-label="Chapter title"
            value={chapter.title}
            onChange={(e) => setChapter({ ...chapter, title: e.target.value })}
          />
          <button type="submit" className="sel-btn is-primary">
            Add
          </button>
        </form>
      ) : (
        <>
          <span className="sel-count">{n} word{n === 1 ? "" : "s"}</span>
          <button type="button" className="sel-btn" onMouseDown={keepSelection} onClick={play}>
            <Play className="h-3.5 w-3.5" />
            Play
          </button>
          <button type="button" className="sel-btn is-cut" onMouseDown={keepSelection} onClick={cut}>
            <Scissors className="h-3.5 w-3.5" />
            Cut
          </button>
          <button type="button" className="sel-btn" onMouseDown={keepSelection} onClick={keepOnly}>
            <Crop className="h-3.5 w-3.5" />
            Keep only
          </button>
          <button type="button" className="sel-btn" onMouseDown={keepSelection} onClick={mark}>
            <Flag className="h-3.5 w-3.5" />
            Mark
          </button>
          <button
            type="button"
            className="sel-btn"
            onMouseDown={keepSelection}
            onClick={() => setChapter({ title: titleFrom(picked.text), picked })}
          >
            <BookmarkPlus className="h-3.5 w-3.5" />
            Start chapter
          </button>
          <span className="sel-sep" aria-hidden="true" />
          <span className="sel-zoom" role="group" aria-label="Zoom level">
            <button
              type="button"
              className="sel-step"
              aria-label="Less zoom"
              onMouseDown={keepSelection}
              onClick={() => setZoomLevel(Math.round((zoomLevel - 0.2) * 10) / 10)}
            >
              <Minus className="h-3 w-3" />
            </button>
            <output className="sel-zoom-level">{zoomLevel.toFixed(1)}×</output>
            <button
              type="button"
              className="sel-step"
              aria-label="More zoom"
              onMouseDown={keepSelection}
              onClick={() => setZoomLevel(Math.round((zoomLevel + 0.2) * 10) / 10)}
            >
              <Plus className="h-3 w-3" />
            </button>
          </span>
          <button type="button" className="sel-btn" onMouseDown={keepSelection} onClick={zoomIn}>
            <ZoomIn className="h-3.5 w-3.5" />
            Zoom in
          </button>
          <button type="button" className="sel-btn" onMouseDown={keepSelection} onClick={zoomOut}>
            <ZoomOut className="h-3.5 w-3.5" />
            Zoom out
          </button>
          <button type="button" className="sel-btn" onMouseDown={keepSelection} onClick={timing}>
            <Gauge className="h-3.5 w-3.5" />
            Timing
          </button>
          <span className="sel-sep" aria-hidden="true" />
          <button type="button" className="sel-btn" onMouseDown={keepSelection} onClick={() => void copy()}>
            <Copy className="h-3.5 w-3.5" />
            Copy
          </button>
        </>
      )}
    </div>,
    document.body,
  );
}
