/**
 * MusicTracksDialog — manage the audio tracks layered under the main EDL.
 *
 * The data model lives in `project.audioTracks`. Each track points at a
 * SourceMedia entry, gets a gain (dB) and offset, and optionally enables
 * sidechain ducking so the music drops under the speaker's voice during
 * export.
 *
 * UI strategy:
 *   * Plus button → file picker → `importMedia` → `addMediaOnly` →
 *     `addAudioTrack`. The track inherits the imported media's id.
 *   * Each row exposes mute / solo toggles, gain slider, offset, fade in/out,
 *     "Duck under voice" toggle and a remove button. Mute and solo silence the
 *     track in the mix (preview and export); they are not the timeline lane
 *     visibility toggles. Solo wins: while any track is soloed only soloed
 *     tracks are heard.
 *   * The editor preview plays these tracks (`MusicPreview`) with gain, offset,
 *     fades, mute and solo. Ducking is applied at export only.
 */

import {
  useCallback,
  useMemo,
  useRef,
  useState,
  type InputHTMLAttributes,
  type ReactNode,
} from "react";
import { open as openDialog } from "@tauri-apps/plugin-dialog";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Music, Plus, Trash2, Volume2, VolumeX } from "lucide-react";
import { importMedia } from "@/lib/ipc";
import { isVoiceOver, projectAudioTracks, type AudioTrack, type VoiceOverMode } from "@/lib/edl";
import { audibleTracks } from "@/lib/audioMix";
import { voiceOverOverflow } from "@/lib/voiceover";
import { OVERRIDE_NOTE } from "@/components/Recorder/VoiceOver";
import { useProjectStore } from "@/stores/projectStore";
import { useMusicPreviewStore } from "@/stores/musicPreviewStore";
import { useUIStore } from "@/stores/uiStore";

const MEDIA_EXTENSIONS = ["mp3", "m4a", "wav", "aac", "flac", "ogg", "mp4", "mov"];

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function MusicTracksDialog({ open, onOpenChange }: Props) {
  const project = useProjectStore((s) => s.project);
  const addAudioTrack = useProjectStore((s) => s.addAudioTrack);
  const removeAudioTrack = useProjectStore((s) => s.removeAudioTrack);
  const updateAudioTrack = useProjectStore((s) => s.updateAudioTrack);
  const addMediaOnly = useProjectStore((s) => s.addMediaOnly);
  const setVoiceOverMode = useProjectStore((s) => s.setVoiceOverMode);
  const pushToast = useUIStore((s) => s.pushToast);

  const tracks = useMemo(() => projectAudioTracks(project), [project]);
  const heard = useMemo(() => new Set(audibleTracks(tracks).map((t) => t.id)), [tracks]);
  const anySolo = tracks.some((t) => t.solo);
  const previewFailed = useMusicPreviewStore((s) => s.failed);

  const handleAdd = useCallback(async () => {
    const picked = await openDialog({
      multiple: false,
      filters: [{ name: "Audio", extensions: MEDIA_EXTENSIONS }],
    });
    if (typeof picked !== "string") return;
    try {
      const media = await importMedia(picked);
      addMediaOnly(media);
      addAudioTrack({
        mediaId: media.id,
        gainDb: -12,
        offsetSec: 0,
        ducks: true,
      });
      pushToast({
        title: "Music track added",
        description: media.path.split(/[\\/]/).pop() ?? media.path,
      });
    } catch (err) {
      pushToast({
        title: "Failed to add music track",
        description: String(err),
        variant: "destructive",
      });
    }
  }, [addAudioTrack, addMediaOnly, pushToast]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Music className="h-4 w-4 text-primary" />
            Music and voice-over tracks
          </DialogTitle>
          <DialogDescription>
            Layer music and sound effects under the main voice. The preview plays them with gain,
            offset, fades, mute and solo. Ducking pushes the music below the voice at export only;
            the preview does not duck. In the preview a boost above 0 dB is capped at 0 dB. Kept
            voice-over takes are listed here too; record them from the Music panel.
          </DialogDescription>
        </DialogHeader>

        <div className="flex flex-col gap-2">
          {tracks.length === 0 && (
            <div className="rounded-md border border-dashed border-border bg-secondary/40 px-3 py-6 text-center text-xs text-muted-foreground">
              No music tracks yet. Add a music bed and WordsCut will mix it under the spoken edit
              when you export.
            </div>
          )}
          {tracks.map((t) => (
            <TrackRow
              key={t.id}
              track={t}
              mediaPath={project.media[t.mediaId]?.path ?? "(missing media)"}
              heard={heard.has(t.id)}
              anySolo={anySolo}
              previewFailed={!!previewFailed[t.id]}
              onUpdate={(patch) => updateAudioTrack(t.id, patch)}
              onRemove={() => removeAudioTrack(t.id)}
              voice={
                isVoiceOver(t)
                  ? {
                      overflow: voiceOverOverflow(project, t),
                      mediaDuration: project.media[t.mediaId]?.duration ?? 0,
                      onMode: (mode) => setVoiceOverMode(t.id, mode),
                    }
                  : undefined
              }
            />
          ))}
        </div>

        <DialogFooter className="sm:justify-between">
          <Button variant="outline" onClick={handleAdd} className="gap-2">
            <Plus className="h-4 w-4" /> Add music track
          </Button>
          <Button onClick={() => onOpenChange(false)}>Done</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/**
 * A number/range input that edits a local draft and commits ONCE (slider
 * release, Enter or blur), so a drag or typing "1.5" is one undo step.
 */
function DraftInput({
  value,
  onCommit,
  children,
  ...rest
}: Omit<InputHTMLAttributes<HTMLInputElement>, "value" | "onChange" | "children"> & {
  value: number;
  onCommit: (v: number) => void;
  /** Renders beside the input with the value being shown (the draft while dragging). */
  children?: (shown: number) => ReactNode;
}) {
  const [draft, setDraft] = useState<string | null>(null);
  const latest = useRef<string | null>(null);
  const commit = () => {
    const raw = latest.current;
    latest.current = null;
    setDraft(null);
    if (raw === null || raw.trim() === "") return;
    const n = Number(raw);
    if (Number.isFinite(n) && n !== value) onCommit(n);
  };
  const shown = draft ?? String(value);
  return (
    <>
      <input
        {...rest}
        value={shown}
        onChange={(e) => {
          latest.current = e.target.value;
          setDraft(e.target.value);
        }}
        onPointerUp={rest.type === "range" ? commit : undefined}
        onKeyUp={(e) => {
          if (rest.type === "range" || e.key === "Enter") commit();
        }}
        onBlur={commit}
      />
      {children?.(Number(shown))}
    </>
  );
}

interface TrackRowProps {
  track: AudioTrack;
  mediaPath: string;
  /** False when mute or another track's solo silences this track. */
  heard: boolean;
  anySolo: boolean;
  /** The editor preview could not load or play this file (export is unaffected). */
  previewFailed: boolean;
  onUpdate: (patch: Partial<Omit<AudioTrack, "id" | "mediaId">>) => void;
  onRemove: () => void;
  /** Present for voice-over takes. */
  voice?: { overflow: number; mediaDuration: number; onMode: (mode: VoiceOverMode) => void };
}

function TrackRow({
  track,
  mediaPath,
  heard,
  anySolo,
  previewFailed,
  onUpdate,
  onRemove,
  voice,
}: TrackRowProps) {
  const base = mediaPath.split(/[\\/]/).pop() ?? mediaPath;
  const insert = track.mode === "insert";
  const filename = voice ? `Voice-over (${insert ? "Insert" : "Overlay"}) ${base}` : base;
  return (
    <div
      role="group"
      aria-label={`Track ${filename}`}
      className="rounded-md border border-border bg-secondary/30 px-3 py-2.5"
    >
      <div className="mb-2 flex items-center justify-between gap-2">
        <span
          className={`truncate text-sm font-medium ${heard ? "" : "opacity-60"}`}
          title={mediaPath}
        >
          {filename}
        </span>
        <span role="status" aria-live="polite" className="shrink-0 text-xs text-muted-foreground">
          {heard ? "" : track.muted && !anySolo ? "Muted" : "Silenced by solo"}
        </span>
        {previewFailed && (
          <span role="alert" className="shrink-0 text-xs text-red-400">
            Preview audio unavailable for {filename}
          </span>
        )}
        <div className="ml-auto flex shrink-0 items-center gap-1">
          <Button
            variant={track.muted ? "default" : "outline"}
            size="sm"
            className="h-7 gap-1 px-2 text-xs"
            aria-pressed={!!track.muted}
            aria-label={`Mute ${filename}`}
            title="Mute this track in the mix (preview and export). Does not hide any timeline lane."
            onClick={() => onUpdate({ muted: !track.muted })}
          >
            {track.muted ? (
              <VolumeX className="h-3.5 w-3.5" />
            ) : (
              <Volume2 className="h-3.5 w-3.5" />
            )}
            Mute
          </Button>
          <Button
            variant={track.solo ? "default" : "outline"}
            size="sm"
            className="h-7 px-2 text-xs"
            aria-pressed={!!track.solo}
            aria-label={`Solo ${filename}`}
            title="Hear only soloed tracks. Solo wins over mute."
            onClick={() => onUpdate({ solo: !track.solo })}
          >
            Solo
          </Button>
        </div>
        <Button
          variant="ghost"
          size="icon"
          className="h-7 w-7 shrink-0 text-muted-foreground hover:text-red-400"
          aria-label={`Remove ${filename}`}
          onClick={onRemove}
        >
          <Trash2 className="h-3.5 w-3.5" />
        </Button>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <label className="grid gap-1 text-xs">
          Gain
          <div className="flex items-center gap-2">
            <DraftInput
              type="range"
              min={-30}
              max={6}
              step={0.5}
              aria-label={`Gain ${filename}`}
              value={track.gainDb}
              onCommit={(gainDb) => onUpdate({ gainDb })}
              className="flex-1"
            >
              {(shown) => (
                <span className="w-12 text-right tabular-nums text-muted-foreground">
                  {shown.toFixed(1)} dB
                </span>
              )}
            </DraftInput>
          </div>
        </label>
        <label className="grid gap-1 text-xs">
          Offset (sec)
          <DraftInput
            type="number"
            step={0.1}
            min={-600}
            max={600}
            aria-label={`Offset ${filename}`}
            value={track.offsetSec}
            disabled={insert}
            title={
              insert
                ? "An inserted take sits on its held frame. Switch to Overlay to move it."
                : undefined
            }
            onCommit={(offsetSec) => onUpdate({ offsetSec })}
            className="h-8 rounded-md border border-input bg-background px-2 text-sm"
          />
        </label>
      </div>
      {voice && (
        <div className="mt-2 grid gap-2">
          <div className="grid grid-cols-2 gap-3">
            <label className="grid gap-1 text-xs">
              Trim start (sec)
              <DraftInput
                type="number"
                step={0.05}
                min={0}
                aria-label={`Trim start ${filename}`}
                value={track.sourceIn ?? 0}
                onCommit={(sourceIn) => onUpdate({ sourceIn })}
                className="h-8 rounded-md border border-input bg-background px-2 text-sm"
              />
            </label>
            <label className="grid gap-1 text-xs">
              Trim end (sec)
              <DraftInput
                type="number"
                step={0.05}
                min={0}
                aria-label={`Trim end ${filename}`}
                value={track.sourceOut ?? voice.mediaDuration}
                onCommit={(sourceOut) => onUpdate({ sourceOut })}
                className="h-8 rounded-md border border-input bg-background px-2 text-sm"
              />
            </label>
          </div>
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <Button
              variant="outline"
              size="sm"
              className="h-7 px-2 text-xs"
              onClick={() => voice.onMode(insert ? "overlay" : "insert")}
            >
              {insert ? "Switch to Overlay" : "Switch to Insert"}
            </Button>
            <label className="flex items-center gap-2" title={OVERRIDE_NOTE}>
              <input
                type="checkbox"
                checked={!!track.overrideOriginal}
                onChange={(e) =>
                  onUpdate({ overrideOriginal: e.target.checked ? true : undefined })
                }
              />
              Override the original audio while it plays
            </label>
          </div>
          {voice.overflow > 0 && (
            <p role="alert" className="text-xs text-amber-500">
              {voice.overflow.toFixed(1)} s runs past the end of the video and is not heard in the
              export. Switch to Insert, trim the take, or move it earlier.
            </p>
          )}
        </div>
      )}
      <div className="mt-2 grid grid-cols-2 gap-3">
        <label className="grid gap-1 text-xs">
          Fade in (sec)
          <DraftInput
            type="number"
            step={0.1}
            min={0}
            max={600}
            aria-label={`Fade in ${filename}`}
            value={track.fadeInSec ?? 0}
            onCommit={(fadeInSec) => onUpdate({ fadeInSec })}
            className="h-8 rounded-md border border-input bg-background px-2 text-sm"
          />
        </label>
        <label className="grid gap-1 text-xs">
          Fade out (sec)
          <DraftInput
            type="number"
            step={0.1}
            min={0}
            max={600}
            aria-label={`Fade out ${filename}`}
            value={track.fadeOutSec ?? 0}
            onCommit={(fadeOutSec) => onUpdate({ fadeOutSec })}
            className="h-8 rounded-md border border-input bg-background px-2 text-sm"
          />
        </label>
      </div>
      <label
        className={`mt-2 ${voice ? "hidden" : "flex"} cursor-pointer items-center gap-2 text-xs text-muted-foreground`}
        title="Applied at export only. The editor preview does not duck."
      >
        <input
          type="checkbox"
          checked={track.ducks}
          onChange={(e) => onUpdate({ ducks: e.target.checked })}
        />
        Duck under voice (sidechain compression, export only)
      </label>
    </div>
  );
}
