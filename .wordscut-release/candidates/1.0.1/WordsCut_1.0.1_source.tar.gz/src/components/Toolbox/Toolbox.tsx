import { useEditorShortcutLabel } from "@/hooks/useShortcutLabel";
import { projectChapters } from "@/lib/edl";
import { applyMarkedRange, clearMarkers, setMarkIn, setMarkOut } from "@/lib/rangeActions";
import { usePlayerStore } from "@/stores/playerStore";
import { useProjectStore } from "@/stores/projectStore";
import { useUIStore } from "@/stores/uiStore";
import { Bookmark, Flag, Scissors, Search, X, ZoomIn, ZoomOut, type LucideIcon } from "lucide-react";

interface ToolboxProps {
  onFindClick?: () => void;
}

export function Toolbox({ onFindClick }: ToolboxProps) {
  const inKey = useEditorShortcutLabel("markIn");
  const outKey = useEditorShortcutLabel("markOut");
  const extractKey = useEditorShortcutLabel("extractRange");
  const deleteKey = useEditorShortcutLabel("deleteRange");
  const project = useProjectStore((s) => s.project);
  const addChapter = useProjectStore((s) => s.addChapter);
  const pushToast = useUIStore((s) => s.pushToast);
  const chapterCount = projectChapters(project).length;
  const currentTime = usePlayerStore((s) => s.currentTime);
  const timelineMarkIn = usePlayerStore((s) => s.timelineMarkIn);
  const timelineMarkOut = usePlayerStore((s) => s.timelineMarkOut);
  const timelineZoom = usePlayerStore((s) => s.timelineZoom);
  const setTimelineZoom = usePlayerStore((s) => s.setTimelineZoom);

  const hasMarkers = timelineMarkIn !== null || timelineMarkOut !== null;
  const hasRange = timelineMarkIn !== null && timelineMarkOut !== null;

  function handleAddChapter() {
    const defaultTitle = `Chapter ${chapterCount + 1}`;
    const title = window.prompt("Chapter title", defaultTitle) ?? defaultTitle;
    if (title === null) return;
    addChapter(currentTime, title);
    pushToast({
      title: "Chapter added",
      description: `${title} at ${currentTime.toFixed(2)}s`,
    });
  }

  return (
    <div className="act-list" aria-label="Editing tools">
      <ActionRow
        icon={Search}
        title="Find in transcript"
        hint="Search, replace and choose fillers"
        onClick={onFindClick}
      />

      <p className="act-group-label">Selection</p>
      <div className="act-pair">
        <ActionRow icon={Flag} title="Set In" kbd={inKey} onClick={setMarkIn} compact />
        <ActionRow icon={Flag} title="Set Out" kbd={outKey} onClick={setMarkOut} compact />
      </div>
      <ActionRow
        icon={Scissors}
        title="Extract selection"
        kbd={extractKey}
        onClick={() => void applyMarkedRange("extract")}
        disabled={!hasRange}
      />
      <ActionRow
        icon={Scissors}
        title="Delete selection"
        kbd={deleteKey}
        onClick={() => void applyMarkedRange("delete")}
        disabled={!hasRange}
      />
      <ActionRow icon={X} title="Clear markers" onClick={clearMarkers} disabled={!hasMarkers} />

      <p className="act-group-label">Chapters</p>
      <ActionRow
        icon={Bookmark}
        title={chapterCount > 0 ? `Add chapter (${chapterCount})` : "Add chapter"}
        hint="At the playhead"
        onClick={handleAddChapter}
        disabled={project.segments.length === 0}
      />

      <p className="act-group-label">Timeline zoom</p>
      <div className="act-zoom">
        <button
          type="button"
          className="act-zoom-btn"
          title="Zoom out timeline"
          aria-label="Zoom out timeline"
          onClick={() => setTimelineZoom(timelineZoom / 1.5)}
          disabled={timelineZoom <= 1.01}
        >
          <ZoomOut className="h-4 w-4" />
        </button>
        <button
          type="button"
          className="act-zoom-value"
          title="Reset zoom"
          onClick={() => setTimelineZoom(1)}
        >
          {timelineZoom.toFixed(1)}×
        </button>
        <button
          type="button"
          className="act-zoom-btn"
          title="Zoom in timeline"
          aria-label="Zoom in timeline"
          onClick={() => setTimelineZoom(timelineZoom * 1.5)}
          disabled={timelineZoom >= 31.99}
        >
          <ZoomIn className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}

interface ActionRowProps {
  icon: LucideIcon;
  title: string;
  hint?: string;
  badge?: number;
  kbd?: string;
  tone?: "filler";
  compact?: boolean;
  disabled?: boolean;
  onClick?: () => void;
}

/** One full-width action: icon, title, optional hint, count badge or shortcut. */
function ActionRow({
  icon: Icon,
  title,
  hint,
  badge,
  kbd,
  tone,
  compact,
  disabled,
  onClick,
}: ActionRowProps) {
  return (
    <button
      type="button"
      className={`act-row${compact ? " is-compact" : ""}`}
      onClick={onClick}
      disabled={disabled}
    >
      <Icon className="act-row-icon h-4 w-4" />
      <span className="act-row-text">
        <span className="act-row-title">{title}</span>
        {hint && <span className="act-row-hint">{hint}</span>}
      </span>
      {badge !== undefined && (
        <span className={`act-row-badge${tone === "filler" ? " is-filler" : ""}`}>{badge}</span>
      )}
      {kbd && <span className="act-row-kbd">{kbd}</span>}
    </button>
  );
}
