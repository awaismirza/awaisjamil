import { useEffect, useState } from "react";
import { open as openDialog } from "@tauri-apps/plugin-dialog";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { relinkSource } from "@/lib/relink";
import { MEDIA_EXTENSIONS } from "@/lib/projectActions";
import { useProjectStore } from "@/stores/projectStore";
import { useRelinkStore } from "@/stores/relinkStore";
import { useUIStore } from "@/stores/uiStore";

const basename = (path: string) => path.split(/[\\/]/).pop() || path;

/**
 * Shown after a project opens with media files that are no longer where the
 * project says. "Locate…" lets the user pick the file; the backend refuses
 * anything that is not the same footage and the reason is shown on that row.
 * Cancelling the file picker or the dialog changes nothing.
 */
export function RelinkDialog() {
  const { projectId, missingIds, dismissed } = useRelinkStore();
  const media = useProjectStore((s) => s.project.media);
  const currentProject = useProjectStore((s) => s.project.id);
  const [busy, setBusy] = useState<string | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});

  // A different project: forget old errors and any list that belongs to another one.
  useEffect(() => {
    setErrors({});
    setBusy(null);
    if (useRelinkStore.getState().projectId !== currentProject) useRelinkStore.getState().clear();
  }, [currentProject]);

  const rows = missingIds.flatMap((id) => (media[id] ? [media[id]] : []));
  const open = projectId === currentProject && rows.length > 0 && !dismissed;

  async function locate(id: string) {
    const source = media[id];
    if (!source || busy) return;
    let picked: string | string[] | null;
    try {
      picked = await openDialog({
        multiple: false,
        directory: false,
        title: `Locate ${basename(source.path)}`,
        filters: [{ name: "Media", extensions: MEDIA_EXTENSIONS }],
      });
    } catch (error) {
      setErrors((e) => ({ ...e, [id]: String(error) }));
      return;
    }
    const path = Array.isArray(picked) ? picked[0] : picked;
    if (!path) return; // cancelled: nothing changes
    setBusy(id);
    setErrors((e) => ({ ...e, [id]: "" }));
    const outcome = await relinkSource(currentProject, source, path);
    // The user may have opened another project while the file was checked.
    if (useProjectStore.getState().project.id !== currentProject) return;
    setBusy(null);
    if (outcome.ok) {
      useUIStore.getState().pushToast({
        title: "Media relinked",
        description: basename(path),
      });
    } else {
      setErrors((e) => ({ ...e, [id]: outcome.message }));
    }
  }

  return (
    <Dialog open={open} onOpenChange={(next) => !next && useRelinkStore.getState().dismiss()}>
      <DialogContent className="max-w-xl">
        <DialogHeader>
          <DialogTitle>Some media is missing</DialogTitle>
          <DialogDescription>
            These files are not where the project saved them. Locate each one to keep editing,
            playing and exporting. Only the original file is accepted.
          </DialogDescription>
        </DialogHeader>
        <ul className="grid gap-3" aria-label="Missing media">
          {rows.map((m) => (
            <li key={m.id} className="grid gap-1 rounded-md border p-3">
              <div className="flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <div className="truncate text-sm font-medium">{basename(m.path)}</div>
                  <div className="truncate text-xs text-muted-foreground" title={m.path}>
                    {m.path}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {m.duration.toFixed(1)} s
                    {m.width > 0 ? ` · ${m.width}×${m.height}` : " · audio only"}
                  </div>
                </div>
                <Button
                  type="button"
                  size="sm"
                  disabled={busy !== null}
                  onClick={() => void locate(m.id)}
                  aria-label={`Locate ${basename(m.path)}`}
                >
                  {busy === m.id ? "Checking…" : "Locate…"}
                </Button>
              </div>
              {errors[m.id] ? (
                <p role="alert" className="text-xs text-destructive">
                  {errors[m.id]}
                </p>
              ) : null}
            </li>
          ))}
        </ul>
        <DialogFooter>
          <Button
            type="button"
            variant="outline"
            disabled={busy !== null}
            onClick={() => useRelinkStore.getState().dismiss()}
          >
            Skip for now
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
