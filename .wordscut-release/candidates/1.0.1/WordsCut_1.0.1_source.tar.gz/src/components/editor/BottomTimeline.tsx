import { Waveform } from "@/components/Waveform/Waveform";

/** Bottom timeline: a ruler, the clip bar and the zoom lane. Nothing else. */
export function BottomTimeline() {
  return (
    <div className="bottom-timeline">
      <Waveform />
    </div>
  );
}
