import { useState } from "react";
import { AudioLines, FolderOpen, History, ShieldCheck, Upload, Video } from "lucide-react";
import { Button } from "@/components/ui/button";
import { getRecentProjects } from "@/lib/recentProjects";
import { useRecordingStore } from "@/stores/recordingStore";

function dispatch(name: string, detail?: unknown) {
  window.dispatchEvent(new CustomEvent(name, detail === undefined ? undefined : { detail }));
}

const STEPS = [
  {
    title: "Import",
    body: "Drop in a video or audio recording. Nothing is uploaded.",
  },
  {
    title: "Transcribe on this Mac",
    body: "Whisper runs locally with Core ML and Metal, word by word.",
  },
  {
    title: "Edit the words",
    body: "Delete a word, a filler or a pause and that exact moment is cut from the video.",
  },
] as const;

/**
 * Shown while no media is loaded. Drops are handled app-wide (see App.tsx), so
 * the drop zone only needs to explain itself and offer the same actions as the
 * Project menu.
 */
export function StartScreen() {
  const openRecorder = useRecordingStore((s) => s.openDialog);
  const [recents] = useState<string[]>(() => getRecentProjects());

  return (
    <div className="start-screen">
      <div className="start-inner">
        <div className="start-main">
          <span className="start-privacy">
            <ShieldCheck className="h-3.5 w-3.5" />
            100% on-device. No upload, no account.
          </span>
          <h1 className="start-title">
            Edit the words.
            <br />
            The video follows.
          </h1>
          <p className="start-lede">
            Drop in a recording. WordsCut transcribes it on your Mac, then every word you delete is
            cut from the video, frame accurate.
          </p>

          <div className="start-drop">
            <div className="start-drop-icon">
              <Upload className="h-6 w-6" />
            </div>
            <p className="start-drop-title">Drop a video or audio file anywhere in this window</p>
            <p className="start-drop-sub">MP4, MOV, M4A, WAV</p>
            <div className="start-drop-actions">
              <Button className="gap-2" onClick={() => dispatch("yusafcut:open")}>
                <Video className="h-4 w-4" />
                Choose file
              </Button>
              <Button variant="outline" className="gap-2" onClick={openRecorder}>
                <AudioLines className="h-4 w-4" />
                Record
              </Button>
              <Button
                variant="ghost"
                className="gap-2"
                onClick={() => dispatch("yusafcut:open-project")}
              >
                <FolderOpen className="h-4 w-4" />
                Open project
              </Button>
            </div>
          </div>
        </div>

        <aside className="start-side">
          <section className="start-card">
            <h2 className="start-card-title">How it works</h2>
            <ol className="start-steps">
              {STEPS.map((s, i) => (
                <li key={s.title}>
                  <span className="start-step-num">{i + 1}</span>
                  <span className="start-step-text">
                    <span className="start-step-title">{s.title}</span>
                    <span className="start-step-body">{s.body}</span>
                  </span>
                </li>
              ))}
            </ol>
          </section>

          {recents.length > 0 && (
            <section className="start-card">
              <h2 className="start-card-title">Recent projects</h2>
              <ul className="start-recents">
                {recents.map((path) => (
                  <li key={path}>
                    <button
                      type="button"
                      className="start-recent"
                      title={path}
                      onClick={() => dispatch("yusafcut:open-project-path", { path })}
                    >
                      <History className="h-4 w-4" />
                      <span className="truncate">{path.split(/[\\/]/).pop()}</span>
                    </button>
                  </li>
                ))}
              </ul>
            </section>
          )}
        </aside>
      </div>
    </div>
  );
}
