import { useEffect, useMemo, useRef, useState } from "react";
import { CaptionBox, CaptionFrame } from "@/components/VideoPreview/CaptionOverlay";
import { layoutProjectCaptions } from "@/lib/captionLayout";
import {
  CAPTION_FONTS,
  CAPTION_POSITIONS,
  DEFAULT_CAPTION_STYLE,
  sanitizeCaptionStyle,
  type CaptionStyle,
} from "@/lib/captionStyle";
import { useProjectStore } from "@/stores/projectStore";

export function Slider({
  label,
  value,
  min,
  max,
  step,
  suffix,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  suffix?: string;
  onChange: (v: number) => void;
}) {
  // A drag edits a local draft and commits once on release, so it is ONE undo step
  // (and the project is not re-laid-out on every tick).
  const [draft, setDraft] = useState<number | null>(null);
  const latest = useRef<number | null>(null);
  const commit = () => {
    if (latest.current !== null) onChange(latest.current);
    latest.current = null;
    setDraft(null);
  };
  const shown = draft ?? value;
  return (
    <label className="cl-slider">
      <span className="cl-slider-row">
        <span>{label}</span>
        <output className="cl-slider-value" aria-live="off">
          {shown}
          {suffix ?? ""}
        </output>
      </span>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={shown}
        onChange={(e) => {
          latest.current = Number(e.target.value);
          setDraft(latest.current);
        }}
        onPointerUp={commit}
        onKeyUp={commit}
        onBlur={commit}
      />
    </label>
  );
}

export function ColorField({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
}) {
  // The native `change` event fires once, when the picker closes: one undo step per choice.
  const ref = useRef<HTMLInputElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const onDone = () => onChange(el.value);
    el.addEventListener("change", onDone);
    return () => el.removeEventListener("change", onDone);
  }, [onChange]);
  return (
    <label className="inspector-row">
      <span className="inspector-row-label">{label}</span>
      <input key={value} ref={ref} type="color" defaultValue={value} />
    </label>
  );
}

export function CaptionsPanel() {
  const project = useProjectStore((s) => s.project);
  const setCaptionStyle = useProjectStore((s) => s.setCaptionStyle);
  const style = useMemo(() => sanitizeCaptionStyle(project.captions), [project.captions]);
  const set = (patch: Partial<CaptionStyle>) => setCaptionStyle(patch);
  const hasWords = project.segments.some((s) => s.words.length > 0);

  const layout = useMemo(() => layoutProjectCaptions(project, style), [project, style]);
  // The preview sample: the first cue that has more than one word, else the first cue.
  const sample = layout.cues.find((c) => c.lines.flat().length > 1) ?? layout.cues[0];
  const media = Object.values(project.media)[0];
  const aspect = media ? media.width / Math.max(1, media.height) : 16 / 9;

  if (!hasWords) {
    return (
      <div className="inspector-panel-content">
        <div className="inspector-section">
          <p className="inspector-section-label">Captions</p>
          <p className="inspector-hint">
            Transcribe a video first. Then style the captions here and turn on "Burn in captions" in
            the Export dialog.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="inspector-panel-content cl-panel">
      <section className="cl-section" aria-label="Caption preview">
        <div className="cl-head">
          <h3 className="cl-title">Preview</h3>
        </div>
        <div
          className="relative w-full overflow-hidden rounded bg-zinc-800"
          style={{ aspectRatio: `${aspect}`, containerType: "size" }}
        >
          {sample && (
            <CaptionFrame aspect={aspect} position={style.position}>
              <CaptionBox cue={sample} style={style} active={{ line: 0, word: 0 }} />
            </CaptionFrame>
          )}
        </div>
        <p className="inspector-hint">
          Captions also show in the main preview. Burn them into the video with "Burn in captions"
          in the Export dialog; SRT and VTT export are unchanged.
        </p>
      </section>

      <section className="cl-section" aria-label="Text">
        <div className="cl-head">
          <h3 className="cl-title">Text</h3>
        </div>
        <label className="inspector-row">
          <span className="inspector-row-label">Font</span>
          <select
            value={style.font}
            onChange={(e) => set({ font: e.target.value as CaptionStyle["font"] })}
          >
            {CAPTION_FONTS.map((f) => (
              <option key={f} value={f}>
                {f}
              </option>
            ))}
          </select>
        </label>
        <Slider
          label="Size"
          value={style.size}
          min={16}
          max={140}
          step={1}
          onChange={(size) => set({ size })}
        />
        <label className="inspector-row">
          <span className="inspector-row-label">Weight</span>
          <select
            value={style.weight}
            onChange={(e) => set({ weight: e.target.value as CaptionStyle["weight"] })}
          >
            <option value="regular">Regular</option>
            <option value="bold">Bold</option>
          </select>
        </label>
        <ColorField label="Color" value={style.color} onChange={(color) => set({ color })} />
        <label className="st-toggle">
          <input
            type="checkbox"
            checked={style.highlight}
            onChange={(e) => set({ highlight: e.target.checked })}
          />
          <span className="st-row-text">
            <span className="st-row-title">Highlight the spoken word</span>
            <span className="st-row-hint">Colors the word being said, in preview and export.</span>
          </span>
        </label>
        {style.highlight && (
          <ColorField
            label="Highlight color"
            value={style.highlightColor}
            onChange={(highlightColor) => set({ highlightColor })}
          />
        )}
      </section>

      <section className="cl-section" aria-label="Background">
        <div className="cl-head">
          <h3 className="cl-title">Background</h3>
        </div>
        <label className="st-toggle">
          <input
            type="checkbox"
            checked={style.box}
            onChange={(e) => set({ box: e.target.checked })}
          />
          <span className="st-row-text">
            <span className="st-row-title">Box behind the text</span>
            <span className="st-row-hint">Replaces the outline.</span>
          </span>
        </label>
        {style.box ? (
          <>
            <ColorField
              label="Box color"
              value={style.boxColor}
              onChange={(boxColor) => set({ boxColor })}
            />
            <Slider
              label="Box opacity"
              value={Math.round(style.boxOpacity * 100)}
              min={0}
              max={100}
              step={5}
              suffix="%"
              onChange={(v) => set({ boxOpacity: v / 100 })}
            />
          </>
        ) : (
          <>
            <Slider
              label="Outline"
              value={style.outline}
              min={0}
              max={12}
              step={1}
              onChange={(outline) => set({ outline })}
            />
            <ColorField
              label="Outline color"
              value={style.outlineColor}
              onChange={(outlineColor) => set({ outlineColor })}
            />
            <Slider
              label="Shadow"
              value={style.shadow}
              min={0}
              max={12}
              step={1}
              onChange={(shadow) => set({ shadow })}
            />
          </>
        )}
      </section>

      <section className="cl-section" aria-label="Layout">
        <div className="cl-head">
          <h3 className="cl-title">Layout</h3>
        </div>
        <div className="st-segment" role="radiogroup" aria-label="Position">
          {CAPTION_POSITIONS.map((p, i) => (
            <button
              key={p}
              type="button"
              role="radio"
              aria-checked={style.position === p}
              tabIndex={style.position === p ? 0 : -1}
              onKeyDown={(e) => {
                const step =
                  e.key === "ArrowRight" || e.key === "ArrowDown"
                    ? 1
                    : e.key === "ArrowLeft" || e.key === "ArrowUp"
                      ? -1
                      : 0;
                if (!step) return;
                e.preventDefault();
                const next =
                  CAPTION_POSITIONS[
                    (i + step + CAPTION_POSITIONS.length) % CAPTION_POSITIONS.length
                  ]!;
                set({ position: next });
                (
                  e.currentTarget.parentElement?.querySelector(
                    `[data-pos="${next}"]`,
                  ) as HTMLElement | null
                )?.focus();
              }}
              data-pos={p}
              className={`st-segment-btn${style.position === p ? " is-on" : ""}`}
              onClick={() => set({ position: p })}
            >
              {p[0]!.toUpperCase() + p.slice(1)}
            </button>
          ))}
        </div>
        <Slider
          label="Characters per line"
          value={style.maxCharsPerLine}
          min={10}
          max={60}
          step={1}
          onChange={(maxCharsPerLine) => set({ maxCharsPerLine })}
        />
        <label className="inspector-row">
          <span className="inspector-row-label">Lines</span>
          <select
            value={style.maxLines}
            onChange={(e) => set({ maxLines: Number(e.target.value) })}
          >
            {[1, 2, 3].map((n) => (
              <option key={n} value={n}>
                {n}
              </option>
            ))}
          </select>
        </label>
        <button
          type="button"
          className="st-segment-btn"
          onClick={() => setCaptionStyle(DEFAULT_CAPTION_STYLE)}
        >
          Reset style
        </button>
      </section>

      <section className="cl-section" aria-label="Reading checks">
        <div className="cl-head">
          <h3 className="cl-title">Reading checks</h3>
        </div>
        {layout.warnings.length === 0 ? (
          <p className="inspector-hint">
            {layout.cues.length} cues, no reading-speed or length problems.
          </p>
        ) : (
          <>
            <p className="inspector-hint">
              {layout.cues.length} cues, {layout.warnings.length} to check. Times come from the
              words and are never changed; trim or re-wrap to fix.
            </p>
            <ul className="inspector-hint">
              {layout.warnings.slice(0, 8).map((w, i) => (
                <li key={i}>{w.message}</li>
              ))}
              {layout.warnings.length > 8 && <li>+{layout.warnings.length - 8} more</li>}
            </ul>
          </>
        )}
      </section>
    </div>
  );
}
