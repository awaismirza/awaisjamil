import { useMemo, useState } from "react";
import { Play, Trash2 } from "lucide-react";
import { generateAutoZoom } from "@/lib/autoZoom";
import { parseCursorLog } from "@/lib/cursor";
import { CLICK_EFFECTS, CURSOR_SHAPES, sanitizeProjectCursor } from "@/lib/cursorStyle";
import { computeTimeline, type Project } from "@/lib/edl";
import { getTimelineIndex } from "@/lib/timelineIndex";
import { useEditorUiStore } from "@/stores/editorUiStore";
import { usePlayerStore } from "@/stores/playerStore";
import { formatTimecode } from "@/lib/timecode";
import { pushUndoToast } from "@/lib/undoToast";
import type { ZoomRegion } from "@/lib/zoom";
import { useProjectStore } from "@/stores/projectStore";
import { useUIStore } from "@/stores/uiStore";

interface Review {
  project: Project;
  regions: ZoomRegion[];
  excluded: string[];
}
function Toggle({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <label className="st-toggle">
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} />
      <span>{label}</span>
    </label>
  );
}
export function ZoomPanel() {
  const project = useProjectStore((s) => s.project);
  const cursor = useMemo(() => sanitizeProjectCursor(project.cursor), [project.cursor]);
  const setAutoZoom = useProjectStore((s) => s.setAutoZoom);
  const setStyle = useProjectStore((s) => s.setCursorStyle);
  const setTrack = useProjectStore((s) => s.setCursorTrack);
  const apply = useProjectStore((s) => s.applyZoomSuggestions);
  const processing = useUIStore((s) => s.isProcessingEdit);
  const withProcessing = useUIStore((s) => s.withProcessingEdit);
  const toast = useUIStore((s) => s.pushToast);
  const [review, setReview] = useState<Review | null>(null);
  const [selectedMedia, setSelectedMedia] = useState("");
  const media = Object.values(project.media).filter((m) => m.width > 0 && m.height > 0);
  const mediaId = media.some((m) => m.id === selectedMedia) ? selectedMedia : media[0]?.id;
  // The clip being worked on: the one selected on the timeline, else the one under the playhead.
  const selectedClipId = useEditorUiStore((s) => s.selectedClipId);
  const activeMediaId = usePlayerStore((s) => {
    const entries = getTimelineIndex(project.segments).entries;
    const picked =
      entries.find((e) => e.segmentId === selectedClipId) ??
      entries.find((e) => s.currentTime >= e.outputStart && s.currentTime < e.outputEnd) ??
      entries[0];
    return picked?.mediaId;
  });
  const hasTracks = computeTimeline(project).some((e) => !!cursor.tracks[e.mediaId]?.points.length);
  // Cursor tools only make sense for footage recorded with cursor data; hide them for other clips.
  const activeHasCursor = !!activeMediaId && !!cursor.tracks[activeMediaId]?.points.length;
  // Any edit or preference change invalidates proposals, rather than applying stale output times.
  const activeReview = review?.project === project ? review : null;
  const chosen = activeReview?.regions.filter((r) => !activeReview.excluded.includes(r.id)) ?? [];
  const { autoZoom: auto, style } = cursor;

  async function generate() {
    await withProcessing("Finding cursor activity…", async () => {
      await new Promise<void>((resolve) => requestAnimationFrame(() => resolve()));
      const regions = generateAutoZoom(cursor.tracks, computeTimeline(project), auto);
      if (useProjectStore.getState().project === project)
        setReview({ project, regions, excluded: [] });
    });
  }
  async function loadLog(file: { text(): Promise<string> } | undefined) {
    if (!file || !mediaId) return;
    try {
      const text = await file.text();
      await withProcessing("Reading cursor log…", async () => {
        await new Promise<void>((resolve) => requestAnimationFrame(() => resolve()));
        if (useProjectStore.getState().project !== project) return;
        const track = parseCursorLog(text);
        if (!track.points.length) throw new Error("No usable cursor positions in this log.");
        setTrack(mediaId, track);
        pushUndoToast("Loaded cursor data");
      });
    } catch (e) {
      toast({
        title: "Could not load cursor data",
        description: String(e),
        variant: "destructive",
      });
    }
  }
  async function loadDemo() {
    if (!mediaId) return;
    try {
      const { syntheticCursorLog } = await import("../../../../../tests/fixtures/cursorLogs");
      if (useProjectStore.getState().project === project) {
        setTrack(mediaId, parseCursorLog(syntheticCursorLog("typing")));
        pushUndoToast("Loaded synthetic cursor demo");
      }
    } catch (e) {
      toast({
        title: "Could not load the cursor demo",
        description: String(e),
        variant: "destructive",
      });
    }
  }
  function add(replace: boolean) {
    if (!activeReview) return;
    apply(chosen, replace);
    setReview(null);
    pushUndoToast(`${replace ? "Replaced zoom with" : "Added"} ${chosen.length} regions`);
  }
  return (
    <div className="inspector-panel-content cl-panel zoom-panel">
      <section className="cl-section" aria-label="Auto zoom">
        <h3 className="cl-title">Auto zoom</h3>
        <p className="inspector-hint">
          Suggest zooms around clicks and typing. Review them before adding, then drag their edges
          on the timeline.
        </p>
        <Toggle
          label="Auto zoom"
          checked={auto.enabled}
          onChange={(enabled) => setAutoZoom({ enabled })}
        />
        <label className="cl-slider">
          Scale · {auto.scale.toFixed(1)}×
          <input
            type="range"
            min="1.2"
            max="4"
            step="0.1"
            value={auto.scale}
            onChange={(e) => setAutoZoom({ scale: +e.target.value })}
          />
        </label>
        <label className="zoom-field">
          Sensitivity
          <select
            value={auto.sensitivity}
            onChange={(e) =>
              setAutoZoom({ sensitivity: e.target.value as typeof auto.sensitivity })
            }
          >
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
          </select>
        </label>
        {activeHasCursor ? (
          <>
            <Toggle
              label="Clicks"
              checked={auto.clicks}
              onChange={(clicks) => setAutoZoom({ clicks })}
            />
            <Toggle
              label="Typing"
              checked={auto.typing}
              onChange={(typing) => setAutoZoom({ typing })}
            />
            <Toggle
              label="Follow cursor"
              checked={auto.follow}
              onChange={(follow) => setAutoZoom({ follow })}
            />
            {!hasTracks && (
              <p className="inspector-hint">
                Recorded without cursor data. New recordings made with the native recorder include
                it.
              </p>
            )}
            <button
              className="cl-primary"
              disabled={!hasTracks || !auto.enabled || processing}
              onClick={() => void generate()}
            >
              Generate from cursor
            </button>
          </>
        ) : (
          <p className="inspector-hint">
            This clip has no cursor data, so cursor-based zoom is off. Only clips recorded with
            WordsCut's recorder include it. Double-click the zoom lane on the timeline to add a zoom
            by hand.
          </p>
        )}
        {activeReview && (
          <>
            <p className="inspector-hint">
              {activeReview.regions.length
                ? "Keep the suggestions you want."
                : "No activity matched these settings."}
            </p>
            <ul className="ch-list" aria-label="Suggested zoom regions">
              {activeReview.regions.map((r) => (
                <li className="ch-item" key={r.id}>
                  <input
                    type="checkbox"
                    aria-label={`Keep zoom at ${r.start.toFixed(1)}`}
                    checked={!activeReview.excluded.includes(r.id)}
                    onChange={(e) =>
                      setReview({
                        ...activeReview,
                        excluded: e.target.checked
                          ? activeReview.excluded.filter((id) => id !== r.id)
                          : [...activeReview.excluded, r.id],
                      })
                    }
                  />
                  <button
                    type="button"
                    className="ch-time"
                    aria-label={`Play zoom at ${r.start.toFixed(1)}`}
                    onClick={() =>
                      window.dispatchEvent(
                        new CustomEvent("yusafcut:seek-output", {
                          detail: { time: r.start, play: true },
                        }),
                      )
                    }
                  >
                    <Play size={12} />
                    {formatTimecode(r.start, { ms: false })}
                  </button>
                  <span>
                    {(r.end - r.start).toFixed(1)} s · {r.scale.toFixed(1)}×
                  </span>
                  <button
                    type="button"
                    className="fr-icon-btn"
                    aria-label={`Remove suggestion at ${r.start.toFixed(1)}`}
                    onClick={() =>
                      setReview({
                        ...activeReview,
                        regions: activeReview.regions.filter((q) => q.id !== r.id),
                      })
                    }
                  >
                    <Trash2 size={14} />
                  </button>
                </li>
              ))}
            </ul>
            <button className="cl-primary" disabled={!chosen.length} onClick={() => add(false)}>
              Add {chosen.length} zoom regions
            </button>
            <button className="cl-secondary" disabled={!chosen.length} onClick={() => add(true)}>
              Replace existing zoom regions
            </button>
            <button className="cl-more" onClick={() => setReview(null)}>
              Discard suggestions
            </button>
          </>
        )}
      </section>
      {activeHasCursor && (
        <section className="cl-section" aria-label="Cursor styling">
          <h3 className="cl-title">Cursor</h3>
          <p className="inspector-hint">
            Cursor styling is included in video exports. A cursor already burned into the source
            cannot be removed.
          </p>
          <Toggle
            label="Show cursor"
            checked={style.show}
            onChange={(show) => setStyle({ show })}
          />
          <label className="zoom-field">
            Style
            <select
              value={style.shape}
              onChange={(e) => setStyle({ shape: e.target.value as typeof style.shape })}
            >
              {CURSOR_SHAPES.map((s) => (
                <option key={s} value={s}>
                  {s === "macos" ? "macOS arrow" : s}
                </option>
              ))}
            </select>
          </label>
          <label className="cl-slider">
            Size · {style.size} px
            <input
              type="range"
              min="12"
              max="96"
              value={style.size}
              onChange={(e) => setStyle({ size: +e.target.value })}
            />
          </label>
          <label className="zoom-field">
            Colour
            <input
              type="color"
              value={style.color}
              onChange={(e) => setStyle({ color: e.target.value })}
            />
          </label>
          <label className="cl-slider">
            Smoothing · {Math.round(style.smoothing * 1000)} ms
            <input
              type="range"
              min="0"
              max="0.5"
              step="0.01"
              value={style.smoothing}
              onChange={(e) => setStyle({ smoothing: +e.target.value })}
            />
          </label>
          <label className="zoom-field">
            Click effect
            <select
              value={style.clickEffect}
              onChange={(e) =>
                setStyle({ clickEffect: e.target.value as typeof style.clickEffect })
              }
            >
              {CLICK_EFFECTS.map((s) => (
                <option value={s} key={s}>
                  {s}
                </option>
              ))}
            </select>
          </label>
          <Toggle
            label="Hide when idle"
            checked={style.hideWhenIdle}
            onChange={(hideWhenIdle) => setStyle({ hideWhenIdle })}
          />
          <Toggle
            label="Motion blur"
            checked={style.motionBlur}
            onChange={(motionBlur) => setStyle({ motionBlur })}
          />
        </section>
      )}
      <section className="cl-section" aria-label="Cursor data">
        <h3 className="cl-title">Cursor data</h3>
        <p className="inspector-hint">
          Load an events.jsonl log for a video. Data stays in this project, on this Mac.
        </p>
        <label className="zoom-field">
          Video
          <select
            value={mediaId ?? ""}
            disabled={!media.length}
            onChange={(e) => setSelectedMedia(e.target.value)}
          >
            {media.map((m) => (
              <option key={m.id} value={m.id}>
                {m.path.split(/[\\/]/).at(-1)}
              </option>
            ))}
          </select>
        </label>
        <label className="zoom-field">
          Load cursor log
          <input
            type="file"
            accept=".jsonl,.json"
            disabled={!mediaId || processing}
            onChange={(e) => {
              void loadLog(e.target.files?.[0]);
              e.target.value = "";
            }}
          />
        </label>
        {import.meta.env.DEV && (
          <button className="cl-secondary" disabled={!mediaId} onClick={() => void loadDemo()}>
            Load synthetic cursor demo (development)
          </button>
        )}
        {mediaId && (
          <p className="inspector-hint">
            {cursor.tracks[mediaId]?.points.length ?? 0} cursor positions for this video.
          </p>
        )}
      </section>
    </div>
  );
}
