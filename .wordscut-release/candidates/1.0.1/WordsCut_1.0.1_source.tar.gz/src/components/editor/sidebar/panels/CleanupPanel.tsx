import { useMemo, useState } from "react";
import { AudioLines, Check, ChevronDown, Eraser, Play, Scissors, Wand2 } from "lucide-react";
import { DETECT_PAUSE_MIN_SEC, useCleanupActions } from "@/hooks/useCleanupActions";
import { wordIdToOutputTime, type Word } from "@/lib/edl";
import {
  findFillersInSegments,
  normaliseFillerToken,
  OPT_IN_FILLERS,
  SAFE_FILLERS,
} from "@/lib/fillers";
import { formatTimecode } from "@/lib/timecode";
import { pushUndoToast } from "@/lib/undoToast";
import { useFillerStore } from "@/stores/fillerStore";
import { useProjectStore } from "@/stores/projectStore";
import { useUIStore } from "@/stores/uiStore";

/** Seconds of audio shown before a cut when jumping to it from the list. */
const LEAD_IN_SEC = 1;
/** Pauses are shortened to this length by "Shorten". */
const SHORTEN_TO_SEC = 0.3;

interface ReviewRow {
  key: string;
  wordIds: string[];
  phrase: string;
  before: string;
  hit: string;
  after: string;
  outputTime: number | null;
  seconds: number;
}

function seek(time: number) {
  window.dispatchEvent(
    new CustomEvent("yusafcut:seek-output", {
      detail: { time: Math.max(0, time - LEAD_IN_SEC), play: true },
    }),
  );
}

function FillerChip({
  phrase,
  count,
  on,
  onToggle,
}: {
  phrase: string;
  count: number;
  on: boolean;
  onToggle: () => void;
}) {
  return (
    <button
      type="button"
      className={`cl-chip${on ? " is-on" : ""}`}
      aria-pressed={on}
      onClick={onToggle}
      title={on ? `Stop treating "${phrase}" as a filler` : `Treat "${phrase}" as a filler`}
    >
      {on && <Check className="h-3 w-3" />}
      <span>{phrase}</span>
      <span className="cl-chip-count">{count}</span>
    </button>
  );
}

export function CleanupPanel() {
  const project = useProjectStore((s) => s.project);
  const pauseTokens = useProjectStore((s) => s.pauseTokens);
  const deleteWords = useProjectStore((s) => s.deleteWords);
  const withProcessingEdit = useUIStore((s) => s.withProcessingEdit);
  const selected = useFillerStore((s) => s.selected);
  const toggleFiller = useFillerStore((s) => s.toggle);
  const actions = useCleanupActions();

  const [ignored, setIgnored] = useState<ReadonlySet<string>>(new Set());
  const [showMore, setShowMore] = useState(false);
  const [threshold, setThreshold] = useState(1);

  const hasWords = project.segments.some((s) => s.words.length > 0);

  // ── Fillers ────────────────────────────────────────────────────────────
  const counts = useMemo(() => {
    const all = findFillersInSegments(project.segments, [...SAFE_FILLERS, ...OPT_IN_FILLERS]);
    const map = new Map<string, number>();
    for (const m of all) map.set(m.phrase, (map.get(m.phrase) ?? 0) + 1);
    return map;
  }, [project.segments]);

  const rows = useMemo<ReviewRow[]>(() => {
    const flat: Word[] = project.segments.flatMap((s) => s.words);
    const index = new Map(flat.map((w, i) => [w.id, i]));
    const byId = new Map(flat.map((w) => [w.id, w]));
    return findFillersInSegments(project.segments, selected).map((m) => {
      const first = index.get(m.wordIds[0]!) ?? 0;
      const text = (ws: Word[]) => ws.map((w) => w.text.trim()).join(" ");
      const words = m.wordIds.map((id) => byId.get(id)!).filter(Boolean);
      return {
        key: m.wordIds[0]!,
        wordIds: m.wordIds,
        phrase: m.phrase,
        before: text(flat.slice(Math.max(0, first - 3), first)),
        hit: text(words),
        after: text(flat.slice(first + words.length, first + words.length + 3)),
        outputTime: wordIdToOutputTime(project, m.wordIds[0]!)?.outputTime ?? null,
        seconds: words.reduce((a, w) => a + Math.max(0, w.end - w.start), 0),
      };
    });
  }, [project, selected]);

  const visible = rows.filter((r) => !ignored.has(r.key));
  const visibleSeconds = visible.reduce((a, r) => a + r.seconds, 0);

  function cut(targets: ReviewRow[]) {
    if (targets.length === 0) return;
    const ids = targets.flatMap((r) => r.wordIds);
    void withProcessingEdit("Removing fillers…", () => {
      deleteWords(ids);
      pushUndoToast(
        `Removed ${targets.length} filler${targets.length === 1 ? "" : "s"}`,
        "Matching audio ranges are cut from the timeline.",
      );
    });
  }

  function keep(row: ReviewRow) {
    setIgnored((prev) => new Set(prev).add(row.key));
  }

  // ── Pauses ─────────────────────────────────────────────────────────────
  const activePauses = pauseTokens.filter((p) => !p.deleted);
  const overThreshold = activePauses.filter((p) => p.duration > threshold);
  const pauseSeconds = overThreshold.reduce((a, p) => a + p.duration, 0);

  if (!hasWords) {
    return (
      <div className="inspector-panel-content">
        <div className="inspector-section">
          <p className="inspector-section-label">Cleanup</p>
          <p className="inspector-hint">
            Transcribe your recording first. Fillers and pauses are found from the transcript and
            the audio, entirely on this Mac.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="inspector-panel-content cl-panel">
      {/* ── Fillers ─────────────────────────────────────────────────────── */}
      <section className="cl-section" aria-label="Fillers">
        <div className="cl-head">
          <h3 className="cl-title">
            <Eraser className="h-4 w-4" />
            Fillers
          </h3>
          <span className="cl-count is-filler">{visible.length}</span>
        </div>

        <div className="cl-chips">
          {SAFE_FILLERS.map((p) => (
            <FillerChip
              key={p}
              phrase={p}
              count={counts.get(p) ?? 0}
              on={selected.has(p)}
              onToggle={() => toggleFiller(p)}
            />
          ))}
        </div>

        <button
          type="button"
          className="cl-more"
          aria-expanded={showMore}
          onClick={() => setShowMore((v) => !v)}
        >
          <ChevronDown className={`h-3.5 w-3.5 ${showMore ? "rotate-180" : ""}`} />
          Real words that are sometimes fillers
        </button>
        {showMore && (
          <div className="cl-chips">
            {OPT_IN_FILLERS.map((p) => (
              <FillerChip
                key={p}
                phrase={p}
                count={counts.get(p) ?? 0}
                on={selected.has(p)}
                onToggle={() => toggleFiller(p)}
              />
            ))}
          </div>
        )}

        <button
          type="button"
          className="cl-primary"
          disabled={visible.length === 0}
          onClick={() => cut(visible)}
        >
          <Scissors className="h-4 w-4" />
          {visible.length === 0
            ? "No fillers to cut"
            : `Cut ${visible.length} filler${visible.length === 1 ? "" : "s"} · ${visibleSeconds.toFixed(1)}s`}
        </button>

        {visible.length > 0 && (
          <ul className="cl-list" aria-label="Filler matches">
            {visible.map((r) => (
              <li key={r.key} className="cl-item">
                <button
                  type="button"
                  className="cl-item-main"
                  onClick={() => r.outputTime !== null && seek(r.outputTime)}
                  disabled={r.outputTime === null}
                  title="Play from one second before"
                >
                  <span className="cl-item-time">
                    <Play className="h-3 w-3" />
                    {r.outputTime !== null ? formatTimecode(r.outputTime, { ms: false }) : "--:--"}
                  </span>
                  <span className="cl-item-text">
                    {r.before && <span className="cl-ctx">{r.before} </span>}
                    <mark className="cl-hit">{r.hit}</mark>
                    {r.after && <span className="cl-ctx"> {r.after}</span>}
                  </span>
                </button>
                <span className="cl-item-actions">
                  <button
                    type="button"
                    className="cl-mini"
                    onClick={() => keep(r)}
                    title={`Keep this "${normaliseFillerToken(r.hit)}"`}
                  >
                    Keep
                  </button>
                  <button type="button" className="cl-mini is-cut" onClick={() => cut([r])}>
                    Cut
                  </button>
                </span>
              </li>
            ))}
          </ul>
        )}
        {ignored.size > 0 && (
          <button type="button" className="cl-more" onClick={() => setIgnored(new Set())}>
            Review {ignored.size} kept again
          </button>
        )}
      </section>

      {/* ── Pauses ──────────────────────────────────────────────────────── */}
      <section className="cl-section" aria-label="Pauses">
        <div className="cl-head">
          <h3 className="cl-title">
            <AudioLines className="h-4 w-4" />
            Pauses
          </h3>
          <span className="cl-count">{activePauses.length}</span>
        </div>

        {activePauses.length === 0 ? (
          <>
            <p className="inspector-hint">
              Find silences longer than {DETECT_PAUSE_MIN_SEC} s in the audio. They show up as
              small chips in the transcript.
            </p>
            <button type="button" className="cl-secondary" onClick={() => void actions.detectAllPauses()}>
              <AudioLines className="h-4 w-4" />
              Detect pauses
            </button>
          </>
        ) : (
          <>
            <label className="cl-slider">
              <span className="cl-slider-row">
                <span>Longer than</span>
                <output className="cl-slider-value">{threshold.toFixed(1)} s</output>
              </span>
              <input
                type="range"
                min={DETECT_PAUSE_MIN_SEC}
                max={3}
                step={0.1}
                value={threshold}
                onChange={(e) => setThreshold(Number(e.target.value))}
              />
            </label>
            <p className="inspector-hint">
              {overThreshold.length} of {activePauses.length} pauses match, {pauseSeconds.toFixed(1)}{" "}
              s of silence.
            </p>
            <button
              type="button"
              className="cl-primary"
              disabled={overThreshold.length === 0}
              onClick={() => void actions.removePauses(threshold)}
            >
              <Scissors className="h-4 w-4" />
              Remove {overThreshold.length} pause{overThreshold.length === 1 ? "" : "s"}
            </button>
            <button
              type="button"
              className="cl-secondary"
              disabled={overThreshold.length === 0}
              onClick={() => void actions.shortenPauses(threshold, SHORTEN_TO_SEC)}
            >
              Shorten to {SHORTEN_TO_SEC} s instead
            </button>
            <button type="button" className="cl-more" onClick={() => void actions.detectAllPauses()}>
              Detect again
            </button>
          </>
        )}
      </section>

      {/* ── Silences ────────────────────────────────────────────────────── */}
      <section className="cl-section" aria-label="Silences">
        <div className="cl-head">
          <h3 className="cl-title">
            <Wand2 className="h-4 w-4" />
            Quick trim
          </h3>
        </div>
        <p className="inspector-hint">
          Cuts every silence over 0.6 s, found in the audio, and keeps a short breath either side.
        </p>
        <button type="button" className="cl-secondary" onClick={() => void actions.trimAudioSilences()}>
          Trim silences
        </button>
      </section>
    </div>
  );
}
