import { useState } from "react";
import { Gauge } from "lucide-react";
import {
  HOLD_UI_MAX_SEC,
  MAX_TRANSITION_SEC,
  MIN_TRANSITION_SEC,
  insertOwnedHold,
  segmentHold,
  segmentSpeed,
  type TimingPatch,
  type TransitionKind,
} from "@/lib/edl";
import { getTimelineIndex } from "@/lib/timelineIndex";
import { formatTimecode } from "@/lib/timecode";
import { pushUndoToast } from "@/lib/undoToast";
import { useEditorUiStore } from "@/stores/editorUiStore";
import { usePlayerStore } from "@/stores/playerStore";
import { useProjectStore } from "@/stores/projectStore";

export const SPEEDS = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 2, 3, 4] as const;

/**
 * A number field that commits once, on blur or Enter, so typing "1.5" is one
 * undo step rather than three. Escape restores the stored value.
 */
function CommitNumber({
  label,
  value,
  min,
  max,
  step,
  disabled,
  onCommit,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  disabled?: boolean;
  onCommit: (v: number) => void;
}) {
  const [draft, setDraft] = useState<string | null>(null);
  const commit = () => {
    if (draft === null) return;
    const v = Number(draft);
    setDraft(null);
    if (Number.isFinite(v) && v !== value) onCommit(Math.min(max, Math.max(min, v)));
  };
  return (
    <label className="tm-row">
      <span>{label}</span>
      <input
        type="number"
        className="tm-input"
        min={min}
        max={max}
        step={step}
        disabled={disabled}
        value={draft ?? String(Math.round(value * 100) / 100)}
        onChange={(e) => setDraft(e.target.value)}
        onBlur={commit}
        onKeyDown={(e) => {
          if (e.key === "Enter") commit();
          if (e.key === "Escape") setDraft(null);
        }}
      />
    </label>
  );
}

/**
 * Speed, mute, freeze frame and the transition into one clip: the clip
 * selected on the timeline, else the one under the playhead. Every control
 * is one undoable edit through `setSegmentTiming`.
 */
export function TimingPanel() {
  const project = useProjectStore((s) => s.project);
  const setTiming = useProjectStore((s) => s.setSegmentTiming);
  const selectedClipId = useEditorUiStore((s) => s.selectedClipId);
  const currentTime = usePlayerStore((s) => s.currentTime);
  const entries = getTimelineIndex(project.segments).entries;
  const entry =
    entries.find((e) => e.segmentId === selectedClipId) ??
    entries.find((e) => currentTime >= e.outputStart && currentTime < e.outputEnd) ??
    entries[entries.length - 1];

  if (!entry) {
    return (
      <div className="inspector-panel-content cl-panel">
        <p className="inspector-hint">Add media first; timing applies to a clip.</p>
      </div>
    );
  }
  const seg = entry.segment;
  const first = entry.index === 0;
  const apply = (patch: TimingPatch, what: string) => {
    setTiming(seg.id, patch);
    pushUndoToast(what);
  };
  const speed = segmentSpeed(seg);
  // Narration inserted by voice-over takes owns part of the hold; only the rest is editable.
  const owned = insertOwnedHold(project, seg.id);
  const hold = Math.max(0, segmentHold(seg) - owned);
  const transition = seg.transitionIn;

  return (
    <div className="inspector-panel-content cl-panel tm-panel">
      <section className="cl-section" aria-label="Clip timing">
        <div className="cl-head">
          <h3 className="cl-title">
            <Gauge className="h-4 w-4" />
            Clip {entry.index + 1} timing
          </h3>
        </div>
        <p className="inspector-hint">
          {formatTimecode(entry.outputStart, { ms: false })}–
          {formatTimecode(entry.outputEnd, { ms: false })} on the timeline. Select a clip on the
          timeline, or use Timing on a transcript selection, to pick another.
        </p>

        <label className="tm-row">
          <span>Speed</span>
          <select
            className="tm-input"
            value={SPEEDS.includes(speed as (typeof SPEEDS)[number]) ? speed : ""}
            onChange={(e) => apply({ speed: Number(e.target.value) }, `Speed ${e.target.value}×`)}
          >
            {!SPEEDS.includes(speed as (typeof SPEEDS)[number]) && (
              <option value="">{speed}×</option>
            )}
            {SPEEDS.map((s) => (
              <option key={s} value={s}>
                {s}×
              </option>
            ))}
          </select>
        </label>
        <label className="st-toggle">
          <input
            type="checkbox"
            checked={!!seg.muted}
            onChange={(e) =>
              apply({ muted: e.target.checked }, e.target.checked ? "Clip muted" : "Clip unmuted")
            }
          />
          <span>Mute this clip</span>
        </label>
        <p className="inspector-hint">Speed keeps the pitch. Words stay on their source times.</p>

        <CommitNumber
          label="Freeze last frame (s)"
          value={hold}
          min={0}
          max={HOLD_UI_MAX_SEC}
          step={0.5}
          onCommit={(v) => apply({ holdSec: owned + v }, v > 0 ? `Freeze ${v}s` : "Freeze removed")}
        />
        <p className="inspector-hint">The hold is silent and comes after the clip plays.</p>
        {owned > 0 && (
          <p className="inspector-hint" role="note">
            This clip also holds its last frame for {Math.round(owned * 100) / 100} s of inserted
            voice-over. That part is not editable here: trim or remove the take in the Music dialog,
            or switch it to Overlay.
          </p>
        )}

        <label className="tm-row">
          <span>Transition in</span>
          <select
            className="tm-input"
            disabled={first}
            value={transition?.kind ?? "none"}
            onChange={(e) => {
              const kind = e.target.value as TransitionKind | "none";
              apply(
                {
                  transitionIn:
                    kind === "none" ? null : { kind, duration: transition?.duration ?? 0.5 },
                },
                kind === "none" ? "Transition removed" : `Transition: ${kind}`,
              );
            }}
          >
            <option value="none">Cut</option>
            <option value="crossfade">Crossfade</option>
            <option value="dip">Dip to black</option>
          </select>
        </label>
        <CommitNumber
          label="Transition (s)"
          value={transition?.duration ?? 0.5}
          min={MIN_TRANSITION_SEC}
          max={MAX_TRANSITION_SEC}
          step={0.1}
          disabled={first || !transition}
          onCommit={(v) =>
            transition &&
            apply({ transitionIn: { ...transition, duration: v } }, `Transition ${v}s`)
          }
        />
        <p className="inspector-hint">
          {first
            ? "The first clip has no cut before it."
            : "Centred on the cut and never changes the length. Preview shows dips; crossfades render on export."}
        </p>
      </section>
    </div>
  );
}
