import { useState } from "react";
import { ImagePlus, RotateCcw } from "lucide-react";
import {
  defaultScene,
  PADDING_MAX_PCT,
  RADIUS_MAX_PCT,
  SCENE_ASPECTS,
  SCENE_PRESETS,
  CROP_MIN,
  cropForRatio,
  cropPixels,
  sanitizeScene,
  sanitizeCrop,
  sceneSourceMedia,
  type CropRect,
  type SceneAspect,
  type SceneBackground,
} from "@/lib/scene";
import { backgroundCss } from "@/lib/sceneCss";
import { useProjectStore } from "@/stores/projectStore";
import { Slider } from "./CaptionsPanel";
import { DeviceFrameSection } from "./DeviceFrameSection";
import { useUIStore } from "@/stores/uiStore";

const ASPECT_LABEL: Record<SceneAspect, string> = {
  source: "Original",
  "16:9": "16:9",
  "9:16": "9:16",
  "1:1": "1:1",
  "4:3": "4:3",
};

function sameBackground(a: SceneBackground, b: SceneBackground) {
  return JSON.stringify(a) === JSON.stringify(b);
}

/** Percent field that applies on Enter or blur, so typing "10" never passes through "1". */
function PercentField({
  label,
  value,
  onCommit,
}: {
  label: string;
  value: number;
  onCommit: (fraction: number) => void;
}) {
  const shown = String(Math.round(value * 1000) / 10);
  // `null` shows the stored (sanitised) value, so after a commit the field
  // always snaps to what was really applied, even when that equals the old value.
  const [draft, setDraft] = useState<string | null>(null);
  const text = draft ?? shown;
  const commit = () => {
    const n = Number(text);
    if (draft !== null && text.trim() !== "" && Number.isFinite(n)) onCommit(n / 100);
    setDraft(null);
  };
  return (
    <label className="sc-num">
      <span>{label}</span>
      <input
        type="number"
        inputMode="decimal"
        min={0}
        max={100}
        step={1}
        value={text}
        aria-label={`${label} (percent of the source)`}
        onChange={(e) => setDraft(e.target.value)}
        onBlur={commit}
        onKeyDown={(e) => {
          if (e.key === "Enter") commit();
        }}
      />
    </label>
  );
}

const CROP_PRESETS: { label: string; ratio: number }[] = [
  { label: "16:9", ratio: 16 / 9 },
  { label: "9:16", ratio: 9 / 16 },
  { label: "1:1", ratio: 1 },
  { label: "4:3", ratio: 4 / 3 },
];

export function ScenePanel() {
  const stored = useProjectStore((s) => s.project.scene);
  const hasMedia = useProjectStore((s) => Object.keys(s.project.media).length > 0);
  // The media the exporter feeds the scene, so crop numbers match what is cut.
  const source = useProjectStore((s) => sceneSourceMedia(s.project));
  const setScene = useProjectStore((s) => s.setScene);
  const clearScene = useProjectStore((s) => s.clearScene);
  const pushToast = useUIStore((s) => s.pushToast);
  const [custom, setCustom] = useState(false);

  const scene = sanitizeScene(stored);
  const bg = scene.background;
  const crop: CropRect = scene.crop ?? { x: 0, y: 0, w: 1, h: 1 };
  const srcSize = source ? { w: source.width, h: source.height } : undefined;
  const cropPx = scene.crop && srcSize ? cropPixels(scene.crop, srcSize) : undefined;
  const [cropNote, setCropNote] = useState(false);
  const setCrop = (patch: Partial<CropRect>) => {
    const want = { ...crop, ...patch };
    const got = sanitizeCrop(want) ?? { x: 0, y: 0, w: 1, h: 1 };
    // Position cannot push the crop outside the picture; tell the user it was adjusted.
    setCropNote(Math.abs(got.x - want.x) > 0.0005 || Math.abs(got.y - want.y) > 0.0005);
    setScene({ crop: want });
  };
  const presetOn = (ratio: number) => {
    const c = srcSize ? cropForRatio(ratio, srcSize) : null;
    if (!scene.crop || !c) return false;
    return (["x", "y", "w", "h"] as const).every((k) => Math.abs(scene.crop![k] - c[k]) < 0.002);
  };

  async function chooseImage() {
    try {
      const { open } = await import("@tauri-apps/plugin-dialog");
      const picked = await open({
        multiple: false,
        filters: [{ name: "Images", extensions: ["png", "jpg", "jpeg", "webp"] }],
      });
      if (typeof picked === "string") setScene({ background: { kind: "image", path: picked } });
    } catch (err) {
      pushToast({
        title: "Could not open the image",
        description: String(err),
        variant: "destructive",
      });
    }
  }

  if (!hasMedia) {
    return (
      <div className="inspector-panel-content">
        <div className="inspector-section">
          <p className="inspector-section-label">Look</p>
          <p className="inspector-hint">
            Open a video first. Then add a background, padding, rounded corners and a shadow around
            it.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="inspector-panel-content cl-panel">
      <section className="cl-section" aria-label="Frame">
        <label className="st-toggle">
          <input
            type="checkbox"
            checked={scene.enabled}
            onChange={(e) => setScene({ enabled: e.target.checked })}
          />
          <span className="st-row-text">
            <span className="st-row-title">Style the frame</span>
            <span className="st-row-hint">
              Shows in the preview and the export. Any change below turns it on.
            </span>
          </span>
        </label>
      </section>

      <section className="cl-section" aria-label="Canvas">
        <div className="cl-head">
          <h3 className="cl-title">Canvas</h3>
        </div>
        <div className="st-segment st-segment-wrap" role="radiogroup" aria-label="Aspect ratio">
          {SCENE_ASPECTS.map((a) => (
            <button
              key={a}
              type="button"
              role="radio"
              aria-checked={scene.aspect === a}
              className={`st-segment-btn${scene.aspect === a ? " is-on" : ""}`}
              onClick={() => setScene({ aspect: a })}
            >
              {ASPECT_LABEL[a]}
            </button>
          ))}
        </div>
        <p className="inspector-hint">
          Original keeps the video's size. Others export at 1080 high, or 1080 wide for 9:16.
        </p>
      </section>

      <section className="cl-section" aria-label="Crop">
        <div className="cl-head">
          <h3 className="cl-title">Crop</h3>
        </div>
        <div className="st-segment st-segment-wrap" role="group" aria-label="Crop presets">
          <button
            type="button"
            className={`st-segment-btn${scene.crop ? "" : " is-on"}`}
            aria-pressed={!scene.crop}
            onClick={() => {
              setCropNote(false);
              // Clearing the crop must not switch a disabled frame on.
              setScene({ crop: undefined, enabled: scene.enabled });
            }}
          >
            None
          </button>
          {CROP_PRESETS.map((p) => (
            <button
              key={p.label}
              type="button"
              className={`st-segment-btn${presetOn(p.ratio) ? " is-on" : ""}`}
              aria-pressed={presetOn(p.ratio)}
              disabled={!srcSize}
              onClick={() => {
                const c = srcSize ? cropForRatio(p.ratio, srcSize) : null;
                setCropNote(false);
                setScene({ crop: c ?? undefined });
              }}
            >
              {p.label}
            </button>
          ))}
        </div>
        <div className="sc-num-grid" role="group" aria-label="Crop rectangle">
          <PercentField label="Left" value={crop.x} onCommit={(x) => setCrop({ x })} />
          <PercentField label="Top" value={crop.y} onCommit={(y) => setCrop({ y })} />
          <PercentField
            label="Width"
            value={crop.w}
            onCommit={(w) => setCrop({ w: Math.max(CROP_MIN, w) })}
          />
          <PercentField
            label="Height"
            value={crop.h}
            onCommit={(h) => setCrop({ h: Math.max(CROP_MIN, h) })}
          />
        </div>
        <p className="inspector-hint">
          {cropPx
            ? `Keeps ${cropPx.w} x ${cropPx.h} px of the source, cut before padding and canvas. `
            : "Whole picture. "}
          Values are percent of the source; presets centre the crop. Crop is part of the frame
          style: it shows in the preview and export only while "Style the frame" is on.
        </p>
        {cropNote && (
          <p className="inspector-hint" role="status">
            Left and Top were adjusted so the crop stays inside the picture.
          </p>
        )}
      </section>

      <section className="cl-section" aria-label="Background">
        <div className="cl-head">
          <h3 className="cl-title">Background</h3>
        </div>
        <div className="sc-swatches" role="group" aria-label="Background presets">
          {SCENE_PRESETS.map((p) => {
            const on = scene.enabled && sameBackground(bg, p.background);
            return (
              <button
                key={p.id}
                type="button"
                className={`sc-swatch${on ? " is-on" : ""}`}
                style={backgroundCss(p.background)}
                aria-label={p.name}
                aria-pressed={on}
                title={p.name}
                onClick={() => setScene({ background: p.background })}
              />
            );
          })}
        </div>

        {bg.kind === "transparent" && (
          <p className="inspector-hint">
            Transparent shows a checkerboard here. Only ProRes 4444 keeps it on export; other
            formats use a black background and the Export dialog says so.
          </p>
        )}

        <button
          type="button"
          className="cl-more"
          aria-expanded={custom}
          onClick={() => setCustom((v) => !v)}
        >
          {custom ? "Hide custom options" : "Custom colour or image"}
        </button>

        {custom && (
          <div className="sc-custom">
            <div className="st-segment" role="radiogroup" aria-label="Background type">
              {(["solid", "gradient", "image"] as const).map((kind) => (
                <button
                  key={kind}
                  type="button"
                  role="radio"
                  aria-checked={bg.kind === kind}
                  className={`st-segment-btn${bg.kind === kind ? " is-on" : ""}`}
                  onClick={() => {
                    if (kind === "solid") {
                      setScene({
                        background: {
                          kind: "solid",
                          color: bg.kind === "solid" ? bg.color : "#0f0f12",
                        },
                      });
                    } else if (kind === "gradient") {
                      setScene({
                        background:
                          bg.kind === "gradient"
                            ? bg
                            : { kind: "gradient", from: "#232526", to: "#414345", angle: 135 },
                      });
                    } else {
                      void chooseImage();
                    }
                  }}
                >
                  {kind === "solid" ? "Solid" : kind === "gradient" ? "Gradient" : "Image"}
                </button>
              ))}
            </div>

            {bg.kind === "solid" && (
              <label className="sc-color">
                <span>Colour</span>
                <input
                  type="color"
                  value={bg.color}
                  aria-label="Background colour"
                  onChange={(e) =>
                    setScene({ background: { kind: "solid", color: e.target.value } })
                  }
                />
              </label>
            )}

            {bg.kind === "gradient" && (
              <>
                <div className="sc-color-row">
                  <label className="sc-color">
                    <span>From</span>
                    <input
                      type="color"
                      value={bg.from}
                      aria-label="Gradient start colour"
                      onChange={(e) => setScene({ background: { ...bg, from: e.target.value } })}
                    />
                  </label>
                  <label className="sc-color">
                    <span>To</span>
                    <input
                      type="color"
                      value={bg.to}
                      aria-label="Gradient end colour"
                      onChange={(e) => setScene({ background: { ...bg, to: e.target.value } })}
                    />
                  </label>
                </div>
                <Slider
                  label="Angle"
                  value={bg.angle}
                  min={0}
                  max={360}
                  step={5}
                  suffix="°"
                  onChange={(angle) => setScene({ background: { ...bg, angle } })}
                />
              </>
            )}

            {bg.kind === "image" && (
              <button type="button" className="cl-secondary" onClick={() => void chooseImage()}>
                <ImagePlus className="h-4 w-4" />
                Choose a different image
              </button>
            )}
          </div>
        )}
      </section>

      <DeviceFrameSection
        frame={scene.frame}
        onChange={(frame) =>
          // Removing the device must not switch a disabled frame on.
          setScene(frame ? { frame } : { frame: undefined, enabled: scene.enabled })
        }
      />

      <section className="cl-section" aria-label="Frame style">
        <div className="cl-head">
          <h3 className="cl-title">Frame</h3>
        </div>
        <Slider
          label="Padding"
          value={scene.paddingPct}
          min={0}
          max={PADDING_MAX_PCT}
          step={1}
          suffix="%"
          onChange={(paddingPct) => setScene({ paddingPct })}
        />
        {scene.frame ? (
          <p className="inspector-hint">
            Corner roundness comes from the device frame. Remove the device to set it here.
          </p>
        ) : (
          <Slider
            label="Rounded corners"
            value={scene.radiusPct}
            min={0}
            max={RADIUS_MAX_PCT}
            step={1}
            suffix="%"
            onChange={(radiusPct) => setScene({ radiusPct })}
          />
        )}
        <Slider
          label="Shadow"
          value={Math.round(scene.shadow * 100)}
          min={0}
          max={100}
          step={5}
          suffix="%"
          onChange={(v) => setScene({ shadow: v / 100 })}
        />
      </section>

      <section className="cl-section" aria-label="Reset">
        <button
          type="button"
          className="cl-secondary"
          onClick={() => setScene({ ...defaultScene(), enabled: true })}
        >
          <RotateCcw className="h-4 w-4" />
          Reset to defaults
        </button>
        <button
          type="button"
          className="cl-secondary is-danger"
          disabled={!stored}
          onClick={clearScene}
        >
          Remove the frame
        </button>
      </section>
    </div>
  );
}
