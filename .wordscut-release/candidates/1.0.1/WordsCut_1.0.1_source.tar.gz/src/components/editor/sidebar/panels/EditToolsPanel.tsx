import { Toolbox } from "@/components/Toolbox/Toolbox";
import { useEditorUiStore } from "@/stores/editorUiStore";

export function EditToolsPanel() {
  const openPanel = useEditorUiStore((s) => s.openPanel);

  return (
    <div className="inspector-panel-content">
      <div className="inspector-section">
        <Toolbox onFindClick={() => openPanel("find")} />
      </div>
    </div>
  );
}
