import { Mic, Music } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useEditorShortcutLabel } from "@/hooks/useShortcutLabel";
import { useProjectStore } from "@/stores/projectStore";
import { useVoiceOverStore } from "@/stores/voiceOverStore";

export function MusicPanel() {
  const projectId = useProjectStore((s) => s.project.id);
  const hasVideo = useProjectStore((s) => s.project.segments.length > 0);
  const phase = useVoiceOverStore((s) => s.phase);
  const pending = useVoiceOverStore(
    (s) => s.pending.filter((d) => d.projectId === projectId).length,
  );
  const prefs = useVoiceOverStore((s) => s.prefs);
  const devices = useVoiceOverStore((s) => s.devices);
  const key = useEditorShortcutLabel("voiceOver");
  const vo = useVoiceOverStore.getState;
  const mics = devices?.audio ?? [];
  return (
    <div className="inspector-panel-content">
      <div className="inspector-section">
        <p className="inspector-section-label">Music</p>
        <Button
          variant="outline"
          className="w-full gap-2 justify-start"
          onClick={() => window.dispatchEvent(new CustomEvent("yusafcut:music"))}
        >
          <Music className="h-4 w-4" />
          Manage music and voice-over tracks
        </Button>
        <p className="inspector-hint">
          Audio beds and kept voice-over takes mixed with the timeline.
        </p>
      </div>
      <div className="inspector-section">
        <p className="inspector-section-label">Voice-over</p>
        <Button
          variant="outline"
          className="w-full gap-2 justify-start"
          disabled={!hasVideo || (phase !== "idle" && phase !== "recording")}
          onClick={() => vo().toggle()}
        >
          <Mic className="h-4 w-4" />
          {phase === "recording" ? "Stop voice-over" : "Record voice-over at playhead"} ({key})
        </Button>
        {pending > 0 && phase === "idle" && (
          <Button variant="secondary" className="w-full" onClick={() => vo().openReview()}>
            Review pending take{pending > 1 ? `s (${pending})` : ""}
          </Button>
        )}
        <label className="grid gap-1 text-xs">
          Microphone
          <select
            className="h-8 rounded-md border border-input bg-background px-2 text-sm"
            value={prefs.micName ?? ""}
            onFocus={() => void vo().refreshDevices()}
            onChange={(e) => vo().setPrefs({ micName: e.target.value || undefined })}
          >
            <option value="">Recorder default</option>
            {prefs.micName && !mics.some((m) => m.name === prefs.micName) && (
              <option value={prefs.micName}>{prefs.micName} (not connected)</option>
            )}
            {mics.map((m) => (
              <option key={m.index} value={m.name}>
                {m.name}
              </option>
            ))}
          </select>
        </label>
        <label className="grid gap-1 text-xs">
          New takes start as
          <select
            className="h-8 rounded-md border border-input bg-background px-2 text-sm"
            value={prefs.mode}
            onChange={(e) =>
              vo().setPrefs({ mode: e.target.value === "insert" ? "insert" : "overlay" })
            }
          >
            <option value="overlay">Overlay (mix over the video)</option>
            <option value="insert">Insert (hold the frame while it plays)</option>
          </select>
        </label>
        <label className="flex items-center gap-2 text-xs">
          <input
            type="checkbox"
            checked={prefs.overrideOriginal}
            onChange={(e) => vo().setPrefs({ overrideOriginal: e.target.checked })}
          />
          Override the original audio by default
        </label>
        <label className="flex items-center gap-2 text-xs">
          <input
            type="checkbox"
            checked={prefs.playWhileRecording}
            onChange={(e) => vo().setPrefs({ playWhileRecording: e.target.checked })}
          />
          Play the video while recording
        </label>
        <label className="grid gap-1 text-xs">
          Latency trim (ms, cut from the start of each kept take)
          <input
            type="number"
            min={0}
            max={1000}
            step={5}
            className="h-8 rounded-md border border-input bg-background px-2 text-sm"
            value={prefs.latencyMs}
            onChange={(e) => {
              const n = Number(e.target.value);
              if (Number.isFinite(n)) vo().setPrefs({ latencyMs: Math.min(1000, Math.max(0, n)) });
            }}
          />
        </label>
        <p className="inspector-hint">
          The take starts where the playhead is when you press Record; playback during the take does
          not move it. After you stop, review it: Overlay or Insert, Override, Keep, Retake or
          Discard.
        </p>
      </div>
    </div>
  );
}
