import { PlaybackDiagnostics } from "./PlaybackDiagnostics";
import { useCallback, useEffect, useState } from "react";
import { RotateCcw } from "lucide-react";
import { editorDef, editorDefsIn, type EditorAction } from "@/lib/editorShortcuts";
import { COUNTDOWN_CHOICES, type CountdownSec } from "@/lib/settings";
import {
  acceleratorFromEvent,
  defaultShortcuts,
  formatAccelerator,
  SHORTCUT_DEFS,
  type ShortcutAction,
} from "@/lib/shortcuts";
import { useSettingsStore } from "@/stores/settingsStore";

interface ShortcutRowProps {
  label: string;
  description?: string;
  accelerator: string;
  defaultAccelerator: string;
  onSet: (accelerator: string) => { ok: true } | { ok: false; reason: string };
  onReset: () => void;
}

function ShortcutRow({
  label,
  description,
  accelerator,
  defaultAccelerator,
  onSet,
  onReset,
}: ShortcutRowProps) {
  const [capturing, setCapturing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const isDefault = accelerator === defaultAccelerator;

  // While capturing, the next key combination becomes the shortcut. Escape cancels.
  useEffect(() => {
    if (!capturing) return;
    const onKey = (e: KeyboardEvent) => {
      e.preventDefault();
      e.stopPropagation();
      if (e.key === "Escape") {
        setCapturing(false);
        setError(null);
        return;
      }
      const next = acceleratorFromEvent(e);
      if (!next) return; // only modifiers so far
      const result = onSet(next);
      setError(result.ok ? null : result.reason);
      setCapturing(false);
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, [capturing, onSet]);

  return (
    <li className="st-row">
      <div className="st-row-text">
        <span className="st-row-title">{label}</span>
        {description && <span className="st-row-hint">{description}</span>}
        {error && (
          <span className="st-error" role="alert">
            {error}
          </span>
        )}
      </div>
      <div className="st-row-keys">
        <button
          type="button"
          className={`st-key${capturing ? " is-capturing" : ""}`}
          onClick={() => {
            setError(null);
            setCapturing((v) => !v);
          }}
          onBlur={() => setCapturing(false)}
          aria-label={`${label} shortcut: ${formatAccelerator(accelerator)}. Click to change.`}
        >
          {capturing ? "Press keys…" : formatAccelerator(accelerator)}
        </button>
        {!isDefault && (
          <button
            type="button"
            className="fr-icon-btn"
            onClick={() => {
              onReset();
              setError(null);
            }}
            aria-label={`Reset ${label} to ${formatAccelerator(defaultAccelerator)}`}
            title="Reset to default"
          >
            <RotateCcw className="h-3.5 w-3.5" />
          </button>
        )}
      </div>
    </li>
  );
}

function RecorderShortcutRow({ action }: { action: ShortcutAction }) {
  const def = SHORTCUT_DEFS.find((d) => d.action === action)!;
  const accelerator = useSettingsStore((s) => s.shortcuts[action]);
  const setShortcut = useSettingsStore((s) => s.setShortcut);
  const resetShortcut = useSettingsStore((s) => s.resetShortcut);
  const onSet = useCallback((a: string) => setShortcut(action, a), [setShortcut, action]);
  return (
    <ShortcutRow
      label={def.label}
      description={def.description}
      accelerator={accelerator}
      defaultAccelerator={defaultShortcuts()[action]}
      onSet={onSet}
      onReset={() => resetShortcut(action)}
    />
  );
}

function EditorShortcutRow({ action }: { action: EditorAction }) {
  const def = editorDef(action);
  const accelerator = useSettingsStore((s) => s.editorShortcuts[action]);
  const setEditorShortcut = useSettingsStore((s) => s.setEditorShortcut);
  const resetEditorShortcut = useSettingsStore((s) => s.resetEditorShortcut);
  const onSet = useCallback(
    (a: string) => setEditorShortcut(action, a),
    [setEditorShortcut, action],
  );
  return (
    <ShortcutRow
      label={def.label}
      accelerator={accelerator}
      defaultAccelerator={def.default}
      onSet={onSet}
      onReset={() => resetEditorShortcut(action)}
    />
  );
}

function Toggle({
  label,
  hint,
  checked,
  onChange,
}: {
  label: string;
  hint: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <label className="st-toggle">
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} />
      <span className="st-row-text">
        <span className="st-row-title">{label}</span>
        <span className="st-row-hint">{hint}</span>
      </span>
    </label>
  );
}

export function SettingsPanel() {
  const recording = useSettingsStore((s) => s.recording);
  const setRecording = useSettingsStore((s) => s.setRecording);
  const resetShortcuts = useSettingsStore((s) => s.resetShortcuts);
  const resetEditorShortcuts = useSettingsStore((s) => s.resetEditorShortcuts);

  return (
    <div className="inspector-panel-content cl-panel">
      <PlaybackDiagnostics />
      <section className="cl-section" aria-label="Recording">
        <div className="cl-head">
          <h3 className="cl-title">Recording</h3>
        </div>

        <fieldset className="st-fieldset">
          <legend className="st-row-title">Recorder style</legend>
          <div className="st-segment" role="radiogroup" aria-label="Recorder style">
            {(
              [
                ["bar", "Floating bar"],
                ["dialog", "Dialog"],
              ] as const
            ).map(([style, label]) => (
              <button
                key={style}
                type="button"
                role="radio"
                aria-checked={recording.setupStyle === style}
                className={`st-segment-btn${recording.setupStyle === style ? " is-on" : ""}`}
                onClick={() => setRecording({ setupStyle: style })}
              >
                {label}
              </button>
            ))}
          </div>
        </fieldset>
        <Toggle
          label="One-press start"
          hint="The shortcut and menu-bar item start recording with your last settings, no dialog."
          checked={recording.quickStart}
          onChange={(v) => setRecording({ quickStart: v })}
        />
        <Toggle
          label="Hide WordsCut while recording"
          hint="Minimises this window so it isn't in the footage. Control it from the menu bar."
          checked={recording.hideWindow}
          onChange={(v) => setRecording({ hideWindow: v })}
        />
        <Toggle
          label="Show floating recording controls"
          hint="Drag them in camera/audio recordings, or hide them and use the Mac menu bar. Screen recordings always hide this overlay so it stays out of footage."
          checked={recording.showHUD}
          onChange={(v) => setRecording({ showHUD: v })}
        />
        <Toggle
          label="Transcribe recordings automatically"
          hint="Uses the best Whisper model you have installed."
          checked={recording.autoTranscribe}
          onChange={(v) => setRecording({ autoTranscribe: v })}
        />
        <Toggle
          label="Turn marked moments into chapters"
          hint="Each moment you mark while recording becomes a chapter."
          checked={recording.markersBecomeChapters}
          onChange={(v) => setRecording({ markersBecomeChapters: v })}
        />

        <fieldset className="st-fieldset">
          <legend className="st-row-title">Countdown before recording</legend>
          <div className="st-segment" role="radiogroup" aria-label="Countdown before recording">
            {COUNTDOWN_CHOICES.map((sec: CountdownSec) => (
              <button
                key={sec}
                type="button"
                role="radio"
                aria-checked={recording.countdownSec === sec}
                className={`st-segment-btn${recording.countdownSec === sec ? " is-on" : ""}`}
                onClick={() => setRecording({ countdownSec: sec })}
              >
                {sec === 0 ? "Off" : `${sec} s`}
              </button>
            ))}
          </div>
        </fieldset>
      </section>

      <section className="cl-section" aria-label="Shortcuts">
        <div className="cl-head">
          <h3 className="cl-title">Shortcuts</h3>
          <button type="button" className="cl-more" onClick={resetShortcuts}>
            Reset all
          </button>
        </div>
        <p className="inspector-hint">
          Click a shortcut, then press the keys you want. They work from any app. Escape cancels.
        </p>
        <ul className="st-list">
          {SHORTCUT_DEFS.map((d) => (
            <RecorderShortcutRow key={d.action} action={d.action} />
          ))}
        </ul>
      </section>

      <section className="cl-section" aria-label="Editor shortcuts">
        <div className="cl-head">
          <h3 className="cl-title">Editor shortcuts</h3>
          <button type="button" className="cl-more" onClick={resetEditorShortcuts}>
            Reset all
          </button>
        </div>
        <p className="inspector-hint">
          Work while the editor has focus, not while typing or in a dialog. Click a shortcut, then
          press the keys you want. Escape cancels.
        </p>
        <ul className="st-list">
          {editorDefsIn("editor").map((d) => (
            <EditorShortcutRow key={d.action} action={d.action} />
          ))}
        </ul>
        <p className="inspector-hint">
          Voice-over review: these keys work only while the take review is open (Escape closes it
          and keeps the take for later).
        </p>
        <ul className="st-list">
          {editorDefsIn("review").map((d) => (
            <EditorShortcutRow key={d.action} action={d.action} />
          ))}
        </ul>
      </section>
    </div>
  );
}
