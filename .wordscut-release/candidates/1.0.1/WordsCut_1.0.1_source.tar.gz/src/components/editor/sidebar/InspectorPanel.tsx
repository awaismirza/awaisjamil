import { useEditorUiStore } from "@/stores/editorUiStore";
import { PANELS } from "./registry";

export function InspectorPanel() {
  const activePanel = useEditorUiStore((s) => s.activePanel);
  const open = useEditorUiStore((s) => s.inspectorOpen);

  if (!open) return null;
  const def = PANELS.find((p) => p.id === activePanel) ?? PANELS[0];
  if (!def) return null;
  const Panel = def.component;

  return (
    <div className="inspector-panel" style={{ width: 352 }}>
      <div className="inspector-panel-header">
        <span className="inspector-panel-title">{def.label}</span>
      </div>
      <div className="inspector-panel-scroll">
        <Panel />
      </div>
    </div>
  );
}
