import {
  Captions,
  Clapperboard,
  Eraser,
  Gauge,
  ListOrdered,
  MicVocal,
  Music,
  Palette,
  Scissors,
  Search,
  Settings,
  Shapes,
  Upload,
  ZoomIn,
  type LucideIcon,
} from "lucide-react";
import type React from "react";
import { CaptionsPanel } from "./panels/CaptionsPanel";
import { ChaptersPanel } from "./panels/ChaptersPanel";
import { CleanupPanel } from "./panels/CleanupPanel";
import { EditToolsPanel } from "./panels/EditToolsPanel";
import { ExportPanel } from "./panels/ExportPanel";
import { FindPanel } from "./panels/FindPanel";
import { MediaPanel } from "./panels/MediaPanel";
import { MusicPanel } from "./panels/MusicPanel";
import { ZoomPanel } from "./panels/ZoomPanel";
import { TimingPanel } from "./panels/TimingPanel";
import { ScenePanel } from "./panels/ScenePanel";
import { OverlaysPanel } from "./panels/OverlaysPanel";
import { SettingsPanel } from "./panels/SettingsPanel";
import { TranscribePanel } from "./panels/TranscribePanel";

export interface PanelDef {
  id: string;
  icon: LucideIcon;
  label: string;
  /** Shorter label for the 68 px tool rail; falls back to `label`. */
  railLabel?: string;
  /** `bottom` pins the tab to the foot of the rail, away from the workflow tabs. */
  placement?: "bottom";
  component: React.FC;
}

/**
 * Declarative panel registry, in rail order. Adding a future panel is one entry
 * here plus a component file — the rail and inspector render whatever this
 * list says. There are no workspace modes: every panel is always available.
 */
export const PANELS: PanelDef[] = [
  { id: "media", icon: Clapperboard, label: "Media", component: MediaPanel },
  { id: "transcribe", icon: MicVocal, label: "Transcribe", component: TranscribePanel },
  { id: "cleanup", icon: Eraser, label: "Cleanup", component: CleanupPanel },
  { id: "chapters", icon: ListOrdered, label: "Chapters", component: ChaptersPanel },
  { id: "zoom", icon: ZoomIn, label: "Zoom", component: ZoomPanel },
  { id: "timing", icon: Gauge, label: "Timing", component: TimingPanel },
  { id: "look", icon: Palette, label: "Look", component: ScenePanel },
  { id: "captions", icon: Captions, label: "Captions", component: CaptionsPanel },
  {
    id: "overlays",
    icon: Shapes,
    label: "Annotations & Keys",
    railLabel: "Overlays",
    component: OverlaysPanel,
  },
  { id: "find", icon: Search, label: "Find & Replace", railLabel: "Find", component: FindPanel },
  {
    id: "edit-tools",
    icon: Scissors,
    label: "Edit Tools",
    railLabel: "Tools",
    component: EditToolsPanel,
  },
  { id: "music", icon: Music, label: "Music", component: MusicPanel },
  { id: "export", icon: Upload, label: "Export", component: ExportPanel },
  {
    id: "settings",
    icon: Settings,
    label: "Settings",
    placement: "bottom",
    component: SettingsPanel,
  },
];
