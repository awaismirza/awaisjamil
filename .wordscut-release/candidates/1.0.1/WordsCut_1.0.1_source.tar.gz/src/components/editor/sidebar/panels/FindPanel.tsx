import { FindReplacePanel } from "@/components/TranscriptEditor/FindReplacePanel";

export function FindPanel() {
  return (
    <div className="inspector-panel-content">
      <FindReplacePanel />
    </div>
  );
}
