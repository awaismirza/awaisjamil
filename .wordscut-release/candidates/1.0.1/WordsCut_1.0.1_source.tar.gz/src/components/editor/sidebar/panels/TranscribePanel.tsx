import { useUIStore } from "@/stores/uiStore";
import { ArrowRight, MicVocal } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useEditorUiStore } from "@/stores/editorUiStore";
import { useProjectStore } from "@/stores/projectStore";

export function TranscribePanel() {
  const media = useProjectStore((s) => s.project.media);
  const background = useUIStore((s) => s.backgroundTranscriptions);
  const recognizing = Object.keys(media).some((id) => Object.hasOwn(background, id));
  const hasTranscript = useProjectStore((s) =>
    s.project.segments.some((seg) => seg.words.length > 0),
  );
  const hasMedia = useProjectStore((s) => Object.keys(s.project.media).length > 0);
  const openPanel = useEditorUiStore((s) => s.openPanel);

  return (
    <div className="inspector-panel-content">
      <div className="inspector-section">
        <p className="inspector-section-label">Transcription</p>
        <Button
          className="w-full gap-2"
          disabled={!hasMedia || recognizing}
          onClick={() => window.dispatchEvent(new CustomEvent("yusafcut:transcribe"))}
        >
          <MicVocal className="h-4 w-4" />
          {recognizing
            ? "Transcribing in background…"
            : hasTranscript
              ? "Re-Transcribe"
              : "Transcribe"}
        </Button>
        {recognizing && (
          <p className="inspector-hint" role="status">
            Playback and clip editing are available while your transcript is prepared.
          </p>
        )}
        <p className="inspector-hint">whisper.cpp · Core ML · Apple Silicon · runs locally</p>
      </div>
      {hasTranscript && (
        <div className="inspector-section">
          <p className="inspector-section-label">Next step</p>
          <Button variant="outline" className="w-full gap-2" onClick={() => openPanel("cleanup")}>
            <ArrowRight className="h-4 w-4" />
            Clean up fillers and pauses
          </Button>
          <p className="inspector-hint">Then edit the video by editing the text.</p>
        </div>
      )}
    </div>
  );
}
