import { useState } from "react";
import {
  FRAME_KINDS,
  FRAME_TITLE_MAX,
  PHONE_CUTOUTS,
  frameColor,
  type DeviceFrame,
  type FrameKind,
  type FrameTheme,
} from "@/lib/scene";
import { ColorField } from "./CaptionsPanel";

const KIND_LABEL: Record<FrameKind, string> = {
  browser: "Browser",
  laptop: "Laptop",
  phone: "Phone",
  tablet: "Tablet",
};

const KIND_HINT: Record<FrameKind, string> = {
  browser: "A window with a title bar. The picture fills it.",
  laptop: "A screen with a bezel and a base. The picture fills the screen.",
  phone:
    "A portrait phone. A landscape picture is letterboxed on the screen; a 9:16 canvas fits it best.",
  tablet: "A landscape tablet. A picture with another shape is letterboxed on the screen.",
};

/** Text that applies on Enter or blur (Escape reverts), so typing is not one undo step per key. */
function TextField({
  label,
  value,
  maxLength,
  onCommit,
}: {
  label: string;
  value: string;
  maxLength: number;
  onCommit: (v: string) => void;
}) {
  const [draft, setDraft] = useState<string | null>(null);
  const text = draft ?? value;
  const commit = () => {
    if (draft !== null && draft !== value) onCommit(draft);
    setDraft(null);
  };
  return (
    <label className="sc-num">
      <span>{label}</span>
      <input
        type="text"
        value={text}
        maxLength={maxLength}
        aria-label={label}
        spellCheck={false}
        onChange={(e) => setDraft(e.target.value)}
        onBlur={commit}
        onKeyDown={(e) => {
          if (e.key === "Enter") commit();
          if (e.key === "Escape") setDraft(null);
        }}
      />
    </label>
  );
}

/** Device frame controls of the Look panel: none, browser, laptop, phone or tablet. */
export function DeviceFrameSection({
  frame,
  onChange,
}: {
  frame: DeviceFrame | undefined;
  /** `undefined` removes the frame. */
  onChange: (frame: DeviceFrame | undefined) => void;
}) {
  const withoutColor = (f: DeviceFrame): DeviceFrame => {
    const { color: _color, ...rest } = f;
    void _color;
    return rest;
  };
  return (
    <section className="cl-section" aria-label="Device frame">
      <div className="cl-head">
        <h3 className="cl-title">Device frame</h3>
      </div>
      <div className="st-segment st-segment-wrap" role="radiogroup" aria-label="Device frame type">
        <button
          type="button"
          role="radio"
          aria-checked={!frame}
          className={`st-segment-btn${frame ? "" : " is-on"}`}
          onClick={() => onChange(undefined)}
        >
          None
        </button>
        {FRAME_KINDS.map((kind) => (
          <button
            key={kind}
            type="button"
            role="radio"
            aria-checked={frame?.kind === kind}
            className={`st-segment-btn${frame?.kind === kind ? " is-on" : ""}`}
            // A new device starts from its own default colour; the browser text carries over.
            onClick={() =>
              onChange({
                kind,
                theme: frame?.theme ?? "light",
                ...(frame?.title ? { title: frame.title } : {}),
              })
            }
          >
            {KIND_LABEL[kind]}
          </button>
        ))}
      </div>

      {frame ? (
        <>
          <p className="inspector-hint">{KIND_HINT[frame.kind]}</p>
          {frame.kind === "phone" && (
            <div className="st-segment" role="radiogroup" aria-label="Camera cutout">
              {PHONE_CUTOUTS.map((cutout) => {
                const on = (frame.cutout ?? "dot") === cutout;
                return (
                  <button
                    key={cutout}
                    type="button"
                    role="radio"
                    aria-checked={on}
                    className={`st-segment-btn${on ? " is-on" : ""}`}
                    onClick={() => onChange({ ...frame, cutout })}
                  >
                    {cutout === "none" ? "No cutout" : cutout === "dot" ? "Dot" : "Notch"}
                  </button>
                );
              })}
            </div>
          )}
          {frame.kind === "browser" && (
            <>
              <div className="st-segment" role="radiogroup" aria-label="Browser window style">
                {(["light", "dark"] as FrameTheme[]).map((theme) => (
                  <button
                    key={theme}
                    type="button"
                    role="radio"
                    aria-checked={frame.theme === theme}
                    className={`st-segment-btn${frame.theme === theme ? " is-on" : ""}`}
                    // A new style starts from its own default colour.
                    onClick={() => onChange({ ...withoutColor(frame), theme })}
                  >
                    {theme === "light" ? "Light" : "Dark"}
                  </button>
                ))}
              </div>
              <TextField
                label="Address bar text"
                value={frame.title ?? ""}
                maxLength={FRAME_TITLE_MAX}
                onCommit={(title) => {
                  const { title: _title, ...rest } = frame;
                  void _title;
                  onChange(title.trim() ? { ...rest, title } : rest);
                }}
              />
            </>
          )}
          <ColorField
            label={frame.kind === "browser" ? "Title bar colour" : "Bezel colour"}
            value={frameColor(frame)}
            onChange={(color) => onChange({ ...frame, color })}
          />
          <button
            type="button"
            className="cl-secondary"
            disabled={!frame.color}
            onClick={() => onChange(withoutColor(frame))}
          >
            Use the default colour
          </button>
        </>
      ) : (
        <p className="inspector-hint">
          Draw a browser window, laptop, phone or tablet around the picture. Drawn from simple
          shapes, with no brand artwork.
        </p>
      )}
    </section>
  );
}
