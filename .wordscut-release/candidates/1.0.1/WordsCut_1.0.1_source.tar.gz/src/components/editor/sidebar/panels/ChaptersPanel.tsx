import { useMemo, useState } from "react";
import { Minus, Play, Plus, Sparkles, Trash2 } from "lucide-react";
import {
  defaultChapterCount,
  DEFAULT_MIN_CHAPTER_SEC,
  suggestChapters,
  type ChapterSuggestion,
} from "@/lib/autoChapters";
import { projectChapters, totalDuration } from "@/lib/edl";
import { formatTimecode } from "@/lib/timecode";
import { pushUndoToast } from "@/lib/undoToast";
import { useProjectStore } from "@/stores/projectStore";

/** Two chapters closer than this are the same chapter. */
const DUPLICATE_WITHIN_SEC = 0.5;
/** YouTube only shows chapters when there are at least this many. */
const YOUTUBE_MIN_CHAPTERS = 3;
const MAX_COUNT = 20;

interface Proposal extends ChapterSuggestion {
  key: string;
  on: boolean;
}

function seek(time: number) {
  window.dispatchEvent(
    new CustomEvent("yusafcut:seek-output", { detail: { time: Math.max(0, time), play: true } }),
  );
}

export function ChaptersPanel() {
  const project = useProjectStore((s) => s.project);
  const addChapter = useProjectStore((s) => s.addChapter);
  const removeChapter = useProjectStore((s) => s.removeChapter);
  const renameChapter = useProjectStore((s) => s.renameChapter);
  const setChapters = useProjectStore((s) => s.setChapters);

  const hasWords = project.segments.some((s) => s.words.length > 0);
  const duration = totalDuration(project);
  const chapters = useMemo(
    () => [...projectChapters(project)].sort((a, b) => a.outputTime - b.outputTime),
    [project],
  );

  const autoCount = defaultChapterCount(duration);
  const [count, setCount] = useState<number | null>(null);
  const wanted = count ?? autoCount;
  const [proposals, setProposals] = useState<Proposal[] | null>(null);

  function suggest() {
    const out = suggestChapters(project, { count: wanted });
    setProposals(out.map((c, i) => ({ ...c, key: `${i}-${c.outputTime}`, on: true })));
  }

  const chosen = (proposals ?? []).filter((p) => p.on && p.title.trim().length > 0);

  function addChosen() {
    let added = 0;
    for (const p of chosen) {
      const exists = chapters.some(
        (c) => Math.abs(c.outputTime - p.outputTime) < DUPLICATE_WITHIN_SEC,
      );
      if (exists) continue;
      addChapter(p.outputTime, p.title.trim());
      added++;
    }
    setProposals(null);
    pushUndoToast(
      added === 0 ? "Those chapters already exist" : `Added ${added} chapter${added === 1 ? "" : "s"}`,
    );
  }

  function replaceAll() {
    setChapters(chosen.map((p) => ({ title: p.title.trim(), outputTime: p.outputTime })));
    setProposals(null);
    pushUndoToast(`Replaced chapters with ${chosen.length}`);
  }

  return (
    <div className="inspector-panel-content cl-panel">
      {/* ── Auto chapters ───────────────────────────────────────────────── */}
      <section className="cl-section" aria-label="Auto chapters">
        <div className="cl-head">
          <h3 className="cl-title">
            <Sparkles className="h-4 w-4" />
            Auto chapters
          </h3>
        </div>
        <p className="inspector-hint">
          Finds where the topic changes from your transcript. Runs on this Mac in an instant, with
          no download. Review every title before adding.
        </p>

        {!hasWords ? (
          <p className="inspector-hint">Transcribe first, then chapters can be suggested.</p>
        ) : (
          <>
            <div className="ch-stepper">
              <span className="ch-stepper-label">Chapters</span>
              <button
                type="button"
                className="fr-icon-btn"
                aria-label="Fewer chapters"
                onClick={() => setCount(Math.max(1, wanted - 1))}
                disabled={wanted <= 1}
              >
                <Minus className="h-4 w-4" />
              </button>
              <output className="ch-stepper-value">{wanted}</output>
              <button
                type="button"
                className="fr-icon-btn"
                aria-label="More chapters"
                onClick={() => setCount(Math.min(MAX_COUNT, wanted + 1))}
                disabled={wanted >= MAX_COUNT}
              >
                <Plus className="h-4 w-4" />
              </button>
            </div>
            <button type="button" className="cl-primary" onClick={suggest}>
              <Sparkles className="h-4 w-4" />
              Suggest chapters
            </button>
          </>
        )}

        {proposals && proposals.length <= 1 && (
          <p className="inspector-hint">
            This video is too short to split into chapters of at least {DEFAULT_MIN_CHAPTER_SEC} s.
          </p>
        )}

        {proposals && proposals.length > 1 && (
          <>
            <ul className="ch-list" aria-label="Suggested chapters">
              {proposals.map((p) => (
                <li key={p.key} className="ch-item">
                  <input
                    type="checkbox"
                    checked={p.on}
                    aria-label={`Include chapter at ${formatTimecode(p.outputTime, { ms: false })}`}
                    onChange={(e) =>
                      setProposals((prev) =>
                        prev ? prev.map((q) => (q.key === p.key ? { ...q, on: e.target.checked } : q)) : prev,
                      )
                    }
                  />
                  <button
                    type="button"
                    className="ch-time"
                    onClick={() => seek(p.outputTime)}
                    title="Play from here"
                  >
                    <Play className="h-3 w-3" />
                    {formatTimecode(p.outputTime, { ms: false })}
                  </button>
                  <input
                    className="ch-title-input"
                    value={p.title}
                    aria-label="Chapter title"
                    onChange={(e) =>
                      setProposals((prev) =>
                        prev ? prev.map((q) => (q.key === p.key ? { ...q, title: e.target.value } : q)) : prev,
                      )
                    }
                  />
                </li>
              ))}
            </ul>
            {chosen.length < YOUTUBE_MIN_CHAPTERS && (
              <p className="inspector-hint">
                YouTube shows chapters only with {YOUTUBE_MIN_CHAPTERS} or more, starting at 0:00.
              </p>
            )}
            <button
              type="button"
              className="cl-primary"
              disabled={chosen.length === 0}
              onClick={addChosen}
            >
              Add {chosen.length} chapter{chosen.length === 1 ? "" : "s"}
            </button>
            <button
              type="button"
              className="cl-secondary"
              disabled={chosen.length === 0}
              onClick={replaceAll}
            >
              Replace existing chapters
            </button>
            <button type="button" className="cl-more" onClick={() => setProposals(null)}>
              Discard suggestions
            </button>
          </>
        )}
      </section>

      {/* ── Current chapters ────────────────────────────────────────────── */}
      <section className="cl-section" aria-label="Chapters">
        <div className="cl-head">
          <h3 className="cl-title">Your chapters</h3>
          <span className="cl-count">{chapters.length}</span>
        </div>
        {chapters.length === 0 ? (
          <p className="inspector-hint">
            None yet. Add one here from suggestions, from the Tools tab, or by selecting text in the
            transcript and choosing Start chapter.
          </p>
        ) : (
          <ul className="ch-list" aria-label="Chapters in the video">
            {chapters.map((c) => (
              <li key={c.id} className="ch-item">
                <button
                  type="button"
                  className="ch-time"
                  onClick={() => seek(c.outputTime)}
                  title="Play from here"
                >
                  <Play className="h-3 w-3" />
                  {formatTimecode(c.outputTime, { ms: false })}
                </button>
                <input
                  key={c.title}
                  className="ch-title-input"
                  defaultValue={c.title}
                  aria-label="Chapter title"
                  onBlur={(e) => {
                    const v = e.target.value.trim();
                    if (v && v !== c.title) renameChapter(c.id, v);
                    else e.target.value = c.title;
                  }}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") (e.target as HTMLInputElement).blur();
                  }}
                />
                <button
                  type="button"
                  className="fr-icon-btn"
                  aria-label={`Delete chapter ${c.title}`}
                  onClick={() => removeChapter(c.id)}
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
