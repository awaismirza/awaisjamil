import { useEffect, useMemo, useRef, useState, type KeyboardEvent } from "react";
import {
  ArrowUpRight,
  EyeOff,
  Image as ImageIcon,
  Keyboard,
  ScanSearch,
  Square,
  Trash2,
  Type,
} from "lucide-react";
import {
  ANNOTATION_COLORS,
  COLOR_NAMES,
  hasEmoji,
  MAX_ANNOTATIONS,
  sanitizeAnnotations,
  type Annotation,
  type AnnotationKind,
} from "@/lib/annotations";
import { computeTimeline, totalDuration } from "@/lib/edl";
import { buildExportOptions } from "@/lib/exportOptions";
import { findMissingMedia, importMedia, maskCoverageSheet, stripSnapshotKeyNames } from "@/lib/ipc";
import {
  fileName,
  IMAGE_EXTENSIONS,
  MAX_OVERLAYS,
  sanitizeOverlays,
  VIDEO_EXTENSIONS,
  type MediaOverlay,
  type OverlayFileInfo,
} from "@/lib/layers";
import {
  MASK_EFFECT_LABEL,
  MASK_EFFECTS,
  MASK_STRENGTH,
  maskFollowZoomOverlap,
  maskOutputSpans,
  coveragePlaces,
  duplicateSources,
  masksOnOverlayFile,
  MIN_MASK_SIZE,
  SMALL_MASK,
  MAX_MASKS,
  projectMaskSpans,
  SAFE_FOR_TEXT,
  sanitizeMasks,
  sourceTimeAt,
  type MaskEffect,
  type PrivacyMask,
} from "@/lib/masks";
import { sanitizeScene, sceneActive, sceneLayout, sceneSourceMedia } from "@/lib/scene";
import { sanitizeZoomRegions } from "@/lib/zoom";
import { useUIStore } from "@/stores/uiStore";
import { countKeyNames, keystrokeCaptions, sanitizeKeystrokes } from "@/lib/keystrokes";
import { formatTimecode } from "@/lib/timecode";
import { usePlayerStore } from "@/stores/playerStore";
import { useProjectStore } from "@/stores/projectStore";

const KIND_LABEL: Record<AnnotationKind, string> = { text: "Text", arrow: "Arrow", box: "Box" };
const KIND_ICON = { text: Type, arrow: ArrowUpRight, box: Square } as const;
const grid = { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 } as const;
const fieldLabel = { display: "flex", flexDirection: "column", gap: 4, fontSize: 12 } as const;

/**
 * A number input that commits once, on blur or Enter, so one edit is one undo
 * step (typing "120" is not three edits). Escape restores the stored value.
 */
function NumberField({
  label,
  value,
  scale = 1,
  step = 1,
  onCommit,
}: {
  label: string;
  value: number;
  /** Shown value = stored value x scale (e.g. 100 for percent). */
  scale?: number;
  step?: number;
  onCommit: (v: number) => void;
}) {
  const shown = Math.round(value * scale * 100) / 100;
  return (
    <label style={fieldLabel}>
      <span>{label}</span>
      <input
        key={shown}
        className="ch-title-input"
        type="number"
        step={step}
        defaultValue={shown}
        onBlur={(e) => {
          const v = Number(e.target.value);
          if (e.target.value !== "" && Number.isFinite(v) && v !== shown) onCommit(v / scale);
          else e.target.value = String(shown);
        }}
        onKeyDown={(e) => {
          const el = e.target as HTMLInputElement;
          if (e.key === "Enter") el.blur();
          if (e.key === "Escape") {
            el.value = String(shown);
            el.blur();
          }
        }}
      />
    </label>
  );
}

/**
 * Colour swatches as a radio group: named for screen readers, one tab stop
 * (roving tabindex), arrow keys move and select, like native radios.
 */
function Swatches({ value, onPick }: { value: string; onPick: (c: string) => void }) {
  const refs = useRef<Array<HTMLButtonElement | null>>([]);
  const index = Math.max(0, ANNOTATION_COLORS.indexOf(value as (typeof ANNOTATION_COLORS)[number]));
  const onKeyDown = (e: KeyboardEvent) => {
    const step = { ArrowRight: 1, ArrowDown: 1, ArrowLeft: -1, ArrowUp: -1 }[e.key];
    if (!step) return;
    e.preventDefault();
    const n = ANNOTATION_COLORS.length;
    const next = (index + step + n) % n;
    onPick(ANNOTATION_COLORS[next]!);
    refs.current[next]?.focus();
  };
  return (
    <div
      role="radiogroup"
      aria-label="Colour"
      style={{ display: "flex", gap: 6 }}
      onKeyDown={onKeyDown}
    >
      {ANNOTATION_COLORS.map((c, i) => (
        <button
          key={c}
          ref={(el) => {
            refs.current[i] = el;
          }}
          type="button"
          role="radio"
          aria-checked={value === c}
          aria-label={COLOR_NAMES[c]}
          title={COLOR_NAMES[c]}
          tabIndex={i === index ? 0 : -1}
          className="fr-icon-btn"
          style={{
            background: c,
            width: 24,
            height: 24,
            borderRadius: 999,
            // White and black need a ring that contrasts with them on any theme.
            boxShadow: c === "#ffffff" ? "inset 0 0 0 1px #6b7280" : undefined,
            outline: value === c ? "2px solid hsl(var(--ring))" : "1px solid hsl(var(--border))",
            outlineOffset: 2,
          }}
          onClick={() => value !== c && onPick(c)}
        />
      ))}
    </div>
  );
}

function Editor({ a }: { a: Annotation }) {
  const update = useProjectStore((s) => s.updateAnnotation);
  const set = (patch: Partial<Omit<Annotation, "id">>) => update(a.id, patch);
  const [emojiNote, setEmojiNote] = useState(false);
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 10 }} aria-label="Edit annotation">
      {a.kind === "text" && (
        <label style={fieldLabel}>
          <span>Text</span>
          <textarea
            key={a.text}
            className="ch-title-input"
            style={{ height: 64, padding: 8, resize: "vertical" }}
            defaultValue={a.text}
            onBlur={(e) => {
              setEmojiNote(hasEmoji(e.target.value));
              if (e.target.value !== a.text && e.target.value.trim()) set({ text: e.target.value });
              else e.target.value = a.text ?? "";
            }}
          />
        </label>
      )}
      {a.kind === "text" && emojiNote && (
        <p className="inspector-hint" role="status">
          Emoji were removed: the export cannot draw colour emoji. Symbols such as ⌘ ✓ © and
          Chinese, Japanese or Korean text are fine.
        </p>
      )}
      <div style={grid}>
        <NumberField
          label="Start (s)"
          value={a.start}
          step={0.1}
          onCommit={(v) => set({ start: v })}
        />
        <NumberField label="End (s)" value={a.end} step={0.1} onCommit={(v) => set({ end: v })} />
        <NumberField
          label={a.kind === "arrow" ? "Tail X (%)" : "X (%)"}
          value={a.x}
          scale={100}
          onCommit={(v) => set({ x: v })}
        />
        <NumberField
          label={a.kind === "arrow" ? "Tail Y (%)" : "Y (%)"}
          value={a.y}
          scale={100}
          onCommit={(v) => set({ y: v })}
        />
        {a.kind !== "text" && (
          <>
            <NumberField
              label={a.kind === "arrow" ? "Head X (%)" : "Width (%)"}
              value={a.kind === "arrow" ? a.x + a.w : a.w}
              scale={100}
              onCommit={(v) => set({ w: a.kind === "arrow" ? v - a.x : v })}
            />
            <NumberField
              label={a.kind === "arrow" ? "Head Y (%)" : "Height (%)"}
              value={a.kind === "arrow" ? a.y + a.h : a.h}
              scale={100}
              onCommit={(v) => set({ h: a.kind === "arrow" ? v - a.y : v })}
            />
          </>
        )}
        {a.kind === "text" ? (
          <NumberField
            label="Size (px @1080)"
            value={a.fontSize}
            onCommit={(v) => set({ fontSize: v })}
          />
        ) : (
          <NumberField
            label="Line (px @1080)"
            value={a.stroke}
            onCommit={(v) => set({ stroke: v })}
          />
        )}
        <span />
        <NumberField
          label="Fade in (ms)"
          value={a.fadeInMs ?? 0}
          step={50}
          onCommit={(v) => set({ fadeInMs: v })}
        />
        <NumberField
          label="Fade out (ms)"
          value={a.fadeOutMs ?? 0}
          step={50}
          onCommit={(v) => set({ fadeOutMs: v })}
        />
      </div>
      <Swatches value={a.color} onPick={(color) => set({ color })} />
      {a.kind === "box" && (
        <label className="st-toggle">
          <input
            type="checkbox"
            checked={!!a.filled}
            onChange={(e) => set({ filled: e.target.checked })}
          />
          <span className="st-row-title">Filled</span>
        </label>
      )}
      <label className="st-toggle">
        <input
          type="checkbox"
          checked={!!a.followZoom}
          onChange={(e) => set({ followZoom: e.target.checked })}
        />
        <span className="st-row-text">
          <span className="st-row-title">Follow zoom</span>
          <span className="st-row-hint">
            Pin it to the picture so it zooms with it. Off: it stays fixed on screen. Position is
            then relative to the picture instead of the whole frame.
          </span>
        </span>
      </label>
    </div>
  );
}

/** Pick an overlay file and read its size, length, audio and checksum (streamed, local). */
async function pickOverlayFile(): Promise<OverlayFileInfo | null> {
  const { open } = await import("@tauri-apps/plugin-dialog");
  const picked = await open({
    multiple: false,
    filters: [
      { name: "Images and videos", extensions: [...IMAGE_EXTENSIONS, ...VIDEO_EXTENSIONS] },
    ],
  });
  if (typeof picked !== "string") return null;
  const media = await useUIStore
    .getState()
    .withProcessingEdit("Reading overlay file…", () => importMedia(picked));
  return {
    path: picked,
    sha256: media.sha256,
    width: media.width,
    height: media.height,
    duration: media.duration,
    hasAudio: media.audioSampleRate > 0,
  };
}

function OverlayEditor({ o, missing }: { o: MediaOverlay; missing: boolean }) {
  const update = useProjectStore((s) => s.updateOverlay);
  const set = (patch: Partial<Omit<MediaOverlay, "id" | "kind" | "path">>) => update(o.id, patch);
  const [relinkNote, setRelinkNote] = useState<string | null>(null);
  const project = useProjectStore((s) => s.project);
  const masked = masksOnOverlayFile(project, o).length;

  async function relink() {
    setRelinkNote(null);
    try {
      const info = await pickOverlayFile();
      if (!info) return;
      if (o.sha256 && info.sha256 !== o.sha256) {
        setRelinkNote(
          "That is a different file: its contents do not match the one you added. Pick the moved original, or delete this overlay and add the new file.",
        );
        return;
      }
      const project = useProjectStore.getState().project;
      if (!useProjectStore.getState().relinkOverlayPath(project.id, o.path, info))
        setRelinkNote("The project changed while the file was checked. Try again.");
      else window.dispatchEvent(new CustomEvent("yusafcut:overlays-relinked"));
    } catch (err) {
      setRelinkNote(`That file could not be used: ${String(err)}`);
    }
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 10 }} aria-label="Edit overlay">
      {missing && (
        <div role="alert" className="inspector-hint" style={{ color: "hsl(var(--destructive))" }}>
          <p>
            The file is missing: {o.path}. The preview shows a placeholder and export stops until
            you relink it.
          </p>
          <button type="button" className="cl-mini" onClick={() => void relink()}>
            Relink…
          </button>
        </div>
      )}
      {masked > 0 && (
        <p className="inspector-hint" role="note" style={{ color: "hsl(var(--filler))" }}>
          This file is masked footage: its {masked} privacy mask{masked === 1 ? " is" : "s are"}{" "}
          applied to this overlay in the export. The preview shows the overlay unmasked.
        </p>
      )}
      {relinkNote && (
        <p className="inspector-hint" role="status">
          {relinkNote}
        </p>
      )}
      <div style={grid}>
        <NumberField
          label="Start (s)"
          value={o.start}
          step={0.1}
          onCommit={(v) => set({ start: v })}
        />
        <NumberField label="End (s)" value={o.end} step={0.1} onCommit={(v) => set({ end: v })} />
        <NumberField label="X (%)" value={o.x} scale={100} onCommit={(v) => set({ x: v })} />
        <NumberField label="Y (%)" value={o.y} scale={100} onCommit={(v) => set({ y: v })} />
        <NumberField label="Width (%)" value={o.w} scale={100} onCommit={(v) => set({ w: v })} />
        <NumberField label="Height (%)" value={o.h} scale={100} onCommit={(v) => set({ h: v })} />
        <NumberField
          label="Opacity (%)"
          value={o.opacity}
          scale={100}
          onCommit={(v) => set({ opacity: v })}
        />
        <NumberField
          label="Rotation (°)"
          value={o.rotation ?? 0}
          onCommit={(v) => set({ rotation: v })}
        />
        <NumberField
          label="Corner radius (px @1080)"
          value={o.radius ?? 0}
          onCommit={(v) => set({ radius: v })}
        />
        <span />
        <NumberField
          label="Fade in (ms)"
          value={o.fadeInMs ?? 0}
          step={50}
          onCommit={(v) => set({ fadeInMs: v })}
        />
        <NumberField
          label="Fade out (ms)"
          value={o.fadeOutMs ?? 0}
          step={50}
          onCommit={(v) => set({ fadeOutMs: v })}
        />
        {o.kind === "video" && (
          <NumberField
            label="Start in file (s)"
            value={o.trimIn ?? 0}
            step={0.1}
            onCommit={(v) => set({ trimIn: v })}
          />
        )}
        {o.kind === "video" && o.includeAudio && (
          <NumberField
            label="Gain (dB)"
            value={o.gainDb ?? 0}
            onCommit={(v) => set({ gainDb: v })}
          />
        )}
      </div>
      {o.kind === "video" && (
        <label className="st-toggle">
          <input
            type="checkbox"
            checked={!!o.includeAudio}
            disabled={!o.hasAudio}
            onChange={(e) => set({ includeAudio: e.target.checked })}
          />
          <span className="st-row-text">
            <span className="st-row-title">Include its audio</span>
            <span className="st-row-hint">
              {o.hasAudio
                ? "Off by default. On: mixed into the export like a music track (never ducked)."
                : "This file has no audio."}
            </span>
          </span>
        </label>
      )}
      <label className="st-toggle">
        <input
          type="checkbox"
          checked={!!o.followZoom}
          onChange={(e) => set({ followZoom: e.target.checked })}
        />
        <span className="st-row-text">
          <span className="st-row-title">Follow zoom</span>
          <span className="st-row-hint">
            Pin it to the picture so it zooms with it. Off: it stays fixed on screen, below
            annotations, captions and key caps.
          </span>
        </span>
      </label>
    </div>
  );
}

function MediaOverlaysSection({ total, frameAspect }: { total: number; frameAspect: number }) {
  const project = useProjectStore((s) => s.project);
  const addOverlay = useProjectStore((s) => s.addOverlay);
  const removeOverlay = useProjectStore((s) => s.removeOverlay);
  const pushToast = useUIStore((s) => s.pushToast);
  const [selected, setSelected] = useState<string | null>(null);
  const [missing, setMissing] = useState<ReadonlySet<string>>(new Set());
  const [recheck, setRecheck] = useState(0);
  const list = useMemo(() => sanitizeOverlays(project.overlays, total), [project.overlays, total]);
  const paths = useMemo(() => [...new Set(list.map((o) => o.path))].sort().join("\n"), [list]);
  useEffect(() => {
    const onRelinked = () => setRecheck((n) => n + 1);
    window.addEventListener("yusafcut:overlays-relinked", onRelinked);
    return () => window.removeEventListener("yusafcut:overlays-relinked", onRelinked);
  }, []);
  useEffect(() => {
    let live = true;
    const all = paths ? paths.split("\n") : [];
    if (all.length === 0) {
      setMissing(new Set());
      return;
    }
    findMissingMedia(all)
      .then((gone) => live && setMissing(new Set(gone)))
      .catch(() => {});
    return () => {
      live = false;
    };
  }, [paths, recheck]);
  const current = list.find((o) => o.id === selected) ?? null;
  const full = list.length >= MAX_OVERLAYS;

  async function add() {
    try {
      const info = await pickOverlayFile();
      if (!info) return;
      const id = addOverlay(info, usePlayerStore.getState().currentTime, frameAspect);
      if (id) setSelected(id);
      else pushToast({ title: "That file cannot be an overlay", variant: "destructive" });
    } catch (err) {
      pushToast({
        title: "Could not add the overlay",
        description: String(err),
        variant: "destructive",
      });
    }
  }

  return (
    <section className="cl-section" aria-label="Images and videos">
      <div className="cl-head">
        <h3 className="cl-title">
          <ImageIcon className="h-4 w-4" />
          Images and videos
        </h3>
        <span className="cl-count">{list.length}</span>
      </div>
      {total <= 0 ? (
        <p className="inspector-hint">Open a video first.</p>
      ) : (
        <>
          <p className="inspector-hint">
            PNG, JPEG, GIF, MP4 or MOV (transparency kept), added at the playhead. Files are used
            from where they are on this Mac: nothing is copied or uploaded.
          </p>
          <button type="button" className="cl-mini" disabled={full} onClick={() => void add()}>
            Add image or video…
          </button>
          {full && (
            <p className="inspector-hint" role="status">
              Limit reached: a project can have at most {MAX_OVERLAYS} overlays.
            </p>
          )}
        </>
      )}
      {list.length > 0 && (
        <ul className="ch-list" aria-label="Overlays in the video">
          {list.map((o) => (
            <li key={o.id} className="ch-item">
              <button
                type="button"
                className="ch-time"
                aria-pressed={o.id === selected}
                style={o.id === selected ? { outline: "2px solid hsl(var(--ring))" } : undefined}
                onClick={() => {
                  setSelected(o.id === selected ? null : o.id);
                  window.dispatchEvent(
                    new CustomEvent("yusafcut:seek-output", { detail: { time: o.start } }),
                  );
                }}
              >
                {formatTimecode(o.start, { ms: false })}
              </button>
              <span
                style={{
                  flex: 1,
                  minWidth: 0,
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                  whiteSpace: "nowrap",
                  fontSize: 13,
                }}
              >
                {missing.has(o.path) && (
                  <span style={{ color: "hsl(var(--destructive))", fontWeight: 600 }}>
                    Missing ·{" "}
                  </span>
                )}
                {fileName(o.path)}
              </span>
              <button
                type="button"
                className="fr-icon-btn"
                aria-label={`Delete overlay ${fileName(o.path)} at ${formatTimecode(o.start, { ms: false })}`}
                onClick={() => removeOverlay(o.id)}
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </li>
          ))}
        </ul>
      )}
      {current && (
        <OverlayEditor key={current.id} o={current} missing={missing.has(current.path)} />
      )}
    </section>
  );
}

const STRENGTH_LABEL: Record<MaskEffect, string> = {
  blur: "Blur (px @1080)",
  pixelate: "Block size (px @1080)",
  solid: "",
  dim: "Dim surroundings (%)",
};

function MaskEditor({ m }: { m: PrivacyMask }) {
  const project = useProjectStore((s) => s.project);
  const update = useProjectStore((s) => s.updateMask);
  const set = (patch: Partial<Omit<PrivacyMask, "id">>) => update(m.id, patch);
  const [sheet, setSheet] = useState<{ url: string; label: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [note, setNote] = useState<string | null>(null);
  const total = totalDuration(project);
  const spans = useMemo(() => projectMaskSpans(project, m), [project, m]);
  const first = spans[0];
  const media = project.media[m.mediaId];
  const followOverlap = maskFollowZoomOverlap(
    spans,
    sanitizeZoomRegions(project.zoomRegions, total),
  );
  const safe = SAFE_FOR_TEXT[m.effect];
  const weak = safe !== undefined && m.strength < safe;
  useEffect(() => () => void (sheet && globalThis.URL.revokeObjectURL(sheet.url)), [sheet]);

  const copies = duplicateSources(project.media, m.mediaId);
  /** A size under 1 % is refused with a message, never turned into a 1 % box. */
  function setSize(patch: { w?: number; h?: number }) {
    if ((patch.w ?? 1) < MIN_MASK_SIZE || (patch.h ?? 1) < MIN_MASK_SIZE) {
      setNote("A mask must be at least 1 % wide and high. The size was not changed.");
      return;
    }
    setNote(null);
    set(patch);
  }

  /** Edit by output time of the first occurrence: mapped back to source time. */
  function setOutput(which: "start" | "end", v: number) {
    const s = sourceTimeAt(project, m.mediaId, v, which === "end");
    if (s === null) {
      setNote("That time shows a different source: a mask stays on its own source footage.");
      return;
    }
    setNote(null);
    set(which === "start" ? { srcStart: s } : { srcEnd: s });
  }

  async function checkCoverage() {
    setBusy(true);
    setError(null);
    try {
      const opts = buildExportOptions(
        project,
        { resolution: "original", customWidth: 1920, customHeight: 1080, codec: "auto" },
        "/coverage.mp4",
      );
      const bytes = await maskCoverageSheet(opts, m.id);
      const url = globalThis.URL.createObjectURL(
        new globalThis.Blob([bytes], { type: "image/png" }),
      );
      setSheet({
        url,
        label: `Coverage check: sampled ${coveragePlaces(spans.length)} of ${spans.length} place${spans.length === 1 ? "" : "s"} this mask is on screen (frames just before, inside and just after each), rendered like the export`,
      });
    } catch (err) {
      setError(String(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 10 }} aria-label="Edit mask">
      <p className="inspector-hint" role="status">
        Source: {media ? fileName(media.path) : "missing source"},{" "}
        {formatTimecode(m.srcStart, { ms: true })}–{formatTimecode(m.srcEnd, { ms: true })}.{" "}
        {spans.length === 0
          ? "Not on the timeline now (that footage is cut); it is masked again wherever it comes back."
          : `On screen ${spans.length} time${spans.length === 1 ? "" : "s"}: every copy of this footage is masked.`}
      </p>
      {copies.length > 0 && (
        <p className="inspector-hint" role="note">
          This file is also imported as {copies.length} other source
          {copies.length === 1 ? "" : "s"} (same path or checksum): those clips are masked too.
        </p>
      )}
      {note && (
        <p className="inspector-hint" role="status">
          {note}
        </p>
      )}
      {(m.w < SMALL_MASK || m.h < SMALL_MASK) && (
        <p className="inspector-hint" role="alert" style={{ color: "hsl(var(--destructive))" }}>
          This mask is under 3 % of the picture in one direction: it hides almost nothing.
        </p>
      )}
      <div style={grid}>
        {first && (
          <>
            <NumberField
              label="Start (s, first time on screen)"
              value={first[0]}
              step={0.1}
              onCommit={(v) => setOutput("start", v)}
            />
            <NumberField
              label="End (s, first time on screen)"
              value={first[1]}
              step={0.1}
              onCommit={(v) => setOutput("end", v)}
            />
          </>
        )}
        <NumberField
          label="Source start (s)"
          value={m.srcStart}
          step={0.1}
          onCommit={(v) => set({ srcStart: v })}
        />
        <NumberField
          label="Source end (s)"
          value={m.srcEnd}
          step={0.1}
          onCommit={(v) => set({ srcEnd: v })}
        />
        <NumberField
          label="X (% of source)"
          value={m.x}
          scale={100}
          onCommit={(v) => set({ x: v })}
        />
        <NumberField
          label="Y (% of source)"
          value={m.y}
          scale={100}
          onCommit={(v) => set({ y: v })}
        />
        <NumberField
          label="Width (%)"
          value={m.w}
          scale={100}
          onCommit={(v) => setSize({ w: v })}
        />
        <NumberField
          label="Height (%)"
          value={m.h}
          scale={100}
          onCommit={(v) => setSize({ h: v })}
        />
        <label style={fieldLabel}>
          <span>Effect</span>
          <select
            className="ch-title-input"
            value={m.effect}
            onChange={(e) => {
              const effect = e.target.value as MaskEffect;
              set({ effect, strength: MASK_STRENGTH[effect][2] });
            }}
          >
            {MASK_EFFECTS.map((e) => (
              <option key={e} value={e}>
                {MASK_EFFECT_LABEL[e]}
              </option>
            ))}
          </select>
        </label>
        <label style={fieldLabel}>
          <span>Shape</span>
          <select
            className="ch-title-input"
            value={m.shape}
            onChange={(e) => set({ shape: e.target.value as PrivacyMask["shape"] })}
          >
            <option value="rect">Rectangle</option>
            <option value="ellipse">Ellipse</option>
          </select>
        </label>
        {m.effect !== "solid" && (
          <NumberField
            label={STRENGTH_LABEL[m.effect]}
            value={m.strength}
            onCommit={(v) => set({ strength: v })}
          />
        )}
      </div>
      {m.effect === "solid" && <Swatches value={m.color} onPick={(color) => set({ color })} />}
      {weak && (
        <p className="inspector-hint" role="alert" style={{ color: "hsl(var(--destructive))" }}>
          Below the safe-for-text level ({safe}): small text or faces may stay recognisable. Raise
          it, or use a solid fill.
        </p>
      )}
      {m.effect === "blur" && !weak && (
        <p className="inspector-hint">
          Strong blur ({m.strength}). For text, a solid fill is still the only effect that cannot be
          partly reversed.
        </p>
      )}
      {m.effect === "dim" && (
        <p className="inspector-hint">Dim surroundings highlights the region: it hides nothing.</p>
      )}
      {followOverlap && (
        <p className="inspector-hint" role="status" style={{ color: "hsl(var(--filler))" }}>
          Warning: this mask overlaps a zoom that follows the cursor. The mask stays on the same
          part of the recording; if what it hides moves while the cursor moves, it moves out from
          under the mask. Check coverage.
        </p>
      )}
      <button
        type="button"
        className="cl-mini"
        disabled={busy || spans.length === 0}
        aria-busy={busy}
        onClick={() => void checkCoverage()}
      >
        <ScanSearch className="mr-1 inline h-3.5 w-3.5" />
        {busy ? "Rendering frames…" : "Check coverage"}
      </button>
      {error && (
        <p className="inspector-hint" role="alert">
          {error}
        </p>
      )}
      {sheet && (
        <figure style={{ margin: 0 }}>
          <img src={sheet.url} alt={sheet.label} style={{ width: "100%", borderRadius: 4 }} />
          <figcaption className="inspector-hint">
            Frames just before, at the start, middle and end, and just after every place this mask
            is on screen (transitions included), rendered locally like the export. Look at every
            frame: the region must stay covered.
          </figcaption>
        </figure>
      )}
    </div>
  );
}

function MasksSection({ total }: { total: number }) {
  const project = useProjectStore((s) => s.project);
  const addMask = useProjectStore((s) => s.addMask);
  const removeMask = useProjectStore((s) => s.removeMask);
  const previewMasks = useUIStore((s) => s.previewMasks);
  const setPreviewMasks = useUIStore((s) => s.setPreviewMasks);
  const [selected, setSelected] = useState<string | null>(null);
  const list = useMemo(() => {
    const tl = computeTimeline(project);
    return sanitizeMasks(project.masks).map((m) => ({
      m,
      spans: maskOutputSpans(tl, m, project.media),
    }));
  }, [project]);
  const current = list.find((v) => v.m.id === selected)?.m ?? null;
  const full = list.length >= MAX_MASKS;
  return (
    <section className="cl-section" aria-label="Privacy masks">
      <div className="cl-head">
        <h3 className="cl-title">
          <EyeOff className="h-4 w-4" />
          Privacy masks
        </h3>
        <span className="cl-count">{list.length}</span>
      </div>
      <p className="inspector-hint" role="note" style={{ color: "hsl(var(--filler))" }}>
        Static region: a mask covers a fixed part of the recording and does not follow moving
        content. It belongs to the source footage, so every copy of that footage on the timeline is
        masked, before zoom, crop, transitions, overlays, annotations and captions. Masks hide
        pixels only: they do not redact the transcript, captions, SRT / VTT files, chapters or
        audio.
      </p>
      {total <= 0 ? (
        <p className="inspector-hint">Open a video first.</p>
      ) : (
        <>
          <button
            type="button"
            className="cl-mini"
            disabled={full}
            onClick={() => {
              const id = addMask(usePlayerStore.getState().currentTime);
              if (id) setSelected(id);
            }}
          >
            Add mask
          </button>
          {full && (
            <p className="inspector-hint" role="status">
              Limit reached: a project can have at most {MAX_MASKS} masks.
            </p>
          )}
        </>
      )}
      <label className="st-toggle">
        <input
          type="checkbox"
          checked={previewMasks}
          onChange={(e) => setPreviewMasks(e.target.checked)}
        />
        <span className="st-row-text">
          <span className="st-row-title">Show masks in preview</span>
          <span className="st-row-hint">
            Export (every format, range and GIF) always applies them. Off: the preview shows the
            unmasked source. The preview proxy files and the source media on disk stay unmasked, and
            FCPXML export does not carry masks.
          </span>
        </span>
      </label>
      {list.length > 0 && (
        <ul className="ch-list" aria-label="Masks in the video">
          {list.map(({ m, spans }) => {
            const at = spans[0]?.[0];
            const when = at === undefined ? "not on timeline" : formatTimecode(at, { ms: false });
            return (
              <li key={m.id} className="ch-item">
                <button
                  type="button"
                  className="ch-time"
                  aria-pressed={m.id === selected}
                  style={m.id === selected ? { outline: "2px solid hsl(var(--ring))" } : undefined}
                  onClick={() => {
                    setSelected(m.id === selected ? null : m.id);
                    if (at !== undefined)
                      window.dispatchEvent(
                        new CustomEvent("yusafcut:seek-output", { detail: { time: at } }),
                      );
                  }}
                >
                  {when}
                </button>
                <span style={{ flex: 1, minWidth: 0, fontSize: 13 }}>
                  {MASK_EFFECT_LABEL[m.effect]} · {m.shape === "ellipse" ? "ellipse" : "rectangle"}
                  {spans.length > 1 ? ` · ×${spans.length}` : ""}
                </span>
                <button
                  type="button"
                  className="fr-icon-btn"
                  aria-label={`Delete ${MASK_EFFECT_LABEL[m.effect].toLowerCase()} mask at ${when}`}
                  onClick={() => removeMask(m.id)}
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </li>
            );
          })}
        </ul>
      )}
      {current && <MaskEditor key={current.id} m={current} />}
    </section>
  );
}

export function OverlaysPanel() {
  const project = useProjectStore((s) => s.project);
  const addAnnotation = useProjectStore((s) => s.addAnnotation);
  const removeAnnotation = useProjectStore((s) => s.removeAnnotation);
  const setKeystrokes = useProjectStore((s) => s.setKeystrokes);
  const stripKeyNames = useProjectStore((s) => s.stripKeyNames);
  const filePath = useProjectStore((s) => s.filePath);
  const [stripNote, setStripNote] = useState<string | null>(null);
  const [selected, setSelected] = useState<string | null>(null);

  const total = totalDuration(project);
  const list = useMemo(
    () => sanitizeAnnotations(project.annotations, total),
    [project.annotations, total],
  );
  const current = list.find((a) => a.id === selected) ?? null;
  const full = list.length >= MAX_ANNOTATIONS;
  const keys = sanitizeKeystrokes(project.keystrokes);
  const hasKeyEvents = Object.values(project.cursor?.tracks ?? {}).some((t) =>
    t.events.some((e) => e.type === "key"),
  );
  const namedKeys = useMemo(() => countKeyNames(project), [project]);
  const shown = useMemo(() => {
    const settings = sanitizeKeystrokes(project.keystrokes);
    return settings.enabled ? keystrokeCaptions(project, settings).length : 0;
  }, [project]);

  const media = sceneSourceMedia(project);
  const scene = sanitizeScene(project.scene);
  const frameAspect = !media
    ? 16 / 9
    : sceneActive(scene)
      ? (() => {
          const l = sceneLayout(scene, { w: media.width, h: media.height });
          return l.canvasW / l.canvasH;
        })()
      : media.width / Math.max(1, media.height);

  function add(kind: AnnotationKind) {
    const id = addAnnotation(kind, usePlayerStore.getState().currentTime);
    if (id) setSelected(id);
  }

  return (
    <div className="inspector-panel-content cl-panel">
      <section className="cl-section" aria-label="Annotations">
        <div className="cl-head">
          <h3 className="cl-title">Annotations</h3>
          <span className="cl-count">{list.length}</span>
        </div>
        {total <= 0 ? (
          <p className="inspector-hint">Open a video first.</p>
        ) : (
          <>
            <p className="inspector-hint">
              Added at the playhead for 3 s. They follow your cuts, show in the preview and are
              drawn into the export.
            </p>
            <div style={{ display: "flex", gap: 6 }}>
              {(["text", "arrow", "box"] as const).map((k) => {
                const Icon = KIND_ICON[k];
                return (
                  <button
                    key={k}
                    type="button"
                    className="cl-mini"
                    disabled={full}
                    onClick={() => add(k)}
                  >
                    <Icon className="mr-1 inline h-3.5 w-3.5" />
                    Add {KIND_LABEL[k].toLowerCase()}
                  </button>
                );
              })}
            </div>
            {full && (
              <p className="inspector-hint" role="status">
                Limit reached: a project can have at most {MAX_ANNOTATIONS} annotations. Delete one
                to add another.
              </p>
            )}
          </>
        )}
        {list.length > 0 && (
          <ul className="ch-list" aria-label="Annotations in the video">
            {list.map((a) => (
              <li key={a.id} className="ch-item">
                <button
                  type="button"
                  className="ch-time"
                  aria-pressed={a.id === selected}
                  style={a.id === selected ? { outline: "2px solid hsl(var(--ring))" } : undefined}
                  onClick={() => {
                    setSelected(a.id === selected ? null : a.id);
                    window.dispatchEvent(
                      new CustomEvent("yusafcut:seek-output", { detail: { time: a.start } }),
                    );
                  }}
                >
                  {formatTimecode(a.start, { ms: false })}
                </button>
                <span
                  style={{
                    flex: 1,
                    minWidth: 0,
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                    whiteSpace: "nowrap",
                    fontSize: 13,
                  }}
                >
                  {KIND_LABEL[a.kind]}
                  {a.kind === "text" ? `: ${a.text}` : ""}
                </span>
                <button
                  type="button"
                  className="fr-icon-btn"
                  aria-label={`Delete ${KIND_LABEL[a.kind].toLowerCase()} at ${formatTimecode(a.start, { ms: false })}`}
                  onClick={() => removeAnnotation(a.id)}
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </li>
            ))}
          </ul>
        )}
        {current && <Editor key={current.id} a={current} />}
      </section>

      <MediaOverlaysSection total={total} frameAspect={frameAspect} />
      <MasksSection total={total} />

      <section className="cl-section" aria-label="Keystroke overlay">
        <div className="cl-head">
          <h3 className="cl-title">
            <Keyboard className="h-4 w-4" />
            Keystrokes
          </h3>
        </div>
        <label className="st-toggle">
          <input
            type="checkbox"
            checked={keys.enabled}
            onChange={(e) => setKeystrokes({ enabled: e.target.checked })}
          />
          <span className="st-row-text">
            <span className="st-row-title">Show keyboard shortcuts</span>
            <span className="st-row-hint">
              Off by default. Recordings made without “Record key names” log only which modifier
              keys were held (⌘ ⌃ ⌥ ⇧), so a shortcut shows as “⌘ key”. With “Record key names” on
              in the recorder, shortcuts show their key (“⌘ K”) and keys like the arrows show by
              name. In Screen and Area recordings, keys pressed in any app were captured, not just
              the one on screen. Recordings that also used “Also record all characters” spell out
              what you typed.
            </span>
          </span>
        </label>
        {keys.enabled && (
          <div
            role="radiogroup"
            aria-label="Which presses to show"
            style={{ display: "flex", flexDirection: "column", gap: 6 }}
          >
            <label className="st-toggle">
              <input
                type="radio"
                name="keystroke-mode"
                checked={keys.mode === "shortcuts"}
                onChange={() => setKeystrokes({ mode: "shortcuts" })}
              />
              <span className="st-row-title">Shortcuts only (with ⌘, ⌃ or ⌥)</span>
            </label>
            <label className="st-toggle">
              <input
                type="radio"
                name="keystroke-mode"
                checked={keys.mode === "all"}
                onChange={() => setKeystrokes({ mode: "all" })}
              />
              <span className="st-row-title">All key presses (shows “Typing”)</span>
            </label>
            {keys.mode === "all" && (
              <p className="inspector-hint" role="note" style={{ color: "hsl(var(--filler))" }}>
                Privacy: this reveals when and for how long you typed, and with “Also record all
                characters” in the recorder it shows exactly what you typed. Password fields are
                normally hidden or missing because macOS withholds those presses (a press may show
                as “Typing (hidden)”), but Terminal or iTerm sudo and ssh prompts and many Electron
                or web fields are not protected unless Secure Keyboard Entry is on. Check the
                overlay before sharing.
              </p>
            )}
            <p className="inspector-hint">
              {hasKeyEvents
                ? `${shown} caption${shown === 1 ? "" : "s"} on the timeline.`
                : "No key presses in this project. They come from recordings made with the native recorder when Input Monitoring is allowed."}
            </p>
          </div>
        )}
        {namedKeys > 0 && (
          <div>
            <button
              type="button"
              className="cl-mini"
              onClick={() => {
                if (
                  !window.confirm(
                    `Remove the recorded key names from this project (${namedKeys} key press${namedKeys === 1 ? "" : "es"})? Shortcuts will show as “⌘ key”. Undo brings the names back in the editor, but snapshot copies are cleaned for good.`,
                  )
                )
                  return;
                stripKeyNames();
                setStripNote("Key names removed from the project.");
                if (filePath) {
                  void stripSnapshotKeyNames(filePath)
                    .then(() =>
                      setStripNote("Key names removed from the project and its snapshots."),
                    )
                    .catch(() =>
                      setStripNote("Removed from the project; snapshots could not be updated."),
                    );
                }
              }}
            >
              Strip key names…
            </button>
            <p className="inspector-hint">
              Removes recorded key names and secure-input markers from this project and its
              snapshots. The original recording folder’s events.jsonl is not changed.
            </p>
          </div>
        )}
        {stripNote && (
          <p className="inspector-hint" role="status">
            {stripNote}
          </p>
        )}
      </section>
    </div>
  );
}
