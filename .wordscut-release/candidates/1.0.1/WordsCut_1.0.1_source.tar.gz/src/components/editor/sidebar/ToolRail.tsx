import { useEditorUiStore } from "@/stores/editorUiStore";
import { PANELS, type PanelDef } from "./registry";

export function ToolRail() {
  const activePanel = useEditorUiStore((s) => s.activePanel);
  const setActivePanel = useEditorUiStore((s) => s.setActivePanel);

  const button = (p: PanelDef) => {
    const Icon = p.icon;
    const active = p.id === activePanel;
    return (
      <button
        key={p.id}
        type="button"
        className={`tool-rail-btn${active ? " is-active" : ""}`}
        title={p.label}
        aria-label={p.label}
        aria-pressed={active}
        onClick={() => setActivePanel(p.id)}
      >
        <Icon className="h-5 w-5" />
        <span className="tool-rail-label">{p.railLabel ?? p.label}</span>
      </button>
    );
  };

  return (
    <div className="tool-rail" role="toolbar" aria-label="Editor tools">
      {PANELS.filter((p) => p.placement !== "bottom").map(button)}
      <div className="tool-rail-spacer" />
      {PANELS.filter((p) => p.placement === "bottom").map(button)}
    </div>
  );
}
