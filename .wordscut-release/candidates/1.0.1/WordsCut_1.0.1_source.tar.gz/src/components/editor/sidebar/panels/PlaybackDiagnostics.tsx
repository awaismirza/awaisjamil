import { useState } from "react";
import {
  diagnosticsEnabled,
  diagnosticsReport,
  resetDiagnostics,
  sampleMemory,
  setDiagnosticsEnabled,
} from "@/lib/playbackDiagnostics";
export function PlaybackDiagnostics() {
  const [enabled, setEnabled] = useState(diagnosticsEnabled);
  const [report, setReport] = useState("");
  return (
    <section className="cl-section" aria-label="Playback diagnostics">
      <h3 className="cl-title">Playback diagnostics</h3>
      <p className="inspector-hint">
        Opt-in measurements stay in memory on this Mac. Run playback and seeks, then show the
        report. Unsupported browser measurements are marked unavailable.
      </p>
      <label className="st-toggle">
        <input
          type="checkbox"
          checked={enabled}
          onChange={(e) => {
            setEnabled(e.target.checked);
            setDiagnosticsEnabled(e.target.checked);
          }}
        />
        <span>Measure playback locally</span>
      </label>
      <button
        className="cl-secondary"
        onClick={() => {
          sampleMemory();
          setReport(JSON.stringify(diagnosticsReport(), null, 2));
        }}
      >
        Show performance report
      </button>
      <button
        className="cl-more"
        onClick={() => {
          resetDiagnostics();
          setReport("");
        }}
      >
        Clear measurements
      </button>
      {report && (
        <textarea
          aria-label="Local performance report"
          readOnly
          rows={14}
          value={report}
          style={{ width: "100%", fontFamily: "monospace", fontSize: 11 }}
        />
      )}
    </section>
  );
}
