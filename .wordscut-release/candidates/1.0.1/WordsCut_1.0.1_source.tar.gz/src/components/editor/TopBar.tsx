import { useCallback, useState } from "react";
import {
  Bot,
  FilePlus2,
  FolderOpen,
  History,
  Menu,
  Power,
  Redo2,
  Save,
  Scissors,
  Undo2,
  Upload,
  Video,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { AgentConnectDialog } from "@/components/Agent/AgentConnectDialog";
import { totalDuration } from "@/lib/edl";
import { getRecentProjects } from "@/lib/recentProjects";
import type { Project } from "@/lib/edl";
import { useProjectStore, useTemporalProjectStore } from "@/stores/projectStore";
import { useShortcutLabel } from "@/hooks/useShortcutLabel";
import { useRecordingStore } from "@/stores/recordingStore";
import { useEditorShortcutLabel } from "@/hooks/useShortcutLabel";

function dispatch(name: string, detail?: unknown) {
  window.dispatchEvent(new CustomEvent(name, detail === undefined ? undefined : { detail }));
}

/** Time cut from the original media, as seconds and a share of the original. */
function cutSummary(project: Project): { removedSec: number; percent: number } | null {
  const used = new Set(project.segments.map((s) => s.mediaId));
  let original = 0;
  for (const id of used) original += project.media[id]?.duration ?? 0;
  if (original <= 0) return null;
  const removedSec = Math.max(0, original - totalDuration(project));
  return { removedSec, percent: Math.round((removedSec / original) * 100) };
}

export function TopBar() {
  const undoKey = useEditorShortcutLabel("undo");
  const redoKey = useEditorShortcutLabel("redo");
  const saveKey = useEditorShortcutLabel("save");
  const filePath = useProjectStore((s) => s.filePath);
  const dirty = useProjectStore((s) => s.dirty);
  const project = useProjectStore((s) => s.project);
  const canUndo = useTemporalProjectStore((s) => s.pastStates.length > 0);
  const canRedo = useTemporalProjectStore((s) => s.futureStates.length > 0);
  const recorderPhase = useRecordingStore((s) => s.phase);
  const openRecorder = useRecordingStore((s) => s.openDialog);
  const recordShortcut = useShortcutLabel("record");
  const [recents, setRecents] = useState<string[]>([]);
  const [agentOpen, setAgentOpen] = useState(false);

  const displayName = filePath?.split(/[\\/]/).pop() ?? `${project.name}.scribe`;
  const cut = cutSummary(project);
  const hasContent = project.segments.length > 0;

  const handleUndo = useCallback(() => {
    useProjectStore.temporal.getState().undo();
  }, []);
  const handleRedo = useCallback(() => {
    useProjectStore.temporal.getState().redo();
  }, []);

  return (
    <div className="editor-topbar">
      <div className="editor-topbar-title">
        <DropdownMenu onOpenChange={(open) => open && setRecents(getRecentProjects())}>
          <DropdownMenuTrigger asChild>
            <Button size="sm" variant="ghost" className="tool-button" title="Project menu">
              <Menu className="h-4 w-4" />
              Project
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start" className="min-w-[220px]">
            <DropdownMenuItem onClick={() => dispatch("yusafcut:new-project")}>
              <FilePlus2 className="h-4 w-4 mr-2" />
              New project
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => dispatch("yusafcut:open-project")}>
              <FolderOpen className="h-4 w-4 mr-2" />
              Open project…
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => dispatch("yusafcut:open")}>
              <Video className="h-4 w-4 mr-2" />
              Open video file…
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => dispatch("yusafcut:add-clip")}>
              <Scissors className="h-4 w-4 mr-2" />
              Add clip…
            </DropdownMenuItem>
            {recents.length > 0 && (
              <>
                <DropdownMenuSeparator />
                <DropdownMenuLabel>Recent projects</DropdownMenuLabel>
                {recents.map((path) => (
                  <DropdownMenuItem
                    key={path}
                    onClick={() => dispatch("yusafcut:open-project-path", { path })}
                  >
                    <History className="h-4 w-4 mr-2" />
                    <span className="truncate">{path.split(/[\\/]/).pop()}</span>
                  </DropdownMenuItem>
                ))}
              </>
            )}
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => dispatch("yusafcut:snapshots")}>
              <History className="h-4 w-4 mr-2" />
              Snapshots…
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => setAgentOpen(true)}>
              <Bot className="h-4 w-4 mr-2" />
              Agent (CLI / MCP)…
            </DropdownMenuItem>
            <DropdownMenuItem
              className="text-destructive focus:text-destructive"
              onClick={() => dispatch("yusafcut:close-project")}
            >
              <Power className="h-4 w-4 mr-2" />
              Close project
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
        <span className="editor-topbar-name">{displayName}</span>
        {dirty && <span className="editor-topbar-dirty">·</span>}
      </div>

      <div className="editor-topbar-center">
        {cut && (
          <div
            className={`topbar-cut-chip${cut.removedSec > 0 ? " has-cuts" : ""}`}
            title="Time removed from the original recording"
          >
            <span className="topbar-cut-dot" />
            <span className="topbar-cut-time">−{cut.removedSec.toFixed(1)}s</span>
            <span className="topbar-cut-pct">{cut.percent}% shorter</span>
          </div>
        )}
      </div>

      <div className="editor-topbar-actions">
        <button
          type="button"
          className={`topbar-record-btn${recorderPhase !== "idle" ? " is-live" : ""}`}
          onClick={openRecorder}
          disabled={recorderPhase !== "idle"}
          title={`Record screen, camera, or voice (${recordShortcut})`}
        >
          <span className="recorder-dot is-live" />
          {recorderPhase === "idle" ? "Record" : "Recording…"}
        </button>
        <Button
          size="sm"
          variant="ghost"
          className="tool-button"
          onClick={handleUndo}
          disabled={!canUndo}
          title={`Undo (${undoKey})`}
        >
          <Undo2 className="h-4 w-4" />
        </Button>
        <Button
          size="sm"
          variant="ghost"
          className="tool-button"
          onClick={handleRedo}
          disabled={!canRedo}
          title={`Redo (${redoKey})`}
        >
          <Redo2 className="h-4 w-4" />
        </Button>
        <Button
          size="sm"
          variant={dirty ? "default" : "ghost"}
          className="tool-button"
          onClick={() => dispatch("yusafcut:save")}
          title={`Save (${saveKey})`}
        >
          <Save className="h-4 w-4" />
          {dirty ? "Save *" : "Save"}
        </Button>
        <Button
          size="sm"
          variant="ghost"
          className="tool-button"
          onClick={() => setAgentOpen(true)}
          title="Agent access (CLI / MCP)"
        >
          <Bot className="h-4 w-4" />
          <span className="max-[860px]:hidden">Agent</span>
        </Button>
        <Button
          size="sm"
          className="topbar-export-btn"
          disabled={!hasContent}
          onClick={() => dispatch("yusafcut:export")}
          title="Export the edited video"
        >
          <Upload className="h-4 w-4" />
          Export
        </Button>
      </div>
      <AgentConnectDialog open={agentOpen} onOpenChange={setAgentOpen} />
    </div>
  );
}
