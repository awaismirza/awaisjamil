/**
 * The chosen screen/window as a thumbnail. For "Area" the thumbnail is also the
 * canvas: drag on it to draw the capture rectangle (display points underneath).
 */

import { useEffect, useRef, useState } from "react";
import { RefreshCw } from "lucide-react";
import { areaFromDrag, areaOverlayStyle, isValidArea, type Point } from "@/lib/recorderSetup";
import { recordingThumbnail, type AreaRect, type DisplayInfo } from "@/lib/ipc";

interface Props {
  /** Thumbnails come from the native helper; without it the box explains why. */
  native: boolean;
  screenIndex?: number;
  windowId?: number;
  /** Set to let the user draw a capture area. */
  display?: DisplayInfo;
  area?: AreaRect;
  onArea?: (area: AreaRect) => void;
  /** Thumbnails need Screen Recording; do not even ask the helper without it. */
  allowed: boolean;
  name?: string;
}

export function SourcePreview({
  native,
  screenIndex,
  windowId,
  display,
  area,
  onArea,
  allowed,
  name,
}: Props) {
  const [url, setUrl] = useState<string | null>(null);
  const [state, setState] = useState<"idle" | "loading" | "error">("idle");
  const [nonce, setNonce] = useState(0);
  const box = useRef<HTMLDivElement>(null);
  const drag = useRef<Point | null>(null);
  const [draft, setDraft] = useState<AreaRect | null>(null);

  useEffect(() => {
    if (!native || !allowed || (screenIndex === undefined && windowId === undefined)) {
      setUrl(null);
      setState("idle");
      return;
    }
    let cancelled = false;
    setState("loading");
    recordingThumbnail({ screenIndex, windowId, maxWidth: 560 })
      .then((u) => {
        if (cancelled) return;
        setUrl(u);
        setState("idle");
      })
      .catch(() => {
        if (cancelled) return;
        setUrl(null);
        setState("error");
      });
    return () => {
      cancelled = true;
    };
  }, [native, allowed, screenIndex, windowId, nonce]);

  const toPoint = (e: React.PointerEvent): Point => {
    const r = box.current?.getBoundingClientRect();
    if (!r || r.width === 0 || r.height === 0) return { x: 0, y: 0 };
    return { x: (e.clientX - r.left) / r.width, y: (e.clientY - r.top) / r.height };
  };

  const drawable = Boolean(display && onArea);
  const shown = draft ?? area;
  const ratio = display ? display.width / display.height : 16 / 10;

  return (
    <div className="recorder-preview-wrap">
      <div
        ref={box}
        className={`recorder-preview${drawable ? " is-drawable" : ""}`}
        style={{ aspectRatio: String(ratio) }}
        onPointerDown={(e) => {
          if (!drawable) return;
          e.currentTarget.setPointerCapture?.(e.pointerId);
          drag.current = toPoint(e);
        }}
        onPointerMove={(e) => {
          if (!drawable || !drag.current || !display) return;
          setDraft(areaFromDrag(drag.current, toPoint(e), display));
        }}
        onPointerUp={(e) => {
          if (!drawable || !drag.current || !display || !onArea) return;
          const next = areaFromDrag(drag.current, toPoint(e), display);
          drag.current = null;
          setDraft(null);
          if (isValidArea(next, display)) onArea(next);
        }}
        onPointerCancel={() => {
          drag.current = null;
          setDraft(null);
        }}
      >
        {url ? (
          <img src={url} alt={name ? `Preview of ${name}` : "Source preview"} draggable={false} />
        ) : (
          <span className="recorder-preview-empty" role="status">
            {!native
              ? "Previews need the native recorder."
              : !allowed
                ? "Allow Screen Recording to see a preview."
                : state === "loading"
                  ? "Loading preview…"
                  : state === "error"
                    ? "Preview unavailable."
                    : "Nothing selected."}
          </span>
        )}
        {drawable && display && shown && (
          <div className="recorder-area" style={areaOverlayStyle(shown, display)} />
        )}
      </div>
      <button
        type="button"
        className="recorder-icon-btn"
        aria-label="Refresh preview"
        title="Refresh preview"
        disabled={!native || !allowed}
        onClick={() => setNonce((n) => n + 1)}
      >
        <RefreshCw className="h-3.5 w-3.5" />
      </button>
    </div>
  );
}
