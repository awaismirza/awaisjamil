/* global MediaStream, AudioContext */
/**
 * Best-effort camera preview and microphone level through the webview's own
 * getUserMedia, matched to the recorder's device by name. It only reads; the
 * take itself is captured natively. Everything is released when `enabled`
 * turns false or the panel closes.
 */

import { useEffect, useState } from "react";
import { matchWebDevice, micLevel } from "@/lib/recorderSetup";

export type PreviewStatus = "off" | "starting" | "live" | "unavailable";

interface Preview<T> {
  status: PreviewStatus;
  /** Why it is unavailable, for the panel to show. */
  reason: string | null;
  value: T;
}

function reasonOf(err: unknown): string {
  const name = (err as { name?: string } | null)?.name;
  if (name === "NotAllowedError" || name === "SecurityError") return "Access was refused.";
  if (name === "NotFoundError" || name === "OverconstrainedError") return "Device not found.";
  if (name === "NotReadableError") return "Another app is using it.";
  return "Preview is not available.";
}

const PREVIEW_VIDEO = { width: { ideal: 1280 }, height: { ideal: 720 } };

async function openStream(kind: "videoinput" | "audioinput", name: string | undefined) {
  const media = navigator.mediaDevices;
  if (!media?.getUserMedia) throw Object.assign(new Error("unsupported"), { name: "NotSupported" });
  // Labels are empty until some access was granted, so ask first, then match.
  const probe = await media.getUserMedia(kind === "videoinput" ? { video: PREVIEW_VIDEO } : { audio: true });
  const list = (await media.enumerateDevices()).filter((d) => d.kind === kind);
  const match = matchWebDevice(list, name);
  if (!match) return probe; // The system default is the best remaining guess.
  const current = probe.getTracks()[0]?.getSettings().deviceId;
  if (current === match.deviceId) return probe;
  probe.getTracks().forEach((t) => t.stop());
  return media.getUserMedia(
    kind === "videoinput"
      ? { video: { ...PREVIEW_VIDEO, deviceId: { exact: match.deviceId } } }
      : { audio: { deviceId: { exact: match.deviceId } } },
  );
}

export function useCameraPreview(
  enabled: boolean,
  name: string | undefined,
): Preview<MediaStream | null> {
  const [state, setState] = useState<Preview<MediaStream | null>>({
    status: "off",
    reason: null,
    value: null,
  });
  useEffect(() => {
    if (!enabled) {
      setState({ status: "off", reason: null, value: null });
      return;
    }
    let cancelled = false;
    let stream: MediaStream | null = null;
    setState({ status: "starting", reason: null, value: null });
    openStream("videoinput", name)
      .then((s) => {
        if (cancelled) return s.getTracks().forEach((t) => t.stop());
        stream = s;
        setState({ status: "live", reason: null, value: s });
      })
      .catch((err) => {
        if (!cancelled) setState({ status: "unavailable", reason: reasonOf(err), value: null });
      });
    return () => {
      cancelled = true;
      stream?.getTracks().forEach((t) => t.stop());
    };
  }, [enabled, name]);
  return state;
}

export function useMicLevel(enabled: boolean, name: string | undefined): Preview<number> {
  const [state, setState] = useState<Preview<number>>({ status: "off", reason: null, value: 0 });
  useEffect(() => {
    if (!enabled) {
      setState({ status: "off", reason: null, value: 0 });
      return;
    }
    let cancelled = false;
    let stream: MediaStream | null = null;
    let ctx: AudioContext | null = null;
    let timer: ReturnType<typeof setInterval> | undefined;
    setState({ status: "starting", reason: null, value: 0 });
    openStream("audioinput", name)
      .then((s) => {
        if (cancelled) return s.getTracks().forEach((t) => t.stop());
        stream = s;
        ctx = new AudioContext();
        const analyser = ctx.createAnalyser();
        analyser.fftSize = 512;
        ctx.createMediaStreamSource(s).connect(analyser);
        const buf = new Uint8Array(analyser.fftSize);
        setState({ status: "live", reason: null, value: 0 });
        timer = setInterval(() => {
          analyser.getByteTimeDomainData(buf);
          setState({ status: "live", reason: null, value: micLevel(buf) });
        }, 80);
      })
      .catch((err) => {
        if (!cancelled) setState({ status: "unavailable", reason: reasonOf(err), value: 0 });
      });
    return () => {
      cancelled = true;
      if (timer) clearInterval(timer);
      stream?.getTracks().forEach((t) => t.stop());
      void ctx?.close();
    };
  }, [enabled, name]);
  return state;
}
