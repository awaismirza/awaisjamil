/** Movable in-editor controls. Screen capture uses menu-bar/global controls
 * until the capture backend can exclude the HUD from recorded footage. */
import { useLayoutEffect, useRef, useState } from "react";
import { EyeOff, Flag, GripVertical, Pause, Play, RotateCcw, Square, X } from "lucide-react";
import { useShortcutLabel } from "@/hooks/useShortcutLabel";
import { formatTimecode } from "@/lib/timecode";
import { runRecorderAction, useRecordingStore } from "@/stores/recordingStore";
import { useSettingsStore } from "@/stores/settingsStore";
import { useVoiceOverStore } from "@/stores/voiceOverStore";
type Point = { x: number; y: number };
const DEFAULT_POSITION: Point = { x: 0.5, y: 0 };
const MARGIN = 8;
export function RecordingHUD() {
  const phase = useRecordingStore((s) => s.phase);
  const mode = useRecordingStore((s) => s.opts.mode);
  const countdown = useRecordingStore((s) => s.countdown);
  const elapsedSec = useRecordingStore((s) => s.elapsedSec);
  const cancel = useRecordingStore((s) => s.cancel);
  const markerCount = useRecordingStore((s) => s.markers.length);
  const showHUD = useSettingsStore((s) => s.recording.showHUD);
  const savedPosition = useSettingsStore((s) => s.recording.hudPosition);
  const setRecording = useSettingsStore((s) => s.setRecording);
  const recordKey = useShortcutLabel("record");
  const pauseKey = useShortcutLabel("pause");
  const rerecordKey = useShortcutLabel("rerecord");
  const markKey = useShortcutLabel("mark");
  const cancelKey = useShortcutLabel("cancel");
  const hud = useRef<globalThis.HTMLDivElement>(null);
  const [bounds, setBounds] = useState({ width: 0, height: 0, hudWidth: 0, hudHeight: 0 });
  const [draft, setDraft] = useState<Point | null>(null);
  const drag = useRef<{
    pointerId: number;
    x: number;
    y: number;
    left: number;
    top: number;
    point: Point;
  } | null>(null);
  // A voice-over take has its own bar (VoiceOverBar); never show two sets of controls.
  const voiceOverTake = useVoiceOverStore((s) => s.phase !== "idle" && s.phase !== "review");
  const visible =
    showHUD &&
    !voiceOverTake &&
    phase !== "idle" &&
    phase !== "countdown" &&
    mode !== "screen" &&
    mode !== "screen-camera";
  useLayoutEffect(() => {
    if (!visible) return;
    const measure = () => {
      const rect = hud.current?.getBoundingClientRect();
      if (rect)
        setBounds({
          width: globalThis.innerWidth,
          height: globalThis.innerHeight,
          hudWidth: rect.width,
          hudHeight: rect.height,
        });
    };
    measure();
    globalThis.addEventListener("resize", measure);
    const observer =
      typeof globalThis.ResizeObserver === "function"
        ? new globalThis.ResizeObserver(measure)
        : null;
    if (hud.current) observer?.observe(hud.current);
    return () => {
      globalThis.removeEventListener("resize", measure);
      observer?.disconnect();
      drag.current = null;
      setDraft(null);
    };
  }, [visible, phase]);
  const availableX = Math.max(0, bounds.width - bounds.hudWidth - MARGIN * 2);
  const availableY = Math.max(0, bounds.height - bounds.hudHeight - MARGIN * 2);
  const point = draft ?? savedPosition ?? DEFAULT_POSITION;
  const left = MARGIN + availableX * point.x;
  const top = MARGIN + availableY * point.y;
  const normalize = (x: number, y: number): Point => ({
    x: availableX ? Math.max(0, Math.min(1, (x - MARGIN) / availableX)) : 0,
    y: availableY ? Math.max(0, Math.min(1, (y - MARGIN) / availableY)) : 0,
  });
  const clearDrag = () => {
    drag.current = null;
    setDraft(null);
  };
  if (!showHUD || phase === "idle") return null;
  if (phase === "countdown")
    return countdown > 0 ? (
      <button
        type="button"
        className="recorder-countdown"
        onClick={() => void cancel()}
        title="Click to cancel countdown"
      >
        <span key={countdown}>{countdown}</span>
        <p>Recording starts… click to cancel</p>
      </button>
    ) : mode !== "screen" && mode !== "screen-camera" ? (
      <div className="recorder-hud" role="status" aria-label="Starting capture">
        <span className="recorder-hud-label">Starting capture…</span>
        <button type="button" aria-label="Cancel capture startup" onClick={() => void cancel()}>
          <X className="h-3.5 w-3.5" />
        </button>
      </div>
    ) : null;
  if (!visible) return null;
  const live = phase === "recording";
  const paused = phase === "paused";
  const busy = phase === "finalizing" || phase === "processing";
  return (
    <div
      ref={hud}
      className={`recorder-hud${paused ? " is-paused" : ""}`}
      role="status"
      aria-label="Recording controls"
      style={{ left, top, transform: "none", maxWidth: "calc(100vw - 16px)" }}
    >
      <button
        type="button"
        aria-label="Move recording controls"
        title="Drag to move · arrow keys: 10 pixels · double-click to reset"
        style={{ touchAction: "none", cursor: "grab" }}
        onPointerDown={(event) => {
          if (event.button !== 0) return;
          event.preventDefault();
          event.currentTarget.setPointerCapture(event.pointerId);
          drag.current = {
            pointerId: event.pointerId,
            x: event.clientX,
            y: event.clientY,
            left,
            top,
            point,
          };
        }}
        onPointerMove={(event) => {
          const current = drag.current;
          if (!current || event.pointerId !== current.pointerId) return;
          current.point = normalize(
            current.left + event.clientX - current.x,
            current.top + event.clientY - current.y,
          );
          setDraft(current.point);
        }}
        onPointerUp={(event) => {
          const current = drag.current;
          if (!current || event.pointerId !== current.pointerId) return;
          setRecording({ hudPosition: current.point });
          clearDrag();
        }}
        onPointerCancel={clearDrag}
        onLostPointerCapture={clearDrag}
        onKeyDown={(event) => {
          const changes: Record<string, Point> = {
            ArrowLeft: { x: -10, y: 0 },
            ArrowRight: { x: 10, y: 0 },
            ArrowUp: { x: 0, y: -10 },
            ArrowDown: { x: 0, y: 10 },
          };
          const change = changes[event.key];
          if (!change) return;
          event.preventDefault();
          event.stopPropagation();
          setRecording({ hudPosition: normalize(left + change.x, top + change.y) });
        }}
        onDoubleClick={() => {
          clearDrag();
          setRecording({ hudPosition: DEFAULT_POSITION });
        }}
      >
        <GripVertical className="h-3.5 w-3.5" />
      </button>
      <span className={`recorder-dot${live ? " is-live" : ""}`} />
      <span className="recorder-hud-time">{formatTimecode(elapsedSec, { ms: false })}</span>
      {busy ? (
        <span className="recorder-hud-label">
          {phase === "finalizing" ? "Finishing up…" : "Processing…"}
        </span>
      ) : (
        <>
          <span className="recorder-hud-label">{paused ? "Paused" : "Recording"}</span>
          <div className="recorder-hud-actions">
            <button
              type="button"
              aria-label={live ? "Pause recording" : "Resume recording"}
              onClick={() => runRecorderAction("pause")}
              title={`${live ? "Pause" : "Resume"} (${pauseKey})`}
            >
              {live ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
            </button>
            <button
              type="button"
              onClick={() => runRecorderAction("mark")}
              disabled={!live}
              title={`Mark a moment (${markKey})`}
              aria-label="Mark a moment"
            >
              <Flag className="h-3.5 w-3.5" />
              {markerCount > 0 && <span className="recorder-hud-badge">{markerCount}</span>}
            </button>
            <button
              type="button"
              aria-label="Restart recording"
              onClick={() => runRecorderAction("rerecord")}
              title={`Restart recording (${rerecordKey})`}
            >
              <RotateCcw className="h-3.5 w-3.5" />
            </button>
            <button
              type="button"
              className="is-stop"
              aria-label="Stop recording"
              onClick={() => runRecorderAction("record")}
              title={`Stop & add to video (${recordKey})`}
            >
              <Square className="h-3.5 w-3.5" />
            </button>
            <button
              type="button"
              className="is-discard"
              aria-label="Discard recording"
              onClick={() => runRecorderAction("cancel")}
              title={`Discard recording (${cancelKey})`}
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        </>
      )}
      <button
        type="button"
        aria-label="Hide recording controls"
        title="Hide controls · use the menu bar or global shortcuts"
        onClick={() => setRecording({ showHUD: false })}
      >
        <EyeOff className="h-3.5 w-3.5" />
      </button>
    </div>
  );
}
