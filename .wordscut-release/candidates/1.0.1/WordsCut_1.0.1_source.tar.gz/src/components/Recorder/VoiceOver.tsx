/**
 * Voice-over UI: the recording bar (countdown, timer, input meter, Stop) and the
 * review dialog shown after a take (audition, Overlay / Insert, override, Keep /
 * Retake / Discard). Every review action has a rebindable key (Settings →
 * Shortcuts, "Voice-over review"); Escape closes the review and keeps the take.
 */

import { useEffect, useMemo, useRef, useState, type KeyboardEvent } from "react";
import { convertFileSrc } from "@tauri-apps/api/core";
import { Mic, Pause, Play, Square } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useMicLevel } from "@/components/Recorder/useMediaPreview";
import { useEditorShortcutLabel } from "@/hooks/useShortcutLabel";
import { matchReviewShortcut, type EditorAction } from "@/lib/editorShortcuts";
import { MAX_HOLD_SEC, totalDuration } from "@/lib/edl";
import { resolveAnchor } from "@/lib/voiceover";
import { formatTimecode } from "@/lib/timecode";
import { useProjectStore } from "@/stores/projectStore";
import { useRecordingStore } from "@/stores/recordingStore";
import { useSettingsStore } from "@/stores/settingsStore";
import { useVoiceOverStore } from "@/stores/voiceOverStore";

/** Takes at least this long ask before Discard deletes them. */
export const CONFIRM_DISCARD_SEC = 2;

const isMac = () => typeof navigator !== "undefined" && /Mac|iPhone|iPad/.test(navigator.platform);

/** Explains what Override can and cannot do with audio recorded as one mixed track. */
export const OVERRIDE_NOTE =
  "Override mutes the clip's own audio track only while this take plays (short fades at the edges). " +
  "If your recording mixed your voice with system audio into that one track, both are muted there: " +
  "they cannot be separated automatically. Music tracks are separate and keep playing. " +
  "Leave Override off to mix the take over the original instead.";

export function VoiceOverBar() {
  const phase = useVoiceOverStore((s) => s.phase);
  const countdown = useVoiceOverStore((s) => s.countdown);
  const micName = useVoiceOverStore((s) => s.prefs.micName);
  const elapsed = useRecordingStore((s) => s.elapsedSec);
  const toggleKey = useEditorShortcutLabel("voiceOver");
  const live = phase === "countdown" || phase === "starting" || phase === "recording";
  const meter = useMicLevel(live, micName);
  if (!live && phase !== "stopping") return null;
  const text =
    phase === "countdown"
      ? `Voice-over in ${countdown}…`
      : phase === "starting"
        ? "Starting the microphone…"
        : phase === "stopping"
          ? "Saving the take…"
          : `Recording voice-over ${formatTimecode(elapsed)}`;
  return (
    <div
      role="status"
      aria-live="polite"
      className="fixed left-1/2 top-3 z-50 flex -translate-x-1/2 items-center gap-3 rounded-full border border-border bg-background/95 px-4 py-2 text-sm shadow-lg"
    >
      <Mic
        className={`h-4 w-4 ${phase === "recording" ? "text-red-500" : "text-muted-foreground"}`}
      />
      <span className="tabular-nums">{text}</span>
      <span
        aria-label={
          meter.status === "live" ? "Input level" : (meter.reason ?? "Input level unavailable")
        }
        title={meter.reason ?? "Input level (preview of the selected microphone)"}
        className="h-1.5 w-20 overflow-hidden rounded-full bg-secondary"
      >
        <span
          className="block h-full bg-emerald-500 transition-[width]"
          style={{ width: `${Math.round(Math.min(1, meter.value) * 100)}%` }}
        />
      </span>
      {phase !== "stopping" && (
        <Button
          size="sm"
          variant="outline"
          className="h-7 gap-1 px-2 text-xs"
          onClick={() => useVoiceOverStore.getState().toggle()}
        >
          <Square className="h-3 w-3" />
          {phase === "recording" ? "Stop" : "Cancel"} ({toggleKey})
        </Button>
      )}
    </div>
  );
}

export function VoiceOverReviewDialog() {
  const open = useVoiceOverStore((s) => s.reviewOpen);
  const draft = useVoiceOverStore((s) => s.draft);
  const busy = useVoiceOverStore((s) => s.busy);
  const project = useProjectStore((s) => s.project);
  const map = useSettingsStore((s) => s.editorShortcuts);
  const audio = useRef<globalThis.HTMLAudioElement | null>(null);
  const [playing, setPlaying] = useState(false);
  const content = useRef<globalThis.HTMLDivElement | null>(null);
  const keys = {
    keep: useEditorShortcutLabel("voKeep"),
    mode: useEditorShortcutLabel("voMode"),
    over: useEditorShortcutLabel("voOverride"),
    play: useEditorShortcutLabel("voAudition"),
    retake: useEditorShortcutLabel("voRetake"),
    discard: useEditorShortcutLabel("voDiscard"),
  };

  // Stop the audition whenever the take or the dialog changes.
  useEffect(() => {
    return () => {
      audio.current?.pause();
      audio.current = null;
      setPlaying(false);
    };
  }, [draft?.id, open]);

  const placement = useMemo(() => {
    if (!draft) return null;
    const resolved = resolveAnchor(project, draft.anchor);
    const total = totalDuration(project);
    const len = draft.durationSec ?? 0;
    return { ...resolved, overflow: Math.max(0, resolved.outputTime + len - total) };
  }, [project, draft]);

  if (!draft) return null;
  const store = useVoiceOverStore.getState;

  const audition = () => {
    if (!draft.path) return;
    if (!audio.current) {
      const el = new globalThis.Audio(convertFileSrc(draft.path));
      el.addEventListener("ended", () => setPlaying(false));
      audio.current = el;
    }
    const el = audio.current;
    if (el.paused) {
      void el.play().then(
        () => setPlaying(true),
        () => setPlaying(false),
      );
    } else {
      el.pause();
      setPlaying(false);
    }
  };

  const run = (action: EditorAction) => {
    switch (action) {
      case "voKeep":
        void store().keep();
        return true;
      case "voMode":
        store().setDraft({ mode: draft.mode === "insert" ? "overlay" : "insert" });
        return true;
      case "voOverride":
        store().setDraft({ overrideOriginal: !draft.overrideOriginal });
        return true;
      case "voAudition":
        audition();
        return true;
      case "voRetake":
        audio.current?.pause();
        void store().retake();
        return true;
      case "voDiscard":
        audio.current?.pause();
        // One stray key must not delete a real take: confirm unless it is tiny.
        if (
          (draft.durationSec ?? 0) >= CONFIRM_DISCARD_SEC &&
          !window.confirm(
            `Discard this ${(draft.durationSec ?? 0).toFixed(1)} s take? The recording is deleted.`,
          )
        )
          return true;
        void store().discard();
        return true;
      default:
        return false;
    }
  };

  const onKeyDownCapture = (e: KeyboardEvent<HTMLDivElement>) => {
    if (e.nativeEvent.isComposing || e.repeat) return;
    // Return / Space on a focused control belong to that control (Tab to
    // Discard + Return discards; Space ticks a checkbox).
    const target = e.target as HTMLElement;
    if (
      (e.key === "Enter" || e.key === " " || e.code === "Space" || e.code === "Enter") &&
      target.closest?.("button, input, select, textarea, label, [role='button']")
    )
      return;
    const ev = {
      code: e.code ?? "",
      key: e.key,
      metaKey: e.metaKey,
      ctrlKey: e.ctrlKey,
      altKey: e.altKey,
      shiftKey: e.shiftKey,
    };
    const action = matchReviewShortcut(map, ev, isMac());
    if (action && !busy && run(action)) {
      e.preventDefault();
      e.stopPropagation();
    }
  };

  return (
    <Dialog
      open={open}
      onOpenChange={(o) => {
        if (!o) {
          audio.current?.pause();
          store().closeReview();
        }
      }}
    >
      <DialogContent
        className="max-w-md"
        ref={content}
        onKeyDownCapture={onKeyDownCapture}
        // Focus the dialog itself, not its first button, so Return keeps and
        // Space plays until the user Tabs to a control.
        onOpenAutoFocus={(e) => {
          e.preventDefault();
          content.current?.focus();
        }}
        tabIndex={-1}
      >
        <DialogHeader>
          <DialogTitle>Voice-over take</DialogTitle>
          <DialogDescription>
            {(draft.durationSec ?? 0).toFixed(1)} s recorded at{" "}
            {formatTimecode(placement?.outputTime ?? draft.anchor.outputTime)}.
            {placement?.moved &&
              " The clip it was recorded over was removed; it will go at this time instead."}
          </DialogDescription>
        </DialogHeader>

        <Button variant="outline" className="w-full gap-2" onClick={audition}>
          {playing ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
          {playing ? "Stop" : "Play the take"} ({keys.play})
        </Button>

        <fieldset className="grid gap-2 text-sm">
          <legend className="mb-1 text-xs text-muted-foreground">
            Placement ({keys.mode} switches)
          </legend>
          <label className="flex items-start gap-2">
            <input
              type="radio"
              name="vo-mode"
              checked={draft.mode !== "insert"}
              onChange={() => store().setDraft({ mode: "overlay" })}
            />
            <span>
              Overlay: mix over the video; its timing does not change.
              {draft.mode !== "insert" && placement && placement.overflow > 0 && (
                <span role="alert" className="block text-xs text-amber-500">
                  {placement.overflow.toFixed(1)} s runs past the end of the video and will not be
                  heard in the export. Choose Insert to hold the last frame for it instead.
                </span>
              )}
            </span>
          </label>
          <label className="flex items-start gap-2">
            <input
              type="radio"
              name="vo-mode"
              checked={draft.mode === "insert"}
              onChange={() => store().setDraft({ mode: "insert" })}
            />
            <span>
              Insert: hold the frame at this point while the take plays, then continue. Everything
              after it moves later by {(draft.durationSec ?? 0).toFixed(1)} s.
              {draft.mode === "insert" && (draft.durationSec ?? 0) > MAX_HOLD_SEC && (
                <span role="alert" className="block text-xs text-amber-500">
                  A frame can be held for at most {MAX_HOLD_SEC / 60} minutes; the rest of the take
                  plays over the following video.
                </span>
              )}
            </span>
          </label>
        </fieldset>

        <label className="flex items-start gap-2 text-sm">
          <input
            type="checkbox"
            checked={draft.overrideOriginal}
            onChange={(e) => store().setDraft({ overrideOriginal: e.target.checked })}
          />
          <span>
            Override the original audio while the take plays ({keys.over})
            <span className="block text-xs text-muted-foreground">{OVERRIDE_NOTE}</span>
          </span>
        </label>

        <DialogFooter className="gap-2 sm:justify-between">
          <div className="flex gap-2">
            <Button variant="ghost" disabled={busy} onClick={() => run("voDiscard")}>
              Discard ({keys.discard})
            </Button>
            <Button variant="outline" disabled={busy} onClick={() => run("voRetake")}>
              Retake ({keys.retake})
            </Button>
          </div>
          <Button disabled={busy} onClick={() => run("voKeep")}>
            Keep ({keys.keep})
          </Button>
        </DialogFooter>
        <p className="text-xs text-muted-foreground">
          Escape closes this and keeps the take for later (voice-over shortcut or the Music panel).
        </p>
      </DialogContent>
    </Dialog>
  );
}
