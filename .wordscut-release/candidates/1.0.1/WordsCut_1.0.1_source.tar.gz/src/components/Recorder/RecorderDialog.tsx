/* global MediaStream */
/**
 * Compact recorder setup (~460 px): pick Screen / Camera / Audio, choose the
 * source, check permissions and devices, then press one Start button.
 *
 * Opens via the TopBar Record button, the Media panel, or the global ⌥⌘R
 * shortcut. While a session is running this dialog stays closed; the desktop
 * controller (or the in-editor HUD) takes over. All choices live in
 * `recordingStore.opts`; native-only features (window/area, thumbnails,
 * permission prompts) appear only when the native helper listed the devices.
 */

import { useEffect, useId, useMemo, useState } from "react";
import {
  AppWindowMac,
  ChevronDown,
  CircleHelp,
  Crop,
  Headphones,
  Keyboard,
  Mic,
  MonitorUp,
  RefreshCw,
  ShieldAlert,
  Video,
  Volume2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useShortcutLabel } from "@/hooks/useShortcutLabel";
import {
  openPrivacySettings,
  type AreaRect,
  type DisplayInfo,
  type PermissionKind,
  type PipCorner,
  type PipSize,
} from "@/lib/ipc";
import { COUNTDOWN_CHOICES, type CountdownSec } from "@/lib/settings";
import {
  ALL_CHARACTERS_NOTE,
  KEY_IDENTITY_NOTE,
  PERMISSION_LABEL,
  clampArea,
  effectiveSource,
  isNative,
  modeFor,
  needsCamera,
  needsScreen,
  permissionIssues,
  startBlocker,
  uiModeOf,
  type UiMode,
} from "@/lib/recorderSetup";
import { useRecordingStore } from "@/stores/recordingStore";
import { useSettingsStore } from "@/stores/settingsStore";
import { SegmentedRadio } from "./SegmentedRadio";
import { SourcePreview } from "./SourcePreview";
import { useCameraPreview, useMicLevel } from "./useMediaPreview";

const CORNERS: Array<{ id: PipCorner; label: string }> = [
  { id: "top-left", label: "↖" },
  { id: "top-right", label: "↗" },
  { id: "bottom-left", label: "↙" },
  { id: "bottom-right", label: "↘" },
];

const SIZES: Array<{ id: PipSize; label: string }> = [
  { id: "small", label: "S" },
  { id: "medium", label: "M" },
  { id: "large", label: "L" },
];

function Switch({
  label,
  checked,
  onChange,
  disabled,
}: {
  label: string;
  checked: boolean;
  onChange: (next: boolean) => void;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      disabled={disabled}
      className={`recorder-switch${checked ? " is-on" : ""}`}
      onClick={() => onChange(!checked)}
    >
      <span />
    </button>
  );
}

export function RecorderDialog() {
  const dialogOpen = useRecordingStore((s) => s.dialogOpen);
  const openDialog = useRecordingStore((s) => s.openDialog);
  const closeDialog = useRecordingStore((s) => s.closeDialog);
  const autoTranscribe = useSettingsStore((s) => s.recording.autoTranscribe);

  // Legacy entry point used by the Media panel.
  useEffect(() => {
    const onRecord = () => openDialog();
    window.addEventListener("yusafcut:record", onRecord);
    return () => window.removeEventListener("yusafcut:record", onRecord);
  }, [openDialog]);

  return (
    <Dialog open={dialogOpen} onOpenChange={(open) => (open ? openDialog() : closeDialog())}>
      <DialogContent className="recorder-panel max-w-[460px] gap-3 p-4">
        <DialogHeader className="space-y-1">
          <DialogTitle className="flex items-center gap-2 text-base">
            <span className="recorder-dot" />
            New recording
          </DialogTitle>
          <DialogDescription className="text-xs">
            Recorded locally · Added to this project
            {autoTranscribe ? " · Transcribed automatically" : " · Not transcribed automatically"}
          </DialogDescription>
        </DialogHeader>
        <RecorderPanel />
      </DialogContent>
    </Dialog>
  );
}

function RecorderPanel() {
  const ids = useId();
  const recordKey = useShortcutLabel("record");
  const pauseKey = useShortcutLabel("pause");
  const rerecordKey = useShortcutLabel("rerecord");
  const markKey = useShortcutLabel("mark");
  const devices = useRecordingStore((s) => s.devices);
  const devicesError = useRecordingStore((s) => s.devicesError);
  const deviceNotices = useRecordingStore((s) => s.deviceNotices);
  const opts = useRecordingStore((s) => s.opts);
  const setOpts = useRecordingStore((s) => s.setOpts);
  const refreshDevices = useRecordingStore((s) => s.refreshDevices);
  const requestPermissions = useRecordingStore((s) => s.requestPermissions);
  const closeDialog = useRecordingStore((s) => s.closeDialog);
  const beginCountdown = useRecordingStore((s) => s.beginCountdown);
  const countdownSec = useSettingsStore((s) => s.recording.countdownSec);
  const hideWindow = useSettingsStore((s) => s.recording.hideWindow);
  const autoTranscribe = useSettingsStore((s) => s.recording.autoTranscribe);
  const setRecording = useSettingsStore((s) => s.setRecording);

  const [advanced, setAdvanced] = useState(false);
  const [help, setHelp] = useState(false);
  const [cameraPreviewOn, setCameraPreviewOn] = useState(false);
  const [micTestOn, setMicTestOn] = useState(false);
  const [busy, setBusy] = useState<PermissionKind | null>(null);

  // Re-read devices when the window regains focus (something was plugged in, or a
  // permission was just granted in System Settings).
  useEffect(() => {
    const onFocus = () => void refreshDevices();
    window.addEventListener("focus", onFocus);
    return () => window.removeEventListener("focus", onFocus);
  }, [refreshDevices]);

  const native = isNative(devices);
  const ui = uiModeOf(opts.mode);
  const source = effectiveSource(opts, devices);
  const screens = useMemo(() => devices?.video.filter((d) => d.isScreen) ?? [], [devices]);
  const cameras = useMemo(() => devices?.video.filter((d) => !d.isScreen) ?? [], [devices]);
  const mics = useMemo(() => devices?.audio ?? [], [devices]);
  const windows = useMemo(
    () =>
      [...(devices?.windows ?? [])].sort((a, b) =>
        `${a.app} ${a.title}`.localeCompare(`${b.app} ${b.title}`),
      ),
    [devices],
  );
  const cameraOn = needsCamera(opts.mode);
  const withScreen = needsScreen(opts.mode);
  const micOn = opts.audioIndex !== undefined;
  const permState = devices?.permissions ?? {};
  const screenAllowed = !native || permState.screenRecording === "granted";
  const issues = permissionIssues(opts, devices);
  const blocker = startBlocker(opts, devices, devicesError);
  const loading = devices === null && !devicesError;

  const selectedScreen = screens.find((s) => s.index === opts.screenIndex);
  const displayInfo = devices?.displays?.find((d) => d.index === opts.screenIndex);
  const selectedWindow = windows.find((w) => w.id === opts.windowId);
  const cameraName = cameras.find((c) => c.index === opts.cameraIndex)?.name;
  const micName = mics.find((m) => m.index === opts.audioIndex)?.name;

  // Camera/mic preview: automatic once the OS permission is known to be granted,
  // otherwise on demand (the first use shows the system prompt).
  const cameraPreviewAllowed = !native || permState.camera === "granted" || cameraPreviewOn;
  const micPreviewAllowed = !native || permState.microphone === "granted" || micTestOn;
  const camera = useCameraPreview(
    cameraOn && cameraPreviewAllowed && cameras.length > 0,
    cameraName,
  );
  const mic = useMicLevel(micOn && micPreviewAllowed && mics.length > 0, micName);

  const setUi = (next: UiMode) => {
    const patch: Partial<typeof opts> = { mode: modeFor(next, cameraOn && ui === "screen") };
    // Voice-over needs a microphone: pick the first one rather than fail Start.
    if (next === "audio" && opts.audioIndex === undefined && mics[0])
      patch.audioIndex = mics[0].index;
    setOpts(patch);
  };

  const request = async (kind: PermissionKind) => {
    setBusy(kind);
    try {
      await requestPermissions([kind]);
    } finally {
      setBusy(null);
    }
  };

  const noun = ui === "audio" ? "audio" : "recording";
  const blockerId = `${ids}-blocker`;

  return (
    <div className="grid gap-3 text-sm">
      <SegmentedRadio<UiMode>
        label="Recording type"
        value={ui}
        onChange={setUi}
        className="is-large"
        options={[
          { id: "screen", label: "Screen", icon: <MonitorUp className="h-4 w-4" /> },
          { id: "camera", label: "Camera", icon: <Video className="h-4 w-4" /> },
          { id: "audio", label: "Audio", icon: <Headphones className="h-4 w-4" /> },
        ]}
      />

      {loading && (
        <p className="recorder-note" role="status">
          Looking for screens and devices…
        </p>
      )}
      {devicesError && (
        <div className="recorder-note is-error" role="alert">
          <span>{devicesError}</span>
          <button type="button" onClick={() => void refreshDevices()}>
            Retry
          </button>
        </div>
      )}
      {deviceNotices.map((n) => (
        <p key={n} className="recorder-note is-warn" role="status">
          {n} Another device was selected.
        </p>
      ))}

      {/* Source (screen modes) */}
      {withScreen && devices && (
        <section className="grid gap-2" aria-label="Screen source">
          <SegmentedRadio
            label="What to record"
            value={source}
            onChange={(kind) => setOpts({ sourceKind: kind })}
            options={[
              { id: "display", label: "Display", icon: <MonitorUp className="h-3.5 w-3.5" /> },
              {
                id: "window",
                label: "Window",
                icon: <AppWindowMac className="h-3.5 w-3.5" />,
                disabled: !native,
                title: native ? undefined : "Window capture needs the native recorder",
              },
              {
                id: "area",
                label: "Area",
                icon: <Crop className="h-3.5 w-3.5" />,
                disabled: !native || !(devices.displays?.length ?? 0),
                title: native ? undefined : "Area capture needs the native recorder",
              },
            ]}
          />

          {source === "window" ? (
            <label className="recorder-field">
              <span>Window</span>
              <select
                value={opts.windowId ?? ""}
                onChange={(e) =>
                  setOpts({ windowId: e.target.value === "" ? undefined : Number(e.target.value) })
                }
              >
                <option value="">{windows.length ? "Choose a window…" : "No windows open"}</option>
                {windows.map((w) => (
                  <option key={w.id} value={w.id}>
                    {w.app}
                    {w.title ? ` — ${w.title}` : ""}
                  </option>
                ))}
              </select>
            </label>
          ) : (
            <label className="recorder-field">
              <span>Display</span>
              <select
                value={opts.screenIndex ?? ""}
                onChange={(e) => setOpts({ screenIndex: Number(e.target.value), area: undefined })}
              >
                {screens.length === 0 && <option value="">No display found</option>}
                {screens.map((s) => (
                  <option key={s.index} value={s.index}>
                    {s.name}
                  </option>
                ))}
              </select>
            </label>
          )}

          <SourcePreview
            native={native}
            allowed={screenAllowed}
            screenIndex={source === "window" ? undefined : opts.screenIndex}
            windowId={source === "window" ? opts.windowId : undefined}
            display={source === "area" ? displayInfo : undefined}
            area={source === "area" ? opts.area : undefined}
            onArea={source === "area" ? (area) => setOpts({ area }) : undefined}
            name={source === "window" ? selectedWindow?.app : selectedScreen?.name}
          />

          {source === "area" && displayInfo && (
            <AreaFields
              area={opts.area}
              display={displayInfo}
              onChange={(area) => setOpts({ area })}
            />
          )}
        </section>
      )}

      {/* Permissions that are not granted */}
      {issues.length > 0 && (
        <section className="grid gap-1.5" aria-label="Permissions">
          {issues.map(({ kind, state }) => (
            <div key={kind} className="recorder-note is-warn">
              <ShieldAlert className="h-3.5 w-3.5 shrink-0" aria-hidden />
              <span>
                {PERMISSION_LABEL[kind]}{" "}
                {state === "notDetermined"
                  ? "has not been allowed yet."
                  : state === "restricted"
                    ? "is restricted on this Mac."
                    : "access is off."}
              </span>
              {state === "notDetermined" && (
                <button type="button" disabled={busy === kind} onClick={() => void request(kind)}>
                  {busy === kind ? "Waiting…" : "Allow"}
                </button>
              )}
              {state === "denied" && (
                <>
                  <button type="button" onClick={() => void openPrivacySettings(kind)}>
                    Open Settings
                  </button>
                  <button type="button" onClick={() => void refreshDevices()}>
                    Re-check
                  </button>
                </>
              )}
            </div>
          ))}
        </section>
      )}

      {/* Camera */}
      {devices && ui !== "audio" && (
        <section className="grid gap-2" aria-label="Camera">
          <div className="recorder-row">
            <span className="recorder-row-label">
              <Video className="h-3.5 w-3.5" /> Camera
            </span>
            {ui === "screen" ? (
              <Switch
                label="Include camera"
                checked={cameraOn}
                onChange={(on) => setOpts({ mode: modeFor("screen", on) })}
              />
            ) : (
              <span className="text-xs text-muted-foreground">Always on</span>
            )}
          </div>
          {cameraOn &&
            (cameras.length === 0 ? (
              <p className="recorder-note is-error" role="status">
                No camera found. Connect one, or switch the camera off.
              </p>
            ) : (
              <>
                <select
                  className="recorder-select"
                  aria-label="Camera device"
                  value={opts.cameraIndex ?? ""}
                  onChange={(e) => setOpts({ cameraIndex: Number(e.target.value) })}
                >
                  {cameras.map((c) => (
                    <option key={c.index} value={c.index}>
                      {c.name}
                    </option>
                  ))}
                </select>
                <div className="recorder-camera">
                  {camera.status === "live" ? (
                    <CameraVideo stream={camera.value} />
                  ) : cameraPreviewAllowed ? (
                    <span role="status">
                      {camera.status === "unavailable"
                        ? `Camera preview unavailable. ${camera.reason ?? ""}`
                        : "Starting camera preview…"}
                    </span>
                  ) : (
                    <button type="button" onClick={() => setCameraPreviewOn(true)}>
                      Show camera preview
                    </button>
                  )}
                </div>
              </>
            ))}
        </section>
      )}

      {/* Microphone + system audio */}
      {devices && (
        <section className="grid gap-2" aria-label="Audio">
          <label className="recorder-field">
            <span>
              <Mic className="h-3.5 w-3.5" /> Microphone
            </span>
            <select
              value={opts.audioIndex ?? "none"}
              onChange={(e) =>
                setOpts({
                  audioIndex: e.target.value === "none" ? undefined : Number(e.target.value),
                })
              }
            >
              {(ui !== "audio" || mics.length === 0) && (
                <option value="none">
                  {mics.length === 0 ? "No microphone found" : "No microphone"}
                </option>
              )}
              {mics.map((m) => (
                <option key={m.index} value={m.index}>
                  {m.name}
                </option>
              ))}
            </select>
          </label>
          {micOn && mics.length > 0 && (
            <div className="recorder-meter-row">
              {micPreviewAllowed ? (
                <div
                  className="recorder-meter"
                  role="meter"
                  aria-label="Microphone level"
                  aria-valuemin={0}
                  aria-valuemax={100}
                  aria-valuenow={Math.round(mic.value * 100)}
                  aria-valuetext={mic.status === "live" ? undefined : (mic.reason ?? "Waiting")}
                >
                  <i style={{ width: `${Math.round(mic.value * 100)}%` }} />
                </div>
              ) : (
                <button type="button" onClick={() => setMicTestOn(true)}>
                  Test microphone level
                </button>
              )}
              {mic.status === "unavailable" && (
                <span className="text-xs text-muted-foreground">
                  Level unavailable. {mic.reason}
                </span>
              )}
            </div>
          )}
          {withScreen && (
            <div className="recorder-row">
              <span className="recorder-row-label">
                <Volume2 className="h-3.5 w-3.5" /> System audio
                {!native && <small> · needs the native recorder</small>}
              </span>
              <Switch
                label="Record system audio"
                checked={Boolean(opts.systemAudio) && native}
                disabled={!native}
                onChange={(on) => setOpts({ systemAudio: on })}
              />
            </div>
          )}
          {withScreen && native && (
            <>
              <div className="recorder-row">
                <span className="recorder-row-label">
                  <Keyboard className="h-3.5 w-3.5" /> Record key names
                </span>
                <Switch
                  label="Record key names"
                  checked={Boolean(opts.recordKeyIdentity)}
                  onChange={(on) =>
                    setOpts({
                      recordKeyIdentity: on,
                      ...(on ? {} : { recordAllCharacters: false }),
                    })
                  }
                />
              </div>
              <p className="text-xs text-muted-foreground" role="note">
                {KEY_IDENTITY_NOTE}
              </p>
              {opts.recordKeyIdentity && (
                <>
                  <div className="recorder-row">
                    <span className="recorder-row-label">Also record all characters</span>
                    <Switch
                      label="Also record all characters"
                      checked={Boolean(opts.recordAllCharacters)}
                      onChange={(on) => setOpts({ recordAllCharacters: on })}
                    />
                  </div>
                  <p className="text-xs text-muted-foreground" role="note">
                    {ALL_CHARACTERS_NOTE}
                  </p>
                </>
              )}
            </>
          )}
        </section>
      )}

      {/* Advanced */}
      <section aria-label="Advanced settings">
        <button
          type="button"
          className="recorder-disclosure"
          aria-expanded={advanced}
          aria-controls={`${ids}-advanced`}
          onClick={() => setAdvanced((v) => !v)}
        >
          <ChevronDown className={`h-3.5 w-3.5${advanced ? "" : " -rotate-90"}`} />
          Advanced
        </button>
        {advanced && (
          <div id={`${ids}-advanced`} className="mt-2 grid gap-2.5">
            <div className="recorder-row">
              <span className="recorder-row-label">Frame rate</span>
              <SegmentedRadio
                label="Frame rate"
                value={String(opts.fps ?? 30)}
                onChange={(v) => setOpts({ fps: Number(v) })}
                options={[
                  { id: "24", label: "24" },
                  { id: "30", label: "30" },
                  { id: "60", label: "60" },
                ]}
              />
            </div>
            <div className="recorder-row">
              <span className="recorder-row-label">Countdown</span>
              <SegmentedRadio
                label="Countdown seconds"
                value={String(countdownSec)}
                onChange={(v) => setRecording({ countdownSec: Number(v) as CountdownSec })}
                options={COUNTDOWN_CHOICES.map((c) => ({
                  id: String(c),
                  label: c === 0 ? "Off" : `${c}s`,
                }))}
              />
            </div>
            {withScreen && (
              <div className="recorder-row">
                <span className="recorder-row-label">Hide WordsCut while recording</span>
                <Switch
                  label="Hide WordsCut while recording"
                  checked={hideWindow}
                  onChange={(on) => setRecording({ hideWindow: on })}
                />
              </div>
            )}
            <div className="recorder-row">
              <span className="recorder-row-label">Transcribe when finished</span>
              <Switch
                label="Transcribe when finished"
                checked={autoTranscribe}
                onChange={(on) => setRecording({ autoTranscribe: on })}
              />
            </div>
            {opts.mode === "screen-camera" && (
              <div className="recorder-row">
                <span className="recorder-row-label">Camera bubble</span>
                <span className="flex items-center gap-2">
                  <SegmentedRadio<PipCorner>
                    label="Camera corner"
                    value={opts.pipCorner ?? "bottom-right"}
                    onChange={(id) => setOpts({ pipCorner: id })}
                    options={CORNERS.map((c) => ({
                      ...c,
                      title: `Camera in ${c.id.replace("-", " ")}`,
                    }))}
                  />
                  <SegmentedRadio<PipSize>
                    label="Camera size"
                    value={opts.pipSize ?? "medium"}
                    onChange={(id) => setOpts({ pipSize: id })}
                    options={SIZES.map((s) => ({ ...s, title: `Camera bubble ${s.id}` }))}
                  />
                </span>
              </div>
            )}
          </div>
        )}
      </section>

      {/* Footer */}
      <div className="grid gap-2 border-t pt-3">
        {blocker && !loading && (
          <p id={blockerId} className="recorder-blocker" role="status">
            {blocker}
          </p>
        )}
        {help && (
          <div className="recorder-shortcuts" id={`${ids}-help`}>
            <span>
              <kbd>{recordKey}</kbd> record / stop
            </span>
            <span>
              <kbd>{pauseKey}</kbd> pause
            </span>
            <span>
              <kbd>{rerecordKey}</kbd> re-record
            </span>
            <span>
              <kbd>{markKey}</kbd> mark a moment
            </span>
          </div>
        )}
        <div className="flex items-center gap-2">
          <button
            type="button"
            className="recorder-icon-btn"
            aria-label="Keyboard shortcuts"
            aria-expanded={help}
            aria-controls={`${ids}-help`}
            title="Keyboard shortcuts"
            onClick={() => setHelp((v) => !v)}
          >
            <CircleHelp className="h-4 w-4" />
          </button>
          <button
            type="button"
            className="recorder-icon-btn"
            aria-label="Refresh devices"
            title="Refresh devices"
            onClick={() => void refreshDevices()}
          >
            <RefreshCw className="h-4 w-4" />
          </button>
          <span className="flex-1" />
          <Button variant="outline" onClick={closeDialog}>
            Cancel
          </Button>
          <Button
            className="recorder-start-btn gap-2"
            disabled={blocker !== null}
            aria-describedby={blocker ? blockerId : undefined}
            onClick={beginCountdown}
          >
            <span className="recorder-dot is-live" />
            Start {noun}
            <kbd className="recorder-start-kbd">{recordKey}</kbd>
          </Button>
        </div>
      </div>
    </div>
  );
}

function CameraVideo({ stream }: { stream: MediaStream | null }) {
  return (
    <video
      aria-label="Camera preview"
      autoPlay
      muted
      playsInline
      ref={(el) => {
        if (el && el.srcObject !== stream) el.srcObject = stream;
      }}
    />
  );
}

/** Typed X / Y / width / height (display points) for the capture area. */
function AreaFields({
  area,
  display,
  onChange,
}: {
  area: AreaRect | undefined;
  display: DisplayInfo;
  onChange: (area: AreaRect) => void;
}) {
  const value = area ?? { x: 0, y: 0, width: display.width, height: display.height };
  const field = (key: keyof AreaRect, label: string, name: string) => (
    <label className="recorder-num">
      <span aria-hidden>{label}</span>
      <input
        type="number"
        aria-label={name}
        min={0}
        value={Math.round(value[key])}
        onChange={(e) => onChange(clampArea({ ...value, [key]: Number(e.target.value) }, display))}
      />
    </label>
  );
  return (
    <div className="recorder-area-fields" role="group" aria-label="Capture area in points">
      {field("x", "X", "Area left")}
      {field("y", "Y", "Area top")}
      {field("width", "W", "Area width")}
      {field("height", "H", "Area height")}
      {!area && (
        <span className="text-xs text-muted-foreground">Drag on the preview, or type a size.</span>
      )}
    </div>
  );
}
