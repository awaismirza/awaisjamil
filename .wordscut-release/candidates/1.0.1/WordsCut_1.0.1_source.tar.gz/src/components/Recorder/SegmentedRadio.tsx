/**
 * Accessible segmented choice: a radio group with a roving tab stop and
 * arrow-key movement (Left/Up = previous, Right/Down = next, Home/End).
 */

import { useRef, type ReactNode } from "react";

export interface SegmentOption<T extends string> {
  id: T;
  label: string;
  icon?: ReactNode;
  disabled?: boolean;
  title?: string;
}

interface Props<T extends string> {
  label: string;
  value: T;
  options: Array<SegmentOption<T>>;
  onChange: (id: T) => void;
  className?: string;
}

export function SegmentedRadio<T extends string>({
  label,
  value,
  options,
  onChange,
  className,
}: Props<T>) {
  const refs = useRef<Array<HTMLButtonElement | null>>([]);

  const move = (from: number, step: number) => {
    const n = options.length;
    for (let k = 1; k <= n; k++) {
      const next = (from + step * k + n * k) % n;
      if (!options[next].disabled) {
        onChange(options[next].id);
        refs.current[next]?.focus();
        return;
      }
    }
  };

  const onKeyDown = (e: React.KeyboardEvent, index: number) => {
    switch (e.key) {
      case "ArrowRight":
      case "ArrowDown":
        e.preventDefault();
        move(index, 1);
        break;
      case "ArrowLeft":
      case "ArrowUp":
        e.preventDefault();
        move(index, -1);
        break;
      case "Home":
        e.preventDefault();
        move(-1, 1);
        break;
      case "End":
        e.preventDefault();
        move(options.length, -1);
        break;
    }
  };

  return (
    <div role="radiogroup" aria-label={label} className={`recorder-seg ${className ?? ""}`}>
      {options.map((o, i) => {
        const active = o.id === value;
        return (
          <button
            key={o.id}
            ref={(el) => {
              refs.current[i] = el;
            }}
            type="button"
            role="radio"
            aria-checked={active}
            tabIndex={active ? 0 : -1}
            disabled={o.disabled}
            title={o.title}
            className={active ? "is-active" : ""}
            onClick={() => onChange(o.id)}
            onKeyDown={(e) => onKeyDown(e, i)}
          >
            {o.icon}
            <span>{o.label}</span>
          </button>
        );
      })}
    </div>
  );
}
