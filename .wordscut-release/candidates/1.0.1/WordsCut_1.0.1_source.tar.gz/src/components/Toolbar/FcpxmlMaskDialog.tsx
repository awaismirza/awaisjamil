import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

/**
 * Shown before the FCPXML save dialog when the project has privacy masks: the
 * FCPXML points at the original media, so masks cannot travel with it.
 * Cancel is the default (focused) button.
 */
export function FcpxmlMaskDialog({
  open,
  onCancel,
  onConfirm,
}: {
  open: boolean;
  onCancel: () => void;
  onConfirm: () => void;
}) {
  return (
    <Dialog open={open} onOpenChange={(o) => !o && onCancel()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>PRIVACY MASKS ARE NOT APPLIED in FCPXML</DialogTitle>
          <DialogDescription>
            An FCPXML file points at your original, unmasked media: the exported timeline will
            show the masked content in Final Cut Pro or any other editor. Export a video instead to
            share masked footage.
          </DialogDescription>
        </DialogHeader>
        <DialogFooter>
          <Button autoFocus onClick={onCancel}>
            Cancel
          </Button>
          <Button variant="destructive" onClick={onConfirm}>
            Export FCPXML without masks
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
