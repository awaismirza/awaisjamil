import { saveProjectRevision } from "@/lib/saveCoordinator";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { replaceProjectBaseline, useProjectStore } from "@/stores/projectStore";
import { useUIStore } from "@/stores/uiStore";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  deleteModel,
  detectPauses,
  downloadModel,
  exportVideo,
  onExportMeasuring,
  importMedia,
  listModels,
  onModelDownloadProgress,
  transcribe,
  type ModelInfo,
  type WhisperModel,
} from "@/lib/ipc";
import { open as openDialog, save as saveDialog } from "@tauri-apps/plugin-dialog";
import { writeTextFile } from "@tauri-apps/plugin-fs";
import { CheckCircle2, Download, MicVocal, Scissors, Settings2 } from "lucide-react";
import {
  addMediaWithTranscript as buildProjectWithMedia,
  newProject,
  totalDuration,
  type Project,
  type Word,
} from "@/lib/edl";
import { buildSrt, buildVtt } from "@/lib/captions";
import { buildFcpxml } from "@/lib/fcpxml";
import { FcpxmlMaskDialog } from "./FcpxmlMaskDialog";
import { addRecentProject } from "@/lib/recentProjects";
import {
  buildExportOptions,
  captionBurnNotes,
  EXPORT_FORMATS,
  exportRequestProblem,
  transparencyWarning,
  type ExportFormat,
  type ExportUiSettings,
  describeAudioReport,
} from "@/lib/exportOptions";
import {
  MEDIA_EXTENSIONS,
  openProjectAtPath as openProjectAtPathAction,
} from "@/lib/projectActions";
import { snapWordsToSilences } from "@/lib/timestampSnap";
import { usePlayerStore } from "@/stores/playerStore";
import { MusicTracksDialog } from "@/components/Toolbox/MusicTracksDialog";
import { SnapshotsDialog } from "@/components/Toolbox/SnapshotsDialog";
import {
  clearTranscriptCache,
  readTranscriptCache,
  writeTranscriptCache,
} from "@/lib/transcriptCache";

const MODELS: { name: WhisperModel; label: string; sizeMb: number }[] = [
  { name: "tiny", label: "Tiny (fast, lower accuracy)", sizeMb: 75 },
  { name: "base", label: "Base", sizeMb: 142 },
  { name: "small", label: "Small", sizeMb: 466 },
  { name: "medium", label: "Medium", sizeMb: 1500 },
  { name: "large-v3-turbo", label: "Large v3 Turbo (recommended)", sizeMb: 1600 },
  { name: "large-v3", label: "Large v3 (max accuracy, 3.1 GB)", sizeMb: 3100 },
];

/** ISO 639-1 languages Whisper supports well. */
const WHISPER_LANGUAGES: { code: string; label: string }[] = [
  { code: "auto", label: "Auto-detect" },
  { code: "en", label: "English" },
  { code: "es", label: "Spanish" },
  { code: "fr", label: "French" },
  { code: "de", label: "German" },
  { code: "it", label: "Italian" },
  { code: "pt", label: "Portuguese" },
  { code: "nl", label: "Dutch" },
  { code: "pl", label: "Polish" },
  { code: "ru", label: "Russian" },
  { code: "ja", label: "Japanese" },
  { code: "zh", label: "Chinese" },
  { code: "ko", label: "Korean" },
  { code: "ar", label: "Arabic" },
  { code: "hi", label: "Hindi" },
  { code: "tr", label: "Turkish" },
  { code: "sv", label: "Swedish" },
  { code: "uk", label: "Ukrainian" },
];

function mediaNameFromPath(path: string, fallback = "Untitled") {
  return (
    path
      .split(/[\\/]/)
      .pop()
      ?.replace(/\.[^.]+$/, "") || fallback
  );
}

function wordsForMedia(project: Project, mediaId: string) {
  return project.segments
    .filter((segment) => segment.mediaId === mediaId)
    .flatMap((segment) => segment.words);
}

function applyTranscriptToMedia(
  project: Project,
  mediaId: string,
  words: Word[],
  force = false,
): Project {
  return {
    ...project,
    originalTranscripts: { ...project.originalTranscripts, [mediaId]: words },
    segments: project.segments.map((segment) => {
      if (segment.mediaId !== mediaId) return segment;
      // In normal mode skip segments that already have words; in force mode overwrite all.
      if (!force && segment.words.length > 0) return segment;
      return {
        ...segment,
        words: words.filter(
          (word) => word.end > segment.sourceIn && word.start < segment.sourceOut,
        ),
      };
    }),
    updatedAt: new Date().toISOString(),
  };
}

export function Toolbar() {
  const project = useProjectStore((s) => s.project);
  const filePath = useProjectStore((s) => s.filePath);

  const transcribeProgress = useUIStore((s) => s.transcribeProgress);
  const exportingProgress = useUIStore((s) => s.exportingProgress);
  // True while the finished file is being measured (the export itself is done).
  const [measuringLoudness, setMeasuringLoudness] = useState(false);
  useEffect(() => {
    let off: (() => void) | undefined;
    void onExportMeasuring(() => setMeasuringLoudness(true)).then((u) => (off = u));
    return () => off?.();
  }, []);
  const modelDownloadProgress = useUIStore((s) => s.modelDownloadProgress);
  const modelDownloadLabel = useUIStore((s) => s.modelDownloadLabel);
  const pushToast = useUIStore((s) => s.pushToast);
  const setMediaLoading = useUIStore((s) => s.setMediaLoading);
  const setExportingProgress = useUIStore((s) => s.setExportingProgress);
  const setTranscribeProgress = useUIStore((s) => s.setTranscribeProgress);
  const [modelDialogOpen, setModelDialogOpen] = useState(false);
  const [exportDialogOpen, setExportDialogOpen] = useState(false);
  const [selectedModel, setSelectedModel] = useState<WhisperModel>("large-v3-turbo");
  const [transcribeLanguage, setTranscribeLanguage] = useState("auto");
  const [transcribeTranslate, setTranscribeTranslate] = useState(false);
  const [transcribeDiarize, setTranscribeDiarize] = useState(false);
  const [installedModels, setInstalledModels] = useState<ModelInfo[]>([]);
  // Burn-in lives in the UI store: the preview reads it to place the key caps like the export.
  const burnCaptions = useUIStore((s) => s.burnCaptions);
  const setBurnCaptions = useUIStore((s) => s.setBurnCaptions);
  const [exportSettings, setExportSettings] = useState({
    resolution: "original" as ExportUiSettings["resolution"],
    customWidth: 1920,
    customHeight: 1080,
    videoBitrateKbps: 8000,
    audioBitrateKbps: 192,
    fps: "",
    codec: "auto" as "auto" | "h264" | "hevc",
    /** When true, bypass smart-cut and re-encode every frame. */
    forceReencode: false,
    format: "mp4" as ExportFormat,
    /** Optional output-timeline span in seconds; empty means the whole edit. */
    rangeStart: "",
    rangeEnd: "",
    stems: false,
    /** Target loudness in LUFS as a string; empty means off. */
    loudness: "",
    stripCaptionEmoji: false,
  });
  // The podcast preset is audio only: handleExport switches a video format to
  // M4A when the dialog opens and the video options are disabled, so the
  // format shown is always the one written.
  const podcastPreset = project.settings.exportPreset === "podcast-audio";
  const exportFormat = exportSettings.format;
  const exportFormatInfo = EXPORT_FORMATS[exportFormat];
  const exportUi = useMemo<ExportUiSettings>(() => {
    const { rangeStart, rangeEnd, loudness, ...rest } = exportSettings;
    return {
      ...rest,
      burnCaptions,
      ...(loudness !== "" ? { loudnessLufs: Number(loudness) } : {}),
      ...(rangeStart !== "" ? { rangeStart: Number(rangeStart) } : {}),
      ...(rangeEnd !== "" ? { rangeEnd: Number(rangeEnd) } : {}),
    };
  }, [exportSettings, burnCaptions]);
  const exportProblem = exportRequestProblem(project, exportUi);
  const exportAlphaWarning = transparencyWarning(project, exportFormat);
  const captionNotes = useMemo(
    () => (exportDialogOpen && burnCaptions ? captionBurnNotes(project) : null),
    [exportDialogOpen, burnCaptions, project],
  );
  // Which model is currently being downloaded inside the dialog, and its progress.
  const [downloadingModel, setDownloadingModel] = useState<string | null>(null);
  const [downloadProgress, setDownloadProgress] = useState(0);
  const [downloadLabel, setDownloadLabel] = useState("Downloading…");
  const [deletingModel, setDeletingModel] = useState<string | null>(null);
  const [musicDialogOpen, setMusicDialogOpen] = useState(false);
  const [snapshotsDialogOpen, setSnapshotsDialogOpen] = useState(false);
  const unlistenDownloadRef = useRef<(() => void) | null>(null);
  /** Set to true before opening the model dialog when the user clicks Re-Transcribe. */
  const forceRetranscribeRef = useRef(false);

  /** True when at least one segment already has transcribed words. */
  const hasTranscript = project.segments.some((s) => s.words.length > 0);

  const resetPlayer = useCallback(() => {
    usePlayerStore.getState().reset();
  }, []);

  const handleOpen = useCallback(async () => {
    const path = await openDialog({
      multiple: false,
      filters: [{ name: "Media", extensions: MEDIA_EXTENSIONS }],
    });
    if (typeof path !== "string") return;
    setMediaLoading(true);
    try {
      const media = await importMedia(path);
      const name = mediaNameFromPath(media.path);
      const cachedWords = readTranscriptCache(media);
      const nextProject = buildProjectWithMedia(newProject(name), media, cachedWords ?? []);
      resetPlayer();
      replaceProjectBaseline(nextProject, { dirty: true, filePath: null });
      pushToast({
        title: cachedWords ? "Media imported with cached transcript" : "Media imported",
        description: media.path,
      });
    } catch (err) {
      pushToast({
        title: "Failed to import media",
        description: String(err),
        variant: "destructive",
      });
    } finally {
      setMediaLoading(false);
    }
  }, [setMediaLoading, pushToast, resetPlayer]);

  const handleAddClip = useCallback(async () => {
    const path = await openDialog({
      multiple: false,
      filters: [{ name: "Media", extensions: MEDIA_EXTENSIONS }],
    });
    if (typeof path !== "string") return;
    setMediaLoading(true);
    try {
      const before = useProjectStore.getState().project;
      const appendAt = totalDuration(before);
      const media = await importMedia(path);
      const cachedWords = readTranscriptCache(media) ?? [];
      useProjectStore.getState().addMediaWithTranscript(media, cachedWords);
      usePlayerStore.getState().clearTimelineRange();
      usePlayerStore.getState().setSelectedWordIds(new Set());
      window.dispatchEvent(new CustomEvent("yusafcut:seek-output", { detail: { time: appendAt } }));
      pushToast({
        title: cachedWords.length > 0 ? "Clip added with cached transcript" : "Clip added",
        description:
          cachedWords.length > 0 ? media.path : "Click Transcribe to generate text for this clip.",
      });
    } catch (err) {
      pushToast({
        title: "Failed to add clip",
        description: String(err),
        variant: "destructive",
      });
    } finally {
      setMediaLoading(false);
    }
  }, [setMediaLoading, pushToast]);

  const handleCloseProject = useCallback(() => {
    replaceProjectBaseline(newProject("Untitled"), { dirty: false, filePath: null });
    resetPlayer();
    pushToast({ title: "Project closed" });
  }, [pushToast, resetPlayer]);

  const handleNewProject = useCallback(() => {
    replaceProjectBaseline(newProject("Untitled"), { dirty: false, filePath: null });
    resetPlayer();
  }, [resetPlayer]);

  const openProjectAtPath = useCallback(
    async (path: string) => {
      try {
        await openProjectAtPathAction(path);
      } catch (err) {
        pushToast({
          title: "Failed to open project",
          description: String(err),
          variant: "destructive",
        });
      }
    },
    [pushToast],
  );

  const handleOpenProject = useCallback(async () => {
    const path = await openDialog({
      multiple: false,
      filters: [{ name: "WordsCut project", extensions: ["scribe"] }],
    });
    if (typeof path !== "string") return;
    await openProjectAtPath(path);
  }, [openProjectAtPath]);

  const refreshModelList = useCallback(async () => {
    try {
      const info = await listModels();
      setInstalledModels(info);
    } catch {
      setInstalledModels([]);
    }
  }, []);

  const handleTranscribe = useCallback(async () => {
    const mediaIds = Array.from(new Set(project.segments.map((segment) => segment.mediaId)));
    if (mediaIds.length === 0) {
      pushToast({ title: "Open a video first", variant: "destructive" });
      return;
    }
    forceRetranscribeRef.current = false;
    await refreshModelList();
    setModelDialogOpen(true);
  }, [project, pushToast, refreshModelList]);

  const handleReTranscribe = useCallback(async () => {
    const mediaIds = Array.from(new Set(project.segments.map((segment) => segment.mediaId)));
    if (mediaIds.length === 0) return;
    forceRetranscribeRef.current = true;
    await refreshModelList();
    setModelDialogOpen(true);
  }, [project, refreshModelList]);

  /** Download a single model from within the dialog, updating inline progress. */
  async function handleDownloadModel(name: string) {
    if (downloadingModel) return; // already downloading something

    setDownloadingModel(name);
    setDownloadProgress(0);

    // Subscribe to download progress events so the inline bar updates live.
    const unlisten = await onModelDownloadProgress((p) => {
      if (p.name === name) {
        setDownloadProgress(p.progress);
        if (p.label) setDownloadLabel(p.label);
      }
    });
    unlistenDownloadRef.current = unlisten;

    try {
      await downloadModel("whisper-cpp", name);
      // Mark as installed in local state immediately.
      setInstalledModels((prev) =>
        prev.map((m) => (m.name === name ? { ...m, installed: true } : m)),
      );
      // Auto-select the freshly downloaded model.
      setSelectedModel(name as WhisperModel);
    } catch (err) {
      pushToast({
        title: "Download failed",
        description: String(err),
        variant: "destructive",
      });
    } finally {
      unlisten();
      unlistenDownloadRef.current = null;
      setDownloadingModel(null);
      setDownloadProgress(0);
      setDownloadLabel("Downloading…");
    }
  }

  /** Delete a downloaded model after confirmation. */
  async function handleDeleteModel(name: string) {
    // Prevent deletion while a transcription using this model is running.
    if (
      transcribeProgress !== null ||
      Object.keys(useUIStore.getState().backgroundTranscriptions).length > 0
    ) {
      pushToast({
        title: "Cannot remove model",
        description: "A transcription is currently running with this model. Wait for it to finish.",
        variant: "destructive",
      });
      return;
    }

    const confirmed = window.confirm("Remove this downloaded model from your computer?");
    if (!confirmed) return;

    setDeletingModel(name);
    try {
      await deleteModel("whisper-cpp", name);
      setInstalledModels((prev) =>
        prev.map((m) => (m.name === name ? { ...m, installed: false } : m)),
      );
      // If the deleted model was selected, fall back to large-v3-turbo if installed.
      if (selectedModel === name) {
        const fallback = installedModels.find((m) => m.name !== name && m.installed);
        if (fallback) setSelectedModel(fallback.name as WhisperModel);
      }
      pushToast({ title: "Model removed", description: `${name} deleted from disk.` });
    } catch (err) {
      pushToast({
        title: "Remove failed",
        description: String(err),
        variant: "destructive",
      });
    } finally {
      setDeletingModel(null);
    }
  }

  // Clean up progress listener if the dialog is closed mid-download.
  useEffect(() => {
    if (!modelDialogOpen && unlistenDownloadRef.current) {
      unlistenDownloadRef.current();
      unlistenDownloadRef.current = null;
      setDownloadingModel(null);
      setDownloadProgress(0);
    }
  }, [modelDialogOpen]);

  /**
   * Best-effort pause detection for a freshly-transcribed clip. Stores the
   * result in projectStore.pauseTokens (which always REPLACES, so re-running
   * never duplicates badges) and surfaces a non-blocking toast. Failures here
   * never fail transcription — they are reported but swallowed.
   */
  const autoDetectPauses = useCallback(
    async (mediaPath: string) => {
      try {
        const pauses = await detectPauses({ mediaPath, noiseThreshold: -35, minDuration: 0.5 });
        useProjectStore.getState().setPauseTokens(pauses);
        pushToast(
          pauses.length > 0
            ? { title: `Detected ${pauses.length} pause${pauses.length === 1 ? "" : "s"}` }
            : { title: "No pauses found" },
        );
      } catch (err) {
        // Non-fatal: transcription already succeeded.
        pushToast({ title: "Pause detection failed", description: String(err) });
      }
    },
    [pushToast],
  );

  async function startTranscribe() {
    setModelDialogOpen(false);
    const force = forceRetranscribeRef.current;
    forceRetranscribeRef.current = false; // reset immediately

    const mediaIds = Array.from(new Set(project.segments.map((segment) => segment.mediaId)));
    if (mediaIds.length === 0) return;

    // Show the transcription progress dialog immediately — before the first
    // Whisper event arrives so the user sees feedback right away.
    setTranscribeProgress(0);

    if (force) {
      pushToast({
        title: "Re-transcribing…",
        description: "Clearing existing transcript and starting fresh.",
      });
    }

    try {
      // ── Step 1: download the model if it isn't on disk yet ──────────────
      const isInstalled = installedModels.find((m) => m.name === selectedModel)?.installed ?? false;
      if (!isInstalled) {
        pushToast({
          title: `Downloading ${selectedModel}…`,
          description: "This may take a few minutes. Progress shown in the toolbar.",
        });
        await downloadModel("whisper-cpp", selectedModel);
        pushToast({ title: "Model downloaded — starting transcription…" });
      }

      // ── Step 2: clear caches when re-transcribing ────────────────────────
      let nextProject = useProjectStore.getState().project;
      if (force) {
        for (const mediaId of mediaIds) {
          const media = nextProject.media[mediaId];
          if (media) clearTranscriptCache(media);
        }
      }

      // ── Step 3: transcribe each clip ─────────────────────────────────────
      let totalWords = 0;
      let transcribedClips = 0;
      for (const mediaId of mediaIds) {
        const media = nextProject.media[mediaId];
        if (!media) continue;
        const cached = force ? null : readTranscriptCache(media);
        const existingWords = wordsForMedia(nextProject, mediaId);
        if (!force && existingWords.length > 0) {
          totalWords += existingWords.length;
          continue;
        }
        let words: Word[];
        if (cached) {
          words = cached; // cache already contains snapped timestamps
        } else {
          words = (
            await transcribe({
              mediaId,
              mediaPath: media.path,
              engine: "whisper-cpp",
              modelName: selectedModel,
              mediaDuration: media.duration,
              language: transcribeLanguage === "auto" ? undefined : transcribeLanguage,
              translate: transcribeTranslate,
              diarize: transcribeDiarize,
            })
          ).words;
          // Snap word boundaries to signal-level silence edges (best-effort —
          // a silencedetect failure must never fail the transcription).
          try {
            const silences = await detectPauses({
              mediaPath: media.path,
              noiseThreshold: -35,
              minDuration: 0.5,
            });
            words = snapWordsToSilences(words, silences);
          } catch {
            /* non-fatal */
          }
        }
        writeTranscriptCache(media, words);
        nextProject = applyTranscriptToMedia(nextProject, mediaId, words, force);
        totalWords += words.length;
        transcribedClips++;
      }

      replaceProjectBaseline(nextProject, { dirty: true, filePath });
      pushToast({
        title: force ? "Re-transcription complete" : "Transcription complete",
        description:
          transcribedClips > 0
            ? `${totalWords} words across ${mediaIds.length} clip${mediaIds.length === 1 ? "" : "s"}`
            : "All clips already had transcript text",
      });

      // Automatically surface pauses so the user sees inline [0.6s] badges
      // without having to open Edit → Show pauses. Best-effort, non-blocking.
      const primaryPath = Object.values(nextProject.media)[0]?.path;
      if (primaryPath && totalWords > 0) {
        await autoDetectPauses(primaryPath);
      }
    } catch (err) {
      pushToast({
        title: force ? "Re-transcription failed" : "Transcription failed",
        description: String(err),
        variant: "destructive",
      });
    } finally {
      // Always hide the progress dialog — whether we succeeded, errored, or
      // skipped transcription entirely (all clips already had words).
      setTranscribeProgress(null);
    }
  }

  const handleSave = useCallback(async () => {
    let path = filePath;
    if (!path) {
      const next = await saveDialog({
        defaultPath: `${project.name}.scribe`,
        filters: [{ name: "WordsCut project", extensions: ["scribe"] }],
      });
      if (!next) return;
      path = next;
    }
    try {
      const result = await saveProjectRevision(project, path, filePath);
      if (result.status === "saved") {
        addRecentProject(path);
        pushToast({
          title: result.current ? "Saved" : "Snapshot saved; newer edits remain unsaved",
        });
      }
    } catch (err) {
      pushToast({
        title: "Save failed",
        description: String(err),
        variant: "destructive",
      });
    }
  }, [filePath, project, pushToast]);

  const runExport = useCallback(async () => {
    // Checked before the save dialog so a bad range never costs a file pick.
    if (exportProblem) {
      pushToast({ title: "Can't export", description: exportProblem, variant: "destructive" });
      return;
    }
    const { ext, label } = EXPORT_FORMATS[exportFormat];
    const outPath = await saveDialog({
      defaultPath: `${project.name}.${ext}`,
      filters: [{ name: label, extensions: [ext] }],
    });
    if (!outPath) return;
    const opts = buildExportOptions(project, exportUi, outPath);

    // Show the export progress dialog immediately so the user sees feedback
    // before the first ffmpeg progress event arrives.
    setExportingProgress(0);

    try {
      const report = await exportVideo(opts);
      const levels = describeAudioReport(report?.audio);
      pushToast(
        levels?.clipped
          ? {
              title: "Export complete, but the audio clips",
              description: `${outPath}\n${levels.text}. Lower the music gain or set a loudness target.`,
              variant: "destructive",
            }
          : {
              title: "Export complete",
              description: levels ? `${outPath}\n${levels.text}` : outPath,
            },
      );
    } catch (err) {
      pushToast({
        title: "Export failed",
        description: String(err),
        variant: "destructive",
      });
    } finally {
      // Always hide the progress dialog — covers both success and ffmpeg errors.
      // On success, the Rust backend already emitted progress=1.0 which would
      // also set this to null via useTranscribeProgress, but being explicit here
      // ensures the dialog closes even if the event is lost.
      setExportingProgress(null);
      setMeasuringLoudness(false);
    }
  }, [exportFormat, exportProblem, exportUi, project, pushToast, setExportingProgress]);

  const handleExport = useCallback(() => {
    if (Object.keys(project.media).length === 0 || project.segments.length === 0) {
      pushToast({ title: "Nothing to export", variant: "destructive" });
      return;
    }
    if (project.settings.exportPreset === "podcast-audio")
      setExportSettings((s) => (EXPORT_FORMATS[s.format].audio ? s : { ...s, format: "m4a" }));
    setExportDialogOpen(true);
  }, [project, pushToast]);

  // ── Caption export (SRT / VTT) ──────────────────────────────────────────
  // Captions reflect the *output* timeline, so deletes and clip reordering
  // carry over to the .srt/.vtt without the user having to think about it.
  const handleExportCaptions = useCallback(async () => {
    const hasWords = project.segments.some((s) => s.words.length > 0);
    if (!hasWords) {
      pushToast({
        title: "No captions to export",
        description: "Transcribe the clip first to generate word timings.",
        variant: "destructive",
      });
      return;
    }
    const outPath = await saveDialog({
      defaultPath: `${project.name}.srt`,
      filters: [
        { name: "SubRip subtitles", extensions: ["srt"] },
        { name: "WebVTT captions", extensions: ["vtt"] },
      ],
    });
    if (!outPath) return;
    const isVtt = outPath.toLowerCase().endsWith(".vtt");
    try {
      const content = isVtt ? buildVtt(project) : buildSrt(project);
      await writeTextFile(outPath, content);
      pushToast({
        title: isVtt ? "WebVTT exported" : "SRT exported",
        description: outPath,
      });
    } catch (err) {
      pushToast({
        title: "Caption export failed",
        description: String(err),
        variant: "destructive",
      });
    }
  }, [project, pushToast]);

  // ── FCPXML export (Final Cut Pro / compatible NLEs) ─────────────────────
  // The FCPXML points at the original media: privacy masks cannot travel with
  // it, so the user must confirm first (Cancel is the default button).
  const [fcpxmlMaskConfirm, setFcpxmlMaskConfirm] = useState(false);
  const handleExportFcpxml = useCallback(
    async (masksConfirmed = false) => {
      if (project.segments.length === 0) {
        pushToast({ title: "Nothing to export", variant: "destructive" });
        return;
      }
      if ((project.masks?.length ?? 0) > 0 && !masksConfirmed) {
        setFcpxmlMaskConfirm(true);
        return;
      }
      const outPath = await saveDialog({
        defaultPath: `${project.name}.fcpxml`,
        filters: [{ name: "Final Cut Pro XML", extensions: ["fcpxml"] }],
      });
      if (!outPath) return;
      try {
        const { xml, unsupported } = buildFcpxml(project);
        await writeTextFile(outPath, xml);
        pushToast({
          title: "FCPXML exported",
          description: unsupported.length
            ? `${outPath}\nNot included: ${unsupported.join("; ")}`
            : outPath,
        });
      } catch (err) {
        pushToast({
          title: "FCPXML export failed",
          description: String(err),
          variant: "destructive",
        });
      }
    },
    [project, pushToast],
  );

  useEffect(() => {
    const onTranscribe = () => {
      if (hasTranscript) {
        void handleReTranscribe();
      } else {
        void handleTranscribe();
      }
    };
    const onOpen = () => void handleOpen();
    const onAddClip = () => void handleAddClip();
    const onMusic = () => setMusicDialogOpen(true);
    const onSnapshots = () => setSnapshotsDialogOpen(true);
    const onExportCaptions = () => void handleExportCaptions();
    const onExportFcpxml = () => void handleExportFcpxml();
    const onNewProject = () => handleNewProject();
    const onOpenProject = () => void handleOpenProject();
    const onOpenProjectPath = (e: Event) => {
      const path = (e as CustomEvent<{ path: string }>).detail?.path;
      if (path) void openProjectAtPath(path);
    };
    const onCloseProject = () => handleCloseProject();

    window.addEventListener("yusafcut:save", handleSave);
    window.addEventListener("yusafcut:export", handleExport);
    window.addEventListener("yusafcut:transcribe", onTranscribe);
    window.addEventListener("yusafcut:open", onOpen);
    window.addEventListener("yusafcut:add-clip", onAddClip);
    window.addEventListener("yusafcut:music", onMusic);
    window.addEventListener("yusafcut:snapshots", onSnapshots);
    window.addEventListener("yusafcut:export-captions", onExportCaptions);
    window.addEventListener("yusafcut:export-fcpxml", onExportFcpxml);
    window.addEventListener("yusafcut:new-project", onNewProject);
    window.addEventListener("yusafcut:open-project", onOpenProject);
    window.addEventListener("yusafcut:open-project-path", onOpenProjectPath);
    window.addEventListener("yusafcut:close-project", onCloseProject);

    return () => {
      window.removeEventListener("yusafcut:save", handleSave);
      window.removeEventListener("yusafcut:export", handleExport);
      window.removeEventListener("yusafcut:transcribe", onTranscribe);
      window.removeEventListener("yusafcut:open", onOpen);
      window.removeEventListener("yusafcut:add-clip", onAddClip);
      window.removeEventListener("yusafcut:music", onMusic);
      window.removeEventListener("yusafcut:snapshots", onSnapshots);
      window.removeEventListener("yusafcut:export-captions", onExportCaptions);
      window.removeEventListener("yusafcut:export-fcpxml", onExportFcpxml);
      window.removeEventListener("yusafcut:new-project", onNewProject);
      window.removeEventListener("yusafcut:open-project", onOpenProject);
      window.removeEventListener("yusafcut:open-project-path", onOpenProjectPath);
      window.removeEventListener("yusafcut:close-project", onCloseProject);
    };
  }, [
    handleSave,
    handleExport,
    handleTranscribe,
    handleReTranscribe,
    handleExportCaptions,
    handleExportFcpxml,
    handleNewProject,
    handleOpenProject,
    openProjectAtPath,
    handleCloseProject,
    handleOpen,
    handleAddClip,
    hasTranscript,
  ]);

  return (
    <>
      <FcpxmlMaskDialog
        open={fcpxmlMaskConfirm}
        onCancel={() => setFcpxmlMaskConfirm(false)}
        onConfirm={() => {
          setFcpxmlMaskConfirm(false);
          void handleExportFcpxml(true);
        }}
      />
      <Dialog open={modelDialogOpen} onOpenChange={setModelDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>
              {forceRetranscribeRef.current ? "Re-Transcribe" : "Transcription settings"}
            </DialogTitle>
            <DialogDescription>
              {forceRetranscribeRef.current
                ? "This will clear the existing transcript and re-run Whisper from scratch."
                : "Choose an engine, model, and language. Larger models are more accurate but slower."}
            </DialogDescription>
          </DialogHeader>

          {/* ── Engine info ── */}
          <p className="text-xs text-muted-foreground rounded-md border border-border px-3 py-2">
            <span className="font-semibold text-foreground">whisper.cpp · Core ML</span> — runs 100%
            locally with Apple Silicon acceleration. Tight word-level timestamps for accurate
            video/text sync.
          </p>

          {/* ── Model list ── */}
          <div className="flex max-h-56 flex-col gap-2 overflow-y-auto pr-1">
            {MODELS.map((m) => {
              const installed = installedModels.find((i) => i.name === m.name)?.installed ?? false;
              const isDownloading = downloadingModel === m.name;
              const isOtherDownloading = downloadingModel !== null && !isDownloading;
              const isDeleting = deletingModel === m.name;
              const isSelected = selectedModel === m.name;

              return (
                <div
                  key={m.name}
                  className={`rounded-md border p-3 transition-colors ${
                    isSelected ? "border-primary bg-accent" : "border-border hover:bg-accent/50"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <label className="flex cursor-pointer items-center gap-2 text-sm font-medium">
                      <input
                        type="radio"
                        name="model"
                        value={m.name}
                        checked={isSelected}
                        disabled={!installed}
                        onChange={() => setSelectedModel(m.name as WhisperModel)}
                      />
                      {m.label}
                    </label>
                    {installed ? (
                      <div className="flex items-center gap-2">
                        <span className="flex items-center gap-1 text-xs text-green-600 dark:text-green-400">
                          <CheckCircle2 className="h-3.5 w-3.5" />
                          Installed
                        </span>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-6 px-2 text-xs text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                          disabled={
                            isDeleting || downloadingModel !== null || transcribeProgress !== null
                          }
                          title="Remove this model from disk"
                          onClick={(e) => {
                            e.stopPropagation();
                            void handleDeleteModel(m.name);
                          }}
                        >
                          {isDeleting ? "Removing…" : "Remove"}
                        </Button>
                      </div>
                    ) : isDownloading ? (
                      <span className="text-xs text-muted-foreground">
                        {Math.round(downloadProgress * 100)}%
                      </span>
                    ) : (
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-7 gap-1 px-2 text-xs"
                        disabled={isOtherDownloading}
                        onClick={(e) => {
                          e.stopPropagation();
                          void handleDownloadModel(m.name);
                        }}
                      >
                        <Download className="h-3 w-3" />
                        {m.sizeMb >= 1000 ? `${(m.sizeMb / 1000).toFixed(1)} GB` : `${m.sizeMb} MB`}
                      </Button>
                    )}
                  </div>
                  {isDownloading && (
                    <div className="mt-2">
                      <Progress value={downloadProgress * 100} className="h-1.5" />
                      <p className="mt-1 text-xs text-muted-foreground">
                        {downloadLabel} — {Math.round(downloadProgress * 100)}% — do not close
                      </p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* ── Language / options ── */}
          <div className="grid gap-3 rounded-md border border-border p-3">
            <label className="grid gap-1 text-xs font-medium text-muted-foreground">
              Source language
              <select
                className="h-8 rounded border border-input bg-background px-2 text-sm text-foreground"
                value={transcribeLanguage}
                onChange={(e) => setTranscribeLanguage(e.target.value)}
              >
                {WHISPER_LANGUAGES.map((l) => (
                  <option key={l.code} value={l.code}>
                    {l.label}
                  </option>
                ))}
              </select>
            </label>

            {/* translate + diarize */}
            <div className="flex flex-col gap-2">
              <label className="flex cursor-pointer items-center gap-2 text-xs">
                <input
                  type="checkbox"
                  checked={transcribeTranslate}
                  onChange={(e) => setTranscribeTranslate(e.target.checked)}
                />
                <span>
                  <span className="font-medium">Translate to English</span>
                  <span className="ml-1 text-muted-foreground">
                    — output English regardless of source
                  </span>
                </span>
              </label>
              <label className="flex cursor-pointer items-center gap-2 text-xs">
                <input
                  type="checkbox"
                  checked={transcribeDiarize}
                  onChange={(e) => setTranscribeDiarize(e.target.checked)}
                />
                <span>
                  <span className="font-medium">Speaker diarisation</span>
                  <span className="ml-1 text-muted-foreground">— label who is speaking</span>
                </span>
              </label>
            </div>
          </div>

          <DialogFooter>
            <Button
              onClick={() => setModelDialogOpen(false)}
              variant="outline"
              disabled={downloadingModel !== null}
            >
              Cancel
            </Button>
            <Button
              onClick={startTranscribe}
              disabled={
                downloadingModel !== null ||
                !installedModels.find((m) => m.name === selectedModel)?.installed
              }
              variant={forceRetranscribeRef.current ? "destructive" : "default"}
            >
              {forceRetranscribeRef.current ? "Re-Transcribe" : "Transcribe"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={exportDialogOpen} onOpenChange={setExportDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Export</DialogTitle>
            <DialogDescription>
              Choose format, resolution and quality before rendering the edited timeline.
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-1">
            <label className="grid gap-1.5 text-sm">
              Format
              <select
                className="h-9 rounded-md border border-input bg-background px-3 text-sm"
                value={exportFormat}
                onChange={(e) =>
                  setExportSettings((s) => ({ ...s, format: e.target.value as ExportFormat }))
                }
              >
                {Object.entries(EXPORT_FORMATS).map(([value, f]) => (
                  <option key={value} value={value} disabled={podcastPreset && !f.audio}>
                    {f.label}
                  </option>
                ))}
              </select>
              {podcastPreset && (
                <span className="text-xs text-muted-foreground">
                  The Podcast audio preset exports audio only.
                </span>
              )}
            </label>

            {exportFormatInfo.audio && (
              <label className="flex cursor-pointer items-center gap-2 text-xs text-muted-foreground">
                <input
                  type="checkbox"
                  checked={exportSettings.stems}
                  onChange={(e) => setExportSettings((s) => ({ ...s, stems: e.target.checked }))}
                />
                Also export stems (one file per recorded source and music track)
              </label>
            )}

            {exportFormat !== "gif" && (
              <label className="grid gap-1.5 text-sm">
                Loudness target
                <select
                  className="h-9 rounded-md border border-input bg-background px-3 text-sm"
                  value={exportSettings.loudness}
                  onChange={(e) => setExportSettings((s) => ({ ...s, loudness: e.target.value }))}
                >
                  <option value="">Off (keep levels as they are)</option>
                  <option value="-16">-16 LUFS (podcast)</option>
                  <option value="-14">-14 LUFS (streaming)</option>
                  <option value="-23">-23 LUFS (broadcast, EBU R128)</option>
                </select>
                <span className="text-xs text-muted-foreground">
                  Single-pass normalisation of the mix with a -1.5 dBTP ceiling; forces a full
                  re-encode. Stems are not normalised. The result shows the measured loudness.
                </span>
              </label>
            )}
            {!exportFormatInfo.audio && (
              <label className="flex cursor-pointer items-center gap-2 text-xs text-muted-foreground">
                <input
                  type="checkbox"
                  checked={burnCaptions}
                  onChange={(e) => setBurnCaptions(e.target.checked)}
                />
                Burn in captions (style in the Captions tab; forces a full re-encode)
              </label>
            )}
            {!exportFormatInfo.audio && captionNotes && (
              <div className="space-y-1 text-xs text-muted-foreground">
                {captionNotes.noTranscript && (
                  <p role="alert" className="text-destructive">
                    There is no transcript, so no captions will be burned in. Transcribe first.
                  </p>
                )}
                {captionNotes.emojiCues > 0 && (
                  <>
                    <p role="alert" className="text-destructive">
                      {captionNotes.emojiCues} caption{captionNotes.emojiCues === 1 ? "" : "s"}{" "}
                      contain emoji. They show in the preview but will not appear in the burned-in
                      video.
                    </p>
                    <label className="flex cursor-pointer items-center gap-2">
                      <input
                        type="checkbox"
                        checked={exportSettings.stripCaptionEmoji}
                        onChange={(e) =>
                          setExportSettings((s) => ({ ...s, stripCaptionEmoji: e.target.checked }))
                        }
                      />
                      Remove emoji from burned captions
                    </label>
                  </>
                )}
                {captionNotes.glyphCues > 0 && (
                  <p role="alert">
                    {captionNotes.glyphCues} caption{captionNotes.glyphCues === 1 ? "" : "s"} use
                    characters that may not draw in the burned-in video. Check the export.
                  </p>
                )}
                {captionNotes.invisibleCues > 0 && (
                  <p role="alert">
                    {captionNotes.invisibleCues} caption
                    {captionNotes.invisibleCues === 1 ? "" : "s"} have no duration and will not be
                    drawn.
                  </p>
                )}
              </div>
            )}

            <div className="grid grid-cols-2 gap-3">
              <label className="grid gap-1.5 text-sm">
                From (seconds)
                <input
                  className="h-9 rounded-md border border-input bg-background px-3 text-sm"
                  type="number"
                  min={0}
                  step={0.1}
                  placeholder="Start"
                  value={exportSettings.rangeStart}
                  onChange={(e) => setExportSettings((s) => ({ ...s, rangeStart: e.target.value }))}
                />
              </label>
              <label className="grid gap-1.5 text-sm">
                To (seconds)
                <input
                  className="h-9 rounded-md border border-input bg-background px-3 text-sm"
                  type="number"
                  min={0}
                  step={0.1}
                  placeholder="End"
                  value={exportSettings.rangeEnd}
                  onChange={(e) => setExportSettings((s) => ({ ...s, rangeEnd: e.target.value }))}
                />
              </label>
            </div>
            <label className="grid gap-1.5 text-sm">
              Resolution
              <select
                className="h-9 rounded-md border border-input bg-background px-3 text-sm"
                value={exportSettings.resolution}
                onChange={(e) =>
                  setExportSettings((s) => ({
                    ...s,
                    resolution: e.target.value as ExportUiSettings["resolution"],
                  }))
                }
              >
                <option value="original">Original</option>
                <option value="720p">1280 x 720</option>
                <option value="1080p">1920 x 1080</option>
                <option value="4k">3840 x 2160</option>
                <option value="custom">Custom</option>
              </select>
            </label>

            {exportSettings.resolution === "custom" && (
              <div className="grid grid-cols-2 gap-3">
                <label className="grid gap-1.5 text-sm">
                  Width
                  <input
                    className="h-9 rounded-md border border-input bg-background px-3 text-sm"
                    type="number"
                    min={16}
                    step={2}
                    value={exportSettings.customWidth}
                    onChange={(e) =>
                      setExportSettings((s) => ({ ...s, customWidth: Number(e.target.value) }))
                    }
                  />
                </label>
                <label className="grid gap-1.5 text-sm">
                  Height
                  <input
                    className="h-9 rounded-md border border-input bg-background px-3 text-sm"
                    type="number"
                    min={16}
                    step={2}
                    value={exportSettings.customHeight}
                    onChange={(e) =>
                      setExportSettings((s) => ({ ...s, customHeight: Number(e.target.value) }))
                    }
                  />
                </label>
              </div>
            )}

            <div className="grid grid-cols-2 gap-3">
              <label className="grid gap-1.5 text-sm">
                Codec
                <select
                  className="h-9 rounded-md border border-input bg-background px-3 text-sm disabled:opacity-50"
                  disabled={exportFormat !== "mp4" && exportFormat !== "mov"}
                  value={exportSettings.codec}
                  onChange={(e) =>
                    setExportSettings((s) => ({
                      ...s,
                      codec: e.target.value as "auto" | "h264" | "hevc",
                    }))
                  }
                >
                  <option value="auto">Match source (smart-cut)</option>
                  <option value="h264">H.264 (re-encode)</option>
                  <option value="hevc">HEVC (re-encode)</option>
                </select>
              </label>
              <label className="grid gap-1.5 text-sm">
                Frame rate
                <input
                  className="h-9 rounded-md border border-input bg-background px-3 text-sm"
                  type="number"
                  min={1}
                  step={1}
                  placeholder="Original"
                  value={exportSettings.fps}
                  onChange={(e) => setExportSettings((s) => ({ ...s, fps: e.target.value }))}
                />
              </label>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <label className="grid gap-1.5 text-sm">
                Video bitrate
                <div className="flex items-center gap-2">
                  <input
                    className="flex-1"
                    type="range"
                    min={1500}
                    max={30000}
                    step={500}
                    value={exportSettings.videoBitrateKbps}
                    onChange={(e) =>
                      setExportSettings((s) => ({
                        ...s,
                        videoBitrateKbps: Number(e.target.value),
                      }))
                    }
                  />
                  <span className="w-16 text-right text-xs tabular-nums text-muted-foreground">
                    {(exportSettings.videoBitrateKbps / 1000).toFixed(1)} Mbps
                  </span>
                </div>
              </label>
              <label className="grid gap-1.5 text-sm">
                Audio bitrate
                <select
                  className="h-9 rounded-md border border-input bg-background px-3 text-sm"
                  value={exportSettings.audioBitrateKbps}
                  onChange={(e) =>
                    setExportSettings((s) => ({
                      ...s,
                      audioBitrateKbps: Number(e.target.value),
                    }))
                  }
                >
                  <option value={128}>128 kbps</option>
                  <option value={192}>192 kbps</option>
                  <option value={256}>256 kbps</option>
                  <option value={320}>320 kbps</option>
                </select>
              </label>
            </div>

            <label className="flex cursor-pointer items-center gap-2 text-xs text-muted-foreground">
              <input
                type="checkbox"
                checked={exportSettings.forceReencode}
                onChange={(e) =>
                  setExportSettings((s) => ({ ...s, forceReencode: e.target.checked }))
                }
              />
              Force full re-encode (disable smart-cut)
            </label>

            {exportAlphaWarning && (
              <p role="status" className="text-xs text-amber-600 dark:text-amber-400">
                {exportAlphaWarning}
              </p>
            )}

            {exportProblem && (
              <p role="alert" className="text-xs text-destructive">
                {exportProblem}
              </p>
            )}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setExportDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              disabled={exportProblem !== null}
              onClick={() => {
                setExportDialogOpen(false);
                void runExport();
              }}
              className="gap-2"
            >
              <Settings2 className="h-4 w-4" />
              Export .{exportFormatInfo.ext}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={transcribeProgress !== null} onOpenChange={() => undefined}>
        <DialogContent className="max-w-sm" hideClose>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <MicVocal className="h-4 w-4 text-primary" />
              Transcribing media
            </DialogTitle>
            <DialogDescription>
              WordsCut is building the word-level edit timeline locally on this Mac.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            {/*
             * Same two-phase pattern as export:
             *  transcribeProgress === 0  → Whisper model is loading / audio is being decoded,
             *                              no meaningful % yet — show indeterminate bar.
             *  transcribeProgress  > 0  → Whisper is actively transcribing; show real %.
             */}
            {(transcribeProgress ?? 0) > 0 ? (
              <>
                <Progress value={(transcribeProgress ?? 0) * 100} />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>Whisper running locally</span>
                  <span>{Math.round((transcribeProgress ?? 0) * 100)}%</span>
                </div>
              </>
            ) : (
              <>
                <Progress indeterminate />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>Whisper running locally</span>
                  <span>Loading model…</span>
                </div>
              </>
            )}
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={exportingProgress !== null} onOpenChange={() => undefined}>
        <DialogContent className="max-w-sm" hideClose>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Scissors className="h-4 w-4 text-primary" />
              Exporting video
            </DialogTitle>
            <DialogDescription>
              Rendering the edited timeline with your selected export settings.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            {/*
             * Two-phase progress UI:
             *  exportingProgress === 0  → ffmpeg is initialising (no frames encoded yet),
             *                             show an indeterminate "running" bar with no %.
             *  exportingProgress  > 0  → real frame data is flowing; switch to a
             *                             determinate bar so the user can see how far along
             *                             the render is.
             */}
            {measuringLoudness ? (
              <>
                <Progress indeterminate />
                <div className="flex justify-between text-xs text-muted-foreground" role="status">
                  <span>Measuring loudness…</span>
                  <span>Export written</span>
                </div>
              </>
            ) : (exportingProgress ?? 0) > 0 ? (
              <>
                <Progress value={(exportingProgress ?? 0) * 100} />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>Writing .mp4</span>
                  <span>{Math.round((exportingProgress ?? 0) * 100)}%</span>
                </div>
              </>
            ) : (
              <>
                <Progress indeterminate />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>Preparing export…</span>
                  <span>Starting ffmpeg</span>
                </div>
              </>
            )}
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={modelDownloadProgress !== null} onOpenChange={() => undefined}>
        <DialogContent className="max-w-sm" hideClose>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Download className="h-4 w-4 text-primary" />
              Downloading model
            </DialogTitle>
            <DialogDescription>Preparing the local transcription model.</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <Progress value={(modelDownloadProgress ?? 0) * 100} />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>{modelDownloadLabel ?? "Downloading…"}</span>
              <span>{Math.round((modelDownloadProgress ?? 0) * 100)}%</span>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/*
       * Heavy-edit progress is now shown by the global <ProcessingOverlay/>
       * (driven by uiStore.isProcessingEdit), which also locks playback.
       */}

      <MusicTracksDialog open={musicDialogOpen} onOpenChange={setMusicDialogOpen} />
      <SnapshotsDialog open={snapshotsDialogOpen} onOpenChange={setSnapshotsDialogOpen} />
    </>
  );
}
