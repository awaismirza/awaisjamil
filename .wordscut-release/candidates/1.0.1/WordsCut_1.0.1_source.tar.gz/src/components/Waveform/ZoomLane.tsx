import { useEffect, useRef, useState } from "react";
import { MIN_REGION_SEC, type ZoomRegion } from "@/lib/zoom";

type DragMode = "move" | "start" | "end";

interface Drag {
  id: string;
  mode: DragMode;
  originX: number;
  start: number;
  end: number;
}

interface ZoomLaneProps {
  regions: readonly ZoomRegion[];
  /** Pixels per second of the rail, so regions line up with the bars above. */
  pxPerSecond: number;
  duration: number;
  selectedId: string | null;
  onSelect: (id: string | null) => void;
  /** Commit a new span when a drag ends. */
  onChange: (id: string, span: { start: number; end: number }) => void;
  /** Double-click on empty lane: add a region starting here. */
  onCreate: (time: number) => void;
}

/**
 * The zoom lane under the waveform: one block per zoom region, positioned on
 * the same scale as the rail. Drag a block to move it, drag its edges to resize.
 * The block follows the pointer locally and commits once on release, so passing
 * over a neighbour never trims it until you let go.
 */
export function ZoomLane({
  regions,
  pxPerSecond,
  duration,
  selectedId,
  onSelect,
  onChange,
  onCreate,
}: ZoomLaneProps) {
  const [preview, setPreview] = useState<{ id: string; start: number; end: number } | null>(null);
  const dragRef = useRef<Drag | null>(null);
  const previewRef = useRef(preview);
  previewRef.current = preview;

  useEffect(() => {
    function onMove(e: MouseEvent) {
      const d = dragRef.current;
      if (!d || pxPerSecond <= 0) return;
      const dt = (e.clientX - d.originX) / pxPerSecond;
      let start = d.start;
      let end = d.end;
      if (d.mode === "move") {
        const len = d.end - d.start;
        start = Math.min(Math.max(0, d.start + dt), Math.max(0, duration - len));
        end = start + len;
      } else if (d.mode === "start") {
        start = Math.min(Math.max(0, d.start + dt), d.end - MIN_REGION_SEC);
      } else {
        end = Math.max(Math.min(duration, d.end + dt), d.start + MIN_REGION_SEC);
      }
      setPreview({ id: d.id, start, end });
    }
    function onUp() {
      const d = dragRef.current;
      dragRef.current = null;
      const p = previewRef.current;
      setPreview(null);
      if (d && p && (p.start !== d.start || p.end !== d.end)) {
        onChange(d.id, { start: p.start, end: p.end });
      }
    }
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
    return () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
    };
  }, [pxPerSecond, duration, onChange]);

  function begin(e: React.MouseEvent, r: ZoomRegion, mode: DragMode) {
    // Keep the rail from starting its own drag-select or seek.
    e.stopPropagation();
    e.preventDefault();
    onSelect(r.id);
    dragRef.current = { id: r.id, mode, originX: e.clientX, start: r.start, end: r.end };
  }

  return (
    <div
      className="zoom-lane"
      onMouseDown={(e) => {
        // Clicking empty lane deselects without moving the playhead.
        e.stopPropagation();
        onSelect(null);
      }}
      onDoubleClick={(e) => {
        e.stopPropagation();
        const rect = e.currentTarget.getBoundingClientRect();
        if (pxPerSecond > 0) onCreate((e.clientX - rect.left) / pxPerSecond);
      }}
      title="Double-click to add a zoom"
    >
      {regions.length === 0 && <span className="zoom-lane-hint">Double-click to add a zoom</span>}
      {regions.map((r) => {
        const live = preview && preview.id === r.id ? preview : r;
        return (
          <div
            key={r.id}
            className={`zoom-region${r.id === selectedId ? " is-selected" : ""}`}
            style={{ left: live.start * pxPerSecond, width: Math.max(4, (live.end - live.start) * pxPerSecond) }}
            onMouseDown={(e) => begin(e, r, "move")}
            onDoubleClick={(e) => e.stopPropagation()}
            title={`${r.scale.toFixed(1)}× zoom · ${(live.end - live.start).toFixed(1)} s`}
            role="button"
            tabIndex={0}
            aria-label={`Zoom ${r.scale.toFixed(1)} times, from ${live.start.toFixed(1)} to ${live.end.toFixed(1)} seconds`}
            aria-pressed={r.id === selectedId}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                onSelect(r.id);
              }
            }}
          >
            <span className="zoom-handle is-start" onMouseDown={(e) => begin(e, r, "start")} />
            <span className="zoom-region-label">{r.scale.toFixed(1)}×</span>
            <span className="zoom-handle is-end" onMouseDown={(e) => begin(e, r, "end")} />
          </div>
        );
      })}
    </div>
  );
}
