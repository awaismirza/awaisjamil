/** Waveform and cut-map lanes. Both use the rail's shared px-per-second scale. */
import { useEffect, useMemo, useRef } from "react";
import { cutPoints, CUT_LEAD_IN_SEC } from "@/lib/cuts";
import type { Project } from "@/lib/edl";
import type { PeakPyramid } from "@/lib/ipc";
import { getTimelineIndex } from "@/lib/timelineIndex";
import { waveformColumns } from "@/lib/waveformView";
import { formatTimecode } from "@/lib/timecode";

/**
 * Peaks for the visible window, drawn on one canvas. `subtle` sits behind the
 * clip lane (faint, click-through); otherwise it is its own full-height lane.
 */
export function WaveformLane({
  project,
  pyramids,
  pxPerSecond,
  from,
  to,
  subtle,
}: {
  project: Project;
  pyramids: Readonly<Record<string, PeakPyramid>>;
  pxPerSecond: number;
  from: number;
  to: number;
  subtle: boolean;
}) {
  const ref = useRef<React.ComponentRef<"canvas"> | null>(null);
  const index = useMemo(() => getTimelineIndex(project.segments), [project.segments]);
  const left = Math.max(0, Math.floor(from * pxPerSecond));
  const width = Math.max(0, Math.ceil(to * pxPerSecond) - left);
  const height = subtle ? 36 : 56;
  const dpr = typeof window === "undefined" ? 1 : Math.max(1, window.devicePixelRatio || 1);
  useEffect(() => {
    const ctx = ref.current?.getContext?.("2d");
    if (!ctx || width <= 0) return;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const cols = waveformColumns(index, pyramids, left, width, pxPerSecond);
    ctx.clearRect(0, 0, width, height);
    ctx.fillStyle = "rgba(160,160,170,0.9)";
    for (let x = 0; x < cols.length; x++) {
      const h = Math.max(1, cols[x]! * height);
      ctx.fillRect(x, (height - h) / 2, 1, h);
    }
  }, [index, pyramids, left, width, pxPerSecond, height, dpr]);
  return (
    <div
      data-lane="waveform"
      className={subtle ? "waveform-lane is-subtle" : "waveform-lane"}
      style={{ height }}
    >
      <canvas
        ref={ref}
        width={Math.round(width * dpr)}
        height={Math.round(height * dpr)}
        style={{ left, width, height }}
      />
    </div>
  );
}

/** One tick per cut (a jump in the source); click seeks to just before it. */
export function CutMapLane({
  project,
  pxPerSecond,
  from,
  to,
}: {
  project: Project;
  pxPerSecond: number;
  from: number;
  to: number;
}) {
  const points = useMemo(() => cutPoints(project), [project]);
  return (
    <div
      data-lane="cutMap"
      className="cutmap-lane"
      role="group"
      aria-label="Cut map (arrow keys move between cuts)"
      tabIndex={0}
      onMouseDown={(e) => e.stopPropagation()}
      onKeyDown={(e) => {
        const dir = e.key === "ArrowRight" ? 1 : e.key === "ArrowLeft" ? -1 : 0;
        if (!dir) return;
        const ticks = [...e.currentTarget.querySelectorAll<HTMLElement>(".cutmap-tick")];
        const at = ticks.indexOf(document.activeElement as HTMLElement);
        const next = at < 0 ? (dir > 0 ? 0 : ticks.length - 1) : at + dir;
        ticks[next]?.focus();
        e.preventDefault();
      }}
    >
      {points.map((t, i) =>
        t < from || t > to ? null : (
          <button
            key={t}
            type="button"
            tabIndex={-1}
            className="cutmap-tick"
            style={{ left: t * pxPerSecond }}
            aria-label={`Cut ${i + 1} at ${formatTimecode(t, { ms: false })}`}
            onMouseUp={(e) => e.stopPropagation()}
            onClick={() =>
              window.dispatchEvent(
                new CustomEvent("yusafcut:seek-output", {
                  detail: { time: Math.max(0, t - CUT_LEAD_IN_SEC), play: true },
                }),
              )
            }
          />
        ),
      )}
    </div>
  );
}
