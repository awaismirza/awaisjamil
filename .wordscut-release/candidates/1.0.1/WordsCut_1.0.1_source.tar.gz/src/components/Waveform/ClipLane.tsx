import { useEffect, useMemo, useRef, useState } from "react";
import {
  dropBoundaries,
  dropIndexAt,
  edgeLimits,
  snapCandidates,
  snapTo,
  rollEdit,
  type ClipEdge,
} from "@/lib/clipEdit";
import { entryOutputAt, entrySourceAt, type Project } from "@/lib/edl";
import { getTimelineIndex, type IndexedEntry } from "@/lib/timelineIndex";
import { useProjectStore } from "@/stores/projectStore";
import { usePlayerStore } from "@/stores/playerStore";
import { useEditorUiStore } from "@/stores/editorUiStore";
interface Drag {
  project: Project;
  entry: IndexedEntry;
  edge: ClipEdge;
  x: number;
  target: number;
  snapped: boolean;
  pointerId: number;
}
/** Pixels the pointer must travel before a press on a clip becomes a reorder drag. */
const MOVE_THRESHOLD_PX = 4;
interface MoveDrag {
  project: Project;
  segmentId: string;
  startX: number;
  /** False until the threshold is passed, so a plain click still just selects. */
  active: boolean;
  /** Index the clip will have after the drop. */
  index: number;
  /** Where the dragged clip is drawn, output seconds. */
  ghostStart: number;
}
/** Draft handles are local; release commits exactly one undoable EDL operation. */
export function ClipLane({
  project,
  pxPerSecond,
  from,
  to,
}: {
  project: Project;
  pxPerSecond: number;
  from: number;
  to: number;
}) {
  const index = useMemo(() => getTimelineIndex(project.segments), [project.segments]);
  const selected = useEditorUiStore((s) => s.selectedClipId);
  const setSelected = useEditorUiStore((s) => s.selectClip);
  const [draft, setDraft] = useState<Drag | null>(null);
  const drag = useRef<Drag | null>(null);
  const [roll, setRoll] = useState(0.1);
  const entry = index.entries.find((e) => e.segmentId === selected);
  const [moving, setMoving] = useState<MoveDrag | null>(null);
  const moveRef = useRef<MoveDrag | null>(null);
  const stopMove = useRef<(() => void) | null>(null);
  useEffect(() => () => stopMove.current?.(), []);
  // Screen-reader announcements, and a neighbour to focus once a clip is deleted.
  const [status, setStatus] = useState("");
  const focusAfter = useRef<string | null>(null);
  useEffect(() => {
    const id = focusAfter.current;
    if (!id) return;
    const el = document.querySelector<HTMLElement>(`[data-clip-id="${id}"]`);
    if (el) {
      el.focus();
      focusAfter.current = null;
    }
  }, [project]);
  function moveTo(item: { segmentId: string; index: number }, to: number) {
    const last = index.entries.length - 1;
    if (useProjectStore.getState().moveClip(item.segmentId, to))
      setStatus(
        `Clip ${item.index + 1} moved to position ${Math.min(last, Math.max(0, to)) + 1} of ${last + 1}`,
      );
  }
  function duplicate(item: { segmentId: string; index: number }) {
    if (useProjectStore.getState().duplicateClip(item.segmentId))
      setStatus(`Clip ${item.index + 1} duplicated; the copy is clip ${item.index + 2}`);
  }
  function rippleDelete(item: { segmentId: string; index: number }) {
    // Prefer the clip that moves up into the gap; at the end, the one before.
    const neighbour = index.entries[item.index + 1] ?? index.entries[item.index - 1];
    if (!useProjectStore.getState().deleteClip(item.segmentId)) return;
    setStatus(`Clip ${item.index + 1} deleted; later clips moved up`);
    if (neighbour) {
      focusAfter.current = neighbour.segmentId;
      setSelected(neighbour.segmentId);
    } else setSelected(null);
  }

  /**
   * Press on a clip name: after a few pixels it becomes a reorder drag. Listeners
   * live on the window so the drag survives leaving the lane; Escape, losing the
   * window, the pointer leaving the window or a pointer cancel all abandon it
   * without touching the project. Release commits one undoable `moveClip`.
   */
  function startMove(e: React.PointerEvent, item: IndexedEntry) {
    if (e.button !== 0 || pxPerSecond <= 0 || index.entries.length < 2) return;
    stopMove.current?.();
    const pointerId = e.pointerId;
    const length = item.outputEnd - item.outputStart;
    const boundaries = dropBoundaries(project, item.segmentId);
    moveRef.current = {
      project,
      segmentId: item.segmentId,
      startX: e.clientX,
      active: false,
      index: item.index,
      ghostStart: item.outputStart,
    };
    const finish = (commitDrop: boolean) => {
      const d = moveRef.current;
      moveRef.current = null;
      stopMove.current?.();
      stopMove.current = null;
      setMoving(null);
      if (
        commitDrop &&
        d?.active &&
        d.index !== item.index &&
        useProjectStore.getState().project === d.project
      )
        moveTo({ segmentId: d.segmentId, index: item.index }, d.index);
    };
    const onMove = (ev: PointerEvent) => {
      const d = moveRef.current;
      if (!d || ev.pointerId !== pointerId) return;
      const dx = ev.clientX - d.startX;
      if (!d.active && Math.abs(dx) < MOVE_THRESHOLD_PX) return;
      let start = Math.max(
        0,
        Math.min(index.duration - length, item.outputStart + dx / pxPerSecond),
      );
      // The drop index comes from the unsnapped start; docking only draws the ghost
      // on the very boundary the indicator already shows.
      const target = dropIndexAt(project, item.segmentId, start);
      if (!ev.altKey) {
        const dock = snapTo(start, boundaries, 6 / pxPerSecond);
        if (dock !== null) start = dock;
      }
      moveRef.current = { ...d, active: true, ghostStart: start, index: target };
      setMoving(moveRef.current);
    };
    const onUp = (ev: PointerEvent) => {
      if (ev.pointerId === pointerId) finish(true);
    };
    const onCancel = () => finish(false);
    const onKey = (ev: KeyboardEvent) => {
      if (ev.key !== "Escape") return;
      ev.preventDefault();
      ev.stopPropagation();
      finish(false);
    };
    // mouseout with no relatedTarget is the pointer leaving the window.
    const onOut = (ev: MouseEvent) => {
      if (!ev.relatedTarget) finish(false);
    };
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
    window.addEventListener("pointercancel", onCancel);
    window.addEventListener("blur", onCancel);
    window.addEventListener("keydown", onKey, true);
    document.addEventListener("mouseout", onOut);
    stopMove.current = () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
      window.removeEventListener("pointercancel", onCancel);
      window.removeEventListener("blur", onCancel);
      window.removeEventListener("keydown", onKey, true);
      document.removeEventListener("mouseout", onOut);
    };
  }
  function handleMoveKey(e: React.KeyboardEvent, item: IndexedEntry) {
    if (!e.altKey || (e.key !== "ArrowLeft" && e.key !== "ArrowRight")) return;
    e.preventDefault();
    e.stopPropagation();
    moveTo(item, item.index + (e.key === "ArrowLeft" ? -1 : 1));
  }
  const dropAt =
    moving?.active && moving.project === project
      ? (dropBoundaries(project, moving.segmentId)[moving.index] ?? null)
      : null;
  const commit = (d: Drag) => {
    if (useProjectStore.getState().project !== d.project) return;
    useProjectStore.getState().trimClip(d.entry.segmentId, d.edge, d.target);
  };
  function handleKey(e: React.KeyboardEvent, item: IndexedEntry, edge: ClipEdge) {
    if (e.key !== "ArrowLeft" && e.key !== "ArrowRight") return;
    e.preventDefault();
    e.stopPropagation();
    const step = e.shiftKey ? 1 : 1 / (project.media[item.mediaId]?.fps || 30);
    useProjectStore
      .getState()
      .trimClip(
        item.segmentId,
        edge,
        (edge === "start" ? item.sourceIn : item.sourceOut) +
          (e.key === "ArrowLeft" ? -step : step),
      );
  }
  return (
    <div
      className="clip-lane"
      aria-label="Clip editing"
      onMouseDown={(e) => e.stopPropagation()}
      onMouseUp={(e) => e.stopPropagation()}
    >
      <div
        role="status"
        aria-live="polite"
        style={{
          position: "absolute",
          width: 1,
          height: 1,
          overflow: "hidden",
          clip: "rect(0 0 0 0)",
        }}
      >
        {status}
      </div>
      <div className="clip-track">
        {index.entries
          .filter(
            (e) =>
              (e.outputEnd >= from && e.outputStart <= to) ||
              drag.current?.entry.segmentId === e.segmentId ||
              moving?.segmentId === e.segmentId,
          )
          .map((item) => {
            const live =
              draft?.entry.segmentId === item.segmentId && draft.project === project ? draft : null;
            const ghost =
              moving?.active && moving.segmentId === item.segmentId && moving.project === project
                ? moving
                : null;
            const shift = ghost ? ghost.ghostStart - item.outputStart : 0;
            // Source -> output through the clip's speed (a hold stays at the end).
            const start =
              shift +
              (live?.edge === "start" ? entryOutputAt(item, live.target) : item.outputStart);
            const end =
              shift +
              (live?.edge === "end"
                ? item.outputEnd +
                  entryOutputAt(item, live.target) -
                  entryOutputAt(item, item.sourceOut)
                : item.outputEnd);
            const label = `Clip ${item.index + 1}`;
            return (
              <div
                key={item.segmentId}
                className={`clip-block ${selected === item.segmentId ? "is-selected" : ""} ${ghost ? "is-moving" : ""}`}
                style={{
                  left: start * pxPerSecond,
                  width: Math.max(6, (end - start) * pxPerSecond),
                }}
              >
                <button
                  type="button"
                  className="clip-name"
                  data-clip-id={item.segmentId}
                  aria-keyshortcuts="Alt+ArrowLeft Alt+ArrowRight"
                  aria-pressed={selected === item.segmentId}
                  onClick={() => setSelected(item.segmentId)}
                  onPointerDown={(e) => startMove(e, item)}
                  onKeyDown={(e) => handleMoveKey(e, item)}
                  title={`${label} · ${item.sourceIn.toFixed(2)}–${item.sourceOut.toFixed(2)} s · drag or Option+arrows to reorder`}
                >
                  {label}
                </button>
                {(["start", "end"] as const).map((edge) => {
                  const limits = edgeLimits(project, item.segmentId, edge);
                  return (
                    <button
                      key={edge}
                      className={`clip-handle is-${edge}`}
                      aria-label={`Trim ${label.toLowerCase()} ${edge}`}
                      title="Drag to trim · arrow keys: one frame · Shift: one second"
                      onKeyDown={(e) => handleKey(e, item, edge)}
                      onPointerDown={(e) => {
                        if (e.button !== 0 || pxPerSecond <= 0) return;
                        e.stopPropagation();
                        e.preventDefault();
                        e.currentTarget.setPointerCapture(e.pointerId);
                        setSelected(item.segmentId);
                        usePlayerStore.getState().setPlaying(false);
                        drag.current = {
                          project,
                          entry: item,
                          edge,
                          x: e.clientX,
                          target: edge === "start" ? item.sourceIn : item.sourceOut,
                          snapped: false,
                          pointerId: e.pointerId,
                        };
                      }}
                      onPointerMove={(e) => {
                        const d = drag.current;
                        if (
                          !d ||
                          !limits ||
                          d.entry !== item ||
                          d.edge !== edge ||
                          d.pointerId !== e.pointerId
                        )
                          return;
                        const original = edge === "start" ? item.sourceIn : item.sourceOut;
                        // Pixels are output time; at speed s one output second is s source seconds.
                        let target =
                          original + ((e.clientX - d.x) / pxPerSecond) * (item.speed ?? 1);
                        const candidates = snapCandidates(
                          project,
                          item.mediaId,
                          project.originalTranscripts?.[item.mediaId],
                          item.segmentId,
                        );
                        const playhead = usePlayerStore.getState().currentTime;
                        if (playhead >= item.outputStart && playhead <= item.outputEnd)
                          candidates.push(entrySourceAt(item, playhead));
                        const snapped = e.altKey
                          ? null
                          : snapTo(target, candidates, (6 / pxPerSecond) * (item.speed ?? 1));
                        target = Math.max(limits.min, Math.min(limits.max, snapped ?? target));
                        drag.current = {
                          ...d,
                          target,
                          snapped: snapped !== null && target === snapped,
                        };
                        setDraft(drag.current);
                      }}
                      onPointerUp={(e) => {
                        e.stopPropagation();
                        const d = drag.current;
                        drag.current = null;
                        setDraft(null);
                        if (
                          d &&
                          d.entry.segmentId === item.segmentId &&
                          d.edge === edge &&
                          d.pointerId === e.pointerId
                        )
                          commit(d);
                      }}
                      onLostPointerCapture={() => {
                        drag.current = null;
                        setDraft(null);
                      }}
                      onPointerCancel={() => {
                        drag.current = null;
                        setDraft(null);
                      }}
                    />
                  );
                })}
              </div>
            );
          })}
        {dropAt !== null && (
          <div
            className="clip-drop"
            data-testid="clip-drop"
            style={{ left: dropAt * pxPerSecond }}
            aria-hidden="true"
          />
        )}
      </div>
      <div className="clip-tools" onMouseDown={(e) => e.stopPropagation()}>
        {!entry && <span>Select a clip to split or trim</span>}
        {entry && (
          <>
            <span>
              {draft
                ? `${draft.target.toFixed(2)} s${draft.snapped ? " · snapped" : ""}`
                : `Clip ${entry.index + 1}`}
            </span>
            <button
              type="button"
              onClick={() =>
                useProjectStore.getState().splitClip(usePlayerStore.getState().currentTime)
              }
            >
              Split at playhead
            </button>
            <button
              type="button"
              disabled={entry.index === 0}
              onClick={() => moveTo(entry, entry.index - 1)}
            >
              Move earlier
            </button>
            <button
              type="button"
              disabled={entry.index === index.entries.length - 1}
              onClick={() => moveTo(entry, entry.index + 1)}
            >
              Move later
            </button>
            <button type="button" onClick={() => duplicate(entry)}>
              Duplicate clip
            </button>
            <button
              type="button"
              disabled={index.entries.length < 2}
              title="Remove this clip and close the gap"
              onClick={() => rippleDelete(entry)}
            >
              Ripple delete
            </button>
            <label>
              Roll cut{" "}
              <input
                aria-label="Roll cut by seconds"
                type="number"
                min={-60}
                max={60}
                step={0.01}
                value={roll}
                onChange={(e) => setRoll(Number(e.target.value))}
              />
            </label>
            <button
              type="button"
              disabled={
                entry.index === index.entries.length - 1 ||
                !Number.isFinite(roll) ||
                rollEdit(project, entry.segmentId, roll, project.originalTranscripts) === project
              }
              onClick={() => useProjectStore.getState().rollCut(entry.segmentId, roll)}
            >
              Apply roll
            </button>
            {!project.originalTranscripts?.[entry.mediaId] && (
              <span title="Retranscribe to preserve complete originals">
                Legacy transcript: extension cannot recover deleted words
              </span>
            )}
          </>
        )}
      </div>
    </div>
  );
}
