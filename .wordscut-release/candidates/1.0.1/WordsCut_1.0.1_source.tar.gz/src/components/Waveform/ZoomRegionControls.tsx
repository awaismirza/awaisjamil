import { Minus, Plus, Trash2 } from "lucide-react";
import { clampScale, type ZoomRegion } from "@/lib/zoom";

/** The 3x3 grid of places the zoom can settle on. */
const FOCUS_POINTS = [0.2, 0.5, 0.8] as const;

interface Props {
  region: ZoomRegion;
  onChange: (patch: Partial<Omit<ZoomRegion, "id">>) => void;
  onRemove: () => void;
}

/** Scale, focus point and delete for the selected zoom region, in the timeline header. */
export function ZoomRegionControls({ region, onChange, onRemove }: Props) {
  const step = (d: number) => onChange({ scale: clampScale(Math.round((region.scale + d) * 10) / 10) });
  return (
    <div className="zoom-controls" role="group" aria-label="Selected zoom">
      <span className="zoom-controls-label">Zoom</span>
      <button type="button" className="zoom-ctl-btn" aria-label="Less zoom" onClick={() => step(-0.2)}>
        <Minus className="h-3 w-3" />
      </button>
      <output className="zoom-ctl-value">{region.scale.toFixed(1)}×</output>
      <button type="button" className="zoom-ctl-btn" aria-label="More zoom" onClick={() => step(0.2)}>
        <Plus className="h-3 w-3" />
      </button>
      <span className="zoom-controls-label">Focus</span>
      <span className="zoom-focus" role="group" aria-label="Where the zoom settles">
        {FOCUS_POINTS.flatMap((y) =>
          FOCUS_POINTS.map((x) => {
            const on = Math.abs(region.focusX - x) < 0.01 && Math.abs(region.focusY - y) < 0.01;
            return (
              <button
                key={`${x}-${y}`}
                type="button"
                className={`zoom-focus-dot${on ? " is-on" : ""}`}
                aria-label={`Focus ${y === 0.2 ? "top" : y === 0.8 ? "bottom" : "middle"} ${x === 0.2 ? "left" : x === 0.8 ? "right" : "centre"}`}
                aria-pressed={on}
                onClick={() => onChange({ focusX: x, focusY: y })}
              />
            );
          }),
        )}
      </span>
      <button type="button" className="zoom-ctl-btn" aria-label="Delete zoom" title="Delete zoom" onClick={onRemove}>
        <Trash2 className="h-3 w-3" />
      </button>
    </div>
  );
}
