/**
 * Output timeline.
 *
 * Two view modes, switched purely by `timelineZoom`:
 *  - zoom = 1: the rail fits the panel exactly and behaves like a static overview.
 *  - zoom > 1: the rail is `zoom × containerWidth` wide and lives inside a
 *    horizontally-scrolling container. The playhead is auto-scrolled into view.
 *
 * Sync notes:
 *  - Bars are positioned in absolute px relative to the full-width rail using a
 *    single `pxPerSecond` scale. Pixel layout never moves while the user scrolls
 *    — only the scrollLeft changes — so the playhead stays sub-pixel accurate
 *    even at 32x zoom.
 *  - Wheel-to-pan (horizontal): regular wheel scroll just scrolls the rail.
 *  - Wheel-to-zoom (Cmd/Ctrl + wheel): zooms in/out, recentring on the cursor.
 */

import { useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { projectChapters, totalDuration, wordIdsInOutputRange } from "@/lib/edl";
import { useProjectStore } from "@/stores/projectStore";
import { usePlayerStore } from "@/stores/playerStore";
import { formatTimecode } from "@/lib/timecode";
import { sanitizeZoomRegions } from "@/lib/zoom";
import { useEditorUiStore } from "@/stores/editorUiStore";
import { subscribePlaybackFrame, getPlaybackFrame } from "@/lib/playbackClock";
import { ClipLane } from "./ClipLane";
import { ZoomLane } from "./ZoomLane";
import { ZoomRegionControls } from "./ZoomRegionControls";
import { TimelineViewMenu } from "./TimelineViewMenu";
import { CutMapLane, WaveformLane } from "./ExtraLanes";
import { cutPoints } from "@/lib/cuts";
import { generateWaveform, type PeakPyramid } from "@/lib/ipc";
import { useTimelineViewStore } from "@/stores/timelineViewStore";
import { resolveVisibleLanes } from "@/lib/timelineView";

/** Px overdraw outside the visible window so virtualised bars enter/exit smoothly. */
const VIRTUAL_OVERDRAW_PX = 200;

export function Waveform() {
  const scrollRef = useRef<HTMLDivElement | null>(null);
  const railRef = useRef<HTMLDivElement | null>(null);
  const project = useProjectStore((s) => s.project);
  const playheadRef = useRef<HTMLDivElement | null>(null);
  const manualFollowUntil = useRef(0);
  const timelineMarkIn = usePlayerStore((s) => s.timelineMarkIn);
  const timelineMarkOut = usePlayerStore((s) => s.timelineMarkOut);
  const timelineZoom = usePlayerStore((s) => s.timelineZoom);
  const setSelectedWordIds = usePlayerStore((s) => s.setSelectedWordIds);
  const setTimelineRange = usePlayerStore((s) => s.setTimelineRange);
  const setTimelineZoom = usePlayerStore((s) => s.setTimelineZoom);
  const [dragStart, setDragStart] = useState<number | null>(null);
  const [dragging, setDragging] = useState(false);
  const [containerWidth, setContainerWidth] = useState(0);
  const [scrollLeft, setScrollLeft] = useState(0);
  const hoverRef = useRef<HTMLDivElement | null>(null);
  const zoomLevel = useEditorUiStore((s) => s.zoomLevel);
  const selectedZoomId = useEditorUiStore((s) => s.selectedZoomId);
  const selectZoomRegion = useEditorUiStore((s) => s.selectZoomRegion);
  const addZoomRegion = useProjectStore((s) => s.addZoomRegion);
  const updateZoomRegion = useProjectStore((s) => s.updateZoomRegion);
  const removeZoomRegion = useProjectStore((s) => s.removeZoomRegion);

  const firstMedia = Object.values(project.media)[0];
  const duration = totalDuration(project);
  const zoomRegions = useMemo(
    () => sanitizeZoomRegions(project.zoomRegions, duration),
    [project.zoomRegions, duration],
  );
  const selectedZoom = zoomRegions.find((r) => r.id === selectedZoomId) ?? null;
  const zoomed = timelineZoom > 1.001;
  const viewPrefs = useTimelineViewStore((s) => s.prefs);
  const chapterList = useMemo(() => projectChapters(project), [project]);
  const [pyramids, setPyramids] = useState<Record<string, PeakPyramid>>({});
  const mediaKey = Object.values(project.media)
    .map((m) => `${m.id}:${m.path}`)
    .join("|");
  const wantWaveform = viewPrefs.lanes.waveform;
  const requested = useRef(new Set<string>());
  const mediaKeys = useRef(new Set<string>());
  useEffect(() => {
    const mediaNow = Object.values(project.media);
    mediaKeys.current = new Set(mediaNow.map((m) => `${m.id}:${m.path}`));
    for (const k of requested.current) if (!mediaKeys.current.has(k)) requested.current.delete(k);
    // Drop peaks for media that left the project.
    setPyramids((prev) => {
      const keep = Object.keys(prev).filter((id) => mediaNow.some((m) => m.id === id));
      return keep.length === Object.keys(prev).length
        ? prev
        : Object.fromEntries(keep.map((id) => [id, prev[id]!]));
    });
    if (!wantWaveform) return; // lane hidden: don't decode audio nobody sees
    for (const m of mediaNow) {
      const key = `${m.id}:${m.path}`;
      if (requested.current.has(key)) continue;
      requested.current.add(key);
      generateWaveform(m)
        .then((p) => {
          if (mediaKeys.current.has(key)) setPyramids((prev) => ({ ...prev, [m.id]: p }));
        })
        .catch(() => {
          requested.current.delete(key); // no peaks (e.g. outside Tauri): lane stays empty
        });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- keyed on media identity
  }, [mediaKey, wantWaveform]);
  const hasCuts = useMemo(() => cutPoints(project).length > 0, [project]);
  const laneContent = {
    waveform: Object.keys(pyramids).length > 0,
    cutMap: hasCuts,
    clips: duration > 0,
    zoom: zoomRegions.length > 0,
    chapters: chapterList.length > 0,
  };
  const visible = new Set(resolveVisibleLanes(viewPrefs, laneContent));

  // ── Layout math ──────────────────────────────────────────────────────────
  // We size the rail relative to the scroll container's clientWidth. At zoom=1
  // the rail equals the container width (and no scrollbar appears). At zoom=N
  // the rail is N× that wide, so 1s of source occupies N times as many pixels.
  const railWidth = Math.max(0, containerWidth * timelineZoom);
  const pxPerSecond = duration > 0 ? railWidth / duration : 0;

  // ── Resize observer to keep `containerWidth` in sync ───────────────────────
  useLayoutEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const measure = () => setContainerWidth(el.clientWidth);
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  // ── Track scrollLeft for virtualisation + minimap ─────────────────────────
  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    let raf = 0;
    const onScroll = () => {
      window.cancelAnimationFrame(raf);
      raf = window.requestAnimationFrame(() => setScrollLeft(el.scrollLeft));
    };
    el.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      el.removeEventListener("scroll", onScroll);
      window.cancelAnimationFrame(raf);
    };
  }, []);

  // Reset scroll when the project changes or zoom drops back to 1.
  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    if (!zoomed) {
      el.scrollLeft = 0;
      setScrollLeft(0);
    }
  }, [zoomed]);

  // ── Auto-follow playhead while playing ────────────────────────────────────
  const playing = usePlayerStore((s) => s.playing);
  useLayoutEffect(() => {
    const paint = (time: number) => {
      const x = time * pxPerSecond;
      if (playheadRef.current) playheadRef.current.style.transform = `translate3d(${x}px,0,0)`;
      const el = scrollRef.current;
      if (!el || !zoomed || !playing || dragging || Date.now() < manualFollowUntil.current) return;
      const inset = el.clientWidth * 0.2;
      if (x < el.scrollLeft + inset || x > el.scrollLeft + el.clientWidth - inset) {
        const target = Math.max(
          0,
          Math.min(el.scrollWidth - el.clientWidth, x - el.clientWidth / 2),
        );
        if (Math.abs(target - el.scrollLeft) > 1) el.scrollTo({ left: target, behavior: "auto" });
      }
    };
    paint(playing ? getPlaybackFrame() : usePlayerStore.getState().currentTime);
    const stopFrames = subscribePlaybackFrame(paint);
    const stopStore = usePlayerStore.subscribe((state, before) => {
      if (!state.playing && state.currentTime !== before.currentTime) paint(state.currentTime);
    });
    return () => {
      stopFrames();
      stopStore();
    };
  }, [duration, pxPerSecond, playing, dragging, zoomed]);

  // ── Wheel: horizontal pan; Cmd/Ctrl wheel = zoom around cursor ───────────
  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const onWheel = (e: globalThis.WheelEvent) => {
      manualFollowUntil.current = Date.now() + 1800;
      if (e.ctrlKey || e.metaKey) {
        e.preventDefault();
        // Zoom factor — slower than the default to feel like a trackpad pinch.
        const factor = e.deltaY < 0 ? 1.12 : 1 / 1.12;
        const beforeZoom = usePlayerStore.getState().timelineZoom;
        const newZoom = Math.max(1, Math.min(32, beforeZoom * factor));
        if (Math.abs(newZoom - beforeZoom) < 1e-3) return;

        // Recentre so the time under the cursor stays put.
        const rect = el.getBoundingClientRect();
        const cursorX = e.clientX - rect.left;
        const beforePx = el.scrollLeft + cursorX;
        setTimelineZoom(newZoom);
        // Apply scroll fix in a microtask so React has re-rendered the rail width.
        window.requestAnimationFrame(() => {
          const scale = newZoom / beforeZoom;
          const afterPx = beforePx * scale;
          el.scrollLeft = Math.max(0, afterPx - cursorX);
        });
        return;
      }
      // Pan: trackpads emit deltaX, classic mice emit deltaY. Always treat
      // wheel-on-timeline as horizontal — vertical scrolling here is meaningless.
      if (!zoomed) return;
      const dx = e.deltaX !== 0 ? e.deltaX : e.deltaY;
      if (dx === 0) return;
      e.preventDefault();
      el.scrollLeft += dx;
    };
    el.addEventListener("wheel", onWheel, { passive: false });
    return () => el.removeEventListener("wheel", onWheel);
  }, [setTimelineZoom, zoomed]);

  // ── Virtualised bars + ticks for the visible window ──────────────────────
  const visibleStartPx = Math.max(0, scrollLeft - VIRTUAL_OVERDRAW_PX);
  const visibleEndPx = scrollLeft + containerWidth + VIRTUAL_OVERDRAW_PX;
  const visibleStartSec = pxPerSecond > 0 ? visibleStartPx / pxPerSecond : 0;
  const visibleEndSec = pxPerSecond > 0 ? Math.min(duration, visibleEndPx / pxPerSecond) : duration;

  const ticks = useMemo(() => {
    if (pxPerSecond <= 0) return [] as TickSpec[];
    // Density-aware tick step. At higher zoom we want finer divisions.
    const visibleDuration = Math.max(visibleEndSec - visibleStartSec, 1e-3);
    const tickStep =
      visibleDuration > 600
        ? 60
        : visibleDuration > 240
          ? 30
          : visibleDuration > 90
            ? 10
            : visibleDuration > 30
              ? 5
              : visibleDuration > 10
                ? 1
                : visibleDuration > 3
                  ? 0.5
                  : 0.1;
    const next: TickSpec[] = [];
    const firstTick = Math.ceil(visibleStartSec / tickStep) * tickStep;
    for (let t = firstTick; t <= visibleEndSec + 1e-6; t += tickStep) {
      next.push({
        leftPx: t * pxPerSecond,
        label: tickStep < 1 ? formatTimecode(t, { ms: true }) : formatTimecode(t, { ms: false }),
      });
    }
    return next;
  }, [pxPerSecond, visibleEndSec, visibleStartSec]);

  // ── Pointer geometry ─────────────────────────────────────────────────────
  function outputTimeFromPointer(e: React.MouseEvent<HTMLDivElement>) {
    const rail = railRef.current;
    if (!rail || railWidth <= 0) return null;
    const rect = rail.getBoundingClientRect();
    const x = e.clientX - rect.left;
    return Math.max(0, Math.min(duration, (x / railWidth) * duration));
  }

  function seekToOutputTime(outputTime: number) {
    if (!firstMedia) return;
    window.dispatchEvent(
      new CustomEvent("yusafcut:seek-output", { detail: { time: outputTime, play: true } }),
    );
  }

  function updateSelection(markIn: number, markOut: number) {
    setTimelineRange(markIn, markOut);
    setSelectedWordIds(wordIdsInOutputRange(project, markIn, markOut));
  }

  function handleMouseDown(e: React.MouseEvent<HTMLDivElement>) {
    const outputTime = outputTimeFromPointer(e);
    if (outputTime === null) return;
    setDragStart(outputTime);
    setDragging(false);
  }

  function handleMouseMove(e: React.MouseEvent<HTMLDivElement>) {
    const outputTime = outputTimeFromPointer(e);
    if (outputTime === null) return;
    if (hoverRef.current)
      hoverRef.current.style.transform = `translate3d(${outputTime * pxPerSecond}px,0,0)`;
    if (hoverRef.current) hoverRef.current.style.opacity = "1";
    if (dragStart === null) return;
    if (Math.abs(outputTime - dragStart) > 0.05) setDragging(true);
    updateSelection(dragStart, outputTime);
  }

  function handleMouseUp(e: React.MouseEvent<HTMLDivElement>) {
    const outputTime = outputTimeFromPointer(e);
    if (outputTime === null) return;
    if (!dragging || dragStart === null) {
      seekToOutputTime(outputTime);
    } else {
      updateSelection(dragStart, outputTime);
    }
    setDragStart(null);
    setDragging(false);
  }

  // ── Render ────────────────────────────────────────────────────────────────
  if (!firstMedia) {
    return (
      <div className="flex h-full items-center justify-center text-xs text-muted-foreground">
        Timeline appears once media is loaded
      </div>
    );
  }

  if (duration <= 0) {
    return (
      <div className="timeline-panel flex items-center justify-center text-xs text-muted-foreground">
        Transcribe to build an editable output timeline
      </div>
    );
  }

  const hasTimelineRange = timelineMarkIn !== null && timelineMarkOut !== null;
  const markInPx = timelineMarkIn !== null ? timelineMarkIn * pxPerSecond : null;
  const markOutPx = timelineMarkOut !== null ? timelineMarkOut * pxPerSecond : null;
  const selectionStartPx = hasTimelineRange
    ? Math.min(timelineMarkIn!, timelineMarkOut!) * pxPerSecond
    : 0;
  const selectionWidthPx = hasTimelineRange
    ? Math.abs(timelineMarkOut! - timelineMarkIn!) * pxPerSecond
    : 0;

  return (
    <div className="timeline-panel">
      <div className="timeline-header">
        <div className="timeline-title">Timeline</div>
        {selectedZoom && (
          <ZoomRegionControls
            region={selectedZoom}
            onChange={(patch) => updateZoomRegion(selectedZoom.id, patch)}
            onRemove={() => {
              removeZoomRegion(selectedZoom.id);
              selectZoomRegion(null);
            }}
          />
        )}

        <TimelineViewMenu content={laneContent} />
        <div
          className="timeline-zoom"
          title="Drag selects · I/O mark range · ⌘+scroll zooms around the cursor"
        >
          <button
            type="button"
            aria-label="Zoom out"
            disabled={timelineZoom <= 1.001}
            onClick={() => setTimelineZoom(Math.max(1, timelineZoom / 1.5))}
          >
            −
          </button>
          <span className="zoom-value">{timelineZoom.toFixed(1)}×</span>
          <button
            type="button"
            aria-label="Zoom in"
            disabled={timelineZoom >= 31.999}
            onClick={() => setTimelineZoom(Math.min(32, timelineZoom * 1.5))}
          >
            +
          </button>
          <button
            type="button"
            aria-label="Fit timeline to window"
            disabled={timelineZoom <= 1.001}
            onClick={() => setTimelineZoom(1)}
            title="Fit to window"
          >
            ⤢
          </button>
        </div>

        <div className="timeline-timecode" title="Playhead position">
          <TimelineTimecode duration={duration} />
        </div>
      </div>

      <div ref={scrollRef} className={zoomed ? "timeline-scroll is-zoomed" : "timeline-scroll"}>
        <div
          ref={railRef}
          className="timeline-rail"
          style={{ width: railWidth || "100%" }}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={() => {
            if (hoverRef.current) hoverRef.current.style.opacity = "0";
          }}
        >
          <div className="timeline-ticks">
            {ticks.map((tick) => (
              <span key={tick.leftPx.toFixed(2)} style={{ left: tick.leftPx }}>
                {tick.label}
              </span>
            ))}
          </div>
          {(visible.has("clips") || visible.has("waveform")) && (
            <div className="timeline-lane-stack">
              {visible.has("waveform") && (
                <WaveformLane
                  project={project}
                  pyramids={pyramids}
                  pxPerSecond={pxPerSecond}
                  from={visibleStartSec}
                  to={visibleEndSec}
                  subtle={viewPrefs.preset !== "detailed"}
                />
              )}
              {visible.has("clips") && (
                <ClipLane
                  project={project}
                  pxPerSecond={pxPerSecond}
                  from={visibleStartSec}
                  to={visibleEndSec}
                />
              )}
            </div>
          )}
          {visible.has("cutMap") && (
            <CutMapLane
              project={project}
              pxPerSecond={pxPerSecond}
              from={visibleStartSec}
              to={visibleEndSec}
            />
          )}
          {hasTimelineRange && selectionWidthPx > 0.1 && (
            <div
              className="timeline-selection"
              style={{ left: selectionStartPx, width: selectionWidthPx }}
            >
              <span />
              <span />
            </div>
          )}
          {markInPx !== null && (
            <div className="timeline-marker is-in" style={{ left: markInPx }}>
              <span>I</span>
            </div>
          )}
          {markOutPx !== null && (
            <div className="timeline-marker is-out" style={{ left: markOutPx }}>
              <span>O</span>
            </div>
          )}
          {visible.has("chapters") &&
            chapterList.map((chapter) => {
              const leftPx = chapter.outputTime * pxPerSecond;
              return (
                <div
                  key={chapter.id}
                  className="timeline-chapter"
                  style={{ left: leftPx }}
                  title={`${chapter.title} (${chapter.outputTime.toFixed(2)}s) — click to jump`}
                  onMouseDown={(e) => {
                    // Stop the rail drag from starting; treat as a chapter click.
                    e.stopPropagation();
                    seekToOutputTime(chapter.outputTime);
                  }}
                >
                  <span>{chapter.title}</span>
                </div>
              );
            })}
          {visible.has("zoom") && (
            <ZoomLane
              regions={zoomRegions}
              pxPerSecond={pxPerSecond}
              duration={duration}
              selectedId={selectedZoomId}
              onSelect={selectZoomRegion}
              onChange={(id, span) => updateZoomRegion(id, span)}
              onCreate={(time) => {
                const id = addZoomRegion({ start: time, end: time + 2, scale: zoomLevel });
                if (id) selectZoomRegion(id);
              }}
            />
          )}
          <div ref={hoverRef} className="timeline-hoverline" style={{ left: 0, opacity: 0 }} />
          <div
            ref={playheadRef}
            className="timeline-playhead"
            style={{ left: 0, willChange: "transform" }}
          >
            <span />
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── local types kept down here to keep the JSX above readable ─────────────
type TickSpec = { leftPx: number; label: string };

function TimelineTimecode({ duration }: { duration: number }) {
  const time = usePlayerStore((s) => s.currentTime);
  return (
    <>
      {formatTimecode(time, { ms: false })} / {formatTimecode(duration, { ms: false })}
    </>
  );
}
