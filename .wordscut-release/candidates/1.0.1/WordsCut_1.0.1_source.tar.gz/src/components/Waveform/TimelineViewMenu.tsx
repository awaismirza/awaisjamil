/** "View" popover in the timeline header: preset, per-lane checkboxes, hide-empty, reset. */
import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { LANE_IDS, LANE_LABELS, type LaneId } from "@/lib/timelineView";
import { useTimelineViewStore } from "@/stores/timelineViewStore";

export function TimelineViewMenu({ content }: { content: Partial<Record<LaneId, boolean>> }) {
  const [open, setOpen] = useState(false);
  const btnRef = useRef<HTMLButtonElement | null>(null);
  const panelRef = useRef<HTMLDivElement | null>(null);
  const s = useTimelineViewStore();
  const { prefs } = s;

  // Portal + fixed position so no ancestor's overflow can clip the panel. It opens
  // upward from the button (the timeline sits at the bottom) unless there is no room.
  const [pos, setPos] = useState<{ left: number; top?: number; bottom?: number }>({ left: 0 });
  const place = () => {
    const r = btnRef.current?.getBoundingClientRect();
    if (!r) return;
    const left = Math.max(8, Math.min(r.left, window.innerWidth - 220));
    setPos(
      r.top > 260 ? { left, bottom: window.innerHeight - r.top + 6 } : { left, top: r.bottom + 6 },
    );
  };

  const close = () => {
    setOpen(false);
    btnRef.current?.focus();
  };

  useEffect(() => {
    if (!open) return;
    place();
    window.addEventListener("resize", place);
    panelRef.current?.querySelector<HTMLElement>("select,input,button")?.focus();
    const onDown = (e: MouseEvent) => {
      const t = e.target as Node;
      if (!panelRef.current?.contains(t) && !btnRef.current?.contains(t)) setOpen(false);
    };
    document.addEventListener("mousedown", onDown);
    return () => {
      document.removeEventListener("mousedown", onDown);
      window.removeEventListener("resize", place);
    };
  }, [open]);

  return (
    <div className="timeline-view">
      <button
        ref={btnRef}
        type="button"
        className="timeline-view-btn"
        aria-haspopup="dialog"
        aria-expanded={open}
        onClick={() => setOpen((o) => !o)}
      >
        View
      </button>
      {open &&
        createPortal(
          <div
            ref={panelRef}
            role="dialog"
            aria-modal="false"
            aria-label="Timeline view"
            className="timeline-view-panel"
            style={pos}
            onKeyDown={(e) => {
              if (e.key === "Escape") {
                e.stopPropagation();
                close();
              }
            }}
          >
            <label>
              Preset{" "}
              <select
                aria-label="View preset"
                value={prefs.preset}
                onChange={(e) => s.setPreset(e.target.value as typeof prefs.preset)}
              >
                <option value="simple">Simple</option>
                <option value="detailed">Detailed</option>
                {prefs.preset === "custom" && <option value="custom">Custom</option>}
              </select>
            </label>
            {LANE_IDS.map((id) => (
              <label key={id}>
                <input
                  type="checkbox"
                  checked={prefs.lanes[id]}
                  onChange={(e) => s.setLane(id, e.target.checked)}
                />{" "}
                {LANE_LABELS[id]}
              </label>
            ))}
            <label>
              <input
                type="checkbox"
                checked={prefs.hideEmpty}
                onChange={(e) => s.setHideEmpty(e.target.checked)}
              />{" "}
              Hide empty lanes
            </label>
            <button type="button" onClick={() => s.showPopulated(content)}>
              Show populated lanes
            </button>
            <button type="button" onClick={s.reset}>
              Reset view
            </button>
          </div>,
          document.body,
        )}
    </div>
  );
}
