/* global MediaStream */
/** Panels that open below the bar. Each one reads and writes `barStore`. */

import { useEffect, useRef, useState } from "react";
import { AppWindowMac, Check, MonitorUp } from "lucide-react";
import { useShortcutLabel } from "@/hooks/useShortcutLabel";
import { SourcePreview } from "@/components/Recorder/SourcePreview";
import { useCameraPreview } from "@/components/Recorder/useMediaPreview";
import { recordingThumbnail, type PipCorner, type PipSize, type RecordingDevices } from "@/lib/ipc";
import { COUNTDOWN_CHOICES } from "@/lib/settings";
import {
  ALL_CHARACTERS_NOTE,
  KEY_IDENTITY_NOTE,
  isNative,
  isValidArea,
  needsCamera,
  needsScreen,
} from "@/lib/recorderSetup";
import { useSettingsStore } from "@/stores/settingsStore";
import { isDenied, screensOf, visibleWindows } from "./barModel";
import { useBarStore } from "./barStore";

const allowedFor = (devices: RecordingDevices | null) =>
  devices?.permissions?.screenRecording === "granted" || devices?.permissions == null;

/** Small segmented control used by the settings panel. */
function Seg<T extends string | number>({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: T;
  options: Array<{ id: T; label: string }>;
  onChange: (id: T) => void;
}) {
  return (
    <div className="rb-seg" role="radiogroup" aria-label={label}>
      {options.map((o) => (
        <button
          key={String(o.id)}
          type="button"
          role="radio"
          aria-checked={o.id === value}
          className={o.id === value ? "is-active" : ""}
          onClick={() => onChange(o.id)}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

function Switch({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: (next: boolean) => void;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      className={`rb-switch${checked ? " is-on" : ""}`}
      onClick={() => onChange(!checked)}
    >
      <span />
    </button>
  );
}

export function DisplayPicker() {
  const devices = useBarStore((s) => s.devices);
  const selected = useBarStore((s) => s.opts.screenIndex);
  const pick = useBarStore((s) => s.pickDisplay);
  return (
    <div className="rb-panel" role="dialog" aria-label="Choose a display">
      <h3>Choose a display to record</h3>
      <div className="rb-grid">
        {screensOf(devices).map((s) => (
          <button
            key={s.index}
            type="button"
            className={`rb-card${s.index === selected ? " is-active" : ""}`}
            onClick={() => pick(s.index)}
          >
            <Thumb screenIndex={s.index} allowed={allowedFor(devices)} native={isNative(devices)} />
            <span className="rb-card-name">{s.name}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

/** A thumbnail loaded once, shortly after mount (staggered so a long list does not stall). */
function Thumb({
  screenIndex,
  windowId,
  allowed,
  native,
  delay = 0,
}: {
  screenIndex?: number;
  windowId?: number;
  allowed: boolean;
  native: boolean;
  delay?: number;
}) {
  const [url, setUrl] = useState<string | null>(null);
  useEffect(() => {
    if (!native || !allowed) return;
    let cancelled = false;
    const timer = setTimeout(() => {
      recordingThumbnail({ screenIndex, windowId, maxWidth: 360 })
        .then((u) => !cancelled && setUrl(u))
        .catch(() => {});
    }, delay);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [screenIndex, windowId, allowed, native, delay]);
  return (
    <div className="rb-card-thumb">
      {url ? <img src={url} alt="" draggable={false} /> : <MonitorUp className="h-5 w-5" />}
    </div>
  );
}

export function WindowPicker() {
  const devices = useBarStore((s) => s.devices);
  const selected = useBarStore((s) => s.opts.windowId);
  const pick = useBarStore((s) => s.pickWindow);
  const windows = visibleWindows(devices);
  return (
    <div className="rb-panel" role="dialog" aria-label="Choose a window">
      <h3>Choose a window to record</h3>
      {windows.length === 0 ? (
        <p className="rb-note">No windows are open.</p>
      ) : (
        <div className="rb-grid">
          {windows.map((w, i) => (
            <button
              key={w.id}
              type="button"
              className={`rb-card${w.id === selected ? " is-active" : ""}`}
              onClick={() => pick(w.id)}
            >
              <Thumb
                windowId={w.id}
                allowed={allowedFor(devices)}
                native={isNative(devices)}
                delay={Math.min(i, 12) * 70}
              />
              <span className="rb-card-name">{w.title || w.app}</span>
              <span className="rb-card-sub">{w.app}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

export function AreaPicker() {
  const devices = useBarStore((s) => s.devices);
  const opts = useBarStore((s) => s.opts);
  const setArea = useBarStore((s) => s.setArea);
  const record = useBarStore((s) => s.recordArea);
  const screen = screensOf(devices).find((s) => s.index === opts.screenIndex);
  const display = devices?.displays?.find((d) => d.index === screen?.index);
  const valid = isValidArea(opts.area, display);
  return (
    <div className="rb-panel" role="dialog" aria-label="Choose an area">
      <h3>Drag on the preview to choose an area</h3>
      <SourcePreview
        native={isNative(devices)}
        allowed={allowedFor(devices)}
        screenIndex={screen?.index}
        display={display}
        area={opts.area}
        onArea={setArea}
        name={screen?.name}
      />
      <div className="rb-panel-foot">
        <span>
          {opts.area && valid
            ? `${opts.area.width} × ${opts.area.height} pt`
            : "Minimum area is 32 × 32 pt."}
        </span>
        <button type="button" className="rb-btn is-primary" disabled={!valid} onClick={record}>
          Record area
        </button>
      </div>
    </div>
  );
}

function CameraVideo({ stream }: { stream: MediaStream | null }) {
  const ref = useRef<HTMLVideoElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (el) el.srcObject = stream;
  }, [stream]);
  return <video ref={ref} autoPlay muted playsInline />;
}

export function CameraPanel() {
  const devices = useBarStore((s) => s.devices);
  const opts = useBarStore((s) => s.opts);
  const setCamera = useBarStore((s) => s.setCamera);
  const openSettings = useBarStore((s) => s.openSettings);
  const cameras = devices?.video.filter((d) => !d.isScreen) ?? [];
  const on = needsCamera(opts.mode);
  const current = cameras.find((c) => c.index === opts.cameraIndex);
  const denied = isDenied(devices?.permissions?.camera);
  const preview = useCameraPreview(on && !denied, current?.name);
  return (
    <div className="rb-panel" role="dialog" aria-label="Camera">
      <div className="rb-split">
        <div className="rb-list" role="listbox" aria-label="Cameras">
          <button
            type="button"
            role="option"
            aria-selected={!on}
            className={`rb-row${!on ? " is-active" : ""}`}
            onClick={() => setCamera(null)}
          >
            <span>Off</span>
            {!on && <Check />}
          </button>
          {cameras.map((c) => (
            <button
              key={c.index}
              type="button"
              role="option"
              aria-selected={on && c.index === opts.cameraIndex}
              className={`rb-row${on && c.index === opts.cameraIndex ? " is-active" : ""}`}
              onClick={() => setCamera(c.index)}
            >
              <span>{c.name}</span>
              {on && c.index === opts.cameraIndex && <Check />}
            </button>
          ))}
          {cameras.length === 0 && <p className="rb-note">No camera found.</p>}
        </div>
        <div>
          <div className="rb-video">
            {denied ? (
              <span>
                Camera access is off.{" "}
                <button type="button" className="rb-link" onClick={() => openSettings("camera")}>
                  Open Settings
                </button>
              </span>
            ) : preview.status === "live" ? (
              <CameraVideo stream={preview.value} />
            ) : (
              <span>
                {!on
                  ? "Choose a camera to see yourself."
                  : preview.status === "unavailable"
                    ? (preview.reason ?? "Preview is not available.")
                    : "Starting camera…"}
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export function MicPanel() {
  const devices = useBarStore((s) => s.devices);
  const opts = useBarStore((s) => s.opts);
  const micOff = useBarStore((s) => s.micOff);
  const setMic = useBarStore((s) => s.setMic);
  const openSettings = useBarStore((s) => s.openSettings);
  const mics = devices?.audio ?? [];
  const denied = isDenied(devices?.permissions?.microphone);
  return (
    <div className="rb-panel" role="dialog" aria-label="Microphone">
      <div className="rb-list" role="listbox" aria-label="Microphones">
        <button
          type="button"
          role="option"
          aria-selected={micOff}
          className={`rb-row${micOff ? " is-active" : ""}`}
          onClick={() => setMic(null)}
        >
          <span>Off</span>
          {micOff && <Check />}
        </button>
        {mics.map((m) => {
          const active = !micOff && m.index === opts.audioIndex;
          return (
            <button
              key={m.index}
              type="button"
              role="option"
              aria-selected={active}
              className={`rb-row${active ? " is-active" : ""}`}
              onClick={() => setMic(m.index)}
            >
              <span>{m.name}</span>
              {active && <Check />}
            </button>
          );
        })}
        {mics.length === 0 && <p className="rb-note">No microphone found.</p>}
      </div>
      {denied && (
        <p className="rb-note">
          Microphone access is off.{" "}
          <button type="button" className="rb-link" onClick={() => openSettings("microphone")}>
            Open Settings
          </button>
        </p>
      )}
    </div>
  );
}

const CORNERS: Array<{ id: PipCorner; label: string }> = [
  { id: "top-left", label: "↖" },
  { id: "top-right", label: "↗" },
  { id: "bottom-left", label: "↙" },
  { id: "bottom-right", label: "↘" },
];
const SIZES: Array<{ id: PipSize; label: string }> = [
  { id: "small", label: "S" },
  { id: "medium", label: "M" },
  { id: "large", label: "L" },
];

export function SettingsPanel() {
  const opts = useBarStore((s) => s.opts);
  const devices = useBarStore((s) => s.devices);
  const setOpts = useBarStore((s) => s.setOpts);
  const moreOptions = useBarStore((s) => s.moreOptions);
  const recording = useSettingsStore((s) => s.recording);
  const setRecording = useSettingsStore((s) => s.setRecording);
  const recordKey = useShortcutLabel("record");
  const pauseKey = useShortcutLabel("pause");
  const markKey = useShortcutLabel("mark");
  return (
    <div className="rb-panel" role="dialog" aria-label="Recording settings">
      <div className="rb-settings">
        <div className="rb-setting">
          <span>Frame rate</span>
          <Seg
            label="Frame rate"
            value={opts.fps ?? 30}
            options={[
              { id: 30, label: "30" },
              { id: 60, label: "60" },
            ]}
            onChange={(fps) => setOpts({ fps })}
          />
        </div>
        <div className="rb-setting">
          <span>Countdown</span>
          <Seg
            label="Countdown"
            value={recording.countdownSec}
            options={COUNTDOWN_CHOICES.map((c) => ({ id: c, label: c === 0 ? "Off" : `${c}s` }))}
            onChange={(countdownSec) => setRecording({ countdownSec })}
          />
        </div>
        <div className="rb-setting">
          <span>Transcribe after recording</span>
          <Switch
            label="Transcribe after recording"
            checked={recording.autoTranscribe}
            onChange={(autoTranscribe) => setRecording({ autoTranscribe })}
          />
        </div>
        {needsScreen(opts.mode) && isNative(devices) && (
          <>
            <div className="rb-setting">
              <span>Record key names</span>
              <Switch
                label="Record key names"
                checked={Boolean(opts.recordKeyIdentity)}
                onChange={(on) =>
                  setOpts({ recordKeyIdentity: on, ...(on ? {} : { recordAllCharacters: false }) })
                }
              />
            </div>
            <p className="rb-note" role="note">
              {KEY_IDENTITY_NOTE}
            </p>
            {opts.recordKeyIdentity && (
              <>
                <div className="rb-setting">
                  <span>Also record all characters</span>
                  <Switch
                    label="Also record all characters"
                    checked={Boolean(opts.recordAllCharacters)}
                    onChange={(on) => setOpts({ recordAllCharacters: on })}
                  />
                </div>
                <p className="rb-note" role="note">
                  {ALL_CHARACTERS_NOTE}
                </p>
              </>
            )}
          </>
        )}
        <div className="rb-setting">
          <span>Shortcuts</span>
          <span>
            <span className="rb-kbd">Record {recordKey}</span>
            <span className="rb-kbd">Pause {pauseKey}</span>
            <span className="rb-kbd">Mark {markKey}</span>
          </span>
        </div>
        {needsCamera(opts.mode) && (
          <>
            <div className="rb-setting">
              <span>Camera bubble corner</span>
              <Seg
                label="Camera bubble corner"
                value={opts.pipCorner ?? "bottom-right"}
                options={CORNERS}
                onChange={(pipCorner) => setOpts({ pipCorner })}
              />
            </div>
            <div className="rb-setting">
              <span>Camera bubble size</span>
              <Seg
                label="Camera bubble size"
                value={opts.pipSize ?? "medium"}
                options={SIZES}
                onChange={(pipSize) => setOpts({ pipSize })}
              />
            </div>
          </>
        )}
      </div>
      <div className="rb-panel-foot">
        <span />
        <button type="button" className="rb-btn" onClick={() => void moreOptions()}>
          <AppWindowMac className="h-3.5 w-3.5" />
          More options…
        </button>
      </div>
    </div>
  );
}
