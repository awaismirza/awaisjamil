/**
 * State of the floating recorder bar. It runs in its own webview, so it must
 * not import `recordingStore` (which pulls in the editor); it talks to Rust
 * through `ipc` and tells the editor about option changes with an event.
 */

import { nextPaint } from "@/lib/paint";
import { create } from "zustand";
import { emitTo } from "@tauri-apps/api/event";
import {
  cancelRecording,
  closeRecorderBar,
  hideRecorderBar,
  listRecordingDevices,
  openPrivacySettings,
  openRecorderBar,
  openRecordingsFolder,
  requestRecordingPermissions,
  startRecording,
  type AreaRect,
  type PermissionKind,
  type RecordOptions,
  type RecordingDevices,
} from "@/lib/ipc";
import { defaultDevicePatch, hasStoredOpts, loadStoredOpts, persistOpts } from "@/lib/recorderOpts";
import { modeFor, startBlocker, toStartOptions } from "@/lib/recorderSetup";
import { useSettingsStore } from "@/stores/settingsStore";
import { screensOf } from "./barModel";

export type Popover = "display" | "window" | "area" | "camera" | "mic" | "settings";
export type BarPhase = "setup" | "countdown" | "starting";

interface BarState {
  opts: RecordOptions;
  devices: RecordingDevices | null;
  devicesError: string | null;
  micOff: boolean;
  popover: Popover | null;
  phase: BarPhase;
  countdown: number;
  error: string | null;
  openedSettings: boolean;

  refreshDevices: () => Promise<void>;
  setOpts: (patch: Partial<RecordOptions>) => void;
  togglePopover: (p: Popover | null) => void;
  /** Mode button: Display starts at once with one screen, the others open their picker. */
  chooseMode: (kind: "display" | "window" | "area") => void;
  pickDisplay: (index: number) => void;
  pickWindow: (id: number) => void;
  setArea: (area: AreaRect) => void;
  recordArea: () => void;
  setCamera: (index: number | null) => void;
  setMic: (index: number | null) => void;
  toggleSystemAudio: () => void;
  start: () => Promise<void>;
  cancel: () => Promise<void>;
  allowScreenRecording: () => Promise<void>;
  openSettings: (kind: PermissionKind) => Promise<void>;
  openFolder: () => Promise<void>;
  moreOptions: () => Promise<void>;
  close: () => Promise<void>;
  dismissError: () => void;
}

let generation = 0;
let sessionId: string | null = null;

const nextFrame = () => nextPaint();
const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

function emitOpts(opts: RecordOptions) {
  try {
    void emitTo("main", "recorder-bar:opts", opts).catch(() => {});
  } catch {
    /* not inside Tauri */
  }
}

export function initialBarState() {
  const opts = loadStoredOpts();
  return {
    opts,
    devices: null,
    devicesError: null,
    // A first run has no stored choice yet; the microphone then defaults on.
    micOff: hasStoredOpts() && opts.audioIndex === undefined,
    popover: null,
    phase: "setup" as BarPhase,
    countdown: 0,
    error: null,
    openedSettings: false,
  };
}

export const useBarStore = create<BarState>()((set, get) => ({
  ...initialBarState(),

  refreshDevices: async () => {
    try {
      const devices = await listRecordingDevices();
      const { opts, micOff } = get();
      const patch = defaultDevicePatch(opts, devices, { micOff });
      set({ devices, devicesError: null, opts: { ...opts, ...patch } });
    } catch (err) {
      set({ devices: null, devicesError: String(err) });
    }
  },

  setOpts: (patch) => {
    const opts = { ...get().opts, ...patch };
    persistOpts(opts);
    emitOpts(opts);
    set({ opts });
  },

  togglePopover: (p) => set({ popover: get().popover === p ? null : p, error: null }),

  chooseMode: (kind) => {
    const { devices } = get();
    get().setOpts({ sourceKind: kind });
    if (kind === "display") {
      const screens = screensOf(devices);
      if (screens.length > 1) {
        set({ popover: "display" });
        return;
      }
      if (screens[0]) get().setOpts({ screenIndex: screens[0].index });
      set({ popover: null });
      void get().start();
      return;
    }
    set({ popover: kind });
  },

  pickDisplay: (index) => {
    get().setOpts({ screenIndex: index, sourceKind: "display" });
    set({ popover: null });
    void get().start();
  },

  pickWindow: (id) => {
    get().setOpts({ windowId: id, sourceKind: "window" });
    set({ popover: null });
    void get().start();
  },

  setArea: (area) => get().setOpts({ area, sourceKind: "area" }),

  recordArea: () => {
    set({ popover: null });
    void get().start();
  },

  setCamera: (index) => {
    if (index === null) {
      get().setOpts({ mode: modeFor("screen", false) });
    } else {
      get().setOpts({ cameraIndex: index, mode: modeFor("screen", true) });
    }
  },

  setMic: (index) => {
    if (index === null) {
      const opts = { ...get().opts };
      delete opts.audioIndex;
      persistOpts(opts);
      emitOpts(opts);
      set({ opts, micOff: true });
    } else {
      set({ micOff: false });
      get().setOpts({ audioIndex: index });
    }
  },

  toggleSystemAudio: () => get().setOpts({ systemAudio: !get().opts.systemAudio }),

  start: async () => {
    const { opts, devices, devicesError, phase } = get();
    if (phase !== "setup") return;
    const blocker = startBlocker(opts, devices, devicesError);
    if (blocker) {
      set({ error: blocker });
      return;
    }
    const mine = ++generation;
    sessionId = null;
    const alive = () => mine === generation;
    const { countdownSec } = useSettingsStore.getState().recording;
    set({ error: null, popover: null, phase: "countdown", countdown: countdownSec });

    for (let n = countdownSec; n > 0; n--) {
      set({ countdown: n });
      await sleep(1000);
      if (!alive()) return;
    }
    set({ countdown: 0, phase: "starting" });
    try {
      // The previews release their tracks as the setup UI unmounts; hide the bar
      // only after that has painted so neither it nor the camera light is filmed.
      await hideRecorderBar();
      await nextFrame();
      await nextFrame();
      await sleep(150);
      if (!alive()) {
        await openRecorderBar().catch(() => {});
        return;
      }
      const snapshot = await startRecording(toStartOptions(get().opts, get().devices));
      sessionId = snapshot.sessionId;
      if (!alive()) {
        if (snapshot.sessionId) await cancelRecording(snapshot.sessionId).catch(() => {});
        await openRecorderBar().catch(() => {});
        return;
      }
      await closeRecorderBar(false);
    } catch (err) {
      if (!alive()) return;
      set({ phase: "setup", error: String(err).replace(/^Error:\s*/, "") });
      await openRecorderBar().catch(() => {});
    }
  },

  cancel: async () => {
    if (get().phase === "setup") return;
    ++generation;
    const id = sessionId;
    sessionId = null;
    set({ phase: "setup", countdown: 0 });
    if (id) await cancelRecording(id).catch(() => {});
  },

  allowScreenRecording: async () => {
    try {
      await requestRecordingPermissions(["screenRecording"]);
    } catch (err) {
      set({ error: String(err) });
    }
    await get().refreshDevices();
  },

  openSettings: async (kind) => {
    set({ openedSettings: true });
    await openPrivacySettings(kind).catch((err) => set({ error: String(err) }));
  },

  openFolder: async () => {
    await openRecordingsFolder().catch((err) => set({ error: String(err) }));
  },

  moreOptions: async () => {
    try {
      await emitTo("main", "recorder:open-dialog", null);
    } catch {
      /* not inside Tauri */
    }
    await closeRecorderBar(true);
  },

  close: async () => {
    await closeRecorderBar(true);
  },

  dismissError: () => set({ error: null }),
}));
