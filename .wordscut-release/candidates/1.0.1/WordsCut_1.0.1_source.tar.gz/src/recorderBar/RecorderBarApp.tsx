/**
 * The floating recorder setup bar: one dark horizontal bar with the capture
 * modes, camera / system audio / microphone chips, the recordings folder and
 * settings. Popovers open below it; the window grows to fit them.
 */
import { useEffect, useLayoutEffect, useRef } from "react";
import { listen } from "@tauri-apps/api/event";
import {
  AppWindowMac,
  ChevronDown,
  Crop,
  Folder,
  Mic,
  MicOff,
  Monitor,
  Settings,
  ShieldAlert,
  Video,
  VideoOff,
  Volume2,
  VolumeX,
  X,
} from "lucide-react";
import { useMicLevel } from "@/components/Recorder/useMediaPreview";
import { onRecorderBarVisibility, setRecorderBarHeight, type SourceKind } from "@/lib/ipc";
import { isNative, needsCamera } from "@/lib/recorderSetup";
import { BAR_HEIGHT, isDenied, modeBlocker, screenPermissionChip } from "./barModel";
import { useBarStore, type Popover } from "./barStore";
import {
  AreaPicker,
  CameraPanel,
  DisplayPicker,
  MicPanel,
  SettingsPanel,
  WindowPicker,
} from "./Popovers";

const MODES: Array<{ kind: SourceKind; label: string; icon: typeof Monitor }> = [
  { kind: "display", label: "Display", icon: Monitor },
  { kind: "window", label: "Window", icon: AppWindowMac },
  { kind: "area", label: "Area", icon: Crop },
];

function Chip({
  icon,
  title,
  sub,
  on,
  bad,
  open,
  caret,
  onClick,
  label,
  children,
}: {
  icon: React.ReactNode;
  title: string;
  sub: string;
  on?: boolean;
  bad?: boolean;
  open?: boolean;
  caret?: boolean;
  onClick: () => void;
  label: string;
  children?: React.ReactNode;
}) {
  return (
    <button
      type="button"
      className={`rb-chip${on ? " is-on" : ""}${bad ? " is-bad" : ""}${open ? " is-open" : ""}`}
      aria-label={label}
      aria-expanded={caret ? Boolean(open) : undefined}
      aria-pressed={caret ? undefined : Boolean(on)}
      onClick={onClick}
    >
      {icon}
      <span className="rb-chip-text">
        <span className="rb-chip-title">{title}</span>
        <span className="rb-chip-sub">{sub}</span>
        {children}
      </span>
      {caret && <ChevronDown className="rb-chip-caret" />}
    </button>
  );
}

function ModeGroup() {
  const opts = useBarStore((s) => s.opts);
  const devices = useBarStore((s) => s.devices);
  const devicesError = useBarStore((s) => s.devicesError);
  const popover = useBarStore((s) => s.popover);
  const chooseMode = useBarStore((s) => s.chooseMode);
  const active = opts.sourceKind ?? "display";
  return (
    <div className="rb-modes" role="group" aria-label="Capture mode">
      {MODES.map(({ kind, label, icon: Icon }) => {
        const blocker = modeBlocker(kind, opts, devices, devicesError);
        return (
          <button
            key={kind}
            type="button"
            className={`rb-mode${active === kind || popover === kind ? " is-active" : ""}`}
            disabled={Boolean(blocker)}
            title={blocker ?? `Record ${label.toLowerCase()}`}
            aria-label={label}
            onClick={() => chooseMode(kind as "display" | "window" | "area")}
          >
            <Icon />
            <span>{label}</span>
          </button>
        );
      })}
    </div>
  );
}

function PermissionChip() {
  const devices = useBarStore((s) => s.devices);
  const opened = useBarStore((s) => s.openedSettings);
  const allow = useBarStore((s) => s.allowScreenRecording);
  const openSettings = useBarStore((s) => s.openSettings);
  const chip = screenPermissionChip(devices, opened);
  if (chip === "none") return null;
  if (chip === "restart") {
    return (
      <span className="rb-perm is-info" role="status">
        <ShieldAlert />
        Restart WordsCut to apply
      </span>
    );
  }
  return (
    <button
      type="button"
      className="rb-perm"
      onClick={() => (chip === "allow" ? void allow() : void openSettings("screenRecording"))}
    >
      <ShieldAlert />
      {chip === "allow" ? "Allow screen recording" : "Open Settings"}
    </button>
  );
}

function CameraChip() {
  const devices = useBarStore((s) => s.devices);
  const opts = useBarStore((s) => s.opts);
  const popover = useBarStore((s) => s.popover);
  const toggle = useBarStore((s) => s.togglePopover);
  const on = needsCamera(opts.mode);
  const current = devices?.video.find((d) => !d.isScreen && d.index === opts.cameraIndex);
  const denied = on && isDenied(devices?.permissions?.camera);
  return (
    <Chip
      label="Camera"
      icon={on ? <Video /> : <VideoOff />}
      title="Camera"
      sub={denied ? "Access off" : on ? (current?.name ?? "On") : "Off"}
      on={on}
      bad={denied}
      open={popover === "camera"}
      caret
      onClick={() => toggle("camera")}
    />
  );
}

function SystemAudioChip() {
  const devices = useBarStore((s) => s.devices);
  const on = useBarStore((s) => Boolean(s.opts.systemAudio));
  const toggle = useBarStore((s) => s.toggleSystemAudio);
  if (!isNative(devices)) return null;
  return (
    <Chip
      label="System audio"
      icon={on ? <Volume2 /> : <VolumeX />}
      title="System audio"
      sub={on ? "On" : "Off"}
      on={on}
      onClick={toggle}
    />
  );
}

function MicChip() {
  const devices = useBarStore((s) => s.devices);
  const opts = useBarStore((s) => s.opts);
  const micOff = useBarStore((s) => s.micOff);
  const phase = useBarStore((s) => s.phase);
  const popover = useBarStore((s) => s.popover);
  const toggle = useBarStore((s) => s.togglePopover);
  const current = devices?.audio.find((m) => m.index === opts.audioIndex);
  const on = !micOff && opts.audioIndex !== undefined;
  const denied = on && isDenied(devices?.permissions?.microphone);
  const level = useMicLevel(on && !denied && phase === "setup", current?.name);
  return (
    <Chip
      label="Microphone"
      icon={on ? <Mic /> : <MicOff />}
      title="Microphone"
      sub={denied ? "Access off" : on ? (current?.name ?? "On") : "Off"}
      on={on}
      bad={denied}
      open={popover === "mic"}
      caret
      onClick={() => toggle("mic")}
    >
      <span className="rb-level" aria-hidden="true">
        <i style={{ width: `${Math.round((on ? level.value : 0) * 100)}%` }} />
      </span>
    </Chip>
  );
}

function CountdownView() {
  const count = useBarStore((s) => s.countdown);
  const phase = useBarStore((s) => s.phase);
  const cancel = useBarStore((s) => s.cancel);
  return (
    <div className="rb-countdown" role="status" aria-live="polite">
      <span
        className="rb-count"
        key={count}
        aria-label={phase === "starting" ? "Starting" : `${count}`}
      >
        {phase === "starting" || count === 0 ? "●" : count}
      </span>
      <button type="button" className="rb-btn" onClick={() => void cancel()}>
        Cancel <span className="rb-kbd">Esc</span>
      </button>
    </div>
  );
}

function PopoverView({ which }: { which: Popover }) {
  switch (which) {
    case "display":
      return <DisplayPicker />;
    case "window":
      return <WindowPicker />;
    case "area":
      return <AreaPicker />;
    case "camera":
      return <CameraPanel />;
    case "mic":
      return <MicPanel />;
    case "settings":
      return <SettingsPanel />;
  }
}

export function RecorderBarApp() {
  const phase = useBarStore((s) => s.phase);
  const popover = useBarStore((s) => s.popover);
  const error = useBarStore((s) => s.error);
  const refresh = useBarStore((s) => s.refreshDevices);
  const toggle = useBarStore((s) => s.togglePopover);
  const dismissError = useBarStore((s) => s.dismissError);
  const below = useRef<HTMLDivElement>(null);

  // Devices on mount, on focus and whenever Rust shows the bar again.
  useEffect(() => {
    void refresh();
    const onFocus = () => void refresh();
    window.addEventListener("focus", onFocus);
    let off: (() => void) | undefined;
    let offRecord: (() => void) | undefined;
    let disposed = false;
    void onRecorderBarVisibility((visible) => visible && void refresh())
      .then((u) => (disposed ? u() : (off = u)))
      .catch(() => {});
    // The editor's record shortcut, forwarded while the bar is up.
    void listen("recorder-bar:record", () => void useBarStore.getState().start())
      .then((u) => (disposed ? u() : (offRecord = u)))
      .catch(() => {});
    return () => {
      disposed = true;
      window.removeEventListener("focus", onFocus);
      off?.();
      offRecord?.();
    };
  }, [refresh]);

  // Esc: cancel a countdown, else close a popover, else close the bar. Enter: start.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const s = useBarStore.getState();
      if (e.key === "Escape") {
        e.preventDefault();
        if (s.phase !== "setup") void s.cancel();
        else if (s.popover) s.togglePopover(s.popover);
        else void s.close();
      } else if (e.key === "Enter" && s.phase === "setup") {
        const tag = (e.target as HTMLElement | null)?.tagName;
        if (tag === "BUTTON" || tag === "SELECT" || tag === "INPUT") return;
        e.preventDefault();
        void s.start();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  // The window is the bar plus whatever is open below it.
  useLayoutEffect(() => {
    const el = below.current;
    if (!el) return;
    const apply = () => void setRecorderBarHeight(BAR_HEIGHT + el.offsetHeight).catch(() => {});
    apply();
    if (typeof ResizeObserver === "undefined") return;
    const ro = new ResizeObserver(apply);
    ro.observe(el);
    return () => ro.disconnect();
  }, [popover, error, phase]);

  const setup = phase === "setup";
  return (
    <div className="rb">
      {setup ? (
        <div className="rb-bar" data-tauri-drag-region>
          <button
            type="button"
            className="rb-icon-btn"
            aria-label="Close recorder"
            title="Close (Esc)"
            onClick={() => void useBarStore.getState().close()}
          >
            <X className="h-4 w-4" />
          </button>
          <div className="rb-divider" data-tauri-drag-region />
          <ModeGroup />
          <PermissionChip />
          <div className="rb-divider" data-tauri-drag-region />
          <CameraChip />
          <SystemAudioChip />
          <MicChip />
          <div className="rb-gap" data-tauri-drag-region />
          <button
            type="button"
            className="rb-icon-btn"
            aria-label="Open recordings folder"
            title="Open recordings folder"
            onClick={() => void useBarStore.getState().openFolder()}
          >
            <Folder className="h-[18px] w-[18px]" />
          </button>
          <button
            type="button"
            className={`rb-icon-btn${popover === "settings" ? " is-open" : ""}`}
            aria-label="Recording settings"
            aria-expanded={popover === "settings"}
            title="Settings"
            onClick={() => toggle("settings")}
          >
            <Settings className="h-[18px] w-[18px]" />
          </button>
        </div>
      ) : (
        <div className="rb-bar" data-tauri-drag-region>
          <CountdownView />
        </div>
      )}
      <div className="rb-below" ref={below}>
        {error && setup && (
          <div className="rb-error" role="alert">
            <span>{error}</span>
            <button
              type="button"
              className="rb-icon-btn"
              aria-label="Dismiss"
              onClick={dismissError}
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        )}
        {setup && popover && <PopoverView which={popover} />}
      </div>
    </div>
  );
}
