/**
 * Entry point of the floating recorder setup bar. Mounts ONLY the bar: no
 * editor App, autosave, media import or transcription run in this window.
 */
import React from "react";
import ReactDOM from "react-dom/client";
import { RecorderBarApp } from "./RecorderBarApp";
import "../styles/globals.css";
import "./recorderBar.css";

document.documentElement.dataset.theme = "dark";
ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <RecorderBarApp />
  </React.StrictMode>,
);
