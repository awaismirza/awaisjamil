/** Pure view-model logic of the recorder bar. No React, no Tauri. */

import type {
  PermissionState,
  RecordOptions,
  RecordingDevices,
  SourceKind,
  WindowDevice,
} from "@/lib/ipc";
import { isNative, startBlocker } from "@/lib/recorderSetup";

export const BAR_HEIGHT = 76;
export const OWN_WINDOW_PREFIX = "WordsCut Recording Controls";

/** Windows worth offering: ours (controller, this bar) are excluded from footage anyway. */
export function visibleWindows(devices: RecordingDevices | null): WindowDevice[] {
  return (devices?.windows ?? []).filter((w) => !w.title.startsWith(OWN_WINDOW_PREFIX));
}

export function screensOf(devices: RecordingDevices | null) {
  return devices?.video.filter((d) => d.isScreen) ?? [];
}

/**
 * Why a mode button must be disabled, or null. Asks `startBlocker` about the
 * mode with a placeholder pick, so "Choose a window" does not disable the very
 * button that lets the user choose one.
 */
export function modeBlocker(
  kind: SourceKind,
  opts: RecordOptions,
  devices: RecordingDevices | null,
  devicesError: string | null,
): string | null {
  if (!devices || devicesError) return startBlocker(opts, devices, devicesError);
  if (kind !== "display" && !isNative(devices)) {
    return "Window and Area capture need the native recorder.";
  }
  const screen = screensOf(devices).find((s) => s.index === opts.screenIndex);
  const probe: RecordOptions = { ...opts, mode: opts.mode, sourceKind: kind };
  if (kind === "window") {
    const first = visibleWindows(devices)[0];
    if (!first) return "No windows to record.";
    probe.windowId = first.id;
  }
  if (kind === "area") {
    const info = devices.displays?.find((d) => d.index === screen?.index);
    probe.area = info ? { x: 0, y: 0, width: info.width, height: info.height } : undefined;
  }
  return startBlocker(probe, devices, devicesError);
}

export type ScreenPermissionChip = "none" | "allow" | "settings" | "restart";

/**
 * The screen-recording call to action. `openedSettings` is set once the user was
 * sent to System Settings: macOS applies a grant only after a restart.
 */
export function screenPermissionChip(
  devices: RecordingDevices | null,
  openedSettings: boolean,
): ScreenPermissionChip {
  if (!devices || !isNative(devices)) return "none";
  const state: PermissionState | undefined = devices.permissions?.screenRecording;
  if (!state || state === "granted") return "none";
  if (state === "notDetermined") return "allow";
  return openedSettings ? "restart" : "settings";
}

export function isDenied(state: PermissionState | undefined): boolean {
  return state === "denied" || state === "restricted";
}
