/**
 * Entry point of the desktop recording controller window. Mounts ONLY the
 * controller: no editor App, autosave, media import or transcription run here.
 */
import React from "react";
import ReactDOM from "react-dom/client";
import { ControllerApp } from "./ControllerApp";
import "../styles/globals.css";

document.documentElement.dataset.theme = "dark";
ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <ControllerApp />
  </React.StrictMode>,
);
