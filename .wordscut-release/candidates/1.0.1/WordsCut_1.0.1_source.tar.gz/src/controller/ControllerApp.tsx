/**
 * The desktop recording controller (≈320 × 52, opaque). It mirrors the Rust
 * recording session and sends session-id actions; it owns no recording state of
 * its own and and has no import or speech-recognition code.
 */
import { useEffect, useState } from "react";
import { Flag, MoreHorizontal, Pause, Play, Square, X } from "lucide-react";
import {
  cancelRecording,
  markRecording,
  pauseRecording,
  restartRecording,
  resumeRecording,
  setControllerExpanded,
  setControllerHidden,
  showMainWindow,
  stopRecording,
  type RecordingSnapshot,
} from "@/lib/ipc";
import { controllerModel } from "@/lib/controllerModel";
import { idleSnapshot } from "@/lib/snapshotDefaults";
import { startSnapshotMirror } from "@/lib/snapshotMirror";

type Confirm = "restart" | "discard" | null;

export function ControllerApp() {
  const [snapshot, setSnapshot] = useState<RecordingSnapshot>(idleSnapshot());
  const [menu, setMenu] = useState(false);
  const [confirm, setConfirm] = useState<Confirm>(null);
  const [failure, setFailure] = useState<string | null>(null);

  useEffect(() => {
    let dispose: (() => void) | null = null;
    let cancelled = false;
    void startSnapshotMirror(setSnapshot).then((d) => {
      if (cancelled) d();
      else dispose = d;
    });
    return () => {
      cancelled = true;
      dispose?.();
    };
  }, []);

  // A take that ended or changed under an open menu/confirmation closes both.
  useEffect(() => {
    setMenu(false);
    setConfirm(null);
  }, [snapshot.sessionId, snapshot.phase]);

  useEffect(() => {
    void setControllerExpanded(menu).catch(() => {});
  }, [menu]);

  const model = controllerModel(snapshot);
  const id = snapshot.sessionId;
  const run = (action: (sessionId: string) => Promise<unknown>) => () => {
    if (!id) return;
    setFailure(null);
    setMenu(false);
    setConfirm(null);
    void action(id).catch((e) => setFailure(String(e)));
  };

  if (confirm) {
    const restart = confirm === "restart";
    return (
      <div className="rc-bar" role="alertdialog" aria-label="Confirm">
        <span className="rc-label">
          {restart ? "Discard this take and restart?" : "Delete this recording?"}
        </span>
        <button type="button" className="rc-text" onClick={() => setConfirm(null)}>
          Keep
        </button>
        <button
          type="button"
          className="rc-text is-danger"
          autoFocus
          onClick={run(restart ? restartRecording : cancelRecording)}
        >
          {restart ? "Restart" : "Delete"}
        </button>
      </div>
    );
  }

  return (
    <div
      className={`rc-bar${model.status === "paused" ? " is-paused" : ""}${
        model.status === "interrupted" ? " is-error" : ""
      }`}
      role="status"
      aria-label="Recording controls"
    >
      <span className="rc-grip" data-tauri-drag-region aria-hidden="true" />
      <span className="rc-dot" data-tauri-drag-region aria-hidden="true" />
      <span className="rc-time" data-tauri-drag-region>
        {model.time}
      </span>
      <span
        className="rc-label"
        data-tauri-drag-region
        title={failure ?? snapshot.error ?? undefined}
      >
        {failure ?? model.label}
      </span>
      {snapshot.keyNames && (
        <span
          className="rc-keys"
          title="Key names are being recorded. Keys typed in any app are captured during screen recording."
        >
          {snapshot.keyNames === "all" ? "All characters ON" : "Key names ON"}
        </span>
      )}
      <span className="rc-actions">
        {model.canPause && (
          <button
            type="button"
            aria-label="Pause recording"
            title="Pause"
            onClick={run(pauseRecording)}
          >
            <Pause className="h-4 w-4" />
          </button>
        )}
        {model.canResume && (
          <button
            type="button"
            aria-label="Resume recording"
            title="Resume"
            onClick={run(resumeRecording)}
          >
            <Play className="h-4 w-4" />
          </button>
        )}
        {model.canMark && (
          <button
            type="button"
            aria-label="Mark a moment"
            title="Mark a moment"
            onClick={run(markRecording)}
          >
            <Flag className="h-4 w-4" />
          </button>
        )}
        {model.canStop && (
          <button
            type="button"
            className="is-stop"
            aria-label="Stop and add to video"
            title="Stop and add to video"
            onClick={run(stopRecording)}
          >
            <Square className="h-4 w-4" />
          </button>
        )}
        {model.status === "starting" && (
          <button
            type="button"
            aria-label="Cancel startup"
            title="Cancel"
            onClick={run(cancelRecording)}
          >
            <X className="h-4 w-4" />
          </button>
        )}
        <button
          type="button"
          aria-label="More actions"
          aria-haspopup="menu"
          aria-expanded={menu}
          title="More"
          onClick={() => setMenu((open) => !open)}
        >
          <MoreHorizontal className="h-4 w-4" />
        </button>
      </span>
      {menu && (
        <div className="rc-menu" role="menu">
          <button type="button" role="menuitem" onClick={() => void showMainWindow()}>
            Show editor
          </button>
          <button type="button" role="menuitem" onClick={() => void setControllerHidden(true)}>
            Hide controls (restore from the menu bar)
          </button>
          {model.canRestart && (
            <button
              type="button"
              role="menuitem"
              onClick={() => {
                setMenu(false);
                setConfirm("restart");
              }}
            >
              Restart take…
            </button>
          )}
          {model.canDiscard && (
            <button
              type="button"
              role="menuitem"
              className="is-danger"
              onClick={() => {
                setMenu(false);
                setConfirm("discard");
              }}
            >
              Discard recording…
            </button>
          )}
        </div>
      )}
    </div>
  );
}
