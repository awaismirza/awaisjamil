import { useCallback, useEffect, useState } from "react";
import type { SourceMedia } from "@/lib/edl";
import { generatePreviewProxy, type PreviewQuality } from "@/lib/ipc";
type ProxyQuality = Exclude<PreviewQuality, "original">;
interface CachedSource {
  path?: string;
  error?: string;
  pending?: Promise<void>;
}
/** Preview-only preference and paths. The project/export always keep originals. */
export function usePreviewSource(media: SourceMedia | undefined) {
  const [quality, updateQuality] = useState<PreviewQuality>("original");
  const [cache] = useState(() => new WeakMap<SourceMedia, Map<ProxyQuality, CachedSource>>());
  const [, refresh] = useState(0);
  const setQuality = useCallback(
    (next: PreviewQuality) => {
      // A deliberate quality change retries failed generation/playback. Ready
      // proxies remain reusable, including Original -> Balanced -> Original.
      if (media && next !== "original" && next !== quality) {
        const sources = cache.get(media);
        if (sources?.get(next)?.error) sources.delete(next);
      }
      updateQuality(next);
    },
    [cache, media, quality],
  );
  useEffect(() => {
    if (!media || !media.width || quality === "original") return;
    let active = true;
    let sources = cache.get(media);
    if (!sources) {
      sources = new Map();
      cache.set(media, sources);
    }
    let entry = sources.get(quality);
    if (!entry) {
      const request: CachedSource = {};
      sources.set(quality, request);
      const destination = sources;
      request.pending = generatePreviewProxy(media, quality).then(
        (path) => {
          if (destination.get(quality) === request) destination.set(quality, { path });
        },
        (error) => {
          if (destination.get(quality) === request)
            destination.set(quality, { error: String(error) });
        },
      );
      entry = request;
    }
    // Rejoining a still-pending source subscribes to the same request. Results
    // may warm inactive cache entries but never replace another source's path.
    void entry.pending?.then(() => {
      if (active) refresh((revision) => revision + 1);
    });
    return () => {
      active = false;
    };
  }, [cache, media, quality]);
  const current = media && quality !== "original" ? cache.get(media)?.get(quality) : undefined;
  const proxy = quality !== "original" && !!media?.width;
  const fallback = useCallback(() => {
    if (media && quality !== "original") {
      const sources = cache.get(media) ?? new Map<ProxyQuality, CachedSource>();
      sources.set(quality, { error: "Proxy could not play. Using original media." });
      cache.set(media, sources);
      refresh((revision) => revision + 1);
    }
  }, [cache, media, quality]);
  return {
    path: proxy && current?.path ? current.path : media?.path,
    usingProxy: !!(proxy && current?.path),
    quality,
    setQuality,
    fallback,
    status: !proxy
      ? ""
      : current?.error
        ? `Original media · ${current.error}`
        : current?.path
          ? ""
          : "Preparing preview · using original · cancel in Jobs",
  };
}
