import type { EditorAction } from "@/lib/editorShortcuts";
import { formatAccelerator, type ShortcutAction } from "@/lib/shortcuts";
import { useSettingsStore } from "@/stores/settingsStore";

/** The user's current shortcut for an action, as a Mac-style label such as ⌥⌘R. */
export function useShortcutLabel(action: ShortcutAction): string {
  return useSettingsStore((s) => formatAccelerator(s.shortcuts[action]));
}

/** The user's current editor hotkey for an action, as a Mac-style label such as ⌘Z. */
export function useEditorShortcutLabel(action: EditorAction): string {
  return useSettingsStore((s) => formatAccelerator(s.editorShortcuts[action]));
}
