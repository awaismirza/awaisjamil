import { useCallback, useLayoutEffect, useRef, useState, type RefObject } from "react";
import { SeekQueue, type IssuedSeek } from "@/lib/seekQueue";
import { recordTiming } from "@/lib/playbackDiagnostics";
/** One decoder seek in flight. A pending drag release replaces approximate requests. */
export function useCoalescedSeek(
  videoRef: RefObject<HTMLVideoElement | null>,
  mediaId: string,
  sourceId: string,
  revision: object,
) {
  const queue = useRef(new SeekQueue());
  const active = useRef<IssuedSeek | null>(null);
  const removeListener = useRef<(() => void) | null>(null);
  const awaitingFrame = useRef<number | null>(null);
  const seekStarted = useRef<number | null>(null);
  const [generation, setGeneration] = useState(0);
  useLayoutEffect(() => {
    const currentQueue = queue.current;
    currentQueue.reset();
    active.current = null;
    awaitingFrame.current = null;
    seekStarted.current = null;
    removeListener.current?.();
    removeListener.current = null;
    return () => {
      currentQueue.reset();
      active.current = null;
      removeListener.current?.();
    };
  }, [mediaId, sourceId, revision]);
  const apply = useCallback(
    (first: IssuedSeek | null) => {
      const el = videoRef.current;
      if (!el || !first) return;
      const issue = (operation: IssuedSeek | null) => {
        if (!operation) {
          active.current = null;
          return;
        }
        active.current = operation;
        const started = globalThis.performance.now();
        const finish = () => {
          if (
            active.current !== operation ||
            el.getAttribute("src") !== operation.sourceId ||
            el.seeking
          )
            return;
          if (operation.exact && Math.abs(el.currentTime - operation.time) > 0.08) return;
          removeListener.current?.();
          removeListener.current = null;
          recordTiming("seek", globalThis.performance.now() - started);
          issue(queue.current.complete(operation.token));
        };
        // No assignment means no late seeked event can acknowledge the following request.
        if (!el.seeking && el.currentTime === operation.time) {
          finish();
          return;
        }
        awaitingFrame.current = operation.time;
        seekStarted.current = started;
        setGeneration((value) => value + 1);
        el.addEventListener("seeked", finish);
        removeListener.current = () => el.removeEventListener("seeked", finish);
        try {
          const fast = (el as HTMLVideoElement & { fastSeek?: (time: number) => void }).fastSeek;
          if (!operation.exact && fast) fast.call(el, operation.time);
          else el.currentTime = operation.time;
        } catch {
          removeListener.current?.();
          removeListener.current = null;
          active.current = null;
          awaitingFrame.current = null;
          queue.current.reset();
        }
      };
      issue(first);
    },
    [videoRef],
  );
  const seek = useCallback(
    (time: number, exact = true) => {
      apply(queue.current.request({ mediaId, sourceId, time, exact }));
    },
    [apply, mediaId, sourceId],
  );
  const acceptFrame = useCallback(
    (time: number) => {
      if (active.current) return false;
      if (awaitingFrame.current !== null) {
        if (!videoRef.current || Math.abs(time - videoRef.current.currentTime) > 0.1) return false;
        awaitingFrame.current = null;
        if (seekStarted.current !== null)
          recordTiming("seekPresented", globalThis.performance.now() - seekStarted.current);
        seekStarted.current = null;
      }
      return true;
    },
    [videoRef],
  );
  const isSeeking = useCallback(() => active.current !== null, []);
  return { seek, acceptFrame, isSeeking, generation };
}
