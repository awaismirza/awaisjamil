/** Debounced/periodic saves share the manual-save queue and never clear newer edits. */
import { useEffect } from "react";
import { useProjectStore } from "@/stores/projectStore";
import { useUIStore } from "@/stores/uiStore";
import { saveProjectRevision } from "@/lib/saveCoordinator";
const DEBOUNCE_MS = 2000;
const INTERVAL_MS = 30_000;
function saveLatest() {
  const { project, dirty, filePath } = useProjectStore.getState();
  if (!dirty || !filePath) return;
  void saveProjectRevision(project, filePath, filePath).catch((error) => {
    useUIStore
      .getState()
      .pushToast({ title: "Auto-save failed", description: String(error), variant: "destructive" });
  });
}
export function useAutoSave() {
  const project = useProjectStore((s) => s.project);
  const dirty = useProjectStore((s) => s.dirty);
  const filePath = useProjectStore((s) => s.filePath);
  useEffect(() => {
    if (!dirty || !filePath) return;
    const timer = setTimeout(saveLatest, DEBOUNCE_MS);
    return () => clearTimeout(timer);
  }, [project, dirty, filePath]);
  useEffect(() => {
    if (!filePath) return;
    const timer = setInterval(saveLatest, INTERVAL_MS);
    return () => clearInterval(timer);
  }, [filePath]);
}
