import { DEFAULT_PADDING_MS } from "@/lib/edl";
import { detectPauses } from "@/lib/ipc";
import { pushUndoToast } from "@/lib/undoToast";
import { useFillerStore } from "@/stores/fillerStore";
import { useProjectStore } from "@/stores/projectStore";
import { useUIStore } from "@/stores/uiStore";

/** Silences shorter than this are left alone by "Trim silences". */
export const TRIM_SILENCE_MIN_SEC = 0.6;

/** Pauses shorter than this are never detected. */
export const DETECT_PAUSE_MIN_SEC = 0.5;

/**
 * The cleanup operations (fillers, pauses, silences) behind one hook, so the
 * sidebar Cleanup panel and anything else share the same cut paths and toasts.
 * Every success toast offers Undo.
 */
export function useCleanupActions() {
  const project = useProjectStore((s) => s.project);
  const trimSilences = useProjectStore((s) => s.trimSilences);
  const deleteFillers = useProjectStore((s) => s.deleteFillers);
  const setPauseTokens = useProjectStore((s) => s.setPauseTokens);
  const deletePausesLongerThan = useProjectStore((s) => s.deletePausesLongerThan);
  const shortenPausesLongerThan = useProjectStore((s) => s.shortenPausesLongerThan);
  const selectedFillers = useFillerStore((s) => s.selected);
  const pushToast = useUIStore((s) => s.pushToast);
  const withProcessingEdit = useUIStore((s) => s.withProcessingEdit);

  const mediaPath = () => Object.values(project.media)[0]?.path;

  async function removeFillers(): Promise<void> {
    await withProcessingEdit("Removing fillers…", () => {
      const removed = deleteFillers(selectedFillers);
      if (removed === 0) {
        pushToast({ title: "No filler words found" });
      } else {
        pushUndoToast(
          `Removed ${removed} filler word${removed === 1 ? "" : "s"}`,
          "Matching audio ranges are cut from the timeline.",
        );
      }
    });
  }

  async function trimAudioSilences(): Promise<void> {
    const path = mediaPath();
    if (!path) {
      pushToast({ title: "No media loaded", description: "Import a video file first." });
      return;
    }
    await withProcessingEdit("Trimming silences…", async () => {
      try {
        // Silences come from the audio signal, not word gaps: DTW word spans
        // absorb the silence before a word, so gaps between words are unreliable.
        const silences = await detectPauses({
          mediaPath: path,
          noiseThreshold: -35,
          minDuration: TRIM_SILENCE_MIN_SEC,
        });
        const paddingSec = (project.settings.paddingMs ?? DEFAULT_PADDING_MS) / 1000;
        const removed = trimSilences(silences, {
          minDuration: TRIM_SILENCE_MIN_SEC,
          keepSec: paddingSec * 2,
        });
        if (removed === 0) {
          pushToast({ title: "Nothing to trim", description: "No silences longer than 600ms found." });
        } else {
          pushUndoToast(`Trimmed ${removed} silence${removed === 1 ? "" : "s"}`);
        }
      } catch (e) {
        pushToast({ title: "Silence detection failed", description: String(e), variant: "destructive" });
      }
    });
  }

  async function detectAllPauses(): Promise<void> {
    const path = mediaPath();
    if (!path) {
      pushToast({ title: "No media loaded", description: "Import a video file first." });
      return;
    }
    await withProcessingEdit("Detecting pauses…", async () => {
      try {
        const pauses = await detectPauses({
          mediaPath: path,
          noiseThreshold: -35,
          minDuration: DETECT_PAUSE_MIN_SEC,
        });
        // Always replace — prevents duplicate badges on repeated detection.
        setPauseTokens(pauses);
        pushToast(
          pauses.length === 0
            ? { title: "No pauses found", description: "No silences longer than 0.5 s detected at –35 dB." }
            : {
                title: `Detected ${pauses.length} pause${pauses.length === 1 ? "" : "s"}`,
                description: "Shown inline in the transcript.",
              },
        );
      } catch (e) {
        pushToast({ title: "Pause detection failed", description: String(e), variant: "destructive" });
      }
    });
  }

  async function removePauses(longerThan: number): Promise<void> {
    await withProcessingEdit("Removing pauses…", () => {
      const removed = deletePausesLongerThan(longerThan);
      if (removed === 0) {
        pushToast({
          title: longerThan > 0 ? `No pauses longer than ${longerThan}s` : "No pauses removed",
          description: "Nothing to remove.",
        });
      } else {
        pushUndoToast(`Removed ${removed} pause${removed === 1 ? "" : "s"}`);
      }
    });
  }

  async function shortenPauses(longerThan: number, shortenTo: number): Promise<void> {
    await withProcessingEdit("Shortening pauses…", () => {
      const shortened = shortenPausesLongerThan({ longerThan, shortenTo });
      if (shortened === 0) {
        pushToast({
          title: `No pauses longer than ${longerThan}s`,
          description: "Nothing to shorten.",
        });
      } else {
        pushUndoToast(
          `Shortened ${shortened} pause${shortened === 1 ? "" : "s"} to ${shortenTo}s`,
          "Cut from the timeline and export.",
        );
      }
    });
  }

  return { removeFillers, trimAudioSilences, detectAllPauses, removePauses, shortenPauses };
}
