/**
 * Editor keyboard shortcuts. The bindings live in the data-driven registry
 * (`lib/editorShortcuts.ts`, rebindable in Settings); this hook only matches a
 * key press to an action and runs it. Defaults:
 *   Space play/pause, J/K/L transport, I/O mark in/out, B chapter, X clear,
 *   Cmd+Shift+X extract range, Backspace/Delete cut selected words,
 *   Cmd+Backspace/Delete delete range, Cmd+Z / Cmd+Shift+Z undo / redo,
 *   Cmd+S save, Cmd+E export.
 *
 * Hotkeys are ignored during IME composition, while a modal dialog or menu is
 * open, and (per action) while typing in an input or the transcript.
 */

import { useEffect } from "react";
import { usePlayerStore } from "@/stores/playerStore";
import { useProjectStore, useTemporalProjectStore } from "@/stores/projectStore";
import { useSettingsStore } from "@/stores/settingsStore";
import { useUIStore } from "@/stores/uiStore";
import { useVoiceOverStore } from "@/stores/voiceOverStore";
import { wordIdToOutputTime } from "@/lib/edl";
import { applyMarkedRange, setMarkIn, setMarkOut } from "@/lib/rangeActions";
import { editorDef, eventAccelerator, matchEditorShortcut } from "@/lib/editorShortcuts";
import { normalizeAccelerator } from "@/lib/shortcuts";
import type { EditorAction } from "@/lib/editorShortcuts";

function isMac() {
  return typeof navigator !== "undefined" && /Mac|iPhone|iPad/.test(navigator.platform);
}

const SHUTTLE_RATES = [1, 1.2, 1.5, 1.8, 2] as const;

function nextShuttleRate(current: number) {
  const idx = SHUTTLE_RATES.findIndex((rate) => rate > current + 0.01);
  return idx === -1 ? SHUTTLE_RATES[SHUTTLE_RATES.length - 1] : SHUTTLE_RATES[idx]!;
}

/** A modal dialog or menu is open: keys belong to it, not the editor. */
const MODAL_SELECTOR =
  '[role="dialog"]:not([aria-modal="false"]), [role="alertdialog"], [aria-modal="true"], [role="menu"]';

function textTarget(target: HTMLElement | null): "native" | "editable" | null {
  if (!target) return null;
  if (["INPUT", "TEXTAREA", "SELECT"].includes(target.tagName)) return "native";
  if (target.isContentEditable || target.closest?.('[contenteditable=""],[contenteditable="true"]'))
    return "editable";
  return null;
}

function deleteSelectedWords(clearDomSelection: boolean) {
  const player = usePlayerStore.getState();
  const selectedIds = [...player.selectedWordIds];
  if (selectedIds.length === 0) return false;
  void useUIStore
    .getState()
    .withProcessingEdit("Updating timeline…", () => {
      useProjectStore.getState().deleteWords(selectedIds);
    })
    .then(() => {
      player.setSelectedWordIds([]);
      if (clearDomSelection) window.getSelection()?.removeAllRanges();
    });
  return true;
}

/** Run an action. Returns true when it did something (the key press is then consumed). */
function runEditorAction(action: EditorAction, slow: boolean): boolean {
  const s = usePlayerStore.getState();
  switch (action) {
    case "playPause": {
      const willPause = s.playing;
      if (!s.playing && s.selectedWordIds.size > 0) {
        const project = useProjectStore.getState().project;
        let best: ReturnType<typeof wordIdToOutputTime> = null;
        for (const id of s.selectedWordIds) {
          const mapped = wordIdToOutputTime(project, id);
          if (mapped && (!best || mapped.outputTime < best.outputTime)) best = mapped;
        }
        if (best) {
          window.dispatchEvent(
            new CustomEvent("yusafcut:seek-output", {
              detail: { time: best.outputTime, play: true },
            }),
          );
        }
      }
      if (willPause) s.setRate(1);
      window.dispatchEvent(new CustomEvent("yusafcut:toggle-play"));
      return true;
    }
    case "rewind": {
      const nextRate = slow ? 0.5 : nextShuttleRate(s.playing ? s.rate : 0);
      s.setRate(nextRate);
      window.dispatchEvent(
        new CustomEvent("yusafcut:seek-output", {
          detail: { time: Math.max(0, s.currentTime - 3 * nextRate), play: true },
        }),
      );
      return true;
    }
    case "pause":
      s.setRate(1);
      window.dispatchEvent(new CustomEvent("yusafcut:pause"));
      return true;
    case "forward":
      s.setRate(nextShuttleRate(s.playing ? s.rate : 0));
      window.dispatchEvent(new CustomEvent("yusafcut:play"));
      return true;
    case "markIn":
      setMarkIn();
      return true;
    case "markOut":
      setMarkOut();
      return true;
    case "addChapter": {
      const projectStore = useProjectStore.getState();
      if (projectStore.project.segments.length === 0) return false;
      projectStore.addChapter(s.currentTime);
      return true;
    }
    case "clearSelection":
      if (s.timelineMarkIn === null && s.timelineMarkOut === null && s.selectedWordIds.size === 0)
        return false;
      s.clearTimelineRange();
      s.setSelectedWordIds([]);
      return true;
    case "extractRange":
      void applyMarkedRange("extract");
      return true;
    case "deleteWords":
    case "deleteWordsAlt":
      return deleteSelectedWords(true);
    case "deleteRange":
    case "deleteRangeAlt": {
      const hasRange = s.timelineMarkIn !== null && s.timelineMarkOut !== null;
      if (hasRange) {
        void applyMarkedRange("delete");
        return true;
      }
      return deleteSelectedWords(false);
    }
    case "undo": {
      const temporal = useProjectStore.temporal.getState();
      if (temporal.pastStates.length === 0) return false;
      temporal.undo();
      return true;
    }
    case "redo": {
      const temporal = useProjectStore.temporal.getState();
      if (temporal.futureStates.length === 0) return false;
      temporal.redo();
      return true;
    }
    case "save":
      window.dispatchEvent(new CustomEvent("yusafcut:save"));
      return true;
    case "export":
      window.dispatchEvent(new CustomEvent("yusafcut:export"));
      return true;
    case "voiceOver":
      useVoiceOverStore.getState().toggle();
      return true;
    default:
      // Review-dialog keys are handled by the dialog itself.
      return false;
  }
}

export function useKeyboardShortcuts() {
  useEffect(() => {
    function onKeyDown(e: KeyboardEvent) {
      // IME composition (keyCode 229 covers Safari's keydown-after-compositionend).
      if (e.isComposing || e.keyCode === 229) return;

      const mac = isMac();
      const { editorShortcuts, shortcuts } = useSettingsStore.getState();
      const hit = matchEditorShortcut(editorShortcuts, e, mac);
      if (!hit) return;

      // A global recorder shortcut owns its combination (the OS already fired it).
      const acc = eventAccelerator(e, mac);
      if (Object.values(shortcuts).some((v) => normalizeAccelerator(v) === acc)) return;

      const def = editorDef(hit.action);

      // While a heavy edit is processing, swallow transport + delete shortcuts so
      // playback can't start and edits can't stack against a half-built timeline.
      if (def.lockedWhileProcessing && useUIStore.getState().isProcessingEdit) {
        e.preventDefault();
        return;
      }

      // Save / export (textScope "always") still work over a modal.
      if (def.textScope !== "always" && document.querySelector(MODAL_SELECTOR)) return;

      const text = textTarget(e.target as HTMLElement | null);
      if (
        text &&
        def.textScope !== "always" &&
        !(text === "editable" && def.textScope === "editable")
      )
        return;

      if (e.repeat && !def.repeatable) return;

      if (runEditorAction(hit.action, hit.slow)) e.preventDefault();
    }

    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, []);

  // Touch the temporal hook so tree-shaking can't drop it.
  // This is intentional — useTemporalProjectStore initialises the temporal
  // store even when no other component has subscribed yet.
  void useTemporalProjectStore;
}
