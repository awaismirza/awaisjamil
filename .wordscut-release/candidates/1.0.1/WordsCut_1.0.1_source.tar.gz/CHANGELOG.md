# Changelog

All notable changes to WordsCut will be documented in this file. Earlier
entries retain the product name used when those versions shipped.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.1] — Unreleased

- Retry Apple ticket stapling/validation and Gatekeeper up to three times after transient network errors; every signing gate still must pass.

### Distribution migration

- Consolidate product pages, paid-checkout readiness, signing credentials and draft-only release orchestration in `awaismirza/awaisjamil`. Application source remains private; the earlier AGPL/GPL release and sources are preserved privately for existing recipients.
- Retire this repository's duplicate release and Pages workflows. Source-specific signing/build scripts and development CI remain here; the personal website repository owns distribution entry points.
- Keep the signed 1.0.0 installer unchanged. This source-version bump prepares the next working version; no 1.0.1 installer or proprietary licence is published.
- Feed native engine test-fixture audio/video inputs independently and finish each track individually, avoiding cross-input backpressure starvation in offline AVAssetWriter generation. Preserve the real writer error on stderr before XCTest aborts. Local engine media/core suites pass; hosted verification is tracked in HANDOFF.

### Changed

- Rename the private source repository to `awaismirza/wordscut-app`; keep the public website and release repository at `awaismirza/wordscut`.
- Update current project documentation and clone instructions to use WordsCut branding while retaining compatibility-sensitive YusafCut identifiers.
- Refresh the README and release ledger with the completed v1.0.0 signed-release verification and current repository links.

## [4.51.0] — 2026-10-21

- CI verification: detach native fixture tasks from XCTest’s blocked setup executor and bound encoder readiness/setup waits; explicitly import VideoToolbox in encoder capability tests, avoiding an SDK-dependent transitive import. Refresh the website social preview to the owner-requested purple palette.

- Rebrand the Mac app, recording controls, permission messages, CLI help and distribution assets as WordsCut; add the original emerald text/play icon. Preserve projects, bundle ID, data keys and helper identifiers. Recognize both legacy and new GUI executable names.
- Add a public download website with a word-deletion demonstration, actual app screenshots, privacy information and published-release discovery.
- Harden release signing: fail without credentials, sign nested code inside out, notarize/staple/assess both app and DMG, publish matching application/native dependency source archives, pin CI actions and whisper sources, and verify release versions.
- Correct MAS sidecar prerequisites and isolate store build output; store submission remains blocked pending sandbox/file-access and licensing review.
- Make the combined timing/compositing regression use software encoding on virtual CI Macs; preserve its frame, pixel and audio assertions and retain separate hardware verification.
- Verification and deployment status are recorded in `docs/wordscut-release.md` and HANDOFF.

## [Unreleased]

## [1.0.0] — 2026-10-22

- First public WordsCut release: transcript-based video editing for Apple Silicon, rebranded from YusafCut with project and data compatibility preserved.
- Developer ID signed and notarized macOS distribution, with matching application source and native dependency source archives plus SHA-256 verification published with the release.
- Release numbering reset for the first public WordsCut release at the owner's request. The earlier Scribe v1.0.0 tag in the private development repository is historical and remains unchanged.

## [4.51.1] — 2026-10-22

- Serialize AVFoundation media-fixture creation in Swift engine tests; virtual macOS runners can fail concurrent writer sessions and leave the tests with unreadable MOVs. Fixture setup now fails immediately if any of its five sources could not be produced.
- Add a separate macOS job that downloads the actual Actions release artifact, verifies every SHA-256 entry, mounts the DMG, validates the DMG and embedded app signatures and notarization tickets, checks Gatekeeper, and confirms the expected Developer ID team and bundle ID. Tag publication now depends on this downloaded-artifact verification job succeeding.
- Document release verification gates and hosted-run evidence in `docs/wordscut-release.md` and `docs/HANDOFF.md`.

## [4.50.5] - 2026-10-21

### Added
- GitHub Actions: `.github/workflows/ci.yml` (PR checks: check, Vitest, Rust tests (non-blocking until proven on a runner), Swift engine tests) and `.github/workflows/release.yml` (tag-only `vX.Y.Z`: verifies tag == the three version files and commit on `main`, builds sidecars + helper, signs, notarizes, staples, publishes DMG + SHA256SUMS to Releases; `workflow_dispatch` is a dry run that never publishes). `scripts/build-whisper.sh`. **Never run on GitHub yet; needs the Apple secrets listed in `docs/plans/ci-cd-release.md`.**
- `src-tauri/Entitlements.direct.plist`: non-sandbox hardened-runtime entitlements (camera, audio-input) for Developer ID builds.

### Fixed
- `scripts/sign-and-notarize.sh` signed with the Mac App Store sandbox entitlements and left the unsigned app inside the DMG. It now uses `Entitlements.direct.plist` for the app and every nested binary, rebuilds the DMG from the signed app before signing/notarizing, and supports App Store Connect API-key notarization (`APPLE_API_KEY_PATH`, `APPLE_API_KEY_ID`, `APPLE_API_ISSUER`). Tested locally with an Apple Development identity (hardened runtime, strict verify, helper launch, DMG verify); notarization untested.

## [4.50.4] - 2026-10-21

### Added
- `app:install` no longer leaves duplicate apps: the rollback copy of the previous install goes to `~/Library/Caches/YusafCut-install-backup` (not the Desktop) and the build-output `.app` is removed after a successful install.
- `docs/plans/ci-cd-release.md`: plan for tag-only signed releases on GitHub Actions (no workflow added yet).
- `npm run app:install` (`scripts/build-app.sh`): one command that checks prerequisites, builds the real native capture helper, builds the `.app` and `.dmg`, verifies the bundled sidecars, installs to `/Applications` and opens it. Flags: `--no-install`, `--check`, `--no-sign`, `--sign [identity]` (signing is now on by default; signs inside-out with your "Apple Development" certificate, no sandbox, so macOS keeps permissions across rebuilds; not Developer ID or notarized). Not notarized; build tested with `--no-install`, the install step not run.

## [4.50.3] - 2026-10-21

### Fixed
- **Recorder bar: countdown reached 0 but recording never started.** The bar hides itself before the take starts and then awaited `requestAnimationFrame`, which never fires in a hidden WKWebView, so `startRecording` was never called (the webview process was also reported terminated). New `nextPaint()` (`src/lib/paint.ts`) resolves on the next frame or after 120 ms; used by the bar and by the editor countdown. Unit-tested with a never-firing rAF; not yet verified in the running app.

- docs: HANDOFF and README branch state updated after the 4.50.2 merge (PR #57).

### Changed
- Docs only: HANDOFF status block and owner live checks for the integration branch, spec sections for the recording hand-off (separate camera track, `pendingCamera`, deferred checksum, gated native engine), ROADMAP "Native Apple media engine" milestones, README status, and CHANGELOG 4.50.0 / 4.50.1 ordering. No source changes.

## [4.50.2] - 2026-10-21

Second review of the recording hand-off (`feature/recording-handoff-slice1`, merged on top of the integration branch 4.50.1).

### Fixed
- **Quick project switch A -> B -> A no longer leaves the camera pending forever.** A run interrupted by a switch restarts at once if the same project is open again when it settles (it used to block the resume and then only toast).
- **Transient failures keep the `pendingCamera` marker.** Only a definite refusal clears it: Rust errors prefixed `camera composite refused:` (tracks folder gone, take without separate tracks, screen file outside the take, video length / size / sound mismatch), the editor's size / sound / length check, or a screen file shared with another entry. Cancel from the Jobs list, ffmpeg killed, ffprobe or I/O failure and a missing clip file keep it and say it is retried on the next open.
- **`swapToComposite` requires the PRESENT entry.** When the take's insertion was undone (only undo / redo states hold it), nothing is swapped, the composite is deleted, the marker stays and "Camera added" is not shown.
- **Webview reload during a composite:** a new composite request for the same take cancels the previous job (one job id per take folder in Rust), a job cancelled while renaming deletes its output, and leftover `camera-composite-*.mp4` files of that take that the project does not reference (media and overlay paths, present and undo / redo, compared canonically; sent as `keep`) are deleted before the job runs.
- **Sparse / VFR screen tracks:** `composite_lines_up` also accepts a composite whose video is at least as long as a sparse hand-off video (shorter than its container, e.g. no frames while the screen was static) when both containers match; a composite picture shorter than the hand-off's is still refused. Real-ffmpeg test with a 2 s static gap at the end and in the middle; the camera-lost truncation test still passes.

## [4.50.1] - 2026-10-21

Review fixes for the recording hand-off (4.49.0).

### Fixed
- **A camera lost mid-take could cut the picture short after the swap.** The old composite used `overlay … shortest=1`, so a 1.5 s camera in a 4 s take gave a 1.5 s picture inside a 4 s file (the container length is the audio mix), and the swap check compared container lengths. The background composite now uses `eof_action=pass` (the bubble just disappears when the camera ends), and Rust compares the VIDEO-stream length, picture size and sound of the composite with the hand-off file (`composite_recording_camera` now takes `screenPath`) and refuses a mismatch. Real-ffmpeg regression test: 4 s screen / 1.5 s camera / 4 s mic.
- **The camera could be lost on quit, project switch or a save before the swap.** The media entry now carries an optional `pendingCamera` marker (`tracksDir`, PiP corner / size; serde default, malformed values dropped, older builds ignore it). It is saved with the project, the composite resumes when the project is opened again (still guarded and cancellable, one per entry), and the marker is cleared on swap or when the composite is given up.
- The swap refuses when the sound differs (a silent raw-copy hand-off after a failed audio mix is never switched to a sounded composite) and takes fps / sample rate from the composite.
- The swap refuses when another media entry (any undo / redo state) uses the same screen file or checksum, so mask identity by path / checksum never splits.
- Composites are now named `camera-composite-<uuid>.mp4`; one that was not swapped in (given up, or finished after a project switch) is deleted with the new `discard_recording_composite` command (only that name pattern inside a take folder). A `.partial` file and a composite that failed validation are removed by the job.

## [4.50.0] - 2026-10-21

Integration branch `integration/native-media-engine-1`: recording hand-off slice 1 (4.49.0) plus the native media engine contract slice.

### Added
- **Native Apple media engine, slice 1 (contract + timing only, off by default).** `docs/native-engine.md` defines the JSON render plan compiled from the EDL (sources, clips with ranges / speed / holds / mute, recording groups with per-track offsets, music beds), Core Media rational timing with the export planner's frame quantisation, capability levels, stable fallback reason codes, the progress / cancel / error model, latest-request-wins generations and memory bounds.
- New Swift package `native/yusafcut-engine` (separate from the capture helper): `EngineCapabilities` (macOS, Apple Silicon, VideoToolbox H.264 / HEVC encoders, Metal device), `RenderPlan` + `PlanValidator` (first unsupported-feature code), and `PlanComposition`, which builds an `AVMutableComposition` + audio mix from a plan (multiple sources, cuts, repeated ranges, speed, holds, missing audio streams, a second video track with an offset, beds). CLI `yusafcut-engine capabilities | validate | probe-plan`. `npm run engine:build`, `npm run engine:test`.
- Rust `native_engine_capabilities` command (`engine_bridge.rs`): runs the helper if present, otherwise `{available:false, reason:"helper-missing"}`. The helper is not bundled.
- `src/lib/nativeEngine.ts`: `compileRenderPlan`, timing mirror, `chooseEngine` (fallback unless explicitly enabled; nothing enables it), `GenerationGate`. Shared TS / Swift timing parity fixture `tests/fixtures/native-engine-timing.json`.

No behaviour change: FFmpeg export and the HTML5 preview remain the only engines; no UI was added.

## [4.49.0] - 2026-10-21

Recording hand-off, slice 1: a finished take is editable and playable without waiting for the camera composite or the full-file hash. Design in `docs/architecture.md` ("Recording hand-off"), numbers in `docs/performance/recording-to-editor.md`.

### Changed
- **Native screen + camera Stop no longer re-encodes the take.** Stop hands back the screen picture (stream copy) with the microphone / system audio mix; the camera stays `tracks/camera.mp4` and `RecordingResult.camera` (path, offset 0, PiP corner and size) describes it. Camera-only, screen-only, voice-over and the FFmpeg fallback are unchanged.
- **The camera is added in the background**: new `composite_recording_camera` command (Jobs list "Adding camera to recording", job kind `composite`, lowered CPU priority, cancellable, one at a time) writes exactly the file Stop used to write; the clip is pointed at it only in the same project, at the same screen file, with the same length and size, once playback is paused. Not an undo step; undo history is rewritten with it. Otherwise the clip stays screen-only and a toast names the camera file.
- **Recording import probes only**: new `probe_media` command (ffprobe without hashing). The SHA-256 is computed afterwards with `hash_media` and attached with a project-id / media-id / path guard, without an undo step and without marking the project unsaved. `import_media` keeps probe + hash for every other caller.
- New stage marks `playable` (the preview `<video>` loaded the take to HAVE_FUTURE_DATA), `checksumAttached` and `cameraComposited`; `importProbed` is now ffprobe only.

### Fixed
- The transcript cache is no longer read or written for media without a checksum; before, every unhashed file shared one cache key and could receive another file's words.
- Background transcript and cursor attaches find a recording's media entry after a late checksum or camera swap (`resolveRecordingSource`), so they are not silently dropped.
- `SourceMedia.sha256` defaults to "" when a project file has no `sha256` key.

## [4.48.2] - 2026-10-21

### Added
- Recording stop benchmark harness: `npm run bench:recording` (`scripts/bench/recording/synthetic-stop.mjs`, synthetic ffmpeg tracks through the `finalize_args` argv shape, labelled not production-path proof), results in `docs/benchmarks/recording-stop-2026-10-21.json`, `scripts/bench/recording/read-spans.md` (reading real spans), and `docs/performance/recording-verification-plan.md` (computer-use test plan). No app behaviour change.

## [4.48.1] - 2026-10-21

### Added
- Stop-to-editor measurement: native spans for the stop, finalize (composite vs copy+mix), probe and import (ffprobe vs SHA-256) stages, a `perf_spans_snapshot` command, and `src/lib/recordingTimeline.ts` stage marks. Baseline and next-slice contracts in `docs/performance/recording-to-editor.md`. No behaviour change.

## [4.48.0] - 2026-10-21

Performance instrumentation and capability-aware transcription (from `feature/apple-silicon-performance`, rebased onto 4.47.0).

### Added
- **Production-path benchmark harness**: `scripts/bench/*` (export, analysis and whisper matrices plus word comparison), `src-tauri/examples/export_argv.rs` and `analysis_argv.rs` (print the argv the app's own builders emit, so benchmarks measure the production command lines), results in `docs/benchmarks/*` and write-ups in `docs/performance/*`.
- **Opt-in native timing spans** (`YUSAFCUT_PERF_SPANS=1`, `src-tauri/src/perf_spans.rs`): bounded ring (4096 entries), no file paths recorded, off by default.

### Fixed
- **Transcription language `auto` now really auto-detects.** It previously reached whisper-cli without `--language` and silently transcribed as English.
- **Transcription no longer adds `--no-gpu` just because the Core ML encoder is missing.** That flag never disabled Core ML, and it removed the only acceleration still available.
- **Core ML encoder download and unzip are cancellable and atomic**: a cancelled or failed download leaves no partial encoder behind.
- **Transcribe results carry the backend used and per-stage timings** (preparation, load, encode, decode).
- **A missing Core ML encoder fails fast with an actionable message** instead of a confusing context-init failure.

## [4.47.2] - 2026-10-21

### Fixed
- The specific device message (for example the microphone name) is kept in the session error instead of being overwritten by the generic one.

## [4.47.1] - 2026-10-21

### Fixed
- Native helper now notices a lost camera or microphone mid-take (capture-session runtime error, interruption, device disconnect) and reports it once, so the session becomes `interrupted` with a truthful message and the take is saved on Stop instead of silently continuing with frozen media.

## [4.47.0] - 2026-10-21

Wave-2 final integration (`qa/wave2-final`): `feature/overlays-masks` (4.43.0: image / video overlays, source-anchored privacy masks, coverage sheet) merged onto `qa/wave2` (4.46.0: voice-over track, device frames, keystroke identity). Details of each feature are in its own section below.

### Merge notes
- Export layer order: per clip `masks (source frames, two passes) -> trim / speed / hold (incl. voice-over insert holds) / transitions`; picture layer `cursor -> masks again over the cursor -> follow-zoom overlays -> follow-zoom annotations -> zoom -> scene (crop, device frame shapes) -> device frame text (scenetv)`; frame layer `fixed overlays -> fixed annotations -> captions -> key caps`. Masks therefore stay in source-picture coordinates and run before the cursor, zoom, crop, device frame and every frame-layer `ass` / overlay stage.
- Audio: the voice-over override envelope is applied to `[mainvox]` (and voice stems) only; music / takes / ducking sidechain follow; video overlays with their own audio are mixed last (`amix`, never ducked, never enveloped). Masks never touch audio.
- Inputs: recorded sources, then media overlays, then the scene background image, then music / voice-over takes, then chapter metadata; stems cover recorded sources only.
- Keystroke overlay: no key caps for presses under a mask (masks branch) AND real key names / "Typing (hidden)" from key identity (wave 2), in TypeScript and Rust.
- Preview: masks, the cursor, follow-zoom overlays and annotations sit inside the device frame's picture box (zoomed with the picture); the frame's notch / title bar draws over them.
- `OverlaysPanel`: keystroke section keeps "Strip key names…" and the identity notes next to the new overlay and mask sections.

### Fixed
- **Coverage sheet / range on a plain project (HIGH):** with no scene the finished picture is the picture layer's last label, not `[outv]`. A project with only a mask (no scene, zoom, crop, cursor, overlays, annotations, captions or keys) asking for "Check coverage" left concat's `[catv]` unconnected and ffmpeg refused the graph. Regression tests: a real-ffmpeg coverage sheet for a raw clip with one mask (expected width, 0 green frames), and every layer combination (mask, scene, device frame, zoom, cursor, cursor + mask, fixed / follow overlays, fixed / follow annotations, captions, keys, GIF, all together) with a contact sheet and a range on and off, each run through ffmpeg.
- Opening an older project no longer marks it unsaved: the background checksum backfill and picture-size refresh write without `dirty` (they persist on the next real save) and without undo steps; the size refresh skips a source relinked while it was probed.
- Pixelate mask preview redraws on every presented video frame (`requestVideoFrameCallback`; every animation frame while playing where it is missing), so a seeked frame that decodes after the time changes is never shown stale.

### Tests
- New real-ffmpeg integration tests: browser device frame with title + zoom + crop + a solid mask over a green secret (0 green frames, title still drawn); a masked clip with a voice-over insert hold (held frame masked, 0 green frames); a mask on a clip with an override take (audio envelope identical to the unmasked export); duplicated + moved masked clips with an insert take (0 green frames); coverage sheet with a device frame (title stage present, 0 green). TypeScript: mask spans cover a voice-over insert hold and later spans move by the take; named key caps under a mask are suppressed. All earlier mask leak probes and the golden default argv tests pass unchanged.
- Agent-run on the merged branch (after the Fixed items): `npm run check`; 1269 Vitest; 424 lib + 17 cli Rust tests (1 ignored); 52 Swift tests; `npm run media:verify` 122 passed / 1 skipped. Nothing was run in the desktop app.

## [4.46.0] - 2026-10-21

Wave-2 integration (`qa/wave2`): merges, in order, voice-over track (4.42.0), device frames (4.44.0) and keystroke identity (4.45.0) onto `main` 4.41.0. Details are in the three sections below.

### Merge notes
- `RecordOptions` (Rust `recorder.rs` and `ipc.ts`) carries both the voice-over `purpose` and the key-identity opt-ins `recordKeyIdentity` / `recordAllCharacters`, all camelCase on the wire (new round-trip test). Voice-over takes pass their own options (`mode: "voiceover"`), so key identity never applies to them; `recordAllCharacters` is still never persisted.
- Export: the device-frame title stage (`[outv]ass=…[scenetv]`) feeds the frame layer (annotations, captions, key caps); the voice-over envelope / ducking sidechain on the audio side is unchanged.
- HANDOFF: all owner live checks are in one OWNER LIVE CHECKS section.

### Tests
- New real-ffmpeg integration export: a light browser device frame with title text + an override voice-over take + burned-in captions in one MP4: title text pixels present, caption box only while the cue is up, original audio silent only inside the take's interval while the take is heard, no ffmpeg error.
- Agent-run on the merged branch: `npm run check`; 1225 Vitest; 383 lib + 17 cli Rust tests (1 ignored); 52 Swift tests; `npm run media:verify` 115 passed / 1 skipped. Nothing was run in the desktop app.

## [4.45.0] - 2026-10-21

### Added
- Opt-in key identity for the keystroke overlay. New recorder options "Record key names" (`recordKeyIdentity`, default off) and "Also record all characters" (`recordAllCharacters`, second opt-in, default off) in the recorder dialog and the recorder bar settings, with a plain-language privacy note. The native helper then adds optional `name` and `secure` fields to `key` events: shortcut keys (with ⌘/⌃/⌥, any key) and Esc, arrows, Home/End, Page Up/Down and F1-F20 are named; typing-flow keys (Return, Tab, Space, Delete, Forward Delete) and ordinary characters typed without ⌘/⌃/⌥ are never recorded unless the second option is on. While macOS secure input is active (`IsSecureEventInputEnabled`) no identity is recorded and the event is flagged `"secure":true`. Key identities are never printed or logged.
- Keystroke overlay renders real key caps ("⌘ K", "⇧ ⌘ Z", "⌥ F5", "↑", "⌘ ↑") in preview and export (TypeScript and Rust, shared fixture `tests/fixtures/keystroke-identity.json`), and "Typing (hidden)" for secure-input presses in "All key presses" mode. Logs without the new fields render exactly as before; hostile `name` / `secure` values are ignored.

### Privacy hardening (review fixes)
- Printable characters count as shortcut keys only with ⌘ or ⌃ held, not Option alone (Option types characters on DE/PL/FR layouts); Option plus arrows, F-keys and Return/Tab/Space/Delete is still named. Shortcut letters come from the ASCII-capable layout (`UCKeyTranslate`), so Cyrillic layouts show the Latin letter and Shift no longer shows as a symbol ("⇧ ⌘ 3", not "⇧ ⌘ #"). Insert/Help and keypad Clear are named; U+F700-U+F8FF names are dropped (Swift, TypeScript, Rust).
- "Also record all characters" is never stored, so it is off at every launch; "Record key names" may persist, and while a screen take records key names the controller shows "Key names ON" / "All characters ON" and the menu-bar title and tooltip carry it too.
- Window capture records key names only while the captured window's app is frontmost; screen and area capture capture keys typed in any app, and the recorder note and Overlays hint say so.
- Wording: password fields are "normally hidden or missing" (macOS withholds those presses), Terminal/iTerm sudo and ssh prompts and many Electron/web fields are not protected unless Secure Keyboard Entry is on, and all-characters recordings spell out what you typed. "Typing (hidden)" is not claimed to appear reliably.
- `events.jsonl` is created with mode 0600.
- New "Strip key names…" action (Overlays panel, with confirmation, one undo step) removes `name` / `secure` from the project's cursor tracks and its snapshot copies (`strip_snapshot_key_names`); the take folder's raw `events.jsonl` is unchanged.
- Key names need Input Monitoring: it is a required permission when "Record key names" is on, and Start is blocked with a clear message while it is denied.
- Accessible names of the switches match their visible text ("Record key names", "Also record all characters").

### Changed
- The Overlays panel keystroke notes now say what recordings with and without "Record key names" contain, and that password fields are hidden as "Typing (hidden)" only when macOS secure input is active and recording identity was on (not guaranteed).

## [4.44.0] - 2026-10-21

### Added
- **Device frames** in the Look tab: None, Browser window (light or dark title bar, three neutral grey dots, optional address text), Laptop (lid bezel, plain base, camera dot), Phone (portrait, rounded bezel, generic camera cutout: dot by default, notch or none) and Tablet (landscape). Bezel / title bar colour is configurable. Drawn from generic rounded rectangles and circles only: no brand artwork, no bundled images.
- `lib/deviceFrame.ts` (re-exported from `lib/scene.ts`): one geometry module (`layoutFrame`) used by the preview (`sceneCss`: CSS boxes) and the export (`scene.rs`: ffmpeg masks), so both draw the same integers. `SceneSettings.frame` (optional; old projects and builds without it are unchanged; Rust keeps it as raw JSON and `sanitizeScene` validates it).
- Export: the device shapes are drawn with per-corner rounded masks (`rounded_rect_mask_radii`), cast the shadow from the device outline, and keep a clean alpha silhouette (frame included) in ProRes 4444 with a transparent background. The browser's address text is drawn through a private ASS file (removed on drop) via `filter_stage`.

### Notes
- Every device offset and size is an even whole number (`layoutFrame`), because 4:2:0 video places overlays on even pixels only: odd layouts used to slip shapes and picture by 1 px independently in MP4 / MOV / GIF.
- Device masks are rendered once (`d=1`, held by overlay repeat or `loop=-1:size=1`) instead of re-evaluating `geq` every output second; at most 12 shapes. The plain rounded-box path keeps its `r=1` mask sources so the default argv stays byte-identical (it still costs one `geq` per second).
- The browser address text event lasts the export length plus a second, not a fixed ten hours.
- Zoom, the cursor and "follows zoom" annotations apply to the picture inside the screen (clipped to it). Fixed annotations, key caps and captions stay on the full canvas. The frame itself never zooms.
- Browser and laptop screens take the picture's aspect; phone (9:19.5) and tablet (4:3) screens are fixed and the picture is letterboxed on black. With a device on, "Rounded corners" is hidden: the device sets its own corners.

## [4.43.0] - 2026-10-21

### Added
- **Image and video overlays** (Overlays tab, "Images and videos"): PNG / JPEG / GIF / MP4 / MOV placed on the output timeline with start / end, position and size (normalised to the frame, or to the picture with "Follow zoom"), opacity, rotation, corner radius and fades. Transparency in PNG, GIF and ProRes 4444 sources is kept, and drawn into the alpha plane of a transparent ProRes 4444 export. Files are referenced where they are (never copied or uploaded) with their SHA-256 recorded; a missing file shows a striped placeholder in the preview, "Missing" in the list and a Relink button that refuses a file with different contents; export stops with a clear message until it is relinked. A video overlay's own audio is off by default; "Include its audio" mixes it like an undocked music track with its own gain. Preview: DOM `<img>` / `<video>` layers synced to the playhead (the main `<video>` is untouched). Export: one bounded ffmpeg input per overlay (`-loop 1`/`-ignore_loop 0`/`-ss` + `-t`) and an `overlay` stage with `enable=between(t,…)`.
- **Privacy masks** (Overlays tab, "Privacy masks"), **source-anchored**: each mask is `{mediaId, srcStart, srcEnd, region, effect, strength}` on one source file (`src/lib/masks.ts`). Where it shows on the output timeline is derived from the timeline at every use (preview, export, coverage check), never stored or retimed, so every occurrence of that footage is masked: duplicated or moved clips, restored words, the same source range used twice, speed and freeze-frame changes; edits cannot leave slivers (derived spans are at least one frame, extended, never dropped). Effects: solid fill (default for new masks), pixelate, Gaussian blur, dim-surround; rectangle or ellipse. Export applies masks PER CLIP on that source's own frames (`trim` with a 1 s margin, constant rate, mask in source time with one frame of padding) before trim, speed, freeze frames, crossfades and dips, so transition and hold frames are masked too, and the region is placed on that source's picture whatever its size or aspect. The masks run again after the cursor so the cursor is hidden inside them; key caps are suppressed for presses under a mask and while one is on screen. Strength floors: blur ≥ 12 and pixelate ≥ 16 at 1080 lines, never below 6 / 8 output pixels; a red warning below the safe-for-text levels (blur 30, pixelate 24). "Check coverage" renders, as a cancellable job, the frames just before (by the longest transition half), at the start, middle and end, and just after every place the mask is on screen, through the real export graph, into one contact sheet. The panel says permanently that a mask is a static region, that masks do not redact the transcript, captions, SRT / VTT, chapters or audio, and warns when a mask overlaps a cursor-following zoom. Preview: CSS `backdrop-filter` blur, a canvas pixelate that is a solid fill until its first draw, solid / dim boxes, each on its own source's aspect; "Show masks in preview" only affects the preview.
- Masks saved by the first output-time shape are converted on load through the timeline (one source mask per clip they touch) with a toast; a legacy mask that touches no footage hid nothing and is removed with a red warning. Rust converts the same way (shared fixture).
- Both: optional `Project.overlays` / `Project.masks` (absent on old projects), kept as raw JSON in Rust and re-validated by `layers_export.rs` with the rules of `layers.ts` / `masks.ts` (shared fixture `tests/fixtures/layersSanitize.json`, hostile values included), at most 200 of each; one undo step per edit. Overlays are retimed through cuts, clip ops (segment-id lineage) and speed / holds via the shared `retimeSpans` (`timeMap.ts`), which annotations now use too; a video overlay split in two by an edit continues its file in the later piece.
- FCPXML export with masks asks first ("PRIVACY MASKS ARE NOT APPLIED in FCPXML", Cancel is the default) and lists masks as NOT APPLIED.
- Overlay inputs are hardened: `-protocol_whitelist file`, an explicit demuxer per type (`image2 -pattern_type none`, `gif`, `mov`), `-max_pixels` 16384²; images over 16384 px are refused; a still is decoded once and repeated with the `loop` filter (an input `-loop 1` retried a corrupt file forever).
- FCPXML export lists overlays as unsupported and masks as "PRIVACY MASKS NOT APPLIED".
- `npm run media:verify` also requires `split`, `pixelize`, `lutyuv`, `rotate`, `colorchannelmixer`, `tile` and `loop`.

### Fixed (second privacy review)
- Masks match by CONTENT, not media id: the same file imported twice (two media items, one SHA-256, or one path) is masked in both; the panel says when a file is imported more than once.
- Mask regions are cut from the actual decoded frame (`iw` / `ih` expressions); stored media sizes are never trusted for placement, so rotated phone clips from builds before rotation-aware probing are masked in the right place. Strength scales with the source's SHORT side. Stored sizes are re-probed on open (`probe_media_size`, toast when corrected) and taken from the probe on relink; the preview uses the `<video>` element's decoded size.
- A video OVERLAY whose file is masked footage (same path or checksum, e.g. a magnified inset) gets those masks on its own frames, in its own time (source time minus `trimIn`), before it is composited. The preview does not; the overlay editor says so.
- Variable-frame-rate sources: the per-clip mask runs on the source frames with no rate conversion before it, so a held masked frame is masked before any later `fps` duplicates it (ScreenCaptureKit recordings are VFR).
- Mask + speed + crossfade + a custom export frame rate exports (the per-clip constant-rate stage that broke `xfade` is gone).
- A mask on a source with no known picture size refuses the export with a clear message instead of being dropped.
- Coverage sheet: every place is sampled when there are up to 12 (else the first 6), and the label says "sampled K of N places"; the PNG is written 0600 inside a per-job 0700 folder that is removed afterwards.
- A stored mask size under 1 % is rejected (never grown into a 1 % box); the panel refuses such an edit with a message and warns when a mask is under 3 % in either direction.

### Fixed (third privacy review)
- A variable-rate frame from BEFORE a mask that stays on screen into it (secret shown, then a static screen) is masked: each clip and each overlay of masked footage is masked twice, on its source frames (pass 1), then after a constant-rate conversion at the source's rate (pass 2, which catches the repeats now inside the span). Dim-surround runs in pass 2 only, so every frame on screen in the span (a held pre-span frame too) is dimmed exactly once.
- Same file: both checksums known and equal, OR equal paths (one path is one set of bytes at export time, even with a stale stored checksum, e.g. a recording overwritten in place and imported again); so an old project without checksums, or with a stale one, and a new import of the same path are one file, and the panel lists them. Sources saved without a checksum are hashed in the background on open (`hash_media`, streamed).
- Rust parses JSON floats exactly (`serde_json` `float_roundtrip`) and both sides accept a 1 ms mask with an epsilon, so 1 ms masks and legacy-conversion pieces are never dropped in one and kept in the other. A permanent parity test derives spans for 400 seeded random timelines in TypeScript and Rust (`tests/fixtures/maskSpansParity.*`).
- The mask pass after the cursor places masks from the decoded frame when clips are not scaled; when they are scaled to an export size the masked sources' sizes are re-probed before the export.
- "Check coverage" always finishes its job, even when its private temp folder or file cannot be created.

### Changed
- Layer order policy: per clip `masks (source frames) -> trim / speed / hold / transitions`; picture layer `cursor -> masks again over the cursor -> follow-zoom overlays -> follow-zoom annotations -> zoom -> scene`; frame layer `fixed overlays -> fixed annotations -> captions -> key caps`. With none of the new layers the export argv is byte-identical (golden test).
- Masks and overlays always use the full re-encode path (never smart-cut stream copy).

### Limits
- Masks are static: they do not track content that moves inside the recording. The second (cursor) pass skips dim-surround masks (they hide nothing). Overlays with several sources of different sizes follow the first source's picture.
- Overlay audio is not written to stems; GIF overlays animate freely in the preview (exact in export); overlay files are not copied into the project.

## [4.42.0] - 2026-10-21

### Added
- **Voice-over track.** Record narration at the timeline playhead and keep it as an editable track (`kind: "voiceover"` on `AudioTrack`; all new fields optional, old projects unchanged).
  - Start / stop with **Cmd+Option+V** (editor shortcut, rebindable) or Music panel → "Record voice-over at playhead". The anchor is captured before the countdown, so playback during the take cannot move it; it is stored with its clip identity and re-resolved on Keep (a deleted anchor clip is reported). Remembered microphone, countdown (Settings), live input meter, optional playback from the anchor once Rust reports the microphone live (first accepted sample), and a manual latency trim.
  - Takes use the existing voice-over `RecordMode` with `purpose: "voiceover-take"`, which Rust echoes in the result, so a take is never auto-appended to the timeline.
  - **Review dialog** after Stop: play the take, Overlay or Insert, "Override the original audio" (default remembered, per take, editable later), Keep / Retake (same anchor and choices) / Discard; keys Return, M, O, Space, R, D (Settings → Shortcuts → Voice-over review); Escape closes and keeps the take pending. Pending takes survive a reload or restart (stored before Rust's result is acknowledged) and belong to their project.
  - **Overlay** mixes the take over the picture; video timing is unchanged; a take running past the end of the video is flagged in the review and in the track list.
  - **Insert** holds the anchor frame (a freeze-frame hold, same mechanism as the Timing panel) for the take's length; everything later (video, audio, captions, chapters, zoom, annotations, music) moves by exactly that length through `computeTimeline`; at the end the last frame is held. Removing the take removes its hold; trimming it resizes the hold. The model hold limit is raised to 3600 s (the Timing panel slider stays at 30 s).
  - **Override** mutes the clip audio only inside the take's replacement interval (50 ms ramps outside it, so the take never moves or mutes itself); music tracks are untouched; muting or removing the take restores the audio; overlapping override takes: the newest wins. A recording that mixed voice and system audio into one track is muted as a whole inside the interval, and the UI says it cannot be separated.
  - Preview: `MusicPreview` plays takes with their trim and the latest-wins envelope; the `<video>` volume follows the override envelope. Export: the music-bed path with source trim, `volume` envelopes on `[mainvox]`, on voice stems and on older takes; stems for takes are named `-narration-N`; loudnorm applies to the mix as before. Default export argv unchanged (golden test).
  - Captions follow what is heard: clip words inside a replacement interval are dropped, kept takes are transcribed in the background after Keep (never blocking playback, never attached to another project) and their words placed at their output time.
  - Discard deletes only the take's own `rec-*` folder inside the app recordings folder (new `discard_recording_take` command), and only when no project state including undo / redo history uses the file.
- FCPXML export honours a take's trim and lists voice-over override as not carried over.

### Fixed (review)
- A second insert take at the same playhead goes after the first (end of that clip's hold) instead of on top of it; removing or trimming one moves the takes after it in the same hold, and undo removes each exactly.
- Stop follows Rust's live session id, retries once when its id is stale, and returns to idle with the error when nothing is live (no more "Saving the take…" forever). Global / tray Pause and Restart are refused during a voice-over take; the record shortcut stops the take.
- Music ducks under voice-over takes: heard takes are mixed into the ducking sidechain with the clip voice (export).
- The hold an insert take owns is not editable in the Timing panel (only a freeze on top of it), `setSegmentTiming` never drops it, and Duplicate copies only the user's own freeze. Holds are matched to their take: when a held clip is deleted the take becomes an overlay and owns nothing, so removing it never shrinks a user's freeze.
- Take transcripts read from a project file are validated (finite times, text, at most 20 000 words) before captions use them.
- Review dialog: Return / Space act on a focused button, checkbox, radio or field instead of Keep / Play; the dialog itself has focus when it opens; D (and the Discard button) ask before deleting a take of 2 s or more.
- Insert holds are capped at `MAX_HOLD_SEC`; the review warns when a take is longer.

### Tests
- Pure model (`tests/voiceover.test.ts`): insert mapping incl. 200 random projects, override envelope, latest-wins precedence, captions, anchors, mode switches, TS fixture shared with Rust. Store / race tests (`tests/voiceOverStore.test.ts`, mocked IPC, no hardware) and keyboard-only review dialog tests. Rust: lenient serde + fixture round trip, replacement intervals, envelope expression, owned-folder discard guard, and real ffmpeg exports with synthetic tones (override silent only inside the interval with fading boundaries, overlay duration unchanged, insert = original + take with the anchor frame held and later audio shifted).

## [4.41.0] - 2026-10-21

Integration of speed / freeze frames / transitions (4.38.0) into `qa/integration-2` (4.40.0).

### Fixed
- Pieces cut from a clip (word delete, keep range, pause trim, split) keep both its timing and its segment-id lineage (`inheritLineage(inheritTiming(piece, seg), seg.id)`), so a duplicated sped-up clip's copy keeps its chapters, zoom, annotations and music through later edits.
- Chapter / music retiming matches segment-id lineage for footage and for freeze-frame holds (`mapHold` takes the owner match), so a hold on a duplicated clip lands on the copy, not on the original.
- Restoring words only joins a clip with a touching neighbour that plays the same way (same speed and mute, no hold in between, no transition on the second): a restored 1x piece next to a 2x clip stays at 1x.
- Timeline clip lane: dragging an edge and snapping to the playhead go through the clip's speed (no longer 1x).
- Annotations retime through speed and holds (`retimeAnnotations` uses the shared `timeMap` rules), and keystroke captions map press times through speed and holds in TypeScript and Rust; the overlay total in export is the output duration.
- Export preflight and progress total use the output duration (speed and holds).

### Fixed (final review)
- **One bad timing value no longer fails the whole project load.** Per-clip `speed`, `muted`, `holdSec` and `transitionIn` are read leniently: a malformed value (e.g. `"speed":"2"`, a `wipe` transition, a transition without a duration) falls back to its default; segment keys this build does not know are kept and written back on save.
- The chapter `ffmeta.txt` temp file is removed on every exit path of an export (cancel, cursor/caption/overlay preparation errors, argv or spawn failure), not only when ffmpeg exits.
- Look sliders (angle, padding, corners, shadow) and music track gain / offset / fades commit once per drag or typed value: one undo step, like the Captions panel.
- Preview key caps sit above bottom captions only when "Burn in captions" is on, the same rule as the export (the option now lives in `uiStore` so the preview can read it).
- `npm run media:verify` now also requires `prores_ks` and `gif` encoders; `palettegen`, `paletteuse`, `loudnorm`, `ebur128`, `astats`, `atempo`, `xfade`, `acrossfade`, `tpad`, `afade`, `fade` filters; `mov` and `gif` muxers.

### Release note
- Builds older than 4.29 do not know the fields added since (clip timing, captions style, annotations, keystrokes, music mute / solo / fades, crop, transparent background) and drop them when they save a project. Do not open and save a project in an older build.

### Tests
- Lineage + timing through delete and split of a duplicated 2x clip, hold mapping onto the copy, restore next to a 2x clip, clip-lane drag at 2x, annotations / key caps / styled-caption cues under speed and holds; Rust key caps under speed and hold; one real-ffmpeg export combining a 2x clip, a hold, a crossfade, a cropped scene, a caption, a fixed annotation and a ducked music bed (duration within a frame of the mapping, overlays at their output times, music audible).

## [4.40.0] - 2026-10-21

### Changed
- Merged annotations and the keystroke overlay (4.36.0) into the integration branch with captions, scene crop, loudness and clip operations. One ffmpeg argv builder (options struct) produces the export graph: picture layer = cursor, follow-zoom annotations, zoom, scene (incl. crop); frame layer = fixed annotations, then captions, then key caps; then range trim and GIF palette. Every frame-layer `ass` stage passes `alpha=1` exactly when the scene keeps alpha (ProRes 4444 + transparent). Annotation and key-cap ASS paths use the shared filter-path escaping. Smart-cut is disabled when annotations, key caps or captions are present. The default argv is unchanged (golden tests).
- Key caps sit higher (80 % of the frame height) when captions are positioned at the bottom, so they never cover the captions.

### Fixed
- Annotations follow the clip they sit on by segment id (same lineage as chapters, zoom and music), so an annotation on a duplicated clip stays on that copy through word delete, trim, roll, split and move, and is never cloned onto the original. Source-time matching remains only for segments no annotation claims.

## [4.39.0] - 2026-10-21

### Added
- **Clip operations in the timeline.** Drag a clip's name to reorder it (drop position by clip midpoint, docks to cuts, Alt turns snapping off); Esc, the pointer leaving the window, window blur or releasing in place cancels with no change. Option+Left/Right moves the focused clip; the clip tools gain Move earlier / Move later, Duplicate clip and Ripple delete. Each is one undo step. Source ranges never change, chapters, zoom regions and music starts ride with their clip, and a duplicate has its own ids so cutting a word in one copy leaves the other. Property tests cover monotonic output time, word ownership by midpoint and repeated source ranges.
- **Restore deleted words.** `restoreWords` (formerly a stub that threw) rebuilds words from the original transcript without overlapping other clips; projects without originals report an explicit limitation and change nothing. Store action `restoreWords(ids)` and `deletedWords(project)`; no selection-menu entry because the transcript has no deleted-word chips.
- **Relink dialog for missing media.** Opening a project whose source files moved lists them with Locate…; the backend refuses any file whose duration (0.1 s), frame rate, picture size, audio sample rate or checksum differ, with a plain-language reason. Cancelling changes nothing; a relink is not an undo step.

### Fixed (review)
- Duplicate clips keep unique word ids when a trim or roll pulls original words back, and restoring words never gives a clip a word it already has under a suffix.
- Chapters, zoom regions and music follow the clip they sit on even when another clip plays the same source (retiming goes by segment id, with recorded lineage through delete, keep, silence trim, split and restore).
- Dragging a long clip past shorter ones works: the drop position is the nearest cut to the ghost's start, and the indicator matches the docked ghost.
- A move keeps a chapter at 0:00 and music that starts at or before the first cut in place.
- Relink accepts a file whose checksum matches even if ffprobe numbers drift, never prints hashes, and the dialog forgets errors when another project opens.
- Clip lane: `aria-keyshortcuts`, a polite live region for move/duplicate/ripple delete, and focus moves to the neighbouring clip after a ripple delete.

### Changed
- `relink_media` takes the project's `SourceMedia` (`expected`) instead of a bare SHA-256, checks structure before hashing and keeps the media id. New command `find_missing_media`.

### Tests
- Integration (`tests/clipOpsIntegration.test.ts`): after duplicate then move, caption words and cues (`flattenWordsInOutputTime`, `layoutProjectCaptions`) follow the new output order with gapless times, zoom regions, chapters and music shift and return with their clip, and scene crop, transparent background and caption style are unchanged.

## [4.38.0] - 2026-10-21

### Added
- **Speed changes, freeze frames and transitions.** A new Timing tab (and Timing on a transcript selection) sets a clip's speed (0.25–4x, pitch kept), mutes it, freezes its last frame for N seconds (silent), or adds a crossfade or dip to black into it (0.1–2 s, centred on the cut). Each change is one undo step; settings back at their defaults are stored as absent, so old projects load and save unchanged.
- **One time mapping** (`src/lib/timeMap.ts`, mirrored in `edl.rs`): every consumer of output time (transcript seek and highlight, playhead, captions and SRT/VTT, chapters and auto chapters, zoom regions and auto zoom, cursor overlay and cursor export, waveform peaks, music offsets, range and chapter export) follows clip speed and holds. Transitions are overlap-neutral and never move output time. Chapters, zoom and music follow their content when timing changes; pieces cut from a clip keep its speed, the first keeps its transition, the last its hold.
- **Export** (`src-tauri/src/retime.rs`): `setpts` + `fps` + `tpad` (clone) for speed and holds, chained `atempo` with exact per-clip audio length, `xfade`/`acrossfade` with frozen-edge padding for crossfades and `fade`/`afade` for dips; audio stems use the same clips. Smart-cut stream copy is skipped when any clip has a timing effect; plain projects keep their exact ffmpeg argv. Real-ffmpeg tests check output length and beep timing within one frame of the mapping, the held frame and the dip.
- **Preview**: clip speed and mute ride on the single `<video>` (`playbackRate`, `muted`); holds pause on the frame with a timer; dips are drawn as a black overlay; crossfades show a badge (they render on export). The scrubber marks speeds, holds and transitions.

### Fixed (review)
- Export lengths are counted in whole frames from the rounded timeline, so picture and sound end together over hundreds of clips; sub-frame clips no longer lose or add frames; `xfade` offsets come from the same counts.
- Retimed clips use a rational, capped frame rate and only clips that need it are resampled (mute/dip alone keep VFR frames).
- Crossfade audio is constant-power (at most -3 dB at the cut instead of -6 dB).
- Preview holds park on the held frame, resume from the playhead after a seek into a hold on another source, and follow rate changes without jumping.
- Keeping a range that starts inside a hold keeps one real source frame to freeze.
- `yusafcut inspect` reports the output duration including speed and holds.

### Known limits
- Speed-mapped rate comes from the stored `r_frame_rate` (capped at 60); `avg_frame_rate` is not stored in projects yet.
- FCPXML keeps each clip's output length on the spine but plays it at 1x with straight cuts; speed, holds, mute and transitions are listed in `unsupported`.
- The timeline clip lane (`Waveform/ClipLane.tsx`) still previews a dragged edge and playhead snap at 1x (fixed in 4.41.0).

## [4.37.0] - 2026-10-21

### Added
- **Styled, burned-in captions.** New Captions tab: font from a safe macOS list, size, weight, color, outline or shadow or a box behind the text, top/middle/bottom position, characters per line and line count, plus an optional spoken-word highlight (the current word is colored) in the preview and the export. The style is saved in the project as optional `captions` (old projects are untouched; Rust keeps it as raw JSON and sanitizes on use). The Export dialog has "Burn in captions" (default off; forces a full re-encode; ignored for audio formats). Layout (`src/lib/captionLayout.ts`, pure and deterministic) breaks cues by characters per line, line count, silence, sentence end and a 6 s cap, never splits a word, glues stand-alone punctuation, and reports reading speed over 20 characters per second, cues under 0.8 s and over-long words as warnings; all times come from the words in output order (after cuts and re-ordering) and are never invented or stretched. `src-tauri/src/captions_export.rs` writes an ASS script for the bundled libass (same route as the cursor), escaping braces, backslashes and control characters, and the captions are drawn last, over zoom and scene, on the final frame. The preview caption now uses the same style and layout; SRT and VTT export are unchanged. Han and kana draw in Hiragino Sans GB and Hangul in Apple SD Gothic Neo (libass has no fallback to them); emoji cannot be drawn by libass, so the Export dialog warns before burn-in and offers "Remove emoji from burned captions", and the Captions tab lists those cues. It also warns when there is no transcript or a cue has no duration. The ASS file path is escaped for both filter-parsing levels (spaces, colons, quotes, commas, brackets). Slider drags in the Captions tab are one undo step; Position is a keyboard radio group.

### Fixed
- Burned-in captions work with a transparent background and with source crop: the caption `ass` stage keeps alpha (`alpha=1`) when the scene keeps alpha (transparent background + ProRes 4444), so caption pixels over the transparent padding are drawn while the rest of the padding stays alpha 0, and the caption canvas size follows the cropped scene canvas. Covered by real-ffmpeg tests.

## [4.36.0] - 2026-10-21

### Added
- **Annotations:** text, arrow and box (outline or filled) overlays on the output timeline, from the new **Overlays** tool tab. Start/end, position and size, colour, line width, text size, fade in/out and an optional **Follow zoom** (pinned to the picture so it zooms with it; otherwise fixed on screen). Each edit is one undo step; they follow cuts like zoom regions, save with the project (optional fields, old projects unchanged) and render in the preview and in exports as ASS vectors/text (`annotations_export.rs`, unicode text, ASS override characters escaped).
- **Keystroke overlay (opt-in, off by default):** recorded key presses shown as key caps at the bottom of the frame, in the preview and the export. Default shows only shortcuts (⌘, ⌃ or ⌥ held); "All key presses" shows a "Typing" badge and a privacy note. The recording log stores only modifiers, never which key was pressed, and has no secure-input / password-field marker, so shortcuts show as e.g. "⇧ ⌘ key".

### Fixed (review)
- Colour emoji are removed from annotation text (the export cannot draw them) with a note in the panel; symbols, CJK and Hangul are kept.
- Malformed stored annotations or zoom regions no longer make every edit throw: they are validated before retiming.
- At most 500 annotations, with a message when the limit is hit. A split annotation fades in only on its first piece and out only on its last.
- Clearer privacy wording for "All key presses"; the shortcuts hint says Option/Control presses show as "⌥ key". Colour swatches have names, a contrast ring on white, one tab stop and arrow-key selection.
- Export stages follow one documented layer order (picture: cursor, follow-zoom annotations, zoom, scene; frame: fixed annotations, captions, key caps), with key caps in their own ASS script and an alpha flag on frame-layer stages.

## [4.35.0] - 2026-10-21

### Added
- **Source crop** (Look tab > Crop). `Project.scene.crop` is an optional normalized rectangle `{x, y, w, h}` of the source, applied before padding, aspect and the rest of the scene layout in both the preview and the export. Numeric fields (percent of the source, applied on Enter or blur) and presets (None, 16:9, 9:16, 1:1, 4:3, centred). Layout sees the cropped size, so "Original" aspect and orientation follow the crop. Preview and export cut the same even whole pixels (`cropPixels`); the exporter adds `crop=w:h:x:y` ahead of the scene scale, after cursor and zoom, which keep working in full-frame coordinates. Old projects have no `crop` and load unchanged (`sanitizeScene` drops invalid or full-frame crops).
- **Transparent background** (Look tab > Background > Transparent). The preview shows a checkerboard. **ProRes 4444** (`prores-4444`, `prores_ks` profile 4, `yuva444p10le`, `.mov`) keeps it: padding and corners export with alpha 0, the video with alpha 255, the shadow with partial alpha. Verified on decoded frames with the bundled ffmpeg.
- Every format without alpha (MP4, MOV, ProRes 422 / HQ, GIF) flattens a transparent background onto opaque black, and the Export dialog shows a warning saying so before you export.

### Fixed
- Crop and the scene are sized from the first segment's media (what the exporter feeds the scene), not the first imported clip; the exporter also clamps the crop to the real source size so no zero or oversized crop reaches ffmpeg.
- Rotated footage (iPhone portrait, display matrix or `rotate` tag of 90/270) now probes at its displayed size, matching what ffmpeg and the preview decode, so scene aspect, crop, zoom and cursor use portrait dimensions. Projects already saved keep their stored size.
- ProRes 4444 with a non-transparent scene stays 4:4:4 through the scene graph. Rounded-corner edges in alpha exports are tested not to darken (no fringe was reproduced).
- Crop panel: preset buttons report `aria-pressed`, fields snap back to the sanitised value, a note shows when Left/Top were adjusted, None no longer turns a disabled frame on, and the panel states that crop needs "Style the frame". Agent `export_start` format text now covers ProRes 4444.

### Changed
- HEVC with alpha (`mov-hevc-alpha`) is intentionally not offered: the bundled ffmpeg 7.1.1 `hevc_videotoolbox` accepts `-alpha_quality` and `bgra` input but writes no alpha layer (output byte-identical to the opaque encode, decoded alpha 255). Revisit with a newer ffmpeg.

## [4.34.0] - 2026-10-21

### Added
- **Audio mixer for music and SFX tracks.** Per-track Mute and Solo (solo wins over mute; both are mix state, distinct from hiding a timeline lane), fade in and fade out in seconds (linear, clamped to the clip and scaled when they overlap; the fade-out ends where the track ends, not where the edit ends). Muted or un-soloed tracks add nothing to the export graph, so an all-muted project exports exactly like one with no tracks, and a project whose tracks are all muted can still stream-copy. New optional `AudioTrack` fields `muted`, `solo`, `fadeInSec`, `fadeOutSec` (TS and Rust); off values are not written, so old projects load and save unchanged. FCPXML skips inaudible tracks and lists fades as unsupported.
- **Music tracks play in the editor preview** (`MusicPreview`, `src/lib/audioMix.ts`): play, pause, seek, rate and the master mute follow the playhead, honouring gain, offset, fades, mute and solo. Not heard by the agent that built it. Limits, also stated in the dialog: ducking is export-only, boosts above 0 dB are capped at 0 dB (element volume), and fades step about ten times a second (playhead update rate).
- **Export loudness target** (Export dialog: off, -16 podcast, -14 streaming, -23 broadcast): single-pass `loudnorm` with a -1.5 dBTP ceiling after the range cut, resampled to 48 kHz; forces a full re-encode; stems are not normalised. Not offered for GIF; the backend rejects targets outside -30..-5 LUFS.
- **Post-export audio report:** `export_video` now returns `{ audio: { integratedLufs, loudnessRangeLu, truePeakDbtp, samplePeakDb, clipped } | null }`, measured with ffmpeg `astats` + `ebur128`. The completion toast shows loudness and true peak, and warns when the sample peak reaches full scale. A failed measurement never fails the export.

### Fixed
- Post-export report: digital silence (infinite peaks) no longer produces a null that crashed the toast and made a good export look failed; levels are individually optional and the UI never formats a missing one. The report parser reads the last `Summary:` / `Peak level dB:` so a file name containing them cannot shift it. The measurement runs after the job is completed and the export lock is released, is limited to 60 s, shows "Measuring loudness…", and can never turn a successful export into an error.
- Music preview stops re-seeking and re-calling `play()` on files that fail to load or have ended (2 s back-off) and the dialog says "Preview audio unavailable for <file>". Mute/Solo buttons are no longer dimmed with the row; Muted / Silenced by solo is announced (`aria-live`).

### Tests
- Rust, real ffmpeg (WAV exports over a silent voice, levels read back with `astats`): a muted track is digital silence while the unmuted control is -21 dB; solo isolates (-41 dB vs -21 dB) and wins over mute; fade ramps are strictly monotonic with a flat sustain and start/end near silence; the fade-out of a delayed short track lands at its own end; `loudnorm` lands on -16 and -14 LUFS; clipping is flagged for a hot mix and not for a calm one; the report parser; the default argv is unchanged by a muted track. Vitest: mute/solo/fade/gain/preview-voice resolution and serialisation.

## [4.33.0] - 2026-10-21

Integration release of the QA pass: timeline lane visibility (4.29.0), rebindable editor hotkeys (4.30.0), export formats (4.31.0) and FCPXML export (4.32.0). Entries below.

### Fixed (review)
- **FCPXML export no longer drifts.** Clip offsets and durations come from the real output times (not per-clip rounding), so 100 segments of 0.35 s at 30 fps total exactly 1050 frames; source ranges stay inside the asset, chapters use the same mapping, and sub-frame segments are dropped and listed. Odd frame rates snap to the nearest standard rate with a note; control characters are stripped, asset ids are unique, and `hasAudio` / music gain follow the source.
- **Editor hotkeys match on the typed letter or digit** (layout-aware, e.g. AZERTY Cmd+Z is undo); Space, arrows, Backspace, Delete and F-keys still use the physical key. Settings capture stores the same form. Save and export now also work while a modal is open.
- The Waveform lane only decodes audio while it is visible, and drops peaks for removed media. The Timeline View popover is marked non-modal. Cut-map ticks are no longer tab stops (the lane is one stop; arrow keys move between cuts) and the waveform canvas is sharp on high-DPI screens.

### Changed
- **Editor hotkeys match modifiers exactly** (from 4.30.0): holding Shift with a bound key no longer triggers its plain action; the only Shift variant is Shift+rewind key (default Shift+J), the slow rewind. Rebind in Settings > Editor shortcuts.

### Documentation
- `docs/ai/`: design-only foundation for AI-assisted editing (milestone 1): capability inventory with file:line and what is on this Mac (no LLM or embedding weights installed; the PyInstaller `mlx-sidecar` fails to start), TypeScript contracts (stable references, `SourceRef`, `Suggestion`, model-output validation, job lifecycle with `stale`, stale-plan detection, one-undo apply, prompt-injection rule, local-inference capability discovery), evaluation plan (synthetic corpus, metrics, mocked vs real-model tiers) and milestone plan with file ownership for parallel agents.


## [4.32.0] - 2026-10-21

### Added
- **FCPXML export** (Export tab, "Export FCPXML…"): writes the EDL as an FCPXML 1.10 timeline with frame-aligned rational times, one asset-clip per segment in output order, chapters as markers and music beds as lane -1 clips with gain. Effects with no FCPXML equivalent (scene, zoom regions, cursor styling, ducking) are left out and listed in the success toast. Pure module `src/lib/fcpxml.ts`, tests in `tests/fcpxml.test.ts`. Not yet tested by importing into Final Cut Pro.

## [4.31.0] - 2026-10-21

### Added
- **Export formats.** The Export dialog, `ExportOptions` (`format`, `range`, `stems`) and the agent `export_start` tool now offer: MOV (H.264/HEVC; HEVC tagged `hvc1` for QuickTime), ProRes 422 and ProRes 422 HQ (`prores_ks`, 10-bit 4:2:2, PCM audio, MOV), animated GIF (a palette per frame so memory stays flat, 15 fps / 640 px wide by default, capped at 30 fps / 960 px and 60 s; longer edits need a range), audio-only M4A (AAC) and WAV (16-bit PCM). The save dialog filter and default extension follow the format, and the backend rejects an output path whose extension does not match. Under the podcast-audio preset the dialog offers only the audio formats.
- **Range export:** export only a span of the edited timeline (From / To seconds in the dialog, `rangeStart` / `rangeEnd` for agents). The range is cut inside the filter graph after music, zoom, cursor and scene are laid out, so it lines up with the preview, nothing outside it is buffered or encoded, and progress counts only the range; chapters are shifted into the range. Bad ranges are reported in the dialog (Export disabled) and as `INVALID_INPUT` to agents before anything starts.
- **Audio stems** (M4A / WAV): beside the mix, one file per recorded source (`<name>-voice-N`, silent while other sources play, so it lines up with the mix) and one per music track (`<name>-music-N`, gain and offset applied, before ducking). The export refuses to start if a stem file already exists or would overwrite an input.
- A failed or cancelled export removes the partial main file and stems it wrote (only files modified during the export).

### Fixed
- Podcast-audio exports failed outright: the graph still built a video output nobody mapped and ffmpeg refused it. Audio-only graphs now build only audio (and GIF only video).
- A music bed failed to export unless exactly one track ducked (an unused or reused sidechain label). Zero, one or several ducking tracks now work.

### Not done
- Alpha output (ProRes 4444 / HEVC with alpha) is blocked: neither the sources nor the scene backgrounds (solid, gradient, image) can be transparent, so any alpha channel would be fully opaque. It needs a transparent scene background first.

### Unchanged
- The default MP4 export builds the same ffmpeg arguments, byte for byte (golden test `tests/fixtures/exportArgvGolden.json`). Smart-cut still runs for MP4 and now also for MOV; ProRes, GIF, audio, ranges and stems always re-encode.

## [4.30.0] - 2026-10-21

### Added
- **Rebindable editor hotkeys.** Space, J/K/L, I/O, B, X, extract, delete, undo/redo, save and export now live in a registry (`src/lib/editorShortcuts.ts`) with the same defaults as before. Settings has a new "Editor shortcuts" section: click to rebind, conflicts with other editor or recorder shortcuts are refused, per-row and "Reset all". Toolbar, toolbox and play-button hints show the current binding. `Delete` is now an accepted key in shortcut capture.

### Fixed
- Editor hotkeys no longer fire during IME composition, while a modal dialog or menu is open, or on key auto-repeat (except undo/redo). Undo/redo/delete-range no longer run while typing in a real input field.
- Added `tests/useKeyboardShortcuts.test.tsx` and `tests/editorShortcuts.test.ts`; the hotkey hook had no tests.

## [4.29.0] - 2026-10-21

### Added
- **Waveform and cut-map lanes** (`Waveform/ExtraLanes.tsx`): peaks from `generate_waveform` drawn on a canvas for the visible window via `waveformColumns`, and one clickable tick per cut from `cutPoints` (seeks to just before the cut).
- **Timeline View menu**: a "View" popover (rendered in a portal so it cannot be clipped) in the timeline header with Simple / Detailed presets, a checkbox per lane, "Hide empty lanes", "Show populated lanes" and "Reset view". Lanes: Clips, Waveform, Zoom regions, Chapters and Cut map. Simple (default) shows a faint waveform behind the clip lane and hides the zoom, chapters and cut-map lanes until populated (cut map is off); Detailed shows every lane, with a full-height waveform. Preferences live in `timelineViewStore` (localStorage), not the project: toggling creates no undo step and never affects playback or export, the video, the time-to-pixel scale, scroll or the playhead. Pure model in `src/lib/timelineView.ts`.

## [4.28.2] - 2026-10-21

### Changed
- `tsconfig.tsbuildinfo` (TypeScript's incremental build cache) is no longer tracked; `*.tsbuildinfo` is now in `.gitignore`, so type-checking no longer leaves a modified file behind.

### Documentation
- `docs/HANDOFF.md` brought up to date for v4.28.2: current state, merged PRs #47–#50, and `main` in the branch table.

## [4.28.1] - 2026-10-21

### Fixed
- Recorder bar: the camera popover preview was clipped at the bottom (the 16:9 box stretched to the full panel width and overflowed the 520 px bar window). It is now capped at 440×248 and shows the whole frame.

## [4.28.0] — 2026-10-21

### Added
- **Floating recorder bar**: Record now opens a ScreenKite-style bar at the top of the screen (Display / Window / Area, camera, system audio, microphone with level, recordings folder, settings) instead of the setup dialog. The main window hides while it is up and returns when the bar closes or a take ends; the bar is excluded from the footage. "More options…" opens the classic dialog, and the dialog is also the fallback if the bar cannot open.
- **Settings → Recording → Recorder style**: Floating bar (default) or Dialog.
- The record shortcut starts the armed mode while the bar is open.

### Changed
- The bar is an opaque window (rounded corners and translucency need a private macOS API the App Store forbids), Area is drawn on a screen thumbnail rather than full screen, and there is no system-audio meter (the capture helper exposes none).
- Settings changed in the bar (countdown, transcribe) now sync to the editor window, so the editor no longer overwrites them with a stale copy.
- The recorder store shares its option storage and device-defaulting helpers with the bar (`src/lib/recorderOpts.ts`).

## [4.27.0] — 2026-10-21

### Added
- **Agent CLI / MCP** (`docs/agent-cli-design.md`): a local loopback server inside the app (`127.0.0.1`, per-launch port, bearer token) lets external AI tools drive the open project. Edits use the same pure functions and store as the UI, so they appear live and undo like a click.
  - `YusafCut agent …` shell CLI (`status`, `project open|info|save|inspect`, `tool list|describe|call`, `skills`, `export`).
  - `YusafCut mcp` stdio MCP bridge for Claude Code, Codex and Gemini CLI.
  - 20 tools with a plan / apply model: `confirm:false` returns a plan with a `baseRevision` check, `confirm:true` applies it as one undo step. A batch tool composes several edits into one undo step, and `history` undoes or redoes.
- **"Project MCP Server" dialog** (TopBar "Agent" button): turns access on or off, shows the status and copy-ready CLI and MCP snippets, and masks the token until revealed.
- Agent access is **off by default**, and the feature is disabled in the Mac App Store build.

### Fixed
- **Recorder camera preview is no longer cropped or zoomed** in the Record panel.

### Changed
- **Modernized recorder panel styling** (setup panel and controls).

## [4.26.0] — 2026-10-20

### Fixed
- **Recorded or added clips no longer land in the middle of the transcript.** The transcript view sorted every word by *source* time, so a clip appended after another (both start at 0 s) interleaved with it. It is now laid out in output order, segment by segment, with a paragraph break at each clip boundary and the timestamp column showing output time (`src/lib/transcriptLayout.ts`). Pause badges attach only to the media they were detected on.
- The timeline no longer shifts when a clip is selected: the clip tools row is always present and the rail is a flow layout instead of stacked absolute rows.

### Changed
- **Simpler timeline**: a ruler, the clip bar and the zoom lane. Removed the cut-map strip, word bars, audio peaks, minimap, legend, hover tooltip and the zoom-lane toggle. The bottom panel is shorter (176 px), leaving more room for the preview.
- **No blocking "Loading media" dialog.** Opening a file, adding a clip or importing a recording shows the video straight away; a small "Opening media…" note appears in the status bar while the file is probed.
- **Zoom panel follows the selected clip** (or the clip under the playhead): clips without cursor data hide Clicks / Typing / Follow cursor / Generate / Cursor styling and explain that manual zoom still works.

### Added
- Words that play inside a zoom region are highlighted in the transcript (purple underline); clicking one selects that zoom on the timeline.
- `tests/transcriptLayout.test.ts`.

## [4.25.0] — 2026-10-20

### Added
- Native Apple Silicon (`arm64` / `aarch64-apple-darwin`) FFmpeg/FFprobe reproducible source builder (`scripts/build-arm64-media.sh`, `npm run media:build`) compiling pinned, SHA-256-verified upstream sources (`FFmpeg 7.1.1`, `libass 0.17.3`, `harfbuzz 10.1.0`, `freetype 2.13.3`, `fribidi 1.0.16`, `x264`) targeting `macOS 13.0` with hermetic `pkg-config` isolation (`otool -L` links only to macOS system frameworks and `/usr/lib`).
- Automated 6-stage media binary verifier (`scripts/verify-media-binaries.sh`, `npm run media:verify`) asserting native `arm64` architecture, Mach-O deployment target, dynamic linkage portability, required codecs/filters/devices, synthetic media smoke paths (probe JSON, 16 kHz WAV extraction, `silencedetect`, preview proxies, 8 kHz waveform PCM, `libass` vector cursor + VFR promotion + zoom + scene composition), and VideoToolbox hardware encoding.
- Reproducible 7-stage native `arm64` media pipeline benchmark (`scripts/benchmark-media-pipeline.mjs`, `npm run media:bench`) and packaging/performance specification (`docs/performance/arm64-media-packaging.md`) including the Phase 5 native Apple media framework follow-up plan.

### Changed
- Enforced strict Apple Silicon (`arm64`) architecture checks across `src-tauri/binaries/fetch.sh`, `scripts/setup.sh`, `scripts/dev.sh`, `scripts/build-production.sh`, and `scripts/build-mas.sh`, removing legacy non-`arm64` download paths.

## [4.24.0] — 2026-10-20

### Added
- **Compact recorder setup** (`RecorderDialog`, ≈460 px) replaces the large modal: **Screen / Camera / Audio** segmented modes (screen + camera is the Camera switch inside Screen), **Display / Window / Area** source choice, source thumbnail, microphone level meter and camera preview, a System-audio switch, and an expandable **Advanced** section (frame rate, countdown, hide-window, transcribe-when-finished, camera bubble corner/size). One **Start** button shows the start shortcut and, when disabled, a visible reason (loading, no display/camera/microphone, missing window or area, denied permission, vanished device). The shortcut reference sits behind a help button. Segmented controls are radio groups with arrow-key movement; switches, meter and notices carry accessible names/roles.
- **Area capture**: drag on the display thumbnail (or type X/Y/W/H in display points) → `RecordOptions.area` → helper `start` `area`. Validated in the UI and again in Rust (finite, ≥ 32 pt, inside the display); the FFmpeg fallback refuses an area take instead of silently recording the whole screen. `list_recording_devices` now returns `displays[]` (point sizes).
- **Permission flows**: `request_recording_permissions` (helper `request-permissions`; the panel's "Allow" for never-asked permissions), `open_privacy_settings` (opens the matching System Settings pane for denied ones), re-check on window focus and via Refresh. Both refuse while a take is running.
- **Source thumbnails**: helper `thumbnail` command (ScreenCaptureKit `SCScreenshotManager`, macOS 14+, JPEG ≤ 1280 px, never prompts) exposed as `recording_thumbnail` → `data:` URL.
- Device-gone notices: a camera/microphone/display that disappears between refreshes is reported by name before another device is selected.

### Changed
- Recording options persist `sourceKind`, `windowId` and `area` with the existing keys; only the fields of the chosen source are sent to Rust (`toStartOptions`).

## [4.23.0] — 2026-10-20

### Added
- **Desktop recording controller** (`controller.html`, `src/controller/`, `src-tauri/src/controller.rs`): a separate ≈320×52 opaque always-on-top window that mirrors the Rust session and shows timer/status with Pause/Resume, Mark, Stop and an overflow menu (Show editor, Hide controls, Restart take… and Discard… behind an inline confirmation). It mounts only the controller UI (no editor App, autosave, import or transcription), is draggable, remembers its position, is clamped to connected displays on every show, and closing it hides it rather than discarding a take. Capability `recording-controller` grants only events + dragging.
- **Capture exclusion** in the native helper: display/area capture filters out windows titled "YusafCut Recording Controls" owned by the launching app (pure `CaptureCore/Exclusion.swift`, re-checked every 750 ms with `updateContentFilter`), and the controller cannot be chosen as a window target or listed. The FFmpeg fallback cannot exclude windows, so the controller stays hidden during FFmpeg screen capture; the menu bar and shortcuts remain.
- Menu bar: "Hide/Show Recording Controls" row; "Show editor" restores the main window explicitly (`show_main_window` targets the `main` window, never the caller).

### Changed
- The editor is restored when a take ends from the controller or menu bar, not only from its own buttons.

## [4.22.0] — 2026-10-20

### Added
- **Authoritative Rust recording session** (`src-tauri/src/recording_session.rs`). Rust owns one session with an id, phase (`idle/starting/recording/paused/finalizing/interrupted`), backend, mode, media-time elapsed, markers and error. Windows fetch `get_recording_snapshot` after subscribing to `record:snapshot` and keep the highest `revision`. All actions (`pause/resume/stop/cancel/restart/mark`) name the session id; stale ids and actions illegal for the phase are rejected, before and after queuing for the action lock, so duplicate Stop/Pause from several windows, the tray or shortcuts cannot repeat work. `restart_recording` discards and starts a new take as one serialized action.
- `record:finished` + `pending_recording_results` / `ack_recording_result`: the editor window alone imports a finished take, once per session id, and recovers one it missed.
- A device or helper failure mid-take is now an explicit `interrupted` phase with the error and the recoverable media; the editor stops it once to keep what was written.

### Changed
- `recordingStore` is a mirror and action client of the Rust session (countdown and import remain editor-local). `record:state` and `record:error` events are replaced by `record:snapshot`; markers are recorded at the take's own media time in Rust and returned with the result.

### Fixed
- Cancelling while capture is starting interrupts native startup (helper killed, files removed) instead of queuing behind the 120 s start, and a cancelled take is never rescued by the FFmpeg fallback. Resume waiting on FFmpeg's first sample is cancellable too.
- Stop, helper failure, Cancel and Restart can no longer finalize the same writers twice; late helper events cannot move a take backwards or leak into a new session. The native helper's own `stop` is idempotent (Stop racing SIGTERM / stdin close).
- A request issued as the helper exits no longer waits out its full timeout.

## [4.21.0] — 2026-10-20

### Added
- Integrated native ScreenCaptureKit/AVFoundation helper source commits 76361be/09380dc with aligned separate tracks, window/system-audio foundations and FFmpeg fallback. The actual ARM64 helper was built locally; source stub remains the documented fallback on machines without Swift.
- Native screen recordings automatically attach processed cursor logs in a background module worker after becoming playable. Source/document guards and undo/redo rebasing preserve edits and prevent late results reaching another document. Missing logs leave usable media.

### Fixed
- Cursor/zoom export supplies animation frames for sparse/static native screen input; explicit export rates and higher source frame rates are retained.
- Native startup waits for accepted primary media and uses that sample as shared time zero. Rust follows the helper's media clock, serializes both backends through finalization, rejects old-helper events and probes final media duration. Audio/webcam-only recording does not collect screen cursor/typing activity.

### Verification limits
- Automated check/JS/Rust/Swift/generated-media tests and production worker bundling are recorded in HANDOFF. Owner requested no more agent computer-use testing; real capture, permissions and system controls remain unverified here.
- Desktop controller/public session actions, area/permission UI, capture exclusion, editable camera and release benchmarks remain pending. Copied FFmpeg is Intel; ARM sidecar packaging and strict Swift 6 sendability warnings remain open.

## [4.20.0] — 2026-10-20

### Added
- Styled cursor video export: six local vector shapes, source-time smoothing, visibility/idle hiding, ripple/ring/bounce click effects and blurred trails. Sampling follows cuts, repeated source ranges and per-media tracks. Cursor drawing happens before zoom and scene framing; audio-only exports ignore it.
- Pure streaming ASS-vector renderer using bundled FFmpeg/libass, with private disposable activity files, cancellation during generation and cleanup on completion/errors. Cursor drawing forces re-encode; hiding it preserves the existing smart-cut decision.
- Shared TypeScript/Rust sampling fixture, real-FFmpeg glyph/effect pixel tests and full export-graph zoom/scene test. A reproducible synthetic filter benchmark is saved under docs/benchmarks.

### Verification limits
- Synthetic 30-second 1080p/30 vector filter took about 1.11–1.13 s versus 0.06–0.14 s without drawing; generation took 90 ms and 864 KB. Copied FFmpeg is an x86_64 binary running on an arm64 host despite its filename, so this is not native-ARM/release performance certification. Packaging must validate real sidecar architecture.
- Owner requested no further computer-use testing; manual visual review is owner-run. Real recording-log attachment and native controller/capture integration remain pending.

## [4.19.2] — 2026-10-20

### Fixed
- Recording time follows encoded media progress instead of counting capture-device startup. Start waits for actual output; paused and final result durations come from the saved media.
- Pause/Stop await FFmpeg's terminal event before probing, moving or concatenating tracks. Stable file size is no longer treated as completion. Recorder transitions remain serialized through finalization, and old tickers cannot update a later take.
- Camera/audio capture startup has a cancellable status; screen controls stay suppressed.

### Verification
- Baseline real-app test showed 14 seconds paused versus 11.573 seconds saved; updated paused display showed 10 whole seconds for a 10.997-second file. This establishes the timer correction, not the exact cause of the historical 0.501-second take.
- Owner requested no further agent computer-use testing and will perform remaining manual checks. Native capture/controller integration, cursor export and release performance certification remain pending.

## [4.19.1] — 2026-10-19

### Verification audit
- Documents an unresolved capture timing discrepancy discovered after the 4.19.0 checkpoint: a paused audio test displayed 12 seconds but its saved M4A contained 0.501 seconds, confirmed with bundled FFprobe. The first test take correctly contained 16.640 seconds. No speculative capture fix is claimed.
- Final merge remains pending native capture/controller integration, cursor export parity and recording/release verification. Movable/hidden controls and background recording transcription were exercised through computer use; system menu-bar/global-key interactions remain unverified by the available UI surface.

## [4.19.0] — 2026-10-19

### Added
- Derived timeline index and entry-anchored transport, including repeated source ranges, stable video nodes, one playing frame clock, isolated zoom/cursor/playhead updates, cached word highlighting and controlled timeline follow.
- Opt-in bounded local frame/seek/cut/long-task/React/save/memory diagnostics. Unsupported measurements are explicit. Saved Node lookup benchmarks and the owner's full improvement plan.
- Source-aligned real audio peaks with multiple cached resolutions; Original/Balanced/Low time-aligned preview proxies, generated locally and cancellable through Jobs. Exports retain original source media.
- Accessible clip lane with snapping, trim handles, frame/second keyboard nudges, split at playhead and roll edits. Drags commit once. Complete originals are preserved per source for extension; old projects remain compatible.
- Movable camera/audio recording controls with a persistent hide preference and a dedicated Hide action; screen recordings suppress the overlay until exclusion is guaranteed. Menu-bar and global-shortcut controls remain available.
- Finished recordings become playable after import while Whisper runs in the background. Progress stays in the status bar. Recognition rebases surviving ranges and undo/redo history instead of overwriting concurrent edits.

### Fixed
- Serializes autosaves/manual saves, coalesces waiting revisions, surfaces failures and clears dirty state only for the saved snapshot. Rust writes through unique temporary files under a shared save gate.
- Coalesces scrub requests with exact release seeks and rejects stale callbacks across media/edit revisions. Audio-only playback uses a frame-clock fallback.
- Same-source roll bounds and cross-media word/snap isolation; undo after saving marks the project dirty. Edited legacy transcripts no longer overwrite the complete-original cache.
- Probe and streaming hash run concurrently. Waveform/proxy/transcription work shares a bounded analysis slot. Cancellation owns its child, so queued or unrelated jobs cannot kill the active export.
- Fixes FFmpeg gradient randomness with a fixed seed and speed, stabilizing exported backgrounds and pixel regressions.

### Verification and remaining work
- Check clean; 432 frontend and 139 Rust tests pass. Computer use verified playable recording during 56% background transcription, split/roll/undo and move/hide/restore controls on a paused take. System menu-bar clicks, global key injection and screen-exclusion footage remain unverified. Automated checks and real-FFmpeg regressions are recorded in HANDOFF §4.6. Performance targets require packaged-release measurements; Node lookup timings do not prove frame or seek targets. Native capture/controller/camera integration and cursor styling export remain unfinished.

## [4.18.0] — 2026-10-19

### Added
- **Zoom tab with reviewed Auto zoom:** scale, sensitivity, clicks/typing and Follow cursor preferences; per-suggestion play, keep/remove, then Add or Replace in one undo action. Logs are clipped through the EDL before clustering so removed footage cannot suggest zooms. High-travel activity stays unzoomed.
- Tolerant version-1 cursor-log parsing, deterministic interpolation and bounded smoothing, and generators for click clusters, typing, idle, flicks and outside-area fixtures. Import `events.jsonl` for a selected video, or load the clearly labelled development demo.
- **Follow cursor** focus keys at roughly 0.25-second intervals, with matching TypeScript preview and Rust/ffmpeg export motion. Keys survive timeline moves, trims, splits, saves and cuts; choosing a manual timeline focus stops following for that region.
- **Cursor preview styling:** show/hide, arrow, pointer, dot, ring, crosshair and macOS arrow, size/colour/smoothing, ripple/ring/bounce clicks, idle hiding and optional blurred trails. The overlay shares the video's scene/zoom transform without remounting the video.
- Project-owned cursor preferences and processed tracks by media id, validated on load and preserved as raw JSON by Rust.

### Limitations / next work
- **Cursor styling is preview only.** Step 6 (a pure cursor export module, sprite/sendcmd lifecycle and click effects, frontend payload and real-ffmpeg parity/performance tests) is unfinished. It has not been benchmarked; this is not a finding that ffmpeg is too heavy. Zoom and Follow cursor already export.
- Step 7 automatic attachment of native `eventsPath` logs to new recordings remains pending the capture branch. Importing logs and the development demo exercise the UI now. Capture code, `native/` and `tauri.conf.json` externalBin were left untouched (only the required app version changed).

### Verification
- Baseline: check clean, 328 TypeScript / 118 Rust tests. This branch: check clean, 364 TypeScript / 121 Rust tests, including shared moving-focus pixel samples rendered by the real bundled ffmpeg and a video-node preservation regression.
- Ran `npm run tauri:dev` on port 1421 (1420 was occupied), packaged the debug app for unambiguous UI inspection, and exercised a synthetic 20-second project: load demo, enable Follow cursor, generate/review/add four zoom regions, muted playback, and visible cursor overlay. Real native capture logs remain unverified.

## [4.17.0] — 2026-10-19

### Added
- **Clip edit operations** (`src/lib/clipEdit.ts`, no interface yet): trim a clip's start or end past the words, split at a time, delete a clip with ripple, roll a cut between two clips, and snap to word and clip edges. Extending a clip over audio that has words brings those words back from the original transcript; clips never overlap in the source, never go below one frame, and never share a word. Groundwork for the timeline editor.
- **Zoom regions.** Select words in the transcript and press **Zoom in** in the flyout to magnify the picture over them; **Zoom out** removes zoom from the selection. A small stepper sets the level (1.2–4×) for the next one.
- **Zoom lane on the timeline:** every zoom is a block under the waveform. Drag it to move it, drag an edge to resize, double-click empty space to add one. The selected block has scale, a 3×3 focus picker (where the zoom settles) and delete in the timeline header. Zooms follow your cuts, close up over deleted passages and disappear if their content is cut.
- The preview animates the zoom (ease in, hold, ease out) inside the frame, and the export renders the same motion with ffmpeg. A zoom forces the full re-encode path and works together with the Look frame (the picture moves inside the frame). Undoable and saved with the project.

### Tests
- Real-ffmpeg tests check where the picture lands at the start, the ease midpoint (matching the preview's curve) and the plateau, plus corner focus, zoom with a frame, and duration across cuts. A test caught that ffmpeg's `crop` keeps the first frame's width, so the crop now uses the explicitly computed scaled size.

### Documentation
- `docs/cursor-events.md`: the `events.jsonl` contract between the native capture helper and auto zoom / cursor styling, and HANDOFF §4.5, a step-by-step brief for Auto zoom, Follow cursor and cursor styling that can start now on synthetic data.
- Added `docs/HANDOFF.md` (current state, what is done, what is in flight, next tasks, traps already hit, a paste-ready prompt for the next agent) and `AGENTS.md`, and pointed `CLAUDE.md` at them.
- README status table no longer lists the removed Transcribe / Edit modes and now lists auto chapters, the selection flyout, the Start screen and the planned native capture. ROADMAP has a current-status block. The manual test checklist has a section for the 4.13 to 4.17 studio features, which are not yet verified in the running app. The original spec carries a status note.

## [4.16.1] — 2026-10-19

### Fixed
- **Screen + camera recording no longer crashes ffmpeg.** The camera was mixed into the screen by a live two-input filter graph, which aborts on some ffmpeg 7.1 builds ("Assertion best_input >= 0 failed"). The screen and the camera are now recorded to separate files and composited after the take, from finished files.
- **A crashed or killed recording is no longer lost.** Takes were written as normal MP4s, whose index is only written at the end, so a crash left an unreadable file ("moov atom not found"). Takes are now fragmented MP4s flushed every packet with a keyframe each second (at most about a second lost) and remuxed to a normal MP4 when you stop. If the capture process dies mid-take, YusafCut now stops at once and keeps what was written.
- If the camera track is empty or the composite fails, the screen recording is kept on its own instead of losing the take.
- **The camera bubble was half its intended size** on ffmpeg 7.1 (the size expression read the camera's width instead of the screen's). It is now 18 / 25 / 33 % of the screen width, as the options say.

## [4.16.0] — 2026-10-19

### Added
- **Look tab: background, padding, rounded corners and shadow around the video.** Pick from 12 built-in backdrops (gradients and solids), or a custom colour, gradient (with angle) or image. Sliders for padding, corner radius and shadow, and an output aspect: Original, 16:9, 9:16, 1:1 or 4:3 (landscape video is letterboxed in portrait). The first change turns it on; it is saved with the project and is undoable.
- The live preview and the export draw the same frame. The export builds it with ffmpeg (`gradients`/`color` backdrop, anti-aliased rounded mask, blurred shadow) and always uses the full re-encode path when a frame is on. Audio-only exports ignore it.

### Tests
- Real-ffmpeg tests check actual pixels (background, rounded corners, shadow, gradient, portrait canvas, image background) and an end-to-end export checks duration against the edit list.

## [4.15.0] — 2026-10-19

### Added
- **Menu-bar item.** While recording, the menu bar shows `● 01:23` (paused: `❚❚`) and a menu to stop and add the take, pause or resume, restart, mark a moment, or discard. It is how you control a take while YusafCut is minimised out of the capture.
- **Settings tab** (bottom of the rail): rebind every recorder shortcut by clicking it and pressing the keys (modifier required, system combinations refused, conflicts explained, reset per shortcut or all), choose a 0/3/5/10 s countdown, and toggle one-press start, hide-window, auto-transcribe and markers-as-chapters.
- **Mark a moment** (⌥⌘M by default): drop a marker during a take; each becomes a "Moment n" chapter on the finished recording. Also a flag button on the recording HUD.
- **Discard shortcut** (⌥⌘⌫ by default) to throw a take away from any app.
- **One-press start:** the start/stop shortcut and the menu-bar item begin recording with your last options, skipping the setup dialog (turn off in Settings).

### Changed
- Shortcut labels in the top bar, HUD and recorder dialog follow your bindings. Shortcuts are re-registered with the OS whenever you change them or a take starts or ends.
- Pressing the record shortcut during a countdown cancels it.

## [4.14.0] — 2026-10-19

### Added
- **Auto chapters.** A new Chapters tab suggests chapters from the transcript (topic changes, pauses, cue phrases, speaker changes) with no model and no download. Pick how many, review each suggestion (include or drop it, edit its title, click to play it), then add them or replace the existing chapters. Chapters are at least 10 s apart and start at 0:00, and a hint shows when there are fewer than the 3 YouTube needs. The tab also lists, renames, deletes and plays your chapters (`src/lib/autoChapters.ts`).
- **Selection flyout.** Selecting text in the transcript shows a quick menu over it: Play, Cut, Keep only, Mark, Start chapter (inline title, prefilled) and Copy. Edits are undoable and toast with Undo.

## [4.13.1] — 2026-10-19

### Changed
- Toasts now dismiss after 5 seconds instead of 15. Hovering or focusing a toast holds it open so Undo can be reached, and the timer restarts when the pointer leaves.

## [4.13.0] — 2026-10-19

### Changed
- **No more Transcribe | Edit mode switch.** Every panel is now a tab in the left sidebar (Media, Transcribe, Cleanup, Find, Tools, Music, Export) and the transcript is always editable. Importing media opens Transcribe; once a transcript exists, Cleanup opens.
- **Cleanup moved into the sidebar** and redesigned: filler chips with live counts (hesitations on by default, real words opt-in), a review list of every match with context, Play / Keep / Cut per match and Cut all, a pause threshold slider with Remove or Shorten, and Quick trim. The Cleanup panel under the preview is gone.
- **Find & Replace moved into the sidebar** as its own tab, with the filler menu removed (it lives in Cleanup). The strip above the transcript (Search, Remove fillers, Remove pauses, Restore) is gone, so the script uses the full height.
- The "time removed" chip is centred in the top bar; the sidebar drawer is 352 px wide.

### Removed
- `workspaceMode`, `setWorkspaceMode`, `findOpen` and `panelsForMode` from `editorUiStore` and the panel registry; the review-only guards on destructive edits.

## [4.12.0] — 2026-10-19

### Added
- **Start screen** while no media is loaded: headline, a drop zone (drops already work app-wide) with Choose file / Record / Open project, a "How it works" card and recent projects, plus the on-device privacy note. Replaces the empty black preview.
- **Previous / next cut** buttons in the preview. They jump to one second before the previous or next removed span (`src/lib/cuts.ts`), so each splice is heard in context.
- **Live captions** over the preview (toggle in the controls) showing the words around the playhead, and a "Preview · edited cut" tag.
- **Undo on bulk cuts.** Remove fillers, Trim silences, Remove / Shorten pauses now toast with a one-click **Undo** button (`pushUndoToast`); toasts support an optional `action`. The transcript toolbar buttons toast too.

## [4.11.1] — 2026-10-19

### Changed
- **Edit Tools is no longer a horizontal toolbar.** The cramped icon row with dropdowns (which scrolled sideways in the 320 px panel) is now a vertical list of full-width action rows: Find, Selection (Set In / Set Out / Extract / Delete / Clear), Chapters and Timeline zoom.
- **Cleanup panel under the preview** (Edit mode): Remove fillers (live count), Trim silences, Remove all pauses, Shorten long pauses, Remove pauses over 1 s and Detect pauses are one click each, next to the video, so the transcript stays wide. The left drawer is closed on launch in Edit mode.
- **Cut map** above the waveform: kept audio in violet, removed time hatched, derived from the EDL.
- Tool rail labels are shortened ("Tools") so they no longer clip.

## [4.11.0] — 2026-10-19

### Changed
- **Editor UI refresh.** The transcript is now the hero: system serif at 21 px with a wider column, the playing word as a solid accent pill, fillers underlined in amber, deleted words struck through in coral and pause badges as small pills.
- Top bar is taller and shows a live "time removed / % shorter" chip plus a primary Export button.
- Tool rail shows a label under each icon; the Transcribe | Edit switch is a quieter segmented control.
- Transcript toolbar gains **Remove pauses (n)** next to **Remove fillers (n)**, so both cleanups are one click from the script. It uses the same cut path as the Edit Tools panel.

## [4.10.0] — 2026-10-19

### Fixed
- **Transcripts no longer split names and contractions.** Every whisper BPE token used to become its own word ("Y ves", "you" + "'re"). Tokens without a leading space are now merged into the previous word (first start, last end, lowest confidence).
- **Pause removal now cuts exactly what the badge shows.** `deletePauseById`, `deletePausesLongerThan` and Toolbox "Trim silences" used a word-based path that only deleted words wholly inside a silence; with DTW word spans (which absorb the silence before a word) it usually deleted nothing yet still removed the badge. They now go through `trimSourceRanges` (like Shorten pauses), a badge is removed only when time was really cut, and a no-op cut adds no undo step. `deletePausesLongerThan` takes an optional `keepSec`.
- "Trim silences" detects silences from the audio (ffmpeg silencedetect, ≥ 0.6 s) instead of word gaps, keeping `2 × paddingMs` of silence.

### Changed
- **One filler list** (`src/lib/fillers.ts`) replaces three that disagreed. The default selection is hesitation sounds only (um, uh, er, erm, ah, hmm, mm, mhm); real words ("like", "so", "right", "actually", "literally", "basically", "okay", …) are opt-in. Multi-word fillers ("you know", "sort of", "kind of", "i mean") match consecutive words in a segment (not across punctuation or a >1 s pause).
- The filler selection (`fillerStore`) drives the transcript highlight, the waveform marks, the status bar and the button counts, so what is highlighted and counted is exactly what "Remove fillers" cuts. The filler menu in Search shows the live match count.
- whisper-cli is passed a disfluent `--prompt` (English/auto only) so um/uh stay in the transcript.

### Removed
- Word-based `removeSilences` (`src/lib/edl.ts`) and `deleteSilenceRange` (store); replaced by `cutSilences` / `trimSilences` and `deleteFillers`.

## [4.9.0] — 2026-10-16

### Fixed
- **Shorten pauses** now really shortens them. It used to update the `[0.6s]` badges only, so preview and export still played the full silence. The middle of each pause longer than the threshold is now cut from the EDL, leaving `shortenTo / 2` of silence on each side; it is one undo step, and chapters and music-bed offsets are re-timed. A cut never removes or clips a word: word spans inside a detected pause are left in place. New pure `trimSourceRanges` in `src/lib/edl.ts`, covered by `tests/shortenPauses.test.ts`.

## [4.8.0] — 2026-10-15

### Added
- **Extract selection** — keep only the range between the I and O marks and drop everything else (`Markers ▾ → Extract selection`, `⇧⌘X`). Works in source time per segment, so untranscribed clips can be trimmed too, and it is one undo step. New pure `keepOutputRange` in `src/lib/edl.ts`.
- **Delete selection** is now also in the Markers menu (was `⌘⌫` only). Both range operations share `src/lib/rangeActions.ts` with the I / O / X shortcuts, show a toast when the range covers nothing, and respect review-only (Transcribe) mode.
- Chapters and music-bed offsets are re-timed after a ripple delete, extract or silence trim so they keep pointing at the same content (a chapter whose content was removed is dropped).
- `tests/rangeEdit.test.ts`: extract/delete behaviour plus 1e-9 s timeline and word-sync invariants (contiguity, 10 000-segment drift, output↔source round trip, 200 seeded random edit sequences).

### Fixed
- Deleting a word or gap shorter than twice `paddingMs` made the neighbouring kept segments overlap in source time, so the same audio played twice. Padding next to a cut is now capped at a quarter of the cut, and degenerate overlapping words are separated.
- Export extended every segment by `paddingMs` a second time, so the exported video grew ~`paddingMs` per segment relative to the timeline and captions/chapters/music drifted later and later. Export now cuts exactly the EDL bounds (padding is already baked into them by the edit); covered by a Rust test.

## [4.7.0] — 2026-07-07

### Added
- **Built-in recorder** — record the screen, screen + camera (picture-in-picture bubble with corner/size options), camera, or a voice-over without leaving the app. Capture runs through the bundled ffmpeg sidecar (avfoundation + VideoToolbox); everything stays local.
- **Global recording shortcuts** that work even while other apps have focus: `⌥⌘R` start/stop, `⌥⌘P` pause/resume, `⌥⌘E` re-record the current take (session shortcuts are registered only while recording).
- **Pause/resume via lossless segments** — each pause boundary starts a new ffmpeg segment; stop concatenates them with the concat demuxer (`-c copy`, no re-encode).
- **Auto-append to the end of the video** — a finished recording is imported, transcribed with the best installed Whisper model, snapped to silence edges, and appended as a new segment at the end of the EDL. If no model is installed the clip is appended untranscribed.
- **Recording HUD** — floating pill with pulsing live dot, elapsed timecode, and pause / re-record / stop / discard controls; 3-2-1 countdown before capture; the main window auto-minimises during screen capture and restores afterwards.
- **Record button** in the top bar and device pickers (display / camera / microphone) in the new recorder dialog.
- Timeline: **zoom controls** (− / value / + / fit) and a live playhead/duration timecode badge in the header; **hover scrub hairline with a timecode tooltip** on the rail.

### Changed
- **"Studio Graphite" redesign** — new token palette (cool graphite surfaces with a violet undertone, Halo-violet accent replacing teal, dedicated recording red), chrome surfaces now derive from a `--panel-deep/--panel/--panel-raised` ladder, gradient timeline bars with rounded caps, brighter playhead, violet-tinted workspace-mode toggle.
- The old `start_native_recording` / `stop_native_recording` commands and the Toolbar record dialog were replaced by the new recorder module (`commands/record.rs`, `recorder.rs`, `stores/recordingStore.ts`, `components/Recorder/`).

## [4.6.0] — 2026-07-06

### Added
- **Workspace modes** — a `Transcribe | Edit` toggle in the top bar. Transcribe mode focuses on getting the text right (Media, Transcribe panels; transcript read-only); Edit mode focuses on cutting (Edit Tools, Music, Export panels).
- **Project menu in the top bar** — New/Open project, Open video, Add clip, Recent projects (last 5), Snapshots, Close project.
- **Panel registry** — sidebar panels are declared in one registry (`sidebar/registry.tsx`); adding a panel is one entry + one component file.
- Recent projects list (`src/lib/recentProjects.ts`, localStorage-backed).

### Changed
- **Sidebar moved to the left** with the icon rail restored; the v4.4.0 right sidebar components were replaced by `components/editor/sidebar/`.
- The combined inspector panel was split into focused panels: Media, Transcribe, Edit Tools, Music, Export.
- Project lifecycle actions moved out of the sidebar into the top bar; Save is a prominent top-bar button.
- Importing media with no transcript now lands in Transcribe mode automatically; a toast nudges to Edit mode after transcription.

## [4.5.0] — 2026-07-06

### Added
- **DTW word-timestamp refinement for `large-v3` and `large-v3-turbo`** — the transcription pipeline now passes `--dtw large.v3` / `--dtw large.v3.turbo` and consumes the DTW-refined `t_dtw` token timestamps, bringing per-word accuracy from ~100 ms to ~20 ms. Fixes click-to-seek landing off-target, playback-highlight lag, and cumulative drift on long videos.
- **Silence-boundary snapping** — freshly transcribed word boundaries that fall inside an ffmpeg-detected silence are snapped to the silence edge (max 120 ms adjustment), so export cuts land in silence instead of clipping syllables. New pure module `src/lib/timestampSnap.ts`.
- Manual sync-accuracy test recipe in `docs/manual-test.md`.

### Changed
- `parse_whisper_json` prefers DTW timestamps when present and falls back to standard offsets, so older `whisper-cli` builds keep working.
- If the bundled `whisper-cli` rejects the `--dtw` preset, transcription retries once without DTW instead of failing.

### Fixed
- **Root cause of the v4.3.0 "large-v3 DTW failure"** — the app passed hyphenated preset names (`--dtw large-v3`) where whisper.cpp expects dot-separated ones (`--dtw large.v3`). The bundled binary supported DTW for the large models all along; with the correct preset names all six models now get refinement.

## [4.4.0] — 2026-06-28

### Added
- Right-side editor sidebar: 52 px icon rail with 12 panels (Layout, Background, Screen, Crop, Annotate, Mask, Transcript, Captions, AI, Media, Export, Settings)
- Right inspector panel (320 px, collapsible) driven by the active rail icon
- `editorUiStore` — UI state for active panel, aspect ratio, preview zoom, auto-fit zoom, find-in-transcript open state
- `EditorLayout` component — root shell with drag-resize, TopBar, RightEditorSidebar, BottomTimeline
- `TopBar` — minimal 40 px bar with project name, dirty indicator, Save, Undo, Redo buttons
- `PreviewWorkspace` — wraps VideoPreview with ResizeObserver auto-fit zoom tracking
- `BottomTimeline` — wraps the waveform with a clear timeline section boundary

### Changed
- `Toolbar` component now renders only its modal dialogs; all toolbar chrome removed
- All file/project actions (Open, Add Clip, Record, Music, New/Open/Close Project, Snapshots) moved to the Media panel
- Export .mp4 and caption export moved to the Export panel
- Transcribe / Re-Transcribe moved to the Transcript panel
- Toolbox editing tools (Select, Find, Markers, Edit, Zoom) moved to the Transcript panel
- `App.tsx` reduced to hooks, drag-drop wiring, and global overlay rendering
- Welcome screen copy updated to reference the Media and Transcript panels

## [4.3.0] - 2026-06-05

### Added
- **Automatic pause detection after transcription** — after a successful Whisper transcription, the app automatically runs pause detection and displays inline pause badges such as `[0.6s]` and `[2.1s]` in the transcript without user action.
- **Toolbox Edit menu pause actions** — new dropdown items: "Show pauses", "Remove all pauses", "Remove pauses > 0.5s", "Remove pauses > 1.0s", "Shorten pauses > 1.0s to 0.3s".
- **Global processing overlay** — heavy transcript/EDL edits (Remove fillers, Trim silences, Detect pauses, Remove pauses, etc.) now show a full-screen "Updating timeline…" overlay with a spinner to indicate in-progress work and lock playback until completion.
- **Pause deletion from transcript** — click any inline pause badge `[0.6s]` to remove that silence from the edit; use ⌘Z to restore. Keyboard Delete also removes a selected pause badge.
- **New `projectStore` actions**: `setPauseTokens`, `removePauseToken`, `markPauseDeleted`, `deletePauseById`, `deletePausesLongerThan`, `shortenPausesLongerThan`.
- Five new Rust pause-parsing unit tests: typical output, no silence, malformed lines, orphaned `silence_end`, invalid range.

### Changed
- **Pause tokens hardened (Phase 1)** — `PauseSegment` now carries a stable UUID `id`, pre-computed `duration`, and optional `deleted`/`shortenedTo` fields. The Rust parser rejects invalid ranges (`end ≤ start`) and orphaned `silence_end` lines without a matching `silence_start`.
- **Pause state moved to `projectStore`** — `pauseTokens` is now stored in `projectStore` (not `uiStore`) so it persists across undo/redo of EDL edits and is co-located with the project. `uiStore.detectedPauses` has been removed.
- **Safer silence deletion** — new `deleteSilenceRange` store action only removes words whose full source span falls within the silence boundary (±30 ms tolerance), preventing accidental deletion of words that merely abut the silence.
- **Pause badge identified by UUID** — `PauseNode` now carries a `pauseId` attr; click and keyboard Delete both use the id to target the correct pause, replacing the fragile float-equality lookup.
- **No duplicate badges** — calling "Show pauses" again replaces the entire list via `setPauseTokens`, never appends.
- **Playback locked during heavy edits** — when a heavy transcript operation (Remove fillers, Trim silences, Detect pauses, etc.) is in progress, the Play button is disabled and Space/J/K/L transport shortcuts are swallowed. If playback is already running, it automatically pauses when a heavy edit starts.

### Fixed
- **Large-v3 transcription failure** — removed unsupported DTW preset (`--dtw large-v3`) that caused transcription to fail with status 1 for the full `large-v3` model.
- **Pause detection sidecar binding** — verified pause detection uses the bundled ffmpeg sidecar in packaged builds (not system ffmpeg), ensuring the feature works in the released app with no external dependencies.
- **File/Edit dropdown menu transparency** — made dropdown menus opaque to improve readability and prevent flickering when the video preview is scrolling behind them.

### Known Limitations (TODO Phase 2)
- `shortenPausesLongerThan` updates the badge display only — actual EDL segment trimming (removing silence from the export timeline) requires splitting segments and is not yet implemented.
- `pauseTokens` are not serialized into the `.scribe` project bundle; they are lost on reload.

## [4.2.0] - 2026-06-05

### Added
- **Delete downloaded model** — installed Whisper models now show a "Remove" button in the model settings dialog. Clicking it prompts for confirmation and deletes the GGML `.bin` file and associated Core ML encoder directory from disk, freeing up space. The Remove button is disabled while a transcription or download is in progress.
- **`large-v3` model entry in settings UI** — the full large-v3 model (3.1 GB) is now visible in the model list so it can be downloaded and deleted from the same dialog.

### Fixed
- `list_models` now includes the `large-v3` variant that was added to the enum in v4.1.0 but omitted from the list response.

## [4.1.0] - 2026-06-05

### Added
- **`large-v3` Whisper model** — the full (non-turbo) large-v3 model (~3.1 GB) is now available in the model-download UI. It receives DTW word-timestamp refinement for maximum per-word accuracy on difficult audio. Use it when `large-v3-turbo` isn't accurate enough.
- **Pause detection command (`detect_pauses`)** — new Rust command that runs `ffmpeg silencedetect` on the source media and returns a list of silent ranges as `PauseSegment { start, end }` entries.
- **Inline pause-duration badges** — after running "Show pauses" in the Edit menu, silent gaps appear inline in the transcript as `[0.6s]`, `[2s]`, etc. Click any badge to cut that range from the EDL; use ⌘Z to restore.
- **"Show pauses" and "Remove all pauses" actions** in the Toolbox Edit dropdown. "Show pauses" runs detection and renders the badges. "Remove all pauses" cuts every detected silent range from the EDL in one operation.

## [3.7.1] - 2026-05-24

### Changed
- **Open source release preparation.** Updated README with clearer setup and build instructions. Implemented proper AGPL-3.0-or-later license file. Moved `yusafcut-spec.md` into `docs/` folder for consistency with other documentation. Removed vite.config.ts timestamp cache files from version control.

## [3.7.0] - 2026-05-21

### Fixed
- **Silence-gap sync / word highlighting.** The playhead was visually losing
  track of its position in the transcript whenever it entered a silence gap
  between two spoken words. The root cause: the highlighting loop only matched
  words whose `start ≤ sourceTime < end`, so any gap left `activeWordId` null
  and the editor cleared the highlight entirely. Fix: the loop now also tracks
  the last word whose `end ≤ sourceTime`. When the playhead is in a silence gap
  the preceding word receives the new `is-silence-after` CSS class — a
  half-opacity teal underline — so the reader's eye stays anchored while the
  gap plays out. Full-brightness `is-playing` is restored the moment the next
  word begins. No EDL changes; purely a visual / highlighting fix.

## [3.6.0] - 2026-05-21

### Added
- **DTW word-timestamp refinement.** `whisper-cli` is now invoked with
  `--dtw <model>` for all standard model sizes (tiny, base, small, medium,
  large-v1/v2/v3). Dynamic Time Warping aligns each word's start/end to its
  actual audio onset on the mel spectrogram — bringing timing accuracy from
  ~100 ms down to ~20 ms without any extra dependency. large-v3-turbo is
  skipped (not in whisper.cpp's DTW model list); its beam-search timestamps
  are already solid.
- **Cut-point pre-roll padding.** Both the full-reencode and smart-cut export
  paths now honour `project.settings.paddingMs` (default 80 ms) by pulling
  each segment's `sourceIn` back by that amount before handing it to FFmpeg.
  This prevents word-initial consonants from being clipped when Whisper's
  raw timestamps land slightly late. Only the start is padded; the end is left
  at the exact word boundary to avoid overlapping adjacent segments.

### Changed
- **Toolbox converted to dropdown groups.** The 10-item flat icon row in the
  centre of the toolbar is replaced with a clean 5-element group:
  - **Select** and **Find** remain always-visible icon buttons.
  - **Markers ▾** dropdown: Set In (I), Set Out (O), Clear markers.
  - **Edit ▾** dropdown: Trim silences, Remove fillers, Add chapter.
  - **Zoom** remains three compact icon buttons.
  The toolbox now uses the same `tool-group` / `tool-button` CSS as the
  left/right toolbar groups and takes a fraction of the horizontal space.
- **Menu consolidation.** Snapshots and Close project moved from a separate
  **Project ▾** right-side dropdown into **File ▾** alongside Add Clip, New
  Project, and Open Project. The right-side group is now just **Transcribe**
  and **Capture ▾** (Record, Music).

## [3.5.0] - 2026-05-21

### Added
- **Remove filler words.** New "Remove fillers" button in the Toolbox strips common
  filler words (um, uh, like, you know, literally, basically, etc.) in one click.
  Each removed word's corresponding audio range is cut from the EDL exactly the same
  way as a manual delete — with undo (⌘Z) support. Shows the blocking-op progress
  dialog so the UI never looks frozen during bulk removal.

### Changed
- **Toolbar cleaned up — no more double traffic lights.** The fake HTML traffic-light
  circles (red/yellow/green) that appeared below the native macOS title-bar traffic
  lights are removed. The top bar is now a clean flex row: project name on the left,
  Export + Captions on the right.
- **Unified toolbar dropdown layout.** The previous split between "full-width flat buttons"
  and "compact dropdowns" is replaced with a single consistent layout at all window sizes:
  - Left: **Open**, **Save**, **File ▾** (Add Clip, New Project, Open Project)
  - Center: Toolbox (select, find, markers, trim silences, remove fillers, chapter, zoom)
  - Right: **Transcribe**, **Capture ▾** (Record, Music), **Project ▾** (Snapshots, Close)
  This eliminates the cramped 10-button flat row that appeared at wider window widths.

## [3.4.0] - 2026-05-21

### Removed
- **AI chapters and b-roll features removed.** `detect_chapters` and
  `suggest_broll` commands, the `LlmSidecar` manager, `src-tauri/src/llm.rs`,
  and `src-tauri/src/commands/llm.rs` are all deleted. The `mlx-sidecar`
  feature flag and its `externalBin` entry in `tauri.conf.json` are also gone.
  This eliminates the Python / PyInstaller / MLX dependency entirely — the
  only sidecar binaries now required are `whisper-cli`, `ffmpeg`, and `ffprobe`.
  The full MLX implementation is preserved at commit `074d1d3`; restore with:
  `git show 074d1d3:src-tauri/src/commands/llm.rs`
- `JobKind::DetectChapters` and `JobKind::SuggestBroll` removed from the Rust
  job queue and from the `JobKind` TypeScript union in `ipc.ts`.
- AI chapters and b-roll buttons removed from `Toolbox.tsx`; the manual
  **Chapter** button (adds a chapter at the playhead) is kept.

## [3.3.0] - 2026-05-21

### Changed
- **Categorical toolbar collapse.** The compact toolbar (< 860 px) no longer
  dumps all secondary actions into a single unlabelled "More ▾" menu. Items are
  now split into two named dropdowns per side:
  - Left: **Open** and **Save** stay visible; **File ▾** holds Add Clip, New
    Project, and Open Project.
  - Right: **Transcribe** stays visible; **Media ▾** holds Record and Music
    tracks; **Project ▾** holds Snapshots and Close project.
  Full-width layout (≥ 860 px) is unchanged — all buttons remain flat.

## [3.2.0] - 2026-05-21

### Added
- **Responsive toolbar overflow.** The top toolbar now uses a `ResizeObserver`
  to detect when the window is too narrow (< 860 px) and collapses each button
  group into a "More ▾" dropdown. Nothing is hidden — every action is always
  reachable.
- **Indeterminate progress dialog for blocking edits.** Any heavy synchronous
  operation (Trim Silences, etc.) now shows a centred modal with a spinning
  indicator and a label so the app never looks frozen. The pattern is driven by
  `uiStore.editOperationLabel` — set a string to show the dialog, set `null` to
  dismiss it. New operations follow the same two-`requestAnimationFrame` deferred
  pattern so React renders the dialog before the work begins.
- **Project open loader.** Opening a `.scribe` file now shows the existing
  media-loading spinner so large projects don't silently stall the UI.

### Changed
- **Whisper.cpp accuracy improvements.** Added `--max-len 0` (eliminates
  segment-length-cap timestamp compression drift), `--best-of 5`, and
  `--beam-size 5` for higher-quality transcripts and better word-timestamp
  alignment.
- **Fixed token-offset ambiguity.** `token_offsets_ms` now correctly handles
  the `seg.from == 0` edge case where absolute and relative token offsets look
  identical, preventing rare timestamp doubling at the start of recordings. Also
  adds a safety clamp (`end = end.max(start + 1)`) to guard against
  zero-duration words from corrupted JSON.

### Removed
- **WhisperKit / ANE engine removed.** The WhisperKit engine and
  `whisperkit-cli` sidecar are removed because ANE-quantized models produced
  inaccurate word timestamps that caused video/text drift. The full
  implementation is preserved in git at commit `4726d25`; restore it with
  `git show 4726d25:src-tauri/src/commands/transcribe.rs`.

## [2.2.0] - 2026-05-21

### Added
- **Smart-cut export.** The exporter now stream-copies the long interior of
  each EDL segment and only re-encodes a few hundred frames either side of
  each cut. Typical 30-minute exports finish in seconds instead of minutes.
  Eligibility falls back to the full re-encode path when the EDL mixes
  multiple source codecs, requests a resolution / fps / codec change, or the
  source has no usable keyframes. A "Force full re-encode" toggle in the
  export dialog lets users opt out.
- **Background job queue.** Exports, transcriptions, and model downloads
  now register as cancellable jobs in a queue that persists across app
  restarts. The new "Jobs" flyout in the StatusBar shows progress, ETA, and
  errors per job, and a single click cancels the running task.
- **Multi-track audio with ducking.** A new "Music" panel adds music beds /
  sfx that the exporter mixes under the main spoken EDL. Each track has its
  own gain, offset, and an optional sidechain-ducking toggle that drops the
  music ~12 dB whenever the speaker is talking.
- **Project snapshots.** Named restore points stored inside the .scribe
  bundle as gzipped JSON. Survive restarts and travel with the project file.
  Accessed via the new "Snapshots" toolbar button.

### Changed
- Export `Codec` selector defaults to "Match source (smart-cut)" so the fast
  path engages without the user thinking about it; explicit H.264 / HEVC
  still works and skips smart-cut.
- Resolution defaults to "Original" so smart-cut isn't disabled by an
  accidental rescale.

## [1.3.0] - 2026-05-20

### Added
- Timeline-docked editing toolbox with working in/out marker controls, marker
  clearing, transcript search access, and timeline zoom.
- Configurable delete-gap padding for transcript search/filler removals, from
  0 to 10 seconds.
- Indeterminate progress animation for local transcription and media probing
  when reliable percentages are unavailable.

### Changed
- Removed non-functional Razor, Slip, and Slide tool buttons in favor of
  controls that are wired to real editing behavior.
- Pausing playback from Space/K/the preview button now restores playback speed
  to 1x.

## [1.1.0] - 2026-05-20

### Added
- Transcript cache keyed by media hash so already-transcribed videos reopen with
  their transcript without rerunning Whisper.
- Transcript and timeline selection sync: marked timeline ranges now highlight
  the matching words in the transcript.

### Changed
- Transcript editing is now selection-and-delete only. Users can select words
  and remove the matching video range, but cannot type over or replace transcript
  text.

### Fixed
- `Cmd+Z` no longer undoes media import, project open, or transcription loading.
  Undo history now starts at intentional edit operations.
- Common edit shortcuts guard against empty undo/redo stacks and selected-word
  deletes clear the native text selection after the EDL update.

## [Scribe 1.0.0, internal] - 2026-05-20

### Added
- MVP-ready local media playback through Tauri's asset protocol.
- Transcript-driven preview, filler highlighting, ripple delete, and export controls.
- Timeline in/out markers with `I`/`O`, `Cmd+Delete` ripple delete, and J/K/L transport.
- Left editor toolbox with Select, Razor, Slip, and Slide tools.
- Centered progress modals for media loading, transcription, model download, and export.
- Initial project scaffold for Phases 0–6 of the spec.
- EDL data model (TypeScript + Rust) with full round-trip tests.
- TipTap-based transcript editor with custom Word inline node.
- Zustand project store with zundo undo middleware (50-step history).
- Rust commands for media import (FFprobe), transcription (whisper.cpp), project
  save/load, and export (FFmpeg + VideoToolbox).
- Vitest + Cargo test suites covering EDL ops, timecode helpers, FFprobe parser,
  Whisper JSON parser, and the ffmpeg filter graph builder.
- GitHub Actions CI workflow (lint, typecheck, test, build).

### Post-1.0
- Sidecar binaries are not bundled — see `src-tauri/binaries/README.md`.
- Auto-update manifest signing.
- Code-signed `.dmg` distribution.
- Filler-word detection, speaker diarisation, LLM features (Phase 2 of the spec).
