#!/usr/bin/env bash
# Prepare a separate sandboxed, distribution-signed store candidate. Never uploads.
set -euo pipefail
REPO="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PROFILE="$REPO/src-tauri/YusafCut_MAS.provisionprofile"
APP="$REPO/src-tauri/target/mas/release/bundle/macos/WordsCut.app"
[[ -f "$PROFILE" ]] || { echo 'WordsCut Mac App Store provisioning profile missing'; exit 1; }
STAGE="$(mktemp -d)"; trap 'rm -rf "$STAGE"' EXIT
security cms -D -i "$PROFILE" > "$STAGE/profile.plist"
python3 - "$STAGE/profile.plist" "$REPO/src-tauri/Entitlements.plist" "$STAGE/entitlements.plist" <<'PYTHON'
import sys,plistlib,datetime
profile=plistlib.load(open(sys.argv[1],'rb'))
assert profile['ExpirationDate'] > datetime.datetime.utcnow(), 'Provisioning profile expired'
assert not profile.get('ProvisionedDevices'), 'Use an App Store distribution profile'
allowed=profile['Entitlements']
identifier=allowed.get('com.apple.application-identifier',allowed.get('application-identifier',''))
assert identifier.endswith('.dev.yusafcut.app'), 'Wrong app provisioning profile'
assert not allowed.get('get-task-allow',False), 'Development profile cannot be shipped'
entitlements=plistlib.load(open(sys.argv[2],'rb'))
for key in ['com.apple.application-identifier','application-identifier','com.apple.developer.team-identifier']:
 if key in allowed: entitlements[key]=allowed[key]
plistlib.dump(entitlements,open(sys.argv[3],'wb'))
PYTHON
IDENTITY="$(python3 - "$STAGE/profile.plist" <<'PYTHON'
import sys,plistlib,hashlib
p=plistlib.load(open(sys.argv[1],'rb'))
print(hashlib.sha1(p['DeveloperCertificates'][0]).hexdigest().upper())
PYTHON
)"
security find-identity -v -p codesigning | grep -q "$IDENTITY" || { echo 'Matching store signing private key is unavailable'; exit 1; }
for NAME in whisper-cli ffmpeg ffprobe yusafcut-capture; do
  FILE="$REPO/src-tauri/binaries/$NAME-aarch64-apple-darwin"
  lipo -archs "$FILE" | grep -qw arm64
  [[ "$(stat -f%z "$FILE")" -gt 100000 ]] || { echo "Missing/stub $NAME"; exit 1; }
done
cd "$REPO"
CARGO_TARGET_DIR="$REPO/src-tauri/target/mas" npx tauri build --bundles app --no-sign --config src-tauri/tauri.mas.conf.json
cp "$PROFILE" "$APP/Contents/embedded.provisionprofile"
while IFS= read -r -d '' FILE; do
  if file -b "$FILE" | grep -q 'Mach-O'; then
    codesign --force --options runtime --timestamp --entitlements "$REPO/src-tauri/EntitlementsHelper.plist" --sign "$IDENTITY" "$FILE"
  fi
done < <(find "$APP/Contents" -type f -print0)
codesign --force --options runtime --timestamp --entitlements "$STAGE/entitlements.plist" --sign "$IDENTITY" "$APP"
codesign --verify --deep --strict --verbose=2 "$APP"
echo "Store-signed candidate: $APP"
echo 'NOT submitted. Sandbox, persistent file access, capture and licensing gates remain open.'
