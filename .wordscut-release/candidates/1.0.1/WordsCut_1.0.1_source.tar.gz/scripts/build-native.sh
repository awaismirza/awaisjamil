#!/usr/bin/env bash
# =============================================================================
# WordsCut — build the native capture helper
#
#   npm run native:build        (calls this script)
#
# Compiles native/yusafcut-capture (ScreenCaptureKit / AVFoundation recorder)
# with `swift build -c release` and installs it as the Tauri sidecar
#   src-tauri/binaries/yusafcut-capture-aarch64-apple-darwin
#
# The repo ships a tiny stub at that path so `tauri build` never breaks on a
# machine without the Swift toolchain; the stub exits immediately and the app
# falls back to its ffmpeg recorder. This script replaces the stub with the real
# binary and marks it skip-worktree so it never shows up in `git status`.
#
# Flags:  --test   also run `swift test` first
# =============================================================================
set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; CYAN='\033[0;36m'; YELLOW='\033[1;33m'; RESET='\033[0m'
ok()   { echo -e "  ${GREEN}✓${RESET}  $*"; }
info() { echo -e "  ${CYAN}→${RESET}  $*"; }
warn() { echo -e "  ${YELLOW}⚠${RESET}  $*"; }
die()  { echo -e "  ${RED}✗${RESET}  $*" >&2; exit 1; }

REPO="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PKG="$REPO/native/yusafcut-capture"
DEST="$REPO/src-tauri/binaries/yusafcut-capture-aarch64-apple-darwin"

[[ "$(uname -s)" == "Darwin" ]] || die "The capture helper is macOS only."
command -v swift >/dev/null 2>&1 || die "swift not found — install Xcode or the Command Line Tools (xcode-select --install)."

if [[ "${1:-}" == "--test" ]]; then
  info "Running swift test…"
  (cd "$PKG" && swift test 2>&1 | grep -E "Executed|error:|failed" | tail -8)
fi

info "Building yusafcut-capture (release, arm64)…"
(cd "$PKG" && swift build -c release --arch arm64 2>&1 | grep -E "error|warning: unre|Compiling|Build complete" | tail -5)
BIN="$(cd "$PKG" && swift build -c release --arch arm64 --show-bin-path)/yusafcut-capture"
[[ -x "$BIN" ]] || die "build produced no binary at $BIN"

mkdir -p "$(dirname "$DEST")"
cp "$BIN" "$DEST"
chmod +x "$DEST"
# Stable identifier so macOS privacy (TCC) entries survive rebuilds as far as possible.
codesign --force --sign - --identifier dev.yusafcut.capture "$DEST" >/dev/null 2>&1 \
  || warn "ad-hoc codesign failed (the linker's own signature is kept)"

( cd "$REPO" && git update-index --skip-worktree "src-tauri/binaries/yusafcut-capture-aarch64-apple-darwin" 2>/dev/null ) || true

SIZE="$(du -sh "$DEST" | awk '{print $1}')"
ok "installed $DEST (${SIZE})"
