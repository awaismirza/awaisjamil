#!/usr/bin/env bash
# scripts/build-arm64-media.sh
#
# Reproducible, hermetic native ARM64 (aarch64-apple-darwin) builder for
# WordsCut's bundled FFmpeg and FFprobe binaries.
#
# Builds from pinned, SHA-256-verified upstream source tarballs:
#   - fribidi 1.0.16 (LGPL-2.1+)
#   - freetype 2.13.3 (FTL / GPL-2.0+)
#   - harfbuzz 10.1.0 (MIT)
#   - libass 0.17.3 (ISC, using macOS CoreText font provider)
#   - x264 31e19f92f00c7003fa115047ce50978bc98c3a0d (GPL-2.0+)
#   - FFmpeg 7.1.1 (GPL-3.0+ with --enable-gpl --enable-version3)
#
# Key properties:
#   - Targets arm64-apple-macos13.0 (matching tauri.conf.json minimumSystemVersion)
#   - Hermetically isolates pkg-config from /opt/homebrew and /usr/local so the
#     resulting binaries link dynamically ONLY to macOS system frameworks and /usr/lib
#   - Uses nice -n 15 and bounded concurrency (default JOBS=4) to avoid hogging CPU
#   - Verifies candidates via scripts/verify-media-binaries.sh BEFORE atomic install
#   - Preserves existing binaries if any download, checksum, build, or verification step fails

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
DEFAULT_INSTALL_DIR="$REPO_ROOT/src-tauri/binaries"

CACHE_DIR="${YUSAFCUT_MEDIA_CACHE_DIR:-/private/tmp/yusafcut-arm64-media-cache}"
WORK_BASE="${YUSAFCUT_MEDIA_WORK_BASE:-/private/tmp}"
INSTALL_DIR="$DEFAULT_INSTALL_DIR"
MACOSX_DEPLOYMENT_TARGET="${MACOSX_DEPLOYMENT_TARGET:-13.0}"
JOBS="${JOBS:-4}"
KEEP_BUILD_DIR=0
SKIP_VERIFY=0
VERIFY_ONLY=0

usage() {
  cat <<'EOF'
Usage: scripts/build-arm64-media.sh [options]

Options:
  --install-dir <dir>   Destination directory for ffmpeg-aarch64-apple-darwin and
                        ffprobe-aarch64-apple-darwin (default: src-tauri/binaries)
  --cache-dir <dir>     Directory for cached upstream source tarballs
                        (default: /private/tmp/yusafcut-arm64-media-cache)
  --jobs <n>            Parallel make jobs (default: 4)
  --keep-build-dir      Do not delete temporary build directory on completion
  --skip-verify         Skip running scripts/verify-media-binaries.sh before install
  --verify-only         Only run scripts/verify-media-binaries.sh on installed binaries
  -h, --help            Show this help message
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --install-dir)
      INSTALL_DIR="$2"
      shift 2
      ;;
    --cache-dir)
      CACHE_DIR="$2"
      shift 2
      ;;
    --jobs)
      JOBS="$2"
      shift 2
      ;;
    --keep-build-dir)
      KEEP_BUILD_DIR=1
      shift
      ;;
    --skip-verify)
      SKIP_VERIFY=1
      shift
      ;;
    --verify-only)
      VERIFY_ONLY=1
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unknown option: $1" >&2
      usage >&2
      exit 2
      ;;
  esac
done

if [[ "$VERIFY_ONLY" -eq 1 ]]; then
  exec bash "$SCRIPT_DIR/verify-media-binaries.sh" \
    --ffmpeg "$INSTALL_DIR/ffmpeg-aarch64-apple-darwin" \
    --ffprobe "$INSTALL_DIR/ffprobe-aarch64-apple-darwin"
fi

source "$SCRIPT_DIR/media-sources.sh"

mkdir -p "$CACHE_DIR" "$INSTALL_DIR"

fetch_and_verify() {
  local name="$1"
  local url="$2"
  local tarball="$3"
  local expected_sha="$4"
  local target_path="$CACHE_DIR/$tarball"

  if [[ -f "$target_path" ]]; then
    local actual_sha
    actual_sha="$(shasum -a 256 "$target_path" | awk '{print $1}')"
    if [[ "$actual_sha" == "$expected_sha" ]]; then
      echo "[cache] Verified $name ($tarball)"
      return 0
    fi
    echo "[cache] Checksum mismatch on cached $tarball, re-downloading..."
    rm -f "$target_path"
  fi

  echo "[fetch] Downloading $name from $url..."
  local tmp_dl="${target_path}.part.$$"
  curl -fL --retry 3 --connect-timeout 20 -o "$tmp_dl" "$url"
  local actual_sha
  actual_sha="$(shasum -a 256 "$tmp_dl" | awk '{print $1}')"
  if [[ "$actual_sha" != "$expected_sha" ]]; then
    rm -f "$tmp_dl"
    echo "ERROR: SHA-256 mismatch for $tarball" >&2
    echo "  Expected: $expected_sha" >&2
    echo "  Actual:   $actual_sha" >&2
    exit 1
  fi
  mv "$tmp_dl" "$target_path"
  echo "[fetch] Verified $name ($expected_sha)"
}

echo "=== Phase 1: Verifying upstream source archives ==="
fetch_and_verify "fribidi" "$FRIBIDI_URL" "$FRIBIDI_TARBALL" "$FRIBIDI_SHA256"
fetch_and_verify "freetype" "$FREETYPE_URL" "$FREETYPE_TARBALL" "$FREETYPE_SHA256"
fetch_and_verify "harfbuzz" "$HARFBUZZ_URL" "$HARFBUZZ_TARBALL" "$HARFBUZZ_SHA256"
fetch_and_verify "libass" "$LIBASS_URL" "$LIBASS_TARBALL" "$LIBASS_SHA256"
fetch_and_verify "x264" "$X264_URL" "$X264_TARBALL" "$X264_SHA256"
fetch_and_verify "ffmpeg" "$FFMPEG_URL" "$FFMPEG_TARBALL" "$FFMPEG_SHA256"

BUILD_ROOT="$(mktemp -d "${WORK_BASE}/yusafcut-arm64-build.XXXXXX")"
STAGE_DIR="$BUILD_ROOT/stage"
SRC_DIR="$BUILD_ROOT/src"
LOG_DIR="$BUILD_ROOT/logs"
mkdir -p "$STAGE_DIR" "$SRC_DIR" "$LOG_DIR"

cleanup() {
  if [[ "$KEEP_BUILD_DIR" -eq 0 && -d "$BUILD_ROOT" ]]; then
    rm -rf "$BUILD_ROOT"
  else
    echo "[info] Build directory preserved at: $BUILD_ROOT"
  fi
}
trap cleanup EXIT

echo "=== Phase 2: Preparing hermetic ARM64 build environment ==="
echo "  Build root:        $BUILD_ROOT"
echo "  Deployment target: macOS $MACOSX_DEPLOYMENT_TARGET (arm64)"
echo "  Concurrency:       JOBS=$JOBS (nice -n 15)"

SDKROOT="$(xcrun --sdk macosx --show-sdk-path)"
export SDKROOT
export MACOSX_DEPLOYMENT_TARGET
export CC="xcrun clang"
export CXX="xcrun clang++"
export AR="xcrun ar"
export RANLIB="xcrun ranlib"
export STRIP="xcrun strip"
export NM="xcrun nm"

COMMON_ARCH_FLAGS="-arch arm64 -mmacosx-version-min=${MACOSX_DEPLOYMENT_TARGET} -isysroot ${SDKROOT}"
export CFLAGS="${COMMON_ARCH_FLAGS} -O3 -I${STAGE_DIR}/include"
export CXXFLAGS="${COMMON_ARCH_FLAGS} -O3 -I${STAGE_DIR}/include"
export LDFLAGS="${COMMON_ARCH_FLAGS} -L${STAGE_DIR}/lib"

# Hermetically seal pkg-config so Homebrew libraries in /opt/homebrew or /usr/local
# are never discovered or linked into our static staging prefix.
export PKG_CONFIG_PATH=""
export PKG_CONFIG_LIBDIR="${STAGE_DIR}/lib/pkgconfig"

run_logged() {
  local step_name="$1"
  shift
  local log_file="$LOG_DIR/${step_name}.log"
  echo "[build] $step_name (log: $log_file)..."
  if ! nice -n 15 "$@" >"$log_file" 2>&1; then
    echo "ERROR: Build step '$step_name' failed. Last 50 lines of $log_file:" >&2
    tail -n 50 "$log_file" >&2
    exit 1
  fi
}

# 1. fribidi (static)
tar -xf "$CACHE_DIR/$FRIBIDI_TARBALL" -C "$SRC_DIR"
pushd "$SRC_DIR/fribidi-${FRIBIDI_VERSION}" >/dev/null
run_logged "01-fribidi-configure" ./configure \
  --prefix="$STAGE_DIR" \
  --host=aarch64-apple-darwin \
  --enable-static \
  --disable-shared \
  --disable-debug \
  --disable-deprecated
run_logged "02-fribidi-make" make -j"$JOBS"
run_logged "03-fribidi-install" make install
popd >/dev/null

# 2. freetype (static, initial pass without harfbuzz; libass uses harfbuzz directly)
tar -xf "$CACHE_DIR/$FREETYPE_TARBALL" -C "$SRC_DIR"
pushd "$SRC_DIR/freetype-${FREETYPE_VERSION}" >/dev/null
run_logged "04-freetype-configure" ./configure \
  --prefix="$STAGE_DIR" \
  --host=aarch64-apple-darwin \
  --enable-static \
  --disable-shared \
  --with-zlib=yes \
  --without-bzip2 \
  --without-png \
  --without-harfbuzz \
  --without-brotli \
  --without-librsvg
run_logged "05-freetype-make" make -j"$JOBS"
run_logged "06-freetype-install" make install
popd >/dev/null

# 3. harfbuzz (static via CMake, with freetype & CoreText)
tar -xf "$CACHE_DIR/$HARFBUZZ_TARBALL" -C "$SRC_DIR"
pushd "$SRC_DIR/harfbuzz-${HARFBUZZ_VERSION}" >/dev/null
run_logged "07-harfbuzz-cmake-configure" cmake -B build \
  -DCMAKE_INSTALL_PREFIX="$STAGE_DIR" \
  -DCMAKE_PREFIX_PATH="$STAGE_DIR" \
  -DCMAKE_OSX_ARCHITECTURES="arm64" \
  -DCMAKE_OSX_DEPLOYMENT_TARGET="$MACOSX_DEPLOYMENT_TARGET" \
  -DCMAKE_OSX_SYSROOT="$SDKROOT" \
  -DCMAKE_BUILD_TYPE=Release \
  -DBUILD_SHARED_LIBS=OFF \
  -DHB_HAVE_FREETYPE=ON \
  -DHB_HAVE_CORETEXT=ON \
  -DHB_HAVE_GLIB=OFF \
  -DHB_HAVE_ICU=OFF \
  -DHB_HAVE_GOBJECT=OFF \
  -DHB_HAVE_CAIRO=OFF \
  -DHB_HAVE_GRAPHITE2=OFF \
  -DFREETYPE_LIBRARY="$STAGE_DIR/lib/libfreetype.a" \
  -DFREETYPE_INCLUDE_DIRS="$STAGE_DIR/include/freetype2" \
  -DCMAKE_DISABLE_FIND_PACKAGE_BZip2=TRUE \
  -DCMAKE_DISABLE_FIND_PACKAGE_PNG=TRUE \
  -DCMAKE_DISABLE_FIND_PACKAGE_BrotliDec=TRUE
run_logged "08-harfbuzz-cmake-build" cmake --build build -j "$JOBS"
run_logged "09-harfbuzz-cmake-install" cmake --install build
popd >/dev/null

# 4. libass (static, using CoreText font provider; no fontconfig required)
tar -xf "$CACHE_DIR/$LIBASS_TARBALL" -C "$SRC_DIR"
pushd "$SRC_DIR/libass-${LIBASS_VERSION}" >/dev/null
run_logged "10-libass-configure" ./configure \
  --prefix="$STAGE_DIR" \
  --host=aarch64-apple-darwin \
  --enable-static \
  --disable-shared \
  --disable-fontconfig \
  --enable-coretext \
  --disable-require-system-font-provider
run_logged "11-libass-make" make -j"$JOBS"
run_logged "12-libass-install" make install
popd >/dev/null

# 5. x264 (static, 8-bit/10-bit unified in modern x264)
tar -xf "$CACHE_DIR/$X264_TARBALL" -C "$SRC_DIR"
pushd "$SRC_DIR/x264-${X264_COMMIT}" >/dev/null
run_logged "13-x264-configure" ./configure \
  --prefix="$STAGE_DIR" \
  --host=aarch64-apple-darwin \
  --enable-static \
  --enable-pic \
  --disable-cli \
  --disable-avs \
  --disable-swscale \
  --disable-lavf \
  --disable-ffms \
  --disable-gpac \
  --disable-lsmash
run_logged "14-x264-make" make -j"$JOBS"
run_logged "15-x264-install" make install
popd >/dev/null

# Remove any accidental .dylib files in STAGE_DIR/lib so the linker can only pick static .a archives
rm -f "$STAGE_DIR"/lib/*.dylib

# 6. FFmpeg + FFprobe 7.1.1 (native arm64, static third-party libs, system frameworks only)
tar -xf "$CACHE_DIR/$FFMPEG_TARBALL" -C "$SRC_DIR"
pushd "$SRC_DIR/ffmpeg-${FFMPEG_VERSION}" >/dev/null
run_logged "16-ffmpeg-configure" ./configure \
  --prefix="$STAGE_DIR" \
  --arch=arm64 \
  --target-os=darwin \
  --cc="$CC" \
  --cxx="$CXX" \
  --extra-cflags="$CFLAGS" \
  --extra-cxxflags="$CXXFLAGS" \
  --extra-ldflags="$LDFLAGS" \
  --pkg-config-flags="--static" \
  --enable-gpl \
  --enable-version3 \
  --enable-static \
  --disable-shared \
  --enable-pthreads \
  --enable-runtime-cpudetect \
  --enable-neon \
  --disable-autodetect \
  --enable-iconv \
  --enable-zlib \
  --enable-bzlib \
  --enable-appkit \
  --enable-avfoundation \
  --enable-coreimage \
  --enable-videotoolbox \
  --enable-audiotoolbox \
  --enable-libx264 \
  --enable-libass \
  --enable-ffmpeg \
  --enable-ffprobe \
  --disable-ffplay \
  --disable-doc \
  --disable-htmlpages \
  --disable-manpages \
  --disable-podpages \
  --disable-txtpages \
  --disable-debug \
  --disable-network
run_logged "17-ffmpeg-make" make -j"$JOBS"
run_logged "18-ffmpeg-install" make install
popd >/dev/null

CANDIDATE_FFMPEG="$STAGE_DIR/bin/ffmpeg"
CANDIDATE_FFPROBE="$STAGE_DIR/bin/ffprobe"

if [[ ! -x "$CANDIDATE_FFMPEG" || ! -x "$CANDIDATE_FFPROBE" ]]; then
  echo "ERROR: Candidate binaries were not produced in $STAGE_DIR/bin" >&2
  exit 1
fi

# Strip local debug symbols to keep bundle size lean while retaining runnable Mach-O
xcrun strip -x "$CANDIDATE_FFMPEG" "$CANDIDATE_FFPROBE"
codesign --force --sign - "$CANDIDATE_FFMPEG" "$CANDIDATE_FFPROBE"

if [[ "$SKIP_VERIFY" -eq 0 ]]; then
  echo "=== Phase 3: Verifying candidate binaries before atomic install ==="
  bash "$SCRIPT_DIR/verify-media-binaries.sh" \
    --ffmpeg "$CANDIDATE_FFMPEG" \
    --ffprobe "$CANDIDATE_FFPROBE" \
    --json "$BUILD_ROOT/verify-candidates.json"
fi

echo "=== Phase 4: Atomically installing verified ARM64 binaries ==="
TMP_INSTALL_FFMPEG="$INSTALL_DIR/.ffmpeg-aarch64-apple-darwin.tmp.$$"
TMP_INSTALL_FFPROBE="$INSTALL_DIR/.ffprobe-aarch64-apple-darwin.tmp.$$"

cp -f "$CANDIDATE_FFMPEG" "$TMP_INSTALL_FFMPEG"
cp -f "$CANDIDATE_FFPROBE" "$TMP_INSTALL_FFPROBE"
chmod 755 "$TMP_INSTALL_FFMPEG" "$TMP_INSTALL_FFPROBE"
codesign --force --sign - "$TMP_INSTALL_FFMPEG" "$TMP_INSTALL_FFPROBE"

mv -f "$TMP_INSTALL_FFMPEG" "$INSTALL_DIR/ffmpeg-aarch64-apple-darwin"
mv -f "$TMP_INSTALL_FFPROBE" "$INSTALL_DIR/ffprobe-aarch64-apple-darwin"

FFMPEG_FINAL_SHA="$(shasum -a 256 "$INSTALL_DIR/ffmpeg-aarch64-apple-darwin" | awk '{print $1}')"
FFPROBE_FINAL_SHA="$(shasum -a 256 "$INSTALL_DIR/ffprobe-aarch64-apple-darwin" | awk '{print $1}')"
FFMPEG_FINAL_SIZE="$(stat -f%z "$INSTALL_DIR/ffmpeg-aarch64-apple-darwin")"
FFPROBE_FINAL_SIZE="$(stat -f%z "$INSTALL_DIR/ffprobe-aarch64-apple-darwin")"

echo "Installed native arm64 binaries to $INSTALL_DIR:"
echo "  ffmpeg-aarch64-apple-darwin:  ${FFMPEG_FINAL_SIZE} bytes (SHA-256: ${FFMPEG_FINAL_SHA})"
echo "  ffprobe-aarch64-apple-darwin: ${FFPROBE_FINAL_SIZE} bytes (SHA-256: ${FFPROBE_FINAL_SHA})"
