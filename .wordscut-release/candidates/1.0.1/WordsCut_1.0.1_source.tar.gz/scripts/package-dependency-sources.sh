#!/usr/bin/env bash
# Ship pinned native dependency sources with every binary release.
set -euo pipefail
REPO="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$REPO/scripts/media-sources.sh"
OUT="${1:?release output directory required}"
mkdir -p "$OUT"
OUT="$(cd "$OUT" && pwd)"
STAGE="$(mktemp -d)"
trap 'rm -rf "$STAGE"' EXIT
mkdir -p "$STAGE/WordsCut-dependency-sources"
for NAME in FFMPEG FREETYPE FRIBIDI HARFBUZZ LIBASS X264; do
  eval 'URL="${'"$NAME"'_URL}"; ARCHIVE="${'"$NAME"'_TARBALL}"; EXPECTED="${'"$NAME"'_SHA256}"'
  DEST="$STAGE/WordsCut-dependency-sources/$ARCHIVE"
  CACHE="${YUSAFCUT_MEDIA_CACHE_DIR:-/private/tmp/yusafcut-arm64-media-cache}/$ARCHIVE"
  if [ -f "$CACHE" ]; then cp "$CACHE" "$DEST"; else curl -fLsS --retry 3 "$URL" -o "$DEST"; fi
  test "$(shasum -a 256 "$DEST" | awk '{print $1}')" = "$EXPECTED"
  printf '%s  %s\n' "$EXPECTED" "$ARCHIVE" >> "$STAGE/WordsCut-dependency-sources/SHA256SUMS.txt"
  printf '%s %s\n' "$ARCHIVE" "$URL" >> "$STAGE/WordsCut-dependency-sources/UPSTREAM.txt"
done
git init -q "$STAGE/WordsCut-dependency-sources/whisper.cpp"
git -C "$STAGE/WordsCut-dependency-sources/whisper.cpp" remote add origin https://github.com/ggml-org/whisper.cpp
git -C "$STAGE/WordsCut-dependency-sources/whisper.cpp" fetch --depth 1 origin 51c6961c7b64b406833f4b6a4a20e67142f69225
git -C "$STAGE/WordsCut-dependency-sources/whisper.cpp" checkout --detach FETCH_HEAD
rm -rf "$STAGE/WordsCut-dependency-sources/whisper.cpp/.git"
cp "$REPO/scripts/build-arm64-media.sh" "$REPO/scripts/media-sources.sh" "$REPO/scripts/build-whisper.sh" "$STAGE/WordsCut-dependency-sources/"
tar -czf "$OUT/WordsCut_dependency_sources.tar.gz" -C "$STAGE" WordsCut-dependency-sources
