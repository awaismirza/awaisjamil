#!/usr/bin/env bash
# =============================================================================
# WordsCut — one-command build + install for real use on this Mac
#
#   npm run app:install            build everything, install to /Applications
#   npm run app:install -- --no-install    build only (app + dmg), do not install
#   npm run app:install -- --check         prerequisites only, build nothing
#   npm run app:install -- --no-sign       skip signing (signing is ON by default)
#   npm run app:install -- --sign <hash|name>   sign with that identity instead
#
# Signing uses your "Apple Development" certificate by default (stable identity,
# so macOS keeps the Screen/Camera/Mic permissions across rebuilds).
#
# Steps: platform + prerequisite check -> npm install -> real native capture
# helper (swift build) -> sidecar verification -> tauri build (.app + .dmg) ->
# install to /Applications -> open it.
#
# Not done here: notarization (see docs/distribution-and-signing.md and
# `npm run sign:dmg`). A locally built app is fine for your own use; first
# launch may need right-click -> Open if macOS shows a Gatekeeper warning.
# Permissions (Screen Recording, Camera, Microphone, Input Monitoring) are
# asked for by macOS the first time the app needs them.
# =============================================================================
set -euo pipefail

INSTALL=1; CHECK_ONLY=0; SIGN=1; SIGN_ID=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    --no-install) INSTALL=0 ;;
    --check) CHECK_ONLY=1 ;;
    --no-sign) SIGN=0 ;;
    --sign) SIGN=1
      if [[ $# -gt 1 && "$2" != --* ]]; then SIGN_ID="$2"; shift; fi ;;
    *) echo "unknown flag: $1" >&2; exit 2 ;;
  esac
  shift
done

G='\033[0;32m'; R='\033[0;31m'; C='\033[0;36m'; B='\033[1m'; N='\033[0m'
ok()   { echo -e "  ${G}✓${N}  $*"; }
info() { echo -e "  ${C}→${N}  $*"; }
die()  { echo -e "  ${R}✗${N}  $*" >&2; exit 1; }
step() { echo -e "\n${B}$*${N}"; }

REPO="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO"
BINS="$REPO/src-tauri/binaries"
ARCH="aarch64-apple-darwin"
APP_SRC="$REPO/src-tauri/target/release/bundle/macos/WordsCut.app"
DMG_DIR="$REPO/src-tauri/target/release/bundle/dmg"
START=$(date +%s)

step "1 / 6  Prerequisites"
[[ "$(uname -s)" == "Darwin" && "$(uname -m)" == "arm64" ]] || die "Apple Silicon Mac required."
for c in node npm cargo swift xcode-select; do
  command -v "$c" >/dev/null 2>&1 || die "$c not found (install Node 20+, Rust via rustup, Xcode command line tools)."
done
xcode-select -p >/dev/null 2>&1 || die "Xcode command line tools missing: xcode-select --install"
ok "Apple Silicon, node $(node --version), $(cargo --version | cut -d' ' -f1-2), swift present"

for b in ffmpeg ffprobe whisper-cli; do
  [[ -x "$BINS/$b-$ARCH" ]] || die "missing sidecar src-tauri/binaries/$b-$ARCH (see HOW_TO_RUN.md; npm run media:build builds ffmpeg/ffprobe)."
done
ok "ffmpeg, ffprobe and whisper-cli sidecars present"

if [[ $INSTALL -eq 1 ]] && { pgrep -x WordsCut >/dev/null 2>&1 || pgrep -x YusafCut >/dev/null 2>&1; }; then
  die "WordsCut or legacy YusafCut is running. Quit it first (it may hold the camera/microphone), then re-run."
fi
if [[ $SIGN -eq 1 && -z "$SIGN_ID" ]]; then
  # SHA-1 of the first valid "Apple Development" certificate (names can repeat).
  SIGN_ID="$(security find-identity -v -p codesigning | awk '/Apple Development:/ {print $2; exit}')"
  [[ -n "$SIGN_ID" ]] || die "no 'Apple Development' signing identity in the keychain (see: security find-identity -v -p codesigning)."
fi
[[ $SIGN -eq 1 ]] && ok "will sign with identity $SIGN_ID"
[[ $CHECK_ONLY -eq 1 ]] && { ok "checks passed"; exit 0; }

step "2 / 6  JavaScript dependencies"
npm install --no-audit --no-fund
ok "npm install"

step "3 / 6  Native capture helper (real ScreenCaptureKit/AVFoundation build)"
npm run native:build
CAP="$BINS/yusafcut-capture-$ARCH"
SIZE=$(stat -f%z "$CAP")
[[ "$SIZE" -gt 100000 ]] || die "capture helper is still the stub ($SIZE bytes); native:build did not install the real binary."
ok "capture helper installed ($SIZE bytes)"

step "4 / 6  Build the app (frontend + Rust release + bundles)"
npx tauri build --bundles app,dmg
[[ -d "$APP_SRC" ]] || die "build finished but $APP_SRC is missing."
ok "built $APP_SRC"
DMG="$(ls -t "$DMG_DIR"/*.dmg 2>/dev/null | head -1 || true)"
[[ -n "$DMG" ]] && ok "dmg: $DMG"

if [[ $SIGN -eq 1 ]]; then
  step "4b  Sign (inside-out, no sandbox)"
  # Nested sidecars first, then the app. No hardened runtime / sandbox entitlements:
  # src-tauri/Entitlements.plist is the Mac App Store sandbox profile and would
  # break the unsandboxed ffmpeg/whisper/capture sidecars.
  while IFS= read -r f; do
    [[ "$(basename "$f")" == "WordsCut" ]] && continue
    codesign --force --sign "$SIGN_ID" "$f"
    ok "signed $(basename "$f")"
  done < <(find "$APP_SRC/Contents/MacOS" -type f -perm +111)
  codesign --force --sign "$SIGN_ID" "$APP_SRC"
  codesign --verify --deep --strict "$APP_SRC" && ok "signature verifies (strict)"
  info "the .dmg still holds the unsigned build; install the .app (this script does) for the signed copy"
fi

step "5 / 6  Verify the bundle"
APP_BIN="$APP_SRC/Contents/MacOS"
for b in ffmpeg ffprobe whisper-cli yusafcut-capture; do
  [[ -f "$APP_BIN/$b" ]] || die "bundle is missing sidecar $b"
done
[[ "$(stat -f%z "$APP_BIN/yusafcut-capture")" -gt 100000 ]] || die "bundled capture helper is the stub."
codesign --verify --deep "$APP_SRC" >/dev/null 2>&1 && ok "code signature verifies" || info "bundle is not signed or fails verification (fine for local use; notarize for distribution)"
ok "all sidecars bundled; real capture helper included"

step "6 / 6  Install"
if [[ $INSTALL -eq 1 ]]; then
  DEST="/Applications/WordsCut.app"
  if [[ -d "$DEST" ]]; then
    # One rollback copy, outside Spotlight's app results (not on the Desktop).
    BK_DIR="$HOME/Library/Caches/WordsCut-install-backup"
    rm -rf "$BK_DIR"; mkdir -p "$BK_DIR"
    mv "$DEST" "$BK_DIR/WordsCut.app"
    info "previous install kept for rollback at $BK_DIR/WordsCut.app"
  fi
  ditto "$APP_SRC" "$DEST"
  xattr -dr com.apple.quarantine "$DEST" 2>/dev/null || true
  ok "installed $DEST"
  # The build-output .app is a duplicate that Spotlight lists as a second app.
  rm -rf "$APP_SRC"
  open "$DEST"
else
  info "skipped (--no-install). Open the app at: $APP_SRC"
fi

echo -e "\n${G}${B}Done in $(( $(date +%s) - START ))s.${N}"
echo "On first recording macOS asks for Screen Recording / Camera / Microphone."
echo "Grant them, then quit and reopen the app if macOS says a restart is needed."
