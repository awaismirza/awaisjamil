#!/usr/bin/env node
/**
 * scripts/benchmark-media-pipeline.mjs
 *
 * Reproducible Apple Silicon ARM64 media pipeline benchmark for WordsCut.
 * Exercises the native arm64 FFmpeg/FFprobe binaries across WordsCut's 7 core
 * media pipeline stages:
 *
 *   1. ffprobe_metadata      - JSON stream/format probe on synthetic recording
 *   2. audio_extract_16k_wav - 16 kHz mono PCM WAV extraction (Whisper input)
 *   3. preview_proxy_720p    - 720p H.264 ultrafast preview proxy generation
 *   4. waveform_pcm_8k       - 8 kHz mono s16le PTS-aligned PCM waveform decode
 *   5. export_vt_h264        - H.264 VideoToolbox hardware encode (no effects)
 *   6. export_libx264        - H.264 libx264 software encode (no effects)
 *   7. export_effects_ass    - Full filtergraph: gradient background + scale/pad +
 *                              crop/zoom + rounded corner mask + libass vector cursor
 *                              overlay + VideoToolbox H.264 + AAC audio
 *
 * Usage:
 *   node scripts/benchmark-media-pipeline.mjs [options]
 *
 * Options:
 *   --ffmpeg <path>    Path to native arm64 ffmpeg (default: src-tauri/binaries/ffmpeg-aarch64-apple-darwin)
 *   --ffprobe <path>   Path to native arm64 ffprobe (default: src-tauri/binaries/ffprobe-aarch64-apple-darwin)
 *   --duration <sec>   Synthetic fixture duration in seconds (default: 5)
 *   --warmup <n>       Warmup iterations per stage (default: 1)
 *   --runs <n>         Measured iterations per stage (default: 3)
 *   --json <path>      Write machine-readable JSON results to <path>
 */

import { spawnSync } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const REPO_ROOT = path.resolve(__dirname, "..");

function parseArgs(argv) {
  const opts = {
    ffmpeg: path.join(REPO_ROOT, "src-tauri/binaries/ffmpeg-aarch64-apple-darwin"),
    ffprobe: path.join(REPO_ROOT, "src-tauri/binaries/ffprobe-aarch64-apple-darwin"),
    duration: 5,
    warmup: 1,
    runs: 3,
    jsonOut: null,
  };

  for (let i = 2; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === "--ffmpeg") opts.ffmpeg = argv[++i];
    else if (arg === "--ffprobe") opts.ffprobe = argv[++i];
    else if (arg === "--duration") opts.duration = Number(argv[++i]);
    else if (arg === "--warmup") opts.warmup = Number(argv[++i]);
    else if (arg === "--runs") opts.runs = Number(argv[++i]);
    else if (arg === "--json") opts.jsonOut = argv[++i];
    else if (arg === "-h" || arg === "--help") {
      console.log(
        "Usage: node scripts/benchmark-media-pipeline.mjs [--ffmpeg <p>] [--ffprobe <p>] [--duration 5] [--warmup 1] [--runs 3] [--json <out.json>]"
      );
      process.exit(0);
    } else {
      throw new Error(`Unknown option: ${arg}`);
    }
  }
  return opts;
}

function sh(cmd, args) {
  const res = spawnSync(cmd, args, { encoding: "utf8" });
  return (res.stdout || "").trim();
}

function getBinaryMeta(binPath) {
  if (!binPath || !fs.existsSync(binPath)) {
    throw new Error(`Binary not found: ${binPath}`);
  }
  const archs = sh("lipo", ["-archs", binPath]);
  const fileOut = sh("file", ["-b", binPath]);
  if (archs !== "arm64") {
    throw new Error(
      `Refusing non-arm64 binary at ${binPath}: lipo reported '${archs}' (${fileOut}). WordsCut supports Apple Silicon arm64 only.`
    );
  }
  const stat = fs.statSync(binPath);
  const verLine = sh(binPath, ["-version"]).split("\n")[0] || "";
  return {
    path: binPath,
    archs,
    fileDescription: fileOut,
    sizeBytes: stat.size,
    versionHeader: verLine,
  };
}

/**
 * Run a command natively under `arch -arm64` and `/usr/bin/time -l` (at nice -n 10)
 * to measure wall time and peak resident set size.
 */
function runTimed(bin, args) {
  const startNs = process.hrtime.bigint();
  const res = spawnSync(
    "/usr/bin/nice",
    ["-n", "10", "/usr/bin/time", "-l", "arch", "-arm64", bin, ...args],
    {
      encoding: "utf8",
      maxBuffer: 32 * 1024 * 1024,
    }
  );
  const endNs = process.hrtime.bigint();
  const wallMs = Number(endNs - startNs) / 1e6;

  if (res.status !== 0) {
    throw new Error(
      `Command failed (exit ${res.status}): ${bin} ${args.join(" ")}\n${res.stderr || ""}`
    );
  }

  const stderr = res.stderr || "";
  const rssMatch = stderr.match(/(\d+)\s+maximum resident set size/);
  const maxRssBytes = rssMatch ? Number(rssMatch[1]) : null;

  return {
    wallMs,
    maxRssBytes,
    stdout: res.stdout || "",
  };
}

function computeStats(samplesMs, rssSamplesBytes) {
  const sorted = [...samplesMs].sort((a, b) => a - b);
  const n = sorted.length;
  const medianMs =
    n % 2 === 1 ? sorted[(n - 1) / 2] : (sorted[n / 2 - 1] + sorted[n / 2]) / 2;
  const meanMs = sorted.reduce((acc, v) => acc + v, 0) / n;
  const minMs = sorted[0];
  const maxMs = sorted[n - 1];
  const spreadMs = maxMs - minMs;

  const validRss = rssSamplesBytes.filter((x) => typeof x === "number" && x > 0);
  const sortedRss = [...validRss].sort((a, b) => a - b);
  const medianRssBytes =
    sortedRss.length > 0 ? sortedRss[Math.floor(sortedRss.length / 2)] : null;

  return {
    runs: n,
    samplesMs: samplesMs.map((v) => Number(v.toFixed(2))),
    medianMs: Number(medianMs.toFixed(2)),
    meanMs: Number(meanMs.toFixed(2)),
    minMs: Number(minMs.toFixed(2)),
    maxMs: Number(maxMs.toFixed(2)),
    spreadMs: Number(spreadMs.toFixed(2)),
    medianMaxRssMB: medianRssBytes ? Number((medianRssBytes / (1024 * 1024)).toFixed(2)) : null,
  };
}

function writeAssFixture(assPath, durationSec) {
  const endCentis = Math.floor(durationSec * 100);
  const secs = String(Math.floor(endCentis / 100)).padStart(2, "0");
  const cs = String(endCentis % 100).padStart(2, "0");
  const assContent = `[Script Info]
ScriptType: v4.00+
PlayResX: 1920
PlayResY: 1080
WrapStyle: 0
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Cursor,Arial,20,&H00FFFFFF,&H000000FF,&H00000000,&H64000000,0,0,0,0,100,100,0,0,1,1.5,1,7,0,0,0,1
Style: Ring,Arial,20,&H6400A5FF,&H000000FF,&H0000A5FF,&H00000000,0,0,0,0,100,100,0,0,1,2,0,7,0,0,0,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
Dialogue: 1,0:00:00.00,0:00:${secs}.${cs},Cursor,,0,0,0,,{\\an7\\move(240,200,1680,880)\\p1}m 0 0 l 0 26 l 7 20 l 13 31 l 17 29 l 11 18 l 20 18 z{\\p0}
Dialogue: 0,0:00:00.50,0:00:01.20,Ring,,0,0,0,,{\\an7\\pos(600,400)\\p1}m -24 0 b -24 -13 -13 -24 0 -24 b 13 -24 24 -13 24 0 b 24 13 13 24 0 24 b -24 13 -24 0{\\p0}
`;
  fs.writeFileSync(assPath, assContent, "utf8");
}

function buildStages(fixtureMp4, assPath, durationSec) {
  const escapedAss = assPath.replace(/\\/g, "\\\\").replace(/:/g, "\\:");
  return [
    {
      id: "ffprobe_metadata",
      description: "FFprobe JSON metadata + stream inspection",
      tool: "ffprobe",
      makeArgs: () => [
        "-v",
        "quiet",
        "-print_format",
        "json",
        "-show_format",
        "-show_streams",
        fixtureMp4,
      ],
      validateOutput: ({ stdout }) => {
        const parsed = JSON.parse(stdout);
        if (!Array.isArray(parsed.streams) || parsed.streams.length < 2) {
          throw new Error("Expected >= 2 streams in ffprobe JSON output");
        }
      },
    },
    {
      id: "audio_extract_16k_wav",
      description: "Audio extraction to 16 kHz mono PCM WAV (transcription input)",
      tool: "ffmpeg",
      makeArgs: (outFile) => [
        "-y",
        "-v",
        "error",
        "-i",
        fixtureMp4,
        "-vn",
        "-acodec",
        "pcm_s16le",
        "-ar",
        "16000",
        "-ac",
        "1",
        outFile,
      ],
      ext: ".wav",
    },
    {
      id: "preview_proxy_720p",
      description: "Preview proxy 720p30 (libx264 ultrafast + AAC)",
      tool: "ffmpeg",
      makeArgs: (outFile) => [
        "-y",
        "-v",
        "error",
        "-i",
        fixtureMp4,
        "-vf",
        "scale=1280:720:flags=bilinear,fps=30,format=yuv420p",
        "-c:v",
        "libx264",
        "-preset",
        "ultrafast",
        "-crf",
        "26",
        "-c:a",
        "aac",
        "-b:a",
        "128k",
        "-movflags",
        "+faststart",
        outFile,
      ],
      ext: ".mp4",
    },
    {
      id: "waveform_pcm_8k",
      description: "Waveform 8 kHz mono s16le PTS-aligned PCM decode (preview_cache.rs)",
      tool: "ffmpeg",
      makeArgs: (outFile) => [
        "-y",
        "-nostdin",
        "-v",
        "error",
        "-threads",
        "2",
        "-filter_threads",
        "1",
        "-i",
        fixtureMp4,
        "-map",
        "0:a:0",
        "-vn",
        "-ac",
        "1",
        "-af",
        "aresample=8000:first_pts=0",
        "-ar",
        "8000",
        "-f",
        "s16le",
        outFile,
      ],
      ext: ".s16le",
    },
    {
      id: "export_vt_h264",
      description: "Direct 1080p30 export (h264_videotoolbox hardware encode)",
      tool: "ffmpeg",
      makeArgs: (outFile) => [
        "-y",
        "-v",
        "error",
        "-i",
        fixtureMp4,
        "-c:v",
        "h264_videotoolbox",
        "-b:v",
        "8M",
        "-allow_sw",
        "1",
        "-pix_fmt",
        "yuv420p",
        "-c:a",
        "aac",
        "-b:a",
        "192k",
        "-movflags",
        "+faststart",
        outFile,
      ],
      ext: ".mp4",
    },
    {
      id: "export_libx264",
      description: "Direct 1080p30 export (libx264 preset veryfast software encode)",
      tool: "ffmpeg",
      makeArgs: (outFile) => [
        "-y",
        "-v",
        "error",
        "-i",
        fixtureMp4,
        "-c:v",
        "libx264",
        "-preset",
        "veryfast",
        "-crf",
        "20",
        "-pix_fmt",
        "yuv420p",
        "-c:a",
        "aac",
        "-b:a",
        "192k",
        "-movflags",
        "+faststart",
        outFile,
      ],
      ext: ".mp4",
    },
    {
      id: "export_effects_ass",
      description:
        "Full export filtergraph (background + zoom/crop + rounded alpha mask + libass vector cursor + h264_videotoolbox)",
      tool: "ffmpeg",
      makeArgs: (outFile) => [
        "-y",
        "-v",
        "error",
        "-f",
        "lavfi",
        "-i",
        `gradients=s=1920x1080:r=30:d=${durationSec}:c0=0x1e293b:c1=0x0f172a`,
        "-i",
        fixtureMp4,
        "-filter_complex",
        `[1:v]fps=30,scale=2112:1188:flags=lanczos,crop=1920:1080:96:54,ass='${escapedAss}',scale=1680:945:flags=lanczos,format=rgba,geq=r='r(X,Y)':g='g(X,Y)':b='b(X,Y)':a='if(gt(abs(W/2-X),W/2-20)*gt(abs(H/2-Y),H/2-20),if(lte(hypot(abs(W/2-X)-(W/2-20),abs(H/2-Y)-(H/2-20)),20),255,0),255)'[fg];[0:v][fg]overlay=(W-w)/2:(H-h)/2:shortest=1,format=yuv420p[v]`,
        "-map",
        "[v]",
        "-map",
        "1:a",
        "-c:v",
        "h264_videotoolbox",
        "-b:v",
        "8M",
        "-allow_sw",
        "1",
        "-c:a",
        "aac",
        "-b:a",
        "192k",
        "-movflags",
        "+faststart",
        outFile,
      ],
      ext: ".mp4",
    },
  ];
}

function main() {
  if (os.platform() !== "darwin" || os.arch() !== "arm64") {
    throw new Error("WordsCut media pipeline benchmark supports Apple Silicon (darwin/arm64) only.");
  }

  const opts = parseArgs(process.argv);
  const workDir = fs.mkdtempSync(path.join(os.tmpdir(), "yusafcut-bench-"));

  try {
    const meta = {
      ffmpeg: getBinaryMeta(opts.ffmpeg),
      ffprobe: getBinaryMeta(opts.ffprobe),
    };

    const fixtureMp4 = path.join(workDir, "fixture-1080p30.mp4");
    const assPath = path.join(workDir, "cursor.ass");
    writeAssFixture(assPath, opts.duration);

    console.log(
      `Generating deterministic ${opts.duration}s 1080p30 synthetic input fixture...`
    );
    runTimed(opts.ffmpeg, [
      "-y",
      "-v",
      "error",
      "-f",
      "lavfi",
      "-i",
      `testsrc2=size=1920x1080:rate=30:duration=${opts.duration}`,
      "-f",
      "lavfi",
      "-i",
      `sine=frequency=440:sample_rate=48000:duration=${opts.duration}`,
      "-c:v",
      "libx264",
      "-preset",
      "ultrafast",
      "-crf",
      "22",
      "-pix_fmt",
      "yuv420p",
      "-c:a",
      "aac",
      "-b:a",
      "128k",
      fixtureMp4,
    ]);

    const stages = buildStages(fixtureMp4, assPath, opts.duration);

    console.log(
      `Running native Apple Silicon (${meta.ffmpeg.archs}) benchmark (${opts.warmup} warmup + ${opts.runs} measured runs)...`
    );

    const stageResults = {};
    console.log("\n=== WordsCut Native ARM64 Media Pipeline Benchmark ===");
    for (const stage of stages) {
      const bin = stage.tool === "ffprobe" ? opts.ffprobe : opts.ffmpeg;
      const samplesMs = [];
      const rssSamples = [];

      const totalIters = opts.warmup + opts.runs;
      for (let iter = 0; iter < totalIters; iter++) {
        const outFile = stage.ext
          ? path.join(workDir, `${stage.id}-${iter}${stage.ext}`)
          : null;
        const args = stage.makeArgs(outFile);
        const timed = runTimed(bin, args);

        if (stage.validateOutput) {
          stage.validateOutput(timed);
        }
        if (outFile) {
          if (!fs.existsSync(outFile) || fs.statSync(outFile).size < 256) {
            throw new Error(`Stage ${stage.id} produced empty or missing output: ${outFile}`);
          }
          fs.unlinkSync(outFile);
        }

        if (iter >= opts.warmup) {
          samplesMs.push(timed.wallMs);
          rssSamples.push(timed.maxRssBytes);
        }
      }

      const stats = computeStats(samplesMs, rssSamples);
      stageResults[stage.id] = {
        description: stage.description,
        ...stats,
      };
      console.log(
        `  ${stage.id.padEnd(24)} | median: ${String(stats.medianMs).padStart(7)} ms (±${String(stats.spreadMs).padStart(6)} ms) | peak RSS: ${stats.medianMaxRssMB} MB`
      );
    }

    const report = {
      timestampUtc: new Date().toISOString(),
      environment: {
        platform: os.platform(),
        arch: os.arch(),
        release: os.release(),
        cpuModel: os.cpus()[0]?.model || "unknown",
        cpuCores: os.cpus().length,
        totalMemoryGB: Number((os.totalmem() / (1024 ** 3)).toFixed(1)),
      },
      config: {
        fixtureResolution: "1920x1080",
        fixtureFps: 30,
        fixtureDurationSec: opts.duration,
        warmupRuns: opts.warmup,
        measuredRuns: opts.runs,
      },
      binaries: meta,
      stages: stageResults,
    };

    if (opts.jsonOut) {
      fs.mkdirSync(path.dirname(path.resolve(opts.jsonOut)), { recursive: true });
      fs.writeFileSync(opts.jsonOut, JSON.stringify(report, null, 2), "utf8");
      console.log(`\nWrote JSON benchmark report to: ${opts.jsonOut}`);
    }
  } finally {
    fs.rmSync(workDir, { recursive: true, force: true });
  }
}

main();
