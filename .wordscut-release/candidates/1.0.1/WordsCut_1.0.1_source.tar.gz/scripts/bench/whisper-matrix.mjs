#!/usr/bin/env node
// WP-2B: whisper-cli backend/threads/flash-attn matrix on `say`-generated speech fixtures.
//
//   node scripts/bench/whisper-matrix.mjs [--models large-v3-turbo,tiny] [--threads 4,perf]
//        [--fa off,on] [--backends coreml-metal,coreml-cpu-decoder,metal-only,cpu]
//        [--reps 3] [--fixture-seconds 40] [--models-dir <dir>] [--out docs/benchmarks/whisper-<date>.json]
//        [--fixture <16k-mono.wav>] [--scratch <dir>] [--dry-run]
//
// Backends (what the binary can actually do is PROBED, never assumed):
//   coreml-metal        encoder .mlmodelc present, Metal decoder (production default)
//   coreml-cpu-decoder  encoder .mlmodelc present, `-ng` (decoder on CPU; Core ML still used)
//   metal-only          model symlinked into a dir WITHOUT the -encoder.mlmodelc
//   cpu                 same dir, plus `-ng`
// A backend that fails at context init is recorded as `blocked` with the stderr markers.
//
// "cold" is only an approximation: rep 1 of each config is called cold, reps 2..N warm. We do
// not purge the page cache or the Core ML/ANE compile cache (needs sudo / is system state), so
// rep 1 is "first invocation in this process"; a true cold start needs [O] (reboot or `sudo purge`).
// Models that are not on disk are skipped and recorded; nothing is ever downloaded.
import { spawnSync } from "node:child_process";
import crypto from "node:crypto";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { captureEnv, median, REPO_ROOT, FFMPEG } from "./lib/env.mjs";
import { compareWords, loadWords } from "./compare-words.mjs";

const arg = (name, def) => {
  const i = process.argv.indexOf(`--${name}`);
  return i >= 0 ? process.argv[i + 1] : def;
};
const flag = (name) => process.argv.includes(`--${name}`);
const list = (s) => s.split(",").map((x) => x.trim()).filter(Boolean);

const WHISPER = path.join(REPO_ROOT, "src-tauri", "binaries", "whisper-cli-aarch64-apple-darwin");
const MODELS_DIR =
  arg("models-dir") ??
  process.env.YUSAFCUT_MODELS_DIR ??
  path.join(os.homedir(), "Library", "Application Support", "dev.yusafcut.app", "models");
const date = new Date().toISOString().slice(0, 10);
const OUT = path.resolve(REPO_ROOT, arg("out", `docs/benchmarks/whisper-${date}.json`));
const SCRATCH = arg("scratch") ?? fs.mkdtempSync(path.join(os.tmpdir(), "whisper-matrix-"));
const REPS = Number(arg("reps", "3"));
const FIXTURE_SECONDS = Number(arg("fixture-seconds", "40"));
const PERF = Number(
  spawnSync("sysctl", ["-n", "hw.perflevel0.physicalcpu"], { encoding: "utf8" }).stdout.trim(),
);
const THREADS = list(arg("threads", "4,perf")).map((t) => (t === "perf" ? PERF : Number(t)));
const FA = list(arg("fa", "off,on"));
const MODELS = list(arg("models", "tiny,large-v3-turbo"));
const BACKENDS = list(arg("backends", "coreml-metal,coreml-cpu-decoder,metal-only,cpu"));

// Same preset names as src-tauri/src/commands/transcribe.rs (dot-form).
const DTW = { tiny: "tiny", "tiny.en": "tiny.en", "large-v3-turbo": "large.v3.turbo", "large-v3": "large.v3" };
const BACKEND_DEFS = {
  "coreml-metal": { ng: false, encoder: true },
  "coreml-cpu-decoder": { ng: true, encoder: true },
  "metal-only": { ng: false, encoder: false },
  cpu: { ng: true, encoder: false },
};
const MARKER_RE =
  /Core ML model loaded|failed to load Core ML|using Metal backend|using BLAS backend|use gpu\s+=|flash attn\s+=|dtw\s+=|not supported with flash_attn|failed to initialize whisper context|loading Core ML model/;

const SENTENCES = [
  "The quick brown fox jumps over the lazy dog.",
  "Editing a transcript edits the video, and every word has a start and an end time.",
  "We measure encode time, decode time and peak memory on Apple silicon.",
  "Um, so, you know, the second take was better than the first one.",
  "Please cut the pause after this sentence, then keep going with the next idea.",
  "Numbers like forty two, one hundred and seven, and twenty twenty six appear here.",
  "The model loads once, the encoder runs on the neural engine, and the decoder runs on the GPU.",
  "Short words and long words make the timing alignment harder to get exactly right.",
];

const log = (...a) => console.error("[whisper-matrix]", ...a);

function makeFixture(seconds) {
  const own = arg("fixture");
  if (own) return path.resolve(own); // owner clip: must already be 16 kHz mono 16-bit wav
  const wav = path.join(SCRATCH, `fixture-${seconds}s.wav`);
  if (fs.existsSync(wav)) return wav;
  const text = [];
  // Repeat sentences until we clearly exceed the target; trim afterwards with -t.
  for (let i = 0; i < 40; i++) text.push(SENTENCES[i % SENTENCES.length]);
  const aiff = path.join(SCRATCH, "fixture.aiff");
  const r = spawnSync("say", ["-o", aiff, text.join(" ")], { encoding: "utf8" });
  if (r.status !== 0) throw new Error(`say failed: ${r.stderr}`);
  const f = spawnSync(
    FFMPEG,
    ["-loglevel", "error", "-y", "-i", aiff, "-t", String(seconds), "-ar", "16000", "-ac", "1", "-c:a", "pcm_s16le", wav],
    { encoding: "utf8" },
  );
  if (f.status !== 0) throw new Error(`ffmpeg failed: ${f.stderr}`);
  return wav;
}
const wavSeconds = (wav) => (fs.statSync(wav).size - 44) / 32000;

function parseRun(stderr) {
  const t = {};
  for (const m of stderr.matchAll(/whisper_print_timings:\s+(\w+) time =\s+([\d.]+) ms/g)) t[m[1]] = Number(m[2]);
  const rss = stderr.match(/(\d+)\s+maximum resident set size/);
  const peak = stderr.match(/(\d+)\s+peak memory footprint/);
  const real = stderr.match(/([\d.]+)\s+real/);
  return {
    timingsMs: t,
    // `decode time` is 0 when the beam-search path is used; the work is in batchd + prompt + sample.
    decodeWorkMs: ["decode", "batchd", "prompt"].reduce((s, k) => s + (t[k] ?? 0), 0),
    maxRssBytes: rss ? Number(rss[1]) : null,
    peakFootprintBytes: peak ? Number(peak[1]) : null,
    wallMs: real ? Number(real[1]) * 1000 : null,
    markers: stderr.split("\n").filter((l) => MARKER_RE.test(l)).map((l) => l.replace(/'[^']*'/g, "'<path>'").trim()),
  };
}

function runOnce({ modelPath, wav, threads, ng, fa, dtw, jsonBase }) {
  const args = [
    "-l", "en", "-t", String(threads), "-m", modelPath, "-f", wav,
    "-sow", "-ml", "0", "-bo", "5", "-bs", "5", "-wt", "0.01", "-ojf", "-of", jsonBase,
  ];
  if (dtw) args.push("--dtw", dtw);
  if (ng) args.push("-ng");
  if (fa) args.push("-fa");
  const t0 = process.hrtime.bigint();
  const r = spawnSync("/usr/bin/time", ["-l", WHISPER, ...args], { encoding: "utf8", maxBuffer: 1 << 28, timeout: 15 * 60_000 });
  const hrWallMs = Number(process.hrtime.bigint() - t0) / 1e6;
  return { exit: r.status, argv: args.map((a) => (a === modelPath ? "<model>" : a === wav ? "<wav>" : a === jsonBase ? "<out>" : a)), hrWallMs, ...parseRun(r.stderr ?? "") };
}

function modelVariant(modelName, withEncoder) {
  const src = path.join(MODELS_DIR, `ggml-${modelName}.bin`);
  if (!fs.existsSync(src)) return null;
  const hasEncoder = fs.existsSync(path.join(MODELS_DIR, `ggml-${modelName}-encoder.mlmodelc`));
  if (withEncoder) return hasEncoder ? { modelPath: src, hasEncoder } : { modelPath: src, hasEncoder, noEncoderOnDisk: true };
  const dir = path.join(SCRATCH, `noenc-${modelName}`);
  fs.mkdirSync(dir, { recursive: true });
  const link = path.join(dir, `ggml-${modelName}.bin`);
  if (!fs.existsSync(link)) fs.symlinkSync(src, link);
  return { modelPath: link, hasEncoder: false };
}

const sha256 = (f) => crypto.createHash("sha256").update(fs.readFileSync(f)).digest("hex");

async function main() {
  if (!fs.existsSync(WHISPER)) throw new Error(`missing ${WHISPER}`);
  fs.mkdirSync(path.dirname(OUT), { recursive: true });
  const wav = makeFixture(FIXTURE_SECONDS);
  const audioSeconds = wavSeconds(wav);
  const env = captureEnv({ buildMode: "bundled whisper-cli sidecar (release binary)", notes: "cold = first invocation in this run, not a purged cache" });
  const result = {
    schema: 1,
    date,
    env,
    binary: { path: "src-tauri/binaries/whisper-cli-aarch64-apple-darwin", sha256: sha256(WHISPER), bytes: fs.statSync(WHISPER).size },
    fixture: { kind: arg("fixture") ? "owner-supplied wav" : "say (default voice) -> 16 kHz mono wav", seconds: Math.round(audioSeconds * 10) / 10, sentences: SENTENCES.length },
    threadsTried: THREADS,
    perfCores: PERF,
    reps: REPS,
    coldDefinition: "rep 1 of each config; page cache and Core ML compile cache NOT purged (needs sudo/reboot) -> approximation",
    models: {},
    configs: [],
    probes: [],
    comparisons: [],
    summary: {},
  };
  log(`fixture ${result.fixture.seconds}s, threads ${THREADS}, models ${MODELS}, scratch ${SCRATCH}`);

  const present = [];
  for (const m of MODELS) {
    const v = modelVariant(m, true);
    if (!v) {
      result.models[m] = { present: false, note: `ggml-${m}.bin not found in ${MODELS_DIR}; not downloaded` };
      continue;
    }
    result.models[m] = { present: true, modelBytes: fs.statSync(v.modelPath).size, encoderMlmodelc: v.hasEncoder };
    present.push(m);
  }
  if (flag("dry-run")) {
    console.log(JSON.stringify({ wouldRun: { present, threads: THREADS, fa: FA, backends: BACKENDS, reps: REPS }, models: result.models }, null, 2));
    return;
  }

  const jsonDir = path.join(SCRATCH, "json");
  fs.mkdirSync(jsonDir, { recursive: true });
  for (const m of present) {
    for (const b of BACKENDS) {
      const def = BACKEND_DEFS[b];
      const v = modelVariant(m, def.encoder);
      if (def.encoder && v.noEncoderOnDisk) {
        result.probes.push({ model: m, backend: b, status: "blocked", reason: "encoder .mlmodelc not on disk" });
        continue;
      }
      // Probe (init succeeds?) with the smallest config; keep its outcome for the doc.
      const probe = runOnce({ modelPath: v.modelPath, wav, threads: THREADS[0], ng: def.ng, fa: false, dtw: DTW[m], jsonBase: path.join(jsonDir, `probe-${m}-${b}`) });
      const ok = probe.exit === 0;
      result.probes.push({ model: m, backend: b, status: ok ? "ok" : "blocked", exit: probe.exit, markers: probe.markers });
      if (!ok) { log(`${m}/${b}: BLOCKED (exit ${probe.exit})`); continue; }
      for (const threads of THREADS) {
        for (const faMode of FA) {
          const id = `${m}.${b}.t${threads}.fa-${faMode}`;
          const jsonBase = path.join(jsonDir, id);
          const runs = [];
          for (let rep = 1; rep <= REPS; rep++) {
            const r = runOnce({ modelPath: v.modelPath, wav, threads, ng: def.ng, fa: faMode === "on", dtw: DTW[m], jsonBase });
            runs.push({ rep, phase: rep === 1 ? "cold-approx" : "warm", ...r });
            log(`${id} rep${rep} exit=${r.exit} total=${r.timingsMs.total ?? "?"}ms rss=${r.maxRssBytes}`);
          }
          const warm = runs.filter((r) => r.phase === "warm" && r.exit === 0);
          const med = (k) => median(warm.map((r) => r.timingsMs[k]).filter((x) => x != null));
          result.configs.push({
            id, model: m, backend: b, threads, flashAttn: faMode === "on",
            dtwActive: !runs[0].markers.some((l) => /dtw\s+=\s+0/.test(l)),
            warmMedianMs: { load: med("load"), mel: med("mel"), encode: med("encode"), decodeWork: median(warm.map((r) => r.decodeWorkMs)), total: med("total"), wall: median(warm.map((r) => r.wallMs)) },
            coldApproxMs: { load: runs[0].timingsMs.load ?? null, encode: runs[0].timingsMs.encode ?? null, total: runs[0].timingsMs.total ?? null, wall: runs[0].wallMs },
            maxRssBytes: Math.max(...runs.map((r) => r.maxRssBytes ?? 0)),
            peakFootprintBytes: Math.max(...runs.map((r) => r.peakFootprintBytes ?? 0)),
            realTimeFactorWarm: med("total") ? Math.round((audioSeconds / (med("total") / 1000)) * 100) / 100 : null,
            runs,
          });
        }
      }
    }
  }

  // Word-timing deltas vs the production default per model (coreml-metal, 4 threads, fa off).
  for (const m of present) {
    const base = result.configs.find((c) => c.model === m && c.backend === "coreml-metal" && c.threads === THREADS[0] && !c.flashAttn);
    if (!base) continue;
    const baseWords = loadWords(path.join(jsonDir, `${base.id}.json`));
    for (const c of result.configs.filter((x) => x.model === m && x.id !== base.id)) {
      const f = path.join(jsonDir, `${c.id}.json`);
      if (!fs.existsSync(f)) continue;
      result.comparisons.push({ model: m, baseline: base.id, other: c.id, ...compareWords(baseWords, loadWords(f), { limitMs: 20 }) });
    }
  }

  // Persistent-model verdict inputs (measured, per config): what a resident model could save per job.
  const prod = result.configs.filter((c) => c.backend === "coreml-metal" && c.threads === THREADS[0] && !c.flashAttn);
  result.summary.persistentModelReuse = prod.map((c) => ({
    model: c.model,
    fixtureSeconds: result.fixture.seconds,
    warmLoadMs: c.warmMedianMs.load,
    warmTotalMs: c.warmMedianMs.total,
    loadShareOfTotal: c.warmMedianMs.total ? Math.round((c.warmMedianMs.load / c.warmMedianMs.total) * 1000) / 1000 : null,
    coldApproxLoadMs: c.coldApproxMs.load,
    coldApproxTotalMs: c.coldApproxMs.total,
    residentRssBytes: c.maxRssBytes,
    peakFootprintBytes: c.peakFootprintBytes,
  }));
  result.limits = [
    "cold is an approximation (no cache purge); a true cold/first-ever Core ML compile (~10 s observed in the roadmap) needs [O].",
    "say fixtures are synthetic TTS: no noise, overlap or disfluency; word-timing deltas are lower-bound-ish for real speech.",
    "single machine, single thermal state, few reps; medians of warm reps only.",
    "backends that fail context init are recorded as blocked, not measured.",
  ];
  fs.writeFileSync(OUT, JSON.stringify(result, null, 2) + "\n");
  log(`wrote ${path.relative(REPO_ROOT, OUT)}`);
}

main().catch((e) => { console.error(e); process.exit(1); });
