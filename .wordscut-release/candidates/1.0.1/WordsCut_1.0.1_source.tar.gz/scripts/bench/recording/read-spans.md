# Reading production-path recording spans

Use this during a real recording to get Stop-to-editor numbers from the app itself (the synthetic
script in `synthetic-stop.mjs` is not production-path proof).

## Prerequisites

- A build whose `yusafcut-capture` is the real Swift helper (`npm run native:build`; the committed file
  is an exit-immediately stub that falls back to ffmpeg capture, which is a different path).
- Screen Recording, Camera and Microphone permissions granted to the app/binary being run. A human
  must grant these; they cannot be scripted.
- Close heavy apps; note the Mac model, macOS version and power state (plugged in, not Low Power).

## Run

```bash
YUSAFCUT_PERF_SPANS=1 npm run tauri:dev      # debug build: numbers are pessimistic
# or, for representative numbers:
npm run tauri:build && YUSAFCUT_PERF_SPANS=1 open -n src-tauri/target/release/bundle/macos/WordsCut.app
```

Open devtools (debug build: right-click -> Inspect, or Cmd+Option+I).

## Per take

1. Clear state: reload the window before each take so the span buffer and timeline start empty.
2. Record the configuration under test for the planned duration. Press Stop once. Do not touch the
   app until the editor shows the clip.
3. In the console, read the Rust spans:

   ```js
   await window.__TAURI_INTERNALS__.invoke("perf_spans_snapshot");
   ```

   Expected span names: `record.stop.command`, `record.stop_native.total`,
   `record.stop_native.helper_stop`, `record.stop_native.finalize_composite` or
   `record.stop_native.finalize_copy_mix`, `record.stop_native.probe`, `import.total`,
   `import.ffprobe`, `import.sha256`. If the list is empty, `YUSAFCUT_PERF_SPANS=1` was not in the
   app's environment (a Finder launch ignores your shell exports: use `open -n` with the variable as
   shown, or `launchctl setenv`).

4. Read the frontend stage marks. `latestRecordingTimeline()` lives in `src/lib/recordingTimeline.ts`
   and is a module export, not a global. In the dev server, import it in the console:

   ```js
   const m = await import("/src/lib/recordingTimeline.ts");
   console.table(m.latestRecordingTimeline());
   ```

   (A production build has no module path; if the helper is not exposed on `window`, temporarily log
   it from a local, uncommitted edit, and say so when reporting.) Marks: `stopRequested`,
   `finishedReceived`, `importStarted`, `importProbed`, `inserted`, `firstFrame`. Differences from
   `stopRequested` give Stop-to-inserted (A) and Stop-to-first-frame (B).

5. Record into the results table: take length, mode, file sizes, each span in ms, A and B, build type.

## What to compare

| Question | Numbers |
|---|---|
| Is the camera composite the dominant cost? | `finalize_composite` vs `import.total` vs the rest |
| Is hashing on the critical path? | `import.sha256` vs `import.ffprobe` (import waits for the slower) |
| Does cost scale with length? | Same config at 15 / 60 / 180 s |
| Synthetic vs real | Compare against `docs/benchmarks/recording-stop-*.json` for the same length |

Report medians of at least 3 takes per configuration, include the raw values, and state build type
(debug vs release), hardware, macOS version and the ffmpeg version.
