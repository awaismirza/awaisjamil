#!/usr/bin/env node
// SYNTHETIC recording-stop benchmark. Not production-path proof.
//
// Generates deterministic tracks with ffmpeg (no capture devices, no permissions) and times the
// Stop-to-editor stages that are plain child processes:
//   (a) sha256 of the screen file          (import_media hash)
//   (b) copy video + mix audio             (finalize_args, screen modes)
//   (c) camera composite re-encode         (finalize_args, screen+camera)
//   (d) ffprobe                            (import_media / captured_duration probe)
// The ffmpeg argv shapes MUST stay in sync with `finalize_args` and `pip_filter` in
// src-tauri/src/native_capture.rs and src-tauri/src/recorder.rs (defaults: pip Medium=0.25,
// BottomRight, margin 28). Real captures differ (content, codec, VFR timestamps): see
// docs/performance/recording-verification-plan.md.
//
// Usage: node scripts/bench/recording/synthetic-stop.mjs [--lengths 15,60,180] [--runs 3]
//        [--work <dir>] [--out <json>]
// Without --work the generated tracks go to a temp dir that is deleted afterwards.
import { spawnSync } from "node:child_process";
import { existsSync, mkdirSync, mkdtempSync, rmSync, statSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));
const root = resolve(here, "../../..");
const arg = (k, d) => {
  const i = process.argv.indexOf(`--${k}`);
  return i >= 0 ? process.argv[i + 1] : d;
};
const lengths = arg("lengths", "15,60,180").split(",").map(Number);
const runs = Number(arg("runs", "3"));
const date = new Date().toISOString().slice(0, 10);
const outPath = resolve(arg("out", join(root, `docs/benchmarks/recording-stop-${date}.json`)));
const userWork = arg("work", null);
const work = userWork ? resolve(userWork) : mkdtempSync(join(tmpdir(), "rec-bench-"));
mkdirSync(work, { recursive: true });

function findTool(name) {
  const rel = `src-tauri/binaries/${name}-aarch64-apple-darwin`;
  const cands = [
    join(root, rel),
    join("/Users/awaisjamil/code/projects/yusaf-cut", rel),
    // worktree layout: <main>/.claude/worktrees/<name>
    join(root, "../../..", rel),
  ];
  for (const c of cands) if (existsSync(c)) return resolve(c);
  const w = spawnSync("which", [name], { encoding: "utf8" });
  if (w.status === 0 && w.stdout.trim()) return w.stdout.trim();
  throw new Error(`${name} not found (looked in ${cands.join(", ")} and PATH)`);
}
const FFMPEG = findTool("ffmpeg");
const FFPROBE = findTool("ffprobe");

// /usr/bin/time -l wrapper: wall seconds + peak RSS bytes of the child.
function timed(cmd, args) {
  const t0 = process.hrtime.bigint();
  const r = spawnSync("/usr/bin/time", ["-l", cmd, ...args], { encoding: "utf8", maxBuffer: 1 << 28 });
  const wall = Number(process.hrtime.bigint() - t0) / 1e9;
  if (r.status !== 0) throw new Error(`${cmd} failed (${r.status}): ${r.stderr.slice(-800)}`);
  const m = /(\d+)\s+maximum resident set size/.exec(r.stderr);
  return { wallS: wall, peakRssBytes: m ? Number(m[1]) : null, stdout: r.stdout };
}
const ff = (args) => timed(FFMPEG, ["-y", "-hide_banner", "-loglevel", "error", ...args]);
const median = (xs) => [...xs].sort((a, b) => a - b)[Math.floor(xs.length / 2)];
const r3 = (n) => Math.round(n * 1000) / 1000;

function bench(fn) {
  const s = [];
  for (let i = 0; i < runs; i++) s.push(fn());
  return {
    runsS: s.map((x) => r3(x.wallS)),
    medianS: r3(median(s.map((x) => x.wallS))),
    peakRssMiB: r3(Math.max(...s.map((x) => x.peakRssBytes ?? 0)) / 1048576),
  };
}

// Streamed sha256 in 1 MiB chunks, run as a child so its peak RSS is measurable.
const hashScript =
  'const c=require("crypto"),f=require("fs");const h=c.createHash("sha256");const fd=f.openSync(process.argv[1],"r");const b=Buffer.allocUnsafe(1<<20);let n;while((n=f.readSync(fd,b,0,b.length,null))>0)h.update(b.subarray(0,n));console.log(h.digest("hex"))';

function sh(cmd, args) {
  const r = spawnSync(cmd, args, { encoding: "utf8" });
  return r.status === 0 ? r.stdout.trim() : null;
}
const hardware = {
  model: sh("sysctl", ["-n", "hw.model"]),
  chip: sh("sysctl", ["-n", "machdep.cpu.brand_string"]),
  cpuCores: Number(sh("sysctl", ["-n", "hw.ncpu"])),
  perfCores: Number(sh("sysctl", ["-n", "hw.perflevel0.physicalcpu"])) || null,
  memoryGiB: Math.round(Number(sh("sysctl", ["-n", "hw.memsize"])) / 2 ** 30),
};
const macos = `${sh("sw_vers", ["-productName"])} ${sh("sw_vers", ["-productVersion"])} (${sh("sw_vers", ["-buildVersion"])})`;
const ffmpegVersion = (spawnSync(FFMPEG, ["-version"], { encoding: "utf8" }).stdout || "").split("\n")[0];

// Mirrors pip_filter(): Medium 0.25, BottomRight, margin 28.
const PIP =
  "[1:v][0:v]scale=w='trunc(ref_w*0.25/2)*2':h='trunc(ref_w*0.25*ih/iw/2)*2'[cam];[0:v][cam]overlay=main_w-overlay_w-28:main_h-overlay_h-28:shortest=1";

function generate(len) {
  const dir = join(work, `take-${len}s`);
  mkdirSync(dir, { recursive: true });
  const t = String(len);
  const files = {
    screen: join(dir, "screen.mp4"),
    camera: join(dir, "camera.mp4"),
    mic: join(dir, "mic.m4a"),
    system: join(dir, "system.m4a"),
  };
  const marker = join(dir, ".done");
  if (existsSync(marker)) return files;
  const t0 = Date.now();
  // testsrc2 is deterministic and harder to scale than typical screen content.
  ff(["-f", "lavfi", "-i", `testsrc2=size=2560x1440:rate=30:duration=${t}`, "-c:v", "h264_videotoolbox", "-b:v", "12000k", "-pix_fmt", "yuv420p", "-movflags", "+faststart", files.screen]);
  ff(["-f", "lavfi", "-i", `smptebars=size=1280x720:rate=30:duration=${t}`, "-c:v", "h264_videotoolbox", "-b:v", "4000k", "-pix_fmt", "yuv420p", "-movflags", "+faststart", files.camera]);
  ff(["-f", "lavfi", "-i", `sine=frequency=440:sample_rate=48000:duration=${t}`, "-c:a", "aac", "-b:a", "128k", files.mic]);
  ff(["-f", "lavfi", "-i", `sine=frequency=880:sample_rate=48000:duration=${t}`, "-c:a", "aac", "-b:a", "128k", files.system]);
  writeFileSync(marker, "");
  console.error(`generated ${len}s take in ${((Date.now() - t0) / 1000).toFixed(1)}s`);
  return files;
}

const results = [];
for (const len of lengths) {
  const f = generate(len);
  const out = join(work, `final-${len}.mp4`);
  const entry = {
    takeSeconds: len,
    sizesMiB: Object.fromEntries(Object.entries(f).map(([k, p]) => [k, r3(statSync(p).size / 1048576)])),
  };
  let digest = "";
  entry.sha256Screen = bench(() => {
    const r = timed(process.execPath, ["-e", hashScript, f.screen]);
    digest = r.stdout.trim();
    return r;
  });
  entry.screenSha256 = digest;
  // finalize_args, screen mode: copy video, mix mic + system audio.
  entry.copyVideoMixAudio = bench(() =>
    ff(["-i", f.screen, "-i", f.mic, "-i", f.system,
      "-filter_complex", "[1:a][2:a]amix=inputs=2:duration=longest:dropout_transition=0,volume=2[outa]",
      "-map", "0:v", "-map", "[outa]", "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", out]),
  );
  // finalize_args, screen+camera: PiP composite re-encode with h264_videotoolbox 8000k.
  entry.cameraCompositeReencode = bench(() =>
    ff(["-i", f.screen, "-i", f.camera, "-i", f.mic, "-i", f.system,
      "-filter_complex", `${PIP}[outv];[2:a][3:a]amix=inputs=2:duration=longest:dropout_transition=0,volume=2[outa]`,
      "-map", "[outv]", "-map", "[outa]", "-c:v", "h264_videotoolbox", "-b:v", "8000k", "-pix_fmt", "yuv420p",
      "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", out]),
  );
  entry.ffprobeOfComposite = bench(() =>
    timed(FFPROBE, ["-v", "error", "-print_format", "json", "-show_format", "-show_streams", out]),
  );
  entry.compositeSecondsPerRecordedSecond = r3(entry.cameraCompositeReencode.medianS / len);
  results.push(entry);
  console.error(`${len}s done`);
}

const doc = {
  label: "synthetic: not production-path proof",
  note: "ffmpeg-generated tracks run through the argv shape of finalize_args; no capture helper, no real screen content, no app, no contention from a recording in progress.",
  date: new Date().toISOString(),
  hardware,
  macos,
  ffmpeg: { path: FFMPEG, version: ffmpegVersion },
  hashChild: "node streaming sha256 (the app uses Rust sha2, so absolute hash cost differs slightly)",
  runsPerStage: runs,
  results,
};
mkdirSync(dirname(outPath), { recursive: true });
writeFileSync(outPath, JSON.stringify(doc, null, 2) + "\n");
console.error(`wrote ${outPath}`);
if (!userWork) rmSync(work, { recursive: true, force: true });
