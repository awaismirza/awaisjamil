#!/usr/bin/env node
// Production-path export benchmark. The ffmpeg argv comes from the Rust example
// `export_argv`, which calls the real `build_reencode_argv` (and the real cursor
// ASS generator). Each argv is run under `/usr/bin/time -l` and the output is
// validated with ffprobe.
//
// usage: node scripts/bench/export-matrix.mjs [--reps 3] [--only 05,09] [--out path.json]
//        [--cache dir] [--skip-build] [--opts ExportOpts.json  (single real export, e.g. long media)]
import { spawnSync, execFileSync } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { captureEnv, median, thermalState, REPO_ROOT, FFMPEG, FFPROBE } from "./lib/env.mjs";

const args = process.argv.slice(2);
const flag = (n, d) => {
  const i = args.indexOf(`--${n}`);
  return i >= 0 ? args[i + 1] : d;
};
const REPS = Number(flag("reps", 3));
const ONLY = flag("only", "")?.split(",").filter(Boolean) ?? [];
const DATE = new Date().toISOString().slice(0, 10);
const OUT = flag("out", path.join(REPO_ROOT, "docs/benchmarks", `export-baseline-${DATE}.json`));
const CACHE = flag("cache", path.join(os.tmpdir(), "yusafcut-bench-export"));
const FIX_DIR = path.join(REPO_ROOT, "scripts/bench/fixtures/export");
const media = Object.fromEntries(Object.entries(JSON.parse(fs.readFileSync(path.join(FIX_DIR, "media.json"), "utf8"))).filter(([k]) => !k.startsWith("_")));
fs.mkdirSync(CACHE, { recursive: true });

const run = (cmd, a, o = {}) => {
  const r = spawnSync(cmd, a, { encoding: "utf8", maxBuffer: 1 << 28, ...o });
  if (r.status !== 0) throw new Error(`${cmd} ${a.slice(0, 6).join(" ")}… exited ${r.status}\n${(r.stderr || "").slice(-2000)}`);
  return r.stdout;
};
const ff = (a) => run(FFMPEG, ["-y", "-hide_banner", "-loglevel", "error", ...a]);

// ---- fixtures -------------------------------------------------------------
function makeFixtures() {
  const P = (k) => path.join(CACHE, media[k].file);
  const aud = (d = 10) => ["-f", "lavfi", "-i", `sine=frequency=440:sample_rate=48000:duration=${d}`];
  const venc = ["-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "128k"];
  const screenSrc = ["-f", "lavfi", "-i", "testsrc2=size=1920x1080:rate=30:duration=10"];
  if (!fs.existsSync(P("screen"))) ff([...screenSrc, ...aud(), ...venc, "-shortest", P("screen")]);
  if (!fs.existsSync(P("screen_vfr")))
    ff([...screenSrc, ...aud(), "-vf", "select='lt(mod(n,9),3)+gt(mod(n,100),80)'", ...venc, "-fps_mode", "vfr", "-video_track_timescale", "30000", "-shortest", P("screen_vfr")]);
  if (!fs.existsSync(P("screen_delayed_audio")))
    ff([...screenSrc, "-itsoffset", "0.5", ...aud(9.5), ...venc, "-map", "0:v", "-map", "1:a", P("screen_delayed_audio")]);
  if (!fs.existsSync(P("camera")))
    ff(["-f", "lavfi", "-i", "testsrc=size=1280x720:rate=25:duration=10", ...aud(), ...venc, "-shortest", P("camera")]);
  return Object.fromEntries(Object.keys(media).map((k) => [k, P(k)]));
}

const probe = (file) =>
  JSON.parse(run(FFPROBE, ["-v", "error", "-count_frames", "-show_format", "-show_streams", "-of", "json", file]));
function summary(file) {
  const j = probe(file);
  const v = j.streams.find((s) => s.codec_type === "video");
  const a = j.streams.find((s) => s.codec_type === "audio");
  return {
    container: j.format.format_name,
    durationSec: Number(j.format.duration),
    sizeBytes: Number(j.format.size),
    video: v && { codec: v.codec_name, w: v.width, h: v.height, rFrameRate: v.r_frame_rate, avgFrameRate: v.avg_frame_rate, frames: Number(v.nb_read_frames), startSec: Number(v.start_time), durationSec: Number(v.duration), bitrate: Number(v.bit_rate) || null },
    audio: a && { codec: a.codec_name, sampleRate: Number(a.sample_rate), startSec: Number(a.start_time), durationSec: Number(a.duration) },
  };
}

// ---- opts + argv from production code --------------------------------------
function cursorFor(mediaIds, duration) {
  const events = [];
  for (let t = 0; t <= duration; t += 1 / 60) {
    events.push({ type: "move", t: +t.toFixed(4), x: 0.5 + 0.35 * Math.cos(t * 1.7), y: 0.5 + 0.3 * Math.sin(t * 2.3) });
  }
  for (let t = 1; t < duration; t += 2) {
    events.push({ type: "down", t, x: 0.5 + 0.35 * Math.cos(t * 1.7), y: 0.5 + 0.3 * Math.sin(t * 2.3) });
    events.push({ type: "up", t: t + 0.12, x: 0.5 + 0.35 * Math.cos(t * 1.7), y: 0.5 + 0.3 * Math.sin(t * 2.3) });
  }
  events.sort((a, b) => a.t - b.t);
  return {
    style: { show: true, shape: "macos", size: 32, color: "#ffffff", smoothing: 0.1, clickEffect: "ripple", hideWhenIdle: false, motionBlur: false },
    tracks: Object.fromEntries(mediaIds.map((id) => [id, { events }])),
  };
}

function buildOpts(sc, files, outPath, srcInfo) {
  const ids = [...new Set(sc.segments.map((s) => s.src))];
  const mediaMap = Object.fromEntries(
    ids.map((id) => [id, { id, path: files[id], duration: 10, fps: media[id].fps, width: media[id].w, height: media[id].h, audioSampleRate: 48000, sha256: "bench" }]),
  );
  const project = {
    version: 1, id: "bench", name: "bench", createdAt: "x", updatedAt: "x",
    media: mediaMap,
    segments: sc.segments.map((s, i) => ({ id: `s${i}`, mediaId: s.src, words: [], sourceIn: s.in, sourceOut: s.out })),
    settings: { exportPreset: "youtube-1080p", paddingMs: 80 },
    chapters: [], audioTracks: [],
  };
  if (sc.cursor) project.cursor = cursorFor(ids, 10);
  return {
    project, outputPath: outPath, preset: "youtube-1080p",
    videoBitrateKbps: null, audioBitrateKbps: null, // UI defaults -> production fallbacks (8000k / 192k)
    width: sc.width ?? null, height: sc.height ?? null, fps: sc.fps ?? null, codec: null,
    forceReencode: false,
    scene: sc.scene ?? null, zoomRegions: sc.zoomRegions ?? [], drawCursor: !!sc.cursor,
  };
}

// ---- timing ----------------------------------------------------------------
function timed(argv, tag) {
  const tf = path.join(CACHE, `time-${tag}.txt`);
  const t0 = process.hrtime.bigint();
  const r = spawnSync("/usr/bin/time", ["-l", "-o", tf, FFMPEG, ...argv], { stdio: ["ignore", "ignore", "pipe"], encoding: "utf8", maxBuffer: 1 << 28 });
  const wallMs = Number(process.hrtime.bigint() - t0) / 1e6;
  const txt = fs.existsSync(tf) ? fs.readFileSync(tf, "utf8") : "";
  const g = (re) => Number(txt.match(re)?.[1] ?? NaN);
  return {
    ok: r.status === 0, status: r.status, wallMs,
    timeRealSec: g(/([\d.]+)\s+real/), userSec: g(/([\d.]+)\s+user/), sysSec: g(/([\d.]+)\s+sys/),
    peakRssBytes: g(/(\d+)\s+maximum resident set size/), peakFootprintBytes: g(/(\d+)\s+peak memory footprint/),
    stderrTail: r.status === 0 ? undefined : (r.stderr || "").slice(-1500),
  };
}

function validate(sc, opts, out, expectedSec) {
  const s = summary(out);
  const notes = [];
  const outFps = Number(eval(s.video.avgFrameRate)) || 30;
  const expFrames = Math.round(expectedSec * outFps);
  const frameTol = Math.max(2, sc.segments.length > 50 ? sc.segments.length : 2);
  const durDelta = s.durationSec - expectedSec;
  const audioOffset = s.audio ? s.audio.startSec - s.video.startSec : null;
  // A source whose audio starts late must keep that offset in the export (A/V sync).
  const first = sc.segments[0];
  const srcInfo = sources[first.src];
  const expectedAudioOffset = first.in === 0 && srcInfo.audio ? srcInfo.audio.startSec - srcInfo.video.startSec : 0;
  const avDur = s.audio ? s.audio.durationSec - s.video.durationSec : null;
  if (Math.abs(durDelta) > 0.15) notes.push(`duration off by ${durDelta.toFixed(3)} s`);
  if (Math.abs(s.video.frames - expFrames) > frameTol) notes.push(`frames ${s.video.frames} vs ~${expFrames} (tol ${frameTol})`);
  if (audioOffset !== null && Math.abs(audioOffset - expectedAudioOffset) > 0.05) notes.push(`audio offset ${audioOffset.toFixed(3)} s, source had ${expectedAudioOffset.toFixed(3)} s (A/V sync not preserved)`);
  return { summary: s, expectedDurationSec: expectedSec, durationDeltaSec: durDelta, expectedFramesApprox: expFrames, frameTolerance: frameTol, audioStartOffsetSec: audioOffset, expectedAudioStartOffsetSec: expectedAudioOffset, audioMinusVideoDurationSec: avDur, pass: notes.length === 0, notes };
}

// ---- main ------------------------------------------------------------------
if (!args.includes("--skip-build"))
  execFileSync("cargo", ["build", "--example", "export_argv"], { cwd: path.join(REPO_ROOT, "src-tauri"), stdio: "inherit" });
const GEN = path.join(process.env.CARGO_TARGET_DIR ?? path.join(REPO_ROOT, "src-tauri/target"), "debug/examples/export_argv");

// Long/real-media mode: --opts <ExportOpts.json> times one real export (no fixtures, no matrix).
if (flag("opts")) {
  const optsPath = path.resolve(flag("opts"));
  const gen = JSON.parse(run(GEN, [optsPath, "--cursor-ass", path.join(CACHE, "real-cursor.ass")]));
  const outFile = gen.argv[gen.argv.length - 1];
  const rec = [];
  for (let i = 0; i < REPS; i++) {
    const t = timed(gen.argv, `real${i}`);
    rec.push({ rep: i, ...t, thermalAfter: thermalState(), output: t.ok ? summary(outFile) : null });
    process.stderr.write(`real rep${i}: ${t.ok ? (t.wallMs / 1000).toFixed(1) + " s" : "FAILED"}\n`);
  }
  const realOut = OUT.replace(/export-baseline-/, "export-real-");
  fs.writeFileSync(realOut, JSON.stringify({ env: captureEnv({ buildMode: "ffmpeg sidecar; argv from production build_reencode_argv" }), smartCutEligible: gen.smartCutEligible, expectedDurationSec: gen.totalDuration, runs: rec }, null, 2) + "\n");
  process.stderr.write(`wrote ${realOut}\n`);
  process.exit(0);
}
const files = makeFixtures();
const env = captureEnv({ buildMode: "timed workload = bundled ffmpeg sidecar binary (arm64); argv generator = cargo debug example calling production build_reencode_argv" });
const sources = Object.fromEntries(Object.entries(files).map(([k, f]) => [k, summary(f)]));
const results = [];
const scenarioFiles = fs.readdirSync(FIX_DIR).filter((f) => /^\d\d-.*\.json$/.test(f)).sort();

for (const sf of scenarioFiles) {
  const sc = JSON.parse(fs.readFileSync(path.join(FIX_DIR, sf), "utf8"));
  if (ONLY.length && !ONLY.some((o) => sc.id.startsWith(o))) continue;
  const out = path.join(CACHE, `out-${sc.id}.mp4`);
  const optsPath = path.join(CACHE, `opts-${sc.id}.json`);
  const opts = buildOpts(sc, files, out);
  fs.writeFileSync(optsPath, JSON.stringify(opts));
  const ass = path.join(CACHE, `cursor-${sc.id}.ass`);
  const gen = JSON.parse(run(GEN, [optsPath, "--cursor-ass", ass]));
  const expectedSec = sc.segments.reduce((a, s) => a + (s.out - s.in), 0);
  if (sc.expectedFail) process.stderr.write(`(${sc.id}: ${sc.expectedFail})\n`);
  const runs = [];
  for (let i = 0; i < REPS; i++) {
    try { fs.unlinkSync(out); } catch {}
    const therm = thermalState();
    const t = timed(gen.argv, sc.id);
    const rec = { rep: i, ...t, thermalBefore: therm?.split("\n").find((l) => /warning|level/i.test(l)) ?? therm };
    if (t.ok) rec.validation = validate(sc, opts, out, expectedSec);
    runs.push(rec);
    process.stderr.write(`${sc.id} rep${i}: ${t.ok ? `${(t.wallMs / 1000).toFixed(2)} s, ${(t.peakRssBytes / 1e6).toFixed(0)} MB` : "FAILED"}\n`);
  }
  const okRuns = runs.filter((r) => r.ok);
  results.push({
    id: sc.id, description: sc.desc, knownIssue: sc.expectedFail ?? null, smartCutEligible: gen.smartCutEligible,
    graph: gen.argv[gen.argv.indexOf("-filter_complex") + 1].length > 4000 ? "(long, omitted)" : gen.argv[gen.argv.indexOf("-filter_complex") + 1],
    argvEncoder: gen.argv[gen.argv.indexOf("-c:v") + 1], argvBitrate: gen.argv[gen.argv.indexOf("-b:v") + 1], argvHasHwaccelNoOutputFormat: gen.argv.includes("-hwaccel") && !gen.argv.includes("-hwaccel_output_format"),
    inputCount: gen.argv.filter((a) => a === "-i").length, cursorAssBytes: gen.cursorAss ? fs.statSync(gen.cursorAss).size : null,
    runs,
    wallMsMedian: median(okRuns.map((r) => r.wallMs)), wallMsMin: Math.min(...okRuns.map((r) => r.wallMs)), wallMsMax: Math.max(...okRuns.map((r) => r.wallMs)),
    peakRssBytesMedian: median(okRuns.map((r) => r.peakRssBytes)),
    realtimeFactor: okRuns.length ? expectedSec / (median(okRuns.map((r) => r.wallMs)) / 1000) : null,
    allValid: okRuns.length === runs.length && okRuns.every((r) => r.validation.pass),
  });
}
const doc = {
  schema: "yusafcut-export-baseline/1", scope: "production build_reencode_argv argv, bundled ffmpeg, 10 s synthetic fixtures; not UI/job overhead, not smart-cut path",
  reps: REPS, env: { ...env, thermalAfter: thermalState() }, sources, results,
};
fs.mkdirSync(path.dirname(OUT), { recursive: true });
fs.writeFileSync(OUT, JSON.stringify(doc, null, 2) + "\n");
process.stderr.write(`wrote ${OUT}\n`);
