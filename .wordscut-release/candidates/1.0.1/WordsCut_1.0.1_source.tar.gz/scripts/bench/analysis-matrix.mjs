#!/usr/bin/env node
// Production-argv benchmark for analysis, proxy, hash and Stop-to-edit paths.
// argv comes from the Rust example `analysis_argv` (real builders: proxy_args,
// waveform_args, finalize_args; silencedetect + 16 kHz extraction are mirrored
// literals because the app builds them inline). Each argv runs under
// `/usr/bin/time -l` (peak RSS of the ffmpeg process only) and is validated
// with ffprobe. Fixtures are synthetic; see docs/performance/analysis-baseline.md.
//
// usage: node scripts/bench/analysis-matrix.mjs [--reps 3] [--speech-sec 60]
//        [--hash-mb 500] [--out path.json] [--cache dir] [--skip-build]
import { spawnSync } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { captureEnv, median, thermalState, REPO_ROOT, FFMPEG, FFPROBE } from "./lib/env.mjs";

const args = process.argv.slice(2);
const flag = (n, d) => {
  const i = args.indexOf(`--${n}`);
  return i >= 0 ? args[i + 1] : d;
};
const REPS = Number(flag("reps", 3));
const SPEECH = Number(flag("speech-sec", 60));
const HASH_MB = Number(flag("hash-mb", 500));
const DATE = new Date().toISOString().slice(0, 10);
const OUT = flag("out", path.join(REPO_ROOT, "docs/benchmarks", `analysis-baseline-${DATE}.json`));
const CACHE = flag("cache", path.join(os.tmpdir(), "yusafcut-bench-analysis"));
const SKIP_BUILD = args.includes("--skip-build");
fs.mkdirSync(CACHE, { recursive: true });
const P = (f) => path.join(CACHE, f);

const run = (cmd, a, o = {}) => {
  const r = spawnSync(cmd, a, { encoding: "utf8", maxBuffer: 1 << 28, ...o });
  if (r.status !== 0) throw new Error(`${cmd} ${a.slice(0, 6).join(" ")}… exited ${r.status}\n${(r.stderr || "").slice(-1500)}`);
  return r.stdout;
};
const ff = (a) => run(FFMPEG, ["-y", "-hide_banner", "-loglevel", "error", ...a]);

// ---- fixtures -------------------------------------------------------------
const SAY_TEXT =
  "This is a short test of the text based video editor. [[slnc 1800]] We pause here on purpose. " +
  "Then we continue speaking for a while, so that silence detection has something to find. [[slnc 2500]] " +
  "And once more, with feeling, to make the clip long enough.";
function speech(sec) {
  const wav = P(`speech-${sec}.wav`);
  if (fs.existsSync(wav)) return wav;
  const unit = P("say-unit.aiff");
  if (!fs.existsSync(unit)) run("say", ["-o", unit, SAY_TEXT]);
  // Loop the spoken unit up to `sec` seconds.
  ff(["-stream_loop", "-1", "-i", unit, "-t", String(sec), "-ar", "48000", "-ac", "1", wav]);
  return wav;
}
const venc = ["-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p"];
function video(name, size, fps, sec, audio) {
  const f = P(name);
  if (fs.existsSync(f)) return f;
  const a = ["-f", "lavfi", "-i", `testsrc2=size=${size}:rate=${fps}:duration=${sec}`];
  if (audio) ff([...a, "-i", audio, ...venc, "-c:a", "aac", "-b:a", "160k", "-shortest", f]);
  else ff([...a, ...venc, f]);
  return f;
}
function fixtures() {
  const wav = speech(SPEECH);
  const f = {};
  f.src1080 = video(`src-1080p-${SPEECH}s.mp4`, "1920x1080", 30, SPEECH, wav);
  f.src4k = video("src-4k-20s.mp4", "3840x2160", 30, 20, speech(20));
  for (const [tag, size, sec] of [["1080p", "1920x1080", SPEECH], ["4k", "3840x2160", 20]]) {
    // Track pair like the native recorder leaves: video-only screen, video-only camera, m4a mic.
    f[`screen_${tag}`] = video(`track-screen-${tag}-${sec}s.mp4`, size, 30, sec);
    f[`camera_${tag}`] = video(`track-camera-${tag}-${sec}s.mp4`, "1280x720", 30, sec);
    const mic = P(`track-mic-${sec}s.m4a`);
    if (!fs.existsSync(mic)) ff(["-i", speech(sec), "-c:a", "aac", "-b:a", "128k", mic]);
    f[`mic_${tag}`] = mic;
  }
  // Shorter pair to show Stop-to-edit growth with take length.
  f.screen_10 = video("track-screen-1080p-10s.mp4", "1920x1080", 30, 10);
  f.camera_10 = video("track-camera-1080p-10s.mp4", "1280x720", 30, 10);
  f.mic_10 = P("track-mic-10s.m4a");
  if (!fs.existsSync(f.mic_10)) ff(["-i", speech(10), "-c:a", "aac", "-b:a", "128k", f.mic_10]);
  return f;
}

// ---- argv from Rust -------------------------------------------------------
if (!SKIP_BUILD) run("cargo", ["build", "--quiet", "--example", "analysis_argv"], { cwd: path.join(REPO_ROOT, "src-tauri") });
const BIN = path.join(REPO_ROOT, "src-tauri/target/debug/examples/analysis_argv");
// sha256_file is CPU-bound, so measure it from an optimized build (separate target dir,
// dev profile at opt-level 3) -- a debug hash would be misleadingly slow.
const OPT_TARGET = path.join(CACHE, "cargo-opt-target");
const HASH_BIN = path.join(OPT_TARGET, "debug/examples/analysis_argv");
if (!SKIP_BUILD)
  run("cargo", ["build", "--quiet", "--example", "analysis_argv"], {
    cwd: path.join(REPO_ROOT, "src-tauri"),
    env: { ...process.env, CARGO_TARGET_DIR: OPT_TARGET, CARGO_PROFILE_DEV_OPT_LEVEL: "3", CARGO_PROFILE_DEV_DEBUG: "0" },
  });
const argvFor = (o) => JSON.parse(run(BIN, Object.entries(o).flatMap(([k, v]) => [`--${k}`, v])));

// ---- measuring ------------------------------------------------------------
const rss = (stderr) => {
  const m = stderr.match(/(\d+)\s+maximum resident set size/);
  return m ? Number(m[1]) : null;
};
function timed(cmd, a, { stdoutBytes = false } = {}) {
  const t = process.hrtime.bigint();
  const r = spawnSync("/usr/bin/time", ["-l", cmd, ...a], { encoding: "buffer", maxBuffer: 1 << 29 });
  const wallMs = Number(process.hrtime.bigint() - t) / 1e6;
  const stderr = r.stderr.toString("utf8");
  if (r.status !== 0) throw new Error(`${path.basename(cmd)} exited ${r.status}\n${stderr.slice(-1200)}`);
  return { wallMs, rssBytes: rss(stderr), stderr, stdoutLen: r.stdout.length, stdoutBytes };
}
const probeJ = (file) =>
  JSON.parse(run(FFPROBE, ["-v", "error", "-count_frames", "-show_format", "-show_streams", "-of", "json", file]));
function summary(file) {
  const j = probeJ(file);
  const v = j.streams.find((s) => s.codec_type === "video");
  const a = j.streams.find((s) => s.codec_type === "audio");
  return {
    container: j.format.format_name,
    durationSec: Number(j.format.duration),
    sizeBytes: Number(j.format.size),
    video: v && { codec: v.codec_name, w: v.width, h: v.height, frames: Number(v.nb_read_frames), fps: v.avg_frame_rate },
    audio: a && { codec: a.codec_name, sampleRate: Number(a.sample_rate), channels: a.channels },
  };
}
const probeDuration = (file) => {
  // Same query as record.rs::captured_duration.
  const t = process.hrtime.bigint();
  run(FFPROBE, ["-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", file]);
  return Number(process.hrtime.bigint() - t) / 1e6;
};

const results = [];
function bench(id, desc, cmd, a, { validate, inputSec, reps = REPS, extra } = {}) {
  const runs = [];
  let last;
  for (let i = 0; i < reps; i++) {
    last = timed(cmd, a);
    runs.push({ wallMs: last.wallMs, rssBytes: last.rssBytes });
  }
  const med = median(runs.map((r) => r.wallMs));
  const rec = {
    id, desc, inputSec, reps,
    wallMsMedian: Math.round(med),
    wallMsRuns: runs.map((r) => Math.round(r.wallMs)),
    peakRssBytesMax: Math.max(...runs.map((r) => r.rssBytes ?? 0)),
    realtimeX: inputSec ? Number((inputSec / (med / 1000)).toFixed(1)) : null,
    ...(validate ? { validation: validate(last) } : {}),
    ...(extra ?? {}),
  };
  console.error(`${id}: ${rec.wallMsMedian} ms, RSS ${(rec.peakRssBytesMax / 1e6).toFixed(0)} MB, ${rec.realtimeX ?? "-"}x`);
  results.push(rec);
  return rec;
}

const fx = fixtures();
const srcSummaries = Object.fromEntries(["src1080", "src4k", "screen_1080p", "camera_1080p"].map((k) => [k, summary(fx[k])]));
const base = {
  "proxy-out": P("out-proxy.mp4"),
  "wav-out": P("out-16k.wav"),
  final: P("out-final.mp4"),
};
const ok = (cond, msg) => ({ ok: !!cond, ...(cond ? {} : { problem: msg }) });
const thermalBefore = thermalState();

// Proxy (Balanced + Low) for 1080p and 4K sources.
for (const [tag, src, sec] of [["1080p", fx.src1080, SPEECH], ["4k", fx.src4k, 20]]) {
  const A = argvFor({ src, ...base, screen: fx.screen_1080p, camera: fx.camera_1080p, mic: fx.mic_1080p });
  for (const q of ["balanced", "low"]) {
    bench(`proxy_${q}_${tag}`, `generate_preview_proxy ${q}, ${tag} source`, FFMPEG, A[`proxy_${q}`], {
      inputSec: sec,
      validate: () => {
        const s = summary(base["proxy-out"]);
        const inp = srcSummaries[tag === "4k" ? "src4k" : "src1080"];
        return { ...s, ...ok(Math.abs(s.durationSec - inp.durationSec) < 0.3 && s.video.frames === inp.video.frames && s.video.h <= (q === "low" ? 640 : 1280), "duration/frames/size mismatch") };
      },
    });
  }
}
// Analysis passes on the 1080p source.
{
  const A = argvFor({ src: fx.src1080, ...base, screen: fx.screen_1080p, camera: fx.camera_1080p, mic: fx.mic_1080p });
  bench("waveform_8k", "generate_waveform PCM decode (8 kHz mono s16le to pipe)", FFMPEG, A.waveform, {
    inputSec: SPEECH,
    validate: (r) => ({ stdoutBytes: r.stdoutLen, expectedBytes: SPEECH * 8000 * 2, ...ok(Math.abs(r.stdoutLen - SPEECH * 16000) < 16000, "pcm length off by >1 s") }),
  });
  bench("silencedetect", "detect_pauses (mirrored argv)", FFMPEG, A.silencedetect.argv, {
    inputSec: SPEECH,
    validate: (r) => {
      const n = (r.stderr.match(/silence_end/g) || []).length;
      return { silenceRanges: n, ...ok(n > 0, "no silences found") };
    },
  });
  bench("extract_16k_wav", "transcribe audio extraction (mirrored argv)", FFMPEG, A.extract16k.argv, {
    inputSec: SPEECH,
    validate: () => {
      const s = summary(base["wav-out"]);
      return { ...s, ...ok(s.audio?.sampleRate === 16000 && Math.abs(s.durationSec - SPEECH) < 0.3, "wav rate/duration") };
    },
  });
}
// Stop-to-edit: finalize_args at several take lengths, then the post-finalize probe.
for (const [tag, scr, cam, mic, sec] of [
  ["10s_1080p", fx.screen_10, fx.camera_10, fx.mic_10, 10],
  [`${SPEECH}s_1080p`, fx.screen_1080p, fx.camera_1080p, fx.mic_1080p, SPEECH],
  ["20s_4k", fx.screen_4k, fx.camera_4k, fx.mic_4k, 20],
]) {
  const A = argvFor({ src: scr, ...base, screen: scr, camera: cam, mic });
  for (const kind of ["screen_camera", "screen"]) {
    let probeMs = [];
    const rec = bench(`finalize_${kind}_${tag}`, `stop_native finalize ${kind} (${tag})`, FFMPEG, A[`finalize_${kind}`], {
      inputSec: sec,
      validate: () => {
        const s = summary(base.final);
        probeMs.push(probeDuration(base.final));
        const inScreen = summary(scr);
        const wantCodec = kind === "screen_camera" ? "h264" : inScreen.video.codec;
        return { ...s, ...ok(Math.abs(s.durationSec - sec) < 0.5 && s.video.frames === inScreen.video.frames && s.video.codec === wantCodec && s.audio, "duration/frames/codec/audio") };
      },
    });
    rec.probeMsMedian = Math.round(median(probeMs));
    rec.stopToEditMsExHelper = rec.wallMsMedian + rec.probeMsMedian;
  }
}
// Hash: the import-time sha256_file on a random file.
{
  const big = P(`random-${HASH_MB}mb.bin`);
  if (!fs.existsSync(big)) run("dd", ["if=/dev/urandom", `of=${big}`, "bs=1048576", `count=${HASH_MB}`]);
  const sizeBytes = fs.statSync(big).size;
  const hashRuns = [];
  for (let i = 0; i < REPS; i++) {
    const r = timed(HASH_BIN, ["--hash", big]);
    hashRuns.push({ wallMs: r.wallMs, rssBytes: r.rssBytes });
  }
  const out = spawnSync(HASH_BIN, ["--hash", big], { encoding: "utf8" }).stdout;
  const inner = JSON.parse(out);
  const t = process.hrtime.bigint();
  const ref = run("shasum", ["-a", "256", big]).split(" ")[0];
  const shasumMs = Number(process.hrtime.bigint() - t) / 1e6;
  const med = median(hashRuns.map((r) => r.wallMs));
  results.push({
    id: `sha256_${HASH_MB}mb`,
    desc: "media::sha256_file (import_media hash), page cache warm after first run",
    sizeBytes,
    reps: REPS,
    wallMsMedian: Math.round(med),
    wallMsRuns: hashRuns.map((r) => Math.round(r.wallMs)),
    innerMs: Math.round(inner.ms),
    peakRssBytesMax: Math.max(...hashRuns.map((r) => r.rssBytes ?? 0)),
    mbPerSec: Number((sizeBytes / 1e6 / (med / 1000)).toFixed(0)),
    shasumReferenceMs: Math.round(shasumMs),
    validation: ok(inner.sha256 === ref, "digest mismatch vs shasum"),
  });
  console.error(`sha256: ${Math.round(med)} ms (${results.at(-1).mbPerSec} MB/s)`);
  fs.rmSync(big, { force: true });
}

const out = {
  schema: "analysis-baseline/1",
  env: captureEnv({ buildMode: "ffmpeg release sidecar binary; argv generator: cargo debug example; sha256_file: example built at opt-level 3" }),
  thermalBefore,
  thermalAfter: thermalState(),
  fixtures: { speechSec: SPEECH, sources: srcSummaries, synthetic: true },
  results,
};
fs.mkdirSync(path.dirname(OUT), { recursive: true });
fs.writeFileSync(OUT, JSON.stringify(out, null, 2) + "\n");
console.error(`wrote ${path.relative(REPO_ROOT, OUT)}`);
