#!/usr/bin/env node
// Per-word timing comparison between two whisper-cli `-ojf` (--output-json-full) results.
// Words are rebuilt from tokens (a token starting with a space begins a new word, special
// tokens like [_BEG_] are skipped). Start time prefers `t_dtw` (centiseconds, x10 = ms) and
// falls back to the token offsets, mirroring how the app's parser treats DTW.
// Words are aligned by an LCS over normalised text, so a dropped or split word does not shift
// every later comparison.
//
// CLI:  node scripts/bench/compare-words.mjs <a.json> <b.json> [--limit-ms 20] [--json]
// Lib:  import { loadWords, compareWords } from "./compare-words.mjs"
import fs from "node:fs";
import { pathToFileURL } from "node:url";

const norm = (s) => s.toLowerCase().replace(/[^\p{L}\p{N}']+/gu, "");

export function wordsFromJson(doc) {
  const words = [];
  for (const seg of doc.transcription ?? []) {
    for (const tok of seg.tokens ?? []) {
      if (/^\[_.*_\]$/.test(tok.text)) continue;
      const startsWord = /^\s/.test(tok.text) || words.length === 0;
      const dtw = typeof tok.t_dtw === "number" && tok.t_dtw >= 0 ? tok.t_dtw * 10 : null;
      const from = tok.offsets?.from ?? null;
      const to = tok.offsets?.to ?? null;
      if (startsWord) {
        words.push({ text: tok.text.trim(), dtwStartMs: dtw, offStartMs: from, endMs: to });
      } else {
        const w = words[words.length - 1];
        w.text += tok.text;
        if (to !== null) w.endMs = to;
      }
    }
  }
  for (const w of words) {
    w.startMs = w.dtwStartMs ?? w.offStartMs;
    w.usedDtw = w.dtwStartMs !== null;
    w.key = norm(w.text);
  }
  return words.filter((w) => w.key.length > 0);
}

export function loadWords(file) {
  return wordsFromJson(JSON.parse(fs.readFileSync(file, "utf8")));
}

function lcsPairs(a, b) {
  const n = a.length, m = b.length;
  const dp = Array.from({ length: n + 1 }, () => new Uint16Array(m + 1));
  for (let i = n - 1; i >= 0; i--)
    for (let j = m - 1; j >= 0; j--)
      dp[i][j] = a[i].key === b[j].key ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
  const pairs = [];
  let i = 0, j = 0;
  while (i < n && j < m) {
    if (a[i].key === b[j].key) pairs.push([i++, j++]);
    else if (dp[i + 1][j] >= dp[i][j + 1]) i++;
    else j++;
  }
  return pairs;
}

export function percentile(sorted, p) {
  if (!sorted.length) return null;
  const idx = Math.min(sorted.length - 1, Math.max(0, Math.ceil((p / 100) * sorted.length) - 1));
  return sorted[idx];
}

function stats(deltas) {
  const abs = deltas.map(Math.abs).sort((x, y) => x - y);
  if (!abs.length) return { n: 0, p50: null, p95: null, max: null, meanSigned: null };
  return {
    n: abs.length,
    p50: percentile(abs, 50),
    p95: percentile(abs, 95),
    max: abs[abs.length - 1],
    meanSigned: Math.round((deltas.reduce((s, d) => s + d, 0) / deltas.length) * 10) / 10,
  };
}

/** Compare two word lists. Deltas are b - a in ms. */
export function compareWords(a, b, { limitMs = 20 } = {}) {
  const pairs = lcsPairs(a, b);
  const startD = [], endD = [], dtwOnlyD = [];
  let basisDtw = 0, basisOffsets = 0;
  for (const [i, j] of pairs) {
    // Pair-consistent basis: DTW only when BOTH words have it, otherwise token offsets for both
    // (DTW and offset times are different quantities and must never be subtracted).
    const bothDtw = a[i].usedDtw && b[j].usedDtw;
    const sa = bothDtw ? a[i].dtwStartMs : a[i].offStartMs;
    const sb = bothDtw ? b[j].dtwStartMs : b[j].offStartMs;
    if (bothDtw) basisDtw++; else basisOffsets++;
    if (sa !== null && sb !== null) startD.push(sb - sa);
    if (a[i].endMs !== null && b[j].endMs !== null) endD.push(b[j].endMs - a[i].endMs);
    if (a[i].usedDtw && b[j].usedDtw) dtwOnlyD.push(b[j].dtwStartMs - a[i].dtwStartMs);
  }
  const start = stats(startD);
  return {
    wordsA: a.length,
    wordsB: b.length,
    matched: pairs.length,
    unmatchedA: a.length - pairs.length,
    unmatchedB: b.length - pairs.length,
    dtwWordsA: a.filter((w) => w.usedDtw).length,
    dtwWordsB: b.filter((w) => w.usedDtw).length,
    startBasis: { dtwPairs: basisDtw, offsetPairs: basisOffsets },
    startMs: start,
    endMs: stats(endD),
    dtwStartMs: stats(dtwOnlyD),
    limitMs,
    startP95WithinLimit: start.p95 !== null ? start.p95 <= limitMs : null,
  };
}

if (import.meta.url === pathToFileURL(process.argv[1] ?? "").href) {
  const args = process.argv.slice(2);
  const files = args.filter((x) => !x.startsWith("--") && !/^\d+$/.test(x));
  const li = args.indexOf("--limit-ms");
  const limitMs = li >= 0 ? Number(args[li + 1]) : 20;
  if (files.length !== 2) {
    console.error("usage: compare-words.mjs <a.json> <b.json> [--limit-ms 20] [--json]  (whisper-cli -ojf output)");
    process.exit(2);
  }
  const res = compareWords(loadWords(files[0]), loadWords(files[1]), { limitMs });
  if (args.includes("--json")) console.log(JSON.stringify(res, null, 2));
  else {
    console.log(`words A=${res.wordsA} B=${res.wordsB} matched=${res.matched} (dtw A=${res.dtwWordsA} B=${res.dtwWordsB})`);
    for (const k of ["startMs", "endMs", "dtwStartMs"]) {
      const s = res[k];
      console.log(`${k.padEnd(10)} n=${s.n} p50=${s.p50} p95=${s.p95} max=${s.max} meanSigned=${s.meanSigned}`);
    }
    console.log(`start basis: dtwPairs=${res.startBasis.dtwPairs} offsetPairs=${res.startBasis.offsetPairs}`);
    console.log(`start p95 <= ${limitMs} ms: ${res.startP95WithinLimit}`);
  }
}
