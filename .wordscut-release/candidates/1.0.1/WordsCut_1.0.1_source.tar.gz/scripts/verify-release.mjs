import fs from "node:fs";
const pkg = JSON.parse(fs.readFileSync("package.json"));
const tauri = JSON.parse(fs.readFileSync("src-tauri/tauri.conf.json"));
const cargo = fs.readFileSync("src-tauri/Cargo.toml", "utf8").match(/^version = "([^"]+)"/m)?.[1];
const lock = JSON.parse(fs.readFileSync("package-lock.json"));
if (![tauri.version, cargo, lock.version, lock.packages[""].version].every(v => v === pkg.version)) throw new Error("Release versions disagree");
if (process.env.GITHUB_REF_TYPE === "tag" && process.env.GITHUB_REF_NAME !== `v${pkg.version}`) throw new Error("Tag does not match release version");
if (tauri.productName !== "WordsCut" || tauri.mainBinaryName !== "WordsCut") throw new Error("Unexpected release branding");
console.log(`WordsCut ${pkg.version}: release metadata verified`);
