#!/usr/bin/env bash
# Developer ID distribution: sign every Mach-O inside out, notarize, staple, verify.
set -euo pipefail
REPO="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUNDLE="${BUNDLE_DIR:-$REPO/src-tauri/target/release/bundle}"
APP="$BUNDLE/macos/WordsCut.app"
ENTITLEMENTS="$REPO/src-tauri/Entitlements.direct.plist"
VERSION="$(node -p "require('$REPO/package.json').version")"
DMG="$BUNDLE/dmg/WordsCut_${VERSION}_aarch64.dmg"
IDENTITY="${APPLE_SIGNING_IDENTITY:-}"
[[ "$IDENTITY" == 'Developer ID Application: '* ]] || { echo 'Developer ID Application identity required'; exit 1; }
[[ -d "$APP" ]] || { echo "Missing $APP"; exit 1; }
NOTARY=()
if [[ -n "${APPLE_API_KEY_PATH:-}" && -n "${APPLE_API_KEY_ID:-}" && -n "${APPLE_API_ISSUER:-}" ]]; then
  NOTARY=(--key "$APPLE_API_KEY_PATH" --key-id "$APPLE_API_KEY_ID" --issuer "$APPLE_API_ISSUER")
elif [[ -n "${NOTARY_PROFILE:-}" ]]; then
  NOTARY=(--keychain-profile "$NOTARY_PROFILE")
else
  echo 'Notarization credentials required; refusing an incomplete release.'; exit 1
fi
# Apple ticket delivery and assessment can transiently lose their network connection.
# Retry each gate three times; never turn a failed gate into a successful release.
retry_apple_gate() {
  local attempt
  for attempt in 1 2 3; do
    if "$@"; then return 0; fi
    if [[ "$attempt" -lt 3 ]]; then
      echo "Apple gate failed; retrying ($attempt/3)." >&2
      sleep "$((attempt * 5))"
    fi
  done
  return 1
}
STAGE="$(mktemp -d)"
trap 'rm -rf "$STAGE"' EXIT
# Traverse the complete bundle, not only Contents/MacOS. Files first, nested bundles next.
while IFS= read -r -d '' FILE; do
  if file -b "$FILE" | grep -q 'Mach-O'; then
    codesign --force --options runtime --timestamp --entitlements "$ENTITLEMENTS" --sign "$IDENTITY" "$FILE"
  fi
done < <(find "$APP/Contents" -type f -print0)
while IFS= read -r -d '' NESTED; do
  codesign --force --options runtime --timestamp --sign "$IDENTITY" "$NESTED"
done < <(find "$APP/Contents" -depth -type d \( -name '*.framework' -o -name '*.app' -o -name '*.xpc' -o -name '*.bundle' \) -print0)
codesign --force --options runtime --timestamp --entitlements "$ENTITLEMENTS" --sign "$IDENTITY" "$APP"
codesign --verify --deep --strict --verbose=2 "$APP"
# Notarize and staple the app before packaging so the installed copy carries its ticket.
ditto -c -k --keepParent "$APP" "$STAGE/WordsCut.zip"
xcrun notarytool submit "$STAGE/WordsCut.zip" "${NOTARY[@]}" --wait --output-format json > "$STAGE/app-notary.json"
python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); print("App notarization:",d.get("status")); sys.exit(0 if d.get("status")=="Accepted" else 1)' "$STAGE/app-notary.json"
retry_apple_gate xcrun stapler staple "$APP"
retry_apple_gate xcrun stapler validate "$APP"
retry_apple_gate spctl --assess --type execute --verbose=2 "$APP"
mkdir -p "$STAGE/image" "$BUNDLE/dmg"
ditto "$APP" "$STAGE/image/WordsCut.app"
ln -s /Applications "$STAGE/image/Applications"
hdiutil create -volname WordsCut -srcfolder "$STAGE/image" -ov -format UDZO "$DMG" >/dev/null
codesign --force --timestamp --sign "$IDENTITY" "$DMG"
xcrun notarytool submit "$DMG" "${NOTARY[@]}" --wait --output-format json > "$STAGE/dmg-notary.json"
python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); print("DMG notarization:",d.get("status")); sys.exit(0 if d.get("status")=="Accepted" else 1)' "$STAGE/dmg-notary.json"
retry_apple_gate xcrun stapler staple "$DMG"
retry_apple_gate xcrun stapler validate "$DMG"
codesign --verify --strict --verbose=2 "$DMG"
retry_apple_gate spctl --assess --type open --context context:primary-signature --verbose=2 "$DMG"
echo "Verified signed and notarized release: $DMG"
