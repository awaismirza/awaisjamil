#!/usr/bin/env bash
# =============================================================================
# WordsCut — Media Sidecar Architecture, Portability & Capability Verifier
#
# Verifies that bundled ffmpeg and ffprobe sidecar binaries:
#   1. Exist, are executable Mach-O binaries (not stubs), and contain arm64.
#   2. Execute natively as arm64 on Apple Silicon without Rosetta translation.
#   3. Target a compatible macOS deployment version (<= 13.0).
#   4. Have portable dynamic linkage (only /System/Library/Frameworks/* and
#      /usr/lib/* — no /opt/homebrew, /usr/local, build temp dirs, or @rpath).
#   5. Expose every codec, filter, format, device, and hwaccel required by
#      WordsCut's actual Rust backend commands.
#   6. Pass portable synthetic smoke tests exercising:
#      - H.264/AAC encoding & faststart MP4 muxing
#      - FFprobe JSON schema (import_media) & keyframe/codec CSV queries
#      - 16 kHz mono WAV audio extraction (transcribe.rs) & silencedetect (pauses.rs)
#      - Preview proxy generation (preview_cache.rs)
#      - PTS-aligned 8 kHz s16le waveform decoding (preview_cache.rs)
#      - Styled ASS vector cursor over sparse VFR input + dynamic zoom +
#        gradient/rounded-mask/shadow scene composition (cursor_export.rs,
#        zoom.rs, scene.rs, export.rs)
#   7. Pass hardware-dependent VideoToolbox encoding checks (h264_videotoolbox,
#      hevc_videotoolbox), kept separate from portable checks.
#
# Usage:
#   bash scripts/verify-media-binaries.sh [options]
#
# Options:
#   --ffmpeg <path>       Path to ffmpeg binary (default: src-tauri/binaries/ffmpeg-aarch64-apple-darwin)
#   --ffprobe <path>      Path to ffprobe binary (default: src-tauri/binaries/ffprobe-aarch64-apple-darwin)
#   --skip-hw             Skip hardware-dependent VideoToolbox encode tests (e.g. restricted sandbox)
#   --run-rust-tests      Also run the Rust real-ffmpeg integration test suite in src-tauri
#   --json <path>         Write machine-readable JSON verification summary to <path>
# =============================================================================
set -euo pipefail

REPO="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FFMPEG="$REPO/src-tauri/binaries/ffmpeg-aarch64-apple-darwin"
FFPROBE="$REPO/src-tauri/binaries/ffprobe-aarch64-apple-darwin"
SKIP_HW=0
RUN_RUST_TESTS=0
JSON_OUT=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --ffmpeg)
      FFMPEG="$2"
      shift 2
      ;;
    --ffprobe)
      FFPROBE="$2"
      shift 2
      ;;
    --skip-hw)
      SKIP_HW=1
      shift
      ;;
    --run-rust-tests)
      RUN_RUST_TESTS=1
      shift
      ;;
    --json)
      JSON_OUT="$2"
      shift 2
      ;;
    -h|--help)
      sed -n '2,35p' "${BASH_SOURCE[0]}"
      exit 0
      ;;
    *)
      echo "Unknown option: $1" >&2
      exit 2
      ;;
  esac
done

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; RESET='\033[0m'

PASS_COUNT=0
FAIL_COUNT=0
SKIP_COUNT=0

pass()   { PASS_COUNT=$((PASS_COUNT + 1)); echo -e "  ${GREEN}✓${RESET}  $*"; }
skip()   { SKIP_COUNT=$((SKIP_COUNT + 1)); echo -e "  ${YELLOW}↷${RESET}  $*"; }
fail()   { FAIL_COUNT=$((FAIL_COUNT + 1)); echo -e "  ${RED}✗${RESET}  $*" >&2; }
header() { echo -e "\n${BOLD}$*${RESET}"; }

TMP_DIR="$(mktemp -d "${TMPDIR:-/tmp}/yusafcut-verify-media.XXXXXX")"
cleanup() {
  rm -rf "$TMP_DIR"
}
trap cleanup EXIT

echo -e "${BOLD}WordsCut Media Binary Verification${RESET}"
echo "  ffmpeg:  $FFMPEG"
echo "  ffprobe: $FFPROBE"

# ── 1. Existence, size & architecture ─────────────────────────────────────────
header "1 / 6  Binary existence & native ARM64 architecture"

for label_bin in "ffmpeg:$FFMPEG" "ffprobe:$FFPROBE"; do
  label="${label_bin%%:*}"
  bin="${label_bin#*:}"

  if [[ ! -f "$bin" ]]; then
    fail "$label missing at $bin"
    continue
  fi
  if [[ ! -x "$bin" ]]; then
    fail "$label is not executable: $bin"
    continue
  fi
  size=$(stat -f "%z" "$bin" 2>/dev/null || wc -c < "$bin")
  if [[ "$size" -lt 1000000 ]]; then
    fail "$label is too small (${size} bytes) — likely a stub"
    continue
  fi
  pass "$label present and executable (${size} bytes)"

  archs=$(lipo -archs "$bin" 2>/dev/null || true)
  file_desc=$(file -b "$bin" 2>/dev/null || true)
  if [[ "$archs" == "arm64" ]]; then
    pass "$label Mach-O architecture is native arm64 (lipo: '$archs', file: '$file_desc')"
  else
    fail "$label is NOT native arm64! Found architectures: '${archs:-unknown}' ($file_desc)"
  fi

  if [[ "$(uname -s)" == "Darwin" ]] && [[ "$(uname -m)" == "arm64" ]]; then
    if arch -arm64 "$bin" -version >/dev/null 2>&1; then
      ver_line=$(arch -arm64 "$bin" -version | head -n 1)
      pass "$label executes natively via 'arch -arm64' ($ver_line)"
    else
      fail "$label failed native 'arch -arm64' execution"
    fi
  fi

  # Check minimum macOS deployment version in Mach-O load commands
  minos=$(otool -l "$bin" 2>/dev/null | awk '
    /LC_BUILD_VERSION/ { in_build=1; next }
    /LC_VERSION_MIN_MACOSX/ { in_min=1; next }
    in_build && /minos/ { print $2; exit }
    in_min && /version/ { print $2; exit }
  ')
  if [[ -n "$minos" ]]; then
    major="${minos%%.*}"
    if [[ "$major" -le 13 ]]; then
      pass "$label minimum macOS deployment target is $minos (<= 13.0)"
    else
      fail "$label minimum macOS deployment target $minos exceeds 13.0 requirement"
    fi
  else
    fail "$label missing LC_BUILD_VERSION / LC_VERSION_MIN_MACOSX load command"
  fi
done

if [[ "$FAIL_COUNT" -gt 0 ]]; then
  echo -e "\n${RED}${BOLD}Verification failed in stage 1 ($FAIL_COUNT failure(s)).${RESET}" >&2
  exit 1
fi

RUN_FFMPEG=(arch -arm64 "$FFMPEG")
RUN_FFPROBE=(arch -arm64 "$FFPROBE")

# ── 2. Dynamic linkage & portability ──────────────────────────────────────────
header "2 / 6  Dynamic linkage & portability (otool -L / LC_RPATH)"

for label_bin in "ffmpeg:$FFMPEG" "ffprobe:$FFPROBE"; do
  label="${label_bin%%:*}"
  bin="${label_bin#*:}"

  dylibs=$(otool -L "$bin" | tail -n +2 | awk '{print $1}')
  bad_links=()
  while IFS= read -r lib; do
    [[ -z "$lib" ]] && continue
    case "$lib" in
      /System/Library/Frameworks/*|/usr/lib/*)
        ;;
      *)
        bad_links+=("$lib")
        ;;
    esac
  done <<< "$dylibs"

  if [[ "${#bad_links[@]}" -eq 0 ]]; then
    count=$(echo "$dylibs" | grep -c . || true)
    pass "$label links only to macOS system frameworks and /usr/lib (${count} system libs)"
  else
    fail "$label links to non-system / non-portable libraries: ${bad_links[*]}"
  fi

  rpaths=$(otool -l "$bin" | awk '/LC_RPATH/{ getline; getline; if ($1 == "path") print $2 }')
  if [[ -z "$rpaths" ]]; then
    pass "$label has no embedded LC_RPATH entries"
  else
    fail "$label has unexpected LC_RPATH entries: $rpaths"
  fi
done

# ── 3. Required codecs, filters, formats & hwaccels ───────────────────────────
header "3 / 6  Required WordsCut capabilities (encoders, decoders, filters, formats, hwaccels)"

HWACCELS=$("${RUN_FFMPEG[@]}" -hide_banner -hwaccels 2>/dev/null)
ENCODERS=$("${RUN_FFMPEG[@]}" -hide_banner -encoders 2>/dev/null)
DECODERS=$("${RUN_FFMPEG[@]}" -hide_banner -decoders 2>/dev/null)
FILTERS=$("${RUN_FFMPEG[@]}" -hide_banner -filters 2>/dev/null)
DEMUXERS=$("${RUN_FFMPEG[@]}" -hide_banner -demuxers 2>/dev/null)
MUXERS=$("${RUN_FFMPEG[@]}" -hide_banner -muxers 2>/dev/null)
DEVICES=$("${RUN_FFMPEG[@]}" -hide_banner -devices 2>/dev/null)

if echo "$HWACCELS" | grep -qw "videotoolbox"; then
  pass "hwaccel: videotoolbox"
else
  fail "hwaccel missing: videotoolbox"
fi

REQ_ENCODERS=(h264_videotoolbox hevc_videotoolbox libx264 aac pcm_s16le png rawvideo prores_ks gif)
for enc in "${REQ_ENCODERS[@]}"; do
  if echo "$ENCODERS" | awk '{print $2}' | grep -qx "$enc"; then
    pass "encoder: $enc"
  else
    fail "encoder missing: $enc"
  fi
done

REQ_DECODERS=(h264 hevc vp8 vp9 prores mpeg4 aac mp3 pcm_s16le flac vorbis opus png mjpeg webp)
for dec in "${REQ_DECODERS[@]}"; do
  if echo "$DECODERS" | awk '{print $2}' | grep -qx "$dec"; then
    pass "decoder: $dec"
  else
    fail "decoder missing: $dec"
  fi
done

REQ_FILTERS=(
  trim setpts scale pad crop fps overlay format setsar null
  alphamerge geq gblur lut ass subtitles select drawbox concat
  color gradients
  atrim asetpts anull asplit volume adelay apad sidechaincompress amix aresample silencedetect
  sine
  palettegen paletteuse loudnorm ebur128 astats atempo xfade acrossfade tpad afade fade
  split pixelize lutyuv rotate colorchannelmixer tile loop
)
for flt in "${REQ_FILTERS[@]}"; do
  if echo "$FILTERS" | awk '{print $2}' | grep -qx "$flt"; then
    pass "filter: $flt"
  else
    fail "filter missing: $flt"
  fi
done

REQ_DEMUXERS=(mov matroska wav mp3 aac flac ogg concat image2 s16le rawvideo ffmetadata)
for dmx in "${REQ_DEMUXERS[@]}"; do
  if echo "$DEMUXERS" | awk '{print $2}' | grep -E "(^|,)${dmx}(,|$)" >/dev/null; then
    pass "demuxer: $dmx"
  else
    fail "demuxer missing: $dmx"
  fi
done

REQ_MUXERS=(mp4 mov gif ipod wav s16le rawvideo null image2 ffmetadata)
for mux in "${REQ_MUXERS[@]}"; do
  if echo "$MUXERS" | awk '{print $2}' | grep -E "(^|,)${mux}(,|$)" >/dev/null; then
    pass "muxer: $mux"
  else
    fail "muxer missing: $mux"
  fi
done

REQ_DEVICES=(avfoundation lavfi)
for dev in "${REQ_DEVICES[@]}"; do
  if echo "$DEVICES" | awk '{print $2}' | grep -qx "$dev"; then
    pass "device: $dev"
  else
    fail "device missing: $dev"
  fi
done

# ── 4. Portable synthetic media smoke suite ───────────────────────────────────
header "4 / 6  Portable synthetic media operations"

SOURCE_MP4="$TMP_DIR/source.mp4"
# Generate 2.0s 640x360@30fps H.264/AAC clip with a 0.6s silence window in the middle (0.7s..1.3s)
if "${RUN_FFMPEG[@]}" -v error -y -nostdin \
  -f lavfi -i "color=c=red:s=640x360:r=30:d=2,drawbox=x=320:y=0:w=320:h=360:color=blue:t=fill" \
  -f lavfi -i "sine=frequency=440:sample_rate=48000:duration=2" \
  -af "volume=enable='between(t,0.7,1.3)':volume=0" \
  -c:v libx264 -preset ultrafast -crf 24 -pix_fmt yuv420p -g 30 \
  -c:a aac -b:a 128k \
  -movflags +faststart \
  "$SOURCE_MP4"; then
  pass "Synthetic H.264/AAC faststart MP4 generation (libx264 + aac)"
else
  fail "Synthetic H.264/AAC faststart MP4 generation failed"
fi

# 4b. FFprobe JSON contract (media.rs parse_ffprobe_json) + keyframe & codec CSV
PROBE_JSON="$TMP_DIR/probe.json"
if "${RUN_FFPROBE[@]}" -v error -print_format json -show_format -show_streams "$SOURCE_MP4" > "$PROBE_JSON"; then
  if node -e '
    const fs = require("fs");
    const d = JSON.parse(fs.readFileSync(process.argv[1], "utf8"));
    const dur = parseFloat(d.format && d.format.duration);
    if (!Number.isFinite(dur) || Math.abs(dur - 2.0) > 0.15) throw new Error("bad duration: " + dur);
    const v = (d.streams || []).find(s => s.codec_type === "video");
    const a = (d.streams || []).find(s => s.codec_type === "audio");
    if (!v || v.width !== 640 || v.height !== 360 || v.r_frame_rate !== "30/1") throw new Error("bad video stream");
    if (!a || String(a.sample_rate) !== "48000") throw new Error("bad audio stream");
  ' "$PROBE_JSON"; then
    pass "FFprobe JSON output matches media.rs parse_ffprobe_json schema"
  else
    fail "FFprobe JSON schema validation failed"
  fi
else
  fail "FFprobe JSON invocation failed"
fi

KF_CSV=$("${RUN_FFPROBE[@]}" -v error -skip_frame nokey -select_streams v:0 -show_entries frame=pkt_pts_time,pts_time -of csv=p=0 "$SOURCE_MP4")
CODEC_CSV=$("${RUN_FFPROBE[@]}" -v error -select_streams v:0 -show_entries stream=codec_name -of csv=p=0 "$SOURCE_MP4" | tr -d '[:space:]')
if [[ -n "$KF_CSV" ]] && [[ "$CODEC_CSV" == "h264" ]]; then
  pass "FFprobe keyframe CSV (smart_cut.rs) & codec_name CSV (preview.rs) queries"
else
  fail "FFprobe CSV queries failed (codec='$CODEC_CSV', keyframes='$KF_CSV')"
fi

# 4c. Audio extraction (transcribe.rs) & silence detection (pauses.rs)
EXTRACTED_WAV="$TMP_DIR/extracted.wav"
if "${RUN_FFMPEG[@]}" -v error -y -nostdin -i "$SOURCE_MP4" -vn -ac 1 -ar 16000 -c:a pcm_s16le "$EXTRACTED_WAV" \
  && [[ $(stat -f "%z" "$EXTRACTED_WAV") -gt 60000 ]]; then
  pass "Audio extraction to 16 kHz mono pcm_s16le WAV (transcribe.rs)"
else
  fail "Audio extraction to 16 kHz mono pcm_s16le WAV failed"
fi

SILENCE_LOG=$("${RUN_FFMPEG[@]}" -hide_banner -nostdin -i "$SOURCE_MP4" -vn -af "silencedetect=noise=-35dB:d=0.4" -f null - 2>&1 || true)
if echo "$SILENCE_LOG" | grep -q "silence_start:" && echo "$SILENCE_LOG" | grep -q "silence_end:"; then
  pass "Audio silencedetect filter output matches pauses.rs parser"
else
  fail "Audio silencedetect filter did not report silence_start/silence_end"
fi

# 4d. Preview proxy generation (preview_cache.rs)
PROXY_MP4="$TMP_DIR/proxy-low.mp4"
PROXY_SCALE="scale=w='max(2,trunc(iw*min(1,640/max(iw,ih))/2)*2)':h='max(2,trunc(ih*min(1,640/max(iw,ih))/2)*2)'"
if "${RUN_FFMPEG[@]}" -v error -y -nostdin -filter_threads 1 -i "$SOURCE_MP4" \
  -map 0:v:0 -map "0:a:0?" -vf "$PROXY_SCALE" \
  -c:v libx264 -preset ultrafast -crf 28 -pix_fmt yuv420p -threads 2 \
  -fps_mode passthrough -c:a aac -ar 48000 -movflags +faststart -f mp4 "$PROXY_MP4"; then
  pass "Preview proxy generation (preview_cache.rs proxy_args)"
else
  fail "Preview proxy generation failed"
fi

# 4e. Waveform PCM decoding (preview_cache.rs waveform_args)
PCM_RAW="$TMP_DIR/waveform.s16le"
if "${RUN_FFMPEG[@]}" -nostdin -v error -threads 2 -filter_threads 1 -i "$SOURCE_MP4" \
  -map 0:a:0 -vn -ac 1 -af "aresample=8000:first_pts=0" -ar 8000 -f s16le "$PCM_RAW"; then
  pcm_bytes=$(stat -f "%z" "$PCM_RAW")
  if [[ "$pcm_bytes" -ge 30000 ]] && [[ $((pcm_bytes % 2)) -eq 0 ]]; then
    pass "Waveform 8 kHz s16le PTS-aligned PCM decode (${pcm_bytes} bytes)"
  else
    fail "Waveform PCM byte count unexpected: ${pcm_bytes}"
  fi
else
  fail "Waveform PCM decode failed"
fi

# 4f. Styled ASS vector cursor over sparse VFR + dynamic zoom + gradient/rounded-mask/shadow scene
ASS_FILE="$TMP_DIR/cursor.ass"
cat > "$ASS_FILE" << 'EOF'
[Script Info]
ScriptType: v4.00+
PlayResX: 640
PlayResY: 360
ScaledBorderAndShadow: yes
[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Cursor,Arial,20,&H00FFFFFF,&H00FFFFFF,&H00171717,&H00000000,0,0,0,0,100,100,0,0,1,0,0,7,0,0,0,1
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
Dialogue: 0,0:00:00.00,0:00:00.50,Cursor,,0,0,0,,{\an7\pos(0,0)\p1\shad0\bord1.0\blur0.0\1c&H00FF00&\3c&H171717&\alpha&H00&}m 160 150 l 200 150 200 210 160 210
Dialogue: 0,0:00:00.50,0:00:01.00,Cursor,,0,0,0,,{\an7\pos(0,0)\p1\shad0\bord1.0\blur0.0\1c&H00FF00&\3c&H171717&\alpha&H00&}m 440 150 l 480 150 480 210 440 210
EOF

ESCAPED_ASS=$(printf '%s' "$ASS_FILE" | sed -e 's/\\/\\\\/g' -e 's/:/\\:/g' -e "s/'/'\\\\''/g")
COMPOSITE_MP4="$TMP_DIR/composite.mp4"
FILTER_GRAPH="[0:v]fps=30[animatedv];\
[animatedv]ass=filename='${ESCAPED_ASS}'[cursorv];\
[cursorv]scale=w='trunc(640*(1+0.5*between(t,0.2,0.9))/2)*2':h='trunc(360*(1+0.5*between(t,0.2,0.9))/2)*2':eval=frame:flags=bicubic,\
crop=w=640:h=360:x='clip(0.5*(trunc(640*(1+0.5*between(t,0.2,0.9))/2)*2)-320,0,(trunc(640*(1+0.5*between(t,0.2,0.9))/2)*2)-640)':y='clip(0.5*(trunc(360*(1+0.5*between(t,0.2,0.9))/2)*2)-180,0,(trunc(360*(1+0.5*between(t,0.2,0.9))/2)*2)-360)'[zoomv];\
gradients=s=800x600:r=30:c0=0x101020:c1=0x204080:x0=0:y0=0:x1=800:y1=600:speed=0:seed=0[scbg];\
[zoomv]scale=640:360:flags=lanczos,setsar=1,format=yuva420p[scvid];\
color=c=black:s=640x360:r=1,format=gray,geq=lum='255*gte((X+0.5),0)*lt((X+0.5),640)*gte((Y+0.5),0)*lt((Y+0.5),360)'[scmask];\
[scvid][scmask]alphamerge=shortest=1[scclip];\
color=c=black:s=800x600:r=1,format=gray,geq=lum='255*gte((X+0.5-80),0)*lt((X+0.5-80),640)*gte((Y+0.5-128),0)*lt((Y+0.5-128),360)',gblur=sigma=12.0,lut=y='val*0.5'[scsmask];\
color=c=black:s=800x600:r=1,format=yuva420p[scsblack];\
[scsblack][scsmask]alphamerge[scshadow];\
[scbg][scshadow]overlay=shortest=1:format=auto[scbase];\
[scbase][scclip]overlay=x=80:y=120:shortest=1:format=auto,format=yuv420p[outv]"

if "${RUN_FFMPEG[@]}" -v error -y -nostdin \
  -f lavfi -i "color=c=black:s=640x360:r=2:d=1" \
  -filter_complex "$FILTER_GRAPH" \
  -map "[outv]" -c:v libx264 -preset ultrafast -crf 22 -pix_fmt yuv420p \
  "$COMPOSITE_MP4"; then
  # Verify frame count is 30 (animated from sparse 2 fps 1s input) and dimensions 800x600
  comp_info=$("${RUN_FFPROBE[@]}" -v error -select_streams v:0 -show_entries stream=width,height,nb_frames -of csv=p=0 "$COMPOSITE_MP4" | tr -d '\r')
  if [[ "$comp_info" == "800,600,30" ]]; then
    pass "ASS vector cursor (libass) + VFR promotion + dynamic zoom + gradient/shadow scene composition (800x600, 30 frames)"
  else
    fail "Composite output stream info unexpected: '$comp_info' (expected 800,600,30)"
  fi
else
  fail "ASS vector cursor + zoom + scene filter graph failed"
fi

# ── 5. Hardware-dependent VideoToolbox encoding checks ────────────────────────
header "5 / 6  Hardware-dependent VideoToolbox encoding (h264_videotoolbox / hevc_videotoolbox)"

if [[ "$SKIP_HW" -eq 1 ]]; then
  skip "Hardware VideoToolbox checks skipped via --skip-hw"
else
  for codec_expected in "h264_videotoolbox:h264" "hevc_videotoolbox:hevc"; do
    vt_enc="${codec_expected%%:*}"
    expected_name="${codec_expected#*:}"
    vt_out="$TMP_DIR/${vt_enc}.mp4"
    if "${RUN_FFMPEG[@]}" -v error -y -nostdin \
      -f lavfi -i "color=c=green:s=640x360:r=30:d=1" \
      -c:v "$vt_enc" -b:v 2000k -pix_fmt yuv420p "$vt_out" 2>"$TMP_DIR/${vt_enc}.err"; then
      probed_codec=$("${RUN_FFPROBE[@]}" -v error -select_streams v:0 -show_entries stream=codec_name -of csv=p=0 "$vt_out" | tr -d '[:space:]')
      if [[ "$probed_codec" == "$expected_name" ]]; then
        pass "Hardware encoder $vt_enc produced valid $expected_name stream"
      else
        fail "Hardware encoder $vt_enc produced unexpected codec '$probed_codec'"
      fi
    else
      fail "Hardware encoder $vt_enc failed: $(cat "$TMP_DIR/${vt_enc}.err")"
    fi
  done
fi

# ── 6. Optional Rust real-ffmpeg test suite ───────────────────────────────────
header "6 / 6  Rust integration tests (--run-rust-tests)"

if [[ "$RUN_RUST_TESTS" -eq 1 ]]; then
  if (cd "$REPO/src-tauri" && cargo test -- --nocapture \
    scene::tests::real_ffmpeg \
    cursor_export::tests:: \
    preview_cache::tests::real_ffmpeg_waveform_preserves_delayed_audio_source_time \
    recorder::tests::real_ffmpeg) >"$TMP_DIR/rust-tests.log" 2>&1; then
    pass "Rust real-ffmpeg integration tests passed"
  else
    cat "$TMP_DIR/rust-tests.log" >&2
    fail "Rust real-ffmpeg integration tests failed"
  fi
else
  skip "Rust test run not requested (pass --run-rust-tests to include)"
fi

if [[ -n "$JSON_OUT" ]]; then
  FFMPEG_SHA=$(shasum -a 256 "$FFMPEG" | awk '{print $1}')
  FFPROBE_SHA=$(shasum -a 256 "$FFPROBE" | awk '{print $1}')
  FFMPEG_ARCH=$(lipo -archs "$FFMPEG" 2>/dev/null || echo "unknown")
  FFPROBE_ARCH=$(lipo -archs "$FFPROBE" 2>/dev/null || echo "unknown")
  FFMPEG_VER=$("${RUN_FFMPEG[@]}" -version | head -n 1)
  node -e '
    const fs = require("fs");
    const out = {
      timestamp: new Date().toISOString(),
      ffmpeg: { path: process.argv[1], sha256: process.argv[2], archs: process.argv[3], version: process.argv[4] },
      ffprobe: { path: process.argv[5], sha256: process.argv[6], archs: process.argv[7] },
      counts: { passed: Number(process.argv[8]), failed: Number(process.argv[9]), skipped: Number(process.argv[10]) }
    };
    fs.writeFileSync(process.argv[11], JSON.stringify(out, null, 2) + "\n");
  ' "$FFMPEG" "$FFMPEG_SHA" "$FFMPEG_ARCH" "$FFMPEG_VER" \
    "$FFPROBE" "$FFPROBE_SHA" "$FFPROBE_ARCH" \
    "$PASS_COUNT" "$FAIL_COUNT" "$SKIP_COUNT" "$JSON_OUT"
fi

echo ""
if [[ "$FAIL_COUNT" -eq 0 ]]; then
  echo -e "${GREEN}${BOLD}All checks passed (${PASS_COUNT} passed, ${SKIP_COUNT} skipped).${RESET}"
  exit 0
else
  echo -e "${RED}${BOLD}Verification failed (${FAIL_COUNT} failed, ${PASS_COUNT} passed, ${SKIP_COUNT} skipped).${RESET}" >&2
  exit 1
fi
