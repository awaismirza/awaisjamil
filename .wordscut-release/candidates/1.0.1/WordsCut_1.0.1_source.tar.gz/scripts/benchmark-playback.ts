/** Algorithm microbenchmark only. Release WebView measurements are a separate gate. */
import { performance } from "node:perf_hooks";
import { writeFileSync } from "node:fs";
import { outputTimeToSource, type Project, type Segment } from "../src/lib/edl";
import { getTimelineIndex, indexedSource } from "../src/lib/timelineIndex";
function project(count: number, repeated: boolean): Project {
  const segments: Segment[] = Array.from({ length: count }, (_, i) => {
    const start = repeated ? 0 : i * 2;
    return { id: `s${i}`, mediaId: "m", sourceIn: start, sourceOut: start + 1, words: Array.from({ length: 12 }, (_, w) => ({ id: `w${i}-${w}`, text: "benchmark", start: start + w/12, end: start + (w+1)/12, confidence: 1 })) };
  });
  return { version: 1, id: "bench", name: "synthetic", createdAt: "", updatedAt: "", media: {}, segments, settings: { exportPreset: "youtube-1080p", paddingMs: 0 } };
}
function measure(fn: (time: number) => unknown, total: number) {
  for (let i=0;i<250;i++) fn((i*37 % total) + 0.25);
  const samples: number[] = [];
  for (let i=0;i<4000;i++) { const t = (i*37 % total) + 0.25, start = performance.now(); fn(t); samples.push(performance.now()-start); }
  samples.sort((a,b)=>a-b);
  return { samples: samples.length, p50Ms: samples[1999], p95Ms: samples[3799], maxMs: samples[3999] };
}
const cases = [ ["short",30,false], ["hundreds-of-cuts",1000,false], ["repeated-source-ranges",1000,true] ] as const;
const results = cases.map(([name,count,repeated]) => {
  const p = project(count,repeated), buildStart=performance.now(), index=getTimelineIndex(p.segments), buildMs=performance.now()-buildStart;
  return { name, entries: count, words: count*12, indexBuildMs: buildMs,
    baseline: measure(t=>outputTimeToSource(p,t),count), indexed: measure(t=>indexedSource(index,t),count) };
});
const report = { date: "2026-10-19", runtime: process.version, scope: "Node lookup microbenchmark; not packaged playback or a user-visible speedup measurement", results };
const json=JSON.stringify(report,null,2)+"\n";
if (process.argv[2]) writeFileSync(process.argv[2],json);
process.stdout.write(json);
