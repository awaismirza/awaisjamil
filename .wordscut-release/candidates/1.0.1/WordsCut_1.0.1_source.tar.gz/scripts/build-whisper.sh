#!/usr/bin/env bash
# Build a static whisper-cli (whisper.cpp v1.7.5, Metal + Core ML) into
# src-tauri/binaries/whisper-cli-aarch64-apple-darwin. Skips if a real static
# binary already exists. Same recipe as scripts/build-production.sh step 5a.
set -euo pipefail
REPO="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="$REPO/src-tauri/binaries/whisper-cli-aarch64-apple-darwin"
if [[ "${FORCE_WHISPER_BUILD:-0}" != 1 && -x "$OUT" ]] && ! head -c2 "$OUT" | grep -q '^#!' && ! otool -L "$OUT" | grep -q '@rpath/libwhisper'; then
  echo "whisper-cli already present (static)"; exit 0
fi
command -v cmake >/dev/null || { echo "cmake required (brew install cmake)" >&2; exit 1; }
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
git init -q "$TMP/src"
git -C "$TMP/src" remote add origin https://github.com/ggml-org/whisper.cpp
git -C "$TMP/src" fetch --depth 1 origin 51c6961c7b64b406833f4b6a4a20e67142f69225
git -C "$TMP/src" checkout --detach FETCH_HEAD
cmake -S "$TMP/src" -B "$TMP/build" -DCMAKE_BUILD_TYPE=Release -DBUILD_SHARED_LIBS=OFF \
  -DCMAKE_OSX_ARCHITECTURES=arm64 -DCMAKE_OSX_DEPLOYMENT_TARGET=13.0 \
  -DGGML_STATIC=ON -DGGML_NATIVE=OFF -DGGML_CPU_ARM_ARCH=armv8.2-a+fp16+dotprod \
  -DGGML_BLAS=OFF -DGGML_ACCELERATE=ON -DGGML_METAL=ON -DGGML_METAL_EMBED_LIBRARY=ON \
  -DWHISPER_COREML=ON -DWHISPER_BUILD_TESTS=OFF
cmake --build "$TMP/build" --target whisper-cli -j"$(sysctl -n hw.logicalcpu)"
BUILT="$(find "$TMP/build/bin" -name whisper-cli -perm +111 -type f | head -1)"
[[ -n "$BUILT" ]] || { echo "whisper-cli not produced" >&2; exit 1; }
mkdir -p "$(dirname "$OUT")"; cp "$BUILT" "$OUT"; chmod +x "$OUT"
echo "whisper-cli built: $OUT"
