const phrase = 'We can um make a really great video today.'.split(' ');
const words = document.querySelector('#demo-words');
const result = document.querySelector('#demo-result');
if (words && result) {
  words.replaceChildren(...phrase.map((text, index) => {
    const button = document.createElement('button');
    button.type = 'button'; button.className = 'word'; button.textContent = text;
    button.setAttribute('aria-pressed', 'false');
    button.setAttribute('aria-label', `Remove word ${index + 1}: ${text}`);
    button.addEventListener('click', () => {
      const removed = button.getAttribute('aria-pressed') !== 'true';
      button.setAttribute('aria-pressed', String(removed));
      button.setAttribute('aria-label', `${removed ? 'Restore' : 'Remove'} word ${index + 1}: ${text}`);
      const kept = [...words.children].filter(word => word.getAttribute('aria-pressed') === 'false');
      result.textContent = `${kept.length} words kept. ${kept.map(word => word.textContent).join(' ') || 'All words removed. Restore a word to keep it.'}`;
    });
    return button;
  }));
  document.querySelector('#reset-demo').addEventListener('click', () => {
    [...words.children].forEach((word, index) => { word.setAttribute('aria-pressed', 'false'); word.setAttribute('aria-label', `Remove word ${index + 1}: ${word.textContent}`); });
    result.textContent = '9 words kept. This is an interactive illustration, not a video upload.';
  });
}
// GitHub returns only published releases here. Never advertise a dry-run artifact.
fetch('https://api.github.com/repos/awaismirza/wordscut/releases/latest')
  .then(response => { if (!response.ok) throw new Error('Release not published'); return response.json(); })
  .then(release => {
    const installer = release.assets.find(asset => /^WordsCut_\d+\.\d+\.\d+_aarch64\.dmg$/.test(asset.name));
    const source = release.assets.find(asset => /^WordsCut_\d+\.\d+\.\d+_source\.tar\.gz$/.test(asset.name));
    const checksums = release.assets.find(asset => asset.name === 'SHA256SUMS.txt');
    if (!installer || !source || !checksums || release.draft || release.prerelease) return;
    const info = document.querySelector('#release-info');
    const label = document.createElement('p');
    label.textContent = `${release.tag_name.replace(/^v/, '')} · Developer ID signed and notarized by Apple`;
    const download = document.createElement('a'); download.className = 'button light';
    download.textContent = 'Download for Mac'; download.href = installer.browser_download_url;
    const links = document.createElement('p'); links.className = 'release-links';
    for (const [text, url] of [['Release notes', release.html_url], ['SHA-256 checksums', checksums.browser_download_url]]) {
      const link = document.createElement('a'); link.textContent = text; link.href = url; links.append(link);
    }
    info.replaceChildren(label, download, links);
  }).catch(() => { /* The honest unpublished-release fallback remains visible. */ });
