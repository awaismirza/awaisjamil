# Historical WordsCut download site

These static files are retained as historical source. Their deployment workflow has been retired. The current product, purchase-availability, privacy, terms and support pages live at https://awaisjamil.com/products/wordscut in `awaismirza/awaisjamil`.

Do not deploy this directory or its former public GitHub release links. Signed release orchestration and verification are owned by `awaisjamil/distribution/wordscut/` and `.github/workflows/wordscut-release.yml`. The complete original distribution website and repository history are preserved in the private migration backup.
