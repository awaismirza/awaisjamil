# WordsCut

> Local-first, transcript-based video editing for Apple Silicon Macs. Edit the
> words; WordsCut edits the video.

WordsCut is an open-source desktop editor for cutting talking-head videos,
podcasts, interviews, courses, screen recordings, and creator clips by editing
their transcript. Delete a word and the matching video disappears. Reorder
paragraphs and the video follows. Everything runs locally on your Mac with no
cloud upload, no telemetry, and no API keys.

The project is built with Tauri, React, TypeScript, Rust, whisper.cpp, and
FFmpeg. It currently targets Apple Silicon Macs.

## ❤️ Sponsor WordsCut

If WordsCut helps you, consider supporting the project:

[☕ Buy me a coffee](https://buymeacoffee.com/awaismirza)

## Why WordsCut?

- **Transcript-first editing:** the transcript is the timeline, not a side
  panel.
- **Local by default:** media, transcripts, models, and project files stay on
  your machine.
- **Fast Apple Silicon pipeline:** whisper.cpp uses Core ML and Metal; exports
  use FFmpeg with VideoToolbox where possible.
- **Real project files:** `.scribe` bundles store the edit decision list,
  metadata, snapshots, and project state.
- **Open-source foundation:** AGPL-licensed so improvements to the editor stay
  available to the community.

## Status

Recording timers now use encoded media time and Pause/Stop wait for FFmpeg to
exit before reading files. Baseline testing confirmed startup inflated the timer;
the older 0.501-second take remains an unresolved historical reproduction.
Further manual app verification is assigned to the owner.

WordsCut 1.0.0 ships reproducible native Apple Silicon (`arm64`) FFmpeg/FFprobe
packaging, automated media capability verification, and pipeline benchmarking,
alongside a compact recorder setup panel (display/window/area, permission prompts,
thumbnails, camera and microphone previews), desktop recording controller,
indexed playback, real audio waveforms, undoable clip trimming/splitting/roll
edits, preview quality controls, and playable recordings while transcription runs in
the background on Apple Silicon Macs. Native screen + camera Stop no longer
re-encodes the take: the camera is added by a background job (agent-verified by
automated tests only; not yet run in the real app). WordsCut 1.0.0 is the first
public release; expect fast iteration and some rough edges around packaging.

| Feature | State |
|---|---|
| Media import with FFprobe | Complete |
| Whisper.cpp transcription with Core ML + Metal | Complete |
| Transcript editor with TipTap + custom word nodes | Complete |
| EDL-based edit operations + 50-step undo | Complete |
| Project save/load as `.scribe` bundles | Complete |
| Smart-cut MP4 export with FFmpeg + VideoToolbox | Complete |
| Export to MOV, ProRes 422 / 422 HQ, GIF, M4A and WAV, a time range, and audio stems | Complete |
| ProRes 4444 export with real alpha, Look tab transparent background (checkerboard preview) and source crop; formats without alpha flatten to black with a warning | Complete (HEVC alpha not offered: bundled ffmpeg cannot write it) |
| Background job queue with cancellation | Complete |
| Multi-clip editing and Add Clip support | Complete |
| Multi-track audio with music ducking, per-track mute / solo / fades, preview playback of music tracks (no ducking in preview), export loudness target (loudnorm) and a post-export loudness / clipping report | Complete (preview audio not yet heard in the running app) |
| Voice-over track: record narration at the playhead (Cmd+Option+V or Music panel), review the take (play, Overlay / Insert, Override the original audio, Keep / Retake / Discard, keyboard only), kept as an editable track; Insert holds the anchor frame and moves later content; Override mutes the clip audio only while the take plays; preview, export, stems and captions follow it | Export verified with real ffmpeg and synthetic tones; recording, review and preview audio need owner QA in the app |
| Project snapshots and named restore points | Complete |
| FCPXML 1.10 timeline export (Export tab): clips, chapter markers and music; scene, zoom, cursor, captions, annotations, keystrokes, image/video overlays, privacy masks (listed as NOT APPLIED), ducking, speed, freeze frames, clip mute and transitions are not carried over (`docs/architecture.md`) | Complete (Final Cut import not yet verified) |
| Styled captions: font, size, color, outline/shadow/box, position, line limits, spoken-word highlight; live in the preview and burned into the export (Export dialog, off by default); SRT/VTT export unchanged | Complete (not yet checked in the running app) |
| One left sidebar of tool tabs (Media, Transcribe, Cleanup, Chapters, Zoom, Timing, Look, Captions, Overlays, Find, Tools, Music, Export, Settings); no workspace modes | Complete |
| Start screen with import, record and recent projects | Complete |
| Top-bar Project menu with recent projects | Complete |
| Blocking-operation progress dialogs | Complete |
| Filler word removal: safe hesitation sounds by default, real words opt-in, multi-word phrases, highlighted and counted before cutting | Complete |
| DTW word-timestamp refinement via `whisper.cpp --dtw` | Complete |
| Cut-point pre-roll padding | Complete |
| Timeline zoom and in/out markers | Complete |
| Auto chapters from the transcript (no model, reviewed before adding) | Complete |
| Selection flyout: play, cut, keep only, mark, start chapter, copy, zoom, timing | Complete |
| Zoom regions: select words and zoom in, drag zoom blocks on the timeline, in preview and export | Complete |
| Clip timing (Timing tab, or Timing on a selection): speed 0.25–4x with pitch kept, clip mute, freeze last frame, crossfade or dip-to-black into a clip; one time mapping keeps transcript, captions, chapters, zoom, cursor and music aligned | Export verified with real ffmpeg; preview playback needs owner QA in the app |
| Auto zoom from cursor logs: review suggestions, Add/Replace, scale, sensitivity, clicks/typing, Follow cursor | Fixture/import workflow tested; native recording attachment implemented, owner QA pending |
| Cursor styling: six shapes, size, colour, smoothing, click effects, idle hiding and blur trails | Preview and video export |
| Annotations: text, arrows and boxes with fades, fixed on screen or following zoom, retimed through cuts (Overlays tab) | Preview and video export; not yet checked in the running app |
| Image and video overlays (PNG, JPEG, GIF, MP4, MOV; transparency kept): position, size, opacity, rotation, rounded corners, fades, fixed or following zoom, optional own audio with gain; files referenced in place (never copied or uploaded), checksum-verified relink (Overlays tab) | Preview and video export (real-ffmpeg tests); not yet checked in the running app |
| Privacy masks: solid fill, pixelate, blur or dim-surround over a rectangle or ellipse of a source's picture, anchored to that source's time so every copy of the footage is masked (duplicates, moves, restores, speed, holds), applied per clip before transitions, zoom, crop, device frames and overlays (a voice-over insert hold of masked footage is masked too; no key caps for presses under a mask); static regions (they do not track moving content); "Check coverage" contact sheet | Export verified with real ffmpeg (crossfade / dip edges, duplicates, 4x, 4:3 source, zoom + crop, GIF, cursor); preview and app use not yet checked |
| Keystroke overlay (opt-in): shortcut key caps from recorded key events; modifiers only unless the opt-in "Record key names" recorder option is on (then ⌘/⌃ shortcuts and navigation keys are named; typing keys and characters only with a second opt-in that is never remembered; keys typed in any app are captured during screen recording; passwords are normally missing or hidden but not guaranteed); caps move above bottom captions when captions are burned in | Preview and video export; not yet checked in the running app |
| Extract / delete the marked in–out range | Complete |
| Pause badges: remove or shorten long pauses (cut from preview and export) | Complete |
| Built-in screen / camera / voice recorder with picture-in-picture | Complete |
| Native capture helper (ScreenCaptureKit + AVFoundation): separate aligned tracks, cursor/click/key events, window capture, system audio; ffmpeg fallback | Integrated; owner capture QA pending (`docs/native-capture.md`) |
| Floating recorder bar (display/window/area, camera, mic, system audio; "Dialog" style in Settings) | Complete; owner QA pending |
| Customisable global recording shortcuts (start/stop, pause, restart, mark a moment, discard) | Complete |
| Menu-bar item with live timer and recorder controls | Complete |
| Settings tab (shortcuts, recorder style, countdown, one-press start, auto-transcribe) | Complete |
| Look tab: background (presets, colour, gradient, image), padding, rounded corners, shadow, aspect ratio, in preview and export | Complete |
| Look tab device frames: browser window (light/dark, address text), laptop, phone, tablet, drawn procedurally (no artwork), in preview and export, alpha-clean in ProRes 4444 | Complete; not yet checked in the running app |
| Recordings auto-transcribed and appended to the end of the video | Complete |
| Clip timeline editing: trim past words, split, roll cuts, duplicate, drag to reorder (Option+arrows too), ripple delete; restore deleted words (store/library) | Undoable clip lane; complete-original recovery for new transcripts; drag gestures not yet verified in the running app |
| Missing-media relink dialog on project open (Locate, original file only: duration, streams and checksum checked) | Implemented; owner QA pending |
| Agent CLI / MCP: `WordsCut agent` and `WordsCut mcp` let Claude Code, Codex or Gemini CLI drive the open project (20 tools, plan then apply, undoable; off by default) | Implemented; owner QA pending (`docs/agent-cli-design.md`) |
| Core Image/Metal rendering | Planned |
| Speaker diarisation | Experimental |
| Developer ID signing and notarisation | Legacy 1.0.0 app/DMG verified; distribution verification now runs in awaisjamil |
| Auto-update | Planned |

### Auto zoom and cursor preview

Open **Zoom**, select a video under **Cursor data**, and load its `events.jsonl`.
In development, **Load synthetic cursor demo (development)** supplies a 20-second
click/typing fixture for the selected video. Enable **Follow cursor**, press
**Generate from cursor**, review/play/keep/remove suggestions, then **Add** or
**Replace**. Suggestions and focus motion follow the edited timeline; Add/Replace
is one undo action. Preferences and processed logs are saved in the project.

Zoom, follow motion and cursor styling render in MP4 exports. Native screen recordings automatically load their cursor logs in the background;
manual capture verification belongs to the owner. A burned-in
cursor in an old recording cannot be removed by hiding this preview overlay.

## Screenshots

Real application screenshots and the product page are now hosted at https://awaisjamil.com/products/wordscut. Signed/notarized legacy release 1.0.0 and its complete verification record are retained privately in the awaisjamil repository. A paid release is in preparation; no new installer or paid checkout is advertised yet.

## Requirements

- macOS on Apple Silicon
- Node.js 20 or newer
- Rust stable via `rustup`
- Xcode Command Line Tools
- Sidecar binaries for transcription/export:
  `whisper-cli`, `ffmpeg`, and `ffprobe`
- Optional: the native recorder helper (`npm run native:build`, needs Swift from Xcode);
  without it the recorder uses ffmpeg

## Quick Start

### First-time setup

Clone the repository and install dependencies:

```bash
git clone https://github.com/awaismirza/wordscut-app.git
cd wordscut-app
nvm use
npm run setup:all
```

The `setup:all` script handles:
- Node.js dependencies installation
- Rust toolchain setup
- Sidecar binary fetching (FFmpeg, FFprobe)

The Whisper CLI binary may need to be built separately. See [`src-tauri/binaries/README.md`](src-tauri/binaries/README.md) for instructions.

### Local development

Start the full desktop app (React + Tauri + Rust):

```bash
npm start
```

The dev server reloads on file changes. First launch takes ~30–60 seconds while Rust compiles; subsequent restarts are faster.

### Production build

Build a release-ready `.app` and `.dmg` for macOS:

```bash
npm run build:production
```

The built artifacts will be in `src-tauri/target/release/bundle/`.

## Common Commands

| Command | What it does |
|---|---|
| `npm run dev` | Start the Vite UI only |
| `npm run tauri:dev` | Run the full desktop app |
| `npm run app:install` | One command: real capture helper + `.app`/`.dmg` + install to `/Applications` (`-- --no-install`, `-- --check`, `-- --no-sign`; signs by default) |
| `npm run tauri:build` | Build a release `.app` and `.dmg` |
| `npm run typecheck` | Run TypeScript checks |
| `npm run lint` | Run ESLint over the frontend |
| `npm test` | Run Vitest unit tests |
| `npm run test:rust` | Run Rust tests |
| `npm run media:build` | Build native Apple Silicon (`arm64`) FFmpeg/FFprobe from pinned sources |
| `npm run media:verify` | Verify native `arm64` FFmpeg/FFprobe architecture, linkage, and capabilities |
| `npm run media:bench` | Run the reproducible 7-stage native `arm64` media pipeline benchmark |
| `npm run check` | Run typecheck and lint |
| `npm run ci` | Run the full local CI suite |

## How It Works

The Edit Decision List (EDL) is the source of truth. It is a flat list of
segments, each pointing into a source media file with `sourceIn`, `sourceOut`,
and word-level timing metadata. The transcript view, preview player, waveform,
snapshots, and export pipeline all derive from this structure.

Edits are pure transformations. Deleting a word range splits surrounding
segments and drops the middle. Source timecodes on words are never mutated,
which keeps preview, undo, save/load, and export predictable.

Read more in:

- [`docs/architecture.md`](docs/architecture.md)
- [`docs/yusafcut-spec.md`](docs/yusafcut-spec.md)
- [`docs/ROADMAP.md`](docs/ROADMAP.md)
- [`docs/manual-test.md`](docs/manual-test.md)

## Privacy Model

WordsCut is local-first:

- Your media is not uploaded.
- Generated transcripts stay on your machine.
- There is no telemetry, analytics, or remote crash reporting in v1.
- Network access is limited to model downloads and, once enabled, release
  update metadata.

See [`SECURITY.md`](SECURITY.md) for the current threat model and vulnerability
reporting process.

## Project Files

WordsCut currently saves projects as `.scribe` bundles. The extension is kept
for compatibility with existing project files while the product name changes to
WordsCut.

## Tech Stack

- **Tauri 2.x:** native macOS shell and Rust backend
- **React + TypeScript + Vite:** frontend app
- **Tailwind + shadcn/ui:** styling and UI primitives
- **TipTap / ProseMirror:** transcript editing surface
- **Zustand + zundo:** state management and undo
- **FFmpeg + viewport canvas:** cached multiresolution audio waveforms
- **whisper.cpp:** local transcription
- **FFmpeg:** media processing and export
- **AVFoundation (contract slice, off by default, not bundled):** `native/yusafcut-engine` (`docs/native-engine.md`); preview and export still use the HTML5 `<video>` and FFmpeg

## Contributing

Contributions are welcome. Please start with
[`CONTRIBUTING.md`](CONTRIBUTING.md), especially the EDL invariants and testing
expectations. For larger architectural changes, open an issue first so the
direction can be discussed before implementation.

Good first contribution areas:

- Improve onboarding and setup docs.
- Add screenshots and short demo assets.
- Expand manual and automated regression coverage.
- Improve packaging, signing, notarisation, and release automation.
- Polish accessibility and keyboard workflows.

## Security

Please do not open public issues for vulnerabilities. Follow the private
reporting process in [`SECURITY.md`](SECURITY.md).

## License

WordsCut is licensed under
[AGPL-3.0-or-later](LICENSE).

The AGPL protects against closed-source hosted or networked forks of an editor
with this much local-first value. Reusable libraries split out of this repo may
use a more permissive license in the future.

### Playback and timeline improvements (4.19.0)

Original / Balanced / Low changes preview quality only; exports always read
original files. Disposable FFmpeg waveform/proxy caches live in the app cache
folder. Generation and transcription share one analysis slot; cache jobs are
cancellable in Jobs. Recordings enter the timeline as soon as import finishes,
with nonblocking transcription progress in the status bar. Words attach to
surviving edits and undo history when recognition finishes.

Select a clip in the timeline to split at the playhead or roll its next cut.
Drag clip edges to trim; arrow keys move an edge one frame, Shift moves one
second, and Alt disables snapping. Drag a clip's name to reorder it (Esc, leaving the window or releasing back in place cancels; Option+Left/Right moves the focused clip); Duplicate clip and Ripple delete are in the clip tools. Newly transcribed media preserve originals
for extension. Legacy projects still open, but missing deleted words cannot be
recovered without retranscription. Zoom's secondary lane can be collapsed.

Settings includes opt-in local playback diagnostics. The saved index lookup
microbenchmark is not a packaged-app performance certification. Native capture UI QA, the desktop recorder pill and the full
release/30-minute benchmark matrix remain pending; see `docs/HANDOFF.md`.

Recording controls can be moved or hidden in Settings → Recording. Screen capture
always suppresses this in-editor overlay; use the Mac menu-bar timer/menu or
global shortcuts for Stop, Pause/Resume and Mark. The separate desktop controller
with native capture exclusion is still pending integration.

The latest capture audit found a paused-audio timer/file-duration mismatch in one
real test. The first audio take was correct; this regression is unresolved and
blocks final integration/merge. Details and reproduction context are in HANDOFF
§4.6. The current branch is a tested implementation checkpoint, not a completed
release of the full recorder plan.

## WordsCut distribution (1.0.0)

WordsCut is the new name for YusafCut. Existing `.scribe` projects and application data stay compatible; the bundle identifier, storage keys, Rust crate and native helper filenames retain their original identifiers. The installed executable is now `/Applications/WordsCut.app/Contents/MacOS/WordsCut`; update hardcoded CLI/MCP paths.

Product, purchase availability and support: https://awaisjamil.com/products/wordscut
Private source repository: https://github.com/awaismirza/wordscut-app

Release orchestration now lives in `awaismirza/awaisjamil`: `.github/workflows/wordscut-release.yml` and `distribution/wordscut/`. It builds reviewed private source snapshots, signs/notarizes/staples the app and DMG, and verifies actual downloaded candidate assets. Installers, matching sources and build diagnostics remain in maintainer-only draft releases. They must not be published as free GitHub/Pages downloads. See the awaisjamil repository's `docs/wordscut-distribution.md` and `docs/wordscut-commerce.md`.

Working source is now 1.0.1 (unreleased administrative migration); the retained signed release remains 1.0.0 and its bytes are unchanged. Existing AGPL-licensed recipients keep their rights and can request the corresponding application/dependency source from support. A future proprietary release requires an ownership and dependency-licence review; this migration does not change the application's licence.
